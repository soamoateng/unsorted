# eStore — Fashion & Lifestyle Shop (Pure Vanilla JS)

A self-contained e-commerce front-end inspired by the BootstrapMade *eStore* demo,
rebuilt from scratch with **100% original code** — plain HTML5, CSS3 and vanilla
JavaScript. No Bootstrap, no jQuery, no Swiper, no build tools, zero dependencies.

- **Project:** estore
- **Version:** 1.2.0
- **Iteration:** 4
- **License:** original code, MIT-style; use freely

## Features

| Area | Details |
|------|---------|
| Header | Rotating announcement top-bar, category-aware search, currency selector (USD/EUR/GBP), wishlist & cart badges |
| Navigation | Dropdown menu, smooth-scroll anchors, mobile off-canvas menu with its own search + currency controls |
| Mobile UX | Always-visible search row in the sticky header (≤880px), currency reachable in topbar and menu at every size |
| Hero | 3-slide carousel — autoplay, swipe, keyboard arrows, dots |
| Catalog | 17-product catalog rendered from `products.js`, filter tabs (All / On sale / Featured / Top rated), category & search filtering |
| Product cards | Discount/top badges, wishlist toggle, quick-view modal, add-to-cart |
| Cart | Slide-in drawer, quantity steppers, line totals, subtotal, localStorage persistence |
| Wishlist | Persistent wishlist with move-to-cart support |
| Pricing | Live currency conversion (USD / EUR / GBP) across every price |
| Deal block | Deal-of-the-day with live countdown timer + stock bar |
| Extras | Testimonial slider, promo banners, newsletter form, toasts, back-to-top, scroll-reveal animations |

## Project structure

```
estore/
├── index.html              # Single-page storefront
├── assets/
│   ├── css/styles.css      # Full design system + responsive layout (~600 lines)
│   ├── js/products.js      # 17-product catalog + testimonial data
│   ├── js/app.js           # All interactivity, vanilla JS (~690 lines)
│   └── img/                # 22 optimized JPG assets (products, hero, promo)
├── VERSION                 # Version / iteration stamp
└── README.md
```

## Getting started

Everything is relative-pathed, so it runs anywhere:

- **Simplest:** unzip and double-click `index.html` (works straight from disk), or
- **Local server:** `python3 -m http.server 8080` in this folder → http://localhost:8080

State (cart, wishlist, currency, slide position) persists via `localStorage` —
clear your browser storage to reset the demo.

## Browser support

Chrome / Edge / Firefox / Safari (current versions). Uses ES6+, `IntersectionObserver`
and CSS custom properties. Respects `prefers-reduced-motion`.

## Changelog

### v1.2.0 — iteration 4 (2026-09-19) — mobile search & currency UX
Closed the two limitations documented during the iteration-3 audit, plus two
smaller defects uncovered while verifying them in a real browser:

- **Mobile search (was hidden ≤880px):** the header now wraps into two rows on
  tablets/phones — burger/logo/actions on top, the category-aware search pill
  always visible below (compact sizing at ≤620px, down to 320px viewports)
- **Mobile currency (was hidden ≤880px):** the topbar keeps the currency
  select on small screens (only the two text links are dropped); the
  off-canvas menu gains its own currency selector as well
- **Mobile menu search:** the off-canvas menu now has a search field; it
  searches the whole catalog (category resets to "all"), closes the menu,
  scrolls to the grid and stays in sync with the header search box in both
  directions — all currency selects are synced the same way
- **Fixed while verifying:** inactive testimonial slides poked ~11px past the
  right viewport edge on phones creating horizontal scroll (`.testi__slides`
  now clips its sliding children); the filter-tab pill can be swiped
  horizontally at ≤620px instead of overflowing 320px viewports; closing the
  mobile menu via Escape or the scrim now resets the burger button's
  `aria-expanded` on every close path
- Desktop (≥881px) rendering is byte-for-byte unaffected — all new rules live
  inside the existing media queries

### v1.1.0 — iteration 3 (2026-09-19) — full error audit & hardening
Systematic audit across syntax / runtime / logic / type / range / workflow /
a11y / security / performance categories, then browser-verified fixes:

- **Robustness (type/range):** persisted cart, wishlist and currency are now
  sanitized on load — corrupted or tampered `localStorage` can no longer crash
  the app (`Object.values(null)` TypeError left deal prices blank) and phantom
  ids / quantities > 99 are dropped or clamped
- **Logic:** nav tab/category links no longer render with stale search filters;
  the sale-category shortcut also clears the search query; search UI stays in
  sync with programmatic filter changes
- **UX/keyboard:** ArrowLeft/Right no longer hijack the hero slider while
  typing in inputs; clearing the search box resets the results
- **Business rules:** hard per-line cart cap of 99 enforced everywhere
  (quick-view input bypass fixed); quick-view "free shipping" figure re-prices
  with the selected currency; deal countdown rolls forward when it expires
  mid-session instead of sticking at 00:00:00:00
- **Workflow:** quick-view closes on dimmed-backdrop click; Escape and scrim
  clicks now resync `aria-hidden`/`inert` on every layer; drawer X buttons use
  the same central layer manager
- **Accessibility:** closed drawers/modal/mobile nav are `inert` (not
  keyboard-focusable); slider dots expose `aria-selected`; the desktop
  dropdown toggles on click with `aria-expanded`; placeholder `#` links no
  longer jump to page top
- **UI/CSS:** back-to-top button is click-through-proof while invisible;
  scrim fades out instead of snapping; error toasts get a red icon; the deal
  stock bar animation actually plays (starts at 0%)
- **Performance:** wishlist toggles update the heart in place instead of
  re-rendering the whole grid (no animation replay); countdown cells cached

### v1.0.0 — iteration 2 (2026-09-19)
- Packaging release: verified full smoke test in headless Chromium (17 cards render,
  cart/wishlist badges update, zero console errors)
- Added `VERSION` stamp and this `README.md`; no functional changes to iteration-1 code

### v1.0.0 — iteration 1 (initial build)
- Complete storefront: hero carousel, filterable 17-product catalog, quick view,
  persistent cart & wishlist drawers, currency switcher, countdown deal, sliders,
  mobile navigation, scroll effects — all in dependency-free vanilla JS
