/* ═══════════════════════════════════════════════════════════
   eStore — application logic in pure vanilla JavaScript
   (no jQuery, no Bootstrap, no libraries of any kind)
   ═══════════════════════════════════════════════════════════ */
(function () {
  "use strict";

  /* ── Tiny DOM helpers ─────────────────────────────────── */
  const $  = (sel, root) => (root || document).querySelector(sel);
  const $$ = (sel, root) => Array.from((root || document).querySelectorAll(sel));

  const store = {
    get(key, fallback) {
      try { const v = localStorage.getItem(key); return v ? JSON.parse(v) : fallback; }
      catch (e) { return fallback; }
    },
    set(key, val) {
      try { localStorage.setItem(key, JSON.stringify(val)); } catch (e) { /* private mode */ }
    }
  };

  /* ── Catalog & state ──────────────────────────────────── */
  const PRODUCTS = window.PRODUCTS || [];
  const TESTIMONIALS = window.TESTIMONIALS || [];
  const byId = id => PRODUCTS.find(p => p.id === id);

  const CURRENCIES = { USD: { rate: 1,    symbol: "$", before: true },
                       EUR: { rate: 0.92, symbol: "€", before: true },
                       GBP: { rate: 0.79, symbol: "£", before: true } };
  let currency = store.get("estore-currency", "USD");
  if (!CURRENCIES[currency]) currency = "USD";          // guard against corrupted storage

  /* Sanitize persisted state — corrupted/tampered localStorage must never crash the app */
  const KNOWN_IDS = new Set(PRODUCTS.map(p => p.id));
  function sanitizeQty(n) {
    n = parseInt(n, 10);
    if (!Number.isFinite(n) || n < 1) return 0;
    return Math.min(99, n);
  }
  const rawCart = store.get("estore-cart", {});
  const cart = {};                                     // { productId: qty }
  if (rawCart && typeof rawCart === "object" && !Array.isArray(rawCart)) {
    Object.keys(rawCart).forEach(id => {
      const q = sanitizeQty(rawCart[id]);
      if (q > 0 && KNOWN_IDS.has(id)) cart[id] = q;    // drop phantom/unknown ids
    });
  }
  const rawWish = store.get("estore-wishlist", []);
  let wishlist = Array.isArray(rawWish)
    ? rawWish.filter(id => typeof id === "string" && KNOWN_IDS.has(id))
    : [];                                              // [productId]
  let activeTab  = "all";
  let searchQuery = "";
  let searchCategory = "all";

  function money(usd) {
    const c = CURRENCIES[currency] || CURRENCIES.USD;
    const v = usd * c.rate;
    const formatted = v.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    return c.before ? c.symbol + formatted : formatted + " " + c.symbol;
  }

  /* ── Toasts ───────────────────────────────────────────── */
  const toastHost = $("#toasts");
  function toast(msg, isError) {
    if (!toastHost) return;
    const el = document.createElement("div");
    el.className = "toast" + (isError ? " toast--error" : "");
    el.innerHTML = '<span class="toast__check">' + (isError ? "!" : "&#10003;") + "</span><span></span>";
    el.lastChild.textContent = msg;
    toastHost.appendChild(el);
    setTimeout(() => el.remove(), 3100);
  }

  /* ── Layer manager (drawers / modal / mobile nav) ──────
     Every open/close path syncs class + aria-hidden + inert so the
     state can never drift out of sync, whatever way a layer closes. */
  const scrim = $("#scrim");
  const LAYER_IDS = ["cartDrawer", "wishDrawer", "quickView", "mobileNav"];
  let openLayers = [];
  function syncLayer(el, open) {
    if (!el) return;
    el.classList.toggle("is-open", open);
    el.setAttribute("aria-hidden", open ? "false" : "true");
    if (open) el.removeAttribute("inert"); else el.setAttribute("inert", "");
    // Every close path (Escape / scrim / X) must reset the burger button state too
    if (el.id === "mobileNav" && !open) {
      const t = $("#navToggle");
      if (t) t.setAttribute("aria-expanded", "false");
    }
  }
  function syncScrim() {
    const anyOpen = openLayers.length > 0;
    scrim.classList.toggle("is-visible", anyOpen);
    document.body.style.overflow = anyOpen ? "hidden" : "";
  }
  function registerLayer(name) {
    if (!openLayers.includes(name)) openLayers.push(name);
    syncLayer(document.getElementById(name), true);
    syncScrim();
  }
  function unregisterLayer(name) {
    openLayers = openLayers.filter(n => n !== name);
    syncLayer(document.getElementById(name), false);
    syncScrim();
  }
  function closeAllLayers() {
    openLayers.slice().forEach(name => syncLayer(document.getElementById(name), false));
    openLayers = [];
    syncScrim();
  }
  scrim.addEventListener("click", closeAllLayers);
  document.addEventListener("keydown", e => { if (e.key === "Escape") closeAllLayers(); });
  $$("[data-close-drawer]").forEach(btn =>
    btn.addEventListener("click", () => unregisterLayer(btn.dataset.closeDrawer)));

  /* ── Stars markup ─────────────────────────────────────── */
  function starsHTML(rating) {
    const full = Math.floor(rating);
    const half = rating - full >= 0.4;
    return "&#9733;".repeat(full) + (half ? "&#189;" : "") ;
  }

  /* ── Product grid ─────────────────────────────────────── */
  const grid = $("#productsGrid");
  const emptyMsg = $("#productsEmpty");

  function currentList() {
    return PRODUCTS.filter(p => {
      if (activeTab === "sale" && !p.onSale) return false;
      if (activeTab === "featured" && !p.featured) return false;
      if (activeTab === "top" && !p.top) return false;
      if (searchCategory !== "all" && p.category !== searchCategory) return false;
      if (searchQuery) {
        const hay = (p.name + " " + p.category + " " + p.desc).toLowerCase();
        if (!hay.includes(searchQuery)) return false;
      }
      return true;
    });
  }

  function cardHTML(p, i) {
    const flags = [];
    if (p.oldPrice) flags.push('<span class="flag flag--sale">-' + Math.round((1 - p.price / p.oldPrice) * 100) + "%</span>");
    if (p.rating >= 4.8) flags.push('<span class="flag flag--top">Top</span>');
    if (!p.oldPrice && p.rating < 4.8 && p.featured) flags.push('<span class="flag flag--new">New</span>');
    const wished = wishlist.includes(p.id);
    return (
      '<article class="card" style="animation-delay:' + (i % 8) * 60 + 'ms" data-id="' + p.id + '">' +
        '<div class="card__media">' +
          '<img src="' + p.img + '" alt="' + p.name + '" loading="lazy">' +
          '<div class="card__badges">' + flags.join("") + "</div>" +
          '<button class="card__wish' + (wished ? " is-active" : "") + '" data-wish="' + p.id + '" aria-label="Toggle wishlist for ' + p.name + '">' +
            '<svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20.5s-7.5-4.6-9.3-9.2C1.4 8 3.4 4.9 6.6 4.9c2 0 3.6 1.1 4.4 2.7h2c.8-1.6 2.4-2.7 4.4-2.7 3.2 0 5.2 3.1 3.9 6.4-1.8 4.6-9.3 9.2-9.3 9.2z"/></svg>' +
          "</button>" +
          '<div class="card__actions">' +
            '<button class="card__btn" data-add="' + p.id + '">' +
              '<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg>Add to cart</button>' +
            '<button class="card__btn card__btn--icon" data-view="' + p.id + '" aria-label="Quick view ' + p.name + '">' +
              '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12z"/><circle cx="12" cy="12" r="3"/></svg>' +
            "</button>" +
          "</div>" +
        "</div>" +
        '<div class="card__body">' +
          '<span class="card__cat">' + p.category + "</span>" +
          '<h3 class="card__title"><a href="#" data-view="' + p.id + '">' + p.name + "</a></h3>" +
          '<div class="card__rating"><span class="stars" aria-hidden="true">' + starsHTML(p.rating) + '</span><small>' + p.rating.toFixed(1) + " (" + p.reviews + ")</small></div>" +
          '<div class="card__price-row"><span class="card__price price" data-price="' + p.price + '">' + money(p.price) + "</span>" +
          (p.oldPrice ? '<span class="price price--old" data-price="' + p.oldPrice + '">' + money(p.oldPrice) + "</span>" : "") +
          "</div>" +
        "</div>" +
      "</article>"
    );
  }

  function renderProducts() {
    if (!grid) return;
    const list = currentList();
    grid.innerHTML = list.map(cardHTML).join("");
    emptyMsg.hidden = list.length > 0;
  }

  /* Grid interactions (event delegation) */
  grid.addEventListener("click", e => {
    const wishBtn = e.target.closest("[data-wish]");
    const addBtn  = e.target.closest("[data-add]");
    const viewEl  = e.target.closest("[data-view]");
    if (wishBtn) { toggleWish(wishBtn.dataset.wish); return; }
    if (addBtn)  { addToCart(addBtn.dataset.add, 1); return; }
    if (viewEl)  { e.preventDefault(); openQuickView(viewEl.dataset.view); }
  });

  /* ── Cart ─────────────────────────────────────────────── */
  const cartItems = $("#cartItems");
  const cartCount = $("#cartCount");
  const cartSubtotal = $("#cartSubtotal");
  const cartDrawerCount = $("#cartDrawerCount");

  function cartQty() { return Object.values(cart).reduce((a, b) => a + (parseInt(b, 10) || 0), 0); }
  function cartSum() {
    return Object.entries(cart).reduce((sum, idQty) => {
      const p = byId(idQty[0]); return p ? sum + p.price * idQty[1] : sum;
    }, 0);
  }

  function addToCart(id, qty) {
    const p = byId(id);
    if (!p) return;
    const add = Math.min(99, Math.max(1, parseInt(qty, 10) || 1));
    cart[id] = Math.min(99, (cart[id] || 0) + add);   // hard per-line cap
    store.set("estore-cart", cart);
    renderCart();
    toast(p.name + " added to cart");
  }

  function setQty(id, qty) {
    if (qty <= 0) { delete cart[id]; } else { cart[id] = Math.min(qty, 99); }
    store.set("estore-cart", cart);
    renderCart();
  }

  function renderCart() {
    const n = cartQty();
    cartCount.textContent = n;
    cartCount.hidden = n === 0;
    cartDrawerCount.textContent = n ? "(" + n + " item" + (n > 1 ? "s" : "") + ")" : "";
    cartSubtotal.textContent = money(cartSum());

    if (n === 0) {
      cartItems.innerHTML =
        '<div class="drawer__empty"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"><path d="M6 7h12l1.2 12.2a1.8 1.8 0 0 1-1.8 1.8H6.6a1.8 1.8 0 0 1-1.8-1.8L6 7z"/><path d="M9 10V6a3 3 0 0 1 6 0v4"/></svg><p>Your cart is empty.<br>Time to fix that.</p></div>';
      return;
    }
    cartItems.innerHTML = Object.entries(cart).map(([id, qty], i) => {
      const p = byId(id);
      if (!p) return "";
      const q = parseInt(qty, 10) || 0;   // hardened display value
      return (
        '<div class="line-item" style="animation-delay:' + i * 40 + 'ms">' +
          '<img class="line-item__img" src="' + p.img + '" alt="' + p.name + '">' +
          "<div>" +
            '<div class="line-item__t">' + p.name + "</div>" +
            '<div class="line-item__p">' + money(p.price) + "</div>" +
            '<div class="line-item__ctrl">' +
              '<span class="qty"><button data-cart-minus="' + id + '" aria-label="Decrease">&minus;</button>' +
              "<input value=\"" + q + '" readonly aria-label="Quantity">' +
              '<button data-cart-plus="' + id + '" aria-label="Increase">+</button></span>' +
              '<button class="line-item__remove" data-cart-remove="' + id + '">Remove</button>' +
            "</div>" +
          "</div>" +
          '<button class="line-item__x" data-cart-remove="' + id + '" aria-label="Remove ' + p.name + '">&#10005;</button>' +
        "</div>"
      );
    }).join("");
  }

  cartItems.addEventListener("click", e => {
    const plus = e.target.closest("[data-cart-plus]");
    const minus = e.target.closest("[data-cart-minus]");
    const rem = e.target.closest("[data-cart-remove]");
    if (plus) setQty(plus.dataset.cartPlus, (cart[plus.dataset.cartPlus] || 0) + 1);
    if (minus) setQty(minus.dataset.cartMinus, (cart[minus.dataset.cartMinus] || 0) - 1);
    if (rem) { const p = byId(rem.dataset.cartRemove); setQty(rem.dataset.cartRemove, 0); if (p) toast(p.name + " removed"); }
  });

  $("#cartBtn").addEventListener("click", () => registerLayer("cartDrawer"));
  $("#checkoutBtn").addEventListener("click", () => {
    if (cartQty() === 0) { toast("Your cart is empty", true); return; }
    toast("Demo checkout — thanks for trying eStore!");
  });

  /* ── Wishlist ─────────────────────────────────────────── */
  const wishItems = $("#wishItems");
  const wishCount = $("#wishlistCount");
  const wishDrawerCount = $("#wishDrawerCount");

  function toggleWish(id) {
    const p = byId(id);
    if (!p) return;
    if (wishlist.includes(id)) {
      wishlist = wishlist.filter(w => w !== id);
      toast(p.name + " removed from wishlist");
    } else {
      wishlist.push(id);
      toast(p.name + " saved to wishlist");
    }
    store.set("estore-wishlist", wishlist);
    renderWishlist();
    // Update the heart in place — a full grid re-render would replay every card animation
    const heartBtn = grid.querySelector('[data-wish="' + id + '"]');
    if (heartBtn) heartBtn.classList.toggle("is-active", wishlist.includes(id));
  }

  function renderWishlist() {
    wishCount.textContent = wishlist.length;
    wishCount.hidden = wishlist.length === 0;
    wishDrawerCount.textContent = wishlist.length ? "(" + wishlist.length + ")" : "";
    if (!wishlist.length) {
      wishItems.innerHTML = '<div class="drawer__empty"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20.5s-7.5-4.6-9.3-9.2C1.4 8 3.4 4.9 6.6 4.9c2 0 3.6 1.1 4.4 2.7h2c.8-1.6 2.4-2.7 4.4-2.7 3.2 0 5.2 3.1 3.9 6.4-1.8 4.6-9.3 9.2-9.3 9.2z"/></svg><p>Nothing saved yet.<br>Tap the heart on any product.</p></div>';
      return;
    }
    wishItems.innerHTML = wishlist.map((id, i) => {
      const p = byId(id);
      if (!p) return "";
      return (
        '<div class="line-item" style="animation-delay:' + i * 40 + 'ms">' +
          '<img class="line-item__img" src="' + p.img + '" alt="' + p.name + '">' +
          "<div>" +
            '<div class="line-item__t">' + p.name + "</div>" +
            '<div class="line-item__p">' + money(p.price) + "</div>" +
            '<div class="line-item__ctrl"><button class="card__btn" data-add="' + id + '" style="flex:none;padding:8px 16px">Add to cart</button></div>' +
          "</div>" +
          '<button class="line-item__x" data-wish-remove="' + id + '" aria-label="Remove from wishlist">&#10005;</button>' +
        "</div>"
      );
    }).join("");
  }

  wishItems.addEventListener("click", e => {
    const addBtn = e.target.closest("[data-add]");
    const rm = e.target.closest("[data-wish-remove]");
    if (addBtn) addToCart(addBtn.dataset.add, 1);
    if (rm) toggleWish(rm.dataset.wishRemove);
  });

  $("#wishlistBtn").addEventListener("click", () => registerLayer("wishDrawer"));
  $("#wishAllToCart").addEventListener("click", () => {
    if (!wishlist.length) { toast("Wishlist is empty", true); return; }
    wishlist.forEach(id => { cart[id] = Math.min(99, (cart[id] || 0) + 1); });
    store.set("estore-cart", cart);
    renderCart();
    toast(wishlist.length + " item(s) moved to cart");
    wishlist = [];
    store.set("estore-wishlist", wishlist);
    renderWishlist();
    renderProducts();
  });

  /* ── Quick view modal ─────────────────────────────────── */
  const modal = $("#quickView");
  let qvProduct = null;

  function openQuickView(id) {
    const p = byId(id);
    if (!p) return;
    qvProduct = p;
    $("#qvImg").src = p.img;
    $("#qvImg").alt = p.name;
    $("#qvCat").textContent = p.category;
    $("#qvTitle").textContent = p.name;
    $("#qvRating").innerHTML = '<span class="stars">' + starsHTML(p.rating) + '</span><small style="color:var(--muted)">' + p.rating.toFixed(1) + " · " + p.reviews + ' reviews</small>';
    $("#qvPrice").textContent = money(p.price);
    $("#qvPrice").dataset.price = p.price;
    $("#qvOldPrice").textContent = p.oldPrice ? money(p.oldPrice) : "";
    $("#qvOldPrice").style.display = p.oldPrice ? "" : "none";
    $("#qvDesc").textContent = p.desc;
    $("#qvQty").value = "1";
    $("#qvMeta").textContent = "Free shipping over " + money(99) + " · 30-day returns · In stock, ships in 24h";
    modal.classList.add("is-open");
    modal.setAttribute("aria-hidden", "false");
    registerLayer("quickView");
  }
  function closeQuickView() { unregisterLayer("quickView"); }
  $$("[data-close-modal]").forEach(el => el.addEventListener("click", closeQuickView));
  modal.addEventListener("click", e => { if (e.target === modal) closeQuickView(); });  // dimmed backdrop

  $("#qvMinus").addEventListener("click", () => {
    const inp = $("#qvQty");
    inp.value = Math.max(1, (parseInt(inp.value, 10) || 1) - 1);
  });
  $("#qvPlus").addEventListener("click", () => {
    const inp = $("#qvQty");
    inp.value = Math.min(99, (parseInt(inp.value, 10) || 1) + 1);
  });
  $("#qvAdd").addEventListener("click", () => {
    if (!qvProduct) return;
    const q = Math.min(99, Math.max(1, parseInt($("#qvQty").value, 10) || 1));
    addToCart(qvProduct.id, q);
    closeQuickView();
    registerLayer("cartDrawer");
  });

  /* ── Hero slider ──────────────────────────────────────── */
  const heroSlides = $$(".hero__slide");
  const heroDots = $("#heroDots");
  let heroIdx = 0;
  let heroTimer = null;

  heroSlides.forEach((_, i) => {
    const b = document.createElement("button");
    b.setAttribute("role", "tab");
    b.setAttribute("aria-label", "Go to slide " + (i + 1));
    b.setAttribute("aria-selected", i === 0 ? "true" : "false");
    if (i === 0) b.classList.add("is-active");
    b.addEventListener("click", () => heroGo(i, true));
    heroDots.appendChild(b);
  });

  function heroGo(i, user) {
    heroIdx = (i + heroSlides.length) % heroSlides.length;
    heroSlides.forEach((s, k) => s.classList.toggle("is-active", k === heroIdx));
    $$("button", heroDots).forEach((d, k) => {
      d.classList.toggle("is-active", k === heroIdx);
      d.setAttribute("aria-selected", k === heroIdx ? "true" : "false");
    });
    if (user) heroRestart();
  }
  function heroNext() { heroGo(heroIdx + 1); }
  function heroRestart() {
    clearInterval(heroTimer);
    heroTimer = setInterval(heroNext, 6000);
  }
  $("#heroNext").addEventListener("click", () => heroGo(heroIdx + 1, true));
  $("#heroPrev").addEventListener("click", () => heroGo(heroIdx - 1, true));
  $(".hero").addEventListener("mouseenter", () => clearInterval(heroTimer));
  $(".hero").addEventListener("mouseleave", heroRestart);

  /* Touch swipe for hero */
  let touchX = null;
  $(".hero").addEventListener("touchstart", e => { touchX = e.touches[0].clientX; }, { passive: true });
  $(".hero").addEventListener("touchend", e => {
    if (touchX === null) return;
    const dx = e.changedTouches[0].clientX - touchX;
    if (Math.abs(dx) > 44) heroGo(heroIdx + (dx < 0 ? 1 : -1), true);
    touchX = null;
  }, { passive: true });

  /* Keyboard arrows when hero in view */
  document.addEventListener("keydown", e => {
    if (openLayers.length) return;
    const t = e.target;
    if (t instanceof Element && (t.matches("input, select, textarea") || t.isContentEditable)) return; // never hijack typing
    if (e.key === "ArrowRight") heroGo(heroIdx + 1, true);
    if (e.key === "ArrowLeft") heroGo(heroIdx - 1, true);
  });
  heroRestart();

  /* ── Testimonials slider ──────────────────────────────── */
  const testiSlides = $("#testiSlides");
  const testiDots = $("#testiDots");
  let testiIdx = 0;
  let testiTimer = null;

  testiSlides.innerHTML = TESTIMONIALS.map((t, i) => (
    '<figure class="testi__slide' + (i === 0 ? " is-active" : "") + '">' +
      '<div class="testi__stars" aria-label="' + t.stars + ' out of 5 stars">' + "&#9733;".repeat(t.stars) + "</div>" +
      '<blockquote class="testi__quote">&ldquo;' + t.quote + "&rdquo;</blockquote>" +
      '<figcaption class="testi__person">' +
        '<span class="testi__avatar" aria-hidden="true">' + t.initials + "</span>" +
        '<span class="testi__who"><strong>' + t.name + "</strong><span>" + t.role + "</span></span>" +
      "</figcaption>" +
    "</figure>"
  )).join("");

  TESTIMONIALS.forEach((_, i) => {
    const b = document.createElement("button");
    b.setAttribute("role", "tab");
    b.setAttribute("aria-label", "Testimonial " + (i + 1));
    b.setAttribute("aria-selected", i === 0 ? "true" : "false");
    if (i === 0) b.classList.add("is-active");
    b.addEventListener("click", () => testiGo(i, true));
    testiDots.appendChild(b);
  });

  function testiGo(i, user) {
    testiIdx = (i + TESTIMONIALS.length) % TESTIMONIALS.length;
    $$(".testi__slide", testiSlides).forEach((s, k) => s.classList.toggle("is-active", k === testiIdx));
    $$("button", testiDots).forEach((d, k) => {
      d.classList.toggle("is-active", k === testiIdx);
      d.setAttribute("aria-selected", k === testiIdx ? "true" : "false");
    });
    if (user) { clearInterval(testiTimer); testiTimer = setInterval(() => testiGo(testiIdx + 1), 7000); }
  }
  $("#testiNext").addEventListener("click", () => testiGo(testiIdx + 1, true));
  $("#testiPrev").addEventListener("click", () => testiGo(testiIdx - 1, true));
  testiTimer = setInterval(() => testiGo(testiIdx + 1), 7000);

  /* ── Countdown (deal of the day) ──────────────────────── */
  let dealEnds = (() => {
    const saved = store.get("estore-deal-ends", null);
    const now = Date.now();
    if (saved && saved > now && saved - now < 72 * 3600e3) return saved;
    const end = new Date();
    end.setHours(23, 59, 59, 999);
    end.setTime(end.getTime() + 36 * 3600e3); // rolls over every ~1.5 days
    store.set("estore-deal-ends", end.getTime());
    return end.getTime();
  })();

  const cdCells = { d: $("#cdDays"), h: $("#cdHours"), m: $("#cdMins"), s: $("#cdSecs") };
  function tickCountdown() {
    let diff = dealEnds - Date.now();
    if (diff <= 0) {                       // expired mid-session — roll the deal forward
      const end = new Date();
      end.setHours(23, 59, 59, 999);
      end.setTime(end.getTime() + 36 * 3600e3);
      dealEnds = end.getTime();
      store.set("estore-deal-ends", dealEnds);
      diff = dealEnds - Date.now();
    }
    const d = Math.floor(diff / 86400e3); diff -= d * 86400e3;
    const h = Math.floor(diff / 3600e3);  diff -= h * 3600e3;
    const m = Math.floor(diff / 60e3);    diff -= m * 60e3;
    const s = Math.floor(diff / 1e3);
    const pad = n => String(n).padStart(2, "0");
    cdCells.d.textContent = pad(d);
    cdCells.h.textContent = pad(h);
    cdCells.m.textContent = pad(m);
    cdCells.s.textContent = pad(s);
  }
  tickCountdown();
  setInterval(tickCountdown, 1000);

  const dealBar = $("#dealStockBar");
  if (dealBar) setTimeout(() => { dealBar.style.width = "72%"; }, 400);

  $$("[data-add-to-cart]").forEach(btn =>
    btn.addEventListener("click", () => addToCart(btn.dataset.addToCart, 1)));

  /* ── Topbar announcements ─────────────────────────────── */
  const annMsgs = $$(".topbar__msg");
  let annIdx = 0;
  function annGo(i) {
    annIdx = (i + annMsgs.length) % annMsgs.length;
    annMsgs.forEach((m, k) => m.classList.toggle("is-active", k === annIdx));
  }
  $("#annNext").addEventListener("click", () => annGo(annIdx + 1));
  $("#annPrev").addEventListener("click", () => annGo(annIdx - 1));
  setInterval(() => annGo(annIdx + 1), 5000);

  /* ── Currency switcher (topbar + mobile menu selects stay in sync) ── */
  const currencySelects = $$("select[data-currency]");
  function syncCurrencyUI() {
    currencySelects.forEach(sel => { if (document.activeElement !== sel) sel.value = currency; });
  }
  currencySelects.forEach(sel => sel.addEventListener("change", () => {
    currency = sel.value;
    store.set("estore-currency", currency);
    syncCurrencyUI();
    refreshPrices();
    renderProducts();
    renderCart();
    renderWishlist();
    toast("Prices now shown in " + currency);
  }));
  syncCurrencyUI();

  function refreshPrices() {
    $$("[data-price]").forEach(el => { el.textContent = money(parseFloat(el.dataset.price)); });
  }

  /* ── Tabs ─────────────────────────────────────────────── */
  $("#productTabs").addEventListener("click", e => {
    const tab = e.target.closest(".tab");
    if (!tab) return;
    setTab(tab.dataset.tab);
  });

  function setTab(tab) {
    activeTab = tab;
    $$(".tab", $("#productTabs")).forEach(t => {
      const on = t.dataset.tab === tab;
      t.classList.toggle("is-active", on);
      t.setAttribute("aria-selected", on ? "true" : "false");
    });
    renderProducts();
  }

  /* Links that jump into the grid with a preset tab/category */
  function syncSearchUI() {
    const sel = $("#searchCategory"), inp = $("#searchInput"), mInp = $("#mnavSearchInput");
    if (sel) sel.value = searchCategory;
    if (inp && document.activeElement !== inp) inp.value = searchQuery;
    if (mInp && document.activeElement !== mInp) mInp.value = searchQuery;
  }
  document.addEventListener("click", e => {
    const tabLink = e.target.closest("[data-tab]:not(.tab)");
    const catLink = e.target.closest("[data-cat]");
    if (tabLink) {
      searchQuery = ""; searchCategory = "all";   // reset stale filters BEFORE rendering
      syncSearchUI();
      setTab(tabLink.dataset.tab);
    }
    if (catLink) {
      const cat = catLink.dataset.cat;
      searchQuery = "";
      searchCategory = cat === "sale" ? "all" : cat;
      syncSearchUI();
      setTab(cat === "sale" ? "sale" : "all");
      closeAllLayers();
    }
  });
  // Placeholder links (href="#") must not yank the user back to the top of the page
  document.addEventListener("click", e => {
    if (e.target.closest('a[href="#"]')) e.preventDefault();
  });

  /* ── Search ───────────────────────────────────────────── */
  $("#searchForm").addEventListener("submit", e => {
    e.preventDefault();
    searchQuery = $("#searchInput").value.trim().toLowerCase();
    searchCategory = $("#searchCategory").value;
    setTab("all");   // syncs tab classes + aria-selected and re-renders
    document.getElementById("products").scrollIntoView({ behavior: "smooth" });
    if (!currentList().length) toast("No matches — try another keyword", true);
  });
  $("#searchInput").addEventListener("input", e => {
    if (!e.target.value.trim() && searchQuery) { searchQuery = ""; renderProducts(); }  // clearing the box resets the search
  });

  /* Mobile-menu search: keyword spans the whole catalog (category resets to "all") */
  $("#mnavSearchForm").addEventListener("submit", e => {
    e.preventDefault();
    searchQuery = $("#mnavSearchInput").value.trim().toLowerCase();
    searchCategory = "all";
    syncSearchUI();
    setTab("all");
    closeMnav();
    document.getElementById("products").scrollIntoView({ behavior: "smooth" });
    if (!currentList().length) toast("No matches — try another keyword", true);
  });
  $("#mnavSearchInput").addEventListener("input", e => {
    if (!e.target.value.trim() && searchQuery) { searchQuery = ""; renderProducts(); }
  });

  /* ── Mobile nav ───────────────────────────────────────── */
  $("#navToggle").addEventListener("click", () => {
    registerLayer("mobileNav");
    syncSearchUI();       // menu inputs always reflect current search/currency state
    syncCurrencyUI();
    $("#navToggle").setAttribute("aria-expanded", "true");
  });
  function closeMnav() {
    unregisterLayer("mobileNav");
    $("#navToggle").setAttribute("aria-expanded", "false");
  }
  $("#mnavClose").addEventListener("click", closeMnav);
  $("#mnavList").addEventListener("click", e => { if (e.target.closest("a")) closeMnav(); });

  /* ── Desktop dropdown: click/touch toggle + aria state ── */
  const ddItem = $(".nav__item--dropdown");
  const ddBtn = ddItem ? ddItem.querySelector("button") : null;
  if (ddItem && ddBtn) {
    ddBtn.addEventListener("click", () => {
      const open = ddItem.classList.toggle("is-open");
      ddBtn.setAttribute("aria-expanded", open ? "true" : "false");
    });
    document.addEventListener("click", e => {
      if (!ddItem.contains(e.target)) {
        ddItem.classList.remove("is-open");
        ddBtn.setAttribute("aria-expanded", "false");
      }
    });
  }

  /* ── Newsletter ───────────────────────────────────────── */
  $("#newsletterForm").addEventListener("submit", e => {
    e.preventDefault();
    const email = $("#newsletterEmail").value.trim();
    if (!/^\S+@\S+\.\S+$/.test(email)) { toast("Please enter a valid email", true); return; }
    toast("Welcome aboard — check your inbox!");
    e.target.reset();
  });

  /* ── Scroll effects: sticky shadow, back-to-top, reveal ── */
  const header = $("#header");
  const toTop = $("#toTop");
  let ticking = false;
  window.addEventListener("scroll", () => {
    if (ticking) return;
    ticking = true;
    requestAnimationFrame(() => {
      const y = window.scrollY;
      header.classList.toggle("is-stuck", y > 8);
      toTop.hidden = false;
      toTop.classList.toggle("is-visible", y > 560);
      ticking = false;
    });
  }, { passive: true });
  toTop.addEventListener("click", () => window.scrollTo({ top: 0, behavior: "smooth" }));

  const io = new IntersectionObserver(entries => {
    entries.forEach(en => {
      if (en.isIntersecting) {
        const delay = en.target.dataset.delay;
        if (delay) en.target.style.transitionDelay = delay * 80 + "ms";
        en.target.classList.add("is-visible");
        io.unobserve(en.target);
      }
    });
  }, { threshold: 0.12, rootMargin: "0px 0px -40px 0px" });
  $$(".reveal").forEach(el => io.observe(el));

  /* ── Init ─────────────────────────────────────────────── */
  // Closed layers must not be keyboard-focusable until opened
  LAYER_IDS.forEach(id => {
    const el = document.getElementById(id);
    if (el && !openLayers.includes(id)) el.setAttribute("inert", "");
  });
  renderProducts();
  renderCart();
  renderWishlist();
  refreshPrices();
})();
