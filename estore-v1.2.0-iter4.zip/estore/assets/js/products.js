/* ═══════════════════════════════════════════════════════════
   eStore — product catalog (plain JS data, no dependencies)
   ═══════════════════════════════════════════════════════════ */

const PRODUCTS = [
  {
    id: "ivory-knit-dress",
    name: "Ivory Knit Midi Dress",
    category: "women",
    price: 49,
    oldPrice: 78,
    rating: 4.8,
    reviews: 124,
    img: "assets/img/product-dress-1.jpg",
    onSale: true, featured: true, top: true,
    desc: "A soft ribbed knit midi with a relaxed silhouette — the one you will reach for from spring well into autumn."
  },
  {
    id: "noir-pleated-gown",
    name: "Noir Pleated Evening Gown",
    category: "women",
    price: 86,
    oldPrice: null,
    rating: 4.9,
    reviews: 87,
    img: "assets/img/product-dress-2.jpg",
    onSale: false, featured: true, top: true,
    desc: "Fluid pleats and a high halter neckline make this floor-length gown an instant evening classic."
  },
  {
    id: "azure-bloom-maxi",
    name: "Azure Bloom Wrap Maxi",
    category: "women",
    price: 59,
    oldPrice: 84,
    rating: 4.6,
    reviews: 210,
    img: "assets/img/product-dress-3.jpg",
    onSale: true, featured: false, top: true,
    desc: "A breezy floral wrap dress with 3/4 sleeves — vacation energy for ordinary weekdays."
  },
  {
    id: "pastel-collection-set",
    name: "Pastel Bridesmaid Dress",
    category: "women",
    price: 74,
    oldPrice: null,
    rating: 4.7,
    reviews: 63,
    img: "assets/img/product-dress-4.jpg",
    onSale: false, featured: false, top: false,
    desc: "Soft pastel tones and a flattering A-line cut, made to mix perfectly with the whole bridal party."
  },
  {
    id: "sunset-linen-dress",
    name: "Sunset Cutout Linen Dress",
    category: "women",
    price: 68,
    oldPrice: 95,
    rating: 4.5,
    reviews: 48,
    img: "assets/img/product-dress-5.jpg",
    onSale: true, featured: true, top: false,
    desc: "Breathable linen blend with a modern cutout detail — designed for golden-hour dinners."
  },
  {
    id: "garden-party-maxi",
    name: "Garden Party White Maxi",
    category: "women",
    price: 79,
    oldPrice: null,
    rating: 4.8,
    reviews: 91,
    img: "assets/img/product-dress-6.jpg",
    onSale: false, featured: false, top: true,
    desc: "Tiered chiffon maxi with delicate straps — light as air and endlessly photogenic."
  },
  {
    id: "sage-chore-jacket",
    name: "Sage Cotton Chore Jacket",
    category: "men",
    price: 89,
    oldPrice: 120,
    rating: 4.8,
    reviews: 156,
    img: "assets/img/product-men-1.jpg",
    onSale: true, featured: true, top: true,
    desc: "A workwear icon in washed sage cotton twill with four utility pockets and a relaxed fit."
  },
  {
    id: "forest-overshirt",
    name: "Forest Heavy Overshirt",
    category: "men",
    price: 75,
    oldPrice: null,
    rating: 4.6,
    reviews: 74,
    img: "assets/img/product-men-3.jpg",
    onSale: false, featured: false, top: false,
    desc: "Brushed flannel overshirt that layers over tees and under coats — built for shoulder season."
  },
  {
    id: "camel-trucker-jacket",
    name: "Camel Trucker Jacket",
    category: "men",
    price: 95,
    oldPrice: 135,
    rating: 4.7,
    reviews: 112,
    img: "assets/img/product-men-4.jpg",
    onSale: true, featured: true, top: false,
    desc: "Warm camel suede-feel trucker with clean lines — instant upgrade to any basic outfit."
  },
  {
    id: "coast-linen-shirt",
    name: "Coastal Camp-Collar Shirt",
    category: "men",
    price: 45,
    oldPrice: null,
    rating: 4.5,
    reviews: 203,
    img: "assets/img/product-men-5.jpg",
    onSale: false, featured: false, top: true,
    desc: "Airy camp-collar shirt in a sky-blue viscose blend. Vacation packed in a fold."
  },
  {
    id: "cloudrunner-sneakers",
    name: "Cloudrunner Trainers",
    category: "shoes",
    price: 129,
    oldPrice: 169,
    rating: 4.9,
    reviews: 341,
    img: "assets/img/product-shoes-1.jpg",
    onSale: true, featured: true, top: true,
    desc: "Plush cushioning, breathable mesh and a rocker sole — your daily miles, upgraded."
  },
  {
    id: "vapor-race-shoes",
    name: "Vapor Race Running Shoes",
    category: "shoes",
    price: 139,
    oldPrice: null,
    rating: 4.7,
    reviews: 158,
    img: "assets/img/product-shoes-2.jpg",
    onSale: false, featured: true, top: false,
    desc: "A carbon-plated racing shoe with an aggressive rocker — built for personal bests."
  },
  {
    id: "oxblood-shoulder-bag",
    name: "Oxblood Shoulder Bag",
    category: "bags",
    price: 110,
    oldPrice: 148,
    rating: 4.8,
    reviews: 96,
    img: "assets/img/product-bag-1.jpg",
    onSale: true, featured: true, top: true,
    desc: "Full-grain leather with a structured flap and brushed gold hardware — small bag, big presence."
  },
  {
    id: "burgundy-saddle-bag",
    name: "Burgundy Saddle Bag",
    category: "bags",
    price: 125,
    oldPrice: null,
    rating: 4.6,
    reviews: 67,
    img: "assets/img/product-bag-2.jpg",
    onSale: false, featured: false, top: false,
    desc: "A vintage-inspired saddle silhouette in rich burgundy with an adjustable strap."
  },
  {
    id: "onyx-skeleton-watch",
    name: "Onyx Skeleton Watch",
    category: "watches",
    price: 299,
    oldPrice: 420,
    rating: 4.9,
    reviews: 74,
    img: "assets/img/product-acc-1.jpg",
    onSale: true, featured: true, top: false,
    desc: "An exposed-movement automatic with sapphire glass on both sides — mechanics as jewellery."
  },
  {
    id: "heritage-silver-watch",
    name: "Heritage Silver Watch",
    category: "watches",
    price: 189,
    oldPrice: null,
    rating: 4.5,
    reviews: 52,
    img: "assets/img/product-acc-2.jpg",
    onSale: false, featured: false, top: true,
    desc: "A slim rectangular dial on a woven bracelet — quiet luxury for every wrist."
  },
  {
    id: "abyss-blue-watch",
    name: "Abyss Blue Automatic",
    category: "watches",
    price: 249,
    oldPrice: 384,
    rating: 4.8,
    reviews: 88,
    img: "assets/img/product-acc-3.jpg",
    onSale: true, featured: true, top: true,
    desc: "A 300 m dive watch with a sunburst blue dial, ceramic bezel and sapphire crystal. Deal of the day."
  }
];

const TESTIMONIALS = [
  {
    stars: 5,
    quote: "Ordered on Tuesday, wearing it on Thursday. The jacket quality genuinely surprised me for this price — already planning my second order.",
    name: "Amelia R.", role: "Verified buyer · Lisbon", initials: "AR"
  },
  {
    stars: 5,
    quote: "The size guide was spot on and returns took me literally two minutes. Customer support replied within the hour when I had a question.",
    name: "Marco V.", role: "Verified buyer · Porto", initials: "MV"
  },
  {
    stars: 4,
    quote: "Beautiful packaging, fair prices and a checkout that actually works on mobile. My go-to store for gifts now.",
    name: "Sofia C.", role: "Verified buyer · Madrid", initials: "SC"
  }
];

/* Expose for app.js without modules (file:// friendly) */
window.PRODUCTS = PRODUCTS;
window.TESTIMONIALS = TESTIMONIALS;
