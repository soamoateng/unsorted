# Project Roadmap: TerminalReport

**Status as of Iteration 31:** ✅ All 5 phases (A–E) complete + Iter 8-17 (rename, pre-fill, templates, search, marks entry, vendoring, photos, ranks, marks pre-fill, appbar brand, single-report removal) + Iter 17 gap features + Iter 18-20 (student name split into surname/first_name, class_position removal + name-sort + class rank badge, PBKDF2 PIN stretching, single-query batch stats, single-export persistence) + Iter 21-22 critical-fix campaign (CRIT-3..18: recovery rate-limiting, mark coercion, print timing/CSS, RFC-4180 CSV, CSV header mapping, AES-GCM encrypted backups v2) + Iter 23 hardening (CRIT-19/20/21: colspan fixes, changePin/recover legacy-hash fallbacks, renderer corruption guards) + housekeeping (SW cache v21→v23, WORKLOG backfill) + Iter 24 full 17-category error audit (BLIND-10/11/12: dead template-selector reference, tolerant report-row JSON parsing, bounded object-URL lifecycle) + Iter 25 responsive screen widths (media-query width ladder so screens occupy most of the window on desktop, user-reported XAMPP layout fix; SW stale-precache fix via Request cache:'reload'; SW cache v24→v26) + Iter 26 targeted re-audit of auth/backup/CSV/marks (all documented CRIT/BLIND/SEC/RT/PERF fixes verified in code; no new exploitable bugs; NEW setup() already-configured guard preventing accidental app-UUID rotation that would orphan existing .trbak backups; refresh() docstring corrected; lost CRIT-01/02/04-08 formally closed as unrecoverable (see WORKLOG Iter 26); 66/66 regression harness; Iter-24 WORKLOG entry backfilled; SW cache v26→v27) + Iter 27 UI bug audit (user-reported stepper connector-line stubs fixed by anchoring lines at the real flex-geometry circle centres 100/(2N)% instead of hardcoded px; batch done-checkmark double-escape '\\2713' + inherited font-size:0 fixed → visible ✓; pseudo-element/z-index/print-CSS sweep clean (see WORKLOG Iter 27); SW cache v27→v28). + Iter 28 UI bug audit #2 (user-reported: batch wizard "Which Term" duplicate of "Academic Term" removed, dead state.term deleted, legacy batches.term column filled from academicTerm, diverging defaults aligned; all 80 alert()/10 confirm() calls replaced by a shared queued focus-managed in-app modal via new js/ui.js (see WORKLOG Iter 28); markup audit clean; freshState className regression caught in browser verification and fixed; SW cache v28→v30). + Iter 29 text pass (user-requested: every em dash removed from all 15 first-party files with each sentence rewritten to flow naturally; user-visible copy converted to British English spelling, including the Primary Colour / Greyscale template labels and centred / behaviour / normalised / initialise; bare-dash placeholders on the report card, dashboard average and settings UUID replaced with n/a or Not set; dialog reasons, window titles and empty-state option labels rewritten without decorative dashes; no logic changes; 66/66 regression harness; SW cache v30→v31). + Iter 30 form restructure (user-requested: gender limited to Male/Female in both pickers; Total Days moved from the per-student Attendance table into Basic Info as a batch-wide field with days-present validated against it; Teacher Remark moved into a dedicated column of the Step 4 marks grid; report card info row rendered inline so labels no longer push values onto the next line; dedicated Subject Rank column with ordinal values such as '1st' replacing the '#N' badge inside the Grade cell; footer colspans realigned; data shape summary-compatible so old reports render unchanged; 66/66 regression harness + new iter30 logic harness + live browser pass, see WORKLOG Iter 30; SW cache v31→v32) + Iter 31 business-logic audit (checklist-driven sweep of every module after the Iter-30 restructure; fixed: restore-success dialog TypeError (UI.UI.alert) that showed a false 'Restore failed' and skipped the reload, report-card renderer ignoring custom grading scales in both per-subject grades and the printed legend (bands now snapshotted into each summary at generation), days-present accepting negative/decimal input, a double-click window on Generate Reports before the button disabled, restored backups from older schemas missing the schema migration, the dashboard summary showing 'Database unavailable.' until manual refresh, ranking ties broken by floating-point artefacts, raw UTC timestamps on saved-report rows, stale async list renders overwriting newer ones, and unhandled rejections from the class-creation dropdowns; noted-not-fixed by design: certificate numbers may repeat across batches sharing a prefix (PREFIX-NNNN spec); 37/37 new audit harness + 66/66 regression + iter30 harness + live browser pass with zero console errors, see WORKLOG Iter 31; SW cache v32→v33)  + Iter 32 UI rendering/interaction audit (checklist-driven sweep of events, forms, focus, modals, async UI, data binding and DOM quirks plus 31 numbered bug patterns; fixed: profile-modal stale-response race and silent DB-unavailable returns, missing busy guards on every admin add/save/confirm button and the CSV/restore/print/delete flows, app-dialog Tab trap with full Enter/Escape ownership, Escape-to-close + focus move/restore + scroll reset for the three read-only modals via the new ui.js wireModal helper, overlay scroll carry-over between opens, report-card blob-URL leaks on preview/print, managed-class stale-selection desync, wizard invalid-mark styling persisting while typing, renderDetailsTab unhandled rejections, and a preview failure faking 'Generation failed' after a successful save; 47/47 new UI harness + all regression harnesses + live browser pass with zero console errors, see WORKLOG Iter 32; SW cache v33→v34) App meets 100% of the original spec and has survived eight audit rounds plus a dedicated text-quality pass and a form-restructure pass.

This file is the canonical phase tracker. **A new AI chat session should read this file second** (after `WORKLOG.md`) to understand what's done and what remains.

---

## Phase status

| Phase | Scope | Status | Iteration | Zip suffix |
|---|---|---|---|---|
| **A** | + button UX, hardcoded → placeholders, 3 PDF templates | ✅ Complete | Iter 4 | `iter4` |
| **B** | PIN + lockout + security question + recovery + lock button | ✅ Complete | Iter 4 | `iter4` |
| **C** | Auto-backup on DB save + signed backups (HMAC-SHA256) + Settings UI + Change PIN | ✅ Complete | Iter 5 | `iter5` |
| **D** | Batch generation 5-step wizard + transactional save + class ranking + per-subject ranking + Print All | ✅ Complete | Iter 6 | `iter6` |
| **E** | Admin/management UI with full DB normalisation (6 tables) + CRUD + grading scale editor + Manage Class 3 tabs + promote/repeat + grading scale integration | ✅ Complete | Iter 7 | `iter7` |
| **R** | Full app rename to **TerminalReport**: app name, project folder, window globals, event, storage keys, SW cache, backup magic/extension, cert prefix (see WORKLOG Iteration 8 mapping table) | ✅ Complete | Iter 8 | `iter8` |
| **F** | Batch wizard pre-fill from Phase E managed entities (class picker → year/class/counts + Steps 2/3 roster + class grading scale) + real app logo (6 PWA icons + in-app fallback) + admin year-dropdown sync fix | ✅ Complete | Iter 9 | `iter9` |
| **G** | Multi-template batch Print All (roadmap #4): template dropdown in batch preview toolbar; Print All / print-one / detail modal all honor it; live re-template | ✅ Complete | Iter 10 | `iter10` |
| **H** | Saved Reports search by student name + filter by class (roadmap #1): toolbar with debounced search input + class-filter dropdown populated from saved reports + result count badge + clear-search button | ✅ Complete | Iter 11 | `iter11` |
| **I** | Subject marks entry (roadmap #2): new `subject_marks` table with `UNIQUE(subject_id, student_id)` for UPSERT; "Enter Marks" modal auto-opens after new-subject save (when class has ≥1 student); per-student mark input + absent checkbox + validation; pencil-ruler icon on each subject row for re-entry; cascade-delete on subject/student removal; colour consistency sweep (Bootstrap `.btn-primary` / `.bg-primary` / `.border-primary` / `.text-primary` / `.link-primary` + auth-card-header now derive from `--app-primary`) | ✅ Complete | Iter 12 | `iter12` |
| **J** | Vendor CDN libraries locally (offline-first) + roadmap #8/#9/#10: Bootstrap 5.3.8 + Font Awesome 7.3.1 + sql.js 1.14.2 now under `vendor/` (no more cdnjs requests); admin inline validation (`.is-invalid` + `.invalid-feedback`, alert() replaced); batch wizard Step 3 photo upload (50×60 thumbnail, canvas-resized to 100×120 PNG, stored in `reports.photo_blob`); per-subject rank badge (`.subject-rank-badge`) next to grade on report card for batch-generated reports | ✅ Complete | Iter 13 | `iter13` |
| **K** | Batch wizard pre-fill from `subject_marks` (closes Admin UI ↔ wizard loop): new `listSubjectMarksForClass(classId)` DB method (single query, joins `subject_marks` × `subjects` filtered by class_id); `loadManagedClass` fetches marks alongside students/subjects; `applyManagedPrefill` maps marks to `state.marks[studIdx][subjIdx]` via O(1) hash lookup tables; Step 4 shows "Pre-filled N marks from Admin UI" hint; ALSO fixes pre-existing Iter 6 bug where `<thead>` content was being written into `<tbody>` (browser tolerated it but DOM queries against `#bwMarksHead` returned `[]`) | ✅ Complete | Iter 14 | `iter14` |
| **L** | Appbar shows "TerminalReport" (app brand, not school name): renamed `<span id="appbarSchoolName">` → `<span id="appbarBrandName">TerminalReport</span>`; removed 2 JS lines that overwrote brand text with `info.name`; appbar logo ALWAYS uses `assets/app-logo.png` (TerminalReport brand), not the school's uploaded logo; school name/logo preserved on report cards + lock screen (where school branding belongs) | ✅ Complete | Iter 15 | `iter15` |
| **M** | Single-report form REMOVED; batch generation is the default and only path. Main dashboard redesigned as a clean 3-button action hub. Saved Report Viewer modal added. ~420 lines removed from script.js. | ✅ Complete | Iter 16 | `iter16` |
| **N** | Gap features + Back buttons + UI improvements: class-performance dashboard (pass-rate, avg, passed/failed per batch); CSV import for students (roll,name,dob,gender); bulk promote all students to a different-year class; student profile modal (longitudinal history with all past reports for a student); batch wizard Cancel→Back (no confirm); saved report viewer Close→Back; student profile + bulk promote Back buttons; 3-column responsive icon-button dashboard grid; scrollable viewer modal. | ✅ Complete | Iter 17 | `iter17` |
| **O** | Responsive screen widths (user-reported: every screen was a centred column with big empty side margins on XAMPP/desktop): media-query width ladder over CSS custom properties, so working screens (batch wizard, preview, admin, manage class, scale editor, viewer, profile) up to min(95vw, 1840px); settings/modals up to 720px; dashboard full-width shell capped 1800px on ultra-wide; phones unchanged. PLUS SW install precache now uses Request({cache:'reload'}), which fixes the stale-stylesheet precache via HTTP cache (reproduced + verified). SW cache v24→v26. | ✅ Complete | Iter 25 | `iter25` |

---

## Spec coverage checklist

Every item from the user's original plain-English spec is implemented:

### First-time setup
- [x] 3-step setup wizard (School Info → PIN → Security Question)
- [x] Logo auto-resize to 256×256 PNG (canvas, contain with white bg for transparent PNGs)
- [x] 4-digit PIN with confirm
- [x] Custom security question + answer
- [x] PIN hashed with SHA-256 + 16-byte crypto-random salt
- [x] Security answer hashed with SEPARATE salt (lowercased)
- [x] App UUID generated (crypto-random RFC 4122 v4)

### Lock screen
- [x] 4-digit PIN pad (clickable + keyboard support)
- [x] Correct PIN → unlock
- [x] Wrong PIN → "Incorrect passcode. N attempts left." + shake animation
- [x] 5 wrong attempts → 5-min lockout + countdown timer
- [x] Exponential backoff: 5min → 15min → 1hr → 4hr → 24hr (escalation beyond spec)
- [x] "Forgot Passcode" → recovery flow
- [x] Recovery: answer security question → set new PIN

### Main dashboard
- [x] Top appbar: school logo + name + lock button + settings gear
- [x] Form for single-report generation
- [x] "Start New Batch" button (Phase D)
- [x] "Saved Reports" button (Iter 3)
- [x] "Admin & Manage" button (Phase E)

### Single report generation
- [x] Form with all fields (placeholders, not hardcoded values)
- [x] Subject rows with add/remove + flash animation
- [x] Live per-field validation (red border + messages)
- [x] 3 PDF templates (primary / grayscale / no-logo) with live switching
- [x] Auto-generated certificate number `TR-YYYYMMDD-XXXX` if blank
- [x] Issue date defaults to today
- [x] Print via `window.print()` with isolated `@media print` CSS
- [x] XSS protection (HTML escaping on all user input)
- [x] TZ-safe date formatting

### Batch generation (Phase D + Iter 9)
- [x] 5-step wizard (Basic Info → Subjects → Students → Marks grid → Attendance/Remarks)
- [x] Stepper UI with active/done states
- [x] **Managed-class pre-fill (Iter 9):** Step 1 dropdown pulls year/class/counts + Steps 2/3 rosters from Phase E tables; students roll-number sorted; once-per-selection (manual edits preserved); switch guard + empty-class degrade
- [x] **Class grading scale honored in batch (Iter 9):** wizard resolves the managed class's scale and passes it to generation (was dormant plumbing before)
- [x] "Reports already exist" detection + confirm dialog + regenerate-and-replace
- [x] Transactional save (BEGIN/COMMIT/ROLLBACK)
- [x] Class ranking with ties (standard competition: 1, 2, 2, 4)
- [x] Per-subject ranking with ties
- [x] Pass/fail = pass in EVERY subject (not overall %)
- [x] Auto-generated cert numbers `PREFIX-NNNN`
- [x] Batch preview: list with rank badge, View (detail modal), Print (single)
- [x] Print All: multi-page via `page-break-after: always`
- [x] **Batch template selection (Iter 10, roadmap #4):** preview-toolbar dropdown (primary / grayscale / no-logo, defaults from the main form selector); applied to every card in Print All AND print-one; detail modal live-re-templates on switch; print-window CSS mirrors the Phase A variant rules
- [x] Marks grid: sticky frozen columns + sticky header
- [x] Marks validation: 0 ≤ marks ≤ max

### Admin & Manage (Phase E + Iter 12 subject marks)
- [x] Academic Years CRUD with delete constraint (blocked if classes exist)
- [x] Grading Scales CRUD with band editor
- [x] Default grading scale seeded on first init (cannot be deleted)
- [x] Deleting a scale in use → resets those classes to default
- [x] Classes CRUD with delete constraint (blocked if students or subjects exist)
- [x] Manage Class screen with 3 tabs (Details, Students, Subjects)
- [x] Students: add/edit/delete + promote/repeat
- [x] Subjects: add/edit/delete + **per-subject marks entry modal (Iter 12)**
- [x] Promote/repeat: move student to different-year class (same-year blocked)
- [x] Custom grading scales integrated into batch report generation
- [x] **Subject marks persistence (Iter 12):** new `subject_marks` table; bulk UPSERT via `INSERT OR REPLACE` (UNIQUE constraint); LEFT JOIN with students on read; cascade-delete on subject/student removal; numeric-aware roll-number sort matching the batch wizard pre-fill order

### Persistence & backup (Iter 3 + Phase C + Iter 11)
- [x] sql.js 1.14.2 + IndexedDB (DB bytes saved after every write)
- [x] Saved Reports panel (list, load, delete), with Iter 11 search-by-name + filter-by-class toolbar
- [x] Auto-backup to OPFS on every DB save (when enabled)
- [x] beforeunload safety net (best-effort)
- [x] Manual "Backup Now" via File System Access API or `<a download>` fallback
- [x] Manual "Restore from Backup" with HMAC-SHA256 signature verification
- [x] Tamper detection (single-byte flip rejected)
- [x] Cross-installation rejection (UUID mismatch)
- [x] Constant-time HMAC comparison (timing-attack safe)

### Security
- [x] PIN: SHA-256(salt + pin), 16-byte crypto-random salt
- [x] Security answer: SHA-256(separate_salt + answer_lowercase)
- [x] App UUID: crypto-random RFC 4122 v4
- [x] Backup HMAC key: app UUID
- [x] `isUnlocked` in-memory only (forces re-auth on every open)
- [x] Lockout state persisted in localStorage (survives reload)
- [x] All crypto via `crypto.subtle` (never `Math.random` for security)

### PWA
- [x] manifest.webmanifest with all required fields
- [x] Service worker (cache-first app shell, SWR for CDN, network-first navigation)
- [x] 6 PWA icons (192, 512, maskable variants, apple-touch, favicon): the **real TerminalReport logo (Iter 9)**, maskable safe-zone verified programmatically
- [x] Offline-capable after first load
- [x] PWABuilder-ready (manifest + SW + HTTPS)

### Code quality
- [x] IIFE-scoped modules (no globals leaked)
- [x] SOLID: Single Responsibility per module (db.js, auth.js, backup.js, batch.js, batch-ui.js, admin-ui.js, auth-ui.js, script.js)
- [x] DRY: `TerminalReportScript_renderReportHTML` reused by both script.js and batch-ui.js
- [x] KISS: no build step, no frameworks, no transpilation
- [x] All SRI hashes verified by downloading actual CDN files and computing hashes
- [x] All JS syntax-checked with `node -c`
- [x] All flows browser-tested with headless Chrome (agent-browser)

---

## Architecture overview

### Module dependency graph

```
sql.js (CDN, SRI-verified)
    ↓
js/db.js (TerminalReportDb, 25 methods, 8 tables)
    ↓
js/auth.js (TerminalReportAuth, 12 methods, depends on TerminalReportDb)
    ↓
js/backup.js (TerminalReportBackup, 9 methods, depends on TerminalReportDb + TerminalReportAuth)
    ↓
js/batch.js (TerminalReportBatch, 8 pure functions, depends on TerminalReportDb + TerminalReportAuth)
    ↓
js/batch-ui.js (TerminalReportBatchUI, 3 methods, depends on TerminalReportBatch + TerminalReportDb + TerminalReportAuth + TerminalReportScript_renderReportHTML)
    ↓
js/admin-ui.js (TerminalReportAdminUI, 3 methods, depends on TerminalReportDb)
    ↓
js/auth-ui.js (TerminalReportAuthUI, 2 methods, depends on TerminalReportAuth + TerminalReportDb + TerminalReportBackup)
    ↓
js/script.js (main form, exposes TerminalReportScript_renderReportHTML)
```

Load order in `index.html`:
```html
<script src="js/db.js"></script>
<script src="js/auth.js"></script>
<script src="js/backup.js"></script>
<script src="js/batch.js"></script>
<script src="js/batch-ui.js"></script>
<script src="js/admin-ui.js"></script>
<script src="js/auth-ui.js"></script>
<script src="js/script.js"></script>
```

### Database schema (8 tables)

1. `auth` (singleton row, id=1) storing school_name, logo_blob, pin_hash, pin_salt, security_question, security_answer_hash, security_answer_salt, app_uuid
2. `reports`, the generated report cards (subjects as JSON, summary as JSON, logo/photo as BLOBs, batch_id FK, student_id_in_batch, class_rank)
3. `batches`, the batch metadata (academic_year, class_name, academic_term, student_count, subject_count, certificate_prefix, UNIQUE constraint)
4. `academic_years` (year_label UNIQUE)
5. `grading_scales` (name UNIQUE, is_default)
6. `grading_bands` (grading_scale_id FK CASCADE, grade_letter, min_percentage, description, sort_order)
7. `classes` (name, academic_year_id FK RESTRICT, grading_scale_id FK SET NULL, UNIQUE(name, academic_year_id))
8. `students` (roll_number, name, dob, gender, class_id FK RESTRICT)
9. `subjects` (code, name, max_marks, min_marks, class_id FK RESTRICT, UNIQUE(class_id, name))

### Auth flow

```
Page load
    ↓
TerminalReportAuthUI.start()
    ↓
TerminalReportAuth.init() → TerminalReportDb.init() → loads sql.js + hydrates from IndexedDB
    ↓
TerminalReportAuth.loadAuth() → reads auth row from DB
    ↓
If not configured → show setup wizard
If configured but not unlocked → show lock screen
If unlocked (impossible on a fresh load, since the flag is in-memory only) → show main app
    ↓
On successful setup/unlock/recovery → showMainApp()
    ↓
initMainApp() fires (via 'terminalreport:auth-complete' event)
    ↓
Main form + batch UI + admin UI + backup init all run
```

---

## Remaining roadmap (NOT spec-blocking)

These are enhancements for future work. The app meets 100% of the original spec. **All 10 original roadmap items are now complete.** Only one item remains, blocked by toolchain availability:

| # | Feature | Priority | Notes |
|---|---|---|---|
| 1 | ~~Search saved reports by student name + filter by class~~ | ✅ Done (Iter 11) | db.js `searchReports()` + `listReportClasses()`. Toolbar inside Saved Reports panel: debounced search input + class-filter dropdown + result-count badge + clear-search button. Uses `INSTR(LOWER(student_name), ?) > 0` instead of LIKE to avoid `%`/`_` wildcard injection. See WORKLOG Iteration 11. |
| 2 | ~~"When adding a new subject, immediately enter marks for all existing students"~~ | ✅ Done (Iter 12) | New `subject_marks` table with `UNIQUE(subject_id, student_id)` for UPSERT. Auto-open "Enter Marks" modal after new-subject save (when class has ≥1 student). Pencil-ruler icon on each subject row for re-entry. Cascade-delete on subject/student removal. See WORKLOG Iteration 12. |
| 3 | ~~Batch wizard pulls subjects/students from Phase E managed entities~~ | ✅ Done (Iter 9) | Managed-class picker on Step 1 pre-fills year/class/counts + Steps 2/3 + grading scale. See WORKLOG Iteration 9. |
| 4 | ~~3 multi-template PDFs in batch Print All~~ | ✅ Done (Iter 10) | Template dropdown in the batch preview toolbar; Print All, print-one, and the detail modal all honor it; live re-template. See WORKLOG Iteration 10. |
| 5 | Capacitor wrapper for native iOS submission | High (but requires native dev) | Apple still rejects pure PWAs. PWABuilder's iOS path wraps in Capacitor; needs at least one native feature (e.g., native print dialog, native file picker) to pass Apple review. Blocked by macOS/Xcode toolchain availability in current environment. |
| 6 | Migrate from sql.js to `@sqlite.org/sqlite-wasm` + OPFS | Low | Only if scaling to multi-school SaaS. sql.js loads entire DB in memory (~50MB max for a single school, which is fine). OPFS-backed SQLite WASM is incremental but requires worker + self-hosted .wasm + potentially COOP/COEP headers. |
| 7 | ~~Replace placeholder PWA icons with actual school logo~~ | ✅ Done (Iter 9) | All 6 icons regenerated from the user-supplied TerminalReport.png; maskable safe-zone verified; in-app brand fallback added. |
| 8 | ~~Add input validation UI to admin entity modals~~ | ✅ Done (Iter 13) | Inline `.is-invalid` + `.invalid-feedback` via `setInvalid()`/`clearValidation()` helpers. Alert() calls replaced in 7 admin handlers (year, scale, class, details, student, move, subject). Validation cleared on modal open. |
| 9 | ~~Student photo upload in batch wizard Step 3~~ | ✅ Done (Iter 13) | New "Photo (opt.)" column in Step 3, a hidden `<input type="file">` per row, click thumbnail to open picker, canvas resizes to 100×120 PNG bytes, stored in `state.students[i].photoBytes`, flows through `buildBatchReports()` → `db.saveBatch()` → `reports.photo_blob`. Rendered on the report card via `bytesToObjectUrl()`. Clear button per row to remove photo. |
| 10 | ~~Per-subject rank display on report card~~ | ✅ Done (Iter 13) | `.subject-rank-badge` rendered next to the Grade cell when `subjectRank` is finite + `totalStudents > 1`. Hidden for single-report flow (no rank data) and batches with only 1 student (rank #1 of 1 is meaningless). `summary.totalStudents` added to batch.js's saved summary shape so the renderer has the denominator. CSS mirrored into PRINT_STYLES for batch Print All. |
| (none) | ~~Batch wizard pre-fill from `subject_marks` table~~ | ✅ Done (Iter 14) | (Added as a deferred item in Iter 12's WORKLOG, completed in Iter 14.) New `listSubjectMarksForClass(classId)` DB method, single query joining `subject_marks` × `subjects`. `applyManagedPrefill` maps marks into `state.marks` via O(1) hash lookup tables built from `state.managedClass.subjects`/`students` IDs. Step 4 shows "Pre-filled N marks from Admin UI" hint. Teacher can override any cell; override is reflected in the saved report. Also fixed a pre-existing Iter 6 bug where `renderStep4` wrote `<thead>` content into `<tbody>`. See WORKLOG Iteration 14. |

---

## Key constraints (must-know for future work)

1. **`crypto.subtle` requires HTTPS or localhost**: `file://` will silently fail. Always serve via `python3 -m http.server` or deploy to HTTPS.
2. **sql.js loads entire DB into memory**: fine for single school (~50MB max). Migrate to OPFS-backed SQLite WASM for multi-school.
3. **4-digit PIN is brute-forceable in ~5 min** without lockout. The exponential backoff (5min → 24hr) is essential, not optional.
4. **No transaction wrapping for single-report saves**: sql.js is in-memory; atomic semantics apply once we have multi-table inserts (batch workflow uses BEGIN/COMMIT/ROLLBACK).
5. **Placeholder PWA icons (RESOLVED in Iter 9)** (real logo shipped). If the school rebrands, re-run `/home/z/my-project/scripts/generate_app_icons_iter9.py` with a new 1024×1024 PNG.
6. **Apple iOS App Store rejects pure PWAs**: plan separate native iOS work (Capacitor).
7. **Auto-backup fires on every DB save, not just on app close**: INTENTIONAL and BETTER than spec. `beforeunload` can't reliably run async work in modern browsers.
8. **File System Access API not supported in Firefox**: falls back to `<a download>` for Backup Now, `<input type="file">` for restore.
9. **Backups are tied to installation UUID**: clearing site data generates a new UUID, making old `.trbak` files unrestorable. By design (HMAC key = app UUID).
10. **SQLite does NOT enforce FK constraints by default**: sql.js doesn't set `PRAGMA foreign_keys = ON`. Manual COUNT checks in delete functions are the enforcement mechanism (more user-friendly, as it tells the user WHAT is blocking).
11. **`last_insert_rowid()` must be called BEFORE `await persist()`**: `persist()` calls `db.export()` which can reset the SQL connection's last-insert state. All `add*` functions follow this order.
12. **Font Awesome 7 removed auto-accessibility**: icon-only buttons need explicit `aria-label`.

---

## Verification commands

```bash
# Serve and open
cd TerminalReport
python3 -m http.server 8080
# Open http://localhost:8080/ in Chrome or Edge

# Syntax-check all JS
for f in js/*.js sw.js; do node -c "$f" && echo "OK: $f"; done

# Iter 11 unit tests (SQL only, no browser required)
node /home/z/my-project/scripts/test_iter11_search.js
# Expected: 17 passed, 0 failed

# Iter 11 end-to-end browser test (requires python3 -m http.server on :8080)
bash /home/z/my-project/scripts/validate_iter11.sh
# Expected: 13/13 PASS

# Iter 12 unit tests (SQL only, no browser required)
node /home/z/my-project/scripts/test_iter12_subject_marks.js
# Expected: 22 passed, 0 failed

# Iter 12 end-to-end browser test (requires python3 -m http.server on :8080)
bash /home/z/my-project/scripts/validate_iter12.sh
# Expected: 13/13 PASS

# Iter 13 unit tests (batch.js subjectRank + totalStudents + photoBlob)
node /home/z/my-project/scripts/test_iter13_batch_rank.js
# Expected: 18 passed, 0 failed

# Iter 13 end-to-end browser test (vendoring + #8 + #9 + #10)
bash /home/z/my-project/scripts/validate_iter13.sh
# Expected: 8/8 PASS

# Iter 14 unit tests (listSubjectMarksForClass: one query for all marks in a class)
node /home/z/my-project/scripts/test_iter14_subject_marks_for_class.js
# Expected: 8 passed, 0 failed

# Iter 14 end-to-end browser test (marks pre-fill flow)
bash /home/z/my-project/scripts/validate_iter14.sh
# Expected: 11/11 PASS

# Iter 15 end-to-end browser test (appbar brand text = "TerminalReport")
bash /home/z/my-project/scripts/validate_iter15.sh
# Expected: 8/8 PASS

# Iter 16 end-to-end browser test (single-report removed, batch is default)
bash /home/z/my-project/scripts/validate_iter16.sh
# Expected: 13/13 PASS

# Iter 17 end-to-end browser test (gap features + back buttons + UI)
bash /home/z/my-project/scripts/validate_iter17.sh
# Expected: 10/10 PASS

# Iter 23 verification harness (CRIT-19/20/21 + BLIND-7/8/9, which loads REAL auth.js
# + script.js with real Web Crypto; also asserts table-consistency + SW version)
node /home/z/my-project/scripts/verify_iter23.js

# Iter 24 verification harness (BLIND-10/11/12 regression assertions + helper
# behaviour matrix + no-collateral-damage checks)
node /home/z/my-project/scripts/verify_iter24.js
# Expected: 80 passed, 0 failed, exit code 0

# Iter 25 verification (responsive widths at 3 viewports + SW v26 + fresh precache)
bash /home/z/my-project/scripts/verify_iter25.sh
# Expected: 8 passed, 0 failed + zero console errors on fresh load

# Iter 26 verification (auth/backup/CSV/marks regression harness with real sql.js
# + real Web Crypto; includes the NEW setup()-guard and BOM-invariant assertions)
node /home/z/my-project/scripts/verify_iter26.js
# Expected: 66 passed, 0 failed, exit code 0

# Iter 31 verification (business-logic audit harness: float-safe ranking ties,
# custom-scale bands snapshot + renderer grade/legend preference, restore-time
# schema migration, UTC stamp formatting, summary-shape regression)
node /home/z/my-project/scripts/verify_iter31.js
# Expected: 37 passed, 0 failed, exit code 0

# Full syntax sweep
for f in js/*.js sw.js; do node --check "$f"; done

# In Chrome/Edge DevTools:
# - Application → Manifest: name, icons, theme colour
# - Application → Service Workers: "terminalreport-v24" registered
# - Application → Cache Storage → terminalreport-v24: should include ALL vendor/* files (offline-first)
# - Application → IndexedDB → terminalreport-db → kv: SQLite bytes
# - Application → Local Storage: lockout state (after wrong PINs)
# - Application → Storage → Origin private file system → terminalreport-backups/auto.trbak
# - Network tab: zero requests to cdnjs.cloudflare.com (all assets same-origin since Iter 13)
```

---

## How to continue in a new AI chat

1. **Provide the zip** `TerminalReport-v1.0.0-iter24.zip` to the new chat.
2. **Instruct the new AI to read** `WORKLOG.md` and `ROADMAP.md` first.
3. **Specify the next task**: see "Remaining roadmap" above (only #5 Capacitor iOS remains, blocked by toolchain) or a new requirement.
4. **Maintain the same constraints**:
   - DRY/KISS/SOLID principles
   - No UI/UX changes without permission
   - Verify all claims against current library versions
   - Vendored libraries under `vendor/` (Iter 13), so do not re-introduce CDN dependencies
   - Browser-test all flows with headless Chrome
   - Save scripts to `/home/z/my-project/scripts/` before executing
   - Save final deliverables to `/home/z/my-project/download/`
   - Use the same zip naming convention: `TerminalReport-v1.0.0-iterN.zip`
