/**
 * TerminalReport: Admin/Management UI (Phase E)
 *
 * Two overlays:
 *   1. #adminScreen: 3 sections (Academic Years, Grading Scales, Classes)
 *   2. #manageClassScreen: 3 tabs (Details, Students, Subjects)
 *
 * Public API (window.TerminalReportAdminUI):
 *   init()           → registers event listeners (called once after auth)
 *   openAdmin()      → opens the admin overlay
 */
(function () {
    'use strict';

    const $ = (id) => document.getElementById(id);
    // Iteration 28 (DLG-01): shared in-app dialog (replaces native alert/confirm)
    const UI = window.TerminalReportUI;

    // Current state for the Manage Class screen
    let currentClass = null;     // {id, name, academicYearId, gradingScaleId, ...}

    // ============================================================
    // Admin overlay: open/close
    // ============================================================
    function openAdmin() {
        refreshAllSections();
        const overlay = $('adminScreen');
        // Iteration 32 (SCROLL-01): the overlay is the scroll container; reset
        // so reopening the admin screen never lands mid-scroll.
        overlay.scrollTop = 0;
        overlay.style.display = 'flex';
        document.body.classList.add('auth-gating');
    }

    function closeAdmin() {
        $('adminScreen').style.display = 'none';
        document.body.classList.remove('auth-gating');
    }

    async function refreshAllSections() {
        await refreshAcademicYears();
        await refreshGradingScales();
        await refreshClasses();
    }

    // ============================================================
    // Academic Years section
    // ============================================================
    async function refreshAcademicYears() {
        const list = $('adminYearsList');
        try {
            const years = await window.TerminalReportDb.listAcademicYears();
            if (!years.length) {
                list.innerHTML = '<div class="text-muted text-center py-3">No academic years yet. Add one below.</div>';
                return;
            }
            list.innerHTML = years.map(function (y) {
                return '<div class="admin-list-row">' +
                    '<div class="admin-list-info">' +
                        '<div class="admin-list-title">' + escapeHtml(y.yearLabel) + '</div>' +
                        '<div class="admin-list-sub">' + y.classCount + ' class(es)</div>' +
                    '</div>' +
                    '<button type="button" class="btn btn-sm btn-outline-danger" data-action="delete-year" data-id="' + y.id + '"' +
                        (y.classCount > 0 ? ' disabled title="Cannot delete: classes exist for this year"' : '') + '>' +
                        '<i class="fas fa-trash"></i>' +
                    '</button>' +
                '</div>';
            }).join('');
        } catch (e) {
            list.innerHTML = '<div class="text-danger">Failed to load: ' + escapeHtml(e.message) + '</div>';
        }
    }

    async function handleAddYear() {
        const input = $('adminYearInput');
        const label = input.value.trim();
        if (!label) {
            // Iter 13 (roadmap #8): inline validation instead of UI.alert()
            setInvalid(input, 'Year label is required.');
            input.focus();
            return;
        }
        // Clear any prior validation state on this input
        clearValidation(input.parentNode);
        try {
            await window.TerminalReportDb.addAcademicYear(label);
            input.value = '';
            await refreshAcademicYears();
            // Keep the class-creation dropdown in sync (Iter 9 fix, it was
            // previously only refreshed when the admin screen was opened).
            await populateClassDropdowns();
        } catch (e) {
            UI.alert('Failed to add year: ' + e.message);
        }
    }

    async function handleDeleteYear(id) {
        if (!(await UI.confirm('Delete this academic year?'))) return;
        try {
            await window.TerminalReportDb.deleteAcademicYear(parseInt(id, 10));
            await refreshAcademicYears();
            await populateClassDropdowns();
        } catch (e) {
            UI.alert(e.message);
        }
    }

    // ============================================================
    // Grading Scales section
    // ============================================================
    async function refreshGradingScales() {
        const list = $('adminScalesList');
        try {
            const scales = await window.TerminalReportDb.listGradingScales();
            if (!scales.length) {
                list.innerHTML = '<div class="text-muted text-center py-3">No grading scales. The default scale should have been seeded; check the console.</div>';
                return;
            }
            list.innerHTML = scales.map(function (s) {
                const bandsStr = s.bands.map(function (b) {
                    return b.gradeLetter + ' (' + b.minPercentage + '%+)';
                }).join(', ');
                return '<div class="admin-list-row">' +
                    '<div class="admin-list-info">' +
                        '<div class="admin-list-title">' + escapeHtml(s.name) +
                            (s.isDefault ? ' <span class="badge bg-success">Default</span>' : '') +
                        '</div>' +
                        '<div class="admin-list-sub">' + escapeHtml(bandsStr) + '</div>' +
                        '<div class="admin-list-sub">' + s.classCount + ' class(es) use this</div>' +
                    '</div>' +
                    '<div class="admin-list-actions">' +
                        '<button type="button" class="btn btn-sm btn-outline-primary" data-action="edit-scale" data-id="' + s.id + '"><i class="fas fa-pen"></i></button>' +
                        '<button type="button" class="btn btn-sm btn-outline-danger" data-action="delete-scale" data-id="' + s.id + '"' +
                            (s.isDefault ? ' disabled title="Cannot delete the default scale"' : '') + '>' +
                            '<i class="fas fa-trash"></i>' +
                        '</button>' +
                    '</div>' +
                '</div>';
            }).join('');
        } catch (e) {
            list.innerHTML = '<div class="text-danger">Failed to load: ' + escapeHtml(e.message) + '</div>';
        }
    }

    function openScaleEditor(scale) {
        // scale = null for new, or {id, name, bands} for edit
        $('scaleEditorId').value = scale ? scale.id : '';
        $('scaleEditorName').value = scale ? scale.name : '';
        const bands = (scale && scale.bands) ? scale.bands : [
            { gradeLetter: '', minPercentage: '', description: '' }
        ];
        renderScaleBands(bands);
        // Iter 13 (roadmap #8): clear any stale validation state from a prior open
        clearValidation($('scaleEditor'));
        $('scaleEditor').style.display = 'flex';
    }

    function closeScaleEditor() {
        $('scaleEditor').style.display = 'none';
    }

    function renderScaleBands(bands) {
        const tbody = $('scaleEditorBands');
        tbody.innerHTML = bands.map(function (b, i) {
            return '<tr>' +
                '<td><input type="text" class="form-control form-control-sm" data-band-idx="' + i + '" data-field="gradeLetter" value="' + escapeAttr(b.gradeLetter || '') + '" placeholder="A+"></td>' +
                '<td><input type="number" class="form-control form-control-sm" data-band-idx="' + i + '" data-field="minPercentage" value="' + (b.minPercentage != null ? b.minPercentage : '') + '" placeholder="90"></td>' +
                '<td><input type="text" class="form-control form-control-sm" data-band-idx="' + i + '" data-field="description" value="' + escapeAttr(b.description || '') + '" placeholder="Outstanding"></td>' +
                '<td><button type="button" class="btn btn-sm btn-outline-danger" data-action="remove-band" data-idx="' + i + '"><i class="fas fa-trash"></i></button></td>' +
            '</tr>';
        }).join('');
    }

    function readScaleBands() {
        const inputs = document.querySelectorAll('#scaleEditorBands input[data-band-idx]');
        // Clear any prior validation state from previous attempt
        clearValidation($('scaleEditorBands'));
        const bands = [];
        let valid = true;
        let firstErrorInput = null;
        let firstErrorMsg = '';
        inputs.forEach(function (inp) {
            const idx = parseInt(inp.dataset.bandIdx, 10);
            if (!bands[idx]) bands[idx] = {};
            const field = inp.dataset.field;
            const val = inp.value.trim();
            if (field === 'gradeLetter') {
                if (!val) {
                    valid = false;
                    if (!firstErrorInput) { firstErrorInput = inp; firstErrorMsg = 'Grade letter is required for every band.'; }
                    setInvalid(inp, 'Grade letter is required.');
                } else {
                    inp.classList.remove('is-invalid');
                }
                bands[idx].gradeLetter = val;
            } else if (field === 'minPercentage') {
                const n = parseInt(val, 10);
                if (!Number.isFinite(n) || n < 0 || n > 100) {
                    valid = false;
                    if (!firstErrorInput) { firstErrorInput = inp; firstErrorMsg = 'Min percentage must be an integer 0–100.'; }
                    setInvalid(inp, 'Min percentage must be 0–100.');
                } else {
                    inp.classList.remove('is-invalid');
                }
                bands[idx].minPercentage = n;
            } else if (field === 'description') {
                bands[idx].description = val;
            }
        });
        if (!valid) {
            // Focus the first invalid input so the user sees the error inline.
            if (firstErrorInput) firstErrorInput.focus();
            return null;
        }
        return bands;
    }

    async function handleSaveScale() {
        const id = $('scaleEditorId').value ? parseInt($('scaleEditorId').value, 10) : null;
        const nameInput = $('scaleEditorName');
        const name = nameInput.value.trim();
        if (!name) {
            // Iter 13 (roadmap #8): inline validation instead of UI.alert()
            setInvalid(nameInput, 'Scale name is required.');
            nameInput.focus();
            return;
        }
        // Clear any prior validation on the name field, the band inputs are
        // validated separately by readScaleBands() below.

        const bands = readScaleBands();
        if (!bands) return; // bands had inline errors, already shown
        try {
            await window.TerminalReportDb.saveGradingScale({ id: id, name: name, bands: bands });
            closeScaleEditor();
            await refreshGradingScales();
        } catch (e) {
            UI.alert('Failed to save scale: ' + e.message);
        }
    }

    function addScaleBandRow() {
        const existing = [];
        document.querySelectorAll('#scaleEditorBands input[data-band-idx][data-field=gradeLetter]').forEach(function (inp) {
            const idx = parseInt(inp.dataset.bandIdx, 10);
            existing[idx] = existing[idx] || {};
            existing[idx].gradeLetter = inp.value;
        });
        document.querySelectorAll('#scaleEditorBands input[data-band-idx]').forEach(function (inp) {
            const idx = parseInt(inp.dataset.bandIdx, 10);
            existing[idx] = existing[idx] || {};
            existing[idx][inp.dataset.field] = inp.value;
        });
        existing.push({ gradeLetter: '', minPercentage: '', description: '' });
        renderScaleBands(existing);
    }

    function removeScaleBandRow(idx) {
        const existing = [];
        document.querySelectorAll('#scaleEditorBands input[data-band-idx]').forEach(function (inp) {
            const i = parseInt(inp.dataset.bandIdx, 10);
            if (i === parseInt(idx, 10)) return;
            existing[i] = existing[i] || {};
            existing[i][inp.dataset.field] = inp.value;
        });
        // Compact the array (remove gaps)
        const compact = existing.filter(function () { return true; });
        renderScaleBands(compact);
    }

    async function handleDeleteScale(id) {
        if (!(await UI.confirm('Delete this grading scale? Classes using it will be reset to the default scale.'))) return;
        try {
            await window.TerminalReportDb.deleteGradingScale(parseInt(id, 10));
            await refreshGradingScales();
        } catch (e) {
            UI.alert(e.message);
        }
    }

    async function handleEditScale(id) {
        try {
            const scale = await window.TerminalReportDb.getGradingScale(parseInt(id, 10));
            if (scale) openScaleEditor(scale);
        } catch (e) {
            UI.alert('Failed to load scale: ' + e.message);
        }
    }

    // ============================================================
    // Classes section
    // ============================================================
    async function refreshClasses() {
        const list = $('adminClassesList');
        try {
            const classes = await window.TerminalReportDb.listClasses();
            if (!classes.length) {
                list.innerHTML = '<div class="text-muted text-center py-3">No classes yet. Add one below.</div>';
                return;
            }
            list.innerHTML = classes.map(function (c) {
                return '<div class="admin-list-row">' +
                    '<div class="admin-list-info">' +
                        '<div class="admin-list-title">' + escapeHtml(c.name) + '</div>' +
                        '<div class="admin-list-sub">' +
                            escapeHtml(c.yearLabel || 'No year') + ' · ' +
                            escapeHtml(c.scaleName || 'Default scale') + ' · ' +
                            c.studentCount + ' students · ' +
                            c.subjectCount + ' subjects' +
                        '</div>' +
                    '</div>' +
                    '<div class="admin-list-actions">' +
                        '<button type="button" class="btn btn-sm btn-outline-primary" data-action="manage-class" data-id="' + c.id + '"><i class="fas fa-gear"></i> Manage</button>' +
                        '<button type="button" class="btn btn-sm btn-outline-danger" data-action="delete-class" data-id="' + c.id + '"' +
                            (c.studentCount > 0 || c.subjectCount > 0 ? ' disabled title="Cannot delete: class has students or subjects"' : '') + '>' +
                            '<i class="fas fa-trash"></i>' +
                        '</button>' +
                    '</div>' +
                '</div>';
            }).join('');
        } catch (e) {
            list.innerHTML = '<div class="text-danger">Failed to load: ' + escapeHtml(e.message) + '</div>';
        }
    }

    async function handleAddClass() {
        const nameInput = $('adminClassNameInput');
        const yearSelect = $('adminClassYearSelect');
        const scaleId = $('adminClassScaleSelect').value;
        const name = nameInput.value.trim();
        const yearId = yearSelect.value;
        // Iter 13 (roadmap #8): inline validation. Validate name first, then
        // year, both must be present. Clear any prior state before re-checking.

        clearValidation(yearSelect.parentNode);
        let firstInvalid = null;
        if (!name) {
            setInvalid(nameInput, 'Class name is required.');
            if (!firstInvalid) firstInvalid = nameInput;
        }
        if (!yearId) {
            setInvalid(yearSelect, 'Select an academic year. Add one above if none exist.');
            if (!firstInvalid) firstInvalid = yearSelect;
        }
        if (firstInvalid) { firstInvalid.focus(); return; }
        try {
            await window.TerminalReportDb.addClass({
                name: name,
                academicYearId: parseInt(yearId, 10),
                gradingScaleId: scaleId ? parseInt(scaleId, 10) : null
            });
            nameInput.value = '';
            await refreshClasses();
        } catch (e) {
            UI.alert('Failed to add class: ' + e.message);
        }
    }

    async function handleDeleteClass(id) {
        if (!(await UI.confirm('Delete this class?'))) return;
        try {
            await window.TerminalReportDb.deleteClass(parseInt(id, 10));
            await refreshClasses();
        } catch (e) {
            UI.alert(e.message);
        }
    }

    /** Populate the <select> dropdowns for adding a class (years + scales). */
    async function populateClassDropdowns() {
        // Iter 31 audit fix (ERR-01): this ran unguarded both here and from
        // the dashboard's Admin button, so a DB failure surfaced only as an
        // unhandled promise rejection with no user-visible feedback.
        try {
            const years = await window.TerminalReportDb.listAcademicYears();
            const scales = await window.TerminalReportDb.listGradingScales();
            const yearSel = $('adminClassYearSelect');
            const scaleSel = $('adminClassScaleSelect');
            yearSel.innerHTML = '<option value="">Select year</option>' +
                years.map(function (y) {
                    return '<option value="' + y.id + '">' + escapeHtml(y.yearLabel) + '</option>';
                }).join('');
            scaleSel.innerHTML = '<option value="">Use default</option>' +
                scales.map(function (s) {
                    return '<option value="' + s.id + '">' + escapeHtml(s.name) + (s.isDefault ? ' (default)' : '') + '</option>';
                }).join('');
        } catch (e) {
            UI.alert('Could not load the year and grading scale dropdowns: ' + (e.message || e));
        }
    }

    // ============================================================
    // Manage Class screen (3 tabs)
    // ============================================================
    async function openManageClass(classId) {
        try {
            const classes = await window.TerminalReportDb.listClasses();
            currentClass = classes.find(function (c) { return c.id === parseInt(classId, 10); });
            if (!currentClass) { UI.alert('Class not found.'); return; }
            $('manageClassTitle').textContent = currentClass.name + ' · ' + (currentClass.yearLabel || 'No year');
            closeAdmin();
            // Show manage class overlay
            const overlay = $('manageClassScreen');
            overlay.scrollTop = 0;   // Iteration 32 (SCROLL-01)
            overlay.style.display = 'flex';
            document.body.classList.add('auth-gating');
            // Switch to Details tab
            switchManageTab('details');
        } catch (e) {
            UI.alert('Failed to open class: ' + e.message);
        }
    }

    function closeManageClass() {
        $('manageClassScreen').style.display = 'none';
        document.body.classList.remove('auth-gating');
        currentClass = null;
        openAdmin(); // go back to admin screen
    }

    function switchManageTab(tabName) {
        document.querySelectorAll('.manage-class-tab').forEach(function (t) {
            t.classList.toggle('active', t.dataset.tab === tabName);
        });
        document.querySelectorAll('.manage-class-tab-panel').forEach(function (p) {
            p.style.display = p.dataset.tabPanel === tabName ? 'block' : 'none';
        });
        if (tabName === 'details') renderDetailsTab();
        else if (tabName === 'students') renderStudentsTab();
        else if (tabName === 'subjects') renderSubjectsTab();
    }

    // --- Details tab ---
    async function renderDetailsTab() {
        if (!currentClass) return;
        $('mcDetailsName').value = currentClass.name;
        // Populate year + scale dropdowns
        // Iteration 32 (ERR-02): this render used to run its two awaited DB
        // reads unguarded, so a failure surfaced only as an unhandled promise
        // rejection while the dropdowns silently stayed empty. Report it.
        try {
            const years = await window.TerminalReportDb.listAcademicYears();
            const scales = await window.TerminalReportDb.listGradingScales();
            $('mcDetailsYear').innerHTML = years.map(function (y) {
                return '<option value="' + y.id + '"' + (y.id === currentClass.academicYearId ? ' selected' : '') + '>' + escapeHtml(y.yearLabel) + '</option>';
            }).join('');
            $('mcDetailsScale').innerHTML = '<option value="">Use default</option>' + scales.map(function (s) {
                return '<option value="' + s.id + '"' + (s.id === currentClass.gradingScaleId ? ' selected' : '') + '>' + escapeHtml(s.name) + (s.isDefault ? ' (default)' : '') + '</option>';
            }).join('');
        } catch (e) {
            console.error('[admin-ui] renderDetailsTab failed:', e);
            UI.alert('Could not load the year and grading scale dropdowns: ' + (e.message || e));
        }
    }

    async function handleSaveDetails() {
        if (!currentClass) return;
        const nameInput = $('mcDetailsName');
        const yearSelect = $('mcDetailsYear');
        const scaleId = $('mcDetailsScale').value;
        const name = nameInput.value.trim();
        const yearId = yearSelect.value;
        // Iter 13 (roadmap #8): inline validation

        clearValidation(yearSelect.parentNode);
        let firstInvalid = null;
        if (!name) {
            setInvalid(nameInput, 'Class name is required.');
            if (!firstInvalid) firstInvalid = nameInput;
        }
        if (!yearId) {
            setInvalid(yearSelect, 'Select an academic year.');
            if (!firstInvalid) firstInvalid = yearSelect;
        }
        if (firstInvalid) { firstInvalid.focus(); return; }
        try {
            await window.TerminalReportDb.updateClass(currentClass.id, {
                name: name,
                academicYearId: parseInt(yearId, 10),
                gradingScaleId: scaleId ? parseInt(scaleId, 10) : null
            });
            // Refresh currentClass
            const classes = await window.TerminalReportDb.listClasses();
            currentClass = classes.find(function (c) { return c.id === currentClass.id; });
            $('manageClassTitle').textContent = currentClass.name + ' · ' + (currentClass.yearLabel || 'No year');
            UI.alert('Class details saved.');
        } catch (e) {
            UI.alert('Failed to save: ' + e.message);
        }
    }

    // --- Students tab ---
    async function renderStudentsTab() {
        if (!currentClass) return;
        const tbody = $('mcStudentsBody');
        try {
            const students = await window.TerminalReportDb.listStudentsForClass(currentClass.id);
            if (!students.length) {
                // CRIT-19 fix (Iter 23): was colspan="7" but the students table has
                // exactly 6 columns (index.html:774-780, #, Student Surname,
                // Student First Name, DOB, Gender, Actions; data rows below also
                // render 6 <td>s, and the error row at the bottom of this function
                // already used colspan="6"). One cell wider than the table made the
                // empty-state row visibly overshoot the column grid.
                tbody.innerHTML = '<tr><td colspan="6" class="text-muted text-center py-3">No students yet. Add one below.</td></tr>';
                return;
            }
            tbody.innerHTML = students.map(function (s, i) {
                return '<tr>' +
                    '<td>' + (i + 1) + '</td>' +
                    '<td>' + escapeHtml(s.surname || '') + '</td>' +
                    '<td>' + escapeHtml(s.firstName || '') + '</td>' +
                    '<td>' + escapeHtml(s.dob || '') + '</td>' +
                    '<td>' + escapeHtml(s.gender || '') + '</td>' +
                    '<td class="text-nowrap">' +
                        '<button type="button" class="btn btn-sm btn-outline-primary" data-action="edit-student" data-id="' + s.id + '"><i class="fas fa-pen"></i></button> ' +
                        '<button type="button" class="btn btn-sm btn-outline-warning" data-action="move-student" data-id="' + s.id + '"><i class="fas fa-arrows-up-down"></i></button> ' +
                        '<button type="button" class="btn btn-sm btn-outline-danger" data-action="delete-student" data-id="' + s.id + '"><i class="fas fa-trash"></i></button>' +
                    '</td>' +
                '</tr>';
            }).join('');
        } catch (e) {
            tbody.innerHTML = '<tr><td colspan="6" class="text-danger">Failed to load: ' + escapeHtml(e.message) + '</td></tr>';
        }
    }

    function openStudentEditor(student) {
        $('mcStudentId').value = student ? student.id : '';
        
        $('mcStudentSurname').value = student ? (student.surname || '') : '';
        $('mcStudentFirstName').value = student ? (student.firstName || '') : '';
        $('mcStudentDob').value = student ? (student.dob || '') : '';
        $('mcStudentGender').value = student ? (student.gender || '') : '';
        $('mcStudentModalTitle').textContent = student ? 'Edit Student' : 'Add Student';
        // Iter 13 (roadmap #8): clear any stale validation state from a prior open
        clearValidation($('mcStudentModal'));
        $('mcStudentModal').style.display = 'flex';
    }

    function closeStudentEditor() {
        $('mcStudentModal').style.display = 'none';
    }

    async function handleSaveStudent() {
        if (!currentClass) return;
        const id = $('mcStudentId').value ? parseInt($('mcStudentId').value, 10) : null;
        const surnameInput = $('mcStudentSurname');
        const firstNameInput = $('mcStudentFirstName');
        const input = {
            surname: surnameInput.value.trim(),
            firstName: firstNameInput.value.trim(),
            dob: $('mcStudentDob').value,
            gender: $('mcStudentGender').value,
            classId: currentClass.id
        };
        // Iter 13 (roadmap #8): inline validation

        if (!input.surname && !input.firstName) {
            setInvalid(surnameInput, 'Student surname or first name is required.');
            surnameInput.focus();
            return;
        }
        try {
            if (id) {
                await window.TerminalReportDb.updateStudent(id, input);
            } else {
                await window.TerminalReportDb.addStudent(input);
            }
            closeStudentEditor();
            await renderStudentsTab();
        } catch (e) {
            UI.alert('Failed to save: ' + e.message);
        }
    }

    async function handleDeleteStudent(id) {
        if (!(await UI.confirm('Delete this student?'))) return;
        try {
            await window.TerminalReportDb.deleteStudent(parseInt(id, 10));
            await renderStudentsTab();
        } catch (e) {
            UI.alert(e.message);
        }
    }

    async function handleEditStudent(id) {
        try {
            const students = await window.TerminalReportDb.listStudentsForClass(currentClass.id);
            const student = students.find(function (s) { return s.id === parseInt(id, 10); });
            if (student) openStudentEditor(student);
        } catch (e) {
            UI.alert('Failed to load student: ' + e.message);
        }
    }

    // ============================================================
    // Iter 17: CSV Import (bulk student add)
    // Format: roll,name,dob,gender (one student per line, header row optional)
    // ============================================================

    function handleCsvImportClick() {
        const fileInput = $('mcCsvFileInput');
        if (!fileInput) return;
        fileInput.value = '';
        fileInput.click();
    }

    async function handleCsvFileSelected(event) {
        const file = event.target.files[0];
        if (!file || !currentClass) return;
        try {
            const text = await file.text();
            // CRIT-15 + BLIND-3 fix: previous parser did `text.split(/\r?\n/)` then
            // `line.split(',')`, that broke on RFC-4180 quoted fields with embedded
            // commas (e.g., `"Smith, Jr."` was parsed as surname="Smith", firstName='"Jr."')
            // AND on quoted fields with embedded newlines (the pre-split would chop a
            // quoted multi-line value into separate "lines" before the field parser
            // ever saw the closing quote).
            //
            // New: parse the whole text in one pass as a character stream,
            // returning rows of fields with proper quote handling:
            //   - `"..."` quotes are stripped, embedded commas are preserved
            //   - `""` inside a quoted field is an escaped quote
            //   - embedded \r\n or \n inside a quoted field stays in the field value
            //   - blank lines outside quoted fields are skipped
            const rows = parseCsvRFC4180(text);
            if (!rows.length) { UI.alert('CSV file is empty.'); return; }
            // CRIT-16 + BLIND-4 fix: previous header detection checked ONLY the first
            // cell of row 0 for substring "surname" or "name", that had two failure
            // modes:
            //   (a) A header like `id,roll,surname,firstname,dob,gender` was NOT
            //       detected (first cell is "id"), so row 0 was imported as data
            //       (surname="id", firstName="roll", dob="surname", gender="firstname").
            //   (b) A data row whose surname happened to contain "name" (e.g.
            //       "Nameington") was INCORRECTLY skipped as a header.
            //   (c) Even when "name" WAS detected, columns were read by POSITION
            //       (surname=col0, firstName=col1, dob=col2, gender=col3), a file
            //       exported as `name,dob,gender` produced surname=<full name>,
            //       firstName=<dob>, dob=<gender>. Silent data corruption.
            //
            // New approach: scan ALL cells in row 0 against a known alias table.
            // If 2+ recognizable columns are found, treat row 0 as a header and build
            // a column-index map. Otherwise, fall back to fixed-order [surname,
            // firstName, dob, gender] (no header skip) with a clear console warning.
            const colMap = detectCsvHeader(rows[0]);
            const hasHeader = colMap.__hasHeader;
            const startIdx = hasHeader ? 1 : 0;
            if (!hasHeader) {
                console.warn('[csv] No recognisable header row detected; assuming column order [surname, firstName, dob, gender]. Add a header row to avoid silent misalignment.');
            } else {
                console.info('[csv] Header detected. Column map:', colMap);
            }
            let added = 0, errors = 0;
            for (let i = startIdx; i < rows.length; i++) {
                const parts = rows[i];
                if (parts.length < 2) { errors++; continue; }
                let surname, firstName, dob, gender;
                if (hasHeader) {
                    // Read by column name; missing columns default to ''.
                    surname = (colMap.surname != null ? (parts[colMap.surname] || '').trim() : '');
                    firstName = (colMap.firstName != null ? (parts[colMap.firstName] || '').trim() : '');
                    dob = (colMap.dob != null ? (parts[colMap.dob] || '').trim() : '');
                    gender = (colMap.gender != null ? (parts[colMap.gender] || '').trim() : '');
                    // BLIND-5 fix: if a "name" column exists but neither surname
                    // nor firstName does, split the full name on first space:
                    //   "Jane Smith" → firstName="Jane", surname="Smith"
                    //   "Smith" (no space) → surname="Smith", firstName=""
                    //   "John Smith Jr" → firstName="John", surname="Smith Jr"
                    if (colMap.fullName != null && !surname && !firstName) {
                        const full = (parts[colMap.fullName] || '').trim();
                        const sp = full.indexOf(' ');
                        if (sp === -1) {
                            surname = full;
                        } else {
                            firstName = full.substring(0, sp).trim();
                            surname = full.substring(sp + 1).trim();
                        }
                    }
                } else {
                    // Fixed-order fallback (preserves backward compat with iter21).
                    surname = (parts[0] || '').trim();
                    firstName = (parts[1] || '').trim();
                    dob = (parts[2] || '').trim();
                    gender = (parts[3] || '').trim();
                }
                if (!surname && !firstName) { errors++; continue; }
                try {
                    await window.TerminalReportDb.addStudent({
                        surname: surname, firstName: firstName, name: (surname + ' ' + firstName).trim(), dob: dob, gender: gender, classId: currentClass.id
                    });
                    added++;
                } catch (e) { errors++; }
            }
            UI.alert('CSV import complete: ' + added + ' student(s) added' + (errors > 0 ? ', ' + errors + ' skipped due to errors' : '') + '.');
            await renderStudentsTab();
        } catch (e) {
            UI.alert('CSV import failed: ' + e.message);
        }
    }

    // ------------------------------------------------------------------
    // CSV header detector (CRIT-16 fix)
    // ------------------------------------------------------------------
    // Returns an object like:
    //   { surname: 0, firstName: 1, dob: 2, gender: 3, fullName: null, __hasHeader: true }
    // OR (when <2 recognizable columns found):
    //   { __hasHeader: false }
    //
    // Aliases are matched case-insensitively after trimming + collapsing
    // internal whitespace. Recognised aliases per column:
    //   surname   : surname, last_name, lastname, last name, lname, family_name, family name
    //   firstName : firstname, first_name, first name, fname, givenname, given name, forename
    //   dob       : dob, date_of_birth, date of birth, birthdate, birthday, born, birth_date
    //   gender    : gender, sex
    //   fullName  : name, full_name, full name, student_name, student name, student
    //              (only used when surname AND firstName are both absent)
    function detectCsvHeader(headerRow) {
        const aliases = {
            surname: ['surname', 'last_name', 'lastname', 'last name', 'lname', 'family_name', 'family name'],
            firstName: ['firstname', 'first_name', 'first name', 'fname', 'givenname', 'given name', 'forename'],
            dob: ['dob', 'date_of_birth', 'date of birth', 'birthdate', 'birthday', 'born', 'birth_date'],
            gender: ['gender', 'sex'],
            fullName: ['name', 'full_name', 'full name', 'student_name', 'student name', 'student']
        };
        const normalize = function (s) {
            return String(s == null ? '' : s).trim().toLowerCase().replace(/\s+/g, ' ');
        };
        const map = { __hasHeader: false, surname: null, firstName: null, dob: null, gender: null, fullName: null };
        let recognized = 0;
        for (let i = 0; i < headerRow.length; i++) {
            const cell = normalize(headerRow[i]);
            if (!cell) continue;
            for (const col in aliases) {
                if (aliases[col].indexOf(cell) !== -1) {
                    // First match wins (don't overwrite if already mapped)
                    if (map[col] === null) {
                        map[col] = i;
                        recognized++;
                    }
                    break;
                }
            }
        }
        // Require at least 2 recognizable columns to treat as header.
        // (1 match could be coincidence, e.g., a column named "sex" in a data row.)
        if (recognized >= 2) {
            map.__hasHeader = true;
        }
        return map;
    }

    // ------------------------------------------------------------------
    // RFC-4180 CSV parser (CRIT-15 + BLIND-3 fix)
    // ------------------------------------------------------------------
    // Handles: quoted fields with embedded commas, escaped quotes (`""` → `"`),
    // and embedded CRLF/LF inside quoted fields. Blank lines OUTSIDE quoted
    // fields are skipped. Returns an array of rows, where each row is an
    // array of field strings. Throws on malformed input (unterminated quote).
    function parseCsvRFC4180(text) {
        const rows = [];
        let row = [];
        let field = '';
        let inQuotes = false;
        let i = 0;
        const n = text.length;
        while (i < n) {
            const ch = text[i];
            if (inQuotes) {
                if (ch === '"') {
                    // Look ahead: "" = escaped quote, else end of quoted field.
                    const next = text[i + 1];
                    if (next === '"') {
                        field += '"';
                        i += 2;
                    } else {
                        inQuotes = false;
                        i++;
                    }
                } else {
                    // Any char inside quotes (including \r, \n, comma) is literal.
                    field += ch;
                    i++;
                }
            } else {
                if (ch === '"') {
                    // Opening quote. If field already has content (e.g., `abc"def"`),
                    // that's malformed, be permissive and just enter quote mode.
                    inQuotes = true;
                    i++;
                } else if (ch === ',') {
                    row.push(field);
                    field = '';
                    i++;
                } else if (ch === '\r') {
                    // CRLF or lone \r → row break
                    if (text[i + 1] === '\n') i++;
                    row.push(field);
                    if (row.length > 1 || row[0] !== '') rows.push(row);
                    row = [];
                    field = '';
                    i++;
                } else if (ch === '\n') {
                    row.push(field);
                    if (row.length > 1 || row[0] !== '') rows.push(row);
                    row = [];
                    field = '';
                    i++;
                } else {
                    field += ch;
                    i++;
                }
            }
        }
        // Flush trailing field/row (file may not end with newline).
        if (field !== '' || row.length > 0) {
            row.push(field);
            if (row.length > 1 || row[0] !== '') rows.push(row);
        }
        if (inQuotes) {
            throw new Error('Malformed CSV: unterminated quoted field');
        }
        return rows;
    }

    // ============================================================
    // Iter 17: Bulk Promote (move all students to a target class)
    // ============================================================

    async function handleBulkPromoteClick() {
        if (!currentClass) return;
        try {
            const allClasses = await window.TerminalReportDb.listClasses();
            const eligible = allClasses.filter(function (c) {
                return c.academicYearId !== currentClass.academicYearId;
            });
            if (!eligible.length) {
                UI.alert('No eligible target classes found. You need a class in a DIFFERENT academic year.');
                return;
            }
            const students = await window.TerminalReportDb.listStudentsForClass(currentClass.id);
            if (!students.length) {
                UI.alert('No students to promote in this class.');
                return;
            }
            $('mcBulkPromoteContext').textContent = 'Moving ' + students.length + ' student(s) from "' + currentClass.name + '" (' + (currentClass.yearLabel || 'No year') + ')';
            const select = $('mcBulkPromoteTargetClass');
            select.innerHTML = eligible.map(function (c) {
                return '<option value="' + c.id + '">' + escapeHtml(c.name) + ' · ' + escapeHtml(c.yearLabel || 'No year') + '</option>';
            }).join('');
            $('mcBulkPromoteModal').style.display = 'flex';
        } catch (e) {
            UI.alert('Failed to prepare bulk promote: ' + e.message);
        }
    }

    function closeBulkPromoteModal() {
        $('mcBulkPromoteModal').style.display = 'none';
    }

    async function handleBulkPromoteConfirm() {
        const targetClassId = parseInt($('mcBulkPromoteTargetClass').value, 10);
        if (!targetClassId) { UI.alert('Please select a target class.'); return; }
        if (!(await UI.confirm('Move ALL students to the selected class? This cannot be undone.'))) return;
        try {
            const students = await window.TerminalReportDb.listStudentsForClass(currentClass.id);
            let moved = 0, errors = 0;
            for (const s of students) {
                try {
                    await window.TerminalReportDb.moveStudent(s.id, targetClassId);
                    moved++;
                } catch (e) { errors++; }
            }
            closeBulkPromoteModal();
            await renderStudentsTab();
            UI.alert('Bulk promote complete: ' + moved + ' student(s) moved' + (errors > 0 ? ', ' + errors + ' failed' : '') + '.');
        } catch (e) {
            UI.alert('Bulk promote failed: ' + e.message);
        }
    }

    // --- Promote / Repeat student (move to a different class in a different year) ---
    async function handleMoveStudent(studentId) {
        if (!currentClass) return;
        // Show a prompt listing all classes in DIFFERENT academic years
        try {
            const allClasses = await window.TerminalReportDb.listClasses();
            const eligible = allClasses.filter(function (c) {
                return c.academicYearId !== currentClass.academicYearId;
            });
            if (!eligible.length) {
                UI.alert('No eligible target classes found. You need a class in a DIFFERENT academic year to promote/repeat a student.\n\nCreate a new academic year and class first.');
                return;
            }
            // Populate the move modal
            $('mcMoveStudentId').value = studentId;
            const select = $('mcMoveTargetClass');
            select.innerHTML = eligible.map(function (c) {
                return '<option value="' + c.id + '">' + escapeHtml(c.name) + ' · ' + escapeHtml(c.yearLabel || 'No year') + '</option>';
            }).join('');
            // Show the student's current class for context
            const students = await window.TerminalReportDb.listStudentsForClass(currentClass.id);
            const student = students.find(function (s) { return s.id === parseInt(studentId, 10); });
            $('mcMoveContext').textContent = 'Moving: ' + (student ? ((student.surname || '') + ' ' + (student.firstName || '')).trim() || student.name || 'Student' : 'Student') + ' from ' + currentClass.name + ' (' + (currentClass.yearLabel || 'No year') + ')';
            $('mcMoveModal').style.display = 'flex';
        } catch (e) {
            UI.alert('Failed to prepare move: ' + e.message);
        }
    }

    function closeMoveModal() {
        $('mcMoveModal').style.display = 'none';
    }

    async function handleConfirmMove() {
        const studentId = parseInt($('mcMoveStudentId').value, 10);
        const select = $('mcMoveTargetClass');
        const targetClassId = parseInt(select.value, 10);
        // Iter 13 (roadmap #8): inline validation
        clearValidation(select.parentNode);
        if (!targetClassId) {
            setInvalid(select, 'Please select a target class.');
            select.focus();
            return;
        }
        try {
            await window.TerminalReportDb.moveStudent(studentId, targetClassId);
            closeMoveModal();
            await renderStudentsTab();
            UI.alert('Student moved successfully.');
        } catch (e) {
            UI.alert(e.message);
        }
    }

    // --- Subjects tab ---
    async function renderSubjectsTab() {
        if (!currentClass) return;
        const tbody = $('mcSubjectsBody');
        try {
            const subjects = await window.TerminalReportDb.listSubjectsForClass(currentClass.id);
            if (!subjects.length) {
                tbody.innerHTML = '<tr><td colspan="6" class="text-muted text-center py-3">No subjects yet. Add one below.</td></tr>';
                return;
            }
            tbody.innerHTML = subjects.map(function (s, i) {
                return '<tr>' +
                    '<td>' + (i + 1) + '</td>' +
                    '<td>' + escapeHtml(s.code || '') + '</td>' +
                    '<td>' + escapeHtml(s.name) + '</td>' +
                    '<td>' + s.maxMarks + '</td>' +
                    '<td>' + s.minMarks + '</td>' +
                    '<td class="text-nowrap">' +
                        // Iter 12: Enter Marks (pencil-ruler icon). Visible to teachers
                        // to re-open the marks-entry modal at any time, not just on first add.
                        '<button type="button" class="btn btn-sm btn-outline-primary" data-action="marks-subject" data-id="' + s.id + '" title="Enter marks" aria-label="Enter marks for this subject"><i class="fas fa-pen-ruler"></i></button> ' +
                        '<button type="button" class="btn btn-sm btn-outline-primary" data-action="edit-subject" data-id="' + s.id + '" title="Edit subject" aria-label="Edit subject"><i class="fas fa-pen"></i></button> ' +
                        '<button type="button" class="btn btn-sm btn-outline-danger" data-action="delete-subject" data-id="' + s.id + '" title="Delete subject" aria-label="Delete subject"><i class="fas fa-trash"></i></button>' +
                    '</td>' +
                '</tr>';
            }).join('');
        } catch (e) {
            tbody.innerHTML = '<tr><td colspan="6" class="text-danger">Failed to load: ' + escapeHtml(e.message) + '</td></tr>';
        }
    }

    function openSubjectEditor(subject) {
        $('mcSubjectId').value = subject ? subject.id : '';
        $('mcSubjectCode').value = subject ? (subject.code || '') : '';
        $('mcSubjectName').value = subject ? subject.name : '';
        $('mcSubjectMax').value = subject ? subject.maxMarks : 100;
        $('mcSubjectMin').value = subject ? subject.minMarks : 35;
        $('mcSubjectModalTitle').textContent = subject ? 'Edit Subject' : 'Add Subject';
        // Iter 13 (roadmap #8): clear any stale validation state from a prior open
        clearValidation($('mcSubjectModal'));
        $('mcSubjectModal').style.display = 'flex';
    }

    function closeSubjectEditor() {
        $('mcSubjectModal').style.display = 'none';
    }

    async function handleSaveSubject() {
        if (!currentClass) return;
        const id = $('mcSubjectId').value ? parseInt($('mcSubjectId').value, 10) : null;
        const isNew = !id;
        const nameInput = $('mcSubjectName');
        const maxInput = $('mcSubjectMax');
        const minInput = $('mcSubjectMin');
        const input = {
            code: $('mcSubjectCode').value.trim(),
            name: nameInput.value.trim(),
            maxMarks: Number.isFinite(parseInt(maxInput.value, 10)) ? parseInt(maxInput.value, 10) : 100,
            minMarks: Number.isFinite(parseInt(minInput.value, 10)) ? parseInt(minInput.value, 10) : 35,
            classId: currentClass.id
        };
        // Iter 13 (roadmap #8): inline validation

        clearValidation(maxInput.parentNode);
        clearValidation(minInput.parentNode);
        let firstInvalid = null;
        if (!input.name) {
            setInvalid(nameInput, 'Subject name is required.');
            if (!firstInvalid) firstInvalid = nameInput;
        }
        // Validate max marks: must be a positive integer
        const maxRaw = parseInt(maxInput.value, 10);
        if (!Number.isFinite(maxRaw) || maxRaw < 1) {
            setInvalid(maxInput, 'Max marks must be ≥ 1.');
            if (!firstInvalid) firstInvalid = maxInput;
        }
        // Validate pass marks: must be 0 ≤ pass ≤ max
        const minRaw = parseInt(minInput.value, 10);
        if (!Number.isFinite(minRaw) || minRaw < 0) {
            setInvalid(minInput, 'Pass marks must be ≥ 0.');
            if (!firstInvalid) firstInvalid = minInput;
        } else if (Number.isFinite(maxRaw) && minRaw > maxRaw) {
            setInvalid(minInput, 'Pass marks cannot exceed max marks.');
            if (!firstInvalid) firstInvalid = minInput;
        }
        if (firstInvalid) { firstInvalid.focus(); return; }
        try {
            let savedSubjectId;
            if (id) {
                await window.TerminalReportDb.updateSubject(id, input);
                savedSubjectId = id;
            } else {
                savedSubjectId = await window.TerminalReportDb.addSubject(input);
            }
            closeSubjectEditor();
            await renderSubjectsTab();
            // Iter 12 (roadmap #2): after adding a NEW subject, immediately open
            // the marks-entry modal IF the class has at least one student. The
            // spec said: "When adding a new subject, immediately enter marks for
            // all existing students". For empty classes there's nobody to enter
            // marks for, so we skip the prompt (still reachable later via the
            // pencil-ruler icon on the subject row once students are added).
            if (isNew && savedSubjectId) {
                try {
                    const students = await window.TerminalReportDb.listStudentsForClass(currentClass.id);
                    if (students.length > 0) {
                        await openSubjectMarksModal(savedSubjectId);
                    }
                } catch (e) {
                    // Non-blocking, the subject was saved successfully; the
                    // marks modal failing to open shouldn't undo that.
                    console.error('[admin-ui] openSubjectMarksModal after add failed:', e);
                }
            }
        } catch (e) {
            UI.alert('Failed to save: ' + e.message);
        }
    }

    async function handleDeleteSubject(id) {
        if (!(await UI.confirm('Delete this subject?'))) return;
        try {
            await window.TerminalReportDb.deleteSubject(parseInt(id, 10));
            await renderSubjectsTab();
        } catch (e) {
            UI.alert(e.message);
        }
    }

    async function handleEditSubject(id) {
        try {
            const subjects = await window.TerminalReportDb.listSubjectsForClass(currentClass.id);
            const subject = subjects.find(function (s) { return s.id === parseInt(id, 10); });
            if (subject) openSubjectEditor(subject);
        } catch (e) {
            UI.alert('Failed to load subject: ' + e.message);
        }
    }

    // ============================================================
    // Iteration 12 (roadmap #2): Subject marks entry modal.
    //
    // Opens after a NEW subject is added (when the class has ≥1 student) OR
    // when the teacher clicks the pencil-ruler icon on a subject row. Lists
    // every student in the subject's class with a numeric input per student
    // + an "Absent" checkbox. Marks are bulk-UPSERTed via db.saveSubjectMarks.
    // ============================================================

    async function openSubjectMarksModal(subjectId) {
        if (!currentClass || !subjectId) return;
        const modal = $('mcSubjectMarksModal');
        const tbody = $('mcSubjectMarksBody');
        const title = $('mcSubjectMarksTitle');
        const context = $('mcSubjectMarksContext');
        const maxLabel = $('mcSubjectMarksMaxLabel');
        if (!modal || !tbody) return;

        $('mcSubjectMarksSubjectId').value = subjectId;
        // BLIND-7 fix (Iter 23): the subject-marks modal table has exactly 4 columns
        // (index.html:914-917, #, Student, Marks, Absent; data rows below render 4
        // <td>s). All placeholder rows in this modal previously used colspan="5",
        // one cell wider than the table, same bug class as CRIT-19.
        tbody.innerHTML = '<tr><td colspan="4" class="text-muted text-center py-3">Loading…</td></tr>';
        modal.style.display = 'flex';

        try {
            const subject = await window.TerminalReportDb.getSubject(subjectId);
            if (!subject) {
                // BLIND-7 fix (Iter 23): colspan 5 → 4 (4-column table).
                tbody.innerHTML = '<tr><td colspan="4" class="text-danger text-center py-3">Subject not found.</td></tr>';
                return;
            }
            title.textContent = 'Enter Marks: ' + subject.name;
            context.innerHTML = 'Class: <strong>' + escapeHtml(currentClass.name) + '</strong> · Max: <strong>' + subject.maxMarks + '</strong> · Pass: <strong>' + subject.minMarks + '</strong>';
            maxLabel.textContent = subject.maxMarks;

            const rows = await window.TerminalReportDb.listSubjectMarks(subjectId);
            if (!rows.length) {
                // BLIND-7 fix (Iter 23): colspan 5 → 4 (4-column table).
                tbody.innerHTML = '<tr><td colspan="4" class="text-muted text-center py-3">No students in this class yet. Add students first.</td></tr>';
                return;
            }
            // Render one row per student. Inputs use data-student-id so the
            // save handler can collect them with querySelectorAll.
            tbody.innerHTML = rows.map(function (r, i) {
                // Absent students get a disabled marks input (treated as 0).
                const marksValue = r.hasMark ? r.obtainedMarks : '';
                const marksDisabled = r.isAbsent ? 'disabled' : '';
                const absentChecked = r.isAbsent ? 'checked' : '';
                return '<tr>' +
                    '<td class="subject-marks-num">' + (i + 1) + '</td>' +
                    '<td class="subject-marks-name">' + escapeHtml((r.surname || '') + ' ' + (r.firstName || '')).trim() + '</td>' +
                    '<td class="subject-marks-input">' +
                        '<input type="number" class="form-control form-control-sm subject-marks-field" ' +
                            'data-student-id="' + r.studentId + '" ' +
                            'value="' + marksValue + '" min="0" max="' + subject.maxMarks + '" step="0.5" ' +
                            'placeholder="-" ' + marksDisabled + ' aria-label="Marks for ' + escapeAttr(r.name || '') + '">' +
                    '</td>' +
                    '<td class="subject-marks-absent text-center">' +
                        '<input type="checkbox" class="form-check-input subject-marks-absent-cb" ' +
                            'data-student-id="' + r.studentId + '" ' + absentChecked + ' aria-label="Mark ' + escapeAttr(r.name || '') + ' absent">' +
                    '</td>' +
                '</tr>';
            }).join('');

            // Wire the absent checkbox: toggling disables/enables the sibling
            // marks input (visually + semantically). Use event delegation on
            // the tbody, added once per render. We re-bind on every open
            // because the rows are recreated.
            // (Previous listeners on tbody are NOT auto-removed by innerHTML
            // reassignment, but since we use addEventListener on tbody itself
            // (not on individual checkboxes), one binding covers all renders.
            // The listener reads data-student-id from the clicked checkbox.)
            // The init() block below binds the tbody 'change' handler ONCE.
        } catch (e) {
            console.error('[admin-ui] openSubjectMarksModal failed:', e);
            // BLIND-7 fix (Iter 23): colspan 5 → 4 (4-column table).
            tbody.innerHTML = '<tr><td colspan="4" class="text-danger text-center py-3">Failed to load: ' + escapeHtml(e.message) + '</td></tr>';
        }
    }

    function closeSubjectMarksModal() {
        const modal = $('mcSubjectMarksModal');
        if (modal) modal.style.display = 'none';
    }

    /**
     * Read the marks-input fields + absent checkboxes from the modal, validate
     * each row (0 ≤ marks ≤ max), and bulk-save via db.saveSubjectMarks.
     *
     * Validation strategy mirrors the batch wizard (readStep4):
     *   - empty input → 0 marks, isAbsent=false
     *   - non-numeric or out-of-range → mark the input red, show first error
     *   - "Absent" checked → marks forced to 0, isAbsent=true
     */
    async function handleSaveSubjectMarks() {
        const subjectId = parseInt($('mcSubjectMarksSubjectId').value, 10);
        if (!subjectId) { UI.alert('Subject ID missing.'); return; }
        let subject = null;
        try {
            subject = await window.TerminalReportDb.getSubject(subjectId);
        } catch (e) {
            UI.alert('Failed to load subject: ' + e.message);
            return;
        }
        if (!subject) { UI.alert('Subject not found.'); return; }

        // Clear any prior validation state on every render.
        document.querySelectorAll('.subject-marks-field').forEach(function (el) { el.classList.remove('is-invalid'); });

        const marksInputs = document.querySelectorAll('.subject-marks-field');
        const absentCbs = document.querySelectorAll('.subject-marks-absent-cb');
        // Index absent by studentId for O(1) lookup.
        const absentByStudent = {};
        absentCbs.forEach(function (cb) {
            absentByStudent[cb.dataset.studentId] = cb.checked;
        });

        const marks = [];
        let firstError = '';
        marksInputs.forEach(function (input) {
            const studentId = parseInt(input.dataset.studentId, 10);
            const isAbsent = !!absentByStudent[input.dataset.studentId];
            const raw = (input.value || '').trim();
            if (isAbsent || raw === '') {
                marks.push({ studentId: studentId, obtainedMarks: 0, isAbsent: isAbsent });
                return;
            }
            const n = parseFloat(raw);
            if (!Number.isFinite(n) || n < 0) {
                input.classList.add('is-invalid');
                if (!firstError) firstError = 'Invalid marks for student (must be ≥ 0).';
                return;
            }
            if (n > subject.maxMarks) {
                input.classList.add('is-invalid');
                if (!firstError) firstError = 'Marks exceed max (' + subject.maxMarks + ') for one or more students.';
                return;
            }
            marks.push({ studentId: studentId, obtainedMarks: n, isAbsent: false });
        });

        if (firstError) {
            UI.alert(firstError);
            return;
        }

        try {
            await window.TerminalReportDb.saveSubjectMarks(subjectId, marks);
            closeSubjectMarksModal();
            // Refresh the subjects tab so any future iterations that surface
            // "marks entered" badges can read the new state.
            await renderSubjectsTab();
        } catch (e) {
            UI.alert('Failed to save marks: ' + e.message);
        }
    }

    function handleSkipSubjectMarks() {
        // Same as close: the subject is already saved, and marks are just deferred.
        closeSubjectMarksModal();
    }

    async function handleEnterMarksForSubject(id) {
        // Opened from the pencil-ruler icon on an existing subject row.
        await openSubjectMarksModal(parseInt(id, 10));
    }

    /** Toggling the absent checkbox disables/enables the sibling marks input. */
    function handleSubjectMarksAbsentToggle(cb) {
        const studentId = cb.dataset.studentId;
        const input = document.querySelector('.subject-marks-field[data-student-id="' + studentId + '"]');
        if (!input) return;
        if (cb.checked) {
            input.value = '';
            input.disabled = true;
            input.classList.remove('is-invalid');
        } else {
            input.disabled = false;
        }
    }

    // ============================================================
    // Helpers
    // ============================================================

    /**
     * Iter 13 (roadmap #8): Inline validation helper.
     *
     * Marks an input as invalid (Bootstrap `.is-invalid` class) and injects
     * an `.invalid-feedback` message div right after it (Bootstrap shows this
     * automatically when the input has `.is-invalid`). If the input is inside
     * a `.input-group`, the feedback div needs `d-block` to render, handled
     * below by detecting the parent.
     *
     * @param {HTMLElement} inputEl
     * @param {string} message
     */
    function setInvalid(inputEl, message) {
        if (!inputEl) return;
        inputEl.classList.add('is-invalid');
        // Find or create the .invalid-feedback sibling.
        let fb = inputEl.nextElementSibling;
        if (!fb || !fb.classList.contains('invalid-feedback') || !fb.hasAttribute('data-trg-validation')) {
            // Remove any non-trg feedback Bootstrap may have left so our message
            // is the only one shown.
            if (fb && fb.classList.contains('invalid-feedback') && !fb.hasAttribute('data-trg-validation')) {
                fb.remove();
                fb = null;
            }
            fb = document.createElement('div');
            fb.className = 'invalid-feedback';
            fb.setAttribute('data-trg-validation', '1');
            // Insert right after the input, for input-group, Bootstrap 5.3
            // requires `d-block` on the feedback for it to render (because
            // the group is display:flex, the default `display:none` of
            // .invalid-feedback stays hidden).
            if (inputEl.closest('.input-group')) {
                fb.classList.add('d-block');
            }
            inputEl.parentNode.insertBefore(fb, inputEl.nextSibling);
        }
        fb.textContent = message;
    }

    /**
     * Iter 13 (roadmap #8): clear all `.is-invalid` markers and their
     * `.invalid-feedback` siblings inside a container (typically the
     * modal/form the user just interacted with).
     *
     * @param {HTMLElement} containerEl
     */
    function clearValidation(containerEl) {
        if (!containerEl) return;
        containerEl.querySelectorAll('.is-invalid').forEach(function (el) {
            el.classList.remove('is-invalid');
        });
        containerEl.querySelectorAll('.invalid-feedback').forEach(function (el) {
            // Only remove feedback divs we added, Bootstrap's own validation
            // markup uses .invalid-feedback too, and we don't want to nuke
            // static HTML feedback. We tag ours with data-trg-validation
            // so we can tell them apart. (Set in setInvalid() above, see below.)
            if (el.hasAttribute('data-trg-validation')) {
                el.remove();
            }
        });
    }

    function escapeHtml(s) {
        return String(s == null ? '' : s)
            .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
    }
    function escapeAttr(s) { return escapeHtml(s); }

    // ------------------------------------------------------------------
    // Iteration 32 (BUSY-01): shared busy-state guard for buttons that
    // trigger async writes (save/add/confirm/import). Double-clicking these
    // used to run the handler twice (two addStudent calls → duplicate
    // students, two saveSubjectMarks calls, a second move that errors
    // confusingly, and so on). While fn runs, the button is disabled and,
    // optionally, shows a spinner label; both are restored in finally on
    // every exit path, including failures.
    // ------------------------------------------------------------------
    async function withBusy(btn, fn, busyHtml) {
        if (btn && btn.disabled) return;
        const orig = btn ? btn.innerHTML : null;
        if (btn) {
            btn.disabled = true;
            if (busyHtml) btn.innerHTML = busyHtml;
        }
        try {
            await fn();
        } finally {
            if (btn) {
                btn.disabled = false;
                btn.innerHTML = orig;
            }
        }
    }

    /** Attach a busy-guarded click handler to a button id. */
    function wireBusy(id, fn, busyHtml) {
        const btn = $(id);
        if (!btn) return;
        btn.addEventListener('click', function () {
            withBusy(btn, fn, busyHtml);
        });
    }

    // ============================================================
    // Init, register all event listeners once
    // ============================================================
    function init() {
        // Admin overlay open/close
        $('adminCloseBtn').addEventListener('click', closeAdmin);

        // Academic Years
        // Iteration 32 (BUSY-01): the add/save/confirm buttons below are
        // busy-guarded so a double-click cannot submit the same write twice.
        wireBusy('adminAddYearBtn', handleAddYear);
        $('adminYearInput').addEventListener('keydown', function (e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                withBusy($('adminAddYearBtn'), handleAddYear);
            }
        });
        $('adminYearsList').addEventListener('click', function (e) {
            const btn = e.target.closest('[data-action="delete-year"]');
            if (btn) handleDeleteYear(btn.dataset.id);
        });

        // Grading Scales
        $('adminAddScaleBtn').addEventListener('click', function () { openScaleEditor(null); });
        $('adminScalesList').addEventListener('click', function (e) {
            const editBtn = e.target.closest('[data-action="edit-scale"]');
            const delBtn = e.target.closest('[data-action="delete-scale"]');
            if (editBtn) handleEditScale(editBtn.dataset.id);
            else if (delBtn) handleDeleteScale(delBtn.dataset.id);
        });
        // Scale editor
        $('scaleEditorCloseBtn').addEventListener('click', closeScaleEditor);
        wireBusy('scaleEditorSaveBtn', handleSaveScale);
        $('scaleEditorAddBandBtn').addEventListener('click', addScaleBandRow);
        $('scaleEditorBands').addEventListener('click', function (e) {
            const btn = e.target.closest('[data-action="remove-band"]');
            if (btn) removeScaleBandRow(btn.dataset.idx);
        });

        // Classes
        wireBusy('adminAddClassBtn', handleAddClass);
        $('adminClassesList').addEventListener('click', function (e) {
            const manageBtn = e.target.closest('[data-action="manage-class"]');
            const delBtn = e.target.closest('[data-action="delete-class"]');
            if (manageBtn) openManageClass(manageBtn.dataset.id);
            else if (delBtn) handleDeleteClass(delBtn.dataset.id);
        });

        // Manage Class tabs
        document.querySelectorAll('.manage-class-tab').forEach(function (tab) {
            tab.addEventListener('click', function () {
                switchManageTab(tab.dataset.tab);
            });
        });
        $('mcBackBtn').addEventListener('click', closeManageClass);
        wireBusy('mcDetailsSaveBtn', handleSaveDetails);

        // Students tab
        $('mcAddStudentBtn').addEventListener('click', function () { openStudentEditor(null); });

        // Iter 17: CSV import + bulk promote
        $('mcCsvImportBtn').addEventListener('click', handleCsvImportClick);
        // Iteration 32 (BUSY-03): the import button is disabled (with a
        // spinner label) for the whole import; previously a second click
        // during a large import opened another picker and a second import
        // loop ran concurrently, duplicating every student.
        $('mcCsvFileInput').addEventListener('change', function (e) {
            withBusy(
                $('mcCsvImportBtn'),
                function () { return handleCsvFileSelected(e); },
                '<i class="fas fa-spinner fa-spin"></i> Importing…'
            );
        });
        $('mcBulkPromoteBtn').addEventListener('click', handleBulkPromoteClick);
        $('mcBulkPromoteCancelBtn').addEventListener('click', closeBulkPromoteModal);
        wireBusy('mcBulkPromoteConfirmBtn', handleBulkPromoteConfirm);

        $('mcStudentsBody').addEventListener('click', function (e) {
            const editBtn = e.target.closest('[data-action="edit-student"]');
            const moveBtn = e.target.closest('[data-action="move-student"]');
            const delBtn = e.target.closest('[data-action="delete-student"]');
            if (editBtn) handleEditStudent(editBtn.dataset.id);
            else if (moveBtn) handleMoveStudent(moveBtn.dataset.id);
            else if (delBtn) handleDeleteStudent(delBtn.dataset.id);
        });
        $('mcStudentCloseBtn').addEventListener('click', closeStudentEditor);
        wireBusy('mcStudentSaveBtn', handleSaveStudent);

        // Move modal
        $('mcMoveCancelBtn').addEventListener('click', closeMoveModal);
        wireBusy('mcMoveConfirmBtn', handleConfirmMove);

        // Subjects tab
        $('mcAddSubjectBtn').addEventListener('click', function () { openSubjectEditor(null); });
        $('mcSubjectsBody').addEventListener('click', function (e) {
            const editBtn = e.target.closest('[data-action="edit-subject"]');
            const delBtn = e.target.closest('[data-action="delete-subject"]');
            const marksBtn = e.target.closest('[data-action="marks-subject"]');
            if (editBtn) handleEditSubject(editBtn.dataset.id);
            else if (delBtn) handleDeleteSubject(delBtn.dataset.id);
            else if (marksBtn) handleEnterMarksForSubject(marksBtn.dataset.id);
        });
        $('mcSubjectCloseBtn').addEventListener('click', closeSubjectEditor);
        wireBusy('mcSubjectSaveBtn', handleSaveSubject);

        // Iter 12: Subject marks entry modal
        $('mcSubjectMarksCloseBtn').addEventListener('click', closeSubjectMarksModal);
        $('mcSubjectMarksSkipBtn').addEventListener('click', handleSkipSubjectMarks);
        wireBusy('mcSubjectMarksSaveBtn', handleSaveSubjectMarks);
        // Event delegation for absent checkboxes, so one binding covers all rows.
        $('mcSubjectMarksBody').addEventListener('change', function (e) {
            const cb = e.target.closest('.subject-marks-absent-cb');
            if (cb) handleSubjectMarksAbsentToggle(cb);
        });
    }

    // ============================================================
    // Export
    // ============================================================
    window.TerminalReportAdminUI = {
        init: init,
        openAdmin: openAdmin,
        populateClassDropdowns: populateClassDropdowns
    };
})();
