/**
 * TerminalReport: auth layer (Phase B)
 *
 * Responsibility:
 *   - First-run 3-step setup wizard (School Info → PIN → Security Question)
 *   - Lock screen with 4-digit PIN pad
 *   - 5-attempt lockout with exponential backoff (5min → 15min → 1hr → 4hr → 24hr)
 *   - Recovery flow (answer security question → set new PIN)
 *   - PIN change (Settings screen integration)
 *
 * Security design:
 *   - PIN is hashed with SHA-256(salt + pin). Salt is 16 bytes of crypto-random,
 *     base64-encoded for storage. Never stored plaintext.
 *   - Security answer is hashed with a SEPARATE salt (compromise of one
 *     doesn't reveal the other).
 *   - Lockout state (failed attempts, lockedUntil, consecutiveLockouts) is
 *     kept in localStorage, NOT in SQLite, so it persists even if the DB
 *     is unavailable. Reason: the lockout must work even if sql.js fails to load.
 *   - isUnlocked is in-memory only, cleared on page reload (forces re-auth).
 *
 * CRITICAL CONSTRAINT: crypto.subtle requires HTTPS or localhost. file:// will
 * fail. The user must serve via http://localhost or deploy to HTTPS.
 *
 * Public API (window.TerminalReportAuth):
 *   init()                         → Promise<{configured:bool}>
 *   isConfigured()                 → boolean
 *   isUnlocked()                   → boolean
 *   getLockState()                 → { failedAttempts, lockedUntil, consecutiveLockouts }
 *   setup(opts)                    → Promise<void>  (opts: schoolName, logoFile, pin, securityQuestion, securityAnswer)
 *   unlock(pin)                    → Promise<{success, error?, lockedUntil?}>
 *   recover(answer, newPin)        → Promise<{success, error?}>
 *   lock()                         → void
 *   changePin(oldPin, newPin)      → Promise<{success, error?}>
 *   getSchoolInfo()                → { name, logoBytes } | null
 *   onLockStateChange(cb)          → void  (cb called when failedAttempts/lockedUntil change)
 */
(function () {
    'use strict';

    // ------------------------------------------------------------------
    // Constants
    // ------------------------------------------------------------------
    const MAX_ATTEMPTS = 5;
    const LOCKOUT_DURATIONS_MS = [
        5 * 60 * 1000,      // 1st lockout: 5 min  (per spec)
        15 * 60 * 1000,     // 2nd lockout: 15 min
        60 * 60 * 1000,     // 3rd lockout: 1 hour
        4 * 60 * 60 * 1000, // 4th lockout: 4 hours
        24 * 60 * 60 * 1000 // 5th+ lockout: 24 hours
    ];
    const LS_KEY = 'terminalreport-auth-lock';

    // ------------------------------------------------------------------
    // State
    // ------------------------------------------------------------------
    let authRow = null;             // cached auth row from DB
    let unlocked = false;           // in-memory only; cleared on reload
    let lockState = loadLockState(); // persisted in localStorage
    const lockStateListeners = [];

    // ------------------------------------------------------------------
    // Helpers
    // ------------------------------------------------------------------
    function loadLockState() {
        try {
            const raw = localStorage.getItem(LS_KEY);
            if (!raw) return { failedAttempts: 0, lockedUntil: null, consecutiveLockouts: 0 };
            const obj = JSON.parse(raw);
            // If lockout has expired, reset failedAttempts but keep consecutiveLockouts
            // (so the next lockout still escalates).
            if (obj.lockedUntil && Date.now() >= obj.lockedUntil) {
                obj.failedAttempts = 0;
                obj.lockedUntil = null;
                // Keep consecutiveLockouts as-is; will reset after a successful unlock.
            }
            return obj;
        } catch (_) {
            return { failedAttempts: 0, lockedUntil: null, consecutiveLockouts: 0 };
        }
    }

    function saveLockState() {
        try {
            localStorage.setItem(LS_KEY, JSON.stringify(lockState));
        } catch (e) {
            console.error('[auth] failed to persist lock state:', e);
        }
        // Notify listeners
        const snapshot = getLockState();
        lockStateListeners.forEach(function (cb) {
            try { cb(snapshot); } catch (_) { /* listener error, ignore */ }
        });
    }

    function getLockState() {
        return {
            failedAttempts: lockState.failedAttempts || 0,
            lockedUntil: lockState.lockedUntil || null,
            consecutiveLockouts: lockState.consecutiveLockouts || 0
        };
    }

    function onLockStateChange(cb) {
        if (typeof cb === 'function') lockStateListeners.push(cb);
    }

    // --- crypto helpers (require HTTPS or localhost) ---
    function generateSalt(bytes) {
        const arr = new Uint8Array(bytes);
        crypto.getRandomValues(arr);
        // base64 encode
        let binary = '';
        for (let i = 0; i < arr.length; i++) binary += String.fromCharCode(arr[i]);
        return btoa(binary);
    }

    async function sha256(text) {
        if (!crypto.subtle) {
            throw new Error('crypto.subtle unavailable. Serve via HTTPS or http://localhost; file:// will not work.');
        }
        const enc = new TextEncoder();
        const buf = await crypto.subtle.digest('SHA-256', enc.encode(text));
        // Convert ArrayBuffer → hex
        const bytes = new Uint8Array(buf);
        let hex = '';
        for (let i = 0; i < bytes.length; i++) {
            hex += bytes[i].toString(16).padStart(2, '0');
        }
        return hex;
    }

    // Iter 20 fix (SEC-01): PBKDF2 key stretching, 100,000 iterations of SHA-256.
    // A 4-digit PIN has 10,000 possibilities. With PBKDF2 at 100k iterations,
    // brute-forcing all 10,000 PINs takes ~10 seconds on a fast CPU (vs <1ms
    // with single SHA-256). This raises the bar significantly for offline attacks.
    const PBKDF2_ITERATIONS = 100000;

    async function pbkdf2Hash(saltBase64, value) {
        if (!crypto.subtle) {
            throw new Error('crypto.subtle unavailable. Serve via HTTPS or http://localhost; file:// will not work.');
        }
        const enc = new TextEncoder();
        // Decode the base64 salt to bytes
        const saltBinary = atob(saltBase64);
        const saltBytes = new Uint8Array(saltBinary.length);
        for (let i = 0; i < saltBinary.length; i++) saltBytes[i] = saltBinary.charCodeAt(i);
        // Import the value as a key material
        const keyMaterial = await crypto.subtle.importKey(
            'raw', enc.encode(value), { name: 'PBKDF2' }, false, ['deriveBits']
        );
        // Derive 256 bits (32 bytes) via PBKDF2
        const derivedBits = await crypto.subtle.deriveBits(
            { name: 'PBKDF2', salt: saltBytes, iterations: PBKDF2_ITERATIONS, hash: 'SHA-256' },
            keyMaterial, 256
        );
        // Convert to hex
        const bytes = new Uint8Array(derivedBits);
        let hex = '';
        for (let i = 0; i < bytes.length; i++) {
            hex += bytes[i].toString(16).padStart(2, '0');
        }
        return hex;
    }

    // Iter 20: hashWithSalt now uses PBKDF2 instead of single SHA-256.
    // Backwards compat: if an old hash (single SHA-256, 64 hex chars) is stored,
    // unlock() falls back to the old comparison (see unlock() below).
    async function hashWithSalt(salt, value) {
        return await pbkdf2Hash(salt, value);
    }

    /** Generate a UUID v4 using crypto.getRandomValues (not Math.random). */
    function generateUuid() {
        const arr = new Uint8Array(16);
        crypto.getRandomValues(arr);
        // Set version (4) and variant (RFC 4122)
        arr[6] = (arr[6] & 0x0f) | 0x40;
        arr[8] = (arr[8] & 0x3f) | 0x80;
        const hex = [];
        for (let i = 0; i < arr.length; i++) hex.push(arr[i].toString(16).padStart(2, '0'));
        const s = hex.join('');
        return s.slice(0, 8) + '-' + s.slice(8, 12) + '-' + s.slice(12, 16) + '-' + s.slice(16, 20) + '-' + s.slice(20, 32);
    }

    /** Resize a logo File to 256x256 PNG. Returns Promise<Uint8Array|null>. */
    async function resizeLogoTo256(file) {
        if (!file) return null;
        return new Promise(function (resolve, reject) {
            const img = new Image();
            const url = URL.createObjectURL(file);
            img.onload = function () {
                URL.revokeObjectURL(url);
                const canvas = document.createElement('canvas');
                canvas.width = 256;
                canvas.height = 256;
                const ctx = canvas.getContext('2d');
                // White background so transparent PNGs don't get black on resize
                ctx.fillStyle = '#ffffff';
                ctx.fillRect(0, 0, 256, 256);
                // Contain (not cover), letterbox if aspect ratios differ
                const scale = Math.min(256 / img.width, 256 / img.height);
                const w = img.width * scale;
                const h = img.height * scale;
                const x = (256 - w) / 2;
                const y = (256 - h) / 2;
                ctx.drawImage(img, x, y, w, h);
                canvas.toBlob(function (blob) {
                    if (!blob) { reject(new Error('Canvas toBlob returned null')); return; }
                    const reader = new FileReader();
                    reader.onload = function (e) { resolve(new Uint8Array(e.target.result)); };
                    reader.onerror = function () { reject(reader.error); };
                    reader.readAsArrayBuffer(blob);
                }, 'image/png');
            };
            img.onerror = function () {
                URL.revokeObjectURL(url);
                reject(new Error('Could not load image. Use PNG, JPG, or GIF.'));
            };
            img.src = url;
        });
    }

    /** File → Uint8Array (used for non-image uploads if needed). */
    function fileToUint8Array(file) {
        return new Promise(function (resolve, reject) {
            if (!file) return resolve(null);
            if (file.arrayBuffer) {
                file.arrayBuffer().then(function (buf) {
                    resolve(new Uint8Array(buf));
                }).catch(reject);
                return;
            }
            const reader = new FileReader();
            reader.onload = function (e) { resolve(new Uint8Array(e.target.result)); };
            reader.onerror = function () { reject(reader.error); };
            reader.readAsArrayBuffer(file);
        });
    }

    // ------------------------------------------------------------------
    // Public API
    // ------------------------------------------------------------------
    async function init() {
        if (!window.TerminalReportDb) return { configured: false };
        try {
            await window.TerminalReportDb.init();
            authRow = await window.TerminalReportDb.loadAuth();
        } catch (e) {
            console.error('[auth] init failed:', e);
            authRow = null;
        }
        return { configured: !!authRow };
    }

    function isConfigured() { return !!authRow; }
    function isUnlocked() { return unlocked; }

    async function setup(opts) {
        if (!window.TerminalReportDb) throw new Error('DB not available');
        // Iter 26 audit guard: setup() overwrites the auth row unconditionally,
        // and generateUuid() below mints a NEW app UUID. A stray second call
        // (script bug, double-click race, restored-DB confusion) would silently
        // rotate the UUID, and since the backup HMAC key + PBKDF2 KDF input IS
        // the app UUID, every previously exported .trbak would become
        // unrestorable. The setup wizard is only reachable when unconfigured
        // (auth-ui start()), so this guard removes no legitimate path; a real
        // reset still goes through clearing site data (which the user is told
        // invalidates backups, see ROADMAP constraint #9).
        if (authRow) throw new Error('App is already configured. Clear site data to start over (this invalidates existing backups).');
        if (!opts.schoolName || !opts.schoolName.trim()) throw new Error('School name is required');
        if (!/^\d{4}$/.test(opts.pin || '')) throw new Error('PIN must be exactly 4 digits');
        if (!opts.securityQuestion || !opts.securityQuestion.trim()) throw new Error('Security question is required');
        if (!opts.securityAnswer || !opts.securityAnswer.trim()) throw new Error('Security answer is required');

        const pinSalt = generateSalt(16);
        const pinHash = await hashWithSalt(pinSalt, opts.pin);
        const answerSalt = generateSalt(16);
        const answerHash = await hashWithSalt(answerSalt, opts.securityAnswer.trim().toLowerCase());
        const logoBytes = opts.logoFile ? await resizeLogoTo256(opts.logoFile) : null;
        const appUuid = generateUuid();

        await window.TerminalReportDb.saveAuth({
            schoolName: opts.schoolName.trim(),
            logoBlob: logoBytes,
            pinHash: pinHash,
            pinSalt: pinSalt,
            securityQuestion: opts.securityQuestion.trim(),
            securityAnswerHash: answerHash,
            securityAnswerSalt: answerSalt,
            appUuid: appUuid
        });

        authRow = await window.TerminalReportDb.loadAuth();
        // Reset lock state on first setup
        lockState = { failedAttempts: 0, lockedUntil: null, consecutiveLockouts: 0 };
        saveLockState();
        unlocked = true;
    }

    async function unlock(pin) {
        if (!authRow) return { success: false, error: 'Not configured' };
        if (!/^\d{4}$/.test(pin || '')) return { success: false, error: 'PIN must be 4 digits' };

        // Check lockout
        if (lockState.lockedUntil && Date.now() < lockState.lockedUntil) {
            const remaining = lockState.lockedUntil - Date.now();
            return { success: false, error: 'locked', lockedUntil: lockState.lockedUntil, remainingMs: remaining };
        }

        const candidateHash = await hashWithSalt(authRow.pinSalt, pin);
        // Iter 20 fix (SEC-01): also check old SHA-256 hash for backwards compat
        // with PINs set before PBKDF2 was introduced. If the old hash matches,
        // we re-hash with PBKDF2 and update the stored hash transparently.
        let matched = (candidateHash === authRow.pinHash);
        if (!matched) {
            // Try old single-SHA-256 hash (salt + ':' + pin)
            const oldHash = await sha256(authRow.pinSalt + ':' + pin);
            if (oldHash === authRow.pinHash) {
                matched = true;
                // Transparently upgrade to PBKDF2
                try {
                    const newHash = await pbkdf2Hash(authRow.pinSalt, pin);
                    await window.TerminalReportDb.updatePin(newHash, authRow.pinSalt);
                    authRow.pinHash = newHash;
                } catch (e) {
                    console.warn('[auth] failed to upgrade PIN hash to PBKDF2:', e);
                }
            }
        }
        if (matched) {
            // Success: reset everything
            lockState = { failedAttempts: 0, lockedUntil: null, consecutiveLockouts: 0 };
            saveLockState();
            unlocked = true;
            return { success: true };
        }

        // Failure
        lockState.failedAttempts = (lockState.failedAttempts || 0) + 1;
        if (lockState.failedAttempts >= MAX_ATTEMPTS) {
            // Lock the user out
            const idx = Math.min(lockState.consecutiveLockouts || 0, LOCKOUT_DURATIONS_MS.length - 1);
            const duration = LOCKOUT_DURATIONS_MS[idx];
            lockState.lockedUntil = Date.now() + duration;
            lockState.consecutiveLockouts = (lockState.consecutiveLockouts || 0) + 1;
            lockState.failedAttempts = 0;
            saveLockState();
            return {
                success: false,
                error: 'locked',
                lockedUntil: lockState.lockedUntil,
                remainingMs: duration,
                reason: 'max_attempts'
            };
        }
        saveLockState();
        return {
            success: false,
            error: 'incorrect',
            attemptsRemaining: MAX_ATTEMPTS - lockState.failedAttempts
        };
    }

    async function recover(answer, newPin) {
        if (!authRow) return { success: false, error: 'Not configured' };
        if (!answer || !answer.trim()) return { success: false, error: 'Answer is required' };
        if (!/^\d{4}$/.test(newPin || '')) return { success: false, error: 'New PIN must be exactly 4 digits' };

        // Iter 21 fix (CRIT-03): rate-limit recovery attempts using the same
        // lockout state as unlock(). Reuses lockState.failedAttempts and
        // lockState.lockedUntil so recovery attempts count toward the same
        // lockout escalation as PIN attempts.
        if (lockState.lockedUntil && Date.now() < lockState.lockedUntil) {
            const remaining = lockState.lockedUntil - Date.now();
            return { success: false, error: 'locked', lockedUntil: lockState.lockedUntil, remainingMs: remaining };
        }

        // BLIND-8 fix (Iter 23): previous comparison was PBKDF2-only. Security
        // answers set before Iter 20 (when hashWithSalt switched to PBKDF2) are
        // stored as single SHA-256 of "salt:answer", the SAME legacy format as
        // pre-Iter-20 PIN hashes (see unlock()'s fallback above). A pre-Iter-20
        // user who forgot their PIN could NEVER pass recovery: the PBKDF2
        // candidate never matched the legacy stored hash → permanent lockout
        // from the recovery flow. Mirror unlock()'s backwards-compat fallback,
        // and on a legacy match transparently upgrade the stored answer hash to
        // PBKDF2 (same pattern as unlock()'s PIN-hash upgrade).
        const candidateAnswerHash = await hashWithSalt(authRow.securityAnswerSalt, answer.trim().toLowerCase());
        let answerMatched = (candidateAnswerHash === authRow.securityAnswerHash);
        let legacyAnswerMatched = false;
        if (!answerMatched) {
            const legacyAnswerHash = await sha256(authRow.securityAnswerSalt + ':' + answer.trim().toLowerCase());
            if (legacyAnswerHash === authRow.securityAnswerHash) {
                answerMatched = true;
                legacyAnswerMatched = true;
            }
        }
        if (!answerMatched) {
            // Iter 21 fix (CRIT-03): increment failedAttempts on wrong answer
            lockState.failedAttempts = (lockState.failedAttempts || 0) + 1;
            if (lockState.failedAttempts >= MAX_ATTEMPTS) {
                const idx = Math.min(lockState.consecutiveLockouts || 0, LOCKOUT_DURATIONS_MS.length - 1);
                const duration = LOCKOUT_DURATIONS_MS[idx];
                lockState.lockedUntil = Date.now() + duration;
                lockState.consecutiveLockouts = (lockState.consecutiveLockouts || 0) + 1;
                lockState.failedAttempts = 0;
                saveLockState();
                return {
                    success: false,
                    error: 'locked',
                    lockedUntil: lockState.lockedUntil,
                    remainingMs: duration,
                    reason: 'max_attempts_recovery'
                };
            }
            saveLockState();
            return {
                success: false,
                error: 'incorrect_answer',
                attemptsRemaining: MAX_ATTEMPTS - lockState.failedAttempts
            };
        }

        // Correct answer: issue a new PIN + new salt
        const newSalt = generateSalt(16);
        const newHash = await hashWithSalt(newSalt, newPin);
        await window.TerminalReportDb.updatePin(newHash, newSalt);
        authRow = await window.TerminalReportDb.loadAuth();
        // BLIND-8 fix (Iter 23): if the answer matched via the legacy SHA-256
        // path, transparently upgrade the stored answer hash to PBKDF2 (best
        // effort, same pattern as unlock()'s PIN-hash upgrade). Without this,
        // the legacy answer hash would persist forever and every future
        // recovery would depend on the fallback path staying correct.
        if (legacyAnswerMatched) {
            try {
                const newAnswerSalt = generateSalt(16);
                const newAnswerHash = await hashWithSalt(newAnswerSalt, answer.trim().toLowerCase());
                await window.TerminalReportDb.updateSecurityAnswer(newAnswerHash, newAnswerSalt);
                authRow = await window.TerminalReportDb.loadAuth();
            } catch (e) {
                console.warn('[auth] failed to upgrade security answer hash to PBKDF2:', e);
            }
        }
        // Reset lockout state on recovery (forgiveness, not punishment)
        lockState = { failedAttempts: 0, lockedUntil: null, consecutiveLockouts: 0 };
        saveLockState();
        unlocked = true;
        return { success: true };
    }

    function lock() {
        unlocked = false;
    }

    async function changePin(oldPin, newPin) {
        if (!authRow) return { success: false, error: 'Not configured' };
        if (!/^\d{4}$/.test(oldPin || '')) return { success: false, error: 'Current PIN must be 4 digits' };
        if (!/^\d{4}$/.test(newPin || '')) return { success: false, error: 'New PIN must be 4 digits' };
        if (oldPin === newPin) return { success: false, error: 'New PIN must differ from current PIN' };

        // CRIT-20 fix (Iter 23): previous comparison was PBKDF2-only, unlike
        // unlock() above, there was no fallback to the pre-Iter-20 single
        // SHA-256 hash. A user whose stored pinHash is still legacy (e.g. the
        // transparent upgrade inside unlock() failed and was swallowed by its
        // try/catch, leaving legacy hash + unlocked session) got a permanent
        // "incorrect PIN" from changePin(). Mirror unlock()'s fallback here:
        // if the legacy hash matches, proceed, the write below stores the NEW
        // PIN with a FRESH salt + PBKDF2, which upgrades the row implicitly.
        const candidateHash = await hashWithSalt(authRow.pinSalt, oldPin);
        let matched = (candidateHash === authRow.pinHash);
        if (!matched) {
            // Legacy format: single SHA-256 of "salt:pin" (pre-Iter-20 hashWithSalt)
            const legacyHash = await sha256(authRow.pinSalt + ':' + oldPin);
            if (legacyHash === authRow.pinHash) matched = true;
        }
        if (!matched) {
            return { success: false, error: 'incorrect' };
        }
        const newSalt = generateSalt(16);
        const newHash = await hashWithSalt(newSalt, newPin);
        await window.TerminalReportDb.updatePin(newHash, newSalt);
        authRow = await window.TerminalReportDb.loadAuth();
        return { success: true };
    }

    function getSchoolInfo() {
        if (!authRow) return null;
        return {
            name: authRow.schoolName,
            logoBytes: authRow.logoBlob,
            appUuid: authRow.appUuid
        };
    }

    /**
     * Phase C: re-read the auth row from DB. Called after restore replaces
     * the in-memory DB with new bytes.
     *
     * Iter 26 audit (docstring correction): this function does NOT reset the
     * in-memory `unlocked` flag, the wording below previously claimed it did.
     * Deliberate behaviour: restore is only reachable from Settings (i.e., an
     * already-unlocked session), and staying unlocked after a same-install
     * restore is the intended UX. The restored PIN applies from the next
     * lock() or page reload. Callers that DO need re-authentication must call
     * TerminalReportAuth.lock() themselves.
     */
    async function refresh() {
        if (!window.TerminalReportDb) return;
        try {
            authRow = await window.TerminalReportDb.loadAuth();
        } catch (e) {
            console.error('[auth] refresh failed:', e);
            authRow = null;
        }
    }

    // ------------------------------------------------------------------
    // Export
    // ------------------------------------------------------------------
    window.TerminalReportAuth = {
        init: init,
        isConfigured: isConfigured,
        isUnlocked: isUnlocked,
        getLockState: getLockState,
        onLockStateChange: onLockStateChange,
        setup: setup,
        unlock: unlock,
        recover: recover,
        lock: lock,
        changePin: changePin,
        getSchoolInfo: getSchoolInfo,
        refresh: refresh,
        // exposed for testing only, not part of public API contract
        _resizeLogoTo256: resizeLogoTo256,
        _generateUuid: generateUuid,
        _MAX_ATTEMPTS: MAX_ATTEMPTS,
        _LOCKOUT_DURATIONS_MS: LOCKOUT_DURATIONS_MS
    };
})();
