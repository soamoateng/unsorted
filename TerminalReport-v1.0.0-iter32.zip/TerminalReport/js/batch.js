/**
 * TerminalReport: batch generation logic (Phase D)
 *
 * Responsibility:
 *   - Pure functions: per-student summary, class ranking (with ties),
 *     per-subject ranking, certificate number generation
 *   - DB save in one transaction (via TerminalReportDb.saveBatch)
 *   - "Reports already exist?" detection (via TerminalReportDb.findBatch)
 *
 * Bound to:
 *   - window.TerminalReportDb (for findBatch, saveBatch, listBatches, listReportsForBatch,
 *                   deleteBatch, getPrefillForClass)
 *   - window.TerminalReportAuth (for school name + logo bytes via getSchoolInfo)
 *
 * Public API (window.TerminalReportBatch):
 *   computeSummary(subjects)                   → { totalMax, totalObtained, percentage, overallGrade, passed }
 *   rankStudents(studentsWithTotals)           → assigns classRank (ties allowed)
 *   rankBySubject(students, subjects, marks)    → assigns subjectRank per (student, subject)
 *   generateCertNos(prefix, count)             → Array<string>
 *   buildBatchReports(input)                   → Array<Report> ready for saveBatch
 *   generateAndSave(input)                      → Promise<{batchId, reportCount}>
 *   checkExistingBatch(academicYear, className, academicTerm) → Promise<{exists:bool, batch?}>
 *
 * Input shape for buildBatchReports / generateAndSave:
 *   { academyName, academicYear, academicTerm, className, term,
 *     studentCount, subjectCount, certificatePrefix,
 *     schoolLogoBytes, totalDays,
 *     subjects: [{code, name, max, min}],
 *     students: [{surname, firstName, name, dob, gender, photoBytes?}],
 *     marks: { [studentIndex]: { [subjectIndex]: number } },
 *     attendance: { [studentIndex]: { daysPresent, remark } },
 *     issueDate }
 *
 * Iteration 30: totalDays is batch-wide (entered once in wizard Step 1)
 * and is copied into every student's summary; attendance holds only
 * daysPresent (Step 5) and remark (Step 4 marks grid).
 */
(function () {
    'use strict';

    // ------------------------------------------------------------------
    // Grade thresholds (DEFAULT, used when no custom scale is provided).
    // Phase E: callers can pass a custom scale (from the grading_scales table)
    // to override these defaults.
    // ------------------------------------------------------------------
    const DEFAULT_GRADE_THRESHOLDS = [
        { grade: 'A+', min: 90 },
        { grade: 'A',  min: 80 },
        { grade: 'B+', min: 70 },
        { grade: 'B',  min: 60 },
        { grade: 'C',  min: 50 },
        { grade: 'D',  min: 40 },
        { grade: 'F',  min: 0  }
    ];

    /**
     * Convert a grading scale from DB format to the internal thresholds format.
     * DB scale: { bands: [{gradeLetter, minPercentage, description}] }
     * Internal: [{grade, min}]
     */
    function normalizeScale(dbScale) {
        if (!dbScale || !dbScale.bands || !dbScale.bands.length) {
            return DEFAULT_GRADE_THRESHOLDS;
        }
        // Sort descending by min_percentage so find() works correctly
        return dbScale.bands
            .map(function (b) {
                return { grade: b.gradeLetter, min: parseInt(b.minPercentage, 10) };
            })
            .sort(function (a, b) { return b.min - a.min; });
    }

    function getGrade(score, scale) {
        const n = Number(score);
        const thresholds = scale || DEFAULT_GRADE_THRESHOLDS;
        if (!Number.isFinite(n)) {
            // Return the lowest band (last after sort = lowest min)
            return thresholds[thresholds.length - 1].grade;
        }
        return (thresholds.find(function (t) { return n >= t.min; }) ||
                thresholds[thresholds.length - 1]).grade;
    }

    function getGradeClass(grade) {
        if (grade.indexOf('A') !== -1) return 'grade-a';
        if (grade.indexOf('B') !== -1) return 'grade-b';
        if (grade.indexOf('C') !== -1 || grade.indexOf('D') !== -1) return 'grade-c';
        return 'grade-f';
    }

    function toNumber(v, fallback) {
        const n = parseFloat(v);
        return Number.isFinite(n) ? n : (fallback || 0);
    }

    // ------------------------------------------------------------------
    // Per-student summary (mirrors script.js computeSummary, but takes
    // a marks array indexed by subject). Phase E: accepts optional scale.
    // ------------------------------------------------------------------
    function computeSummary(subjects, marksBySubject, scale) {
        // subjects: [{code, name, max, min}, ...]
        // marksBySubject: { 0: 85, 1: 72, ... } (subjectIndex → obtained marks)
        // scale: normalised thresholds array [{grade, min}] OR null (use default)
        const thresholds = scale || DEFAULT_GRADE_THRESHOLDS;
        let totalMax = 0, totalObtained = 0, totalMin = 0;
        let allPassed = true;
        const subjectResults = [];

        subjects.forEach(function (s, idx) {
            const obtained = toNumber(marksBySubject[idx], 0);
            const max = toNumber(s.max, 100);
            const min = toNumber(s.min, 35);
            const passed = obtained >= min;
            if (!passed) allPassed = false;
            totalMax += max;
            totalObtained += obtained;
            totalMin += min;
            const pct = max > 0 ? (obtained / max) * 100 : 0;
            const grade = getGrade(pct, thresholds);
            subjectResults.push({
                code: s.code || '',
                name: s.name,
                max: max,
                min: min,
                obtained: obtained,
                percentage: pct,
                grade: grade,
                gradeClass: getGradeClass(grade),
                passed: passed
            });
        });

        const percentage = totalMax > 0 ? (totalObtained / totalMax) * 100 : 0;
        const overallGrade = getGrade(percentage, thresholds);

        return {
            subjects: subjectResults,
            totalMax: totalMax,
            totalObtained: totalObtained,
            totalMin: totalMin,
            percentage: percentage.toFixed(1),
            overallGrade: overallGrade,
            overallGradeClass: getGradeClass(overallGrade),
            passed: subjects.length > 0 && allPassed
        };
    }

    // ------------------------------------------------------------------
    // Class ranking with ties (standard competition ranking: 1, 2, 2, 4)
    // ------------------------------------------------------------------

    // Iter 31 audit fix (FLT-01): totals are sums of float marks, so two
    // students with mathematically equal totals can differ by float noise
    // (e.g. 33.3 + 33.3 + 33.4 → 100.00000000000001 vs 100), which broke the
    // tie comparison and ranked equal students differently. Ranking compares
    // on a fixed-precision key (4 dp, far beyond any real mark granularity)
    // so float artefacts tie while genuine differences still rank.
    function rankKey(v) {
        return Math.round(Number(v) * 10000);
    }

    function rankStudents(studentsWithTotals) {
        // studentsWithTotals: [{studentIndex, totalMarks, ...}, ...]
        // Mutates each to add .classRank
        // Sort by totalMarks desc
        const sorted = studentsWithTotals.slice().sort(function (a, b) {
            return b.totalMarks - a.totalMarks;
        });
        let currentRank = 0;
        let lastKey = null;
        sorted.forEach(function (s, i) {
            const key = rankKey(s.totalMarks);
            if (lastKey === null || key !== lastKey) {
                currentRank = i + 1;
            }
            s.classRank = currentRank;
            lastKey = key;
        });
        return studentsWithTotals; // return original (now with classRank added)
    }

    // ------------------------------------------------------------------
    // Per-subject ranking (also standard competition ranking with ties)
    // ------------------------------------------------------------------
    function rankBySubject(students, subjects, marks) {
        // For each subject, sort students by obtained marks desc, assign rank
        // Returns { [subjectIndex]: { [studentIndex]: rank } }
        const result = {};
        subjects.forEach(function (_, subjIdx) {
            const list = students.map(function (_, studIdx) {
                return { studentIndex: studIdx, obtained: toNumber(marks[studIdx] && marks[studIdx][subjIdx], 0) };
            }).sort(function (a, b) {
                return b.obtained - a.obtained;
            });
            let currentRank = 0;
            let lastKey = null;
            result[subjIdx] = {};
            list.forEach(function (entry, i) {
                const key = rankKey(entry.obtained);
                if (lastKey === null || key !== lastKey) {
                    currentRank = i + 1;
                }
                result[subjIdx][entry.studentIndex] = currentRank;
                lastKey = key;
            });
        });
        return result;
    }

    // ------------------------------------------------------------------
    // Certificate number generation
    // Format: PREFIX-NNNN (zero-padded 4-digit sequence)
    // If prefix is empty, use TR-YYYYMMDD as prefix
    // ------------------------------------------------------------------
    function generateCertNos(prefix, count) {
        const out = [];
        const actualPrefix = (prefix && prefix.trim()) || defaultPrefix();
        for (let i = 1; i <= count; i++) {
            out.push(actualPrefix + '-' + String(i).padStart(4, '0'));
        }
        return out;
    }

    function defaultPrefix() {
        const now = new Date();
        const ymd = now.getFullYear() +
            String(now.getMonth() + 1).padStart(2, '0') +
            String(now.getDate()).padStart(2, '0');
        return 'TR-' + ymd;
    }

    // ------------------------------------------------------------------
    // Build all reports for a batch (pure, no DB I/O)
    // Phase E: accepts optional gradingScale (DB format) to use custom bands.
    // ------------------------------------------------------------------
    function buildBatchReports(input) {
        const subjects = input.subjects || [];
        const students = input.students || [];
        const marks = input.marks || {};
        const attendance = input.attendance || {};
        const issueDate = input.issueDate;
        const certPrefix = (input.certificatePrefix || '').trim();
        const certNos = generateCertNos(certPrefix, students.length);
        const schoolLogoBytes = input.schoolLogoBytes || null;
        // Phase E: normalise the grading scale (if provided)
        const scale = input.gradingScale ? normalizeScale(input.gradingScale) : null;

        // Iter 31 audit fix (SCALE-01, part A): snapshot the grading bands
        // actually used for this batch into every report summary. The report
        // renderer previously recomputed grades from hardcoded default
        // thresholds, so a class on a CUSTOM grading scale printed the wrong
        // per-subject letters, and the printed "Grading Scale" legend was
        // always the default 7-band scale regardless of the class's scale.
        // The bands are carried (with the DB band descriptions, when the
        // scale came from the DB) so the renderer can draw both the grade
        // and the legend from the same source the grades were computed with.
        let gradingScaleBands = null;
        if (scale && scale.length) {
            const dbBands = (input.gradingScale && input.gradingScale.bands) || [];
            gradingScaleBands = scale.map(function (t) {
                let description = '';
                for (let i = 0; i < dbBands.length; i++) {
                    if (dbBands[i] && dbBands[i].gradeLetter === t.grade) {
                        description = dbBands[i].description || '';
                        break;
                    }
                }
                return { grade: t.grade, min: t.min, description: description };
            });
        } else {
            // No scale resolved: the default thresholds are what the grades
            // actually used, so snapshot those as well. Every new report then
            // carries its true legend (robust even if the defaults change in
            // a future version); only pre-Iter-31 rows lack the field.
            gradingScaleBands = DEFAULT_GRADE_THRESHOLDS.map(function (t) {
                return { grade: t.grade, min: t.min, description: '' };
            });
        }

        // Compute per-student totals for ranking
        const studentsWithTotals = students.map(function (stud, idx) {
            const summary = computeSummary(subjects, marks[idx] || {}, scale);
            return {
                studentIndex: idx,
                student: stud,
                totalMarks: summary.totalObtained,
                totalMax: summary.totalMax,
                summary: summary
            };
        });

        // Class ranking
        rankStudents(studentsWithTotals);

        // Per-subject ranking
        const subjectRanks = rankBySubject(students, subjects, marks);

        // Build final report objects
        const reports = studentsWithTotals.map(function (swt) {
            const idx = swt.studentIndex;
            const stud = swt.student;
            const summary = swt.summary;
            const att = attendance[idx] || {};

            // Inject subjectRank into each subject result
            summary.subjects.forEach(function (subj, subjIdx) {
                subj.subjectRank = subjectRanks[subjIdx] ? subjectRanks[subjIdx][idx] : null;
            });

            return {
                academyName: input.academyName,
                academicYear: input.academicYear,
                academicTerm: input.academicTerm,
                studentName: ((stud.surname || '') + ' ' + (stud.firstName || '')).trim() || stud.name || '',
                studentClass: input.className,
                issueDate: issueDate,
                certificateNo: certNos[idx],
                subjects: summary.subjects,
                summary: {
                    totalMax: summary.totalMax,
                    totalObtained: summary.totalObtained,
                    totalMin: summary.totalMin,
                    percentage: summary.percentage,
                    overallGrade: summary.overallGrade,
                    overallGradeClass: summary.overallGradeClass,
                    passed: summary.passed,
                    daysPresent: toNumber(att.daysPresent, 0),
                    // Iteration 30: totalDays is batch-level input now; the
                    // per-student value (old attendance.totalDays) is no
                    // longer collected.
                    totalDays: toNumber(input.totalDays, 0),
                    teacherRemark: att.remark || '',
                    classRank: swt.classRank,
                    // Iter 13 (roadmap #10): expose totalStudents so the report
                    // card can render "Rank #N of M" badges per subject.
                    totalStudents: students.length,
                    // Iter 31 audit fix (SCALE-01, part A): the grading bands
                    // used for this batch, so the rendered legend always
                    // matches the scale the grades were computed with.
                    // Null for legacy rows (renderer keeps its default legend).
                    gradingScaleBands: gradingScaleBands
                },
                logoBlob: schoolLogoBytes,
                photoBlob: stud.photoBytes || null,
                studentIdInBatch: idx + 1,
                classRank: swt.classRank
            };
        });
        return reports;
    }

    // ------------------------------------------------------------------
    // Check for existing batch (for "regenerate?" prompt)
    // ------------------------------------------------------------------
    async function checkExistingBatch(academicYear, className, academicTerm) {
        if (!window.TerminalReportDb) return { exists: false };
        const batch = await window.TerminalReportDb.findBatch(academicYear, className, academicTerm);
        return { exists: !!batch, batch: batch };
    }

    // ------------------------------------------------------------------
    // Generate + save in one transaction
    // ------------------------------------------------------------------
    async function generateAndSave(input) {
        if (!window.TerminalReportDb) throw new Error('TerminalReportDb not available');
        const reports = buildBatchReports(input);
        const batchId = await window.TerminalReportDb.saveBatch({
            academyName: input.academyName,
            academicYear: input.academicYear,
            academicTerm: input.academicTerm,
            className: input.className,
            // Iteration 28 (DUP-01): the wizard's separate `term` input was
            // removed as a duplicate of academicTerm. The legacy batches.term
            // column (NOT NULL, pre-Iteration-21 schema) is kept populated
            // from the authoritative academicTerm, no schema migration.
            term: input.academicTerm || '1st',
            studentCount: input.students.length,
            subjectCount: input.subjects.length,
            certificatePrefix: (input.certificatePrefix || '').trim(),
            reports: reports
        });
        return { batchId: batchId, reportCount: reports.length, reports: reports };
    }

    // ------------------------------------------------------------------
    // Export
    // ------------------------------------------------------------------
    window.TerminalReportBatch = {
        computeSummary: computeSummary,
        rankStudents: rankStudents,
        rankBySubject: rankBySubject,
        generateCertNos: generateCertNos,
        buildBatchReports: buildBatchReports,
        generateAndSave: generateAndSave,
        checkExistingBatch: checkExistingBatch,
        normalizeScale: normalizeScale,
        // Exposed for testing
        _getGrade: getGrade,
        _getGradeClass: getGradeClass,
        _DEFAULT_GRADE_THRESHOLDS: DEFAULT_GRADE_THRESHOLDS
    };
})();
