/**
 * TerminalReport: batch wizard UI controller (Phase D)
 *
 * 5-step wizard flow:
 *   Step 1: Basic Info (managed-class pre-fill [Roadmap #3], academic year,
 *           class, term, student count, subject count, total days,
 *           cert prefix, issue date)
 *   Step 2: Define Subjects (code, name, max, min, pass marks)
 *   Step 3: Enter Students (roll#, name, DOB, gender)
 *   Step 4: Enter Marks (grid: students × subjects, plus a per-student
 *           Teacher Remark column, moved here from Step 5 in Iteration 30)
 *   Step 5: Attendance (days present per student; Total Days lives in
 *           Step 1 since Iteration 30 because it is batch-wide)
 *   Generate → confirm "Reports already exist?" if needed → save in transaction → show preview
 *
 * Roadmap #3 (Iter 9): Step 1 has a "Pre-fill from Managed Class" dropdown
 * fed by the Phase E `classes`/`students`/`subjects` tables. Selecting a class
 * auto-fills the year/class-name/counts, resolves the class's grading scale,
 * and pre-fills Steps 2 + 3 on the first Next (manual edits are preserved when
 * navigating back and forth). Manual entry remains fully supported.
 *
 * Roadmap #4 (Iter 10): the batch preview toolbar has a PDF Template selector
 * (primary / grayscale / no-logo; the same options as the main form). The chosen
 * template is applied to every report in Print All AND print-one, and to the
 * report shown in the detail modal (live re-template on selector change), so
 * what the teacher previews is exactly what prints.
 *
 * Public API (window.TerminalReportBatchUI):
 *   start()              → opens the wizard overlay
 *   showBatchPreview(batchId) → opens the preview for a saved batch
 */
(function () {
    'use strict';

    const $ = (id) => document.getElementById(id);
    // Iteration 28 (DLG-01): shared in-app dialog (replaces native alert/confirm)
    const UI = window.TerminalReportUI;

    // Wizard state (in-memory only, reset on close)
    let state = freshState();

    function freshState() {
        return {
            academyName: '',
            academicYear: '',
            academicTerm: '1st',
            // Iteration 28 (DUP-01): the parallel `term` field was removed,
            // it duplicated academicTerm (different defaults, never read).
            // The legacy batches.term DB column is now filled from
            // academicTerm in batch.js generateAndSave().
            className: '',
            studentCount: 5,
            subjectCount: 5,
            // Iteration 30: total school days in the term, entered once in
            // Basic Info and shared by every student in the batch (moved out
            // of the per-student attendance table).
            totalDays: '',
            certificatePrefix: '',
            issueDate: new Date().toISOString().split('T')[0],
            subjects: [],   // [{code, name, max, min}]
            students: [],   // [{surname, firstName, name, dob, gender, photoBytes?}]
            marks: {},      // { studentIndex: { subjectIndex: number } }
            // Iteration 30: attendance now holds daysPresent and remark only;
            // the remark is edited in the Step 4 marks grid, daysPresent in
            // Step 5. totalDays moved to the batch-level state field above.
            attendance: {}, // { studentIndex: { daysPresent, remark } }
            // Roadmap #3: Phase E pre-fill:
            // selected managed class id (null = manual entry), the loaded
            // entities snapshot, whether the snapshot has been applied to
            // subjects/students yet, and the class's grading scale.
            managedClassId: null,
            managedClass: null,   // { id, name, yearLabel, subjects: [], students: [], marks: [] }, with marks added in Iter 14
            managedApplied: false,
            gradingScale: null,   // DB-format scale passed to TerminalReportBatch
            // Iter 14: count of marks pre-filled from subject_marks via
            // applyManagedPrefill. Reset to 0 on every wizard reset. Used by
            // renderStep4() to show a "Pre-filled N marks from Admin UI" hint.
            marksPreFilledCount: 0
        };
    }

    // ------------------------------------------------------------------
    // Overlay show/hide
    // ------------------------------------------------------------------
    function openWizard() {
        state = freshState();
        // Pre-fill academy name from TerminalReportAuth
        if (window.TerminalReportAuth) {
            const info = window.TerminalReportAuth.getSchoolInfo();
            if (info) {
                state.academyName = info.name || '';
                // Pull logo bytes for embedding in reports
                state.schoolLogoBytes = info.logoBytes || null;
            }
        }
        renderStep(1);
        const overlay = $('batchWizard');
        // Iteration 32 (SCROLL-01): the .auth-overlay is the scroll container;
        // without this reset, reopening the wizard after viewing a long marks
        // grid lands mid-scroll on the new form.
        overlay.scrollTop = 0;
        overlay.style.display = 'flex';
        document.body.classList.add('auth-gating');
    }

    function closeWizard() {
        $('batchWizard').style.display = 'none';
        document.body.classList.remove('auth-gating');
    }

    // ------------------------------------------------------------------
    // Step rendering
    // ------------------------------------------------------------------
    function renderStep(stepNum) {
        // Update stepper UI
        document.querySelectorAll('.batch-step').forEach(function (s) {
            const n = parseInt(s.dataset.step, 10);
            s.classList.toggle('active', n === stepNum);
            s.classList.toggle('done', n < stepNum);
        });
        document.querySelectorAll('.batch-step-panel').forEach(function (p) {
            p.style.display = parseInt(p.dataset.stepPanel, 10) === stepNum ? 'block' : 'none';
        });
        // Render the panel content for this step
        switch (stepNum) {
            case 1: renderStep1(); break;
            case 2: renderStep2(); break;
            case 3: renderStep3(); break;
            case 4: renderStep4(); break;
            case 5: renderStep5(); break;
        }
    }

    // ------------------------------------------------------------------
    // Step 1: Basic Info
    // ------------------------------------------------------------------
    function renderStep1() {
        $('bwAcademyName').value = state.academyName;
        $('bwAcademicYear').value = state.academicYear;
        $('bwAcademicTerm').value = state.academicTerm;
        $('bwClassName').value = state.className;
        $('bwStudentCount').value = state.studentCount;
        $('bwSubjectCount').value = state.subjectCount;
        $('bwCertPrefix').value = state.certificatePrefix;
        $('bwIssueDate').value = state.issueDate;
        $('bwTotalDays').value = state.totalDays;
        // Roadmap #3: refresh the managed-class picker (data may have changed
        // in the Admin overlay since the wizard was last opened).
        const sel = $('bwManagedClass');
        if (sel) sel.value = state.managedClassId != null ? String(state.managedClassId) : '';
        populateManagedClassOptions();
        updateManagedHint();
    }

    // Roadmap #3: fill the managed-class dropdown from the Phase E tables.
    async function populateManagedClassOptions() {
        const sel = $('bwManagedClass');
        if (!sel || !window.TerminalReportDb) return;
        try {
            const classes = await window.TerminalReportDb.listClasses();
            if (!classes.length) {
                sel.innerHTML = '<option value="">No managed classes yet; set one up in Admin &amp; Manage</option>';
                sel.disabled = true;
                if (state.managedClassId != null) {
                    state.managedClassId = null;
                    state.managedClass = null;
                    state.managedApplied = false;
                    state.gradingScale = null;
                }
                updateManagedHint();
                return;
            }
            sel.disabled = false;
            const current = state.managedClassId != null ? String(state.managedClassId) : '';
            let html = '<option value="">Enter manually</option>';
            classes.forEach(function (c) {
                const label = c.name + ' · ' + (c.yearLabel || 'no year') +
                    ' (' + c.studentCount + ' students, ' + c.subjectCount + ' subjects)';
                html += '<option value="' + c.id + '">' + escapeHtml(label) + '</option>';
            });
            sel.innerHTML = html;
            // Preserve the selection only if that class still exists
            const exists = classes.some(function (c) { return String(c.id) === current; });
            sel.value = exists ? current : '';
            if (!exists && current) {
                state.managedClassId = null;
                state.managedClass = null;
                state.managedApplied = false;
                state.gradingScale = null;
            }
        } catch (e) {
            console.warn('[batch-ui] could not load managed classes:', e);
        }
    }

    // Roadmap #3: user picked (or cleared) a managed class on Step 1.
    async function handleManagedClassChange() {
        const sel = $('bwManagedClass');
        const raw = parseInt(sel.value, 10);
        const classId = Number.isFinite(raw) && raw > 0 ? raw : null;

        if (!classId) {
            // Cleared: keep whatever is in the basic-info fields and whatever
            // was already pre-filled; just drop the live linkage + custom scale.
            state.managedClassId = null;
            state.managedClass = null;
            state.gradingScale = null;
            state.managedApplied = false;
            updateManagedHint();
            return;
        }

        // Guard: loading a roster replaces anything typed into steps 2–5.
        const hasEnteredData =
            state.subjects.some(function (s) { return s && s.name; }) ||
            state.students.some(function (s) { return s && (s.surname || s.firstName || s.name); }) ||
            Object.keys(state.marks).length > 0;
        if (hasEnteredData) {
            const proceed = await UI.confirm(
                'Loading a managed class will replace the subjects, students, marks, ' +
                'and attendance already entered in this wizard.\n\nContinue?'
            );
            if (!proceed) {
                sel.value = state.managedClassId != null ? String(state.managedClassId) : '';
                return;
            }
        }

        try {
            const classes = await window.TerminalReportDb.listClasses();
            const cls = classes.find(function (c) { return c.id === classId; });
            if (!cls) throw new Error('Class no longer exists.');
            const loaded = await Promise.all([
                window.TerminalReportDb.listStudentsForClass(classId),
                window.TerminalReportDb.listSubjectsForClass(classId)
            ]);
            const students = orderStudentsForRoster(loaded[0]);
            const subjects = loaded[1];

            // Iter 14: also fetch any saved subject_marks for this class
            // in ONE query. Closes the loop with Iter 12's Admin UI "Enter
            // Marks" modal: marks the teacher already entered are pre-filled
            // into Step 4's marks grid. Fetched here (async) and stored on
            // state.managedClass.marks; applyManagedPrefill() (sync, runs
            // when navigating past Step 1) maps them into state.marks.
            let marksRows = [];
            try {
                marksRows = await window.TerminalReportDb.listSubjectMarksForClass(classId);
            } catch (e) {
                // Non-blocking, if subject_marks fetch fails (e.g., the
                // table doesn't exist on an old DB), the wizard still works
                // with an empty marks grid. Logged to console for debugging.
                console.error('[batch-ui] listSubjectMarksForClass failed:', e);
                marksRows = [];
            }

            // Resolve the class's grading scale (custom, or the seeded default).
            let scale = null;
            if (cls.gradingScaleId) {
                scale = await window.TerminalReportDb.getGradingScale(cls.gradingScaleId);
            }
            if (!scale) scale = await window.TerminalReportDb.getDefaultGradingScale();

            // Iteration 32 (SEL-01): stale-selection guard. The loads above
            // await several DB reads; if the user re-picked another class (or
            // cleared back to "Enter manually") while they were in flight,
            // applying THIS request's snapshot now would desynchronise the
            // dropdown from the wizard state (dropdown shows one thing, the
            // generated batch uses another). Bail without touching state.
            if (sel.value !== String(classId)) return;

            state.managedClassId = classId;
            state.managedClass = {
                id: cls.id,
                name: cls.name,
                yearLabel: cls.yearLabel || '',
                subjects: subjects,
                students: students,
                marks: marksRows   // Iter 14: array of {subjectId, studentId, obtainedMarks, isAbsent}
            };
            state.managedApplied = false;
            state.gradingScale = scale;

            // Auto-fill the Step 1 fields from the managed entities.
            if (cls.yearLabel) $('bwAcademicYear').value = cls.yearLabel;
            $('bwClassName').value = cls.name;
            if (students.length > 0) $('bwStudentCount').value = students.length;
            if (subjects.length > 0) $('bwSubjectCount').value = subjects.length;

            // The roster is about to change, so wipe downstream step data.
            state.subjects = [];
            state.students = [];
            state.marks = {};
            state.attendance = {};
            updateManagedHint();
        } catch (e) {
            UI.alert('Could not load managed class: ' + (e.message || e));
            // Iteration 32 (SEL-01): only reset the linkage if this request is
            // still the current selection; a newer pick owns the state now.
            if (sel.value === String(classId)) {
                state.managedClassId = null;
                state.managedClass = null;
                state.managedApplied = false;
                state.gradingScale = null;
                sel.value = '';
            }
            updateManagedHint();
        }
    }

    // Prefer roll-number order when every student has a numeric roll number;
    // otherwise keep the DB's name-ascending order.
    // Iter 19: removed orderStudentsForRoster, students are now sorted by name (no class_position column).
    // Kept as a no-op for backwards compat in case any caller still references it.
    function orderStudentsForRoster(students) {
        return students;
    }

    // Roadmap #3: copy the managed entities into the wizard state, once per
    // selection (so going Back and re-Next preserves manual edits).
    // Iter 14: also pre-fills state.marks from any subject_marks the teacher
    // already saved via the Admin UI's "Enter Marks" modal (Iter 12).
    function applyManagedPrefill() {
        if (!state.managedClass || state.managedApplied) return;
        state.managedApplied = true;
        state.subjects = state.managedClass.subjects.map(function (s) {
            return {
                code: s.code || '',
                name: s.name || '',
                max: s.maxMarks != null ? Number(s.maxMarks) : 100,
                min: s.minMarks != null ? Number(s.minMarks) : 35
            };
        });
        state.students = state.managedClass.students.map(function (s) {
            return {
                surname: s.surname || '',
                firstName: s.firstName || '',
                name: s.name || '',
                dob: s.dob || '',
                gender: s.gender || ''
            };
        });
        state.marks = {};
        state.attendance = {};

        // Iter 14: pre-fill state.marks from saved subject_marks.
        // managedClass.marks is an array of {subjectId, studentId, obtainedMarks, isAbsent}.
        // We need to map each (subjectId, studentId) → (subjIdx, studIdx) in the
        // wizard's state.subjects/state.students arrays, then store at
        // state.marks[studIdx][subjIdx] = obtainedMarks.
        //
        // Mapping uses the .id field on the managed subjects/students (still
        // present on the source objects from listSubjectsForClass/listStudentsForClass).
        // We build two lookup tables for O(1) access, then iterate the marks rows.
        if (state.managedClass.marks && state.managedClass.marks.length) {
            // Build { subjectId → subjIdx } and { studentId → studIdx } maps.
            // state.subjects is a freshly-built array of plain objects WITHOUT
            // ids (we copied only code/name/max/min above), so we look up via
            // the original managedClass.subjects which has .id.
            const subjIdToIdx = {};
            state.managedClass.subjects.forEach(function (s, i) {
                if (s.id != null) subjIdToIdx[s.id] = i;
            });
            const studIdToIdx = {};
            state.managedClass.students.forEach(function (s, i) {
                if (s.id != null) studIdToIdx[s.id] = i;
            });

            let preFilledCount = 0;
            state.managedClass.marks.forEach(function (m) {
                const subjIdx = subjIdToIdx[m.subjectId];
                const studIdx = studIdToIdx[m.studentId];
                // Skip rows whose subject or student isn't in the wizard's
                // current roster (e.g., the teacher deleted a row in Step 2
                // or 3 before navigating to Step 4).
                if (subjIdx == null || studIdx == null) return;
                if (!state.marks[studIdx]) state.marks[studIdx] = {};
                // Absent students contribute 0 to totals (matches batch.js
                // behaviour). The mark is still stored so the cell renders
                // the value rather than the placeholder.
                state.marks[studIdx][subjIdx] = Number(m.obtainedMarks) || 0;
                preFilledCount++;
            });
            // Stash the count for the Step 4 hint to display.
            state.marksPreFilledCount = preFilledCount;
        } else {
            state.marksPreFilledCount = 0;
        }
    }

    // Small status line under the managed-class dropdown.
    function updateManagedHint() {
        const hint = $('bwManagedHint');
        if (!hint) return;
        if (state.managedClass) {
            const mc = state.managedClass;
            hint.textContent = 'Loaded ' + mc.students.length + ' student(s) and ' +
                mc.subjects.length + ' subject(s) from "' + mc.name + '"' +
                (mc.yearLabel ? ' · ' + mc.yearLabel : '') +
                '. Steps 2 and 3 will be pre-filled; edit anything you like.';
        } else {
            hint.textContent = 'Pick a class set up in Admin & Manage to auto-fill the academic year, class name, subjects, students, and grading scale below.';
        }
    }

    function readStep1() {
        const name = $('bwAcademyName').value.trim();
        const year = $('bwAcademicYear').value.trim();
        const className = $('bwClassName').value.trim();
        if (!name) { UI.alert('Academy name is required.'); return false; }
        if (!year) { UI.alert('Academic year is required.'); return false; }
        if (!className) { UI.alert('Class name is required.'); return false; }
        const studentCount = parseInt($('bwStudentCount').value, 10);
        const subjectCount = parseInt($('bwSubjectCount').value, 10);
        if (!Number.isFinite(studentCount) || studentCount < 1 || studentCount > 200) {
            UI.alert('Student count must be between 1 and 200.'); return false;
        }
        if (!Number.isFinite(subjectCount) || subjectCount < 1 || subjectCount > 30) {
            UI.alert('Subject count must be between 1 and 30.'); return false;
        }
        state.academyName = name;
        state.academicYear = year;
        state.academicTerm = $('bwAcademicTerm').value;
        state.className = className;
        // Iteration 28 (DUP-01): `state.term` removed, duplicate of
        // academicTerm ('Which Term' field deleted from the form).
        state.studentCount = studentCount;
        state.subjectCount = subjectCount;
        state.certificatePrefix = $('bwCertPrefix').value.trim();
        state.issueDate = $('bwIssueDate').value || new Date().toISOString().split('T')[0];
        // Iteration 30: batch-level Total Days (optional, blank counts as 0).
        const totalDays = parseInt($('bwTotalDays').value, 10);
        if (Number.isFinite(totalDays) && totalDays < 0) {
            UI.alert('Total days cannot be negative.'); return false;
        }
        state.totalDays = Number.isFinite(totalDays) ? totalDays : 0;
        return true;
    }

    // ------------------------------------------------------------------
    // Step 2: Subjects
    // ------------------------------------------------------------------
    function renderStep2() {
        // Initialise subjects array if empty
        if (state.subjects.length !== state.subjectCount) {
            // Preserve existing if shrinking/growing
            const newArr = [];
            for (let i = 0; i < state.subjectCount; i++) {
                newArr.push(state.subjects[i] || { code: '', name: '', max: 100, min: 35 });
            }
            state.subjects = newArr;
        }
        const hint = $('bwSubjectsHint');
        if (hint) {
            hint.textContent = (state.managedClass && state.managedClass.subjects.length)
                ? 'Pre-filled ' + state.managedClass.subjects.length + ' subject(s) from managed class "' +
                    state.managedClass.name + '". Edit as needed.'
                : 'Define the subjects for this class.';
        }
        const tbody = $('bwSubjectsBody');
        tbody.innerHTML = state.subjects.map(function (s, i) {
            return '<tr>' +
                '<td>' + (i + 1) + '</td>' +
                '<td><input type="text" class="form-control form-control-sm" data-subj-idx="' + i + '" data-field="code" value="' + escapeAttr(s.code) + '" placeholder="Optional"></td>' +
                '<td><input type="text" class="form-control form-control-sm" data-subj-idx="' + i + '" data-field="name" value="' + escapeAttr(s.name) + '" placeholder="e.g., Mathematics"></td>' +
                '<td><input type="number" class="form-control form-control-sm" data-subj-idx="' + i + '" data-field="max" value="' + s.max + '" min="1"></td>' +
                '<td><input type="number" class="form-control form-control-sm" data-subj-idx="' + i + '" data-field="min" value="' + s.min + '" min="0"></td>' +
            '</tr>';
        }).join('');
    }

    function readStep2() {
        const inputs = document.querySelectorAll('#bwSubjectsBody input[data-subj-idx]');
        const seen = {};
        let valid = true;
        let firstError = '';
        inputs.forEach(function (inp) {
            const idx = parseInt(inp.dataset.subjIdx, 10);
            const field = inp.dataset.field;
            if (!state.subjects[idx]) state.subjects[idx] = { code: '', name: '', max: 100, min: 35 };
            const val = inp.value.trim();
            if (field === 'code') {
                state.subjects[idx].code = val;
            } else if (field === 'name') {
                if (!val) { valid = false; if (!firstError) firstError = 'Subject ' + (idx + 1) + ': name is required.'; inp.classList.add('is-invalid'); }
                else { inp.classList.remove('is-invalid'); }
                if (seen[val.toLowerCase()]) { valid = false; if (!firstError) firstError = 'Subject "' + val + '" is duplicated.'; inp.classList.add('is-invalid'); }
                seen[val.toLowerCase()] = true;
                state.subjects[idx].name = val;
            } else if (field === 'max') {
                const n = parseInt(val, 10);
                if (!Number.isFinite(n) || n <= 0) { valid = false; if (!firstError) firstError = 'Subject ' + (idx + 1) + ': max marks must be > 0.'; inp.classList.add('is-invalid'); }
                else { inp.classList.remove('is-invalid'); }
                state.subjects[idx].max = Number.isFinite(n) ? n : 100;
            } else if (field === 'min') {
                const n = parseInt(val, 10);
                if (!Number.isFinite(n) || n < 0) { valid = false; if (!firstError) firstError = 'Subject ' + (idx + 1) + ': pass marks cannot be negative.'; inp.classList.add('is-invalid'); }
                else if (n > state.subjects[idx].max) { valid = false; if (!firstError) firstError = 'Subject ' + (idx + 1) + ': pass marks cannot exceed max.'; inp.classList.add('is-invalid'); }
                else { inp.classList.remove('is-invalid'); }
                state.subjects[idx].min = Number.isFinite(n) ? n : 35;
            }
        });
        if (!valid) { UI.alert(firstError); return false; }
        return true;
    }

    // ------------------------------------------------------------------
    // Step 3: Students (Iter 13: added Photo column for roadmap #9)
    //
    // Photo handling:
    //   - Each row has a hidden <input type="file" accept="image/*">
    //   - Clicking the thumbnail/placeholder label opens the picker
    //   - On change: read as bytes, resize to 100×120 PNG via canvas (same
    //     technique as the school logo in auth-ui.js), store in state.students[idx].photoBytes
    //   - The thumbnail <img> shows a live preview via base64 data URL
    //   - bytes are passed through batch.js → db.saveBatch → reports.photo_blob
    // ------------------------------------------------------------------

    /** Resize an image File to 100×120 PNG bytes (matches .student-photo CSS). */
    function resizeImageToBytes(file, width, height) {
        return new Promise(function (resolve, reject) {
            if (!file || !file.type || !file.type.startsWith('image/')) {
                reject(new Error('File is not an image'));
                return;
            }
            const reader = new FileReader();
            reader.onload = function () {
                const img = new Image();
                img.onload = function () {
                    const canvas = document.createElement('canvas');
                    canvas.width = width;
                    canvas.height = height;
                    const ctx = canvas.getContext('2d');
                    // White background so transparent PNGs don't render as black
                    ctx.fillStyle = '#ffffff';
                    ctx.fillRect(0, 0, width, height);
                    // Contain (preserve aspect ratio, fit inside WxH)
                    const scale = Math.min(width / img.width, height / img.height);
                    const w = img.width * scale;
                    const h = img.height * scale;
                    const x = (width - w) / 2;
                    const y = (height - h) / 2;
                    ctx.drawImage(img, x, y, w, h);
                    canvas.toBlob(function (blob) {
                        if (!blob) { reject(new Error('Canvas toBlob failed')); return; }
                        blob.arrayBuffer().then(function (buf) {
                            resolve(new Uint8Array(buf));
                        });
                    }, 'image/png');
                };
                img.onerror = function () { reject(new Error('Image load failed')); };
                img.src = reader.result;
            };
            reader.onerror = function () { reject(new Error('FileReader failed')); };
            reader.readAsDataURL(file);
        });
    }

    function renderStep3() {
        if (state.students.length !== state.studentCount) {
            const newArr = [];
            for (let i = 0; i < state.studentCount; i++) {
                newArr.push(state.students[i] || { surname: '', firstName: '', name: '', dob: '', gender: '', photoBytes: null });
            }
            state.students = newArr;
        }
        const hint = $('bwStudentsHint');
        if (hint) {
            hint.textContent = (state.managedClass && state.managedClass.students.length)
                ? 'Pre-filled ' + state.managedClass.students.length + ' student(s) from managed class "' +
                    state.managedClass.name + '". Edit as needed.'
                : 'Enter student details.';
        }
        const tbody = $('bwStudentsBody');
        tbody.innerHTML = state.students.map(function (s, i) {
            // Iter 13 (roadmap #9): Photo cell with live preview.
            // Label wraps both the placeholder thumb AND the hidden file input,
            // so clicking either opens the picker (no JS needed for the click).
            // The <img> preview is updated on change by the handler in init().
            const photoThumbSrc = s.photoBytes
                ? 'data:image/png;base64,' + bytesToBase64(s.photoBytes)
                : '';
            const photoThumbHTML = photoThumbSrc
                ? '<img src="' + photoThumbSrc + '" alt="" class="bw-photo-thumb-img">'
                : '<i class="fas fa-user fa-2x text-muted"></i>';
            return '<tr>' +
                '<td>' + (i + 1) + '</td>' +
                '<td><input type="text" class="form-control form-control-sm" data-stud-idx="' + i + '" data-field="surname" value="' + escapeAttr(s.surname || s.name || '') + '" placeholder="Surname"></td>' +
                '<td><input type="text" class="form-control form-control-sm" data-stud-idx="' + i + '" data-field="firstName" value="' + escapeAttr(s.firstName || '') + '" placeholder="First name"></td>' +
                '<td><input type="date" class="form-control form-control-sm" data-stud-idx="' + i + '" data-field="dob" value="' + escapeAttr(s.dob) + '"></td>' +
                '<td>' +
                    '<select class="form-select form-select-sm" data-stud-idx="' + i + '" data-field="gender">' +
                        '<option value=""' + (s.gender === '' ? ' selected' : '') + '>-</option>' +
                        '<option value="Male"' + (s.gender === 'Male' ? ' selected' : '') + '>Male</option>' +
                        '<option value="Female"' + (s.gender === 'Female' ? ' selected' : '') + '>Female</option>' +
                    '</select>' +
                '</td>' +
                '<td class="bw-photo-cell">' +
                    '<label class="bw-photo-label">' +
                        '<div class="bw-photo-thumb" data-stud-idx="' + i + '">' + photoThumbHTML + '</div>' +
                        '<input type="file" accept="image/*" data-stud-idx="' + i + '" data-field="photo" style="display:none;">' +
                    '</label>' +
                    (s.photoBytes
                        ? '<button type="button" class="btn btn-sm btn-link text-danger p-0 bw-photo-clear" data-stud-idx="' + i + '" title="Remove photo"><i class="fas fa-xmark"></i></button>'
                        : '') +
                '</td>' +
            '</tr>';
        }).join('');
    }

    /** Tiny base64 encoder for previewing the resized photo thumbnail. */
    function bytesToBase64(bytes) {
        let binary = '';
        const len = bytes.length;
        // Chunk in 8KB to avoid call-stack overflow on very long arrays
        const chunk = 8192;
        for (let i = 0; i < len; i += chunk) {
            binary += String.fromCharCode.apply(null, bytes.subarray(i, Math.min(i + chunk, len)));
        }
        return btoa(binary);
    }

    /**
     * Iter 13 (roadmap #9): handle photo file change for a student row.
     * Reads the file, resizes to 100×120 PNG, stores bytes in state, updates
     * the thumbnail preview.
     */
    async function handleStudentPhotoChange(fileInput) {
        const idx = parseInt(fileInput.dataset.studIdx, 10);
        if (!fileInput.files || !fileInput.files.length) return;
        if (!state.students[idx]) state.students[idx] = { surname: '', firstName: '', name: '', dob: '', gender: '' };
        try {
            const bytes = await resizeImageToBytes(fileInput.files[0], 100, 120);
            state.students[idx].photoBytes = bytes;
            // Update the thumbnail preview
            const thumb = document.querySelector('.bw-photo-thumb[data-stud-idx="' + idx + '"]');
            if (thumb) {
                thumb.innerHTML = '<img src="data:image/png;base64,' + bytesToBase64(bytes) + '" alt="" class="bw-photo-thumb-img">';
            }
            // Show a clear button next to it
            const cell = fileInput.closest('.bw-photo-cell');
            if (cell && !cell.querySelector('.bw-photo-clear')) {
                const clearBtn = document.createElement('button');
                clearBtn.type = 'button';
                clearBtn.className = 'btn btn-sm btn-link text-danger p-0 bw-photo-clear';
                clearBtn.title = 'Remove photo';
                clearBtn.setAttribute('data-stud-idx', idx);
                clearBtn.innerHTML = '<i class="fas fa-xmark"></i>';
                cell.appendChild(clearBtn);
            }
        } catch (e) {
            console.error('[batch-ui] photo resize failed:', e);
            UI.alert('Could not load that image. Please try a different file (PNG, JPG, or GIF).');
        }
        // Reset the file input so the same file can be re-selected later if needed
        fileInput.value = '';
    }

    /** Iter 13 (roadmap #9): clear the photo for a student row. */
    function handleStudentPhotoClear(idx) {
        if (!state.students[idx]) return;
        state.students[idx].photoBytes = null;
        const thumb = document.querySelector('.bw-photo-thumb[data-stud-idx="' + idx + '"]');
        if (thumb) {
            thumb.innerHTML = '<i class="fas fa-user fa-2x text-muted"></i>';
        }
        const clearBtn = document.querySelector('.bw-photo-clear[data-stud-idx="' + idx + '"]');
        if (clearBtn) clearBtn.remove();
    }

    function readStep3() {
        // Iter 13 (roadmap #9): exclude photo file inputs, they don't have a
        // string value we can `.trim()`, and their bytes are already in state
        // via the change handler `handleStudentPhotoChange`. The attribute
        // selector `[data-field!="photo"]` is jQuery-style and not valid CSS,
        // so we filter in JS instead.
        const allInputs = document.querySelectorAll('#bwStudentsBody input[data-stud-idx], #bwStudentsBody select[data-stud-idx]');
        const inputs = Array.prototype.filter.call(allInputs, function (el) {
            return el.dataset.field !== 'photo';
        });
        let valid = true;
        let firstError = '';
        const seenNames = {};
        inputs.forEach(function (inp) {
            const idx = parseInt(inp.dataset.studIdx, 10);
            const field = inp.dataset.field;
            if (!state.students[idx]) state.students[idx] = { surname: '', firstName: '', name: '', dob: '', gender: '' };
            const val = inp.value.trim();
            if (field === 'surname' || field === 'firstName') {
                state.students[idx][field] = val;
                state.students[idx].name = ((state.students[idx].surname || '') + ' ' + (state.students[idx].firstName || '')).trim();
                if (field === 'firstName' && !val && !state.students[idx].surname) {
                    valid = false; if (!firstError) firstError = 'Student ' + (idx + 1) + ': surname or first name is required.'; inp.classList.add('is-invalid');
                } else { inp.classList.remove('is-invalid'); }
            } else {
                state.students[idx][field] = val;
            }
        });
        if (!valid) { UI.alert(firstError); return false; }
        return true;
    }

    // ------------------------------------------------------------------
    // Step 4: Marks grid (Iter 14: shows pre-fill hint from subject_marks)
    // ------------------------------------------------------------------
    function renderStep4() {
        const subjects = state.subjects;
        const students = state.students;
        // Iter 14: show a hint when marks were pre-filled from the Admin UI's
        // "Enter Marks" modal (Iter 12) via the managed-class pre-fill (Iter 14).
        const hintEl = $('bwMarksHint');
        if (hintEl) {
            if (state.marksPreFilledCount > 0) {
                hintEl.innerHTML = '<i class="fas fa-circle-info"></i> Pre-filled ' +
                    state.marksPreFilledCount + ' mark' + (state.marksPreFilledCount === 1 ? '' : 's') +
                    ' from Admin UI "Enter Marks"; edit any cell to override.';
                hintEl.style.display = 'block';
            } else {
                hintEl.style.display = 'none';
                hintEl.textContent = '';
            }
        }
        // Iter 14: fix pre-existing bug from Iter 6: the original code wrote
        // both <thead> and <tbody> content into #bwMarksGrid (which is the
        // <tbody> element), leaving #bwMarksHead (the <thead>) empty. The
        // browser still rendered it correctly because it's lenient about
        // misplaced table content, but the DOM structure was wrong (any
        // querySelector('#bwMarksHead th') returned []). Split the write into
        // the two proper elements.
        let headHtml = '<tr>' +
            '<th class="marks-grid-frozen">#</th>' +
            '<th class="marks-grid-frozen-name">Student</th>';
        subjects.forEach(function (s) {
            headHtml += '<th title="' + escapeAttr(s.name) + '">' + escapeHtml(s.name) + '<br><small class="text-muted">/' + s.max + '</small></th>';
        });
        // Iteration 30: per-student Teacher Remark column (moved from Step 5).
        headHtml += '<th class="marks-grid-remark">Teacher Remark</th>';
        headHtml += '</tr>';
        $('bwMarksHead').innerHTML = headHtml;

        let bodyHtml = '';
        students.forEach(function (stud, studIdx) {
            const att = state.attendance[studIdx] || {};
            bodyHtml += '<tr>' +
                '<td class="marks-grid-frozen">' + (studIdx + 1) + '</td>' +
                '<td class="marks-grid-frozen-name">' + escapeHtml(((stud.surname || '') + ' ' + (stud.firstName || '')).trim() || stud.name || ('Student ' + (studIdx + 1))) + '</td>';
            subjects.forEach(function (_, subjIdx) {
                const val = (state.marks[studIdx] && state.marks[studIdx][subjIdx] != null) ? state.marks[studIdx][subjIdx] : '';
                bodyHtml += '<td><input type="number" class="form-control form-control-sm marks-cell" ' +
                    'data-stud-idx="' + studIdx + '" data-subj-idx="' + subjIdx + '" ' +
                    'value="' + val + '" min="0" max="' + state.subjects[subjIdx].max + '" ' +
                    'placeholder="-"></td>';
            });
            bodyHtml += '<td><input type="text" class="form-control form-control-sm marks-remark-cell" ' +
                'data-stud-idx="' + studIdx + '" data-field="remark" ' +
                'value="' + escapeAttr(att.remark || '') + '" ' +
                'placeholder="e.g., Good improvement"></td>';
            bodyHtml += '</tr>';
        });
        $('bwMarksGrid').innerHTML = bodyHtml;
    }

    function readStep4() {
        const cells = document.querySelectorAll('.marks-cell');
        let valid = true;
        let firstError = '';
        cells.forEach(function (cell) {
            const studIdx = parseInt(cell.dataset.studIdx, 10);
            const subjIdx = parseInt(cell.dataset.subjIdx, 10);
            const val = cell.value.trim();
            if (!state.marks[studIdx]) state.marks[studIdx] = {};
            if (val === '') {
                // Iter 21 fix (CRIT-10): empty cells default to 0 (same as before),
                // but we add a visual hint, the placeholder shows "−" which signals
                // "not entered". The teacher should explicitly enter 0 if they mean 0.
                // We keep the 0-default behaviour for backwards compatibility, but
                // mark the cell with a subtle outline so the teacher can see which
                // cells were left empty vs explicitly entered.
                state.marks[studIdx][subjIdx] = 0;
                cell.classList.remove('is-invalid');
                // Iter 21: add a visual indicator for empty cells (not an error,
                // just a reminder). CSS class .marks-cell-empty styles this.
                cell.classList.add('marks-cell-empty');
                return;
            }
            // Iter 21: cell has a value, remove the empty indicator
            cell.classList.remove('marks-cell-empty');
            const n = parseFloat(val);
            const max = state.subjects[subjIdx].max;
            if (!Number.isFinite(n) || n < 0) {
                valid = false;
                if (!firstError) firstError = 'Invalid marks at row ' + (studIdx + 1) + ', subject ' + (subjIdx + 1) + '.';
                cell.classList.add('is-invalid');
            } else if (n > max) {
                valid = false;
                if (!firstError) firstError = 'Marks exceed max at row ' + (studIdx + 1) + ', subject ' + (subjIdx + 1) + ' (max: ' + max + ').';
                cell.classList.add('is-invalid');
            } else {
                cell.classList.remove('is-invalid');
            }
            state.marks[studIdx][subjIdx] = Number.isFinite(n) ? n : 0;
        });
        // Iteration 30: the remark inputs ride on the same grid (free text,
        // no validation) and are stored in the same attendance slots the
        // generator reads, so the data shape is unchanged.
        const remarkInputs = document.querySelectorAll('#bwMarksGrid input[data-field="remark"]');
        remarkInputs.forEach(function (inp) {
            const studIdx = parseInt(inp.dataset.studIdx, 10);
            if (!state.attendance[studIdx]) state.attendance[studIdx] = { daysPresent: 0, remark: '' };
            state.attendance[studIdx].remark = inp.value.trim();
        });
        if (!valid) { UI.alert(firstError); return false; }
        return true;
    }

    // ------------------------------------------------------------------
    // Step 5: Attendance (Iteration 30: days present only; Total Days lives
    // in Step 1 and the remark is collected in the Step 4 marks grid)
    // ------------------------------------------------------------------
    function renderStep5() {
        const tbody = $('bwAttendanceBody');
        tbody.innerHTML = state.students.map(function (stud, i) {
            const att = state.attendance[i] || { daysPresent: '' };
            return '<tr>' +
                '<td>' + (i + 1) + '</td>' +
                '<td>' + escapeHtml(((stud.surname || '') + ' ' + (stud.firstName || '')).trim() || stud.name || ('Student ' + (i + 1))) + '</td>' +
                '<td><input type="number" class="form-control form-control-sm" data-att-idx="' + i + '" data-field="daysPresent" value="' + (att.daysPresent != null ? att.daysPresent : '') + '" min="0" placeholder="0"></td>' +
            '</tr>';
        }).join('');
    }

    function readStep5() {
        const inputs = document.querySelectorAll('#bwAttendanceBody input[data-att-idx]');
        let valid = true;
        let firstError = '';
        inputs.forEach(function (inp) {
            const idx = parseInt(inp.dataset.attIdx, 10);
            const field = inp.dataset.field;
            if (!state.attendance[idx]) state.attendance[idx] = { daysPresent: 0, remark: '' };
            const val = inp.value.trim();
            if (field === 'daysPresent') {
                // Iter 31 audit fix (VAL-01): reject negative and non-integer
                // values. Previously only the HTML min="0" guarded the
                // spinner, so a typed "-5" was stored verbatim and a typed
                // "12.5" was silently truncated to 12 by parseInt; negative
                // days then flowed into the saved summary unvalidated.
                const n = parseFloat(val);
                if (val !== '' && (!Number.isFinite(n) || n < 0 || n % 1 !== 0)) {
                    valid = false;
                    if (!firstError) firstError = 'Row ' + (idx + 1) + ': days present must be a whole number of 0 or more.';
                    inp.classList.add('is-invalid');
                    state.attendance[idx].daysPresent = 0;
                    return;
                }
                state.attendance[idx].daysPresent = val === '' ? 0 : n;
                // Iteration 30: compare against the batch-level Total Days
                // from Step 1. The check is skipped when no total was given
                // (0), so attendance can still be recorded without it.
                if (state.totalDays > 0 && state.attendance[idx].daysPresent > state.totalDays) {
                    valid = false;
                    if (!firstError) firstError = 'Row ' + (idx + 1) + ': days present cannot exceed the total of ' + state.totalDays + ' days.';
                    inp.classList.add('is-invalid');
                } else {
                    inp.classList.remove('is-invalid');
                }
            }
        });
        if (!valid) { UI.alert(firstError); return false; }
        return true;
    }

    // ------------------------------------------------------------------
    // Generate
    // ------------------------------------------------------------------
    // Iter 31 audit fix (RACE-01): re-entrancy guard. The button used to be
    // disabled only AFTER two awaits (the existing-batch check + the replace
    // confirm), leaving a window where a double-click ran handleGenerate
    // twice: two queued confirm dialogs and, worst case, two concurrent
    // saveBatch transactions. The guard is checked and set synchronously on
    // every entry, and the button is disabled for the whole flow (including
    // the confirm), re-enabled in finally on every exit path.
    let generating = false;
    async function handleGenerate() {
        if (generating) return;
        generating = true;
        const btn = $('bwGenerate');
        const orig = btn.innerHTML;
        btn.disabled = true;
        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Generating...';
        try {
            if (!readStep5()) return;
            // Check for existing batch
            try {
                const check = await window.TerminalReportBatch.checkExistingBatch(
                    state.academicYear, state.className, state.academicTerm
                );
                if (check.exists) {
                    const proceed = await UI.confirm(
                        'Reports already exist for ' + state.className + ' / ' + state.academicYear + ' / ' + state.academicTerm + ' Term.\n\n' +
                        'Do you want to regenerate and replace them?\n\n' +
                        'Click OK to replace, Cancel to abort.'
                    );
                    if (!proceed) return;
                }
            } catch (e) {
                console.error('[batch-ui] checkExistingBatch failed:', e);
            }

            // Pull latest school logo bytes
            if (window.TerminalReportAuth) {
                const info = window.TerminalReportAuth.getSchoolInfo();
                if (info) state.schoolLogoBytes = info.logoBytes || null;
            }
            const result = await window.TerminalReportBatch.generateAndSave(state);
            // Close wizard + show preview
            closeWizard();
            // Iteration 32 (ERR-03): a preview failure after a successful save
            // used to surface as "Generation failed", which is untrue (the
            // batch IS saved) and sent users looking for a problem in their
            // marks. Report the two facts separately.
            try {
                await showBatchPreview(result.batchId);
            } catch (previewErr) {
                console.error('[batch-ui] preview after generate failed:', previewErr);
                UI.alert('The reports were saved successfully, but the preview could not be opened: ' +
                    (previewErr.message || previewErr) +
                    '. You can open them any time from Saved Reports.');
            }
        } catch (e) {
            UI.alert('Generation failed: ' + (e.message || e));
            console.error('[batch-ui] generate failed:', e);
        } finally {
            generating = false;
            btn.disabled = false;
            btn.innerHTML = orig;
        }
    }

    // ------------------------------------------------------------------
    // Batch preview (list + per-student view + print all)
    // ------------------------------------------------------------------
    async function showBatchPreview(batchId) {
        if (!window.TerminalReportDb) return;
        const batch = (await window.TerminalReportDb.listBatches()).find(function (b) { return b.id === batchId; });
        const reports = await window.TerminalReportDb.listReportsForBatch(batchId);
        if (!batch || !reports.length) {
            UI.alert('No reports found.');
            return;
        }
        // Render the preview overlay
        renderBatchPreview(batch, reports);
        const overlay = $('batchPreview');
        // Iteration 32 (SCROLL-01): reset scroll so a long report list from a
        // previous batch never carries over into this one.
        overlay.scrollTop = 0;
        overlay.style.display = 'flex';
        document.body.classList.add('auth-gating');
    }

    function renderBatchPreview(batch, reports) {
        $('bpBatchTitle').textContent = batch.className + ' · ' + batch.academicYear + ' · ' + batch.academicTerm + ' Term · ' + reports.length + ' students';
        // Roadmap #4 (Iter 10): batch template selection.
        // BLIND-10 fix (Iter 24 audit): this code referenced a main-form
        // '#pdfTemplate' selector that does not exist anywhere in index.html
        // (stale comment, the only template selector is #bpTemplateSelector
        // in the preview toolbar itself). formSel was therefore ALWAYS null,
        // so every preview build force-reset the toolbar to 'primary' and
        // silently discarded a template the user had picked earlier. Now: the
        // toolbar is only normalised when its current value is invalid, a
        // valid user choice survives re-renders. <select> defaults to the
        // first option ('primary') on first open, so the initial value is
        // always valid and needs no explicit seeding.
        const bpSel = $('bpTemplateSelector');
        if (bpSel && TEMPLATE_IDS.indexOf(bpSel.value) === -1) bpSel.value = 'primary';
        // List
        $('bpReportList').innerHTML = reports.map(function (r, i) {
            return '<div class="batch-report-card" data-report-idx="' + i + '">' +
                '<div class="batch-report-rank">#' + (r.classRank || '-') + '</div>' +
                '<div class="batch-report-info">' +
                    '<div class="batch-report-name">' + escapeHtml(r.studentName) + '</div>' +
                    '<div class="batch-report-sub">' +
                        '<span class="grade-' + (r.summary.overallGrade || '').charAt(0).toLowerCase() + '">' + (r.summary.overallGrade || '-') + '</span>' +
                        ' · ' + r.summary.percentage + '% · ' +
                        (r.summary.passed ? '<span class="text-success">PASS</span>' : '<span class="text-danger">FAIL</span>') +
                        ' · Cert ' + escapeHtml(r.certificateNo) +
                    '</div>' +
                '</div>' +
                '<div class="batch-report-actions">' +
                    '<button type="button" class="btn btn-sm btn-outline-primary" data-action="view-report" data-idx="' + i + '"><i class="fas fa-eye"></i></button>' +
                    '<button type="button" class="btn btn-sm btn-outline-secondary" data-action="print-one" data-idx="' + i + '"><i class="fas fa-print"></i></button>' +
                '</div>' +
            '</div>';
        }).join('');
        // Stash reports for view/print actions
        window.__bpReports = reports;
        window.__bpBatch = batch;
    }

    function closeBatchPreview() {
        $('batchPreview').style.display = 'none';
        document.body.classList.remove('auth-gating');
        window.__bpReports = null;
        window.__bpBatch = null;
    }

    // Iteration 32 (KEY-01 + LEAK-01): lifecycle wiring for the read-only
    // report detail modal. Escape closes it, focus moves to the header close
    // button while it is open and returns to the triggering list button on
    // close, the overlay scroll resets on every open, and the blob URLs the
    // report card created are revoked when the modal closes (they pin the
    // logo/photo blobs in memory for as long as they exist).
    const detailModalCtl = UI.wireModal($('bpDetailModal'), {
        close: closeReportDetail,
        focusEl: function () { return $('bpDetailClose'); }
    });

    function viewReport(idx) {
        const reports = window.__bpReports || [];
        const r = reports[idx];
        if (!r) return;
        // Reuse the main script's report HTML generator via a custom event
        // Simpler: render inline in a modal-style popup
        // Roadmap #4 (Iter 10): render with the selected template so the
        // detail modal matches the Print All output (styles.css carries the
        // template-XXX variants for in-app rendering).
        const html = window.TerminalReportScript_renderReportHTML(r, r.summary);
        $('bpDetailBody').innerHTML = applyTemplateClassToCard(html, getSelectedTemplate());
        const overlay = $('bpDetailModal');
        overlay.style.display = 'flex';
        detailModalCtl.onOpen();
    }

    function closeReportDetail() {
        $('bpDetailModal').style.display = 'none';
        $('bpDetailBody').innerHTML = '';
        // Iteration 32 (LEAK-01): drop the object URLs this card created.
        if (window.TerminalReportScript_revokeReportObjectUrls) {
            window.TerminalReportScript_revokeReportObjectUrls();
        }
        detailModalCtl.onClose();
    }

    // ------------------------------------------------------------------
    // Roadmap #4 (Iter 10): PDF template selection for batch printing
    // ------------------------------------------------------------------
    // Same three template ids the single-report flow uses (Phase A).
    const TEMPLATE_IDS = ['primary', 'grayscale', 'nologo'];

    /** Read + validate the template chosen in the batch preview toolbar.
     *  BLIND-10 fix (Iter 24 audit): removed the dead fallback to the
     *  non-existent main-form #pdfTemplate selector, falls back to
     *  'primary' directly. */
    function getSelectedTemplate() {
        const sel = $('bpTemplateSelector');
        if (sel && TEMPLATE_IDS.indexOf(sel.value) !== -1) return sel.value;
        return 'primary';
    }

    /** Inject the template-XXX class onto the .terminalreport card markup
     *  produced by TerminalReportScript_renderReportHTML (its first element is
     *  always <div class="terminalreport ...">). The regex requires "terminalreport"
     *  to be followed by a space or the closing quote, so inner elements like
     *  terminalreport-header / terminalreport-logo can never match. Fail-safe:
     *  if the markup ever changes, the HTML is returned unchanged (primary look). */
    function applyTemplateClassToCard(html, template) {
        if (!html) return html;
        const t = (TEMPLATE_IDS.indexOf(template) !== -1) ? template : 'primary';
        return html.replace(
            /class="terminalreport( [^"]*)?"/,
            'class="terminalreport$1 template-' + t + '"'
        );
    }

    /** Re-template the report card currently shown in the detail modal
     *  (called when the toolbar selector changes with the modal open). */
    function retemplateDetailModal() {
        const card = document.querySelector('#bpDetailBody .terminalreport');
        if (!card) return;
        TEMPLATE_IDS.forEach(function (t) { card.classList.remove('template-' + t); });
        card.classList.add('template-' + getSelectedTemplate());
    }

    // CRIT-13 + BLIND-2 fix: previous implementation used setTimeout(300/600ms)
    // before calling w.print(), that races with both the <link> stylesheet
    // load AND <img> (logo/photo) decode. On a slow connection, the print
    // dialog could open before images loaded → blank image placeholders.
    // Also, the old `setTimeout(w.close, 500)` could fire WHILE the user was
    // still choosing print options in the print dialog, closing the window.
    //
    // New approach:
    //   1. Wait for `w.onload` (fires after all `<link>` CSS and synchronous
    //      scripts have loaded).
    //   2. Then wait for every `<img>` in the doc to fire `load` OR `error`
    //      (broken images shouldn't block printing forever).
    //   3. Hard cap of 5s so a missing image never wedges the print button.
    //   4. Use `w.onafterprint` to close the window (only after the print
    //      dialog is dismissed) with a 2s fallback for browsers that don't
    //      fire `onafterprint` reliably.
    function triggerPrintWhenReady(w) {
        const HARD_CAP_MS = 5000;
        let printed = false;
        function doPrint() {
            if (printed) return;
            printed = true;
            try {
                w.focus();
                w.print();
            } catch (e) {
                // Window may have been closed by user, ignore.
            }
            // Iteration 32 (LEAK-01): every image in the print document has
            // loaded by now, so the blob URLs the report cards created are no
            // longer needed. Revoke them here so a Print All of a large batch
            // does not pin every logo/photo in memory until page unload.
            if (window.TerminalReportScript_revokeReportObjectUrls) {
                window.TerminalReportScript_revokeReportObjectUrls();
            }
        }
        // Schedule close AFTER print dialog, with a fallback in case
        // onafterprint never fires (some older browsers / certain OS print
        // dialogs suppress it).
        let closed = false;
        function doClose() {
            if (closed) return;
            closed = true;
            setTimeout(function () {
                try { w.close(); } catch (e) {}
            }, 250);
        }
        if (w.matchMedia) {
            // onafterprint is the canonical signal, fires after the browser's
            // print pipeline finishes (whether the user printed or cancelled).
            w.onafterprint = doClose;
        }
        // Hard fallback in case onafterprint is missing or suppressed.
        setTimeout(doClose, 60000);
        // Step 1: wait for the document's onload event.
        function step2_waitForImages() {
            const imgs = Array.prototype.slice.call(w.document.querySelectorAll('img'));
            if (!imgs.length) { doPrint(); return; }
            let remaining = imgs.length;
            const done = function () {
                if (--remaining === 0) doPrint();
            };
            imgs.forEach(function (img) {
                if (img.complete && (img.naturalWidth || img.naturalHeight)) {
                    done();
                } else {
                    img.addEventListener('load', done, { once: true });
                    img.addEventListener('error', done, { once: true });
                }
            });
            // Hard cap so a broken image URL never wedges printing.
            setTimeout(function () { if (!printed) doPrint(); }, HARD_CAP_MS);
        }
        if (w.document.readyState === 'complete') {
            step2_waitForImages();
        } else {
            w.addEventListener('load', step2_waitForImages, { once: true });
            // Fallback in case onload never fires (e.g., blocked resources).
            setTimeout(function () { if (!printed) step2_waitForImages(); }, HARD_CAP_MS);
        }
    }

    function printOne(idx) {
        const reports = window.__bpReports || [];
        const r = reports[idx];
        if (!r) return;
        // Open a fresh window with just this report and call print()
        // Roadmap #4 (Iter 10): honor the selected template.
        const html = buildStandalonePrintHTML(r, getSelectedTemplate());
        const w = window.open('', '_blank');
        if (!w) {
            // Iteration 32 (LEAK-01): the card HTML already created blob URLs
            // for the logo/photo; nothing will consume them now.
            if (window.TerminalReportScript_revokeReportObjectUrls) {
                window.TerminalReportScript_revokeReportObjectUrls();
            }
            UI.alert('Pop-up blocked. Please allow pop-ups to print.');
            return;
        }
        w.document.write(html);
        w.document.close();
        triggerPrintWhenReady(w);
    }

    function printAll() {
        const reports = window.__bpReports || [];
        if (!reports.length) { UI.alert('No reports to print.'); return; }
        // Open a fresh window with all reports stacked + page breaks
        // Roadmap #4 (Iter 10): honor the selected template.
        const html = buildPrintAllHTML(reports, getSelectedTemplate());
        const w = window.open('', '_blank');
        if (!w) {
            // Iteration 32 (LEAK-01): revoke the per-report blob URLs.
            if (window.TerminalReportScript_revokeReportObjectUrls) {
                window.TerminalReportScript_revokeReportObjectUrls();
            }
            UI.alert('Pop-up blocked. Please allow pop-ups to print.');
            return;
        }
        w.document.write(html);
        w.document.close();
        triggerPrintWhenReady(w);
    }

    function buildStandalonePrintHTML(report, template) {
        const all = [report];
        return buildPrintAllHTML(all, template);
    }

    function buildPrintAllHTML(reports, template) {
        const t = (TEMPLATE_IDS.indexOf(template) !== -1) ? template : 'primary';
        const cardsHtml = reports.map(function (r) {
            return '<div class="terminalreport-page">' +
                applyTemplateClassToCard(window.TerminalReportScript_renderReportHTML(r, r.summary), t) +
                '</div>';
        }).join('');
        return '<!DOCTYPE html><html><head><meta charset="UTF-8">' +
            '<title>TerminalReport: Batch Print</title>' +
            '<link rel="stylesheet" href="vendor/bootstrap/bootstrap.min.css">' +
            '<link rel="stylesheet" href="vendor/font-awesome/css/all.min.css">' +
            '<style>' + PRINT_STYLES + '</style>' +
            '</head><body>' + cardsHtml + '</body></html>';
    }

    // Inline print CSS: replicate the @media print rules from styles.css
    const PRINT_STYLES = `
        body { background:#fff; font-family:'Segoe UI',Tahoma,Geneva,Verdana,sans-serif; margin:0; padding:0; }
        .terminalreport-page { page-break-after: always; }
        .terminalreport-page:last-child { page-break-after: auto; }
        .terminalreport { max-width:100%; margin:0 auto; background:#fff; box-shadow:none; border-radius:0;
            -webkit-print-color-adjust:exact; print-color-adjust:exact; }
        .terminalreport-header { background:linear-gradient(135deg,#3a8eba 0%,#2c3e50 100%); color:#fff; padding:20px; text-align:center; position:relative; -webkit-print-color-adjust:exact; print-color-adjust:exact; }
        .terminalreport-logo { width:80px; height:80px; background-color:#fff; border-radius:50%; display:flex; align-items:center; justify-content:center; margin:0 auto 15px; box-shadow:0 5px 15px rgba(0,0,0,0.2); overflow:hidden; }
        .terminalreport-logo img { width:100%; height:100%; object-fit:contain; }
        .student-photo { width:100px; height:120px; border:3px solid #fff; position:absolute; right:20px; top:20px; background-color:#e9ecef; display:flex; align-items:center; justify-content:center; overflow:hidden; }
        .student-photo img { width:100%; height:100%; object-fit:cover; }
        .terminalreport-title { font-size:24px; font-weight:bold; margin-bottom:5px; }
        .student-info { background-color:#f8f9fa; padding:15px 20px; border-bottom:1px solid #dee2e6; -webkit-print-color-adjust:exact; print-color-adjust:exact; }
        .info-row { display:flex; flex-wrap:wrap; margin-bottom:10px; }
        .info-item { flex:1; min-width:200px; margin-bottom:5px; }
        .info-label { font-weight:600; color:#495057; }
        /* CRIT-12 fix: previously only .terminalreport-table th was styled, body cells,
           table-bordered borders, and table-secondary (Total/Percentage rows) had NO
           CSS in the print window. The <link> to vendor/bootstrap/bootstrap.min.css
           was supposed to provide them, but on slow connections the print dialog
           could open before the <link> finished loading. Inline the critical
           Bootstrap table rules here as defense-in-depth. */
        .table { width:100%; margin-bottom:1rem; color:#212529; border-collapse:collapse; }
        .table th, .table td { padding:0.5rem 0.5rem; vertical-align:top; border:1px solid #dee2e6; text-align:left; }
        .table thead th { vertical-align:bottom; border-bottom:2px solid #dee2e6; }
        .table tbody + tbody { border-top:2px solid #dee2e6; }
        .table-bordered { border:1px solid #dee2e6; }
        .table-bordered th, .table-bordered td { border:1px solid #dee2e6; }
        .table-secondary { background-color:#e9ecef; -webkit-print-color-adjust:exact; print-color-adjust:exact; }
        .text-end { text-align:right; }
        .fw-bold { font-weight:700; }
        .terminalreport-table { width:100%; border-collapse:collapse; }
        .terminalreport-table th { background-color:#3a8eba; color:#fff; font-weight:500; -webkit-print-color-adjust:exact; print-color-adjust:exact; }
        .terminalreport-table td { padding:0.5rem; border:1px solid #dee2e6; }
        .grade-a { color:#28a745; font-weight:bold; }
        .grade-b { color:#17a2b8; font-weight:bold; }
        .grade-c { color:#fd7e14; font-weight:bold; }
        .grade-f { color:#dc3545; font-weight:bold; }
        .result-section { background-color:#f8f9fa; padding:15px 20px; border-top:1px solid #dee2e6; -webkit-print-color-adjust:exact; print-color-adjust:exact; }
        .result-box { background-color:#28a745; color:#fff; border-radius:5px; padding:10px 15px; display:inline-block; font-weight:bold; -webkit-print-color-adjust:exact; print-color-adjust:exact; }
        .result-box-fail { background-color:#dc3545; }
        .signature-section { display:flex; justify-content:space-between; margin-top:30px; padding-bottom:10px; }
        .signature { text-align:center; width:150px; }
        .signature-line { width:100%; border-top:1px solid #000; margin-bottom:5px; }
        .table-responsive { overflow:visible; }
        @media (max-width:480px) {
            .signature-section { flex-direction:column; align-items:center; gap:20px; }
            .signature { width:80%; }
        }
        /* Roadmap #4 (Iter 10): template variants, mirrored from styles.css
           (Phase A) so batch print output matches the single-report preview. */
        .terminalreport.template-grayscale,
        .terminalreport.template-grayscale .terminalreport-header,
        .terminalreport.template-grayscale .terminalreport-table th,
        .terminalreport.template-grayscale .result-box,
        .terminalreport.template-grayscale .result-box-fail,
        .terminalreport.template-grayscale .student-info,
        .terminalreport.template-grayscale .result-section,
        .terminalreport.template-grayscale .student-photo {
            -webkit-filter: grayscale(100%) !important;
            filter: grayscale(100%) !important;
        }
        .terminalreport.template-grayscale .terminalreport-header {
            background: linear-gradient(135deg, #555 0%, #333 100%) !important;
        }
        .terminalreport.template-grayscale .terminalreport-table th {
            background-color: #555 !important;
        }
        .terminalreport.template-grayscale .result-box,
        .terminalreport.template-grayscale .result-box-fail {
            background-color: #555 !important;
        }
        .terminalreport.template-grayscale .grade-a,
        .terminalreport.template-grayscale .grade-b,
        .terminalreport.template-grayscale .grade-c,
        .terminalreport.template-grayscale .grade-f {
            color: #333 !important;
        }
        .terminalreport.template-nologo .terminalreport-logo {
            display: none !important;
        }
        .terminalreport.template-nologo .terminalreport-header {
            padding-top: 20px;
        }
        /* Iter 13 (roadmap #10): per-subject rank badge (mirrors styles.css).
           Iteration 30: the badge was replaced by a dedicated Subject Rank
           column rendered by generateReportHTML, so this rule is gone. */
    `;

    // ------------------------------------------------------------------
    // Helpers
    // ------------------------------------------------------------------
    function escapeHtml(s) {
        return String(s == null ? '' : s)
            .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
    }
    function escapeAttr(s) { return escapeHtml(s); }

    // ------------------------------------------------------------------
    // Init
    // ------------------------------------------------------------------
    function init() {
        // Stepper navigation buttons
        $('bwNext1').addEventListener('click', function () {
            if (readStep1()) {
                applyManagedPrefill();
                renderStep(2);
            }
        });
        $('bwBack2').addEventListener('click', function () { renderStep(1); });
        $('bwNext2').addEventListener('click', function () { if (readStep2()) renderStep(3); });
        $('bwBack3').addEventListener('click', function () { renderStep(2); });
        $('bwNext3').addEventListener('click', function () { if (readStep3()) renderStep(4); });

        // Iter 13 (roadmap #9): Step 3 photo upload + clear buttons.
        // Event delegation on the tbody: one change handler for any photo input
        // in the table, one click handler for any clear button.
        $('bwStudentsBody').addEventListener('change', function (e) {
            const fileInput = e.target.closest('input[type="file"][data-field="photo"]');
            if (fileInput) handleStudentPhotoChange(fileInput);
        });
        $('bwStudentsBody').addEventListener('click', function (e) {
            const clearBtn = e.target.closest('.bw-photo-clear');
            if (clearBtn) {
                e.preventDefault();
                handleStudentPhotoClear(parseInt(clearBtn.dataset.studIdx, 10));
            }
        });
        $('bwBack4').addEventListener('click', function () { renderStep(3); });
        $('bwNext4').addEventListener('click', function () { if (readStep4()) renderStep(5); });
        $('bwBack5').addEventListener('click', function () { renderStep(4); });
        $('bwGenerate').addEventListener('click', handleGenerate);

        // Close buttons
        $('bwCancel').addEventListener('click', function () {
            // Iter 17: removed confirm dialog; "Back" label makes intent clear.
            // The wizard state is freshState()'d on every openWizard() call,
            // so nothing is persisted until the user clicks Generate.
            closeWizard();
        });
        $('bpClose').addEventListener('click', closeBatchPreview);
        $('bpPrintAll').addEventListener('click', printAll);
        $('bpDetailClose').addEventListener('click', closeReportDetail);

        // List actions (event delegation)
        $('bpReportList').addEventListener('click', function (e) {
            const btn = e.target.closest('[data-action]');
            if (!btn) return;
            const idx = parseInt(btn.dataset.idx, 10);
            if (btn.dataset.action === 'view-report') viewReport(idx);
            else if (btn.dataset.action === 'print-one') printOne(idx);
        });

        // Roadmap #3 (Iter 9): managed-class picker (Phase E entities → wizard
        // Steps 2/3 + grading scale). Replaces the earlier deferred pre-fill
        // hook; manual entry via the basic-info fields is still fully supported.
        $('bwManagedClass').addEventListener('change', handleManagedClassChange);

        // Roadmap #4 (Iter 10): batch template selector. Changing it live
        // re-templates the report card shown in the detail modal (if open),
        // so the preview always matches what Print All / print-one will output.
        $('bpTemplateSelector').addEventListener('change', retemplateDetailModal);

        // Iteration 32 (VAL-02): clear a control's invalid state as soon as
        // the user edits it, instead of leaving the red border (and the old
        // error styling) in place until the next Next click re-validates.
        // Full validation still runs on every Next/Generate press.
        ['bwSubjectsBody', 'bwStudentsBody', 'bwMarksGrid', 'bwAttendanceBody'].forEach(function (id) {
            const el = $(id);
            if (!el) return;
            el.addEventListener('input', function (e) {
                if (e.target && e.target.classList && e.target.classList.contains('is-invalid')) {
                    e.target.classList.remove('is-invalid');
                }
            });
        });
    }

    // ------------------------------------------------------------------
    // Export
    // ------------------------------------------------------------------
    window.TerminalReportBatchUI = {
        init: init,
        start: openWizard,
        showBatchPreview: showBatchPreview
    };
})();
