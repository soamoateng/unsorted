/* ==========================================================================
 * TerminalReport: shared in-app dialog module (Iteration 28, DLG-01)
 *
 * Replaces every native alert() / confirm() in the app with an in-app modal
 * that matches the app's existing auth-overlay / auth-card design language.
 *
 * Why: native browser dialogs (a) look foreign and unbranded, (b) are not
 * stylable, (c) behave differently per browser/OS, and (d) in a PWA feel
 * like a bug rather than a choice. This module gives the whole app ONE
 * consistent, keyboard-accessible dialog.
 *
 * Public API (window.TerminalReportUI):
 *   UI.alert(message [, options])  → Promise<void>   resolves when dismissed
 *   UI.confirm(message [, options]) → Promise<bool>  true = OK, false = cancel
 *
 * options = {
 *   title:      string; an optional bold heading above the message
 *   okText:     string; primary button label (default 'OK' / 'Confirm')
 *   cancelText: string; cancel button label (default 'Cancel')
 *   variant:    string; one of 'info' | 'success' | 'warning' | 'danger'
 *                          icon + button colour; confirm defaults to 'warning'
 * }
 *
 * Guarantees:
 *   - Messages are rendered with textContent (XSS-safe) and pre-line
 *     whitespace, so existing '\n\n' multi-line messages keep their layout.
 *   - Requests are queued: an alert raised while another dialog is open
 *     resolves strictly after its predecessor closes.
 *   - Focus is moved to the primary button on open and restored to the
 *     previously-focused element on close (keyboard/a11y friendly).
 *   - Keyboard: Enter = OK, Escape = Cancel (confirm) / dismiss (alert).
 *   - Backdrop click: dismiss (alert) / cancel (confirm).
 * ==========================================================================
 */
(function () {
    'use strict';

    const $ = (id) => document.getElementById(id);

    let queue = [];          // pending requests waiting for the dialog
    let active = null;       // { resolve, isConfirm } for the visible dialog
    let lastFocus = null;    // element to restore focus to on close

    function getDom() {
        return {
            overlay: $('appDialog'),
            icon: $('appDialogIcon'),
            title: $('appDialogTitle'),
            msg: $('appDialogMsg'),
            ok: $('appDialogOk'),
            cancel: $('appDialogCancel')
        };
    }

    const VARIANTS = {
        info:    { icon: 'fa-circle-info',          btn: 'btn-primary' },
        success: { icon: 'fa-circle-check',         btn: 'btn-success' },
        warning: { icon: 'fa-triangle-exclamation', btn: 'btn-warning' },
        danger:  { icon: 'fa-circle-exclamation',   btn: 'btn-danger' }
    };

    function applyVariant(dom, variant) {
        const v = VARIANTS[variant] || VARIANTS.info;
        dom.icon.className = 'app-dialog-icon ' + variant;
        dom.icon.innerHTML = '<i class="fas ' + v.icon + '"></i>';
        dom.ok.className = 'btn flex-grow-1 ' + v.btn;
    }

    function show(request) {
        const dom = getDom();
        if (!dom.overlay || !dom.ok) {
            // Markup missing (should never happen, index.html ships it).
            // Fail soft towards the legacy behaviour so flows aren't bricked.
            if (request.isConfirm) {
                request.resolve(window.confirm(request.message));
            } else {
                window.alert(request.message);
                request.resolve();
            }
            return;
        }
        active = request;
        lastFocus = document.activeElement;

        applyVariant(dom, request.variant);
        // textContent, never innerHTML, because messages routinely embed
        // user data (class names, filenames, error strings).
        dom.msg.textContent = request.message;
        if (request.title) {
            dom.title.textContent = request.title;
            dom.title.style.display = 'block';
        } else {
            dom.title.style.display = 'none';
        }
        dom.ok.textContent = request.okText || (request.isConfirm ? 'Confirm' : 'OK');
        dom.cancel.style.display = request.isConfirm ? '' : 'none';
        dom.cancel.textContent = request.cancelText || 'Cancel';

        dom.overlay.style.display = 'flex';

        dom.ok.onclick = function () { finish(true); };
        dom.cancel.onclick = function () { finish(false); };
        dom.overlay.onclick = function (e) {
            if (e.target === dom.overlay) finish(request.isConfirm ? false : true);
        };

        document.addEventListener('keydown', onKeyDown, true);
        // Defer focus so the overlay is painted first (matches .auth-overlay
        // display:flex toggling used by every other modal in the app).
        setTimeout(function () { dom.ok.focus(); }, 0);
    }

    function onKeyDown(e) {
        if (!active) return;
        if (e.key === 'Enter') {
            e.preventDefault();
            // Iteration 32 (KEY-01): stop the event from reaching listeners
            // registered further down the path (e.g. the wireModal Escape/
            // keyboard helper), so an open dialog fully owns the keyboard and
            // a single Enter press can never dismiss both the dialog AND the
            // modal underneath it.
            e.stopPropagation();
            finish(true);
        } else if (e.key === 'Escape') {
            e.preventDefault();
            e.stopPropagation();
            finish(active.isConfirm ? false : true);
        } else if (e.key === 'Tab') {
            // Iteration 32 (KEY-01): minimal focus trap. The dialog covers
            // the whole viewport, so Tabbing out of it only lands on hidden
            // background elements; cycle between the two dialog buttons
            // instead so keyboard users never lose the dialog.
            const d = getDom();
            const focusables = [d.ok];
            if (d.cancel && d.cancel.style.display !== 'none') focusables.push(d.cancel);
            const idx = focusables.indexOf(document.activeElement);
            if (idx === -1) {
                e.preventDefault();
                focusables[0].focus();
            } else {
                e.preventDefault();
                const next = e.shiftKey
                    ? (idx - 1 + focusables.length) % focusables.length
                    : (idx + 1) % focusables.length;
                focusables[next].focus();
            }
        }
    }

    function finish(result) {
        const dom = getDom();
        const current = active;
        active = null;
        document.removeEventListener('keydown', onKeyDown, true);
        if (dom.overlay) dom.overlay.style.display = 'none';
        dom.ok.onclick = dom.cancel.onclick = dom.overlay.onclick = null;
        if (lastFocus && typeof lastFocus.focus === 'function') {
            try { lastFocus.focus(); } catch (e) { /* element may be gone */ }
        }
        lastFocus = null;
        if (current) current.resolve(result);
        // Serve the next queued request, if any.
        if (queue.length) show(queue.shift());
    }

    function request(message, options, isConfirm) {
        const opts = options || {};
        const req = {
            message: String(message == null ? '' : message),
            title: opts.title,
            okText: opts.okText,
            cancelText: opts.cancelText,
            variant: opts.variant || (isConfirm ? 'warning' : 'info'),
            isConfirm: isConfirm,
            resolve: null
        };
        const p = new Promise(function (resolve) { req.resolve = resolve; });
        if (active) queue.push(req); else show(req);
        return p;
    }

    // ------------------------------------------------------------------
    // Iteration 32 (KEY-01 + SCROLL-01): shared lifecycle helper for the
    // app's READ-ONLY modals (saved report viewer, student profile, batch
    // report detail). Gives them, without touching their existing close
    // buttons:
    //   - Escape closes the topmost wired modal only, and only when no
    //     appDialog is active above it (form overlays such as the wizard,
    //     the admin screens and the settings screen are deliberately NOT
    //     wired: an accidental Escape there could discard typed data).
    //   - On open, the overlay's scroll position resets, so reopening a
    //     modal never shows the middle of a previous report.
    //   - Focus moves to the modal's header close control on open and is
    //     restored to the triggering element on close (guarded, the
    //     trigger may have been re-rendered away in the meantime).
    // ------------------------------------------------------------------
    const wiredModals = [];   // stack of { overlay, close, focusEl, lastFocus }
    document.addEventListener('keydown', function (e) {
        if (e.key !== 'Escape' || !wiredModals.length) return;
        if (active) return;     // an appDialog is open; its own handler owns Escape
        const top = wiredModals[wiredModals.length - 1];
        e.preventDefault();
        top.close();
    }, false);

    function wireModal(overlayEl, opts) {
        const entry = {
            overlay: overlayEl,
            close: opts.close,
            focusEl: opts.focusEl || null,
            lastFocus: null
        };
        return {
            /** Call right after setting overlay.style.display = 'flex'. */
            onOpen: function () {
                entry.lastFocus = document.activeElement;
                if (overlayEl) overlayEl.scrollTop = 0;
                const i = wiredModals.indexOf(entry);
                if (i === -1) wiredModals.push(entry);
                const fe = entry.focusEl && entry.focusEl();
                if (fe && typeof fe.focus === 'function') {
                    setTimeout(function () { try { fe.focus(); } catch (e) {} }, 0);
                }
            },
            /** Call inside the modal's close function (idempotent). */
            onClose: function () {
                const i = wiredModals.indexOf(entry);
                if (i !== -1) wiredModals.splice(i, 1);
                if (entry.lastFocus && typeof entry.lastFocus.focus === 'function') {
                    try { entry.lastFocus.focus(); } catch (e) { /* trigger may be gone */ }
                }
                entry.lastFocus = null;
            }
        };
    }

    window.TerminalReportUI = {
        /** In-app replacement for alert(). Fire-and-forget is fine; the
         *  returned promise resolves when the user dismisses the dialog. */
        alert: function (message, options) { return request(message, options, false); },
        /** In-app replacement for confirm(). Resolves true (OK) / false. */
        confirm: function (message, options) { return request(message, options, true); },
        /** Iteration 32: keyboard/scroll/focus lifecycle for read-only modals. */
        wireModal: wireModal
    };
})();
