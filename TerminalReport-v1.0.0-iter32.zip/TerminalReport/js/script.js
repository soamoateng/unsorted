/**
 * TerminalReport: vanilla JS, IIFE-scoped.
 *
 * Iter 16: the single-report generation form has been REMOVED. The batch
 * wizard (class-based generation) is now the default and only way to
 * generate terminal reports. This file now contains ONLY:
 *   - Report card HTML renderer (generateReportHTML), shared by batch-ui.js
 *     and the Saved Report Viewer modal
 *   - Saved Reports panel (search, filter, view, print, delete)
 *   - Saved Report Viewer modal (renders a saved report for viewing + printing)
 *   - initMainApp, wires up the 3 dashboard buttons (Start New Batch,
 *     Saved Reports, Admin & Manage) + DB + backup init
 *
 * Previously (Iter 1-15), this file also contained the single-report form
 * logic (addSubjectRow, validateInput, collectFormData, computeSummary,
 * generateTerminalReport, printTerminalReport, resetForm, etc.). All of that
 * has been removed; the batch wizard and Admin UI now cover all use cases.
 *
 * Bound to index.html element IDs:
 *   Dashboard: #startBatchBtn, #loadSavedBtn, #adminBtn
 *   Saved: #savedReportsPanel, #savedReportsList, #refreshSavedBtn, #closeSavedBtn
 *   Saved viewer modal: #savedReportViewerModal, #srvBody, #srvCloseBtn, #srvPrintBtn
 */
(function () {
    'use strict';

    // ------------------------------------------------------------------
    // State
    // ------------------------------------------------------------------
    const createdObjectUrls = []; // tracked for cleanup on re-render
    let currentViewedReportId = null; // saved report ID currently open in the viewer modal

    // ------------------------------------------------------------------
    // DOM helpers (DRY)
    // ------------------------------------------------------------------
    const $ = (id) => document.getElementById(id);
    // Iteration 28 (DLG-01): shared in-app dialog (replaces native alert/confirm)
    const UI = window.TerminalReportUI;

    // ------------------------------------------------------------------
    // XSS guard: a minimal HTML escaper. No new deps (KISS).
    // ------------------------------------------------------------------
    function escapeHtml(value) {
        return String(value == null ? '' : value)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;');
    }

    // ------------------------------------------------------------------
    // Object URL lifecycle (fixes memory leak, issue #4 + Iter 2 preview)
    // ------------------------------------------------------------------
    function trackObjectUrl(file) {
        if (!file || !URL.createObjectURL) return '';
        const url = URL.createObjectURL(file);
        createdObjectUrls.push(url);
        return url;
    }

    function revokeAllObjectUrls() {
        while (createdObjectUrls.length) {
            const url = createdObjectUrls.pop();
            if (URL.revokeObjectURL) URL.revokeObjectURL(url);
        }
    }

    // ------------------------------------------------------------------
    // Grading (Single Responsibility, pure, no DOM access)
    // ------------------------------------------------------------------
    const GRADE_THRESHOLDS = [
        { grade: 'A+', min: 90 },
        { grade: 'A',  min: 80 },
        { grade: 'B+', min: 70 },
        { grade: 'B',  min: 60 },
        { grade: 'C',  min: 50 },
        { grade: 'D',  min: 40 },
        { grade: 'F',  min: 0  }
    ];

    function getGrade(score) {
        const n = Number(score);
        if (!Number.isFinite(n)) return 'F';
        return (GRADE_THRESHOLDS.find(t => n >= t.min) || GRADE_THRESHOLDS[GRADE_THRESHOLDS.length - 1]).grade;
    }

    function getGradeClass(grade) {
        // BLIND-9 fix (Iter 23): harden against non-string grades from corrupted
        // summary_json (e.g. "overallGrade": 90, number has no .indexOf and
        // previously threw TypeError here). Coerce; null/undefined → ''.
        grade = String(grade == null ? '' : grade);
        if (grade.indexOf('A') !== -1) return 'grade-a';
        if (grade.indexOf('B') !== -1) return 'grade-b';
        if (grade.indexOf('C') !== -1 || grade.indexOf('D') !== -1) return 'grade-c';
        return 'grade-f';
    }

    // ------------------------------------------------------------------
    // Date formatting (TZ-safe, issue #6)
    // ------------------------------------------------------------------
    function formatDateGB(yyyymmdd) {
        if (!yyyymmdd) return '';
        const parts = yyyymmdd.split('-');
        if (parts.length !== 3) return yyyymmdd;
        const [y, m, d] = parts;
        if (!y || !m || !d) return yyyymmdd;
        return d + '/' + m + '/' + y;
    }

    /**
     * Iter 31 audit fix (TZ-01): format a SQLite datetime('now') value
     * ('YYYY-MM-DD HH:MM:SS', stored in UTC) as a local date and time.
     * The saved-reports list previously printed the raw UTC string, so the
     * "Saved ..." stamp drifted from the user's wall clock by the zone
     * offset. Unrecognised values are returned unchanged.
     */
    function formatDateTimeUtcToLocal(sqlUtc) {
        const raw = String(sqlUtc == null ? '' : sqlUtc);
        const m = /^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2}):(\d{2})/.exec(raw);
        if (!m) return raw;
        const d = new Date(Date.UTC(Number(m[1]), Number(m[2]) - 1, Number(m[3]), Number(m[4]), Number(m[5]), Number(m[6])));
        if (isNaN(d.getTime())) return raw;
        const pad = function (x) { return String(x).padStart(2, '0'); };
        return pad(d.getDate()) + '/' + pad(d.getMonth() + 1) + '/' + d.getFullYear() +
            ' ' + pad(d.getHours()) + ':' + pad(d.getMinutes());
    }

    /** Convert a Uint8Array back into an object URL for display. */
    function bytesToObjectUrl(bytes) {
        if (!bytes || !bytes.length || !URL.createObjectURL) return '';
        // BLOB type "image/*": let the browser sniff the actual format.
        const blob = new Blob([bytes], { type: 'image/*' });
        const url = URL.createObjectURL(blob);
        createdObjectUrls.push(url);
        return url;
    }

    // ==================================================================
    // Report card HTML renderer (Iter 1+, shared by batch-ui.js + saved
    // report viewer modal via window.TerminalReportScript_renderReportHTML)
    // Iter 13 (roadmap #10): per-subject rank badge
    // ==================================================================
    function generateReportHTML(data, summary) {
        // Iter 20 fix (RT-03/04): null-guard summary and data.subjects
        if (!summary) summary = {};
        if (!data.subjects) data.subjects = [];
        // Iter 13 (roadmap #10): per-subject rank display on the card.
        // batch.js computes `subjectRank` for each subject during batch
        // generation; the value is the student's rank in that subject within
        // the batch (1 = highest).
        //
        // summary.totalStudents is the batch's student count; if missing,
        // fall back to data.totalStudents (so a saved report with the field
        // in either place renders correctly).
        const totalStudents = (summary && summary.totalStudents) ||
                              data.totalStudents ||
                              (summary && summary.subjects && summary.subjects.length
                                  ? Math.max(...summary.subjects.map(function (s) { return s.subjectRank || 0; }))
                                  : 0);

        // Iteration 30: the per-subject rank moved out of the Grade cell
        // (it used to render as a '#N' badge next to the letter grade) into
        // its own Subject Rank column, written as an ordinal such as '1st'.
        // The hover title keeps the 'of M students' context the badge had.
        function subjectRankCell(s) {
            if (!(Number.isFinite(s.subjectRank) && s.subjectRank > 0)) {
                // Missing or invalid rank (e.g. a saved report from before
                // the field existed) renders like the other missing fields.
                return '<td>n/a</td>';
            }
            const ordinal = window.TerminalReportScript_toOrdinal
                ? window.TerminalReportScript_toOrdinal(s.subjectRank)
                : String(s.subjectRank);
            const title = (totalStudents > 1)
                ? ' title="Ranked ' + ordinal + ' of ' + totalStudents + ' students in this subject"'
                : '';
            return '<td class="subject-rank"' + title + '>' + ordinal + '</td>';
        }

        // Iter 31 audit fix (SCALE-01, part B): the "Grading Scale" legend on
        // the card is drawn from the bands stored in the summary (the exact
        // scale the grades were computed with), not from a hardcoded default.
        // Legacy reports without stored bands keep the original hardcoded
        // default legend, so old rows render exactly as before.
        function gradingLegendHtml() {
            const bands = Array.isArray(summary.gradingScaleBands) ? summary.gradingScaleBands : null;
            if (!bands || !bands.length) {
                return '' +
                    '<div><span class="grade-a">A+ (90-100)</span> - Outstanding</div>' +
                    '<div><span class="grade-a">A (80-89)</span> - Excellent</div>' +
                    '<div><span class="grade-b">B+ (70-79)</span> - Very Good</div>' +
                    '<div><span class="grade-b">B (60-69)</span> - Good</div>' +
                    '<div><span class="grade-c">C (50-59)</span> - Average</div>' +
                    '<div><span class="grade-c">D (40-49)</span> - Below Average</div>' +
                    '<div><span class="grade-f">F (Below 40)</span> - Fail</div>';
            }
            const sorted = bands.slice().sort(function (a, b) { return (Number(b.min) || 0) - (Number(a.min) || 0); });
            return sorted.map(function (b, i) {
                const min = Number(b.min) || 0;
                let range;
                if (sorted.length === 1 || i === 0) {
                    // Top band runs up to 100 (or a single-band scale covers all).
                    range = min + '-100';
                } else if (i === sorted.length - 1 && min <= 0) {
                    // Bottom band starting at 0 is conventionally shown as "Below".
                    range = 'Below ' + (Number(sorted[i - 1].min) || 0);
                } else {
                    range = min + '-' + ((Number(sorted[i - 1].min) || 0) - 1);
                }
                const cls = getGradeClass(String(b.grade == null ? '' : b.grade));
                const desc = b.description ? ' - ' + escapeHtml(b.description) : '';
                return '<div><span class="' + cls + '">' + escapeHtml(b.grade) + ' (' + range + ')</span>' + desc + '</div>';
            }).join('');
        }

        const subjectRows = data.subjects.map(function (s) {
            // CRIT-21 fix (Iter 23), part 1: a null/undefined ELEMENT inside the
            // subjects array (e.g. subjects_json = '[null]', valid JSON, parses
            // fine in db.js loadReport) previously crashed the whole renderer on
            // the first property read. Normalise to {} so it renders as 'n/a' for missing fields
            // row below (consistent with other corrupted-row treatment).
            s = s || {};
            // CRIT-21 fix (Iter 23), part 2: individual subject fields were NOT guarded,
            // only summary and data.subjects themselves were (Iter 20, RT-03/04).
            // A single corrupted subject row (missing max/min/obtained, e.g. a
            // hand-edited or partially-written subjects_json) rendered the literal
            // string "undefined" in the Max/Pass/Obtained columns of an otherwise
            // fine report card. Guard every numeric field: compute with coalesced
            // numbers (missing → 0, matching the max=0 → pct=0 semantics the
            // renderer already had), render 'n/a' for missing raw values.
            //   * s.max undefined → old: pct=0 (via `undefined > 0` → false)
            //   * s.obtained >= s.min with undefined → old: false → misleading FAIL ×
            const hasMax = (s.max != null);
            const hasMin = (s.min != null);
            const hasObtained = (s.obtained != null);
            const maxN = hasMax ? Number(s.max) : 0;
            const minN = hasMin ? Number(s.min) : 0;
            const obtN = hasObtained ? Number(s.obtained) : 0;
            const pct = maxN > 0 ? (obtN / maxN) * 100 : 0;
            // Iter 31 audit fix (SCALE-01, part B): prefer the grade STORED at
            // generation time. batch.js computed it with the class's grading
            // scale (which may be a custom scale from the grading_scales
            // table); recomputing here from the hardcoded default thresholds
            // printed the wrong letter for every class on a custom scale.
            // The recompute fallback only serves legacy rows that somehow
            // lack a grade string.
            const grade = (typeof s.grade === 'string' && s.grade) ? s.grade : getGrade(pct);
            const gradeClass = (typeof s.gradeClass === 'string' && s.gradeClass)
                ? s.gradeClass
                : getGradeClass(grade);
            const subjectPassed = obtN >= minN;
            return '' +
                '<tr>' +
                    '<td>' + escapeHtml(s.code) + '</td>' +
                    '<td>' + escapeHtml(s.name) + '</td>' +
                    // CRIT-21 fix (Iter 23): 'n/a' instead of literal "undefined" when
                    // the field is missing (null/undefined only, 0 is a valid value
                    // and must still render as 0).
                    '<td>' + (hasMax ? s.max : 'n/a') + '</td>' +
                    '<td>' + (hasMin ? s.min : 'n/a') + '</td>' +
                    '<td>' + (hasObtained ? s.obtained : 'n/a') + '</td>' +
                    '<td class="' + gradeClass + '">' + grade +
                        (subjectPassed ? '' : ' <span class="text-danger">&times;</span>') +
                    '</td>' +
                    subjectRankCell(s) +
                '</tr>';
        }).join('');

        // For saved reports (Iter 3), images come back as Uint8Array, not File.
        // Handle both cases uniformly via bytesToObjectUrl helper.
        const logoSrc = data.schoolLogoBytes
            ? bytesToObjectUrl(data.schoolLogoBytes)
            : (data.schoolLogo ? trackObjectUrl(data.schoolLogo) : '');
        const logoHTML = logoSrc
            ? '<img src="' + logoSrc + '" alt="School Logo">'
            : '<i class="fas fa-graduation-cap fa-3x" style="color:#3a8eba;"></i>';

        const photoSrc = data.studentPhotoBytes
            ? bytesToObjectUrl(data.studentPhotoBytes)
            : (data.studentPhoto ? trackObjectUrl(data.studentPhoto) : '');
        const photoHTML = photoSrc
            ? '<img src="' + photoSrc + '" alt="Student Photo">'
            : '<i class="fas fa-user fa-3x text-secondary"></i>';

        const resultBoxClass = summary.passed ? 'result-box' : 'result-box result-box-fail';
        const passFailIcon = summary.passed ? 'fa-circle-check' : 'fa-circle-xmark';

        return '' +
            '<div class="terminalreport position-relative">' +
                '<div class="terminalreport-header">' +
                    '<div class="terminalreport-logo">' + logoHTML + '</div>' +
                    '<div class="terminalreport-title">' + escapeHtml(data.academyName) + '</div>' +
                    '<div>Academic Year ' + escapeHtml(data.academicYear) + '</div>' +
                    '<div>' + escapeHtml(data.academicTerm) + ' Term</div>' +
                    '<div class="mt-2">STUDENT TERMINAL REPORT</div>' +
                    '<div class="student-photo">' + photoHTML + '</div>' +
                '</div>' +

                '<div class="student-info">' +
                    // Iteration 30: each label and its value now flow on one
                    // line ("Student Name: Dadson Kweku") instead of the
                    // label sitting on its own line above the value.
                    '<div class="info-row">' +
                        '<div class="info-item"><span class="info-label">Student Name:</span> ' + escapeHtml(data.studentName) + '</div>' +
                        '<div class="info-item"><span class="info-label">Class:</span> ' + escapeHtml(data.studentClass) + '</div>' +
                        (Number.isFinite(summary.classRank) && summary.classRank > 0 && totalStudents > 1
                            ? '<div class="info-item"><span class="info-label">Class Rank:</span> <span class="class-rank-badge">' + (window.TerminalReportScript_toOrdinal ? window.TerminalReportScript_toOrdinal(summary.classRank) : summary.classRank) + ' of ' + totalStudents + '</span></div>'
                            : '') +
                    '</div>' +
                '</div>' +

                '<div class="table-responsive">' +
                    '<table class="table table-bordered terminalreport-table mb-0">' +
                        '<thead>' +
                            '<tr>' +
                                '<th>Subject Code</th>' +
                                '<th>Subject</th>' +
                                '<th>Max Marks</th>' +
                                '<th>Pass Marks</th>' +
                                '<th>Obtained</th>' +
                                '<th>Grade</th>' +
                                '<th>Subject Rank</th>' +
                            '</tr>' +
                        '</thead>' +
                        '<tbody>' + subjectRows + '</tbody>' +
                        '<tfoot>' +
                            // BLIND-9 fix (Iter 23): the Iter 20 null-summary guard
                            // (`if (!summary) summary = {}`) prevented a TypeError at
                            // the TOP of this function but the footer still crashed or
                            // leaked "undefined":
                            //   * getGradeClass(summary.overallGrade) called
                            //     grade.indexOf() on undefined → TypeError → the whole
                            //     renderer threw (guard defeated 113 lines later).
                            //   * summary.totalMax/totalMin/totalObtained/percentage
                            //     interpolated raw → literal "undefined" in the Total /
                            //     Percentage rows.
                            // Guard every footer field with `== null` (0 and "0.0" are
                            // valid values and must still render as-is).
                            '<tr class="table-secondary">' +
                                '<td colspan="2" class="text-end fw-bold">Total</td>' +
                                '<td class="fw-bold">' + (summary.totalMax == null ? 'n/a' : summary.totalMax) + '</td>' +
                                '<td class="fw-bold">' + (summary.totalMin == null ? 'n/a' : summary.totalMin) + '</td>' +
                                '<td class="fw-bold">' + (summary.totalObtained == null ? 'n/a' : summary.totalObtained) + '</td>' +
                                '<td></td>' +
                                '<td></td>' +
                            '</tr>' +
                            '<tr class="table-secondary">' +
                                '<td colspan="2" class="text-end fw-bold">Percentage</td>' +
                                '<td colspan="3" class="fw-bold">' + (summary.percentage == null ? 'n/a' : summary.percentage) + '%</td>' +
                                '<td class="' + (summary.overallGrade == null ? '' : getGradeClass(summary.overallGrade)) + '">' + (summary.overallGrade == null ? 'n/a' : summary.overallGrade) + '</td>' +
                                '<td></td>' +
                            '</tr>' +
                        '</tfoot>' +
                    '</table>' +
                '</div>' +

                '<div class="result-section">' +
                    '<div class="d-flex justify-content-between">' +
                        '<div>' +
                            '<div class="mb-2"><strong>Grading Scale:</strong></div>' +
                            '<div class="small">' + gradingLegendHtml() + '</div>' +
                        '</div>' +
                        '<div class="text-end">' +
                            '<div class="mb-3">' +
                                '<div class="' + resultBoxClass + '">' +
                                    (summary.passed ? 'PASS' : 'FAIL') +
                                    ' <i class="fas ' + passFailIcon + ' ms-1"></i>' +
                                '</div>' +
                            '</div>' +
                            '<div>' +
                                '<div class="fw-bold">Issue Date: ' + escapeHtml(formatDateGB(data.issueDate)) + '</div>' +
                                '<div>Certificate No: ' + escapeHtml(data.certificateNo) + '</div>' +
                            '</div>' +
                        '</div>' +
                    '</div>' +

                    '<div class="signature-section">' +
                        '<div class="signature">' +
                            '<div class="signature-line"></div>' +
                            '<div>Class Teacher</div>' +
                        '</div>' +
                        '<div class="signature">' +
                            '<div class="signature-line"></div>' +
                            '<div>Principal</div>' +
                        '</div>' +
                        '<div class="signature">' +
                            '<div class="signature-line"></div>' +
                            '<div>Examination Controller</div>' +
                        '</div>' +
                    '</div>' +
                '</div>' +
            '</div>';
    }

    // ==================================================================
    // Saved Reports UI (Iter 3 + Iter 11 search/filter + Iter 16 viewer modal)
    //
    // Iter 11 (roadmap #1) additions:
    //   - Search input (#srSearchInput), case-insensitive substring match on
    //     student_name. Debounced 200ms. Honored by db.js's searchReports().
    //   - Class filter dropdown (#srClassFilter), populated from distinct
    //     student_class values in the reports table.
    //   - Clear-search button (#srClearBtn), appears only when there's text.
    //   - Result-count badge (#srResultCount).
    //
    // Iter 16: "Load" button renamed to "View" so it opens the report in a modal
    // (#savedReportViewerModal) instead of the (now-removed) single-report
    // form. Added a "Print" button per row.
    // ==================================================================
    let srSearchDebounceTimer = null;
    const SR_SEARCH_DEBOUNCE_MS = 200;
    // Iter 31 audit fix (ASYNC-01): sequence tokens so a slow, stale response
    // can never overwrite a newer render (search queries resolve locally, but
    // nothing guaranteed their order; each refresh now checks that it is
    // still the latest before touching the DOM).
    let srListSeq = 0;
    let dashboardSeq = 0;

    function toggleSavedReportsPanel() {
        const panel = $('savedReportsPanel');
        if (!panel) return;
        const isVisible = panel.style.display === 'block';
        if (isVisible) {
            panel.style.display = 'none';
        } else {
            panel.style.display = 'block';
            // Iter 11: refresh the class filter options first (reports may have
            // changed since the panel was last open), then refresh the list.
            populateSavedReportsClassFilter().finally(function () {
                refreshSavedReportsPanel();
            });
        }
    }

    async function refreshSavedReportsPanelIfOpen() {
        const panel = $('savedReportsPanel');
        if (!panel || panel.style.display !== 'block') return;
        await refreshSavedReportsPanel();
    }

    /**
     * Iter 11: Read the current filter values from the toolbar and call
     * db.searchReports({ studentName, className }). Renders the filtered
     * list and updates the result-count badge.
     */
    async function refreshSavedReportsPanel() {
        const listEl = $('savedReportsList');
        if (!listEl) return;
        const countEl = $('srResultCount');
        const seq = ++srListSeq;

        if (!window.TerminalReportDb || !window.TerminalReportDb.isReady()) {
            listEl.innerHTML = '<div class="text-danger text-center py-3">Database unavailable.</div>';
            if (countEl) countEl.textContent = '0 reports';
            return;
        }

        // Read the current filter state from the toolbar DOM.
        const searchInput = $('srSearchInput');
        const classSelect = $('srClassFilter');
        const studentName = searchInput ? searchInput.value : '';
        const className = classSelect ? classSelect.value : '';

        // Only show "Loading…" if the list isn't already populated; this avoids
        // a flash of "Loading…" on every keystroke during the debounce wait.
        if (!listEl.innerHTML.trim()) {
            listEl.innerHTML = '<div class="text-muted text-center py-3">Loading…</div>';
        }

        try {
            const reports = await window.TerminalReportDb.searchReports({
                studentName: studentName,
                className: className
            });
            // Iter 31 audit fix (ASYNC-01): a newer refresh superseded this one.
            if (seq !== srListSeq) return;
            updateSrClearButtonVisibility(searchInput);

            if (!reports.length) {
                // Distinguish "no reports at all" from "no matches for this filter"
                // so the user knows whether to clear the filter or generate a report.
                const anyFilterActive = !!(studentName && studentName.trim()) || !!(className && className.trim());
                listEl.innerHTML = anyFilterActive
                    ? '<div class="text-muted text-center py-3">No reports match your search. Try clearing the filter.</div>'
                    : '<div class="text-muted text-center py-3">No saved reports yet. Use "Start New Batch" to generate reports.</div>';
                if (countEl) countEl.textContent = '0 reports';
                return;
            }
            listEl.innerHTML = reports.map(renderSavedReportRow).join('');
            if (countEl) {
                const anyFilterActive = !!(studentName && studentName.trim()) || !!(className && className.trim());
                countEl.textContent = anyFilterActive
                    ? (reports.length + (reports.length === 1 ? ' match' : ' matches'))
                    : (reports.length + (reports.length === 1 ? ' report' : ' reports'));
            }
        } catch (err) {
            console.error('[terminalreport] searchReports failed:', err);
            if (seq !== srListSeq) return;
            listEl.innerHTML = '<div class="text-danger text-center py-3">Failed to load saved reports.</div>';
            if (countEl) countEl.textContent = '0 reports';
        }
    }

    /**
     * Iter 11: Refresh the class-filter dropdown options from the DB.
     * Preserves the current selection if the class still exists; resets to
     * "All classes" if the previously-selected class is no longer present.
     */
    async function populateSavedReportsClassFilter() {
        const select = $('srClassFilter');
        if (!select) return;
        if (!window.TerminalReportDb || !window.TerminalReportDb.isReady()) return;
        const previousValue = select.value;
        let classes = [];
        try {
            classes = await window.TerminalReportDb.listReportClasses();
        } catch (err) {
            console.error('[terminalreport] listReportClasses failed:', err);
            return;
        }
        const optionsHtml = ['<option value="">All classes</option>']
            .concat(classes.map(function (c) {
                return '<option value="' + escapeHtml(c) + '">' + escapeHtml(c) + '</option>';
            }))
            .join('');
        select.innerHTML = optionsHtml;
        if (previousValue && classes.indexOf(previousValue) !== -1) {
            select.value = previousValue;
        } else {
            select.value = '';
        }
    }

    /** Show the ✕ clear-search button only when there's text in the search field. */
    function updateSrClearButtonVisibility(searchInput) {
        const clearBtn = $('srClearBtn');
        if (!clearBtn || !searchInput) return;
        clearBtn.style.display = searchInput.value ? '' : 'none';
    }

    function renderSavedReportRow(r) {
        const date = r.issueDate ? formatDateGB(r.issueDate) : '(no date)';
        // Iter 17: student name is clickable → opens Student Profile modal.
        // Added a "Profile" button (user-graduate icon).
        return '' +
            '<div class="saved-report-row" data-id="' + r.id + '">' +
                '<div class="saved-report-meta">' +
                    '<div class="meta-name"><a href="#" data-action="view-profile" data-name="' + escapeHtml(r.studentName || '') + '" class="text-decoration-none">' + escapeHtml(r.studentName || '(unnamed)') + '</a></div>' +
                    '<div class="meta-sub">' +
                        escapeHtml(r.studentClass || '') + ' · ' +
                        escapeHtml(r.academicYear || '') + ' · ' +
                        escapeHtml(r.academicTerm || '') + ' Term · ' +
                        'Cert ' + escapeHtml(r.certificateNo || '') + ' · ' +
                        'Issued ' + escapeHtml(date) + ' · ' +
                        // Iter 31 audit fix (TZ-01): created_at is a UTC SQLite
                        // stamp; render it in the user's local time.
                        'Saved ' + escapeHtml(formatDateTimeUtcToLocal(r.createdAt)) +
                    '</div>' +
                '</div>' +
                '<div class="saved-report-actions">' +
                    '<button type="button" class="btn btn-sm btn-outline-secondary" data-action="profile-report" data-name="' + escapeHtml(r.studentName || '') + '" aria-label="Student profile" title="Student profile"><i class="fas fa-user-graduate"></i></button>' +
                    '<button type="button" class="btn btn-sm btn-outline-primary" data-action="view-report" data-id="' + r.id + '" aria-label="View report">' +
                        '<i class="fas fa-eye"></i> View' +
                    '</button>' +
                    '<button type="button" class="btn btn-sm btn-outline-secondary" data-action="print-report" data-id="' + r.id + '" aria-label="Print report">' +
                        '<i class="fas fa-print"></i>' +
                    '</button>' +
                    '<button type="button" class="btn btn-sm btn-outline-danger" data-action="delete-report" data-id="' + r.id + '" aria-label="Delete report">' +
                        '<i class="fas fa-trash"></i>' +
                    '</button>' +
                '</div>' +
            '</div>';
    }

    // ------------------------------------------------------------------
    // Iter 16: Saved Report Viewer modal
    // (replaces populateFormFromSavedReport which filled the now-removed form)
    // ------------------------------------------------------------------

    async function viewSavedReport(id) {
        if (!window.TerminalReportDb || !window.TerminalReportDb.isReady()) {
            UI.alert('Database unavailable.');
            return;
        }
        try {
            const report = await window.TerminalReportDb.loadReport(parseInt(id, 10));
            if (!report) {
                UI.alert('Report not found.');
                return;
            }
            // Revoke any prior object URLs before rendering new ones
            revokeAllObjectUrls();
            const html = window.TerminalReportScript_renderReportHTML(report, report.summary);
            $('srvBody').innerHTML = html;
            const overlay = $('savedReportViewerModal');
            overlay.style.display = 'flex';
            // Iteration 32 (KEY-01 + SCROLL-01): Escape closes, focus moves to
            // the header Back button, scroll resets, focus is restored on close.
            viewerModalCtl.onOpen();
            currentViewedReportId = parseInt(id, 10);
        } catch (err) {
            console.error('[terminalreport] viewSavedReport failed:', err);
            UI.alert('Failed to load report.');
        }
    }

    // Iteration 32 (KEY-01 + SCROLL-01): shared lifecycle for the viewer modal
    // (see ui.js wireModal). Defined at module scope so both the open path and
    // the close path share one entry on the Escape stack.
    const viewerModalCtl = UI.wireModal($('savedReportViewerModal'), {
        close: closeSavedReportViewer,
        focusEl: function () { return $('srvCloseBtn'); }
    });

    function closeSavedReportViewer() {
        $('savedReportViewerModal').style.display = 'none';
        $('srvBody').innerHTML = '';
        revokeAllObjectUrls();
        currentViewedReportId = null;
        viewerModalCtl.onClose();
    }

    /** Print a single saved report; it opens a new window with just that report. */
    async function printSavedReport(id, triggerBtn) {
        // Iteration 32 (BUSY-02): a double-click on a print button used to
        // open two print windows for the same report. Disable the triggering
        // button while the window is being built (it is re-enabled in the
        // finally below, before the browser's print dialog takes over).
        if (triggerBtn && triggerBtn.disabled) return;
        const origBtnHtml = triggerBtn ? triggerBtn.innerHTML : null;
        if (triggerBtn) {
            triggerBtn.disabled = true;
            triggerBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
        }
        if (!window.TerminalReportDb || !window.TerminalReportDb.isReady()) {
            UI.alert('Database unavailable.');
            if (triggerBtn) { triggerBtn.disabled = false; triggerBtn.innerHTML = origBtnHtml; }
            return;
        }
        try {
            const report = await window.TerminalReportDb.loadReport(parseInt(id, 10));
            if (!report) {
                UI.alert('Report not found.');
                return;
            }
            // Build a self-contained HTML document for the print window.
            // Mirror the PRINT_STYLES from batch-ui.js so the printed card
            // looks identical to the batch Print All output.
            const cardHTML = window.TerminalReportScript_renderReportHTML(report, report.summary);
            const printWin = window.open('', '_blank');
            if (!printWin) {
                // Iteration 32 (LEAK-01): the card HTML created blob URLs for
                // the logo/photo; nothing will consume them now.
                revokeAllObjectUrls();
                UI.alert('Pop-up blocked. Please allow pop-ups to print reports.');
                return;
            }
            printWin.document.write(
                '<!DOCTYPE html><html><head><meta charset="utf-8">' +
                '<title>TerminalReport: ' + escapeHtml(report.studentName || 'Report') + '</title>' +
                '<style>' +
                'body { background:#fff; font-family:"Segoe UI",Tahoma,Geneva,Verdana,sans-serif; margin:0; padding:0; }' +
                '.terminalreport { max-width:100%; margin:0 auto; background:#fff; box-shadow:none; border-radius:0; -webkit-print-color-adjust:exact; print-color-adjust:exact; }' +
                '.terminalreport-header { background:linear-gradient(135deg,#3a8eba 0%,#2c3e50 100%); color:#fff; padding:20px; text-align:center; position:relative; -webkit-print-color-adjust:exact; print-color-adjust:exact; }' +
                '.terminalreport-logo { width:80px; height:80px; background-color:#fff; border-radius:50%; display:flex; align-items:center; justify-content:center; margin:0 auto 15px; box-shadow:0 5px 15px rgba(0,0,0,0.2); overflow:hidden; }' +
                '.terminalreport-logo img { width:100%; height:100%; object-fit:contain; }' +
                '.student-photo { width:100px; height:120px; border:3px solid #fff; position:absolute; right:20px; top:20px; background-color:#e9ecef; display:flex; align-items:center; justify-content:center; overflow:hidden; }' +
                '.student-photo img { width:100%; height:100%; object-fit:cover; }' +
                '.terminalreport-title { font-size:24px; font-weight:bold; margin-bottom:5px; }' +
                '.student-info { background-color:#f8f9fa; padding:15px 20px; border-bottom:1px solid #dee2e6; -webkit-print-color-adjust:exact; print-color-adjust:exact; }' +
                '.info-row { display:flex; flex-wrap:wrap; margin-bottom:10px; }' +
                '.info-item { flex:1; min-width:200px; margin-bottom:5px; }' +
                '.info-label { font-weight:600; color:#495057; }' +
                // CRIT-11 fix: previously only .terminalreport-table th was styled, body cells,
                // table-bordered borders, and table-secondary (Total/Percentage rows) had NO
                // CSS in the print window, so printed saved reports looked unprofessional.
                // Inlining the critical Bootstrap table rules here (defense-in-depth, even
                // if bootstrap.min.css were linked it might not load before print()).
                '.table { width:100%; margin-bottom:1rem; color:#212529; border-collapse:collapse; }' +
                '.table th, .table td { padding:0.5rem 0.5rem; vertical-align:top; border:1px solid #dee2e6; text-align:left; }' +
                '.table thead th { vertical-align:bottom; border-bottom:2px solid #dee2e6; }' +
                '.table tbody + tbody { border-top:2px solid #dee2e6; }' +
                '.table-bordered { border:1px solid #dee2e6; }' +
                '.table-bordered th, .table-bordered td { border:1px solid #dee2e6; }' +
                '.table-secondary { background-color:#e9ecef; -webkit-print-color-adjust:exact; print-color-adjust:exact; }' +
                '.text-end { text-align:right; }' +
                '.fw-bold { font-weight:700; }' +
                '.terminalreport-table { width:100%; border-collapse:collapse; }' +
                '.terminalreport-table th { background-color:#3a8eba; color:#fff; font-weight:500; -webkit-print-color-adjust:exact; print-color-adjust:exact; }' +
                '.terminalreport-table td { padding:0.5rem; border:1px solid #dee2e6; }' +
                '.grade-a { color:#28a745; font-weight:bold; }' +
                '.grade-b { color:#17a2b8; font-weight:bold; }' +
                '.grade-c { color:#fd7e14; font-weight:bold; }' +
                '.grade-f { color:#dc3545; font-weight:bold; }' +
                '.result-section { background-color:#f8f9fa; padding:15px 20px; border-top:1px solid #dee2e6; -webkit-print-color-adjust:exact; print-color-adjust:exact; }' +
                '.result-box { background-color:#28a745; color:#fff; border-radius:5px; padding:10px 15px; display:inline-block; font-weight:bold; -webkit-print-color-adjust:exact; print-color-adjust:exact; }' +
                '.result-box-fail { background-color:#dc3545; }' +
                '.signature-section { display:flex; justify-content:space-between; margin-top:30px; padding-bottom:10px; }' +
                '.signature { text-align:center; width:150px; }' +
                '.signature-line { width:100%; border-top:1px solid #000; margin-bottom:5px; }' +
                '.subject-rank { white-space:nowrap; }' +
                '.table-responsive { overflow:visible; }' +
                '@media print { @page { margin: 12mm; } }' +
                '</style></head><body>' +
                cardHTML +
                '</body></html>'
            );
            printWin.document.close();
            // BLIND-1 fix (sibling of CRIT-13): printSavedReport() previously used
            // setTimeout(250) before printWin.print(), same image-load race as
            // batch-ui.js. Wait for onload + all <img> load/error events with a
            // 5s hard cap so a broken logo/photo never wedges the print button.
            (function () {
                const w = printWin;
                const HARD_CAP_MS = 5000;
                let printed = false;
                function doPrint() {
                    if (printed) return;
                    printed = true;
                    try { w.focus(); w.print(); } catch (e) {}
                    // Iteration 32 (LEAK-01): the print document's images have
                    // all loaded by now, so the card's blob URLs can be freed.
                    revokeAllObjectUrls();
                }
                function step2_waitForImages() {
                    const imgs = Array.prototype.slice.call(w.document.querySelectorAll('img'));
                    if (!imgs.length) { doPrint(); return; }
                    let remaining = imgs.length;
                    const done = function () {
                        if (--remaining === 0) doPrint();
                    };
                    imgs.forEach(function (img) {
                        if (img.complete && (img.naturalWidth || img.naturalHeight)) {
                            done();
                        } else {
                            img.addEventListener('load', done, { once: true });
                            img.addEventListener('error', done, { once: true });
                        }
                    });
                    setTimeout(function () { if (!printed) doPrint(); }, HARD_CAP_MS);
                }
                if (w.document.readyState === 'complete') {
                    step2_waitForImages();
                } else {
                    w.addEventListener('load', step2_waitForImages, { once: true });
                    setTimeout(function () { if (!printed) step2_waitForImages(); }, HARD_CAP_MS);
                }
            })();
        } catch (err) {
            console.error('[terminalreport] printSavedReport failed:', err);
            UI.alert('Failed to print report.');
        } finally {
            if (triggerBtn) {
                triggerBtn.disabled = false;
                triggerBtn.innerHTML = origBtnHtml;
            }
        }
    }

    // Iteration 32 (BUSY-02): ids currently being deleted; a second confirm
    // on the same row used to run deleteReport twice and then report a
    // misleading "Failed to delete report." for the row it had just removed.
    const deletingReportIds = new Set();

    async function deleteSavedReport(id) {
        if (!window.TerminalReportDb || !window.TerminalReportDb.isReady()) {
            UI.alert('Database unavailable.');
            return;
        }
        if (deletingReportIds.has(id)) return;
        deletingReportIds.add(id);
        try {
            if (!(await UI.confirm('Delete this saved report? This cannot be undone.'))) return;
            await window.TerminalReportDb.deleteReport(parseInt(id, 10));
            // Iter 11: the deleted report may have been the last one with
            // its class string, so refresh the class filter options.
            await populateSavedReportsClassFilter();
            await refreshSavedReportsPanel();
        } catch (err) {
            console.error('[terminalreport] deleteReport failed:', err);
            UI.alert('Failed to delete report.');
        } finally {
            deletingReportIds.delete(id);
        }
    }

    // ------------------------------------------------------------------
    // Saved-reports panel event delegation (View + Print + Delete + Iter 11 filters)
    // ------------------------------------------------------------------
    function initSavedReportsPanel() {
        const panel = $('savedReportsPanel');
        if (!panel) return;
        panel.addEventListener('click', function (e) {
            const target = e.target.closest('[data-action]');
            if (!target) return;
            const action = target.dataset.action;
            const id = target.dataset.id;
            const name = target.dataset.name;
            if (action === 'view-report') viewSavedReport(id);
            else if (action === 'print-report') printSavedReport(id, target);
            else if (action === 'delete-report') deleteSavedReport(id);
            else if (action === 'view-profile' || action === 'profile-report') {
                e.preventDefault();
                if (name) openStudentProfile(name);
            }
        });

        const refreshBtn = $('refreshSavedBtn');
        if (refreshBtn) refreshBtn.addEventListener('click', function () {
            populateSavedReportsClassFilter().finally(refreshSavedReportsPanel);
        });

        const closeBtn = $('closeSavedBtn');
        if (closeBtn) closeBtn.addEventListener('click', function () {
            panel.style.display = 'none';
        });

        // Iter 11: search input: debounced refresh
        const searchInput = $('srSearchInput');
        if (searchInput) {
            searchInput.addEventListener('input', function () {
                updateSrClearButtonVisibility(searchInput);
                if (srSearchDebounceTimer) clearTimeout(srSearchDebounceTimer);
                srSearchDebounceTimer = setTimeout(function () {
                    srSearchDebounceTimer = null;
                    refreshSavedReportsPanel();
                }, SR_SEARCH_DEBOUNCE_MS);
            });
        }

        // Iter 11: class filter dropdown: immediate refresh
        const classFilter = $('srClassFilter');
        if (classFilter) {
            classFilter.addEventListener('change', refreshSavedReportsPanel);
        }

        // Iter 11: clear-search button
        const clearBtn = $('srClearBtn');
        if (clearBtn) {
            clearBtn.addEventListener('click', function () {
                if (searchInput) searchInput.value = '';
                updateSrClearButtonVisibility(searchInput);
                refreshSavedReportsPanel();
            });
        }
    }

    // ------------------------------------------------------------------
    // Iter 16: Saved Report Viewer modal wiring
    // ------------------------------------------------------------------
    function initSavedReportViewer() {
        const closeBtn = $('srvCloseBtn');
        if (closeBtn) closeBtn.addEventListener('click', closeSavedReportViewer);

        const printBtn = $('srvPrintBtn');
        if (printBtn) printBtn.addEventListener('click', function () {
            if (currentViewedReportId != null) {
                printSavedReport(currentViewedReportId, printBtn);
            }
        });
    }

    // ==================================================================
    // Iter 17: Class Performance Dashboard Summary
    // Queries the reports table, groups by (class_name, academic_year, academic_term),
    // and shows summary cards: student count, pass rate, class average.
    // ==================================================================

    async function refreshDashboardSummary() {
        const body = $('dashboardSummaryBody');
        if (!body) return;
        const seq = ++dashboardSeq;
        if (!window.TerminalReportDb || !window.TerminalReportDb.isReady()) {
            body.innerHTML = '<div class="text-muted text-center py-3">Database unavailable.</div>';
            return;
        }
        try {
            // Iter 20 fix (PERF-01): replaced N+1 (listBatches + listReportsForBatch per batch)
            // with a single SQL query that returns only the summary stats we need
            // (no subjects_json, logo_blob, or photo_blob loaded).
            const batchStats = await window.TerminalReportDb.getBatchSummaryStats();
            // Iter 31 audit fix (ASYNC-01): a newer refresh superseded this one.
            if (seq !== dashboardSeq) return;
            if (!batchStats.length) {
                body.innerHTML = '<div class="text-muted text-center py-3">No batches generated yet. Click "Start New Batch" to generate reports.</div>';
                return;
            }
            const summaries = batchStats.map(function (bs) {
                const total = bs.studentCount || 0;
                const passed = bs.passedCount || 0;
                // CRIT-14 fix: previously hardcoded to a dash with a comment saying
                // "could add a SQL AVG later". Now surfaced via getBatchSummaryStats().
                // Format to 1 decimal place for display; show 'n/a' only if there is no data.
                const avgPct = (bs.avgPct == null || !isFinite(bs.avgPct))
                    ? 'n/a'
                    : Number(bs.avgPct).toFixed(1);
                return {
                    className: bs.className,
                    year: bs.academicYear,
                    term: bs.academicTerm,
                    studentCount: total,
                    passRate: total > 0 ? ((passed / total) * 100).toFixed(0) : '0',
                    avgPct: avgPct,
                    passed: passed,
                    failed: total - passed
                };
            });
            // Render summary cards
            body.innerHTML = summaries.map(function (s) {
                const passColor = s.passRate >= 80 ? 'success' : (s.passRate >= 50 ? 'warning' : 'danger');
                return '<div class="dashboard-summary-card border rounded p-2 mb-2">' +
                    '<div class="d-flex justify-content-between align-items-center flex-wrap gap-2">' +
                        '<div>' +
                            '<div class="fw-bold">' + escapeHtml(s.className) + '</div>' +
                            '<div class="text-muted small">' + escapeHtml(s.year) + ' · ' + escapeHtml(s.term) + ' Term · ' + s.studentCount + ' students</div>' +
                        '</div>' +
                        '<div class="d-flex gap-3 align-items-center">' +
                            '<div class="text-center">' +
                                '<div class="fw-bold fs-5 text-' + passColor + '">' + s.passRate + '%</div>' +
                                '<div class="text-muted small">Pass Rate</div>' +
                            '</div>' +
                            '<div class="text-center">' +
                                '<div class="fw-bold fs-5">' + (s.avgPct === 'n/a' ? 'n/a' : s.avgPct + '%') + '</div>' +
                                '<div class="text-muted small">Class Avg</div>' +
                            '</div>' +
                            '<div class="text-center">' +
                                '<div class="fw-bold fs-5 text-success">' + s.passed + '</div>' +
                                '<div class="text-muted small">Passed</div>' +
                            '</div>' +
                            '<div class="text-center">' +
                                '<div class="fw-bold fs-5 text-danger">' + s.failed + '</div>' +
                                '<div class="text-muted small">Failed</div>' +
                            '</div>' +
                        '</div>' +
                    '</div>' +
                '</div>';
            }).join('');
        } catch (err) {
            console.error('[terminalreport] dashboard summary failed:', err);
            if (seq !== dashboardSeq) return;
            body.innerHTML = '<div class="text-danger text-center py-3">Failed to load summary.</div>';
        }
    }

    // ==================================================================
    // Iter 17: Student Profile (longitudinal history)
    // Shows all saved reports for a student, grouped by year/term.
    // ==================================================================

    // Iteration 32 (RACE-02): sequence token for the profile modal. Opening a
    // profile fires several awaited DB reads; without the token, a slow
    // profile A closed and replaced by a faster profile B could still have
    // its continuation write A's rows into the modal afterwards. Also the
    // DB-unavailable case used to return silently (a click that does nothing
    // and no message anywhere), which the checklist calls a console-only
    // failure; it now tells the user what happened.
    let profileSeq = 0;

    async function openStudentProfile(studentName) {
        if (!studentName) return;
        if (!window.TerminalReportDb || !window.TerminalReportDb.isReady()) {
            UI.alert('Database unavailable. Student profiles cannot be loaded right now.');
            return;
        }
        const seq = ++profileSeq;
        const body = $('spBody');
        const title = $('spTitle');
        if (!body || !title) return;
        title.textContent = 'Student Profile: ' + studentName;
        body.innerHTML = '<div class="text-muted text-center py-3">Loading reports…</div>';
        const overlay = $('studentProfileModal');
        overlay.style.display = 'flex';
        profileModalCtl.onOpen();
        try {
            const reports = await window.TerminalReportDb.searchReports({ studentName: studentName });
            if (seq !== profileSeq) return;   // a newer profile open superseded this one
            if (!reports.length) {
                body.innerHTML = '<div class="text-muted text-center py-3">No saved reports found for "' + escapeHtml(studentName) + '".</div>';
                return;
            }
            // Load full report data for each
            const fullReports = [];
            for (const r of reports) {
                const full = await window.TerminalReportDb.loadReport(r.id);
                if (full) fullReports.push(full);
            }
            if (seq !== profileSeq) return;   // re-check after the (slow) N reads
            // Render a compact history list
            body.innerHTML = '<div class="mb-3"><strong>' + fullReports.length + '</strong> report(s) found for <strong>' + escapeHtml(studentName) + '</strong></div>' +
                fullReports.map(function (r) {
                    const pct = r.summary && r.summary.percentage != null ? r.summary.percentage : '?';
                    const grade = r.summary && r.summary.overallGrade ? r.summary.overallGrade : '?';
                    const passed = r.summary && r.summary.passed;
                    const badgeClass = passed ? 'bg-success' : 'bg-danger';
                    return '<div class="border rounded p-2 mb-2">' +
                        '<div class="d-flex justify-content-between align-items-center flex-wrap gap-2">' +
                            '<div>' +
                                '<div class="fw-bold">' + escapeHtml(r.academicYear || '') + ' · ' + escapeHtml(r.academicTerm || '') + ' Term</div>' +
                                '<div class="text-muted small">' + escapeHtml(r.studentClass || '') + ' · Cert ' + escapeHtml(r.certificateNo || '') + '</div>' +
                            '</div>' +
                            '<div class="d-flex gap-2 align-items-center">' +
                                '<span class="badge ' + badgeClass + '">' + (passed ? 'PASS' : 'FAIL') + '</span>' +
                                '<span class="fw-bold">' + pct + '%</span>' +
                                '<span class="badge bg-primary">' + grade + '</span>' +
                                '<button type="button" class="btn btn-sm btn-outline-primary" data-action="view-from-profile" data-id="' + r.id + '"><i class="fas fa-eye"></i></button>' +
                            '</div>' +
                        '</div>' +
                    '</div>';
                }).join('');
            // Wire "view" buttons
            body.querySelectorAll('[data-action="view-from-profile"]').forEach(function (btn) {
                btn.addEventListener('click', function () {
                    // Iteration 32: close through closeStudentProfile (not a bare
                    // display toggle) so the Escape stack, focus restore and the
                    // stale-response token are all updated consistently.
                    closeStudentProfile();
                    viewSavedReport(btn.dataset.id);
                });
            });
        } catch (err) {
            console.error('[terminalreport] student profile failed:', err);
            if (seq !== profileSeq) return;
            body.innerHTML = '<div class="text-danger text-center py-3">Failed to load profile.</div>';
        }
    }

    // Iteration 32 (KEY-01 + SCROLL-01): shared lifecycle for the profile modal
    // (Escape close, focus move/restore, scroll reset), mirroring the viewer.
    const profileModalCtl = UI.wireModal($('studentProfileModal'), {
        close: closeStudentProfile,
        focusEl: function () { return $('spCloseBtn'); }
    });

    function closeStudentProfile() {
        $('studentProfileModal').style.display = 'none';
        $('spBody').innerHTML = '';
        profileModalCtl.onClose();
        // Iteration 32 (RACE-02): nothing may write into the closed modal.
        profileSeq++;
    }

    // ------------------------------------------------------------------
    // Init
    // ------------------------------------------------------------------
    function initMainApp() {
        // Iter 16: no single-report form to initialise.
        // The main dashboard has 3 buttons: Start New Batch, Saved Reports,
        // Admin & Manage: all wired below.

        // Saved Reports panel + viewer modal
        const loadBtn = $('loadSavedBtn');
        if (loadBtn) loadBtn.addEventListener('click', toggleSavedReportsPanel);
        initSavedReportsPanel();
        initSavedReportViewer();

        // Iter 17: Student Profile modal close button
        const spClose = $('spCloseBtn');
        if (spClose) spClose.addEventListener('click', closeStudentProfile);

        // Iter 17: Dashboard summary refresh button + initial load
        const refreshSummary = $('refreshSummaryBtn');
        if (refreshSummary) refreshSummary.addEventListener('click', refreshDashboardSummary);
        refreshDashboardSummary();

        // Initialise the persistence layer. This is best-effort; the UI still
        // works fully even if the DB fails to load.
        if (window.TerminalReportDb) {
            window.TerminalReportDb.init().then(function () {
                // Iter 31 audit fix (WF-01): the initial refreshDashboardSummary()
                // call above runs before DB init has finished, so on a slower load the
                // dashboard showed "Database unavailable." until the user clicked
                // Refresh manually. Re-render once init actually resolves.
                refreshDashboardSummary();
            }).catch(function (err) {
                console.error('[terminalreport] DB init failed; saving disabled:', err);
            });
        }

        // Initialise the backup layer (OPFS dir, etc.). Idempotent.
        if (window.TerminalReportBackup) {
            window.TerminalReportBackup.init().catch(function (err) {
                console.error('[terminalreport] TerminalReportBackup init failed; backup disabled:', err);
            });
        }

        // Wire up the batch wizard UI controller.
        // init() registers all event listeners; start() opens the wizard.
        if (window.TerminalReportBatchUI && typeof window.TerminalReportBatchUI.init === 'function') {
            window.TerminalReportBatchUI.init();
            const batchBtn = $('startBatchBtn');
            if (batchBtn) {
                batchBtn.addEventListener('click', function () {
                    window.TerminalReportBatchUI.start();
                });
            }
        }

        // Wire up the Admin UI controller.
        if (window.TerminalReportAdminUI && typeof window.TerminalReportAdminUI.init === 'function') {
            window.TerminalReportAdminUI.init();
            const adminBtn = $('adminBtn');
            if (adminBtn) {
                adminBtn.addEventListener('click', function () {
                    if (typeof window.TerminalReportAdminUI.populateClassDropdowns === 'function') {
                        window.TerminalReportAdminUI.populateClassDropdowns();
                    }
                    window.TerminalReportAdminUI.openAdmin();
                });
            }
        }
    }

    document.addEventListener('DOMContentLoaded', function () {
        if (window.TerminalReportAuthUI) {
            document.addEventListener('terminalreport:auth-complete', initMainApp, { once: true });
            window.TerminalReportAuthUI.start();
        } else {
            // Degraded mode (no auth module): init immediately
            initMainApp();
        }
    });

    // ------------------------------------------------------------------
    // Phase D: Expose generateReportHTML for batch-ui.js to reuse.
    // Same function, just made globally available via window.TerminalReportScript_*.
    // The data shape is { academyName, academicYear, ..., subjects, schoolLogoBytes, ... }.
    // ------------------------------------------------------------------
    window.TerminalReportScript_renderReportHTML = function (report, summary) {
        const data = {
            academyName: report.academyName,
            academicYear: report.academicYear,
            academicTerm: report.academicTerm,
            studentName: report.studentName,
            studentClass: report.studentClass,
            issueDate: report.issueDate,
            certificateNo: report.certificateNo,
            schoolLogo: null,
            studentPhoto: null,
            schoolLogoBytes: report.logoBlob,
            studentPhotoBytes: report.photoBlob,
            subjects: report.subjects
        };
        return generateReportHTML(data, summary || report.summary);
    };

    // Iter 17: expose openStudentProfile for external callers (e.g., saved report row click)
    window.TerminalReportScript_openStudentProfile = openStudentProfile;
    window.TerminalReportScript_refreshDashboardSummary = refreshDashboardSummary;
    // Iteration 32 (LEAK-01): let the batch wizard's preview + print flows
    // release the blob URLs that generateReportHTML creates for embedded
    // logo/photo bytes; those flows run outside this module's viewer where
    // revocation used to happen.
    window.TerminalReportScript_revokeReportObjectUrls = revokeAllObjectUrls;
    // Iter 20 fix: removed `window.TerminalReportScript_toOrdinal = toOrdinal;`, toOrdinal
    // is defined in db.js (not script.js), and db.js already exports it at line ~1490.
    // The bare reference caused ReferenceError at load time under 'use strict'.
})();
