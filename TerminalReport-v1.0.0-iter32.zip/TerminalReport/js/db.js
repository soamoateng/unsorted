/**
 * TerminalReport: persistence layer (Iteration 3; Iter 13 vendored sql.js)
 *
 * Stack:
 *   - sql.js 1.14.2 (vendored locally under vendor/sql.js/ since Iter 13), SQLite compiled to WASM
 *   - IndexedDB, used to persist the binary DB bytes between sessions
 *
 * Why sql.js + IndexedDB instead of @sqlite.org/sqlite-wasm + OPFS:
 *   - OPFS-backed SQLite WASM requires a Web Worker + self-hosted .wasm file
 *     + potentially COOP/COEP headers for SharedArrayBuffer (threaded build).
 *   - sql.js + IndexedDB works from file://, any static host, no headers,
 *     no worker. Same SQL surface.
 *   - Trade-off (honestly stated): sql.js loads the entire DB into memory.
 *     For a single school with hundreds of reports, this is well under 10MB.
 *     Upgrade to OPFS only if/when multi-school SaaS is in scope.
 *
 * Iter 13 note: the .wasm binary was previously loaded from cdnjs with an SRI
 * hash. It is now vendored under vendor/sql.js/sql-wasm.wasm (precached by the
 * service worker). Same-origin = integrity; tampering would require write
 * access to the project's own static folder. This makes the app fully offline-
 * capable on first load, no network fetch to cdnjs needed.
 *
 * Single Responsibility: this module owns ALL persistence. UI code in
 * script.js never touches sql.js or IndexedDB directly, it goes through
 * TerminalReportDb.saveReport / listReports / loadReport / deleteReport.
 *
 * Public API (window.TerminalReportDb):
 *   - init()                   → Promise<void> (idempotent)
 *   - saveReport(report)       → Promise<number> (returns new row id)
 *   - listReports()            → Promise<Array<{id, studentName, ...}>>
 *   - loadReport(id)           → Promise<Report|null>
 *   - deleteReport(id)         → Promise<void>
 *   - isReady()                → boolean
 *
 * Future upgrade path (DO NOT implement without user permission):
 *   Swap `sql.js` for `@sqlite.org/sqlite-wasm`, add a worker file, and
 *   move the IndexedDB-export call to OPFS sync access handles. Public
 *   API stays identical; only the internals change.
 */
(function () {
    'use strict';

    // Iter 18: ordinal formatter: 1→"1st", 2→"2nd", 3→"3rd", 11→"11th", 21→"21st"
    function toOrdinal(n) {
        n = parseInt(n, 10);
        if (!Number.isFinite(n) || n < 1) return String(n);
        const s = ['th', 'st', 'nd', 'rd'];
        const v = n % 100;
        return n + (s[(v - 20) % 10] || s[v] || s[0]);
    }

    // Iter 18: format a student's full name from surname + firstName
    function getStudentFullName(student) {
        if (!student) return '';
        if (student.surname != null || student.firstName != null) {
            return ((student.surname || '') + ' ' + (student.firstName || '')).trim();
        }
        return student.name || '';
    }

    // Iter 13: sql.js is vendored locally under vendor/sql.js/, no longer loaded
    // from cdnjs. Path is relative to index.html (which lives at the project root),
    // so this resolves correctly regardless of where the app is hosted (including
    // file://, though crypto.subtle still needs http(s) or localhost).
    const SQL_JS_VENDOR_BASE = 'vendor/sql.js';
    const IDB_NAME = 'terminalreport-db';
    const IDB_STORE = 'kv';
    const IDB_KEY = 'sqlite-db-bytes';

    let SQL = null;    // sql.js module instance
    let db = null;     // SQLite Database instance
    let initPromise = null;

    // ------------------------------------------------------------------
    // Initialisation
    // ------------------------------------------------------------------
    async function init() {
        // Idempotent, concurrent callers share the same promise.
        if (initPromise) return initPromise;
        initPromise = doInit().catch(function (err) {
            initPromise = null; // allow retry on failure
            throw err;
        });
        return initPromise;
    }

    async function doInit() {
        if (typeof initSqlJs !== 'function') {
            throw new Error('sql.js failed to load. Check your network connection.');
        }
        if (!SQL) {
            SQL = await initSqlJs({ locateFile: function (file) { return SQL_JS_VENDOR_BASE + '/' + file; } });
        }
        const bytes = await loadFromIDB();
        if (bytes) {
            db = new SQL.Database(new Uint8Array(bytes));
            // Iter 18: run schema migration on existing DBs too (not just new ones).
            // migrateStudentsSchema() is idempotent, try/catch per ALTER statement.
            migrateStudentsSchema();
        } else {
            db = new SQL.Database();
            createSchema();
            await persist();
        }
    }

    function isReady() {
        return db !== null;
    }

    function createSchema() {
        // KISS: reports table for individual student report cards (Iter 3+);
        // auth table (Phase B); batches table (Phase D) for batch metadata.
        // Full normalisation (classes/students/subjects as their own tables)
        // is Phase E scope, for now, batch metadata + reports is enough.
        db.run(
            'CREATE TABLE IF NOT EXISTS reports (' +
                'id INTEGER PRIMARY KEY AUTOINCREMENT, ' +
                'academy_name TEXT NOT NULL, ' +
                'academic_year TEXT, ' +
                'academic_term TEXT, ' +
                'student_name TEXT, ' +
                'student_class TEXT, ' +
                'issue_date TEXT, ' +
                'certificate_no TEXT, ' +
                'subjects_json TEXT NOT NULL, ' +
                'summary_json TEXT NOT NULL, ' +
                'logo_blob BLOB, ' +
                'photo_blob BLOB, ' +
                'batch_id INTEGER, ' +            // Phase D: links to batches table
                'student_id_in_batch INTEGER, ' + // Phase D: student roll# within batch
                'class_rank INTEGER, ' +           // Phase D: 1-based, ties allowed
                'created_at TEXT DEFAULT (datetime(\'now\'))' +
            ');'
        );
        db.run(
            'CREATE TABLE IF NOT EXISTS auth (' +
                'id INTEGER PRIMARY KEY CHECK (id = 1), ' +
                'school_name TEXT NOT NULL, ' +
                'logo_blob BLOB, ' +
                'pin_hash TEXT NOT NULL, ' +
                'pin_salt TEXT NOT NULL, ' +
                'security_question TEXT NOT NULL, ' +
                'security_answer_hash TEXT NOT NULL, ' +
                'security_answer_salt TEXT NOT NULL, ' +
                'app_uuid TEXT NOT NULL, ' +
                'created_at TEXT DEFAULT (datetime(\'now\')), ' +
                'updated_at TEXT DEFAULT (datetime(\'now\'))' +
            ');'
        );
        // Phase D: batch metadata. Each batch = one Generate click that
        // produces N student reports. The reports themselves are stored in
        // the `reports` table with batch_id FK.
        db.run(
            'CREATE TABLE IF NOT EXISTS batches (' +
                'id INTEGER PRIMARY KEY AUTOINCREMENT, ' +
                'academy_name TEXT NOT NULL, ' +
                'academic_year TEXT NOT NULL, ' +
                'academic_term TEXT NOT NULL, ' +
                'class_name TEXT NOT NULL, ' +
                'term TEXT NOT NULL, ' +             // "1st" / "2nd" / "3rd"
                'student_count INTEGER NOT NULL, ' +
                'subject_count INTEGER NOT NULL, ' +
                'certificate_prefix TEXT, ' +         // e.g., "EA-2425-"
                'created_at TEXT DEFAULT (datetime(\'now\')), ' +
                'UNIQUE (academic_year, class_name, academic_term)' +
            ');'
        );
        // Phase E: normalised entity tables for the Admin UI.
        // These coexist with the `reports` + `batches` tables (which store
        // rendered output). The entity tables are the source of truth for
        // classes, students, subjects, grading scales, and academic years.
        db.run(
            'CREATE TABLE IF NOT EXISTS academic_years (' +
                'id INTEGER PRIMARY KEY AUTOINCREMENT, ' +
                'year_label TEXT NOT NULL UNIQUE, ' +   // e.g., "2025-2026"
                'created_at TEXT DEFAULT (datetime(\'now\'))' +
            ');'
        );
        db.run(
            'CREATE TABLE IF NOT EXISTS grading_scales (' +
                'id INTEGER PRIMARY KEY AUTOINCREMENT, ' +
                'name TEXT NOT NULL UNIQUE, ' +          // e.g., "Default 7-Band"
                'is_default INTEGER DEFAULT 0, ' +       // 1 = the default scale
                'created_at TEXT DEFAULT (datetime(\'now\'))' +
            ');'
        );
        db.run(
            'CREATE TABLE IF NOT EXISTS grading_bands (' +
                'id INTEGER PRIMARY KEY AUTOINCREMENT, ' +
                'grading_scale_id INTEGER NOT NULL, ' +
                'grade_letter TEXT NOT NULL, ' +         // e.g., "A+"
                'min_percentage INTEGER NOT NULL, ' +    // e.g., 90
                'description TEXT, ' +                   // e.g., "Outstanding"
                'sort_order INTEGER DEFAULT 0, ' +
                'FOREIGN KEY (grading_scale_id) REFERENCES grading_scales(id) ON DELETE CASCADE' +
            ');'
        );
        db.run(
            'CREATE TABLE IF NOT EXISTS classes (' +
                'id INTEGER PRIMARY KEY AUTOINCREMENT, ' +
                'name TEXT NOT NULL, ' +                 // e.g., "Grade 10 - Section A"
                'academic_year_id INTEGER, ' +           // FK to academic_years
                'grading_scale_id INTEGER, ' +           // FK to grading_scales (nullable = use default)
                'created_at TEXT DEFAULT (datetime(\'now\')), ' +
                'FOREIGN KEY (academic_year_id) REFERENCES academic_years(id) ON DELETE RESTRICT, ' +
                'FOREIGN KEY (grading_scale_id) REFERENCES grading_scales(id) ON DELETE SET NULL, ' +
                'UNIQUE (name, academic_year_id)' +      // same class name OK across different years
            ');'
        );
        db.run(
            'CREATE TABLE IF NOT EXISTS students (' +
                'id INTEGER PRIMARY KEY AUTOINCREMENT, ' +
                'surname TEXT, ' +                      // Iter 18: split from name
                'first_name TEXT, ' +                   // Iter 18: split from name
                'name TEXT NOT NULL, ' +                // Iter 18: kept for backwards compat (surname + ' ' + first_name)
                'dob TEXT, ' +                            // YYYY-MM-DD
                'gender TEXT, ' +                         // "Male" / "Female" / "Other" / NULL
                'class_id INTEGER NOT NULL, ' +
                'created_at TEXT DEFAULT (datetime(\'now\')), ' +
                'FOREIGN KEY (class_id) REFERENCES classes(id) ON DELETE RESTRICT' +
            ');'
        );
        db.run(
            'CREATE TABLE IF NOT EXISTS subjects (' +
                'id INTEGER PRIMARY KEY AUTOINCREMENT, ' +
                'code TEXT, ' +
                'name TEXT NOT NULL, ' +
                'max_marks INTEGER DEFAULT 100, ' +
                'min_marks INTEGER DEFAULT 35, ' +        // pass marks
                'class_id INTEGER NOT NULL, ' +
                'created_at TEXT DEFAULT (datetime(\'now\')), ' +
                'FOREIGN KEY (class_id) REFERENCES classes(id) ON DELETE RESTRICT, ' +
                'UNIQUE (class_id, name)' +               // no duplicate subject names within a class
            ');'
        );
        // Iter 12 (roadmap #2): per-student marks per subject.
        // Lets a teacher enter marks for an existing class roster at the time
        // a new subject is added (Admin → Manage Class → Subjects → Add Subject).
        // Cascade on both sides: deleting the subject OR the student removes
        // the dangling mark. UNIQUE(subject_id, student_id) makes UPSERT trivial.
        // Marks are stored DECIMAL(5,2), same precision as the batch wizard's
        // internal float, sufficient for half-mark granularity (e.g. 78.5/100).
        db.run(
            'CREATE TABLE IF NOT EXISTS subject_marks (' +
                'id INTEGER PRIMARY KEY AUTOINCREMENT, ' +
                'subject_id INTEGER NOT NULL, ' +
                'student_id INTEGER NOT NULL, ' +
                'obtained_marks REAL DEFAULT 0, ' +     // 0..subject.max_marks
                'is_absent INTEGER DEFAULT 0, ' +       // 0 = present, 1 = absent (treated as 0)
                'updated_at TEXT DEFAULT (datetime(\'now\')), ' +
                'FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE CASCADE, ' +
                'FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE, ' +
                'UNIQUE (subject_id, student_id)' +
            ');'
        );
        // Iter 19: migration: add surname + first_name if missing, drop class_position
        migrateStudentsSchema();
        // Seed default grading scale if none exists
        seedDefaultGradingScale();
    }

    /** Iter 18/19, idempotent schema migration for the students table. */
    function migrateStudentsSchema() {
        // Iter 18: add surname + first_name columns (if not already present)
        try { db.run('ALTER TABLE students ADD COLUMN surname TEXT;'); } catch (_) {}
        try { db.run('ALTER TABLE students ADD COLUMN first_name TEXT;'); } catch (_) {}
        // Backfill: split existing name into surname + first_name if they're NULL
        try {
            db.run("UPDATE students SET surname = TRIM(SUBSTR(name, 1, INSTR(name, ' ') - 1)), first_name = TRIM(SUBSTR(name, INSTR(name, ' ') + 1)) WHERE surname IS NULL AND name LIKE '% %';");
            db.run("UPDATE students SET surname = name, first_name = '' WHERE surname IS NULL AND (name NOT LIKE '% %' OR name IS NULL);");
        } catch (_) {}
        // Iter 19: drop class_position column if it still exists (SQLite 3.35+ supports DROP COLUMN)
        try { db.run('ALTER TABLE students DROP COLUMN class_position;'); } catch (_) {}
    }

    /** Phase E: seed the default 7-band grading scale on first DB init. */
    function seedDefaultGradingScale() {
        try {
            const res = db.exec('SELECT COUNT(*) AS c FROM grading_scales;');
            const count = res.length ? res[0].values[0][0] : 0;
            if (count > 0) return;
            db.run('INSERT INTO grading_scales (name, is_default) VALUES (?, 1);', ['Default 7-Band']);
            const idRes = db.exec('SELECT last_insert_rowid() AS id;');
            const scaleId = idRes.length ? idRes[0].values[0][0] : 0;
            const bands = [
                ['A+', 90, 'Outstanding'],
                ['A',  80, 'Excellent'],
                ['B+', 70, 'Very Good'],
                ['B',  60, 'Good'],
                ['C',  50, 'Average'],
                ['D',  40, 'Below Average'],
                ['F',   0, 'Fail']
            ];
            const stmt = db.prepare(
                'INSERT INTO grading_bands (grading_scale_id, grade_letter, min_percentage, description, sort_order) ' +
                'VALUES (?, ?, ?, ?, ?);'
            );
            bands.forEach(function (b, i) {
                stmt.run([scaleId, b[0], b[1], b[2], i]);
            });
            stmt.free();
        } catch (e) {
            console.error('[db] seedDefaultGradingScale failed:', e);
        }
    }

    // ------------------------------------------------------------------
    // Persistence, export DB bytes to IndexedDB after every write.
    // Phase C: also fires TerminalReportBackup.autoBackup() if enabled (writes a
    // signed copy to OPFS, so the auto-backup is always fresh,
    // not just at app close, which can't reliably run async work).
    // ------------------------------------------------------------------

    /**
     * BLIND-11 fix (Iter 24 audit): tolerant JSON parse for report rows.
     * getReport()/listReports() deserialized subjects_json / summary_json with
     * bare JSON.parse. Those columns are written only by this app, but a
     * hand-edited or partially-corrupt restored backup would make parse throw
     * and hard-brick the report detail/list views with no recovery path (the
     * batch path at getBatchSummaryStats already parsed defensively, this
     * helper makes the row readers match that convention). Corrupt JSON now
     * degrades to the same shape as an empty report instead of throwing.
     *
     * NOTE: `fallback` is an actual [] / {} value (NOT a JSON string literal),
     * its array-ness defines the expected shape of the stored JSON.
     */
    function safeParseJson(text, fallback) {
        let v = null;
        try { v = (text == null || text === '') ? null : JSON.parse(text); } catch (_) { v = null; }
        // Only accept objects/arrays that match the fallback's shape; reject
        // JSON scalars ("42", "\"str\"", null) and cross-shape payloads.
        if (v === null || typeof v !== 'object') return fallback;
        if (Array.isArray(fallback) !== Array.isArray(v)) return fallback;
        return v;
    }

    function persist() {
        if (!db) return Promise.resolve();
        // Iter 20 fix (PERF-02): db.export() is called ONCE here. The bytes
        // are passed to both IndexedDB (saveToIDB) and autoBackup (if enabled).
        // Previously, autoBackup() called db.export() AGAIN internally,
        // causing a double serialization of the entire DB on every save.
        const bytes = db.export();
        // Copy the buffer for IndexedDB (avoid holding the typed array view).
        const idbPromise = saveToIDB(bytes.buffer.slice(0));
        // Fire-and-forget auto-backup using the SAME bytes, no re-export needed.
        if (window.TerminalReportBackup && window.TerminalReportBackup.isAutoBackupEnabled()) {
            try { window.TerminalReportBackup.autoBackupFromBytes(bytes); } catch (e) {
                console.error('[db] auto-backup hook failed:', e);
            }
        }
        return idbPromise;
    }

    // ------------------------------------------------------------------
    // CRUD, public API
    // ------------------------------------------------------------------

    /**
     * @param {Object} report
     *   { academyName, academicYear, academicTerm, studentName, studentClass,
     *     issueDate, certificateNo, subjects: Array, summary: Object,
     *     logoBlob: Uint8Array|null, photoBlob: Uint8Array|null }
     * @returns {Promise<number>} new row id
     */
    async function saveReport(report) {
        if (!db) await init();
        const stmt = db.prepare(
            'INSERT INTO reports ' +
            '(academy_name, academic_year, academic_term, student_name, student_class, ' +
             'issue_date, certificate_no, subjects_json, summary_json, logo_blob, photo_blob) ' +
            'VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);'
        );
        stmt.run([
            report.academyName,
            report.academicYear,
            report.academicTerm,
            report.studentName,
            report.studentClass,
            report.issueDate,
            report.certificateNo,
            JSON.stringify(report.subjects),
            JSON.stringify(report.summary),
            report.logoBlob || null,
            report.photoBlob || null
        ]);
        stmt.free();
        // Get last_insert_rowid() BEFORE persist, persist() calls db.export()
        // which may reset the SQL connection's last-insert state.
        const res = db.exec('SELECT last_insert_rowid() AS id;');
        const id = res.length ? res[0].values[0][0] : 0;
        await persist();
        return id;
    }

    /**
     * List saved reports, newest first. Equivalent to `searchReports({})`.
     * Kept for back-compat (Iter 3 callers in script.js still use it).
     * @returns {Promise<Array>}
     */
    async function listReports() {
        return searchReports({});
    }

    /**
     * Iteration 11 (roadmap #1): Search saved reports by student name
     * substring + optional exact class filter.
     *
     * @param {Object} filter  { studentName?: string, className?: string }
     *   - studentName: case-insensitive substring match (SQL INSTR on
     *     LOWER(student_name) vs the lowercased term, INSTR treats its
     *     second arg as a literal substring, never a LIKE pattern, so
     *     characters like % or _ in the user's input are matched verbatim
     *     with no escaping required).
     *   - className:  exact match (only reports whose student_class equals it)
     *   - Either may be empty / undefined → that filter is skipped.
     * @returns {Promise<Array>} same shape as listReports(), newest first.
     */
    async function searchReports(filter) {
        if (!db) await init();
        filter = filter || {};
        const where = [];
        const params = [];
        if (filter.studentName && String(filter.studentName).trim()) {
            // INSTR returns the 1-based index of the substring, or 0 if not
            // found. Both sides are lowercased so the match is case-insensitive.
            // (SQLite's INSTR is binary on TEXT, but lowercasing both sides
            // gives us case-insensitive matching without LOWER() index concerns
            // (that distinction is irrelevant here, since we scan the whole table.)
            where.push('INSTR(LOWER(student_name), ?) > 0');
            params.push(String(filter.studentName).trim().toLowerCase());
        }
        if (filter.className && String(filter.className).trim()) {
            where.push('student_class = ?');
            params.push(String(filter.className).trim());
        }
        const whereSql = where.length ? ('WHERE ' + where.join(' AND ')) : '';
        const sql =
            'SELECT id, student_name, student_class, academic_year, academic_term, ' +
                   'certificate_no, issue_date, created_at ' +
            'FROM reports ' + whereSql + ' ' +
            'ORDER BY created_at DESC, id DESC;';
        const res = db.exec(sql, params);
        if (!res.length) return [];
        const cols = res[0].columns;
        return res[0].values.map(function (row) {
            const obj = {};
            cols.forEach(function (c, i) { obj[c] = row[i]; });
            return {
                id: obj.id,
                studentName: obj.student_name,
                studentClass: obj.student_class,
                academicYear: obj.academic_year,
                academicTerm: obj.academic_term,
                certificateNo: obj.certificate_no,
                issueDate: obj.issue_date,
                createdAt: obj.created_at
            };
        });
    }

    /**
     * Iteration 11 (roadmap #1): Distinct student_class values that
     * appear in the saved reports table, alphabetically sorted.
     *
     * Used to populate the class-filter dropdown. Reads from `reports`
     * (rendered historical output), NOT from the Phase E `classes` table,
     * because the saved-report class string is free-text that may predate
     * or diverge from any managed class. Filtering on what actually appears
     * in saved reports guarantees the dropdown never offers a class with
     * zero matching rows.
     *
     * @returns {Promise<Array<string>>} e.g. ["Grade 10 - Section A", "Grade 11"]
     */
    async function listReportClasses() {
        if (!db) await init();
        const res = db.exec(
            'SELECT DISTINCT student_class FROM reports ' +
            'WHERE student_class IS NOT NULL AND TRIM(student_class) <> \'\' ' +
            'ORDER BY student_class COLLATE NOCASE ASC;'
        );
        if (!res.length) return [];
        return res[0].values.map(function (row) { return row[0]; });
    }

    /**
     * @param {number} id
     * @returns {Promise<Object|null>} full report including subjects/summary
     */
    async function loadReport(id) {
        if (!db) await init();
        const stmt = db.prepare('SELECT * FROM reports WHERE id = ?;');
        stmt.bind([id]);
        let result = null;
        if (stmt.step()) {
            const row = stmt.getAsObject();
            result = {
                id: row.id,
                academyName: row.academy_name,
                academicYear: row.academic_year,
                academicTerm: row.academic_term,
                studentName: row.student_name,
                studentClass: row.student_class,
                issueDate: row.issue_date,
                certificateNo: row.certificate_no,
                subjects: safeParseJson(row.subjects_json, []),
                summary: safeParseJson(row.summary_json, {}),
                logoBlob: row.logo_blob ? new Uint8Array(row.logo_blob) : null,
                photoBlob: row.photo_blob ? new Uint8Array(row.photo_blob) : null,
                createdAt: row.created_at
            };
        }
        stmt.free();
        return result;
    }

    /** @param {number} id */
    async function deleteReport(id) {
        if (!db) await init();
        db.run('DELETE FROM reports WHERE id = ?;', [id]);
        await persist();
    }

    // ------------------------------------------------------------------
    // Phase B: auth table CRUD. Singleton row (id=1).
    // ------------------------------------------------------------------

    /** Save the auth row (replaces any existing row). Called once at setup. */
    async function saveAuth(authRow) {
        if (!db) await init();
        db.run('DELETE FROM auth WHERE id = 1;'); // replace
        const stmt = db.prepare(
            'INSERT INTO auth ' +
            '(id, school_name, logo_blob, pin_hash, pin_salt, security_question, ' +
             'security_answer_hash, security_answer_salt, app_uuid) ' +
            'VALUES (1, ?, ?, ?, ?, ?, ?, ?, ?);'
        );
        stmt.run([
            authRow.schoolName,
            authRow.logoBlob || null,
            authRow.pinHash,
            authRow.pinSalt,
            authRow.securityQuestion,
            authRow.securityAnswerHash,
            authRow.securityAnswerSalt,
            authRow.appUuid
        ]);
        stmt.free();
        await persist();
    }

    /** Update only the PIN-related fields (after PIN change or recovery). */
    async function updatePin(pinHash, pinSalt) {
        if (!db) await init();
        db.run(
            'UPDATE auth SET pin_hash = ?, pin_salt = ?, updated_at = datetime(\'now\') WHERE id = 1;',
            [pinHash, pinSalt]
        );
        await persist();
    }

    /**
     * BLIND-8 fix (Iter 23): update only the security-answer fields. Used by
     * auth.js recover() to transparently upgrade a pre-Iter-20 legacy answer
     * hash (single SHA-256) to PBKDF2 after a successful recovery, mirrors
     * updatePin() exactly (same statement shape, same persist() ordering).
     */
    async function updateSecurityAnswer(answerHash, answerSalt) {
        if (!db) await init();
        db.run(
            'UPDATE auth SET security_answer_hash = ?, security_answer_salt = ?, updated_at = datetime(\'now\') WHERE id = 1;',
            [answerHash, answerSalt]
        );
        await persist();
    }

    /** Load the auth row, or null if not configured. */
    async function loadAuth() {
        if (!db) await init();
        const res = db.exec('SELECT * FROM auth WHERE id = 1;');
        if (!res.length) return null;
        const row = res[0].values[0];
        const cols = res[0].columns;
        const obj = {};
        cols.forEach(function (c, i) { obj[c] = row[i]; });
        return {
            schoolName: obj.school_name,
            logoBlob: obj.logo_blob ? new Uint8Array(obj.logo_blob) : null,
            pinHash: obj.pin_hash,
            pinSalt: obj.pin_salt,
            securityQuestion: obj.security_question,
            securityAnswerHash: obj.security_answer_hash,
            securityAnswerSalt: obj.security_answer_salt,
            appUuid: obj.app_uuid,
            createdAt: obj.created_at,
            updatedAt: obj.updated_at
        };
    }

    /** Update school_name + logo_blob only (after settings change). */
    async function updateSchoolInfo(schoolName, logoBlob) {
        if (!db) await init();
        db.run(
            'UPDATE auth SET school_name = ?, logo_blob = ?, updated_at = datetime(\'now\') WHERE id = 1;',
            [schoolName, logoBlob || null]
        );
        await persist();
    }

    // ------------------------------------------------------------------
    // Phase D: batch operations
    // ------------------------------------------------------------------

    /**
     * Find an existing batch by (academic_year, class_name, academic_term).
     * Used for the "reports already exist" detection before regeneration.
     * Returns the batch row, or null.
     */
    async function findBatch(academicYear, className, academicTerm) {
        if (!db) await init();
        const res = db.exec(
            'SELECT id, academy_name, academic_year, academic_term, class_name, term, ' +
                   'student_count, subject_count, certificate_prefix, created_at ' +
            'FROM batches WHERE academic_year = ? AND class_name = ? AND academic_term = ? ' +
            'LIMIT 1;',
            [academicYear, className, academicTerm]
        );
        if (!res.length) return null;
        const cols = res[0].columns;
        const row = res[0].values[0];
        const obj = {};
        cols.forEach(function (c, i) { obj[c] = row[i]; });
        return {
            id: obj.id,
            academyName: obj.academy_name,
            academicYear: obj.academic_year,
            academicTerm: obj.academic_term,
            className: obj.class_name,
            term: obj.term,
            studentCount: obj.student_count,
            subjectCount: obj.subject_count,
            certificatePrefix: obj.certificate_prefix,
            createdAt: obj.created_at
        };
    }

    /**
     * Save a batch + all its reports in one transaction.
     * If a batch already exists for the same (year, class, term), delete it first
     * (and its reports), this is the "regenerate and replace" path.
     *
     * @param {Object} batchInput
     *   { academyName, academicYear, academicTerm, className, term,
     *     studentCount, subjectCount, certificatePrefix, reports: Array }
     *   where each report is the shape accepted by saveReport (Iter 3) PLUS:
     *     { studentIdInBatch, classRank }
     * @returns {Promise<number>} the new batch id
     */
    async function saveBatch(batchInput) {
        if (!db) await init();
        db.run('BEGIN TRANSACTION;');
        try {
            // Replace existing batch if any (cascade delete reports)
            db.run(
                'DELETE FROM reports WHERE academic_year = ? AND student_class = ? AND academic_term = ?;',
                [batchInput.academicYear, batchInput.className, batchInput.academicTerm]
            );
            db.run(
                'DELETE FROM batches WHERE academic_year = ? AND class_name = ? AND academic_term = ?;',
                [batchInput.academicYear, batchInput.className, batchInput.academicTerm]
            );

            // Insert batch row
            const stmt = db.prepare(
                'INSERT INTO batches ' +
                '(academy_name, academic_year, academic_term, class_name, term, ' +
                 'student_count, subject_count, certificate_prefix) ' +
                'VALUES (?, ?, ?, ?, ?, ?, ?, ?);'
            );
            stmt.run([
                batchInput.academyName,
                batchInput.academicYear,
                batchInput.academicTerm,
                batchInput.className,
                batchInput.term,
                batchInput.studentCount,
                batchInput.subjectCount,
                batchInput.certificatePrefix || null
            ]);
            stmt.free();
            const batchIdRes = db.exec('SELECT last_insert_rowid() AS id;');
            const batchId = batchIdRes.length ? batchIdRes[0].values[0][0] : 0;

            // Insert each report row, linking to batchId
            const reportStmt = db.prepare(
                'INSERT INTO reports ' +
                '(academy_name, academic_year, academic_term, student_name, student_class, ' +
                 'issue_date, certificate_no, subjects_json, summary_json, logo_blob, photo_blob, ' +
                 'batch_id, student_id_in_batch, class_rank) ' +
                'VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);'
            );
            (batchInput.reports || []).forEach(function (r) {
                reportStmt.run([
                    r.academyName,
                    r.academicYear,
                    r.academicTerm,
                    r.studentName,
                    r.studentClass,
                    r.issueDate,
                    r.certificateNo,
                    JSON.stringify(r.subjects),
                    JSON.stringify(r.summary),
                    r.logoBlob || null,
                    r.photoBlob || null,
                    batchId,
                    r.studentIdInBatch || null,
                    r.classRank || null
                ]);
            });
            reportStmt.free();

            db.run('COMMIT;');
            await persist();
            return batchId;
        } catch (e) {
            // Roll back on any error; this preserves atomic transaction semantics
            try { db.run('ROLLBACK;'); } catch (_) { /* ignore */ }
            throw e;
        }
    }

    /** List all batches, newest first. */
    async function listBatches() {
        if (!db) await init();
        const res = db.exec(
            'SELECT id, academy_name, academic_year, academic_term, class_name, term, ' +
                   'student_count, subject_count, certificate_prefix, created_at ' +
            'FROM batches ORDER BY created_at DESC, id DESC;'
        );
        if (!res.length) return [];
        const cols = res[0].columns;
        return res[0].values.map(function (row) {
            const obj = {};
            cols.forEach(function (c, i) { obj[c] = row[i]; });
            return {
                id: obj.id,
                academyName: obj.academy_name,
                academicYear: obj.academic_year,
                academicTerm: obj.academic_term,
                className: obj.class_name,
                term: obj.term,
                studentCount: obj.student_count,
                subjectCount: obj.subject_count,
                certificatePrefix: obj.certificate_prefix,
                createdAt: obj.created_at
            };
        });
    }

    /** Get all reports for a batch. */
    async function listReportsForBatch(batchId) {
        if (!db) await init();
        const stmt = db.prepare(
            'SELECT * FROM reports WHERE batch_id = ? ORDER BY student_id_in_batch ASC, class_rank ASC;'
        );
        stmt.bind([batchId]);
        const reports = [];
        while (stmt.step()) {
            const row = stmt.getAsObject();
            reports.push({
                id: row.id,
                academyName: row.academy_name,
                academicYear: row.academic_year,
                academicTerm: row.academic_term,
                studentName: row.student_name,
                studentClass: row.student_class,
                issueDate: row.issue_date,
                certificateNo: row.certificate_no,
                subjects: safeParseJson(row.subjects_json, []),
                summary: safeParseJson(row.summary_json, {}),
                logoBlob: row.logo_blob ? new Uint8Array(row.logo_blob) : null,
                photoBlob: row.photo_blob ? new Uint8Array(row.photo_blob) : null,
                batchId: row.batch_id,
                studentIdInBatch: row.student_id_in_batch,
                classRank: row.class_rank,
                createdAt: row.created_at
            });
        }
        stmt.free();
        return reports;
    }

    /** Delete a batch + all its reports (cascade). */
    async function deleteBatch(batchId) {
        if (!db) await init();
        db.run('DELETE FROM reports WHERE batch_id = ?;', [batchId]);
        db.run('DELETE FROM batches WHERE id = ?;', [batchId]);
        await persist();
    }

    /**
     * Look up subjects + students from prior reports for a class.
     * Used by wizard Steps 2 + 3 to pre-fill if user has saved reports
     * for this class before.
     * Returns { subjects: Array, students: Array } or empty arrays.
     */
    async function getPrefillForClass(className) {
        if (!db) await init();
        const res = db.exec(
            'SELECT subjects_json, student_name FROM reports ' +
            'WHERE student_class = ? ORDER BY id DESC LIMIT 1;',
            [className]
        );
        if (!res.length) return { subjects: [], students: [] };
        const cols = res[0].columns;
        const row = res[0].values[0];
        const obj = {};
        cols.forEach(function (c, i) { obj[c] = row[i]; });
        let subjects = [];
        try { subjects = JSON.parse(obj.subjects_json || '[]'); } catch (_) {}
        // Get all student names for this class (distinct)
        const studentsRes = db.exec(
            'SELECT DISTINCT student_name FROM reports WHERE student_class = ? ORDER BY student_name ASC;',
            [className]
        );
        const students = studentsRes.length ? studentsRes[0].values.map(function (r) {
            return { name: r[0] };
        }) : [];
        return { subjects: subjects, students: students };
    }

    // ------------------------------------------------------------------
    // Phase E: Admin entity CRUD (academic_years, grading_scales,
    // grading_bands, classes, students, subjects)
    // ------------------------------------------------------------------

    // --- Academic Years ---

    async function listAcademicYears() {
        if (!db) await init();
        const res = db.exec(
            'SELECT y.id, y.year_label, y.created_at, ' +
                   '(SELECT COUNT(*) FROM classes c WHERE c.academic_year_id = y.id) AS class_count ' +
            'FROM academic_years y ORDER BY y.year_label DESC;'
        );
        if (!res.length) return [];
        const cols = res[0].columns;
        return res[0].values.map(function (row) {
            const obj = {};
            cols.forEach(function (c, i) { obj[c] = row[i]; });
            return {
                id: obj.id,
                yearLabel: obj.year_label,
                classCount: obj.class_count,
                createdAt: obj.created_at
            };
        });
    }

    async function addAcademicYear(yearLabel) {
        if (!db) await init();
        if (!yearLabel || !yearLabel.trim()) throw new Error('Year label is required');
        db.run('INSERT INTO academic_years (year_label) VALUES (?);', [yearLabel.trim()]);
        const res = db.exec('SELECT last_insert_rowid() AS id;');
        const id = res.length ? res[0].values[0][0] : 0;
        await persist();
        return id;
    }

    async function deleteAcademicYear(id) {
        if (!db) await init();
        // Check constraint: no classes for this year
        const res = db.exec('SELECT COUNT(*) AS c FROM classes WHERE academic_year_id = ?;', [id]);
        const count = res.length ? res[0].values[0][0] : 0;
        if (count > 0) {
            throw new Error('Cannot delete: ' + count + ' class(es) exist for this academic year. Delete or move them first.');
        }
        db.run('DELETE FROM academic_years WHERE id = ?;', [id]);
        await persist();
    }

    // --- Grading Scales ---

    async function listGradingScales() {
        if (!db) await init();
        const res = db.exec(
            'SELECT s.id, s.name, s.is_default, s.created_at, ' +
                   '(SELECT COUNT(*) FROM classes c WHERE c.grading_scale_id = s.id) AS class_count ' +
            'FROM grading_scales s ORDER BY s.is_default DESC, s.name ASC;'
        );
        if (!res.length) return [];
        const cols = res[0].columns;
        const scales = res[0].values.map(function (row) {
            const obj = {};
            cols.forEach(function (c, i) { obj[c] = row[i]; });
            return {
                id: obj.id,
                name: obj.name,
                isDefault: !!obj.is_default,
                classCount: obj.class_count,
                createdAt: obj.created_at
            };
        });
        // Load bands for each scale
        for (let i = 0; i < scales.length; i++) {
            scales[i].bands = await listGradingBands(scales[i].id);
        }
        return scales;
    }

    async function listGradingBands(scaleId) {
        const res = db.exec(
            'SELECT id, grade_letter, min_percentage, description, sort_order ' +
            'FROM grading_bands WHERE grading_scale_id = ? ORDER BY min_percentage DESC, sort_order ASC;',
            [scaleId]
        );
        if (!res.length) return [];
        const cols = res[0].columns;
        return res[0].values.map(function (row) {
            const obj = {};
            cols.forEach(function (c, i) { obj[c] = row[i]; });
            return {
                id: obj.id,
                gradeLetter: obj.grade_letter,
                minPercentage: obj.min_percentage,
                description: obj.description,
                sortOrder: obj.sort_order
            };
        });
    }

    async function getGradingScale(id) {
        if (!db) await init();
        const res = db.exec(
            'SELECT id, name, is_default, created_at FROM grading_scales WHERE id = ?;',
            [id]
        );
        if (!res.length) return null;
        const cols = res[0].columns;
        const row = res[0].values[0];
        const obj = {};
        cols.forEach(function (c, i) { obj[c] = row[i]; });
        return {
            id: obj.id,
            name: obj.name,
            isDefault: !!obj.is_default,
            createdAt: obj.created_at,
            bands: await listGradingBands(id)
        };
    }

    async function getDefaultGradingScale() {
        if (!db) await init();
        const res = db.exec('SELECT id FROM grading_scales WHERE is_default = 1 LIMIT 1;');
        if (!res.length) return null;
        return await getGradingScale(res[0].values[0][0]);
    }

    /**
     * Create a grading scale with bands.
     * @param {Object} input { name, bands: [{gradeLetter, minPercentage, description}] }
     */
    async function saveGradingScale(input) {
        if (!db) await init();
        if (!input.name || !input.name.trim()) throw new Error('Scale name is required');
        if (!input.bands || input.bands.length === 0) throw new Error('At least one band is required');
        db.run('BEGIN TRANSACTION;');
        try {
            if (input.id) {
                // Update existing
                db.run('UPDATE grading_scales SET name = ? WHERE id = ?;', [input.name.trim(), input.id]);
                db.run('DELETE FROM grading_bands WHERE grading_scale_id = ?;', [input.id]);
            } else {
                // Insert new
                db.run('INSERT INTO grading_scales (name, is_default) VALUES (?, 0);', [input.name.trim()]);
                const idRes = db.exec('SELECT last_insert_rowid() AS id;');
                input.id = idRes.length ? idRes[0].values[0][0] : 0;
            }
            const stmt = db.prepare(
                'INSERT INTO grading_bands (grading_scale_id, grade_letter, min_percentage, description, sort_order) ' +
                'VALUES (?, ?, ?, ?, ?);'
            );
            input.bands.forEach(function (b, i) {
                stmt.run([input.id, b.gradeLetter, parseInt(b.minPercentage, 10), b.description || '', i]);
            });
            stmt.free();
            db.run('COMMIT;');
            await persist();
            return input.id;
        } catch (e) {
            try { db.run('ROLLBACK;'); } catch (_) {}
            throw e;
        }
    }

    async function deleteGradingScale(id) {
        if (!db) await init();
        // Check if it's the default
        const res = db.exec('SELECT is_default FROM grading_scales WHERE id = ?;', [id]);
        if (res.length && res[0].values[0][0] === 1) {
            throw new Error('Cannot delete the default grading scale.');
        }
        // Per spec: deleting a scale in use resets those classes to default.
        // ON DELETE SET NULL on the FK handles the NULL part; we set them to
        // the default scale's id explicitly.
        const defaultRes = db.exec('SELECT id FROM grading_scales WHERE is_default = 1 LIMIT 1;');
        const defaultId = defaultRes.length ? defaultRes[0].values[0][0] : null;
        if (defaultId) {
            db.run('UPDATE classes SET grading_scale_id = ? WHERE grading_scale_id = ?;', [defaultId, id]);
        }
        // CASCADE on grading_bands FK deletes the bands automatically
        db.run('DELETE FROM grading_scales WHERE id = ?;', [id]);
        await persist();
    }

    // --- Classes ---

    async function listClasses() {
        if (!db) await init();
        const res = db.exec(
            'SELECT c.id, c.name, c.academic_year_id, c.grading_scale_id, c.created_at, ' +
                   'y.year_label, ' +
                   's.name AS scale_name, ' +
                   '(SELECT COUNT(*) FROM students st WHERE st.class_id = c.id) AS student_count, ' +
                   '(SELECT COUNT(*) FROM subjects su WHERE su.class_id = c.id) AS subject_count ' +
            'FROM classes c ' +
            'LEFT JOIN academic_years y ON c.academic_year_id = y.id ' +
            'LEFT JOIN grading_scales s ON c.grading_scale_id = s.id ' +
            'ORDER BY c.created_at DESC, c.name ASC;'
        );
        if (!res.length) return [];
        const cols = res[0].columns;
        return res[0].values.map(function (row) {
            const obj = {};
            cols.forEach(function (c, i) { obj[c] = row[i]; });
            return {
                id: obj.id,
                name: obj.name,
                academicYearId: obj.academic_year_id,
                gradingScaleId: obj.grading_scale_id,
                yearLabel: obj.year_label,
                scaleName: obj.scale_name,
                studentCount: obj.student_count,
                subjectCount: obj.subject_count,
                createdAt: obj.created_at
            };
        });
    }

    async function addClass(input) {
        if (!db) await init();
        if (!input.name || !input.name.trim()) throw new Error('Class name is required');
        db.run(
            'INSERT INTO classes (name, academic_year_id, grading_scale_id) VALUES (?, ?, ?);',
            [input.name.trim(), input.academicYearId || null, input.gradingScaleId || null]
        );
        const res = db.exec('SELECT last_insert_rowid() AS id;');
        const id = res.length ? res[0].values[0][0] : 0;
        await persist();
        return id;
    }

    async function updateClass(id, input) {
        if (!db) await init();
        db.run(
            'UPDATE classes SET name = ?, academic_year_id = ?, grading_scale_id = ? WHERE id = ?;',
            [input.name.trim(), input.academicYearId || null, input.gradingScaleId || null, id]
        );
        await persist();
    }

    async function deleteClass(id) {
        if (!db) await init();
        // Check constraint: no students and no subjects (spec says "no students and no reports")
        const studentRes = db.exec('SELECT COUNT(*) AS c FROM students WHERE class_id = ?;', [id]);
        const studentCount = studentRes.length ? studentRes[0].values[0][0] : 0;
        if (studentCount > 0) {
            throw new Error('Cannot delete: ' + studentCount + ' student(s) exist in this class. Delete or move them first.');
        }
        const subjectRes = db.exec('SELECT COUNT(*) AS c FROM subjects WHERE class_id = ?;', [id]);
        const subjectCount = subjectRes.length ? subjectRes[0].values[0][0] : 0;
        if (subjectCount > 0) {
            throw new Error('Cannot delete: ' + subjectCount + ' subject(s) exist in this class. Delete them first.');
        }
        db.run('DELETE FROM classes WHERE id = ?;', [id]);
        await persist();
    }

    // --- Students ---

    async function listStudentsForClass(classId) {
        if (!db) await init();
        const res = db.exec(
            'SELECT id, surname, first_name, name, dob, gender, created_at ' +
            'FROM students WHERE class_id = ? ORDER BY name ASC;',
            [classId]
        );
        if (!res.length) return [];
        const cols = res[0].columns;
        return res[0].values.map(function (row) {
            const obj = {};
            cols.forEach(function (c, i) { obj[c] = row[i]; });
            return {
                id: obj.id,
                surname: obj.surname,
                firstName: obj.first_name,
                name: obj.name,
                dob: obj.dob,
                gender: obj.gender,
                createdAt: obj.created_at
            };
        });
    }

    async function addStudent(input) {
        if (!db) await init();
        if ((!input.surname || !input.surname.trim()) && (!input.firstName || !input.firstName.trim())) throw new Error('Student surname or first name is required');
        if (!input.classId) throw new Error('Class ID is required');
        db.run(
            'INSERT INTO students (surname, first_name, name, dob, gender, class_id) VALUES (?, ?, ?, ?, ?, ?);',
            [(input.surname || '').trim() || null, (input.firstName || '').trim() || null, ((input.surname || '').trim() + ' ' + (input.firstName || '').trim()).trim(), input.dob || null, input.gender || null, input.classId]
        );
        const res = db.exec('SELECT last_insert_rowid() AS id;');
        const id = res.length ? res[0].values[0][0] : 0;
        await persist();
        return id;
    }

    async function updateStudent(id, input) {
        if (!db) await init();
        db.run(
            'UPDATE students SET surname = ?, first_name = ?, name = ?, dob = ?, gender = ? WHERE id = ?;',
            [(input.surname || '').trim() || null, (input.firstName || '').trim() || null, ((input.surname || '').trim() + ' ' + (input.firstName || '').trim()).trim(), input.dob || null, input.gender || null, id]
        );
        await persist();
    }

    async function deleteStudent(id) {
        if (!db) await init();
        db.run('DELETE FROM students WHERE id = ?;', [id]);
        await persist();
    }

    /**
     * Promote or repeat a student: move them to a target class.
     * Constraint: target class must be in a DIFFERENT academic year
     * from the student's current class.
     */
    async function moveStudent(studentId, targetClassId) {
        if (!db) await init();
        // Get student's current class + its academic year
        const curRes = db.exec(
            'SELECT c.academic_year_id FROM students s ' +
            'JOIN classes c ON s.class_id = c.id WHERE s.id = ?;',
            [studentId]
        );
        if (!curRes.length) throw new Error('Student not found');
        const curYearId = curRes[0].values[0][0];
        // Get target class's academic year
        const tgtRes = db.exec('SELECT academic_year_id FROM classes WHERE id = ?;', [targetClassId]);
        if (!tgtRes.length) throw new Error('Target class not found');
        const tgtYearId = tgtRes[0].values[0][0];
        if (curYearId === tgtYearId) {
            throw new Error('Cannot move a student to a different class in the same academic year. Choose a class from a different year.');
        }
        db.run('UPDATE students SET class_id = ? WHERE id = ?;', [targetClassId, studentId]);
        await persist();
    }

    // --- Subjects ---

    async function listSubjectsForClass(classId) {
        if (!db) await init();
        const res = db.exec(
            'SELECT id, code, name, max_marks, min_marks, created_at ' +
            'FROM subjects WHERE class_id = ? ORDER BY name ASC;',
            [classId]
        );
        if (!res.length) return [];
        const cols = res[0].columns;
        return res[0].values.map(function (row) {
            const obj = {};
            cols.forEach(function (c, i) { obj[c] = row[i]; });
            return {
                id: obj.id,
                code: obj.code,
                name: obj.name,
                maxMarks: obj.max_marks,
                minMarks: obj.min_marks,
                createdAt: obj.created_at
            };
        });
    }

    async function addSubject(input) {
        if (!db) await init();
        if (!input.name || !input.name.trim()) throw new Error('Subject name is required');
        if (!input.classId) throw new Error('Class ID is required');
        db.run(
            'INSERT INTO subjects (code, name, max_marks, min_marks, class_id) VALUES (?, ?, ?, ?, ?);',
            [input.code || null, input.name.trim(), Number.isFinite(parseInt(input.maxMarks, 10)) ? parseInt(input.maxMarks, 10) : 100, Number.isFinite(parseInt(input.minMarks, 10)) ? parseInt(input.minMarks, 10) : 35, input.classId]
        );
        const res = db.exec('SELECT last_insert_rowid() AS id;');
        const id = res.length ? res[0].values[0][0] : 0;
        await persist();
        return id;
    }

    async function updateSubject(id, input) {
        if (!db) await init();
        db.run(
            'UPDATE subjects SET code = ?, name = ?, max_marks = ?, min_marks = ? WHERE id = ?;',
            [input.code || null, input.name.trim(), Number.isFinite(parseInt(input.maxMarks, 10)) ? parseInt(input.maxMarks, 10) : 100, Number.isFinite(parseInt(input.minMarks, 10)) ? parseInt(input.minMarks, 10) : 35, id]
        );
        await persist();
    }

    async function deleteSubject(id) {
        if (!db) await init();
        // subject_marks has ON DELETE CASCADE on subject_id FK, so the rows are
        // removed automatically. (SQLite enforces FK actions only if
        // PRAGMA foreign_keys = ON, sql.js doesn't set this, so we also do
        // an explicit DELETE below to be safe across sql.js versions.)
        db.run('DELETE FROM subject_marks WHERE subject_id = ?;', [id]);
        db.run('DELETE FROM subjects WHERE id = ?;', [id]);
        await persist();
    }

    // ------------------------------------------------------------------
    // Iteration 12 (roadmap #2): per-student subject marks CRUD.
    //
    // These methods back the "Enter marks for N students" modal that opens
    // immediately after a new subject is added (Admin → Manage Class →
    // Subjects → Add Subject). The marks are stored independently of any
    // generated report, they're the source of truth for "what each student
    // scored in this subject" until a batch overwrites them.
    //
    // Future-friendly: the batch wizard can later optionally pre-fill from
    // these marks, but that wiring is deliberately NOT in scope here,
    // this iteration only ships the entry + persistence UI.
    // ------------------------------------------------------------------

    /**
     * Bulk-save marks for a (subject, student) pair, UPSERT semantics.
     *
     * @param {number} subjectId
     * @param {Array<{studentId:number, obtainedMarks:number, isAbsent:boolean}>} marks
     * @returns {Promise<void>}
     */
    async function saveSubjectMarks(subjectId, marks) {
        if (!db) await init();
        if (!subjectId) throw new Error('Subject id is required');
        // Use INSERT OR REPLACE, the UNIQUE(subject_id, student_id) constraint
        // turns this into an UPSERT. Single prepared statement reused in a loop.
        const stmt = db.prepare(
            'INSERT OR REPLACE INTO subject_marks ' +
            '(subject_id, student_id, obtained_marks, is_absent, updated_at) ' +
            'VALUES (?, ?, ?, ?, datetime(\'now\'));'
        );
        try {
            db.run('BEGIN TRANSACTION;');
            (marks || []).forEach(function (m) {
                if (!m.studentId) return; // skip blank rows
                // Iter 21 fix (CRIT-09): coerce strings to numbers via parseFloat.
                // Number.isFinite("78.5") returns false (doesn't coerce strings),
                // so a string value would silently become 0. parseFloat handles
                // both number and string inputs correctly.
                const obtained = Number.isFinite(parseFloat(m.obtainedMarks)) ? parseFloat(m.obtainedMarks) : 0;
                stmt.run([
                    subjectId,
                    m.studentId,
                    obtained,
                    m.isAbsent ? 1 : 0
                ]);
            });
            db.run('COMMIT;');
        } catch (e) {
            try { db.run('ROLLBACK;'); } catch (_) {}
            try { stmt.free(); } catch (_) {}
            throw e;
        }
        stmt.free();
        await persist();
    }

    /**
     * List all saved marks for a subject, joined with student info.
     * Returns one row per student in the subject's class, ordered by roll
     * number (numeric-aware) then name, matching the wizard's pre-fill order.
     *
     * @param {number} subjectId
     * @returns {Promise<Array<{studentId, surname, firstName, name, obtainedMarks, isAbsent}>>}
     */
    async function listSubjectMarks(subjectId) {
        if (!db) await init();
        // Iter 19: removed class_position column, sort by name ASC
        const res = db.exec(
            'SELECT s.id, s.surname, s.first_name, s.name, ' +
                   'COALESCE(sm.obtained_marks, 0) AS obtained_marks, ' +
                   'COALESCE(sm.is_absent, 0) AS is_absent, ' +
                   'CASE WHEN sm.id IS NULL THEN 1 ELSE 0 END AS has_mark ' +
            'FROM students s ' +
            'JOIN subjects sub ON s.class_id = sub.class_id ' +
            'LEFT JOIN subject_marks sm ON sm.student_id = s.id AND sm.subject_id = sub.id ' +
            'WHERE sub.id = ? ' +
            'ORDER BY s.name COLLATE NOCASE ASC;',
            [subjectId]
        );
        if (!res.length) return [];
        const cols = res[0].columns;
        return res[0].values.map(function (row) {
            const obj = {};
            cols.forEach(function (c, i) { obj[c] = row[i]; });
            return {
                studentId: obj.id,
                surname: obj.surname,
                firstName: obj.first_name,
                name: obj.name,
                obtainedMarks: obj.obtained_marks,
                isAbsent: !!obj.is_absent,
                hasMark: !obj.has_mark
            };
        });
    }

    /**
     * Get the subject's max_marks, convenience wrapper used by the modal
     * for input validation (min=0, max=N) before saving.
     * @param {number} subjectId
     * @returns {Promise<{id, name, maxMarks, minMarks, classId}|null>}
     */
    async function getSubject(subjectId) {
        if (!db) await init();
        const res = db.exec(
            'SELECT id, code, name, max_marks, min_marks, class_id ' +
            'FROM subjects WHERE id = ?;',
            [subjectId]
        );
        if (!res.length) return null;
        const cols = res[0].columns;
        const row = res[0].values[0];
        const obj = {};
        cols.forEach(function (c, i) { obj[c] = row[i]; });
        return {
            id: obj.id,
            code: obj.code,
            name: obj.name,
            maxMarks: obj.max_marks,
            minMarks: obj.min_marks,
            classId: obj.class_id
        };
    }

    /**
     * Iter 14 (closes the loop on Iter 12's subject_marks): list ALL saved
     * marks for EVERY subject in a class, in ONE query.
     *
     * Returns one row per (subject, student) pair where the student has a
     * saved mark for that subject. Pairs without a saved mark are simply
     * absent from the result (the caller treats missing as 0/empty).
     *
     * Each row: { subjectId, studentId, obtainedMarks, isAbsent }
     *
     * Used by the batch wizard (applyManagedPrefill) to pre-fill Step 4's
     * marks grid from marks the teacher already entered via the Admin UI's
     * "Enter Marks" modal; it closes the loop between Admin UI entry and the
     * batch wizard.
     *
     * @param {number} classId
     * @returns {Promise<Array<{subjectId, studentId, obtainedMarks, isAbsent}>>}
     */
    async function listSubjectMarksForClass(classId) {
        if (!db) await init();
        // JOIN subjects (filtered by class) → subject_marks → students.
        // LEFT JOIN would include students-with-no-marks rows (with NULL
        // obtained_marks); INNER JOIN excludes them, which is what we want
        // (the caller treats "not in result" as "no saved mark, leave blank".)
        const res = db.exec(
            'SELECT sm.subject_id, sm.student_id, sm.obtained_marks, sm.is_absent ' +
            'FROM subject_marks sm ' +
            'JOIN subjects sub ON sm.subject_id = sub.id ' +
            'WHERE sub.class_id = ?;',
            [classId]
        );
        if (!res.length) return [];
        const cols = res[0].columns;
        return res[0].values.map(function (row) {
            const obj = {};
            cols.forEach(function (c, i) { obj[c] = row[i]; });
            return {
                subjectId: obj.subject_id,
                studentId: obj.student_id,
                obtainedMarks: obj.obtained_marks,
                isAbsent: !!obj.is_absent
            };
        });
    }

    // ------------------------------------------------------------------
    // Phase C: export/replace entire DB (for backup/restore)
    // ------------------------------------------------------------------

    /** Export the SQLite bytes. Used by TerminalReportBackup for manual + auto backups. */
    function exportDb() {
        if (!db) return null;
        return db.export(); // Uint8Array
    }

    /**
     * Replace the in-memory DB with new bytes (from a restored backup).
     * Re-creates the Database instance, runs schema (idempotent), persists
     * to IndexedDB. Does NOT touch the auth table contents, those come
     * from the backup bytes themselves.
     * @param {Uint8Array} bytes
     */
    async function replaceDatabase(bytes) {
        if (!SQL) await doInit();
        if (db) {
            try { db.close(); } catch (_) { /* ignore */ }
            db = null;
        }
        if (bytes && bytes.length) {
            db = new SQL.Database(new Uint8Array(bytes));
            // Iter 31 audit fix (CONS-02): run the idempotent schema migration
            // on restored bytes, mirroring doInit(). A backup exported by an
            // older app version can predate later schema changes (e.g. the
            // Iter-18 surname/first_name columns); without this, every
            // students query after such a restore failed with an SQL error.
            migrateStudentsSchema();
        } else {
            db = new SQL.Database();
            createSchema();
        }
        await persist();
    }

    // ------------------------------------------------------------------
    // IndexedDB helpers: store the SQLite bytes under a single key
    // ------------------------------------------------------------------
    function openIDB() {
        return new Promise(function (resolve, reject) {
            const req = indexedDB.open(IDB_NAME, 1);
            req.onupgradeneeded = function (e) {
                const idb = e.target.result;
                if (!idb.objectStoreNames.contains(IDB_STORE)) {
                    idb.createObjectStore(IDB_STORE);
                }
            };
            req.onsuccess = function (e) { resolve(e.target.result); };
            req.onerror = function () { reject(req.error); };
        });
    }

    function loadFromIDB() {
        return openIDB().then(function (idb) {
            return new Promise(function (resolve, reject) {
                const tx = idb.transaction(IDB_STORE, 'readonly');
                const store = tx.objectStore(IDB_STORE);
                const getReq = store.get(IDB_KEY);
                getReq.onsuccess = function () { resolve(getReq.result || null); };
                getReq.onerror = function () { reject(getReq.error); };
            });
        });
    }

    function saveToIDB(buffer) {
        return openIDB().then(function (idb) {
            return new Promise(function (resolve, reject) {
                const tx = idb.transaction(IDB_STORE, 'readwrite');
                const store = tx.objectStore(IDB_STORE);
                const putReq = store.put(buffer, IDB_KEY);
                putReq.onsuccess = function () { resolve(); };
                putReq.onerror = function () { reject(putReq.error); };
            });
        });
    }

    // ------------------------------------------------------------------
    // Iter 20 (PERF-01): Single-query batch summary stats.
    // Replaces the N+1 pattern in script.js's refreshDashboardSummary()
    // which called listBatches() + listReportsForBatch() per batch.
    // This function returns summary data WITHOUT loading subjects_json/logo_blob/photo_blob.
    // ------------------------------------------------------------------
    async function getBatchSummaryStats() {
        if (!db) await init();
        // CRIT-14 fix: added AVG of CAST(json_extract(r.summary_json, '$.percentage') AS REAL)
        // to surface the "Class Avg" column with a real value (previously hardcoded to a dash).
        // summary.percentage is stored as a string like "85.5" (see batch.js:137
        // `percentage.toFixed(1)`), so CAST(... AS REAL) is required, AVG on TEXT
        // returns 0.0 in SQLite. NULL percentages (e.g., malformed rows) are excluded
        // from AVG automatically.
        const res = db.exec(
            'SELECT b.id, b.class_name, b.academic_year, b.academic_term, ' +
                   'COUNT(r.id) AS student_count, ' +
                   'SUM(CASE WHEN json_extract(r.summary_json, \'$.passed\') = 1 THEN 1 ELSE 0 END) AS passed_count, ' +
                   'AVG(CAST(json_extract(r.summary_json, \'$.percentage\') AS REAL)) AS avg_pct ' +
            'FROM batches b ' +
            'LEFT JOIN reports r ON r.batch_id = b.id ' +
            'GROUP BY b.id ' +
            'ORDER BY b.created_at DESC, b.id DESC;'
        );
        if (!res.length) return [];
        const cols = res[0].columns;
        return res[0].values.map(function (row) {
            const obj = {};
            cols.forEach(function (c, i) { obj[c] = row[i]; });
            return {
                batchId: obj.id,
                className: obj.class_name,
                academicYear: obj.academic_year,
                academicTerm: obj.academic_term,
                studentCount: obj.student_count,
                passedCount: obj.passed_count,
                avgPct: (obj.avg_pct == null || !isFinite(obj.avg_pct)) ? null : obj.avg_pct
            };
        });
    }

    // ------------------------------------------------------------------
    // Export
    // ------------------------------------------------------------------
    window.TerminalReportDb = {
        init: init,
        isReady: isReady,
        saveReport: saveReport,
        listReports: listReports,
        searchReports: searchReports,         // Iter 11: roadmap #1 (filter by name + class)
        listReportClasses: listReportClasses, // Iter 11: roadmap #1 (populate class filter)
        loadReport: loadReport,
        deleteReport: deleteReport,
        // Phase B
        saveAuth: saveAuth,
        loadAuth: loadAuth,
        updatePin: updatePin,
        updateSecurityAnswer: updateSecurityAnswer, // BLIND-8 fix (Iter 23)
        updateSchoolInfo: updateSchoolInfo,
        // Phase C
        export: exportDb,
        replaceDatabase: replaceDatabase,
        // Phase D
        findBatch: findBatch,
        saveBatch: saveBatch,
        listBatches: listBatches,
        listReportsForBatch: listReportsForBatch,
        deleteBatch: deleteBatch,
        getPrefillForClass: getPrefillForClass,
        // Phase E: Academic Years
        listAcademicYears: listAcademicYears,
        addAcademicYear: addAcademicYear,
        deleteAcademicYear: deleteAcademicYear,
        // Phase E: Grading Scales
        listGradingScales: listGradingScales,
        listGradingBands: listGradingBands,
        getGradingScale: getGradingScale,
        getDefaultGradingScale: getDefaultGradingScale,
        saveGradingScale: saveGradingScale,
        deleteGradingScale: deleteGradingScale,
        // Phase E: Classes
        listClasses: listClasses,
        addClass: addClass,
        updateClass: updateClass,
        deleteClass: deleteClass,
        // Phase E: Students
        listStudentsForClass: listStudentsForClass,
        addStudent: addStudent,
        updateStudent: updateStudent,
        deleteStudent: deleteStudent,
        moveStudent: moveStudent,
        // Phase E: Subjects
        listSubjectsForClass: listSubjectsForClass,
        addSubject: addSubject,
        updateSubject: updateSubject,
        deleteSubject: deleteSubject,
        // Iter 12: Subject marks (roadmap #2)
        getSubject: getSubject,                         // fetch subject (incl. maxMarks) for validation
        saveSubjectMarks: saveSubjectMarks,            // bulk UPSERT marks for one subject across all students
        listSubjectMarks: listSubjectMarks,            // list marks for one subject joined with student info
        listSubjectMarksForClass: listSubjectMarksForClass,  // Iter 14: list ALL marks for ALL subjects in a class (batch wizard pre-fill)
        // Iter 20: batch summary stats (replaces N+1 in dashboard)
        getBatchSummaryStats: getBatchSummaryStats
    };

    // Iter 18: expose toOrdinal for admin-ui.js + script.js
    window.TerminalReportScript_toOrdinal = toOrdinal;
    window.TerminalReportScript_getStudentFullName = getStudentFullName;
})();
