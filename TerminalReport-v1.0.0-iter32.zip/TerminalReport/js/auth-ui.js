/**
 * TerminalReport: auth UI controller (Phase B)
 *
 * Responsibility:
 *   - Show/hide the setup wizard, lock screen, and recovery screen
 *   - Wire PIN pad clicks to TerminalReportAuth.unlock()
 *   - Show lockout countdown timer
 *   - On successful setup/unlock/recovery, reveal the main app
 *
 * Bound to index.html element IDs:
 *   Overlays: #setupWizard, #lockScreen, #recoveryScreen
 *   Setup: #setupSchoolName, #setupLogoFile, #setupPin1, #setupPin2, #setupSecQuestion, #setupSecAnswer
 *          #setupNext1, #setupNext2, #setupBack2, #setupBack3, #setupFinish, #setupPinError, #setupSecError
 *          .auth-step, .auth-step-panel
 *   Lock: #lockSchoolName, #lockSchoolLogo, #lockPinDisplay, #lockMessage, #lockCountdown, .pin-key
 *   Recovery: #recoveryQuestionLabel, #recoveryAnswer, #recoveryNewPin, #recoveryError,
 *             #recoveryCancel, #recoverySubmit
 *   Appbar: #terminalreportAppbar, #appbarBrandName (Iter 15: was #appbarSchoolName), #appbarLogo, #appbarLockBtn
 *   Body class: .auth-gating (when any overlay is visible)
 *
 * Public API (window.TerminalReportAuthUI):
 *   start()                    → Promise<void>  (entry point, checks configured/unlocked, shows right screen)
 *   showMainApp()              → void  (called by script.js after init OR after successful auth)
 */
(function () {
    'use strict';

    const $ = (id) => document.getElementById(id);
    // Iteration 28 (DLG-01): shared in-app dialog (replaces native alert/confirm)
    const UI = window.TerminalReportUI;

    // PIN entry buffer (digits), 0-4 chars
    let pinBuffer = '';
    let countdownInterval = null;
    let isBusy = false;  // prevent double-submit during async unlock

    // ------------------------------------------------------------------
    // Overlay show/hide
    // ------------------------------------------------------------------
    function hideAllOverlays() {
        ['setupWizard', 'lockScreen', 'recoveryScreen'].forEach(function (id) {
            const el = $(id);
            if (el) el.style.display = 'none';
        });
    }

    function showOverlay(id) {
        hideAllOverlays();
        const el = $(id);
        if (el) el.style.display = 'flex';
        document.body.classList.add('auth-gating');
    }

    function showMainApp() {
        hideAllOverlays();
        document.body.classList.remove('auth-gating');
        const appbar = $('terminalreportAppbar');
        const main = $('mainApp');
        if (appbar) appbar.style.display = 'flex';
        if (main) main.style.display = 'block';

        // Iter 15: the appbar is the APP's chrome, not the school's branding.
        // It ALWAYS shows "TerminalReport" as the brand text and the TerminalReport
        // brand logo (assets/app-logo.png). The school's name + logo (uploaded
        // during setup) appear on the report cards themselves via
        // generateReportHTML() → data.academyName / data.schoolLogoBytes.
        //
        // Previously (Iter 9) the appbar showed the user's typed-in school name
        // and the school's uploaded logo. That mixed school branding into the
        // app's chrome, the user explicitly requested the appbar always say
        // "TerminalReport" (the app name) regardless of the school on file.
        //
        // The HTML default text is already "TerminalReport" (set in index.html),
        // so we don't need to set textContent here. We DO need to ensure the
        // TerminalReport brand logo is rendered (the school's uploaded logo is
        // intentionally NOT shown in the appbar anymore).
        const logoBox = $('appbarLogo');
        if (logoBox) {
            logoBox.innerHTML = '<img src="assets/app-logo.png" alt="TerminalReport logo">';
        }

        if (!window.__terminalReportAuthUiInited) {
            window.__terminalReportAuthUiInited = true;
            initLockScreen();
            initRecoveryScreen();
            initSettingsScreen();
            initAutoBackupOnClose();
        }

        // Notify script.js that auth is complete (it can finish its own init)
        document.dispatchEvent(new CustomEvent('terminalreport:auth-complete'));
    }

    // Local copy of bytesToObjectUrl (script.js has its own; we don't want to depend on it)
    // BLIND-12 fix (Iter 24 audit): this helper previously created blob URLs with
    // NO tracking and NO revocation, and its callers (lock-screen logo render +
    // settings logo preview) run on every re-render, so every lock/unlock cycle
    // and every settings open leaked one more object URL that pinned the logo
    // blob in memory until page unload. URLs are now tracked and capped: the
    // oldest is revoked once more than LOCAL_OBJECT_URL_CAP exist. Revoking an
    // old URL never affects an <img> that already finished loading, and the cap
    // (8) is far above the number of simultaneously-live previews, so rendering
    // behaviour is unchanged while the leak becomes bounded.
    const LOCAL_OBJECT_URL_CAP = 8;
    const localObjectUrls = [];
    function bytesToObjectUrl(bytes) {
        if (!bytes || !bytes.length) return '';
        const blob = new Blob([bytes], { type: 'image/png' });
        const url = URL.createObjectURL(blob);
        localObjectUrls.push(url);
        while (localObjectUrls.length > LOCAL_OBJECT_URL_CAP) {
            URL.revokeObjectURL(localObjectUrls.shift());
        }
        return url;
    }

    // ------------------------------------------------------------------
    // Setup wizard
    // ------------------------------------------------------------------
    function showSetupStep(stepNum) {
        document.querySelectorAll('.auth-step').forEach(function (s) {
            s.classList.toggle('active', parseInt(s.dataset.step, 10) === stepNum);
        });
        document.querySelectorAll('.auth-step-panel').forEach(function (p) {
            p.style.display = parseInt(p.dataset.stepPanel, 10) === stepNum ? 'block' : 'none';
        });
    }

    function initSetupWizard() {
        showSetupStep(1);

        $('setupNext1').addEventListener('click', function () {
            const name = $('setupSchoolName').value.trim();
            if (!name) { UI.alert('Please enter your school name.'); return; }
            showSetupStep(2);
        });

        $('setupNext2').addEventListener('click', function () {
            const pin1 = $('setupPin1').value;
            const pin2 = $('setupPin2').value;
            const err = $('setupPinError');
            err.style.display = 'none';
            if (!/^\d{4}$/.test(pin1)) {
                err.textContent = 'PIN must be exactly 4 digits.';
                err.style.display = 'block';
                return;
            }
            if (pin1 !== pin2) {
                err.textContent = 'PINs do not match.';
                err.style.display = 'block';
                return;
            }
            showSetupStep(3);
        });

        $('setupBack2').addEventListener('click', function () { showSetupStep(1); });
        $('setupBack3').addEventListener('click', function () { showSetupStep(2); });

        $('setupFinish').addEventListener('click', async function () {
            const err = $('setupSecError');
            err.style.display = 'none';
            const schoolName = $('setupSchoolName').value.trim();
            const logoFile = $('setupLogoFile').files[0] || null;
            const pin = $('setupPin1').value;
            const question = $('setupSecQuestion').value.trim();
            const answer = $('setupSecAnswer').value.trim();

            if (!question) {
                err.textContent = 'Security question is required.';
                err.style.display = 'block';
                return;
            }
            if (!answer) {
                err.textContent = 'Security answer is required.';
                err.style.display = 'block';
                return;
            }

            const btn = $('setupFinish');
            btn.disabled = true;
            btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Setting up...';

            try {
                await window.TerminalReportAuth.setup({
                    schoolName: schoolName,
                    logoFile: logoFile,
                    pin: pin,
                    securityQuestion: question,
                    securityAnswer: answer
                });
                showMainApp();
            } catch (e) {
                err.textContent = e.message || 'Setup failed.';
                err.style.display = 'block';
                btn.disabled = false;
                btn.innerHTML = '<i class="fas fa-check"></i> Complete Setup';
            }
        });
    }

    // ------------------------------------------------------------------
    // Lock screen
    // ------------------------------------------------------------------
    function populateLockScreenHeader() {
        if (window.TerminalReportAuth) {
            const info = window.TerminalReportAuth.getSchoolInfo();
            if (info) {
                if ($('lockSchoolName')) $('lockSchoolName').textContent = info.name || 'TerminalReport';
                const logoBox = $('lockSchoolLogo');
                if (logoBox) {
                    logoBox.innerHTML = info.logoBytes
                        ? '<img src="' + bytesToObjectUrl(info.logoBytes) + '" alt="School logo">'
                        : '<img src="assets/app-logo.png" alt="TerminalReport logo">';
                }
            }
        }
    }

    function initLockScreen() {
        // Populate school name + logo on the lock screen
        populateLockScreenHeader();

        // PIN pad click handler (event delegation)
        $('lockScreen').addEventListener('click', function (e) {
            const btn = e.target.closest('.pin-key');
            if (!btn) return;
            const key = btn.dataset.pinKey;
            if (key === 'forgot') {
                showRecovery();
            } else if (key === 'back') {
                pinBuffer = pinBuffer.slice(0, -1);
                updatePinDisplay();
            } else if (/^[0-9]$/.test(key)) {
                if (pinBuffer.length < 4 && !isBusy) {
                    pinBuffer += key;
                    updatePinDisplay();
                    if (pinBuffer.length === 4) {
                        attemptUnlock();
                    }
                }
            }
        });

        // Keyboard support: type 0-9, Backspace, Enter
        document.addEventListener('keydown', function (e) {
            // Only react when lock screen is visible
            if ($('lockScreen').style.display === 'none') return;
            if ($('setupWizard').style.display !== 'none') return; // setup wizard uses keyboard too
            if ($('recoveryScreen').style.display !== 'none') return;

            if (/^[0-9]$/.test(e.key)) {
                if (pinBuffer.length < 4 && !isBusy) {
                    pinBuffer += e.key;
                    updatePinDisplay();
                    if (pinBuffer.length === 4) attemptUnlock();
                }
            } else if (e.key === 'Backspace') {
                pinBuffer = pinBuffer.slice(0, -1);
                updatePinDisplay();
            } else if (e.key === 'Enter' && pinBuffer.length === 4) {
                attemptUnlock();
            }
        });

        // Lock button in appbar: re-populate lock screen header on every show
        const lockBtn = $('appbarLockBtn');
        if (lockBtn) {
            lockBtn.addEventListener('click', function () {
                if (window.TerminalReportAuth) window.TerminalReportAuth.lock();
                pinBuffer = '';
                updatePinDisplay();
                populateLockScreenHeader();
                showOverlay('lockScreen');
            });
        }

        // Subscribe to lock state changes (e.g., countdown updates)
        if (window.TerminalReportAuth) {
            window.TerminalReportAuth.onLockStateChange(function (state) {
                if (state.lockedUntil && Date.now() < state.lockedUntil) {
                    startCountdown(state.lockedUntil);
                } else {
                    stopCountdown();
                }
            });
        }
    }

    function updatePinDisplay() {
        const dots = document.querySelectorAll('#lockPinDisplay .pin-dot');
        dots.forEach(function (dot, i) {
            dot.classList.toggle('filled', i < pinBuffer.length);
        });
    }

    function setLockMessage(msg, isError) {
        const el = $('lockMessage');
        if (!el) return;
        el.textContent = msg || '';
        el.className = isError ? 'text-danger mt-2' : 'text-success mt-2';
        el.style.minHeight = '1.5em';
    }

    async function attemptUnlock() {
        if (isBusy) return;
        isBusy = true;
        setLockMessage('Checking...', false);

        try {
            const result = await window.TerminalReportAuth.unlock(pinBuffer);
            if (result.success) {
                pinBuffer = '';
                updatePinDisplay();
                setLockMessage('', false);
                showMainApp();
                return;
            }
            if (result.error === 'locked') {
                pinBuffer = '';
                updatePinDisplay();
                setLockMessage('Too many attempts. Locked out.', true);
                startCountdown(result.lockedUntil);
            } else if (result.error === 'incorrect') {
                pinBuffer = '';
                updatePinDisplay();
                setLockMessage('Incorrect passcode. ' + (result.attemptsRemaining || 0) + ' attempts left.', true);
                shakePinDisplay();
            } else {
                setLockMessage(result.error || 'Failed to unlock.', true);
            }
        } catch (e) {
            setLockMessage(e.message || 'Unlock failed.', true);
        } finally {
            isBusy = false;
        }
    }

    function shakePinDisplay() {
        const el = $('lockPinDisplay');
        if (!el) return;
        el.classList.remove('shake');
        // Force reflow so animation restarts
        void el.offsetWidth;
        el.classList.add('shake');
    }

    function startCountdown(lockedUntil) {
        stopCountdown();
        const el = $('lockCountdown');
        if (!el) return;
        el.style.display = 'block';

        function tick() {
            const remaining = lockedUntil - Date.now();
            if (remaining <= 0) {
                stopCountdown();
                setLockMessage('Lockout expired. Try again.', false);
                return;
            }
            const min = Math.floor(remaining / 60000);
            const sec = Math.floor((remaining % 60000) / 1000);
            el.textContent = 'Locked. Try again in ' + min + ':' + String(sec).padStart(2, '0');
        }
        tick();
        countdownInterval = setInterval(tick, 500);
    }

    function stopCountdown() {
        if (countdownInterval) {
            clearInterval(countdownInterval);
            countdownInterval = null;
        }
        const el = $('lockCountdown');
        if (el) {
            el.style.display = 'none';
            el.textContent = '';
        }
    }

    // ------------------------------------------------------------------
    // Recovery
    // ------------------------------------------------------------------
    function showRecovery() {
        // Populate the security question from auth state
        if (window.TerminalReportAuth) {
            const info = window.TerminalReportAuth.getSchoolInfo();
            // We need to read the security question from the DB, TerminalReportAuth doesn't expose it directly
            // to avoid leaking it to potential attackers. But for recovery, the user IS the owner.
            // We'll fetch it via a one-off DB read.
            window.TerminalReportDb.loadAuth().then(function (authRow) {
                if (authRow) {
                    $('recoveryQuestionLabel').textContent = authRow.securityQuestion;
                }
            }).catch(function (e) {
                // Iter 31 audit: the question label keeps its default text if
                // the read fails; log so the failure is diagnosable instead of
                // surfacing as an unhandled promise rejection.
                console.error('[auth-ui] could not load security question:', e);
            });
        }
        showOverlay('recoveryScreen');
    }

    function initRecoveryScreen() {
        $('recoveryCancel').addEventListener('click', function () {
            // Go back to lock screen
            pinBuffer = '';
            updatePinDisplay();
            showOverlay('lockScreen');
            // Re-check lockout state, if still locked, show countdown
            if (window.TerminalReportAuth) {
                const st = window.TerminalReportAuth.getLockState();
                if (st.lockedUntil && Date.now() < st.lockedUntil) startCountdown(st.lockedUntil);
            }
        });

        $('recoverySubmit').addEventListener('click', async function () {
            const err = $('recoveryError');
            err.style.display = 'none';
            const answer = $('recoveryAnswer').value;
            const newPin = $('recoveryNewPin').value;
            if (!answer) { err.textContent = 'Answer is required.'; err.style.display = 'block'; return; }
            if (!/^\d{4}$/.test(newPin)) { err.textContent = 'New PIN must be exactly 4 digits.'; err.style.display = 'block'; return; }

            const btn = $('recoverySubmit');
            btn.disabled = true;
            btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Resetting...';

            try {
                const result = await window.TerminalReportAuth.recover(answer, newPin);
                if (result.success) {
                    $('recoveryAnswer').value = '';
                    $('recoveryNewPin').value = '';
                    pinBuffer = '';
                    updatePinDisplay();
                    showMainApp();
                } else {
                    err.textContent = result.error === 'incorrect_answer'
                        ? 'Incorrect answer. Please try again.'
                        : (result.error || 'Recovery failed.');
                    err.style.display = 'block';
                }
            } catch (e) {
                err.textContent = e.message || 'Recovery failed.';
                err.style.display = 'block';
            } finally {
                btn.disabled = false;
                btn.innerHTML = '<i class="fas fa-check"></i> Reset Passcode';
            }
        });
    }

    // ------------------------------------------------------------------
    // Phase C: Settings overlay (school info, backup/restore, change PIN)
    // ------------------------------------------------------------------
    function initSettingsScreen() {
        // Settings gear button in appbar
        const gearBtn = $('appbarSettingsBtn');
        if (gearBtn) {
            gearBtn.addEventListener('click', function () {
                populateSettingsScreen();
                showOverlay('settingsScreen');
            });
        }

        // Close button
        const closeBtn = $('settingsCloseBtn');
        if (closeBtn) {
            closeBtn.addEventListener('click', function () {
                // Hide overlay, no body class change (auth-gating only on actual auth overlays)
                $('settingsScreen').style.display = 'none';
                document.body.classList.remove('auth-gating');
            });
        }

        // Iteration 32 (SCROLL-01): reset scroll every time the settings
        // overlay is opened; it is tall on small screens and the overlay
        // itself is the scroll container. (Runs before the existing gear
        // handler below, which populates and shows the overlay.)
        const gearScrollBtn = $('appbarSettingsBtn');
        if (gearScrollBtn) {
            gearScrollBtn.addEventListener('click', function () {
                const s = $('settingsScreen');
                if (s) s.scrollTop = 0;
            });
        }

        // School info save
        const saveSchoolBtn = $('settingsSaveSchoolBtn');
        if (saveSchoolBtn) {
            saveSchoolBtn.addEventListener('click', handleSaveSchoolInfo);
        }

        // Logo preview on file select
        const logoFile = $('settingsLogoFile');
        if (logoFile) {
            logoFile.addEventListener('change', function (e) {
                const file = e.target.files[0];
                if (!file) return;
                const reader = new FileReader();
                reader.onload = function (ev) {
                    $('settingsLogoPreviewImg').src = ev.target.result;
                    $('settingsLogoPreview').style.display = 'block';
                };
                reader.readAsDataURL(file);
            });
        }

        // Auto-backup toggle
        const autoToggle = $('autoBackupToggle');
        if (autoToggle) {
            // Initialise from current state
            if (window.TerminalReportBackup) {
                autoToggle.checked = window.TerminalReportBackup.isAutoBackupEnabled();
            }
            autoToggle.addEventListener('change', function () {
                if (window.TerminalReportBackup) {
                    window.TerminalReportBackup.setAutoBackupEnabled(autoToggle.checked);
                }
            });
        }

        // Backup Now button
        const backupNowBtn = $('backupNowBtn');
        if (backupNowBtn) {
            backupNowBtn.addEventListener('click', handleBackupNow);
        }

        // Restore button (uses hidden file input)
        const restoreBtn = $('restoreBtn');
        const restoreInput = $('restoreFileInput');
        if (restoreBtn && restoreInput) {
            restoreBtn.addEventListener('click', function () {
                restoreInput.value = '';
                restoreInput.click();
            });
            restoreInput.addEventListener('change', handleRestoreFromFile);
        }

        // Change PIN button
        const changePinBtn = $('changePinBtn');
        if (changePinBtn) {
            changePinBtn.addEventListener('click', handleChangePin);
        }
    }

    function populateSettingsScreen() {
        if (!window.TerminalReportAuth) return;
        const info = window.TerminalReportAuth.getSchoolInfo();
        if (!info) return;
        if ($('settingsSchoolName')) $('settingsSchoolName').value = info.name || '';
        if ($('settingsAppUuid')) $('settingsAppUuid').textContent = info.appUuid || 'Not set';
        // Logo preview
        const previewBox = $('settingsLogoPreview');
        const previewImg = $('settingsLogoPreviewImg');
        if (info.logoBytes && previewBox && previewImg) {
            previewImg.src = bytesToObjectUrl(info.logoBytes);
            previewBox.style.display = 'block';
        } else if (previewBox) {
            previewBox.style.display = 'none';
        }
        // Reset logo file input
        if ($('settingsLogoFile')) $('settingsLogoFile').value = '';
        // Clear PIN fields
        if ($('changePinOld')) $('changePinOld').value = '';
        if ($('changePinNew')) $('changePinNew').value = '';
        if ($('changePinConfirm')) $('changePinConfirm').value = '';
    }

    async function handleSaveSchoolInfo() {
        const btn = $('settingsSaveSchoolBtn');
        const name = $('settingsSchoolName').value.trim();
        if (!name) { UI.alert('School name cannot be empty.'); return; }
        const file = $('settingsLogoFile').files[0] || null;

        btn.disabled = true;
        const orig = btn.innerHTML;
        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Saving...';

        try {
            let logoBytes = null;
            if (file) {
                // Reuse TerminalReportAuth's logo resizer (exposed for testing)
                logoBytes = await window.TerminalReportAuth._resizeLogoTo256(file);
            } else {
                // Keep existing logo if user didn't pick a new one
                const info = window.TerminalReportAuth.getSchoolInfo();
                logoBytes = info ? info.logoBytes : null;
            }
            await window.TerminalReportDb.updateSchoolInfo(name, logoBytes);
            await window.TerminalReportAuth.refresh();
            // Refresh appbar logo
            populateAppbarLogo();
            // Refresh lock screen logo (in case user re-locks)
            populateLockScreenHeader();
            UI.alert('School information saved.');
        } catch (e) {
            UI.alert('Failed to save school info: ' + (e.message || e));
        } finally {
            btn.disabled = false;
            btn.innerHTML = orig;
        }
    }

    function populateAppbarLogo() {
        // Iter 15: the appbar is the APP's chrome, not the school's branding.
        // It ALWAYS shows the TerminalReport brand logo (assets/app-logo.png),
        // regardless of whether the school uploaded a logo via Settings. The
        // brand text "TerminalReport" is set in the HTML default and never
        // changed by JS. So this function just (re-)renders the brand logo.
        //
        // (Previously Iter 9: this function set the brand text to info.name
        // and used the school's uploaded logo. That mixed school branding
        // into the app's chrome.)
        const logoBox = $('appbarLogo');
        if (logoBox) {
            logoBox.innerHTML = '<img src="assets/app-logo.png" alt="TerminalReport logo">';
        }
    }

    async function handleBackupNow() {
        const btn = $('backupNowBtn');
        btn.disabled = true;
        const orig = btn.innerHTML;
        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Backing up...';
        try {
            const result = await window.TerminalReportBackup.exportNow();
            if (result.ok) {
                if (result.method === 'fs-access') {
                    UI.alert('Backup saved to your chosen location:\n' + result.filename);
                } else {
                    UI.alert('Backup downloaded to your Downloads folder:\n' + result.filename);
                }
            } else if (result.error !== 'Cancelled') {
                UI.alert('Backup failed: ' + result.error);
            }
        } catch (e) {
            UI.alert('Backup failed: ' + (e.message || e));
        } finally {
            btn.disabled = false;
            btn.innerHTML = orig;
        }
    }

    async function handleRestoreFromFile(e) {
        const file = e.target.files[0];
        if (!file) return;
        if (!(await UI.confirm('Restore from this backup? This will REPLACE your current database with the backup contents. Make sure you have a current backup first.', { variant: 'danger', okText: 'Restore' }))) {
            e.target.value = ''; // allow re-picking the same file after cancel
            return;
        }
        // Iteration 32 (BUSY-04): disable the Restore button while the import
        // runs so the flow cannot be started a second time against a
        // half-replaced database. The page reloads on success; the finally
        // below restores the button on every failure path.
        const restoreBtn = $('restoreBtn');
        const origHtml = restoreBtn ? restoreBtn.innerHTML : null;
        if (restoreBtn) {
            restoreBtn.disabled = true;
            restoreBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Restoring…';
        }
        try {
            const result = await window.TerminalReportBackup.importFromFile(file);
            if (result.ok) {
                // Await so the user actually sees the dialog before the reload
                // wipes it (native alert blocked JS here; a modal does not).
                // Iter 31 audit fix (XFILE-01): this line previously called
                // UI.UI.alert(); TerminalReportUI exposes alert() directly, so
                // the undefined .UI property threw a TypeError on EVERY
                // successful restore. The catch block then showed a false
                // "Restore failed" message and the reload never ran, leaving
                // the user on the restored database believing the restore
                // had failed.
                await UI.alert('Restore successful. The app will reload to apply the changes.', { variant: 'success' });
                location.reload();
            } else {
                UI.alert('Restore failed: ' + (result.reason || 'Unknown error'));
            }
        } catch (err) {
            UI.alert('Restore failed: ' + (err.message || err));
        } finally {
            e.target.value = '';
            if (restoreBtn) {
                restoreBtn.disabled = false;
                restoreBtn.innerHTML = origHtml;
            }
        }
    }

    async function handleChangePin() {
        const oldPin = $('changePinOld').value;
        const newPin = $('changePinNew').value;
        const confirmPin = $('changePinConfirm').value;
        if (!/^\d{4}$/.test(oldPin)) { UI.alert('Current passcode must be 4 digits.'); return; }
        if (!/^\d{4}$/.test(newPin)) { UI.alert('New passcode must be 4 digits.'); return; }
        if (newPin !== confirmPin) { UI.alert('New passcode and confirmation do not match.'); return; }
        if (oldPin === newPin) { UI.alert('New passcode must be different from the current one.'); return; }

        const btn = $('changePinBtn');
        btn.disabled = true;
        const orig = btn.innerHTML;
        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Changing...';
        try {
            const result = await window.TerminalReportAuth.changePin(oldPin, newPin);
            if (result.success) {
                UI.alert('Passcode changed successfully.');
                $('changePinOld').value = '';
                $('changePinNew').value = '';
                $('changePinConfirm').value = '';
            } else {
                UI.alert('Failed to change passcode: ' + (result.error || 'Unknown error'));
            }
        } catch (e) {
            UI.alert('Failed to change passcode: ' + (e.message || e));
        } finally {
            btn.disabled = false;
            btn.innerHTML = orig;
        }
    }

    // ------------------------------------------------------------------
    // Phase C: Auto-backup on app close (beforeunload handler)
    // ------------------------------------------------------------------
    function initAutoBackupOnClose() {
        // Best-effort auto-backup. beforeunload handlers can't reliably do
        // async work (download, file IO) in modern browsers, they get killed
        // before completing. So we trigger an OPFS write (which is fast) and
        // rely on the manual "Backup Now" button for filesystem-level backups.
        //
        // The "Backing up database..." overlay is intentionally NOT shown on
        // beforeunload, it would just flash and confuse the user. We only
        // show it after explicit user actions (e.g., a future "Quit" button).
        window.addEventListener('beforeunload', function () {
            if (!window.TerminalReportBackup) return;
            if (!window.TerminalReportBackup.isAutoBackupEnabled()) return;
            // Fire-and-forget; we can't await in beforeunload reliably.
            // The promise may not resolve before the page unloads, but OPFS
            // writes are typically fast enough (<50ms) to complete for a tab close.
            try {
                window.TerminalReportBackup.autoBackup();
            } catch (e) {
                console.error('[backup] beforeunload auto-backup failed:', e);
            }
        });
    }

    // ------------------------------------------------------------------
    // Entry point
    // ------------------------------------------------------------------
    async function start() {
        if (!window.TerminalReportAuth) {
            // No auth module: fall through to main app (degraded mode)
            showMainApp();
            return;
        }
        try {
            const { configured } = await window.TerminalReportAuth.init();
            if (!configured) {
                showOverlay('setupWizard');
                initSetupWizard();
                return;
            }
            if (window.TerminalReportAuth.isUnlocked()) {
                showMainApp();
                return;
            }
            // Configured but not unlocked → show lock screen
            // Check if currently locked out (e.g., user closed and reopened during lockout)
            const st = window.TerminalReportAuth.getLockState();
            if (st.lockedUntil && Date.now() < st.lockedUntil) {
                setLockMessage('Locked out from previous attempts.', true);
            }
            showOverlay('lockScreen');
            // initLockScreen/initRecoveryScreen are called inside showMainApp()
            // to handle the post-setup flow. But if we came here directly (returning
            // user, not setup), we still need them. Use the same guard.
            if (!window.__terminalReportAuthUiInited) {
                window.__terminalReportAuthUiInited = true;
                initLockScreen();
                initRecoveryScreen();
                initSettingsScreen();
                initAutoBackupOnClose();
            }
        } catch (e) {
            console.error('[auth-ui] start failed:', e);
            // Degraded mode: show main app
            showMainApp();
        }
    }

    // ------------------------------------------------------------------
    // Export
    // ------------------------------------------------------------------
    window.TerminalReportAuthUI = {
        start: start,
        showMainApp: showMainApp
    };
})();
