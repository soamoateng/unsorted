/**
 * TerminalReport: backup layer (Phase C)
 *
 * Stack:
 *   - HMAC-SHA256 signing via crypto.subtle (Web Crypto API)
 *   - AES-GCM encryption (CRIT-18 fix), payload is now encrypted, not just signed
 *   - PBKDF2-SHA-256 (100,000 iterations) for key derivation from appUuid + salt
 *   - OPFS (Origin Private File System) for auto-backup storage
 *   - File System Access API (showSaveFilePicker / showOpenFilePicker) for
 *     manual backup/restore, with <a download> + <input type=file> fallback
 *   - App UUID (from Phase B auth row) as HMAC key + KDF input, backups are tied
 *     to the installation, so a backup from a different machine/install is rejected
 *
 * Public API (window.TerminalReportBackup):
 *   init()                              → Promise<void>  (ensures OPFS backup dir)
 *   isAutoBackupEnabled()               → boolean
 *   setAutoBackupEnabled(bool)          → void
 *   autoBackup()                        → Promise<void>  (writes to OPFS; silent on failure)
 *   exportNow()                         → Promise<{ok, error?}>  (triggers user-visible download)
 *   importFromFile(file)                → Promise<{ok, error?, reason?}>  (verifies signature)
 *   getOpfsAutoBackup()                 → Promise<Uint8Array|null>  (reads OPFS auto-backup bytes)
 *   isFileSystemAccessSupported()       → boolean
 *
 * Backup file format (binary), v2 (encrypted, current):
 *   Offset  Size  Field
 *   0       7     Magic: "TR-BAK2"
 *   7       1     Version: 2
 *   8       16    KDF salt (random per backup, used for PBKDF2 key derivation)
 *   24      12    AES-GCM nonce (random per backup)
 *   36      32    HMAC-SHA256(salt + nonce + ciphertext, key=appUuid)
 *   68      4     Ciphertext length (uint32, big-endian)
 *   72      N     Ciphertext (AES-GCM encrypted SQLite bytes; includes 16-byte GCM auth tag)
 *
 * Backup file format (binary), v1 (signed only, NOT encrypted, deprecated):
 *   Offset  Size  Field
 *   0       7     Magic: "TR-BAK1"
 *   7       1     Version: 1
 *   8       36    App UUID (UUIDv4 string, ASCII, stored in PLAINTEXT, known weakness)
 *   44      32    HMAC-SHA256(payload, key=app_uuid)
 *   76      4     Payload length (uint32, big-endian)
 *   80      N     Payload (raw SQLite bytes, NOT ENCRYPTED)
 *
 * v1 → v2 migration: v1 backups are still READABLE by parseAndVerifyBackup
 * (backward compat), but a console.warn is emitted to alert the user that
 * the file is unencrypted and should be re-exported. All NEW backups use v2.
 *
 * Threat model addressed by v2 (CRIT-18):
 *   - Cloud storage provider (iCloud, OneDrive, Google Drive) stores the .trbak
 *     file. v1 leaked student PII (names, DOBs, grades, photos) in plaintext.
 *     v2 encrypts the payload with AES-GCM, key derived from appUuid + per-backup
 *     salt via PBKDF2. The appUuid is NOT stored in the v2 header (only used as
 *     KDF input + HMAC key), so an attacker with only the .trbak file cannot
 *     decrypt the payload.
 *
 * Cross-file dependencies:
 *   - TerminalReportDb.export() returns the raw SQLite bytes, we use that as payload
 *   - TerminalReportAuth.getSchoolInfo().appUuid is the HMAC key + KDF input
 *   - TerminalReportDb.replaceDatabase(bytes) replaces the in-memory DB with new bytes
 *     (added in Phase C: see db.js)
 */
(function () {
    'use strict';

    // CRIT-18 fix: v2 magic + format for AES-GCM-encrypted backups.
    // v1 ("TR-BAK1") remains readable for backward compat (with console.warn).
    const MAGIC = 'TR-BAK2';
    const VERSION = 2;
    const V1_MAGIC = 'TR-BAK1';     // legacy, unencrypted
    const V1_VERSION = 1;
    const V1_HEADER_LEN = 7 + 1 + 36 + 32 + 4; // 80 bytes

    // v2 header layout
    const SALT_LEN = 16;            // PBKDF2 salt, random per backup
    const NONCE_LEN = 12;           // AES-GCM nonce, random per backup
    const UUID_LEN = 36;            // v1 only, appUuid stored in plaintext header
    const HMAC_LEN = 32;
    const HEADER_LEN = 7 + 1 + SALT_LEN + NONCE_LEN + HMAC_LEN + 4; // 72 bytes
    const PBKDF2_ITERATIONS = 100000;

    const LS_AUTOBACKUP_KEY = 'terminalreport-autobackup-enabled';
    const OPFS_BACKUP_DIR = 'terminalreport-backups';
    const OPFS_AUTO_FILENAME = 'auto.trbak';

    let opfsBackupDirHandle = null;
    let opfsInitPromise = null;

    // ------------------------------------------------------------------
    // Helpers
    // ------------------------------------------------------------------

    /** Encode a string to UTF-8 bytes. */
    function strToBytes(s) {
        return new TextEncoder().encode(s);
    }

    /** Concatenate N Uint8Arrays into one. */
    function concatBytes(arrays) {
        let total = 0;
        for (let i = 0; i < arrays.length; i++) total += arrays[i].length;
        const out = new Uint8Array(total);
        let offset = 0;
        for (let i = 0; i < arrays.length; i++) {
            out.set(arrays[i], offset);
            offset += arrays[i].length;
        }
        return out;
    }

    /** Compute HMAC-SHA256(payload, key=keyStr) → 32-byte Uint8Array. */
    async function hmacSha256(keyStr, payloadBytes) {
        if (!crypto.subtle) {
            throw new Error('crypto.subtle unavailable. Serve via HTTPS or localhost.');
        }
        const enc = new TextEncoder();
        const key = await crypto.subtle.importKey(
            'raw',
            enc.encode(keyStr),
            { name: 'HMAC', hash: 'SHA-256' },
            false,
            ['sign']
        );
        const sigBuf = await crypto.subtle.sign('HMAC', key, payloadBytes);
        return new Uint8Array(sigBuf);
    }

    // ------------------------------------------------------------------
    // CRIT-18 fix: AES-GCM encryption helpers
    // ------------------------------------------------------------------

    /** Generate cryptographically-secure random bytes via crypto.getRandomValues. */
    function randomBytes(n) {
        const out = new Uint8Array(n);
        crypto.getRandomValues(out);
        return out;
    }

    /**
     * Derive an AES-GCM 256-bit key from appUuid + salt via PBKDF2.
     * Returns a CryptoKey suitable for encrypt/decrypt with AES-GCM.
     */
    async function deriveAesGcmKey(appUuid, saltBytes) {
        if (!crypto.subtle) {
            throw new Error('crypto.subtle unavailable. Serve via HTTPS or localhost.');
        }
        const enc = new TextEncoder();
        const keyMaterial = await crypto.subtle.importKey(
            'raw',
            enc.encode(appUuid),
            { name: 'PBKDF2' },
            false,
            ['deriveKey']
        );
        return await crypto.subtle.deriveKey(
            { name: 'PBKDF2', salt: saltBytes, iterations: PBKDF2_ITERATIONS, hash: 'SHA-256' },
            keyMaterial,
            { name: 'AES-GCM', length: 256 },
            false,
            ['encrypt', 'decrypt']
        );
    }

    /**
     * AES-GCM encrypt: returns ciphertext bytes (plaintext length + 16-byte GCM auth tag).
     * The 12-byte nonce is prepended to the returned bytes for caller convenience.
     */
    async function aesGcmEncrypt(key, plaintext, nonce) {
        const cipherBuf = await crypto.subtle.encrypt(
            { name: 'AES-GCM', iv: nonce, tagLength: 128 },
            key,
            plaintext
        );
        return new Uint8Array(cipherBuf);
    }

    /** AES-GCM decrypt: throws if GCM auth tag fails (tamper / wrong key). */
    async function aesGcmDecrypt(key, ciphertext, nonce) {
        const plainBuf = await crypto.subtle.decrypt(
            { name: 'AES-GCM', iv: nonce, tagLength: 128 },
            key,
            ciphertext
        );
        return new Uint8Array(plainBuf);
    }

    /** Convert a hex string to Uint8Array (32-byte HMAC → 32-byte array). */
    function hexToBytes(hex) {
        const out = new Uint8Array(hex.length / 2);
        for (let i = 0; i < hex.length; i += 2) {
            out[i / 2] = parseInt(hex.substr(i, 2), 16);
        }
        return out;
    }

    /** Convert Uint8Array to hex string (lowercase). */
    function bytesToHex(bytes) {
        let hex = '';
        for (let i = 0; i < bytes.length; i++) {
            hex += bytes[i].toString(16).padStart(2, '0');
        }
        return hex;
    }

    /** Are two Uint8Arrays equal (constant-time-ish for crypto use)? */
    function constantTimeEqual(a, b) {
        if (a.length !== b.length) return false;
        let diff = 0;
        for (let i = 0; i < a.length; i++) {
            diff |= a[i] ^ b[i];
        }
        return diff === 0;
    }

    /** Get the app UUID from TerminalReportAuth (cached). Throws if not configured. */
    function getAppUuid() {
        if (!window.TerminalReportAuth) throw new Error('TerminalReportAuth not loaded');
        const info = window.TerminalReportAuth.getSchoolInfo();
        if (!info || !info.appUuid) throw new Error('App not configured; complete setup first');
        return info.appUuid;
    }

    /** Write uint32 big-endian. */
    function writeUint32BE(value) {
        const out = new Uint8Array(4);
        out[0] = (value >>> 24) & 0xff;
        out[1] = (value >>> 16) & 0xff;
        out[2] = (value >>> 8) & 0xff;
        out[3] = value & 0xff;
        return out;
    }

    /** Read uint32 big-endian from a Uint8Array at offset. */
    function readUint32BE(bytes, offset) {
        return (
            ((bytes[offset] << 24) >>> 0) +
            (bytes[offset + 1] << 16) +
            (bytes[offset + 2] << 8) +
            bytes[offset + 3]
        );
    }

    // ------------------------------------------------------------------
    // Public API
    // ------------------------------------------------------------------

    function isFileSystemAccessSupported() {
        return typeof window.showSaveFilePicker === 'function' &&
               typeof window.showOpenFilePicker === 'function';
    }

    function isAutoBackupEnabled() {
        try {
            return localStorage.getItem(LS_AUTOBACKUP_KEY) === '1';
        } catch (_) {
            return false;
        }
    }

    function setAutoBackupEnabled(enabled) {
        try {
            localStorage.setItem(LS_AUTOBACKUP_KEY, enabled ? '1' : '0');
        } catch (e) {
            console.error('[backup] failed to persist auto-backup setting:', e);
        }
    }

    async function init() {
        // Ensure OPFS backup dir exists. Idempotent, concurrent callers share the same promise.
        if (opfsInitPromise) return opfsInitPromise;
        opfsInitPromise = (async function () {
            try {
                if (!navigator.storage || !navigator.storage.getDirectory) {
                    console.warn('[backup] OPFS not supported, auto-backup disabled');
                    return;
                }
                opfsBackupDirHandle = await navigator.storage.getDirectory();
                // Create the subdir
                await opfsBackupDirHandle.getDirectoryHandle(OPFS_BACKUP_DIR, { create: true });
            } catch (e) {
                console.error('[backup] OPFS init failed:', e);
                opfsBackupDirHandle = null;
            }
        })().catch(function (e) {
            opfsInitPromise = null; // allow retry
            throw e;
        });
        return opfsInitPromise;
    }

    // ------------------------------------------------------------------
    // Backup file format: pack / unpack
    // ------------------------------------------------------------------

    /**
     * Build an encrypted + signed v2 backup file from SQLite bytes + app UUID.
     * Layout (72-byte header + ciphertext):
     *   [0..7)   magic "TR-BAK2"
     *   [7..8)   version byte (2)
     *   [8..24)  KDF salt (16 bytes, random per backup)
     *   [24..36) AES-GCM nonce (12 bytes, random per backup)
     *   [36..68) HMAC-SHA256(salt + nonce + ciphertext, key=appUuid), 32 bytes
     *   [68..72) ciphertext length (uint32 BE)
     *   [72..N)  AES-GCM ciphertext of SQLite bytes (includes 16-byte GCM tag)
     */
    async function buildBackupFile(sqliteBytes, appUuid) {
        // 1. Generate per-backup salt + nonce
        const salt = randomBytes(SALT_LEN);
        const nonce = randomBytes(NONCE_LEN);
        // 2. Derive AES-GCM key from appUuid + salt (PBKDF2-SHA-256, 100k iter)
        const aesKey = await deriveAesGcmKey(appUuid, salt);
        // 3. Encrypt the SQLite payload (output includes 16-byte GCM auth tag)
        const ciphertext = await aesGcmEncrypt(aesKey, sqliteBytes, nonce);
        // 4. HMAC over (salt + nonce + ciphertext) for tamper detection
        //    (AES-GCM already provides integrity, but HMAC adds defense-in-depth
        //    and lets us reject wrong-key attempts BEFORE attempting GCM decrypt.)
        const hmacInput = concatBytes([salt, nonce, ciphertext]);
        const hmac = await hmacSha256(appUuid, hmacInput);
        // 5. Assemble header
        const header = new Uint8Array(HEADER_LEN);
        header.set(strToBytes(MAGIC), 0);
        header[7] = VERSION;
        header.set(salt, 8);
        header.set(nonce, 8 + SALT_LEN);
        header.set(hmac, 8 + SALT_LEN + NONCE_LEN);
        header.set(writeUint32BE(ciphertext.length), 8 + SALT_LEN + NONCE_LEN + HMAC_LEN);
        // 6. Concat header + ciphertext
        return concatBytes([header, ciphertext]);
    }

    /**
     * Parse + verify a backup file (supports v2 encrypted + v1 legacy unencrypted).
     * Returns { ok: true, payload: Uint8Array, version: N } on success.
     * Returns { ok: false, reason: string } on failure.
     */
    async function parseAndVerifyBackup(bytes, expectedAppUuid) {
        if (!(bytes instanceof Uint8Array)) bytes = new Uint8Array(bytes);
        if (bytes.length < 8) {
            return { ok: false, reason: 'File too small to be a backup (expected at least 8 bytes, got ' + bytes.length + ').' };
        }
        // Read magic (first 7 bytes) + version (byte 7)
        let magic = '';
        for (let i = 0; i < 7; i++) magic += String.fromCharCode(bytes[i]);
        const version = bytes[7];

        // ------------------------------------------------------------
        // v1 legacy path (unencrypted, backward compat)
        // ------------------------------------------------------------
        if (magic === V1_MAGIC) {
            if (version !== V1_VERSION) {
                return { ok: false, reason: 'Unsupported v1 backup version: ' + version + '. This app supports v1 (read) and v2 (read+write).' };
            }
            if (bytes.length < V1_HEADER_LEN) {
                return { ok: false, reason: 'v1 backup file too small (expected ≥' + V1_HEADER_LEN + ' bytes, got ' + bytes.length + ').' };
            }
            // v1 stores appUuid in plaintext header, compare to expected
            let fileUuid = '';
            for (let i = 0; i < UUID_LEN; i++) fileUuid += String.fromCharCode(bytes[8 + i]);
            if (fileUuid !== expectedAppUuid) {
                return { ok: false, reason: 'Backup was created by a different installation. Cannot restore (UUID mismatch).' };
            }
            const storedHmac = bytes.slice(8 + UUID_LEN, 8 + UUID_LEN + HMAC_LEN);
            const payloadLen = readUint32BE(bytes, 8 + UUID_LEN + HMAC_LEN);
            if (payloadLen <= 0 || payloadLen > bytes.length - V1_HEADER_LEN) {
                return { ok: false, reason: 'Backup file is corrupted (payload length mismatch).' };
            }
            const payload = bytes.slice(V1_HEADER_LEN, V1_HEADER_LEN + payloadLen);
            const computedHmac = await hmacSha256(expectedAppUuid, payload);
            if (!constantTimeEqual(storedHmac, computedHmac)) {
                return { ok: false, reason: 'Backup signature mismatch; the file may have been tampered with.' };
            }
            console.warn('[backup] Restoring v1 (unencrypted) backup. Re-export to upgrade to encrypted v2 format.');
            return { ok: true, payload: payload, version: 1 };
        }

        // ------------------------------------------------------------
        // v2 path (encrypted, current)
        // ------------------------------------------------------------
        if (magic !== MAGIC) {
            return { ok: false, reason: 'Not a TerminalReport backup file (bad magic: ' + JSON.stringify(magic) + ').' };
        }
        if (version !== VERSION) {
            return { ok: false, reason: 'Unsupported backup version: ' + version + '. This app supports version ' + VERSION + ' (and v1 for backward compat).' };
        }
        if (bytes.length < HEADER_LEN) {
            return { ok: false, reason: 'Backup file too small (expected ≥' + HEADER_LEN + ' bytes, got ' + bytes.length + ').' };
        }
        // Parse v2 header fields
        const salt = bytes.slice(8, 8 + SALT_LEN);
        const nonce = bytes.slice(8 + SALT_LEN, 8 + SALT_LEN + NONCE_LEN);
        const storedHmac = bytes.slice(8 + SALT_LEN + NONCE_LEN, 8 + SALT_LEN + NONCE_LEN + HMAC_LEN);
        const payloadLen = readUint32BE(bytes, 8 + SALT_LEN + NONCE_LEN + HMAC_LEN);
        if (payloadLen <= 0 || payloadLen > bytes.length - HEADER_LEN) {
            return { ok: false, reason: 'Backup file is corrupted (ciphertext length mismatch).' };
        }
        const ciphertext = bytes.slice(HEADER_LEN, HEADER_LEN + payloadLen);
        // HMAC over (salt + nonce + ciphertext) using appUuid
        const hmacInput = concatBytes([salt, nonce, ciphertext]);
        const computedHmac = await hmacSha256(expectedAppUuid, hmacInput);
        if (!constantTimeEqual(storedHmac, computedHmac)) {
            // Don't reveal whether the file is from a different install vs tampered,
            // both produce HMAC mismatch. Use the same message.
            return { ok: false, reason: 'Backup signature mismatch; the file may be from a different installation or may have been tampered with.' };
        }
        // HMAC is valid → appUuid is correct. Derive AES-GCM key and decrypt.
        const aesKey = await deriveAesGcmKey(expectedAppUuid, salt);
        let plaintext;
        try {
            plaintext = await aesGcmDecrypt(aesKey, ciphertext, nonce);
        } catch (e) {
            // GCM auth tag failure means tampering that HMAC missed (shouldn't
            // happen since HMAC verified), or a corrupted ciphertext.
            return { ok: false, reason: 'Backup decryption failed; the file is corrupted.' };
        }
        return { ok: true, payload: plaintext, version: 2 };
    }

    // ------------------------------------------------------------------
    // Auto-backup to OPFS
    // ------------------------------------------------------------------

    async function autoBackup() {
        if (!isAutoBackupEnabled()) return;
        if (!opfsBackupDirHandle) {
            await init();
            if (!opfsBackupDirHandle) return; // OPFS not available
        }
        try {
            if (!window.TerminalReportDb || !window.TerminalReportDb.isReady()) return;
            const sqliteBytes = window.TerminalReportDb.export();
            await _writeAutoBackup(sqliteBytes);
        } catch (e) {
            console.error('[backup] auto-backup failed:', e);
        }
    }

    // Iter 20 fix (PERF-02): accepts pre-exported bytes to avoid double db.export().
    // Called by db.js persist() which already has the bytes.
    async function autoBackupFromBytes(sqliteBytes) {
        if (!isAutoBackupEnabled()) return;
        if (!opfsBackupDirHandle) {
            await init();
            if (!opfsBackupDirHandle) return;
        }
        try {
            await _writeAutoBackup(sqliteBytes);
        } catch (e) {
            console.error('[backup] auto-backup (from bytes) failed:', e);
        }
    }

    // Shared helper: writes the signed backup to OPFS.
    // Iter 20 fix (RT-14): wrapped in try/finally to ensure writable.close()
    // is always called, even if write() throws.
    async function _writeAutoBackup(sqliteBytes) {
        const appUuid = getAppUuid();
        const backupBytes = await buildBackupFile(sqliteBytes, appUuid);
        const dirHandle = await opfsBackupDirHandle.getDirectoryHandle(OPFS_BACKUP_DIR, { create: true });
        const fileHandle = await dirHandle.getFileHandle(OPFS_AUTO_FILENAME, { create: true });
        const writable = await fileHandle.createWritable();
        try {
            await writable.write(backupBytes);
        } finally {
            await writable.close();
        }
    }

    async function getOpfsAutoBackup() {
        if (!opfsBackupDirHandle) {
            await init();
            if (!opfsBackupDirHandle) return null;
        }
        try {
            const dirHandle = await opfsBackupDirHandle.getDirectoryHandle(OPFS_BACKUP_DIR);
            const fileHandle = await dirHandle.getFileHandle(OPFS_AUTO_FILENAME);
            const file = await fileHandle.getFile();
            const buf = await file.arrayBuffer();
            return new Uint8Array(buf);
        } catch (_) {
            // File doesn't exist or other error
            return null;
        }
    }

    // ------------------------------------------------------------------
    // Manual backup (export): uses the File System Access API or the <a download> fallback
    // ------------------------------------------------------------------

    async function exportNow() {
        if (!window.TerminalReportDb || !window.TerminalReportDb.isReady()) {
            return { ok: false, error: 'Database not ready.' };
        }
        try {
            const sqliteBytes = window.TerminalReportDb.export();
            const appUuid = getAppUuid();
            const backupBytes = await buildBackupFile(sqliteBytes, appUuid);
            const filename = buildBackupFilename();

            if (isFileSystemAccessSupported()) {
                // Use the File System Access API so the user picks the save location
                const fileHandle = await window.showSaveFilePicker({
                    suggestedName: filename,
                    types: [{
                        description: 'TerminalReport Backup',
                        accept: { 'application/octet-stream': ['.trbak'] }
                    }]
                });
                const writable = await fileHandle.createWritable();
                await writable.write(backupBytes);
                await writable.close();
                return { ok: true, method: 'fs-access', filename: filename };
            }

            // Fallback: trigger a download
            const blob = new Blob([backupBytes], { type: 'application/octet-stream' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = filename;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            setTimeout(function () { URL.revokeObjectURL(url); }, 1000);
            return { ok: true, method: 'download', filename: filename };
        } catch (e) {
            // User cancelled picker, etc.
            if (e && e.name === 'AbortError') return { ok: false, error: 'Cancelled' };
            return { ok: false, error: e.message || 'Backup failed' };
        }
    }

    function buildBackupFilename() {
        const now = new Date();
        const ymd = now.getFullYear() +
            String(now.getMonth() + 1).padStart(2, '0') +
            String(now.getDate()).padStart(2, '0');
        const hms = String(now.getHours()).padStart(2, '0') +
            String(now.getMinutes()).padStart(2, '0') +
            String(now.getSeconds()).padStart(2, '0');
        return 'terminalreport-backup-' + ymd + '-' + hms + '.trbak';
    }

    // ------------------------------------------------------------------
    // Manual restore (import): uses the File System Access API or <input type=file>
    // ------------------------------------------------------------------

    /**
     * Verify + restore from a File object.
     * Calls TerminalReportDb.replaceDatabase(payload) on success.
     * Returns { ok: true } or { ok: false, reason: string }.
     */
    async function importFromFile(file) {
        if (!file) return { ok: false, reason: 'No file provided.' };
        try {
            const buf = await file.arrayBuffer();
            const bytes = new Uint8Array(buf);
            const appUuid = getAppUuid();
            const result = await parseAndVerifyBackup(bytes, appUuid);
            if (!result.ok) return result;
            // Replace the in-memory DB
            if (window.TerminalReportDb && typeof window.TerminalReportDb.replaceDatabase === 'function') {
                await window.TerminalReportDb.replaceDatabase(result.payload);
                // Also re-init TerminalReportAuth so it picks up the new auth row
                if (window.TerminalReportAuth && typeof window.TerminalReportAuth.refresh === 'function') {
                    await window.TerminalReportAuth.refresh();
                }
                return { ok: true };
            }
            return { ok: false, reason: 'TerminalReportDb.replaceDatabase is not available; update db.js to Phase C.' };
        } catch (e) {
            return { ok: false, reason: e.message || 'Restore failed' };
        }
    }

    // ------------------------------------------------------------------
    // Export
    // ------------------------------------------------------------------
    window.TerminalReportBackup = {
        init: init,
        isAutoBackupEnabled: isAutoBackupEnabled,
        setAutoBackupEnabled: setAutoBackupEnabled,
        autoBackup: autoBackup,
        autoBackupFromBytes: autoBackupFromBytes, // Iter 20: avoids double db.export()
        exportNow: exportNow,
        importFromFile: importFromFile,
        getOpfsAutoBackup: getOpfsAutoBackup,
        isFileSystemAccessSupported: isFileSystemAccessSupported,
        // Exposed for tests
        _buildBackupFile: buildBackupFile,
        _parseAndVerifyBackup: parseAndVerifyBackup,
        _HEADER_LEN: HEADER_LEN,
        _MAGIC: MAGIC,
        _VERSION: VERSION,
        _V1_MAGIC: V1_MAGIC,
        _V1_HEADER_LEN: V1_HEADER_LEN,
        _deriveAesGcmKey: deriveAesGcmKey,
        _aesGcmEncrypt: aesGcmEncrypt,
        _aesGcmDecrypt: aesGcmDecrypt,
        _randomBytes: randomBytes,
        _hmacSha256: hmacSha256
    };
})();
