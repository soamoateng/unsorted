/*
 * Service Worker: TerminalReport
 *
 * Strategy (KISS, deliberately minimal):
 *   - Pre-cache the app shell (HTML, CSS, JS, icons, manifest, AND vendored
 *     libraries) on install.
 *   - Cache-first for same-origin static assets (now includes vendor/).
 *   - Network-first for navigation requests (the HTML) so updates land when
 *     online, but fall back to cached index.html when offline.
 *
 * Iter 13 change: Bootstrap, Font Awesome, and sql.js are now vendored
 * locally under vendor/. The previous stale-while-revalidate path for CDN
 * hosts is gone; there is no CDN traffic anymore. The app is fully offline-
 * capable on FIRST load (the previous SW cached CDN responses on first
 * successful fetch but would fail on a fresh install with no network).
 *
 * NOT in scope (deliberate KISS guard):
 *   - No background sync, no push, no periodic sync, as none is needed for an
 *     offline single-tenant report generator.
 *   - No IndexedDB caching layer, because SQLite WASM (Iteration 3) owns its own
 *     persistence; we don't want a second cache to manage.
 *
 * Bump CACHE_VERSION on every deploy to invalidate old caches.
 */

/*
 * Iter 23 change: CACHE_VERSION bumped v21 → 'terminalreport-v23'.
 * NOTE: v22 was SKIPPED: iteration 22 (CRIT-16..18 fixes in admin-ui.js,
 * backup.js, index.html) shipped without a cache bump, so 'v22' was never
 * deployed to any client. The jump v21 → v23 is intentional: this deploy
 * picks up BOTH the iter-22 fixes AND the iter-23 fixes (CRIT-19/20/21 +
 * BLIND-7/8/9) in one invalidation. Clients on v21 will delete the old
 * cache on activate and re-precache every asset from the network.
 *
 * Iter 24 change: CACHE_VERSION bumped v23 → 'terminalreport-v24', the
 * Iter-24 audit fixed BLIND-10/11/12 in batch-ui.js, db.js and auth-ui.js.
 * (v23 itself was never deployed beyond the local build, but the project
 * convention is to bump on every change batch, so v24 it is.)
 *
 * Iter 25 change: CACHE_VERSION bumped v24 → 'terminalreport-v26' (v25 was
 * consumed by the local test build). Two changes ship together:
 *   1. The responsive-width fix (styles.css width ladder + index.html
 *      dashboard shell), users testing on XAMPP/desktop saw every screen
 *      squeezed into a centred column with large empty side margins.
 *   2. The install handler now precaches with Request({cache:'reload'}),
 *      during testing, the v25 install precached the STALE stylesheet from
 *      the browser's HTTP cache (python http.server / XAMPP send no
 *      Cache-Control), so the new CSS never reached the page. See the
 *      install handler comment for the full post-mortem.
 *
 * Iter 26 change: CACHE_VERSION bumped v26 → 'terminalreport-v27'. Iter 26
 * is a targeted re-audit of the auth/backup/CSV/marks paths (attempting to
 * close out the seven CRIT IDs whose records were lost with the Iter-21
 * audit list). Outcomes shipped here: auth.js; setup() now refuses to run
 * when the app is already configured (a stray re-setup would rotate the app
 * UUID and orphan every existing .trbak backup, since the UUID is the
 * backup HMAC key); auth.js refresh() docstring corrected (it never reset
 * the unlock flag). No behaviour changes anywhere else.
 *
 * Iter 27 change: CACHE_VERSION bumped v27 → 'terminalreport-v28'. UI bug
 * audit of the wizard steppers (user-reported + same-class sweep):
 *   1. Both stepper connector lines used hardcoded px offsets (auth 30px,
 *      batch 50px) that ignored the real circle positions (flex:1 steps put
 *      circle centres at 100/(2N)% of the row), leaving stray line stubs
 *      poking out past the first/last nodes. Lines now anchor at those
 *      percentages; the <=480px px overrides were removed (no longer needed).
 *   2. .batch-step.done checkmark had content '\\2713' (double backslash →
 *      CSS rendered literal "\2713") and inherited font-size: 0 from the
 *      number-hiding rule, because done steps showed empty green circles. Now
 *      proper '\2713' at 1rem/600.
 *
 * Iter 28 change: CACHE_VERSION bumped v28 → 'terminalreport-v29'. User-
 * reported bug fixes + whole-app UI audit:
 *   1. DUP-01: the batch wizard's "Which Term" field (#bwTerm) duplicated
 *      "Academic Term" (#bwAcademicTerm) with a DIFFERENT default; its value
 *      was stored but never read. Field/state removed; legacy batches.term
 *      column now filled from academicTerm in batch.js.
 *   2. DLG-01: every native alert()/confirm() (80 calls across batch-ui,
 *      admin-ui, script, auth-ui) replaced with a shared in-app modal
 *      (js/ui.js + #appDialog), queued, focus-managed, keyboard-accessible,
 *      variant-styled, textContent-rendered (XSS-safe).
 *
 * Iter 28b change: CACHE_VERSION bumped v29 → 'terminalreport-v30'. The v29
 * precache had already been consumed by live testing when a regression in
 * batch-ui.js freshState() (className key accidentally dropped during the
 * DUP-01 edit, making the Class Name field show "undefined") was caught in
 * browser verification and fixed. Cache-first serving means same-version
 * patches never reach installed clients, hence the bump.
 *
 * Iter 29 change: CACHE_VERSION bumped v30 → 'terminalreport-v31'. Text
 * pass across every first-party file: every em dash removed and rewritten
 * into free-flowing sentences, user-visible copy converted to British
 * English spelling (Primary Colour, Greyscale, centred, behaviour,
 * normalised, recognise, initialise), missing-value placeholders on the
 * report card, dashboard and settings changed from a bare dash to 'n/a' or
 * 'Not set', and empty-state option labels ("Enter manually", "Select
 * year", "Use default") stripped of decorative dashes. String changes in
 * backup.js reasons, titles and hints are user-visible; no logic changed.
 *
 * Iter 30 change: CACHE_VERSION bumped v31 → 'terminalreport-v32'. Form
 * restructure across the batch wizard and the report card: gender choice
 * limited to Male/Female in both pickers, Total Days moved from the
 * per-student Attendance table into Basic Info as a batch-wide field,
 * Teacher Remark moved from the Attendance table into a dedicated column
 * of the Step 4 marks grid, and the report card gained a Subject Rank
 * column (ordinals such as '1st') replacing the '#N' badge inside the
 * Grade cell, plus inline student info labels. JS, HTML and CSS all
 * changed; the data shape stays summary-compatible (totalDays is now read
 * from the batch input, remarks still live in the attendance slots).
 *
 * Iter 31 change: CACHE_VERSION bumped v32 → 'terminalreport-v33'. A full
 * vanilla JS business-logic audit ran over every module after the Iter-30
 * restructure. Fixes shipped: the restore-success dialog no longer throws
 * (XFILE-01), report cards honour custom grading scales in both the
 * per-subject grades and the printed legend (SCALE-01), days present
 * rejects negative and non-integer input (VAL-01), the Generate button is
 * double-click safe for the whole flow (RACE-01), restored backups from
 * older schemas are migrated on import (CONS-02), dashboard summary
 * re-renders once the DB init resolves (WF-01), ranking ties survive
 * floating-point artefacts (FLT-01), saved-report timestamps render in
 * local time (TZ-01), stale async responses can no longer overwrite newer
 * list renders (ASYNC-01), and the class-creation dropdowns report
 * failures instead of unhandled rejections (ERR-01).
 *
 * Iter 32 change: CACHE_VERSION bumped v33 → 'terminalreport-v34'. A UI
 * rendering/interaction audit ran over every module with a user-supplied
 * checklist (events, forms, focus, modals, async UI, data binding, DOM
 * quirks) plus 31 numbered bug patterns. Fixes shipped: the student profile
 * modal ignores stale responses and surfaces DB failures (RACE-02); the
 * admin add/save/confirm buttons, CSV import, restore and saved-report
 * print/delete flows are busy-guarded so double-clicks cannot duplicate
 * work (BUSY-01..04); the app dialog traps Tab and owns Enter/Escape even
 * over other modals, while the three read-only modals gained Escape-to-
 * close, focus move/restore and scroll reset via the new wireModal helper
 * (KEY-01, SCROLL-01); report-card blob URLs are revoked on close/print so
 * large batches no longer pin logo/photo memory (LEAK-01); the managed-
 * class picker ignores superseded selections (SEL-01); wizard grids clear
 * their invalid marks while typing (VAL-02); and two misleading error
 * paths now tell the truth (ERR-02, ERR-03).
 */
const CACHE_VERSION = 'terminalreport-v34';
const APP_SHELL = [
  './',
  './index.html',
  './css/styles.css',
  './js/db.js',          // Iter 3: persistence layer (Iter 13: vendored sql.js path)
  './js/ui.js',          // Iter 28: shared in-app alert/confirm dialog module (DLG-01)
  './js/auth.js',        // Phase B: auth module (PIN/lockout/recovery)
  './js/backup.js',      // Phase C: backup module (HMAC-SHA256, OPFS)
  './js/batch.js',       // Phase D: batch generation logic (ranking, grades, cert numbers)
  './js/batch-ui.js',    // Phase D: batch wizard UI controller (Iter 9: Phase E pre-fill; Iter 10: template-aware Print All; Iter 13: photo upload Step 3; Iter 14: subject_marks pre-fill Step 4)
  './js/admin-ui.js',    // Phase E: admin & manage class UI (Iter 12: subject-marks modal; Iter 13: inline validation)
  './js/auth-ui.js',     // Phase B+C: auth UI controller + settings UI (Iter 15: appbar shows TerminalReport brand, not school name)
  './js/script.js',      // main form + report rendering + saved-reports panel (Iter 11: search/filter; Iter 13: subject rank on card)
  './manifest.webmanifest',
  './assets/app-logo.png',   // Iter 9: TerminalReport brand logo (appbar/lock fallback)

  // Iter 13: vendored libraries (previously loaded from cdnjs)
  './vendor/bootstrap/bootstrap.min.css',
  './vendor/bootstrap/bootstrap.bundle.min.js',
  './vendor/font-awesome/css/all.min.css',
  './vendor/font-awesome/webfonts/fa-solid-900.woff2',
  './vendor/font-awesome/webfonts/fa-regular-400.woff2',
  './vendor/font-awesome/webfonts/fa-brands-400.woff2',
  './vendor/sql.js/sql-wasm.js',
  './vendor/sql.js/sql-wasm.wasm',

  './icons/icon-192.png',
  './icons/icon-512.png',
  './icons/apple-touch-icon.png',
  './icons/favicon-32.png'
];

// ------------------------------------------------------------------
// Install: pre-cache app shell
// ------------------------------------------------------------------
self.addEventListener('install', function (event) {
  event.waitUntil(
    caches.open(CACHE_VERSION).then(function (cache) {
      // addAll is atomic: if any single fetch fails, none are cached.
      // That's the right default for the app shell.
      //
      // Iter 25 fix: each URL is fetched with { cache: 'reload' }, because a plain
      // addAll(url-string) may resolve through the browser's HTTP cache,
      // which can hold a heuristically-fresh STALE copy (dev servers like
      // `python3 -m http.server` and XAMPP Apache send no Cache-Control).
      // Reproduced locally: after shipping a CSS change, the new SW version
      // precached the OLD stylesheet straight out of the HTTP cache, so the
      // layout fix never reached the page until a full site-data wipe.
      // Request-level `cache: 'reload'` bypasses the HTTP cache and always
      // hits the network, guaranteeing the precache matches what's deployed.
      // (Per-request options on addAll are supported in all evergreen
      // browsers; sql-wasm.wasm and the fonts are included and behave like
      // any other entry.)
      return cache.addAll(APP_SHELL.map(function (url) {
        return new Request(url, { cache: 'reload' });
      })).catch(function (err) {
        console.warn('[sw] some app-shell assets failed to pre-cache:', err);
      });
    }).then(function () {
      // Activate immediately; do not wait for the old SW to release control.
      return self.skipWaiting();
    })
  );
});

// ------------------------------------------------------------------
// Activate: clean up old caches
// ------------------------------------------------------------------
self.addEventListener('activate', function (event) {
  event.waitUntil(
    caches.keys().then(function (keys) {
      return Promise.all(
        keys
          .filter(function (k) { return k !== CACHE_VERSION; })
          .map(function (k) {
            console.log('[sw] deleting old cache:', k);
            return caches.delete(k);
          })
      );
    }).then(function () {
      // Take control of all open clients immediately.
      return self.clients.claim();
    })
  );
});

// ------------------------------------------------------------------
// Fetch: route by request type
// ------------------------------------------------------------------
self.addEventListener('fetch', function (event) {
  const req = event.request;

  // Only handle GET; never intercept POST/PUT (none in this app; SQLite
  // WASM saves data via OPFS, not HTTP).
  if (req.method !== 'GET') return;

  const url = new URL(req.url);
  const isSameOrigin = url.origin === self.location.origin;

  // Navigation requests (the HTML page): network-first, falling back to cache
  if (req.mode === 'navigate') {
    event.respondWith(
      fetch(req)
        .then(function (res) {
          const copy = res.clone();
          caches.open(CACHE_VERSION).then(function (c) { c.put('./index.html', copy); });
          return res;
        })
        .catch(function () {
          return caches.match('./index.html');
        })
    );
    return;
  }

  // Iter 13: all app assets are now same-origin (vendor/ included). The old
  // CDN_HOSTS check + stale-while-revalidate branch is removed, without a
  // CDN, there's nothing to SWR. Cache-first for everything same-origin.
  if (isSameOrigin) {
    event.respondWith(
      caches.match(req).then(function (cached) {
        if (cached) return cached;
        return fetch(req).then(function (res) {
          if (res && res.status === 200 && res.type === 'basic') {
            const copy = res.clone();
            caches.open(CACHE_VERSION).then(function (c) { c.put(req, copy); });
          }
          return res;
        });
      })
    );
    return;
  }

  // Everything else (cross-origin, rare; e.g., a fetch the app makes to a
  // third-party API), straight to network. Intentionally not cached. KISS.
});

// ------------------------------------------------------------------
// Message: allow page to trigger SW update
// ------------------------------------------------------------------
self.addEventListener('message', function (event) {
  if (event.data === 'SKIP_WAITING') {
    self.skipWaiting();
  }
});
