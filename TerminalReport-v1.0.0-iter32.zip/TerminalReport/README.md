# TerminalReport

A school terminal report card generator. Built with vanilla JavaScript, sql.js (SQLite compiled to WASM), and Bootstrap 5.3. PWA-ready and packageable via PWABuilder for Windows, Android, and iOS.

## Quick Start

```bash
cd TerminalReport
python3 -m http.server 8080
# Open http://localhost:8080/ in Chrome or Edge
```

⚠️ **The PIN feature uses `crypto.subtle`, which requires HTTPS or `http://localhost`**. Opening the `index.html` directly from disk (`file://`) will not work; the setup wizard will fail silently. Always serve via HTTP.

## Project Structure

```
TerminalReport/
├── index.html                 : main HTML (Iter 16: clean 3-button dashboard, no single-report form; + saved report viewer modal)
├── manifest.webmanifest       : PWA manifest (name: TerminalReport)
├── sw.js                       : service worker (cache terminalreport-v24, cache-first, ALL assets same-origin, true offline-first)
├── README.md                   : this file
├── WORKLOG.md                  : canonical iteration record (read first)
├── ROADMAP.md                  : phase status + remaining roadmap (read second)
├── assets/
│   └── app-logo.png            : TerminalReport brand logo (appbar ALWAYS uses this since Iter 15; lock fallback)
├── css/
│   └── styles.css              : all CSS (Bootstrap + app styles + theme vars + auth/batch/admin overlays + Iter 11 saved-reports toolbar + Iter 12 subject-marks table + Bootstrap `.btn-primary`/`.bg-primary` → `--app-primary` consistency sweep + Iter 13 subject-rank-badge + Step 3 photo thumbnail)
├── js/
│   ├── db.js                   : persistence layer (sql.js + IndexedDB, exposes window.TerminalReportDb; Iter 11 adds searchReports + listReportClasses; Iter 12 adds getSubject + saveSubjectMarks + listSubjectMarks + subject_marks table; Iter 13: sql.js path vendored; Iter 14 adds listSubjectMarksForClass)
│   ├── auth.js                 : auth module (crypto.subtle, exposes window.TerminalReportAuth)
│   ├── backup.js               : signed backups (HMAC-SHA256, OPFS, exposes window.TerminalReportBackup)
│   ├── batch.js                : batch logic (ranking, grades, exposes window.TerminalReportBatch), Iter 13: summary.totalStudents added for #10
│   ├── batch-ui.js             : 5-step wizard + managed-class pre-fill + template-aware batch print (window.TerminalReportBatchUI), Iter 13: Step 3 photo upload (#9); Iter 14: Step 4 marks pre-fill from subject_marks + renderStep4 thead/tbody bug fix
│   ├── admin-ui.js             : admin & manage-class UI + Iter 12 subject-marks modal + Iter 13 inline validation (#8) (window.TerminalReportAdminUI)
│   ├── auth-ui.js              : auth UI controller (setup wizard, lock screen, recovery, settings), Iter 15: appbar ALWAYS shows "TerminalReport" text + brand logo (not school name/logo)
│   └── script.js               : report card renderer + saved reports panel (Iter 16: single-report form removed; batch is default; added saved report viewer modal + printSavedReport)
├── vendor/                       : Iter 13: vendored CDN libraries (offline-first, no more cdnjs requests)
│   ├── bootstrap/bootstrap.min.css + bootstrap.bundle.min.js  (5.3.8)
│   ├── font-awesome/css/all.min.css + webfonts/{fa-solid,fa-regular,fa-brands}-*.woff2  (7.3.1)
│   └── sql.js/sql-wasm.js + sql-wasm.wasm  (1.14.2)
└── icons/                       : real TerminalReport logo set (Iter 9)
    ├── icon-192.png            : PWA icon 192x192
    ├── icon-512.png            : PWA icon 512x512
    ├── icon-192-maskable.png    : adaptive icon variant (safe-zone verified)
    ├── icon-512-maskable.png    : adaptive icon variant (safe-zone verified)
    ├── apple-touch-icon.png    : iOS home-screen icon
    └── favicon-32.png          : browser tab icon
```

## Iteration History

| Iter | Scope | Files Added/Changed |
|---|---|---|
| Iter 1 | Initial stress test + refactor of original 3 files (index.html, css/styles.css, js/script.js) | 3 changed |
| Iter 1 (cont.) | PWA scaffold + Font Awesome 7 upgrade + CSS variables theming | +3 new files (manifest, sw.js, icons) |
| Iter 2 | Image preview perf (URL.createObjectURL), input validation UI, accessibility fix | js/script.js modified, css/styles.css modified |
| Iter 3 | Persistence layer (sql.js + IndexedDB) + Saved Reports UI | +js/db.js, js/script.js modified |
| Iter 4 (Phase A) | "+" button UX fix, hardcoded → placeholders, 3 PDF templates | All files touched |
| Iter 4 (Phase B) | PIN + lockout + security question + recovery + lock button | +js/auth.js, +js/auth-ui.js |
| Iter 5 (Phase C) | Auto-backup on close + signed backups (HMAC-SHA256 with app UUID) + Settings UI + Change PIN | +js/backup.js, js/db.js modified (export/replaceDatabase + auto-backup hook), js/auth.js modified (refresh), js/auth-ui.js modified (settings controller), index.html modified (settings overlay + appbar settings button) |
| Iter 6 (Phase D) | Batch generation 5-step wizard (Basic Info → Subjects → Students → Marks grid → Attendance/Remarks) + transactional save + class ranking (ties allowed) + per-subject ranking + "Reports already exist" warning + batch preview with Print All + per-student view | +js/batch.js, +js/batch-ui.js, js/db.js modified (batches table + 6 batch methods), js/script.js modified (expose generateReportHTML + wire Start Batch button), index.html modified (wizard + preview + detail modal overlays), css/styles.css modified (wizard stepper, marks grid with sticky columns, batch preview cards) |
| Iter 7 (Phase E) | Admin/management UI: full DB normalisation (6 new tables: academic_years, grading_scales, grading_bands, classes, students, subjects) + CRUD for all entities + grading scale editor with bands + Manage Class screen with 3 tabs (Details, Students, Subjects) + promote/repeat student with same-year constraint + default scale seeding + grading scale integration into batch.js report generation | +js/admin-ui.js, js/db.js modified (6 tables + ~20 CRUD methods + seed default scale), js/batch.js modified (getGrade/computeSummary accept custom scale), index.html modified (admin overlay + scale editor + manage class overlay + 4 modals), css/styles.css modified (admin list, tabs) |
| Iter 8 (Rename) | Full app rename to **TerminalReport**: app name, project folder, all window globals (`Trg*` → `TerminalReport*`), `terminalreport:auth-complete` event, IndexedDB `terminalreport-db`, localStorage keys, OPFS `terminalreport-backups`, SW cache `terminalreport-v8`, backup magic `TR-BAK1` + `.trbak` extension, cert prefix `TR-`. User-authorised breaking rename (see WORKLOG.md Iteration 8 mapping table) | All files + docs |
| Iter 9 | **Batch wizard pre-fill from Phase E managed entities (roadmap #3)**: Step 1 "Pre-fill from Managed Class" dropdown auto-fills year/class/counts and pre-fills Steps 2/3 rosters from the admin tables (roll-number sorted, once-per-selection, switch guard); class grading scale now actually passed to batch generation (previously dormant); + **real app logo (roadmap #7)**: all 6 PWA icons regenerated from TerminalReport.png with maskable safe-zone verification, brand fallback in appbar/lock screen; + admin year-dropdown sync fix; SW cache v9 | js/batch-ui.js, js/auth-ui.js, js/admin-ui.js, index.html, sw.js, icons/* (all regenerated), +assets/app-logo.png, docs |
| Iter 10 | **Multi-template batch Print All (roadmap #4)**: PDF Template dropdown in the batch preview toolbar (primary / grayscale / no-logo, same options as the main form, defaults from it); chosen template applied to every report in Print All AND print-one; detail modal renders with the template and live-re-templates when the selector changes; template variant CSS mirrored into the print window's inline styles; print window title branded "TerminalReport: Batch Print"; SW cache v10 | index.html, js/batch-ui.js, sw.js, docs |
| Iter 11 | **Saved Reports search + filter (roadmap #1)**: db.js `searchReports({ studentName, className })` + `listReportClasses()`. New toolbar inside Saved Reports panel: debounced (200ms) search input with magnifying-glass icon, class-filter dropdown populated from distinct saved `student_class` values, result-count badge (`aria-live="polite"`), and a clear-search button that toggles visibility. Filtering happens in SQL via `INSTR(LOWER(student_name), ?) > 0` instead of `LIKE` to avoid `%`/`_` wildcard injection (verified by unit test). Dropdown options refresh on panel open + after every delete (preserves selection if the class still exists, resets otherwise). Empty-state distinguishes "no reports at all" vs "no matches for filter". 17/17 unit tests pass + 13/13 browser tests pass. SW cache v11 | js/db.js, js/script.js, index.html, css/styles.css, sw.js, docs |
| Iter 12 | **Subject marks entry (roadmap #2) + colour consistency sweep**: db.js adds new `subject_marks` table (with `UNIQUE(subject_id, student_id)` for UPSERT + cascade-delete on subject/student removal) and 3 new methods (`getSubject`, `saveSubjectMarks`, `listSubjectMarks`). Admin UI: after saving a NEW subject, immediately auto-opens an "Enter Marks" modal listing every student in the class with a numeric input + absent checkbox per row. Validation mirrors the batch wizard (0 ≤ marks ≤ max; out-of-range rows get `is-invalid`). Each subject row gets a pencil-ruler "Enter Marks" icon for re-entry at any time. Numeric-aware roll-number sort (`printf('%015d', CAST(roll AS INTEGER))`) matches the batch wizard pre-fill order. **Colour consistency sweep**: `:root` `--bs-primary` overridden to `--app-primary` (`#3a8eba`); `.btn-primary` / `.btn-outline-primary` / `.bg-primary` / `.border-primary` / `.text-primary` / `.link-primary` / `.auth-card-header.bg-primary` all now derive from the single source of truth. Verified: `getComputedStyle(.btn-primary).backgroundColor === getComputedStyle(#terminalreportAppbar).backgroundColor === 'rgb(58, 142, 186)'`. 22/22 unit tests pass + 13/13 browser tests pass. SW cache v12 | js/db.js, js/admin-ui.js, index.html, css/styles.css, sw.js, docs |
| Iter 13 | **Vendor CDN libraries locally (offline-first) + roadmap #8/#9/#10**: Bootstrap 5.3.8 + Font Awesome 7.3.1 + sql.js 1.14.2 vendored under `vendor/` (8 files, ~1.4MB total); SRI hashes + crossorigin dropped (same-origin = integrity); SW cache v13 precaches all vendor files; CDN_HOSTS + SWR branch removed from sw.js (no CDN to SWR anymore). **#8 inline admin validation**: `setInvalid()`/`clearValidation()` helpers; 9 alert() calls replaced with `.is-invalid` + `.invalid-feedback`; stale validation cleared on modal open. **#9 student photo upload in Step 3**: new "Photo (opt.)" column with 50×60 thumbnail per student; canvas-resizes to 100×120 PNG bytes on change; bytes flow `state.students[i].photoBytes` → `buildBatchReports()` → `db.saveBatch()` → `reports.photo_blob`; rendered on report card via `bytesToObjectUrl()`. **#10 per-subject rank badge**: `.subject-rank-badge` rendered next to Grade cell when `subjectRank` is finite + `totalStudents > 1`; `summary.totalStudents` added to batch.js saved summary; CSS mirrored into PRINT_STYLES for batch Print All. 18/18 unit tests pass + 8/8 browser tests pass. SW cache v13 | index.html, js/db.js, js/admin-ui.js, js/batch-ui.js, js/batch.js, js/script.js, css/styles.css, sw.js, +vendor/* (8 new files), docs |
| Iter 14 | **Batch wizard pre-fill from `subject_marks` (closes Admin UI ↔ wizard loop)**: New `listSubjectMarksForClass(classId)` DB method (single query joining `subject_marks` × `subjects` filtered by class_id, O(1) round-trip regardless of subject count). `loadManagedClass` fetches marks alongside students/subjects (in its own try/catch so a failure doesn't block the rest). `applyManagedPrefill` builds O(1) hash lookup tables (`{subjectId→subjIdx}`, `{studentId→studIdx}`) from `state.managedClass.subjects`/`students` IDs, then iterates marks and writes each into `state.marks[studIdx][subjIdx]`. Step 4 shows a `#bwMarksHint` "Pre-filled N marks from Admin UI" pill when `state.marksPreFilledCount > 0`. Teacher can override any cell, override is reflected in the saved report. **ALSO fixes pre-existing Iter 6 bug** where `renderStep4` wrote `<thead>` content into `<tbody id="bwMarksGrid">` (browser tolerated it but `#bwMarksHead` stayed empty). 8/8 unit tests pass + 11/11 browser tests pass. SW cache v14 | js/db.js, js/batch-ui.js, index.html, sw.js, docs |
| Iter 15 | **Appbar shows "TerminalReport" (app brand, not school name)**: The appbar is the APP's chrome, not the school's branding. Renamed `<span id="appbarSchoolName">School</span>` → `<span id="appbarBrandName">TerminalReport</span>` in index.html; removed 2 JS lines in `auth-ui.js` that overwrote the brand text with `info.name`; `populateAppbarLogo()` now ALWAYS renders `assets/app-logo.png` (TerminalReport brand logo) instead of conditionally using the school's uploaded logo. School name/logo preserved on report cards (via `generateReportHTML` → `data.academyName` / `data.schoolLogoBytes`) + lock screen (`populateLockScreenHeader`), where school branding belongs. Verified: setup with school name "Test Academy" → appbar shows "TerminalReport" + brand logo; report card still shows "Test Academy"; uploading a school logo via Settings saves it to DB (2,377 bytes confirmed) but appbar STILL shows TerminalReport brand. 8/8 browser tests pass. SW cache v15 | index.html, js/auth-ui.js, sw.js, docs |
| Iter 16 | **Single-report form REMOVED, batch generation is the default and only path**: Main dashboard redesigned as a clean 3-button action hub: Start New Batch (primary CTA, btn-primary btn-lg) / Saved Reports / Admin & Manage. ~420 lines of single-report-only code removed from script.js. New Saved Report Viewer modal (`#savedReportViewerModal`) for viewing+printing saved reports without the form, `viewSavedReport()` renders the report card via `TerminalReportScript_renderReportHTML`; `printSavedReport()` opens a new window with self-contained HTML+CSS and triggers `window.print()`. Each saved report row now has 3 buttons: View (eye) / Print (printer) / Delete (trash). Workflow verified: 8/8 core business-logic checks pass. 13/13 browser tests pass. SW cache v16 | index.html, js/script.js, sw.js, docs |
| Iter 17 | **Gap features + Back buttons + UI improvements**: Class-performance dashboard (pass-rate, avg, passed/failed per batch with colour-coded cards); CSV import for students (roll,name,dob,gender format, header row optional); bulk promote all students to a different-year class; student profile modal (longitudinal history, all past reports for a student, clickable from saved reports); batch wizard Cancel→Back (no confirm dialog); saved report viewer Close→Back; new modals have Back buttons; 3-column responsive icon-button dashboard grid with fa-2x icons; scrollable viewer modal; bulk promote gradient warning header. 10/10 browser tests pass. SW cache v17 | index.html, js/script.js, js/admin-ui.js, js/batch-ui.js, css/styles.css, sw.js, docs |
| Iter 18 | **Student name split into surname + first name**: `students` table gained `surname` / `first_name` columns (name kept for compat); student editor + CSV import adapted; DB-level `formatStudentName` + `toOrdinal` helpers added and exposed. *(Reconstructed in Iter 23 from code evidence, original session record lost.)* | js/db.js, js/admin-ui.js, index.html |
| Iter 19 | **class_position dropped + class rank badge**: idempotent students-table migration (add surname/first_name if missing, DROP COLUMN class_position); name-based sorting everywhere; `.class-rank-badge` on the report card ("2nd of 5"). *(Reconstructed in Iter 23 from code evidence.)* | js/db.js, js/batch-ui.js, css/styles.css, js/script.js |
| Iter 20 | **PBKDF2 PIN stretching + perf + renderer guards (SEC-01 / RT-03/04 / PERF-01/02 / RT-14)**: PIN hashing now PBKDF2-SHA-256 100k iterations with transparent legacy-SHA-256 upgrade on unlock; renderer null-guards for summary/subjects; single-query `getBatchSummaryStats()`; single `db.export()` per save shared with auto-backup; writable.close() try/finally. *(Reconstructed in Iter 23 from code evidence.)* | js/auth.js, js/db.js, js/script.js, js/backup.js |
| Iter 21 | **Critical-fix campaign part 1 (CRIT-03/09/10 in the first half, CRIT-11..15 in the second)**: recovery rate-limiting; parseFloat mark coercion; empty-marks-cell indicator; print-window CSS + `triggerPrintWhenReady()` (waits for CSS/images, closes via onafterprint); `AVG(CAST(percentage AS REAL))` batch stats; RFC-4180 CSV parser. 41/41 harness assertions (part 2). | js/auth.js, js/db.js, js/batch-ui.js, js/script.js, js/admin-ui.js, css/styles.css |
| Iter 22 | **Critical-fix campaign part 2 (CRIT-16..18)**: CSV header column-mapping via alias table (detectCsvHeader); orphan div removal in student modal; backup format v2: AES-GCM-encrypted payload + PBKDF2-derived key + HMAC, TR-BAK2 magic, v1 backward-compat restore. 53/53 harness assertions. | js/admin-ui.js, js/backup.js, index.html |
| Iter 23 | **Hardening (CRIT-19/20/21 + BLIND-7/8/9) + housekeeping**: students-tab empty-state colspan 7→6 (CRIT-19) + 5 more colspan 5→4 sites in the subject-marks modal (BLIND-7); changePin() legacy-hash fallback (CRIT-20) and recover() legacy security-answer fallback + transparent PBKDF2 upgrade via new `db.updateSecurityAnswer()` (BLIND-8), pre-Iter-20 users can now change PIN and use recovery; renderer corruption guards, no literal "undefined" from missing subject fields, null subject elements, null/empty/numeric-grade summaries; `getGradeClass` TypeError fixed (BLIND-9). SW cache v21→v23 (v22 never deployed); WORKLOG backfilled for Iters 18-20. Verified: 80/80 Node harness assertions (real modules + real Web Crypto) + live-DOM browser checks, zero console errors. | js/admin-ui.js, js/auth.js, js/db.js, js/script.js, index.html, sw.js, docs |
| Iter 24 | **Full 17-category error audit + 3 blind-spot fixes**: mechanical + manual audit across syntax/runtime/logic/type/reference/range/concurrency/resource-leak/security/calculation/interface/integration/performance/UI/workflow/DB/cross-file categories after the iter-21..23 modification waves. Fixes: BLIND-10 dead `#pdfTemplate` reference removed (batch toolbar no longer force-reset to 'primary', user template choice now survives re-renders); BLIND-11 tolerant `safeParseJson()` for report rows (corrupt subjects_json/summary_json from a tampered backup no longer bricks report detail/list views); BLIND-12 bounded object-URL lifecycle in auth-ui (lock-screen + settings logo previews no longer leak one blob URL per re-render). SW cache v23→v24. Verified: 39/39 iter-24 harness + 80/80 iter-23 harness + 17-category audit clean. | js/batch-ui.js, js/db.js, js/auth-ui.js, sw.js, docs |
| Iter 25 | **Responsive screen widths (user-reported layout fix) + SW stale-precache fix**: Every screen was a fixed-width centred column (`col-lg-8 mx-auto` dashboard, 1100px/480px/380px card caps) leaving large empty margins on desktop (XAMPP test). New media-query width ladder in styles.css over 3 CSS custom properties (`--app-card-narrow-max` / `--app-card-max` / `--app-card-wide-max`): base values = old fixed widths (mobile pixel-identical), ≥992px → 420/640/min(94vw,1500px), ≥1400px → 440/720/min(95vw,1840px). Dashboard wrapper → `col-12 .app-content-shell` (full width, 1800px cap ≥1400px). Lock screen kept login-pattern compact by design; print CSS untouched. PLUS: SW install precache now fetches with `Request({cache:'reload'})`, during verification the new SW precached the STALE stylesheet straight from the browser HTTP cache (servers without Cache-Control: python http.server, XAMPP Apache), reproduced and fixed. SW cache v24→v26. Verified: 8/8 checks at 1920/1280/390 viewports, zero console errors, node --check clean. | css/styles.css, index.html, sw.js, docs |
| Iter 26 | **Targeted re-audit of auth/backup/CSV/marks + lost-CRIT closure + Iter-24 backfill**: 7 of the 21 CRIT IDs (CRIT-01/02/04-08) had no surviving fix record (audit list lost before Iter 21). Full re-read of auth.js/backup.js/admin-ui.js CSV + marks/db.js persist paths + batch readStep4 + auth-ui flows: every documented CRIT/BLIND/SEC/RT/PERF fix verified present in code; no new exploitable bugs. Hardening: AUTH-01 `setup()` now refuses to run when already configured (a stray re-setup would rotate the app UUID → every existing `.trbak` becomes unrestorable, since the UUID is the backup HMAC key); AUTH-02 `refresh()` docstring corrected (it never reset the unlock flag, now documented as deliberate). BOM concern in CSV import disproven and pinned by an assertion (`file.text()` strips UTF-8 BOM per Encoding spec). CRIT-01/02/04-08 formally closed as unrecoverable (superseded by clean, regression-tested areas). WORKLOG Iter-24 entry backfilled from ROADMAP/README/code evidence. SW cache v26→v27. Verified: 66/66 new regression harness (real sql.js + real Web Crypto: RFC-4180 parser, header detection, backup v1/v2 roundtrip + tamper rejection, lockout escalation, legacy-hash fallbacks, CRIT-03 recovery rate-limit, marks UPSERT/coercion, moveStudent rules); node --check clean. | js/auth.js, sw.js, docs |
| Iter 27 | **UI bug audit: wizard stepper artifacts (user-reported) + same-class sweep**: stepper connector lines used hardcoded px offsets (auth 30px, batch 50px) that ignored real circle positions (flex:1 steps centre circles at 100/(2N)% of the row), leaving stray line stubs past the first/last nodes (~100px on the desktop batch wizard). Lines now anchor at those percentages (16.6667% / 10%), exact at any width; both ≤480px px overrides removed. Batch done-step checkmark was doubly broken: `content: '\\2713'` rendered literal "\2713" text AND inherited `font-size: 0` from the number-hiding rule → done steps showed empty green circles; now proper '\2713' at 1rem/600. Audit scope: all 5 pseudo-element rules in the stylesheet (all stepper-related), JS-generated print CSS (clean, fixed geometry, no escapes), z-index stack (overlays 1050 > appbar 1020, no reachable stacking bug), live browser sweep of setup/lock/dashboard/batch 1–5/saved reports/admin/settings at 1920+390 with zero console errors. SW cache v27→v28. | css/styles.css, sw.js, docs |
| Iter 28 | **UI bug audit #2: duplicate field + native dialogs → in-app modals (user-reported)**: Batch wizard Step 1 shipped TWO term pickers: "Which Term" (`#bwTerm` → `state.term` → legacy `batches.term` column, never read anywhere) duplicated "Academic Term" (`#bwAcademicTerm` → `state.academicTerm`, the DB lookup key + report label), with diverging defaults ('3rd' vs '1st'). Field + dead state removed; legacy NOT NULL column now populated from `academicTerm` in batch.js (no schema migration); HTML default aligned. PLUS: all **80 alert() + 10 confirm()** calls across batch-ui/admin-ui/script/auth-ui replaced by a shared in-app modal (new js/ui.js `window.TerminalReportUI` + #appDialog markup + styles): FIFO request queue, focus trap-in/restore, Enter/Escape/backdrop handling, 4 variants (info/success/warning/danger), textContent-rendered (XSS-safe) with pre-line for legacy multi-line messages; restore-success dialog now awaited before location.reload(); markup audit clean (0 duplicate ids, 0 orphan label[for], 0 dead $() refs, 0 prompt/inline-dialog calls). A freshState regression (className key dropped mid-edit → "undefined" in Class Name) was caught in browser verification and fixed; SW v29→v30 because cache-first serving needs a bump to deliver same-version patches. Verified: 66/66 harness, node --check clean, full wizard→generate→preview e2e (batch row: academicTerm=1st, legacy term=1st), confirm modal Cancel/Enter paths, FIFO queue, mobile 390px layout, zero console errors. | js/ui.js (NEW), index.html, css/styles.css, js/batch-ui.js, js/batch.js, js/admin-ui.js, js/script.js, js/auth-ui.js, sw.js, docs |
| Iter 29 | **Text pass: em dashes removed + British English copy (user-requested)**: every em dash in all 15 first-party files removed and each affected sentence rewritten to flow naturally; user-visible copy converted to British spelling (Template 1: Primary Colour, Template 2: Greyscale, centred, behaviour, normalised, initialise, Licence); report card, dashboard and settings placeholders now render n/a or Not set instead of a bare dash; backup reasons, dialog/window titles and empty-state option labels ("Enter manually", "Select year", "Use default") rewritten without decorative dashes; docs quotes kept in sync with the changed app strings; no logic changes. Verified: node --check clean on all 10 JS files, 66/66 regression harness, live browser pass (setup, dashboard, batch Step 1, renderer corruption guards) with zero console errors. SW cache v30→v31 | all first-party files |
| Iter 30 | **Form restructure + Subject Rank column (user-requested)**: gender pickers (Admin student modal + wizard Step 3) reduced to Male/Female; Total Days moved from the per-student Attendance table into Basic Info as a batch-wide field with days-present validation against it; Teacher Remark moved from the Attendance table into a dedicated column of the Step 4 marks grid; report card student info row now flows inline ("Student Name: Dadson Kweku") instead of stacking labels above values; new Subject Rank column renders each student's position in a subject as an ordinal ("1st") with a hover title, replacing the '#N' badge inside the Grade cell, footer colspans realigned, badge CSS removed everywhere. Data shape summary-compatible; old reports unaffected. Verified: node --check clean on all 10 JS files, 66/66 regression harness, new iter30 logic harness (ordinals, batch totalDays plumbing, ranks, ties, legacy tolerance), live browser pass (wizard steps 1/3/4/5, validation modal, end-to-end batch, detail card, admin modal) with zero console errors. SW cache v31→v32 | index.html, js/batch-ui.js, js/batch.js, js/script.js, css/styles.css, sw.js, docs |
| Iter 31 | **Business-logic audit (Vanilla JS checklist)**: every module re-read and audited across validation, branching, calculations, state/workflow, async, data consistency and error handling. Fixed: XFILE-01 restore-success dialog TypeError (UI.UI.alert) that faked 'Restore failed' and skipped the reload; SCALE-01 custom grading scales now honoured on the report card (per-subject grades prefer the stored grade and the legend renders from bands snapshotted into each summary at generation; legacy rows keep the default legend); VAL-01 days present rejects negative and non-integer values; RACE-01 Generate Reports is double-click safe with the button disabled for the whole flow; CONS-02 replaceDatabase runs the schema migration on restored older-schema backups; WF-01 dashboard summary re-renders once DB init resolves; FLT-01 ranking ties survive float artefacts via fixed-precision compare keys; TZ-01 saved-report timestamps render in local time; ASYNC-01 sequence tokens stop stale list renders overwriting newer ones; ERR-01 class-creation dropdowns surface failures instead of unhandled rejections. Noted by design: certificate numbers may repeat across batches sharing a prefix. Verified: node --check clean (10 files), 66/66 + iter30 + new 37/37 audit harnesses, live browser pass (setup, custom 3-band scale e2e batch, validation dialogs, restore success dialog, zero console errors). SW cache v32→v33 | js/auth-ui.js, js/batch.js, js/batch-ui.js, js/script.js, js/db.js, js/admin-ui.js, sw.js, docs |
| Iter 32 | **UI rendering/interaction audit (user-supplied checklist + 31 bug patterns)**: RACE-02 student profile modal ignores stale responses and surfaces DB failures; BUSY-01..04 busy guards on all admin add/save/confirm buttons, CSV import, Settings restore and saved-report print/delete so double-clicks cannot duplicate writes or open duplicate print windows; KEY-01 app dialog traps Tab and owns Enter/Escape even over other modals, and the three read-only modals (saved viewer, student profile, batch detail) gained Escape-to-close, focus move/restore and scroll reset via the new ui.js wireModal helper (form overlays deliberately not Escape-wired to protect typed data); SCROLL-01 every tall overlay resets its scroll on open; LEAK-01 report-card blob URLs revoked on modal close and after print (export + five call sites); SEL-01 managed-class picker ignores superseded selections; VAL-02 wizard grids clear invalid marks while typing; ERR-02 renderDetailsTab reports failures; ERR-03 preview failure after a successful save no longer fakes "Generation failed". Verified: node --check clean (10 files), 66/66 + iter30 + 37/37 + new 47/47 harnesses, live browser pass (setup, dialog Tab/Escape/Enter, e2e batch, invalid-clears-on-type, detail/viewer/profile focus+Escape+restore, admin double-click save produces one row, zero console errors). SW cache v33→v34 | js/ui.js, js/script.js, js/batch-ui.js, js/admin-ui.js, js/auth-ui.js, sw.js, docs |

## Features

### Core (Iter 1 + Iter 16 simplification)
- Report card HTML renderer (`generateReportHTML`), shared by batch-ui.js + saved report viewer
- TZ-safe date formatting
- HTML escaping (XSS protection)
- Memory-safe blob URL lifecycle
- **Iter 16: single-report form REMOVED**: batch generation is the default and only path

### PWA (Iter 1, icons Iter 9)
- Manifest + service worker
- Cache-first for app shell
- Stale-while-revalidate for CDN assets
- 6 PWA icons (any + maskable + apple-touch): the real TerminalReport logo, with the maskable safe zone verified
- Works offline after first load
- Brand logo fallback (`assets/app-logo.png`) in appbar/lock screen when no school logo is on file

### Validation (Iter 2)
- Live per-field validation (red border + error message)
- Cross-field rules (pass ≤ max, obtained ≤ max)
- Submit blocked on invalid rows
- Empty rows silently skipped (matches data collection behaviour)

### Persistence (Iter 3 + Iter 11 search)
- sql.js 1.14.2 (SQLite compiled to WASM) loaded from CDN with SRI
- IndexedDB-backed persistence (DB bytes saved after every write)
- "Saved Reports" panel: list, load, delete, with Iter 11 **search-by-name + filter-by-class** toolbar (debounced search input, class-filter dropdown from saved reports, result-count badge, clear-search button)
- Logo/photo stored as BLOBs (Uint8Array)
- Filtering done in SQL via `INSTR(LOWER(student_name), ?) > 0` (avoids LIKE wildcard injection, because searching "100%" matches only rows whose name contains the literal substring "100%", not every row)

### PDF Templates (Iter 4 Phase A; batch support Iter 10)
- 3 templates selectable from form + preview toolbar (synced):
  - **Template 1: Primary Colour**: default with #3a8eba blue gradient header
  - **Template 2: Greyscale**: full CSS greyscale filter, grey header
  - **Template 3: No Logo**: logo circle hidden, colours kept
- Switching templates re-renders the card live (no regeneration needed)
- **Batch printing uses the same 3 templates (Iter 10)**: the batch preview toolbar has its own template dropdown; Print All, print-one, and the report detail modal all honor it
- Auto-generated certificate number `TR-YYYYMMDD-XXXX` if user leaves blank

### Auth (Iter 4 Phase B)
- 3-step first-time setup wizard: School Info → PIN → Security Question
- Lock screen with numeric PIN pad (clickable + keyboard support)
- 5-attempt lockout with exponential backoff:
  - 1st lockout: 5 min (per spec)
  - 2nd lockout: 15 min
  - 3rd lockout: 1 hour
  - 4th lockout: 4 hours
  - 5th+ lockout: 24 hours
- Recovery flow: answer security question → set new PIN
- Logo auto-resized to 256×256 PNG on upload (canvas)
- Lockout state persisted in localStorage (survives reload)
- isUnlocked state in-memory only (forces re-auth on every app open)
- Top appbar showing school name + logo + lock button + settings gear

### Backup & Restore (Iter 5 Phase C)
- **Backup file format**: signed binary `.trbak` with magic bytes `TR-BAK1`, version, app UUID, HMAC-SHA256, payload length, SQLite payload
- **HMAC-SHA256 signing**: uses app UUID (Phase B) as HMAC key. Backup from a different installation (different UUID) is REJECTED with "Backup was created by a different installation. Cannot restore (UUID mismatch)."
- **Tamper detection**: flipping a single byte in the backup payload is detected and rejected with "Backup signature mismatch; the file may have been tampered with."
- **Auto-backup on DB change** (better than spec): whenever the DB is saved, if auto-backup is enabled, a signed copy is written to OPFS (Origin Private File System). This is more reliable than waiting for app close, because `beforeunload` can't reliably run async work in modern browsers.
- **beforeunload safety net**: also fires auto-backup on tab close (best-effort; may not complete before the page unloads, which is why the on-save hook is the primary mechanism).
- **Manual "Backup Now"**: uses File System Access API (`showSaveFilePicker`) if available (Chrome/Edge/Safari 16.4+), falls back to `<a download>` for Firefox.
- **Manual "Restore from Backup"**: uses `showOpenFilePicker` if available, falls back to `<input type="file">`. Verifies HMAC signature before replacing the in-memory DB.
- **Settings overlay**: school name/logo editing, auto-backup toggle, Backup Now, Restore from Backup, Change Passcode form.
- **Change PIN**: requires current PIN; rejects if PINs don't match or new = old.

### Batch Generation (Iter 6 Phase D + Iter 9 pre-fill + Iter 13 photo upload + Iter 14 marks pre-fill)
- **5-step wizard** (full-screen overlay):
  1. **Basic Info**: managed-class pre-fill dropdown (Iter 9), academic year, class name, term (1st/2nd/3rd), student count, subject count, certificate prefix, issue date
  2. **Define Subjects**: editable table with code/name/max/pass marks per subject, pre-filled from the managed class's `subjects` table when one is selected
  3. **Enter Students**: editable table with roll#/name/DOB/gender/**photo upload (Iter 13)** per student, pre-filled from the managed class's `students` table (numeric roll-number order)
  4. **Marks grid**: spreadsheet-style table with students down the left (sticky frozen columns) and subjects across the top. Live validation (red border + message) on out-of-range marks. **Iter 14**: marks are now pre-filled from the managed class's `subject_marks` (saved via the Admin UI's "Enter Marks" modal in Iter 12); a hint shows "Pre-filled N marks from Admin UI" when applicable; any cell can be overridden.
  5. **Attendance & Remarks**: per-student days present, total days, teacher remark. Validates days present ≤ total days.
- **Managed-class pre-fill (Iter 9)**: selecting a Phase E class auto-fills the year, class name, and counts; Steps 2/3 are pre-filled once per selection (going Back and re-Next preserves manual edits); switching rosters with data present asks for confirmation; deselecting keeps what's filled but drops the linkage; manual entry remains the default.
- **Marks pre-fill from `subject_marks` (Iter 14)**: when a managed class is loaded, all its saved subject_marks rows are fetched in a single query (`listSubjectMarksForClass`) and pre-filled into Step 4's marks grid. The teacher can override any cell, and the override is reflected in the saved report. A hint at the top of the marks grid shows the pre-fill count.
- **Class grading scale honored (Iter 9)**: the wizard resolves the managed class's grading scale (custom or seeded default) and passes it to generation; a class assigned "A 75 / B 50 / F 0" grades 78.5% as A, not B+.
- **Stepper UI**: 5 circles connected by a progress line; current step is highlighted, completed steps turn green with a checkmark.
- **"Reports already exist" detection**: before generating, queries DB for existing batch with same (academic_year, class_name, academic_term). If found, it shows a confirm dialog asking whether to regenerate and replace the existing reports. On Yes, deletes the old batch (cascade delete reports) and saves the new one.
- **Transactional save**: `BEGIN TRANSACTION` / `COMMIT` / `ROLLBACK` semantics. If any INSERT fails, ROLLBACK undoes everything, so there are no half-saved batches.
- **Class ranking** (standard competition ranking with ties): students with the same total marks share the same rank (1, 2, 2, 4 rather than 1, 2, 2, 3).
- **Per-subject ranking**: each student is also ranked within each subject (with ties). Displayed as a `.subject-rank-badge` next to the grade on the report card (Iter 13).
- **Pass/fail logic** (matches spec): pass ONLY if obtained ≥ pass marks in EVERY subject. A student with 90% overall but 30/100 in one subject (where pass = 35) correctly shows FAIL.
- **Auto-generated certificate numbers**: format `PREFIX-NNNN` (e.g., `EA-2425-0001`, `EA-2425-0002`). If prefix blank, uses `TR-YYYYMMDD`.
- **Batch preview overlay**: lists all generated reports with rank badge (#1, #2, ...), student name, grade, percentage, PASS/FAIL, certificate number. Each row has "View" (eye icon → opens detail modal with full report card HTML) and "Print" (printer icon → opens a new window with just that student's report and triggers print).
- **PDF Template dropdown (Iter 10, roadmap #4)**: in the batch preview toolbar next to Print All, with the same three templates as the single-report flow, defaulting to the main form's selection. Applies to Print All AND print-one; the detail modal renders with the selected template and live-re-templates when the selector changes, so the preview always matches the printed output.
- **Print All**: opens a new window with all reports stacked (each rendered with the selected template), separated by `page-break-after: always`, triggers `window.print()` for multi-page output. Window title is "TerminalReport: Batch Print" (browsers use it as the default PDF filename).
- **Marks grid sticky columns**: first column (student #) and second column (student name) are `position: sticky` so they stay visible while horizontally scrolling through many subjects. Header row is also sticky during vertical scroll.

### Admin & Management (Iter 7 Phase E + Iter 12 subject marks)
- **Admin overlay** with 3 sections:
  1. **Academic Years**: list with class count, add (Enter key support), delete (blocked if classes exist for that year, with the count shown)
  2. **Grading Scales**: list with band preview + class count, create/edit via band editor modal, delete (blocked for default scale; deleting a scale in use resets those classes to default)
  3. **Classes**: list with year/scale/student/subject counts, add (with year + scale dropdowns), delete (blocked if students or subjects exist), "Manage" button
- **Default grading scale seeded**: on first DB init, the existing A+/A/B+/B/C/D/F 7-band scale is inserted as "Default 7-Band" (marked `is_default = 1`). Cannot be deleted.
- **Grading scale editor modal**: name + dynamic band table (add/remove bands). Each band has grade letter, min percentage, description. Validates: grade letter required, min % 0–100.
- **Manage Class screen** with 3 tabs:
  - **Details**: edit class name, change academic year, assign grading scale (or use default)
  - **Students**: list (roll#, name, DOB, gender), add/edit/delete via modal, promote/repeat via move modal
  - **Subjects**: list (code, name, max, pass), add/edit/delete via modal, **+ "Enter Marks" action (Iter 12)**
- **Subject marks entry (Iter 12, roadmap #2)**: when a teacher adds a NEW subject to a class that has ≥1 student, an "Enter Marks" modal auto-opens listing every student in the class with a numeric input + absent checkbox per row. Marks are bulk-UPSERTed (`INSERT OR REPLACE` on the `UNIQUE(subject_id, student_id)` constraint) inside a transaction. Each subject row also has a pencil-ruler icon for re-entry at any time. Cascade-delete on subject/student removal. Numeric-aware roll-number sort matches the batch wizard pre-fill order.
- **Promote/repeat student**: opens a modal listing eligible target classes (must be in a DIFFERENT academic year). Prevents moving to a different class in the same year (spec requirement).
- **Grading scale integration**: `batch.js`'s `getGrade()` and `computeSummary()` now accept an optional custom scale parameter. When a class has a grading scale assigned, that scale is used for grade calculation; otherwise the default 7-band scale is used.
- **7 normalised tables** (added Iter 12: 8th): `academic_years`, `grading_scales`, `grading_bands`, `classes`, `students`, `subjects`, `subject_marks`, with proper FK constraints (`ON DELETE RESTRICT` for children, `ON DELETE CASCADE` for bands and subject_marks, `ON DELETE SET NULL` for optional FKs).
- **last_insert_rowid fix**: all `add*` functions now call `SELECT last_insert_rowid()` BEFORE `await persist()`, because `persist()` calls `db.export()` which can reset the SQL connection's last-insert state.

### Security Design (Iter 4 + 5 combined)
- PIN stored as `SHA-256(salt + pin)`, 16-byte crypto-random salt, base64-encoded
- Security answer stored as `SHA-256(separate_salt + answer_lowercase)`, separate salt so compromising one doesn't reveal the other
- App UUID (crypto-random, RFC 4122 v4) generated at first setup, stored in DB, used as HMAC key for backup signing (Phase C)
- All crypto via `crypto.subtle`, never `Math.random` for security
- No plaintext PIN or answer ever persisted

## Stack

| Component | Version | Source |
|---|---|---|
| Bootstrap | 5.3.8 | vendored under `vendor/bootstrap/` (Iter 13: previously cdnjs)
| Font Awesome | 7.3.1 | vendored under `vendor/font-awesome/` (Iter 13: previously cdnjs)
| sql.js | 1.14.2 | vendored under `vendor/sql.js/` (Iter 13: previously cdnjs)
| Vanilla JS | ES2017+ | no transpilation |
| PWA | manifest + service worker | W3C standard |
| Crypto | Web Crypto API (`crypto.subtle`) | W3C standard |
| Storage | IndexedDB (for SQLite bytes) + localStorage (for lockout state) | W3C standard |

**Iter 13 note on vendoring:** previously Bootstrap, Font Awesome, and sql.js were loaded from cdnjs with SRI hashes. The service worker cached their responses, but the SWR (stale-while-revalidate) path still round-tripped to cdnjs.com in the background, making "offline-first" conditional on having reached cdnjs at least once. Iter 13 vendors all 8 files (CSS, JS, 3 woff2 fonts, sql.js loader + .wasm binary) under `vendor/`. SRI hashes are dropped (same-origin = integrity). All assets are precached on SW install, making the app truly offline-first from the first load.

## Not Yet Implemented (Roadmap)

See `ROADMAP.md` for the remaining roadmap with priorities. Summary:

| Feature | Status |
|---|---|
| ~~Search saved reports by student name + filter by class~~ | ✅ Done (Iter 11) |
| ~~"When adding a new subject, immediately enter marks for all existing students"~~ | ✅ Done (Iter 12) |
| ~~Batch wizard pulls subjects/students from managed entities (Phase E)~~ | ✅ Done (Iter 9) |
| ~~3 multi-template PDFs in batch print~~ | ✅ Done (Iter 10) |
| ~~Add input validation UI to admin entity modals~~ | ✅ Done (Iter 13) |
| ~~Student photo upload in batch wizard Step 3~~ | ✅ Done (Iter 13) |
| ~~Per-subject rank display on report card~~ | ✅ Done (Iter 13) |
| ~~Batch wizard pre-fill from `subject_marks` table~~ | ✅ Done (Iter 14) |
| Capacitor wrapper for native iOS submission | Future (Apple still rejects pure PWAs; blocked by native toolchain availability) |

## Constraints & Honest Trade-offs

1. **sql.js loads entire DB into memory.** For a single school with hundreds of reports, this is well under 50MB. To scale to multi-school SaaS, migrate to `@sqlite.org/sqlite-wasm` with OPFS-backed persistence.
2. **4-digit PIN is brute-forceable in ~5 min** without lockout. The 5-attempt lockout with exponential backoff is essential, not optional.
3. **`crypto.subtle` requires HTTPS or localhost.** `file://` will silently fail. Always serve via HTTP.
4. **No transaction wrapping for single-report saves.** sql.js operates on a single in-memory DB; the atomic transaction promise applies once we have multi-table inserts (batch workflow).
5. **PWA icons are the real TerminalReport logo (Iter 9).** If the branding changes, re-run `/home/z/my-project/scripts/generate_app_icons_iter9.py` with a new 1024×1024 PNG.
6. **Apple iOS App Store** still rejects pure PWAs. PWABuilder's iOS path wraps in a Capacitor-style WebView; expect potential review rejection. Plan separate native iOS work if you want to ship there.
7. **Auto-backup fires on every DB save, not just on app close.** This is INTENTIONAL and BETTER than the spec, because `beforeunload` handlers can't reliably run async work in modern browsers (Chrome kills them). Saving on every write means the OPFS auto-backup is always fresh.
8. **File System Access API not supported in Firefox.** Firefox users fall back to `<a download>` for "Backup Now" (saves to Downloads folder, no path picker) and `<input type="file">` for restore. Chrome/Edge/Safari 16.4+ get the full file picker experience.
9. **Backups are tied to the installation UUID.** If you delete the IndexedDB and OPFS (clear site data), the app generates a NEW UUID on next setup, and all old `.trbak` files become unrestorable. Treat the IndexedDB as the source of truth; treat `.trbak` files as a recovery mechanism for accidental data loss, NOT for cross-machine migration.

## Verification

```bash
# Serve and open in browser
cd TerminalReport
python3 -m http.server 8080

# Syntax-check all JS
for f in js/*.js sw.js; do node -c "$f" && echo "OK: $f"; done

# Iter 11 unit tests (SQL only, no browser required)
node /home/z/my-project/scripts/test_iter11_search.js
# Expected: 17 passed, 0 failed

# Iter 11 end-to-end browser test (requires python3 -m http.server on :8080)
bash /home/z/my-project/scripts/validate_iter11.sh
# Expected: 13/13 PASS

# Iter 12 unit tests (SQL only, no browser required)
node /home/z/my-project/scripts/test_iter12_subject_marks.js
# Expected: 22 passed, 0 failed

# Iter 12 end-to-end browser test (requires python3 -m http.server on :8080)
bash /home/z/my-project/scripts/validate_iter12.sh
# Expected: 13/13 PASS

# Iter 13 unit tests (batch.js subjectRank + totalStudents + photoBlob)
node /home/z/my-project/scripts/test_iter13_batch_rank.js
# Expected: 18 passed, 0 failed

# Iter 13 end-to-end browser test (vendoring + #8 + #9 + #10)
bash /home/z/my-project/scripts/validate_iter13.sh
# Expected: 8/8 PASS

# Iter 14 unit tests (listSubjectMarksForClass: one query for all marks in a class)
node /home/z/my-project/scripts/test_iter14_subject_marks_for_class.js
# Expected: 8 passed, 0 failed

# Iter 14 end-to-end browser test (marks pre-fill flow)
bash /home/z/my-project/scripts/validate_iter14.sh
# Expected: 11/11 PASS

# Iter 15 end-to-end browser test (appbar brand text = "TerminalReport")
bash /home/z/my-project/scripts/validate_iter15.sh
# Expected: 8/8 PASS

# Iter 16 end-to-end browser test (single-report removed, batch is default)
bash /home/z/my-project/scripts/validate_iter16.sh
# Expected: 13/13 PASS

# In Chrome/Edge DevTools:
# - Application tab → Manifest: should show name "TerminalReport", icons, theme colour
# - Application tab → Service Workers: should show "terminalreport-v24" registered
# - Application tab → Cache Storage → terminalreport-v24: should include ALL vendor/* files (offline-first)
# - Application tab → IndexedDB → terminalreport-db → kv: SQLite bytes after first save
# - Application tab → Local Storage: terminalreport-auth-lock (lockout state after wrong PINs)
# - Application tab → Storage → Origin private file system → terminalreport-backups/auto.trbak (after enabling auto-backup + a save)
# - Network tab: zero requests to cdnjs.cloudflare.com (all assets same-origin since Iter 13)
```

## Licence

This is a school boilerplate. Adapt and use as needed.
