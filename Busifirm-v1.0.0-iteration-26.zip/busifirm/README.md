# Busifirm

Ghana Tech M&A Platform — frontend SPA + PHP 8.3 / MySQL 8.4 backend.

**Current state (this iteration, v0.9.2-iteration-20):** All Must-have items (M1–M10) plus Phase 3 polish for M4 / M5 / M6 are implemented. v0.9.2 fixes 10 app workflow bugs (WF-01, 02, 04, 07, 08, 12, 13, 14, 22, 27). v0.9.1 fixed 9 performance bugs. v0.9.0 fixed all security bugs. v0.8.x fixed all BL/UX/UI/OTH bugs. New in v0.8.0:
- **M4 polish:** proration (immediate prorated charge on upgrade; scheduled downgrade), 14-day no-card trials, plan-limit enforcement (`max_listings`, `max_chat_per_day`) returning HTTP 402 on quota exceeded.
- **M5 polish:** pluggable storage backend (`StorageInterface` + `LocalStorage` + `S3Storage` + `StorageFactory`), `finfo_file()` content-based MIME validation (defense vs spoofed uploads), ClamAV virus scanning via clamd INSTREAM, chunked upload protocol (3 endpoints + frontend `uploadAuto` helper), disk GC cron (`bin/gc-documents.php`) for hard-deleting soft-deleted files past retention.
- **M6 polish:** GDPR user-delete (soft-delete + anonymized audit_log + hard-delete GC cron), session invalidation via `role_version` pattern (closes the v0.7.0 stale-role risk), admin role-change UI (admin can change a user's role via the panel — promotion TO admin stays SQL-only by design).

Phase 3 remaining: M9 GDPR export endpoint (delete is done), M10 backup automation, recurring-billing cron (trial expiration + downgrade application are done — recurring charge cron is Paystack-side). See `PROJECT_ROADMAP.md`.

## Stack

| Layer | Tech |
|-------|------|
| Frontend | Vanilla JS SPA, Bootstrap 5.3.3, Font Awesome 6.5.1 |
| Backend | PHP 8.3, framework-less (no Laravel, no Symfony) |
| Database | MySQL 8.4 (utf8mb4, InnoDB) |
| Password hashing | `PASSWORD_BCRYPT`, cost 12 (OWASP 2026 minimum). **Argon2id intentionally not used, per project requirement.** |
| Sessions | PHP native sessions, `Secure` + `HttpOnly` + `SameSite=Lax` cookies. Role-version checked on every authenticated request (M6 polish). |
| CSRF | Per-session 32-byte token, sent as `X-CSRF-Token` header on every mutating request |
| Rate limiting | File-based per-IP sliding window (Phase 3 swaps for Redis) |
| Mail | PHP `mail()` for dev (Phase 3 swaps for SMTP via Sendgrid/Postmark) |
| Document storage | Pluggable: `local` (default) or `s3` (M5 polish). S3 backend supports AWS S3, MinIO, DigitalOcean Spaces, Cloudflare R2, Backblaze B2. |
| Virus scanning | ClamAV via clamd INSTREAM socket (M5 polish). Disabled by default; enable via `CLAMAV_ENABLED=true`. |
| Billing | Paystack REST API (direct cURL, no SDK). Proration + trials + plan-enforcement (M4 polish). |

## Project layout

```
busifirm/
├── app/
│   ├── Core/           Config, Database, Csrf, Validator, Mailer, Role,
│   │                   PaystackClient, StorageInterface, LocalStorage,
│   │                   S3Storage, StorageFactory, ClamAV
│   ├── Services/       UserService, ListingService, IPService, DealService,
│   │                   ChatService, ESignService, IntegrationService,
│   │                   KycService, BillingService, DocumentService,
│   │                   AdminService, PlanEnforcementService
│   ├── Controllers/    AuthController, ListingController, IPController,
│   │                   DealController, ChatController, ESignController,
│   │                   IntegrationController, KycController, AuditController,
│   │                   BillingController, DocumentController, AdminController
│   └── Middleware/     AuthMiddleware (with role_version check), AdminMiddleware, RateLimitMiddleware
├── database/
│   └── migrations/     20260904_001 through 20260911_007 (7 migrations)
├── public/             Front controller + static assets
│   ├── index.php
│   ├── index.html
│   ├── css/style.css
│   └── js/{app.js,api.js}
├── config/routes.php   (documentation; routing inline in index.php)
├── bin/
│   ├── migrate.php              Migration runner
│   ├── billing-cron.php         M4 polish: expire trials + apply pending downgrades
│   ├── gc-documents.php         M5 polish: hard-delete soft-deleted documents past retention
│   └── purge-deleted-users.php  M6 polish: hard-delete soft-deleted users past retention
├── tests/              PHPUnit (smoke tests)
├── .env.example        Copy to .env and fill in
├── composer.json
├── phpunit.xml
├── PROJECT_ROADMAP.md
└── worklog.md
```

## Setup (dev)

```bash
# 1. Prerequisites
php -v          # must be >= 8.3
mysql --version # must be 8.0+ (8.4 recommended)
composer --version

# 2. Clone + install
git clone <repo> busifirm && cd busifirm
composer install           # dev deps only (PHPUnit)

# 3. Configure env
cp .env.example .env
# edit .env: set DB_HOST, DB_USER, DB_PASSWORD, DB_NAME, APP_URL

# 4. Create the database + user (one-time)
mysql -u root -p <<'SQL'
CREATE DATABASE busifirm CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
CREATE USER 'busifirm'@'localhost' IDENTIFIED BY 'change-me';
GRANT ALL PRIVILEGES ON busifirm.* TO 'busifirm'@'localhost';
FLUSH PRIVILEGES;
SQL

# 5. Run migrations
php bin/migrate.php

# 6. Start the dev server
composer serve
#   → http://localhost:8000
```

## Dev convenience: token echo

In development (`APP_ENV=development` and `MAIL_ECHO_TOKENS_IN_DEV=true`), the API responses for register / login / forgot-password include a `_dev_verify_token` or `_dev_reset_token` field. This lets you click the verification/reset link without a working mail server. **Never set `MAIL_ECHO_TOKENS_IN_DEV=true` in production.**

The verification link format is: `http://localhost:8000/#verify-email?token=<64-hex>`
The reset link format is: `http://localhost:8000/#reset-password?token=<64-hex>`

## API endpoints (M1 through M6 polish)

### Auth (M1)

| Method | Path | Auth | Rate-limited | Purpose |
|--------|------|------|--------------|---------|
| POST | `/api/auth/register` | no (CSRF-exempt) | yes (10/min/IP) | Create account + send verification email |
| GET | `/api/auth/verify?token=…` | no | no | Consume email-verification token |
| POST | `/api/auth/login` | no (CSRF-exempt) | yes (10/min/IP) | Authenticate, start session, issue CSRF |
| POST | `/api/auth/logout` | yes (CSRF) | no | Destroy session |
| GET | `/api/auth/me` | yes | no | Fetch current user (or 401) |
| GET | `/api/auth/csrf` | no | no | Issue a CSRF token for an anonymous client |
| POST | `/api/auth/forgot` | no (CSRF-exempt) | yes (10/min/IP) | Send password-reset email (always-success) |
| POST | `/api/auth/reset` | no (CSRF-exempt) | yes (10/min/IP) | Consume reset token + set new password |

### Domain (M2 — all require auth + CSRF on mutations; M3 RBAC noted per row)

| Method | Path | Purpose | M3 RBAC |
|--------|------|---------|---------|
| GET | `/api/listings` | List user's + system listings | any role |
| POST | `/api/listings` | Create or update listing | **seller or broker only** |
| GET | `/api/listings/{id}` | Fetch one listing | any role |
| POST | `/api/listings/{id}/delete` | Delete listing | **seller or broker only** (owner) |
| GET | `/api/listings/duplicate?companyName=…` | Check duplicate company name | any role |
| GET | `/api/ips` / `/api/ips/all` / `/api/ips/search` | Browse IP catalog | any role |
| GET | `/api/ips/{id}` | Fetch one IP | any role |
| GET | `/api/deals` | List user's deals | any role |
| POST | `/api/deals` | Create deal | any role |
| POST | `/api/deals/{id}` | Update deal fields | any role (owner) |
| POST | `/api/deals/{id}/delete` | Delete deal | any role (owner) |
| GET | `/api/chat` | List user's conversations | any role |
| POST | `/api/chat` | Create new conversation | any role |
| GET | `/api/chat/{id}` | Fetch one conversation with messages | any role (owner) |
| POST | `/api/chat/{id}/message` | Send a message | any role (owner) |
| POST | `/api/chat/{id}/read` | Mark conversation as read | any role (owner) |
| GET | `/api/esigns` | List user's e-sign documents | any role |
| GET | `/api/esigns/awaiting-witness` | List docs awaiting witness signature | any role (UI shows only to lawyers) |
| POST | `/api/esigns` | Create or update e-sign document | any role (owner) |
| POST | `/api/esigns/{id}/witness-sign` | Co-sign document as witness | **lawyer only** |
| GET | `/api/integrations` | Get user's integration task list | any role |
| POST | `/api/integrations/tasks` | Create integration task | any role |
| POST | `/api/integrations/tasks/{id}` | Update integration task | any role |
| GET | `/api/kyc` | Get user's KYC status | any role |
| POST | `/api/kyc` | Update KYC status (M5 will replace with file upload) | any role (self only) |
| GET | `/api/audit?limit=200` | List user's audit events | any role (self only) |
| POST | `/api/audit` | Write an audit event from the client | any role |
| GET | `/api/billing/plans` | List all active plans | any role |
| GET | `/api/billing/me` | Get current subscription + plan | any role |
| POST | `/api/billing/checkout` | Start Paystack checkout for a plan | any role |
| GET | `/api/billing/return?reference=…` | Paystack redirect-back (verifies payment) | any role |
| POST | `/api/billing/cancel` | Cancel active subscription | any role (subscription owner) |
| POST | `/api/billing/trial` | Start a 14-day no-card trial (M4 polish) | any role |
| POST | `/api/billing/change-plan` | Upgrade (prorated) or schedule downgrade (M4 polish) | any role |
| GET | `/api/billing/proration?planCode=…` | Preview proration charge without committing (M4 polish) | any role |
| POST | `/api/billing/webhook` | Paystack webhook | **none** (signature-verified, not session-auth) |
| POST | `/api/documents` | Upload file (multipart/form-data) | any role |
| GET | `/api/documents` | List user's documents (?purpose=kyc) | any role |
| GET | `/api/documents/{id}` | Download file (streams with proper headers) | any role (owner) |
| POST | `/api/documents/{id}/delete` | Soft-delete file | any role (owner) |
| POST | `/api/documents/chunk` | Start chunked upload session (M5 polish) | any role |
| POST | `/api/documents/chunk/{id}` | Upload one chunk (multipart: file + index) | any role (owner) |
| POST | `/api/documents/chunk/{id}/complete` | Finalize chunked upload (assemble + scan + persist) | any role (owner) |
| POST | `/api/documents/chunk/{id}/abort` | Abort chunked upload + cleanup | any role (owner) |
| GET | `/api/admin/stats` | Aggregate counts (users, KYC, revenue) | **admin only** |
| GET | `/api/admin/users` | List all users with KYC + plan | **admin only** |
| POST | `/api/admin/users/{id}/verify-kyc` | Verify a user's KYC | **admin only** |
| POST | `/api/admin/users/{id}/reject-kyc` | Reject a user's KYC | **admin only** |
| GET | `/api/admin/plans` | List plans with paystack_plan_code | **admin only** |
| POST | `/api/admin/plans/{code}/set-code` | Set paystack_plan_code | **admin only** |
| POST | `/api/admin/plans/{code}/clear-code` | Clear paystack_plan_code | **admin only** |
| POST | `/api/admin/users/{id}/role` | Change user role (invalidates session) (M6 polish) | **admin only** |
| POST | `/api/admin/users/{id}/delete` | GDPR soft-delete user (M6 polish + M9 precursor) | **admin only** |
| POST | `/api/admin/users/{id}/cancel-deletion` | Restore a soft-deleted user (M6 polish) | **admin only** |
| GET | `/api/admin/audit` | List all audit events (with filters) | **admin only** |
| GET | `/api/health` | Liveness probe | none |

## Admin panel (M6 + M6 polish)

The admin panel is a read-mostly UI for moderators. It closes the dev-shortcut loops from earlier iterations:

- **KYC verification** — the 3-second auto-verify has been REMOVED. Users submit → status flips to `pending` → admin reviews → admin clicks verify/reject.
- **Paystack plan codes** — admins can now set `paystack_plan_code` on each plan via the UI, enabling recurring billing.
- **Audit log** — read-only viewer across ALL users (not scoped). Filterable by action + user ID.
- **M6 polish: Role change** — admins can change a user's role (seller/buyer/lawyer/broker) via the UI. The user's active session is invalidated on their next request via the `role_version` pattern. Promotion TO admin stays SQL-only by design.
- **M6 polish: GDPR user-delete** — admins can soft-delete a user. The user cannot log in immediately. Their subscription is cancelled, audit_log entries are anonymized (user_id set to NULL), and the user row + all dependent data are hard-deleted after a 30-day window by `bin/purge-deleted-users.php`. Cancel-deletion within the 30-day window restores access (subscription must be re-subscribed manually).

**Admin role assignment:** There is NO admin-promotion endpoint. To make a user an admin, run SQL directly:

```sql
UPDATE users SET role = 'admin' WHERE email = 'admin@busifirm.com';
```

This is intentional — admin promotion is a rare, high-trust operation that should require DB access, not a button in the UI. The user's existing session is invalidated on their next request (M6 polish: role_version pattern), so they'll be forced to log in again with the new role.

**Defense in depth:**
1. Front controller calls `AdminMiddleware::requireAdmin()` before dispatching to `AdminController`.
2. `AdminController` re-checks `requireAdmin()` at the top of every method.
3. `AdminService` methods assume admin context (no per-method check) — accepted because the controller is the only caller.
4. M6 polish: `AuthMiddleware::requireUser()` verifies `role_version` on every authenticated request — session regeneration happens automatically if an admin changed the user's role.

**Admin capabilities:**
- View all users + their KYC status + plan
- Verify / reject any user's KYC
- Set / clear `paystack_plan_code` on any plan
- M6 polish: Change user role (invalidates session)
- M6 polish: GDPR soft-delete user + restore within 30-day window
- View aggregate stats (total users, KYC verified/pending, active subscriptions, revenue)
- View full audit log with filters

**Admin cannot:**
- Create listings (admin role lacks `canCreateListings()` — separation of duties)
- Sign as witness (admin role lacks `canSignAsWitness()`)
- Promote other users to admin (SQL-only by design — Phase 4+ may add a super-admin role)
- Delete another admin (defense in depth — demote them first via SQL)
- Delete their own account (defense in depth)

## Document storage (M5 + M5 polish)

Files are stored via a pluggable backend selected by `STORAGE_DRIVER` in `.env`:
- `local` (default): filesystem under `STORAGE_PATH/DOCUMENT_STORAGE_SUBDIR/{user_id}/{uuid}.{ext}`.
- `s3`: S3-compatible object storage (AWS S3, MinIO, DigitalOcean Spaces, Cloudflare R2, Backblaze B2). Requires `composer require aws/aws-sdk-php`.

The `documents` table and `DocumentService` are backend-agnostic — switching from local to S3 is a one-line `.env` change. The `StorageInterface` contract has 8 methods: `save`, `stream`, `exists`, `size`, `delete`, `saveChunk`, `assembleChunks`, `abortChunkedUpload`.

**Upload constraints:**
- Max size: 10MB (configurable via `DOCUMENT_MAX_SIZE_MB`)
- Allowed MIME types: `application/pdf`, `image/png`, `image/jpeg` (configurable via `DOCUMENT_ALLOWED_MIMES`)
- M5 polish: MIME is validated TWICE — once via `$_FILES['type']` (claimed) and once via `finfo_file()` (content-detected). Both must match the whitelist. The detected MIME is stored in `documents.detected_mime` for audit.
- Stored filename is a random UUID + extension — users never control the on-disk path (no path traversal)
- SHA-256 content hash stored for audit

**M5 polish: ClamAV virus scanning:**
- Disabled by default (`CLAMAV_ENABLED=false`). Enable in production.
- Files are scanned via clamd INSTREAM socket BEFORE `Storage::save()`. Infected files are rejected with HTTP 422.
- Scan status is stored in `documents.scan_status` (`pending` / `clean` / `infected` / `skipped` / `failed`).
- `CLAMAV_FAIL_CLOSED=false` (default): scan failures (e.g. clamd not running) are logged but the upload is accepted with `scan_status='failed'`. Set to `true` in production to reject uploads on scan failure.

**M5 polish: Chunked uploads:**
- For files larger than 5MB (frontend-configurable threshold), the frontend auto-switches to chunked upload via `API.documents.uploadAuto(file, purpose)`.
- Protocol: `POST /api/documents/chunk` (start) → `POST /api/documents/chunk/{id}` (one per chunk, sequential) → `POST /api/documents/chunk/{id}/complete` (assemble + scan + persist).
- Chunks are 2MB by default (configurable via `DOCUMENT_CHUNK_SIZE_BYTES`).
- Resume: if a chunk POST fails, the client re-uploads the same index — the server overwrites the staged chunk.
- Abort: `POST /api/documents/chunk/{id}/abort` cleans up staged chunks.
- Chunk sessions are tracked in the `document_uploads` table. Abandoned sessions (status=`uploading` for >24h) are cleaned up by the disk GC cron.

**Security:**
- Ownership checks on every read/download/delete
- `STORAGE_PATH` must NOT be inside `public/` — `LocalStorage` enforces this at boot
- Soft-delete only (`deleted_at`); M5 polish: hard-delete via `bin/gc-documents.php` cron after `DOCUMENT_GC_RETENTION_DAYS` (default 30).
- M5 polish: Content-based MIME detection via `finfo_file()` (defense vs spoofed `$_FILES['type']`).

## Billing model (M4 + M4 polish)

Three plans, GHS-denominated, monthly billing. M4 polish adds proration + trials + plan enforcement.

| Plan | Price | Max Listings | Max Chat/day | Key Features |
|------|-------|--------------|--------------|--------------|
| Free | GHS 0/mo | 1 | 5 | Browse marketplace, basic chat |
| Pro | GHS 99/mo | unlimited | unlimited | E-sign documents, priority support, analytics |
| Enterprise | GHS 990/mo | unlimited | unlimited | Dedicated account manager, API access, SLA |

**M4 polish: Proration:**
- Upgrades are immediate with a prorated charge via Paystack. The prorated amount = (new_plan_price − old_plan_unused_value) for the remaining days in the current cycle.
- Downgrades are scheduled for `next_billing_at` (no charge today). The user retains their current plan until then.
- Preview proration without committing: `GET /api/billing/proration?planCode=pro` returns `{action, amountKobo, amountGhs, daysRemaining, oldCreditKobo, newChargeKobo}`.
- On upgrade, the webhook handler cancels the old subscription and starts a new one with a fresh `next_billing_at`. The proration invoice is marked `is_proration=1` for admin visibility.

**M4 polish: Trials:**
- 14-day free trial on Pro and Enterprise. No card required.
- `POST /api/billing/trial` with `{planCode}` creates a subscription with status=`trialing` and `trial_ends_at = NOW() + BILLING_TRIAL_DAYS`.
- Trial abuse prevention: a user can only ever have one trial per account. Re-trialing after expiry is rejected.
- `bin/billing-cron.php` (run hourly) expires trials whose `trial_ends_at` has passed — flips status to `expired`, downgrading the user to Free on their next request.

**M4 polish: Plan enforcement:**
- `PlanEnforcementService` checks `max_listings` and `max_chat_per_day` from the user's current plan.
- `ListingService::save()` calls `assertCanCreateListing(userId)` on new listings — throws `plan_limit_reached:` on quota exceeded.
- `ChatService::sendMessage()` calls `assertCanSendMessage(userId)` — throws `plan_limit_reached:` on quota exceeded.
- Controllers map `plan_limit_reached:` to HTTP 402 Payment Required (vs 403 for RBAC, 400 for validation).
- "Today" is computed in `Africa/Accra` timezone (the project's primary market) — daily counters reset at midnight Accra, not UTC.
- `0` in `max_listings` / `max_chat_per_day` means UNLIMITED (matches Pro and Enterprise seed).

**Cron jobs:**

```bash
# Hourly: expire due trials + apply pending downgrades (M4 polish)
0 * * * * cd /path/to/busifirm && php bin/billing-cron.php >> /var/log/busifirm/billing-cron.log 2>&1

# Daily 03:00: hard-delete soft-deleted documents past retention (M5 polish)
0 3 * * * cd /path/to/busifirm && php bin/gc-documents.php >> /var/log/busifirm/gc.log 2>&1

# Daily 03:30: hard-delete soft-deleted users past retention + purge expired audit_log (M6 polish)
30 3 * * * cd /path/to/busifirm && php bin/purge-deleted-users.php >> /var/log/busifirm/purge.log 2>&1
```

**Paystack integration:**
- **Test mode:** Set `PAYSTACK_SECRET_KEY=sk_test_…` in `.env`. Use Paystack test card `4084 0830 8315 3133` (GHS).
- **Live mode:** Set `PAYSTACK_SECRET_KEY=sk_live_…`. Replace webhook secret too.
- **Webhook URL:** Configure `https://your-domain.com/api/billing/webhook` in Paystack dashboard → Settings → API Keys & Webhooks. Set `PAYSTACK_WEBHOOK_SECRET` in `.env` to the secret Paystack shows.
- **Plans:** The `plans` table is seeded in SQL. `paystack_plan_code` is NULL until an admin creates matching plans in the Paystack dashboard and pastes the codes back via the admin panel. Until then, BillingService uses one-time transactions (no recurring billing) — users pay each month manually.
- **Recurring billing:** Enabled once admins set `paystack_plan_code`. The BillingService code path is already written; it just needs the codes.
- **Webhook signature verification:** HMAC-SHA512 of the raw request body, compared with `hash_equals()` (constant-time). Invalid signatures return 400 (no retry). Valid signatures return 200 always, even for unknown event types (so Paystack doesn't retry).
- **Idempotency:** The `invoices.paystack_reference` column has a UNIQUE constraint. Re-delivering the same webhook event updates the same invoice row without creating a duplicate or double-activating the subscription.

**Usage flow:**
1. Frontend uploads a file via `POST /api/documents` (multipart/form-data with `file` + `purpose` fields)
2. Server returns a document DTO with `id`, `downloadUrl`, `originalFilename`, etc.
3. Frontend passes the `id` to `KycService.updateStatus()` or `ESignService.save()` as a `documentId`
4. On read, `KycService.getStatus()` resolves document IDs to full DTOs with download links

## RBAC model (M3)

Five roles, three capability checks. KISS: native PHP enum, no permissions table.

| Role | canCreateListings() | canSignAsWitness() | isAdmin() | Other capabilities |
|------|---------------------|--------------------|-----------|--------------------|
| `seller` | ✅ | ❌ | ❌ | All read endpoints, create deals, sign own docs, manage integrations |
| `buyer` | ❌ | ❌ | ❌ | All read endpoints, initiate contact, make offers, create deals |
| `lawyer` | ❌ | ✅ | ❌ | All read endpoints, witness-sign any document (except own) |
| `broker` | ✅ | ❌ | ❌ | Same as seller (brokers represent sellers in M&A transactions) |
| `admin` | ❌ | ❌ | ✅ | All read endpoints + admin panel (verify KYC, set plan codes, view audit log) |

**Stale-role risk:** Role is cached in `$_SESSION['_busifirm_role']` at login. If an admin changes a user's role without invalidating the session, the cached role lags until next login. Phase 3 admin panel will invalidate sessions on role change.

**Admin promotion:** There is NO admin-promotion endpoint. Admin accounts are created via direct SQL: `UPDATE users SET role = 'admin' WHERE email = '…';`. The user must log out and log back in for the change to take effect.

## Security model (M1 + M2 + M3 + M4 + M5 + M6)

- **Passwords**: bcrypt, cost 12. Plaintext password is sent over HTTPS only; never logged, never stored client-side.
- **Tokens** (email verify + password reset): 32 random bytes (64 hex chars), stored **hashed** (SHA-256) in the DB. Plaintext returned once to the caller. Single-use. 24h verify TTL / 1h reset TTL.
- **Sessions**: PHP native, `session_regenerate_id(true)` on login, cookie flags `Secure`+`HttpOnly`+`SameSite=Lax`. Idle timeout 30 min (client-side timer + server-side session expiry).
- **CSRF**: Required on every POST/PUT/PATCH/DELETE. Exempt paths: `/auth/register`, `/auth/login`, `/auth/forgot`, `/auth/reset` (these are callable before a CSRF token can be issued — login itself bootstraps the token).
- **Rate limiting**: 10 requests/minute/IP per endpoint on the four bruteforce-prone routes. File-based, hash-of-IP filenames.
- **Audit log**: every auth event written to `audit_log` with `ip_hash` + `user_agent_hash` (not raw values).
- **Account enumeration**: `/auth/forgot` always returns success regardless of whether the email exists. `/auth/login` returns the same error for "no such user" and "wrong password".

## Tests

```bash
composer test     # phpunit
```

A `busifirm_test` database is required (see `phpunit.xml`). The test suite uses `Database::setInstance()` to inject a real PDO connection; integration tests will truncate relevant tables between tests.

## Known limitations (v0.8.0 scope)

- ✅ M1 done: server-side auth (bcrypt + email verify + password reset).
- ✅ M2 done: listings, chat, KYC, deals, esign, integrations, audit log all server-backed.
- ✅ M3 done: RBAC enforced on listing create/delete (seller/broker only) and witness-sign (lawyer only).
- ✅ M4 done: Paystack subscription billing with 3 plans, webhook signature verification, billing dashboard, cancel flow.
- ✅ M4 polish done (v0.8.0): proration on upgrades, scheduled downgrades, 14-day trials, plan enforcement on max_listings + max_chat_per_day (HTTP 402 on quota).
- ✅ M5 done: Document storage with file upload (PDF/PNG/JPEG, 10MB max), download streaming, soft-delete, KYC + esign integration.
- ✅ M5 polish done (v0.8.0): StorageInterface + LocalStorage + S3Storage + StorageFactory (pluggable backend), finfo_file content-based MIME validation, ClamAV scanning, chunked uploads, disk GC cron.
- ✅ M6 done: Admin panel with KYC verification, plan-code management, audit log viewer, aggregate stats.
- ✅ M6 polish done (v0.8.0): GDPR user-delete (soft-delete + anonymized audit_log + hard-delete GC cron), session invalidation via role_version pattern (closes v0.7.0 stale-role risk), admin role-change UI.
- ⏳ M9 GDPR export endpoint (delete is done; export is the remaining half) — Phase 3.
- ⏳ M10 backup automation — Phase 3.
- Chat messages stored as JSON column on `chat_conversations` — will be normalized to a separate `chat_messages` table when the WebSocket real-time chat milestone (Phase 4) lands. (OTH-25 fix: clarified that "S3" here refers to the Phase 4 sprint milestone, NOT Amazon S3 storage.)
- Per-user seed data (sample chat, sample esign, sample deals) was dropped in M2. New users see empty states. Dev-mode lazy seeding is a Phase 3 candidate.
- M5 polish: S3 chunked upload assembly uses GetObject + PutObject (not S3 multipart upload). Acceptable for files up to ~100MB; Phase 4+ should switch to S3 multipart for larger files.
- M5 polish: ClamAV scanning for chunked uploads is best-effort (scans the assembled file, not individual chunks). A malicious chunk could be uploaded but would be caught at assembly time.
- M5 polish: SHA-256 for chunked uploads only works on local FS (where we can hash the assembled file path). S3 chunked uploads get a placeholder SHA — Phase 4+ should add multi-part SHA via the S3 SDK.
- M6 polish: admin promotion to admin role is still SQL-only by design. Phase 4+ may add a super-admin role that can promote others.
- M6 polish: when an admin changes a user's role, the user's session is invalidated on their NEXT request — not instantly. If the user is mid-request when the role changes, that request completes with the old role. Acceptable for v0.8.0; a Phase 4+ sessions table would enable instant invalidation.
- M6 polish: admin can change roles for seller/buyer/lawyer/broker only. Cannot demote another admin via the UI (must use SQL).

## Development notes

- **OTH-17 fix**: composer.json `suggest` messages now have proper spacing.
- **OTH-19 fix**: `composer serve-public` script added for binding to `0.0.0.0` (mobile testing on the same network).
- **OTH-27 fix**: `composer lint` script added — runs `php -l` on all PHP files in `app/`, `bin/`, and `public/index.php`. Run before committing to catch syntax errors.

## License

Proprietary. © 2026 Busifirm. Licensed under Ghana Companies Act 2019.
