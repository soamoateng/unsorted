<?php
declare(strict_types=1);

namespace Busifirm\Middleware;

use Busifirm\Core\Role;

/**
 * AdminMiddleware — gates admin-only endpoints.
 *
 * KISS: a single static method. Checks $_SESSION['_busifirm_role'] against
 * the Role enum. Returns true on admin, sends 403 JSON + returns false
 * otherwise. Session must already be started by the caller (the front
 * controller starts it for all /api/* routes).
 *
 * The role is cached in session at login (M3). If an admin is demoted
 * without invalidating the session, the cached role lags until next login.
 * Phase 3+ admin panel will call session_regenerate_id(true) on role change.
 */
final class AdminMiddleware
{
    /**
     * Returns true if the current session's user is an admin. Sends a 403
     * JSON response and returns false otherwise so the caller can short-circuit.
     */
    public static function requireAdmin(): bool
    {
        $roleString = (string)($_SESSION['_busifirm_role'] ?? '');
        $role = Role::fromString($roleString);
        if ($role === null || !$role->isAdmin()) {
            http_response_code(403);
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode([
                'ok' => false,
                'error' => 'Admin access required.',
            ]);
            return false;
        }
        return true;
    }
}
