<?php
declare(strict_types=1);

namespace Busifirm\Middleware;

use Busifirm\Core\Database;

/**
 * AuthMiddleware — protects endpoints that require a logged-in user.
 *
 * KISS: a single static method, no interface, no DI. If/when middleware chains
 * become complex (Phase 2+), introduce a Middleware interface and a chain
 * runner. Not before.
 *
 * M6 polish (v0.8.0): session invalidation on role change. We compare
 * $_SESSION['_busifirm_role_version'] (cached at login) to the DB's
 * users.role_version. If they differ, the user's role was changed by an
 * admin since login — we regenerate the session and re-read the role from
 * the DB. This closes the stale-role risk documented in v0.7.0.
 *
 * The role_version check is a single SELECT on every authenticated request.
 * For high-traffic deployments, consider caching role_version in a Redis
 * counter or moving sessions to DB (Phase 4+). For v0.8.0, the extra query
 * is acceptable — AuthMiddleware already runs on every authenticated request.
 *
 * Hard-deleted users (deleted_at IS NOT NULL) are also rejected here —
 * their session is wiped and they're sent a 401. This catches the edge case
 * where an admin deletes a user while they have an active session.
 */
final class AuthMiddleware
{
    /**
     * Returns true if the current session has a user_id AND the user is still
     * active (not deleted) AND the role hasn't changed since login. Sends a
     * 401 JSON response and returns false otherwise so the caller can short-circuit.
     */
    public static function requireUser(): bool
    {
        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }
        $userId = $_SESSION['_busifirm_user_id'] ?? null;
        if ($userId === null) {
            self::unauthorized('Not authenticated.');
            return false;
        }

        // PHP-001 / XFILE-003 fix: enforce the email-verification gate that
        // AuthController::register sets via $_SESSION['_busifirm_email_verified'] = false
        // (app/Controllers/AuthController.php:50). The SEC-36 "fix" set the flag
        // but no code ever read it — unverified users could call every
        // /api/{listings, deals, chat, esigns, ...} endpoint. The verification
        // gate was purely client-side. This 4-line guard closes the hole.
        // The DB-side check further down (line 64) re-confirms via
        // users.email_verified_at in case the session flag is stale.
        $emailVerified = $_SESSION['_busifirm_email_verified'] ?? false;
        if ($emailVerified !== true) {
            self::destroySession();
            self::unauthorized('Email verification required. Please check your email and click the verification link.');
            return false;
        }

        // M6 polish: verify the user still exists, isn't deleted, and their
        // role hasn't changed since login. If any of these fail, destroy the
        // session and return 401.
        try {
            $row = Database::run(
                'SELECT role, role_version, deleted_at, email_verified_at FROM users WHERE id = ? LIMIT 1',
                [$userId]
            )->fetch();
        } catch (\Throwable $e) {
            // DB error — fail open (let the request through) but log. The
            // downstream controller will likely fail too. KISS: don't block
            // on transient DB issues.
            error_log('[busifirm] AuthMiddleware DB check failed: ' . $e->getMessage());
            return true;
        }

        if ($row === false) {
            // User was hard-deleted (GDPR cron ran). Wipe session.
            self::destroySession();
            self::unauthorized('Account no longer exists.');
            return false;
        }
        if ($row['deleted_at'] !== null) {
            // User was soft-deleted by an admin. Wipe session.
            self::destroySession();
            self::unauthorized('Account has been deactivated.');
            return false;
        }
        // PHP-001 defense-in-depth: even if the session flag was tampered with
        // or the user's email_verified_at was reset by an admin, re-check the
        // source of truth. This also catches sessions created before the
        // SEC-36 flag was introduced (legacy sessions still in the wild).
        if ($row['email_verified_at'] === null) {
            self::destroySession();
            self::unauthorized('Email verification required. Please check your email and click the verification link.');
            return false;
        }

        $cachedRoleVersion = $_SESSION['_busifirm_role_version'] ?? 0;
        $dbRoleVersion = (int)$row['role_version'];
        if ($cachedRoleVersion !== $dbRoleVersion) {
            // Role was changed by an admin since login. Regenerate the session
            // (invalidates the old session ID to prevent fixation) and update
            // the cached role + version.
            session_regenerate_id(true);
            $_SESSION['_busifirm_role'] = $row['role'];
            $_SESSION['_busifirm_role_version'] = $dbRoleVersion;
            // Also refresh the cached plan code in case the role change came
            // with a billing change (admin downgraded them as part of a
            // support ticket, etc.).
            try {
                $planRow = Database::run(
                    'SELECT p.code FROM subscriptions s
                     INNER JOIN plans p ON s.plan_id = p.id
                     WHERE s.user_id = ? AND s.status IN ("active", "trialing", "past_due")
                     ORDER BY s.created_at DESC LIMIT 1',
                    [$userId]
                )->fetch();
                $_SESSION['_busifirm_plan_code'] = $planRow !== false ? $planRow['code'] : 'free';
            } catch (\Throwable $e) {
                $_SESSION['_busifirm_plan_code'] = 'free';
            }
        }

        return true;
    }

    private static function unauthorized(string $message): void
    {
        http_response_code(401);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['ok' => false, 'error' => $message]);
    }

    private static function destroySession(): void
    {
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $p = session_get_cookie_params();
            // PHP-037 fix: use array form of setcookie to include SameSite=Strict.
            setcookie(session_name(), '', [
                'expires' => time() - 42000,
                'path' => $p['path'],
                'domain' => $p['domain'],
                'secure' => $p['secure'],
                'httponly' => $p['httponly'],
                'samesite' => $p['samesite'] ?? 'Strict',
            ]);
        }
        @session_destroy();
    }
}
