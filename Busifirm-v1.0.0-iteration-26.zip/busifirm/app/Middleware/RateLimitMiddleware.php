<?php
declare(strict_types=1);

namespace Busifirm\Middleware;

use Busifirm\Core\Config;

/**
 * RateLimitMiddleware — file-based per-IP rate limiter for auth endpoints.
 *
 * KISS: file-based (sys_get_temp_dir) because Phase 1 has no Redis. Each IP
 * gets a small file with a sliding-window counter. Phase 3 swaps this for
 * Redis without changing the call site.
 *
 * SOLID (SRP): this class only counts requests per IP per window. It does not
 * know which endpoints are rate-limited (caller decides) or what to do when
 * the limit is hit (caller sends the 429).
 *
 * SECURITY: file names are hashed IPs (sha256) so directory listings don't
 * leak visitor IPs.
 */
final class RateLimitMiddleware
{
    /**
     * @return bool True if request is allowed; false if rate-limited.
     */
    public static function allow(string $bucket, ?int $perMinute = null): bool
    {
        $perMinute ??= Config::getInt('AUTH_RATE_LIMIT_PER_MINUTE', 10);
        // SEC-07 fix: use the same trusted-proxy logic as AuthController::ip().
        $ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
        $trustedProxies = \Busifirm\Core\Config::get('TRUSTED_PROXIES', '');
        if ($trustedProxies !== '') {
            $proxyList = array_map('trim', explode(',', $trustedProxies));
            if (in_array($ip, $proxyList, true)) {
                $forwarded = $_SERVER['HTTP_X_FORWARDED_FOR'] ?? '';
                if ($forwarded !== '') {
                    $parts = explode(',', $forwarded);
                    $ip = trim($parts[0]);
                }
            }
        }

        $dir = sys_get_temp_dir() . '/busifirm_ratelimit';
        if (!is_dir($dir)) {
            @mkdir($dir, 0700, true);
        }
        $file = $dir . '/' . hash('sha256', $bucket . '|' . $ip);

        $now = time();
        $windowStart = $now - 60;

        // PHP-004 fix: the old code used file_get_contents (no lock) for the
        // read, then file_put_contents(LOCK_EX) for the write. Two concurrent
        // requests could both read 9 hits, both see under the limit, both
        // append, and both write 10 hits — allowing 11 requests through when
        // the limit is 10. The LOCK_EX on the write didn't help because the
        // read was unlocked.
        //
        // Fix: open the file with 'c+' (create+read-write, no truncation) and
        // acquire an exclusive lock (flock LOCK_EX) BEFORE reading. This
        // serializes the entire read-modify-write cycle. Other requests block
        // until the lock is released.
        $fp = @fopen($file, 'c+');
        if ($fp === false) {
            // Can't open the rate-limit file (disk full? permissions?). Fail
            // OPEN — let the request through. Rate limiting is a defense, not
            // a hard requirement; blocking legit users because the temp dir is
            // unwritable is worse than allowing a few extra requests.
            return true;
        }
        try {
            if (!flock($fp, LOCK_EX)) {
                // Can't acquire the lock — fail open (same reasoning as above).
                return true;
            }

            // Read the current data under the lock.
            $data = ['hits' => []];
            $raw = stream_get_contents($fp);
            if ($raw !== false && $raw !== '') {
                $decoded = json_decode($raw, true);
                if (is_array($decoded) && isset($decoded['hits']) && is_array($decoded['hits'])) {
                    $data = $decoded;
                }
            }

            // Drop entries outside the 60s window.
            $data['hits'] = array_values(array_filter(
                $data['hits'],
                fn(int $ts): bool => $ts > $windowStart
            ));

            if (count($data['hits']) >= $perMinute) {
                return false;
            }

            $data['hits'][] = $now;

            // Write the updated data back under the lock. Truncate + rewind
            // first so we don't leave stale bytes at the end if the new
            // payload is shorter than the old one.
            ftruncate($fp, 0);
            rewind($fp);
            fwrite($fp, json_encode($data));
            fflush($fp);

            return true;
        } finally {
            // Release the lock and close the handle.
            @flock($fp, LOCK_UN);
            @fclose($fp);
        }
    }

    /** Send a 429 response and end execution. */
    public static function denyResponse(): void
    {
        http_response_code(429);
        header('Content-Type: application/json; charset=utf-8');
        header('Retry-After: 60');
        echo json_encode([
            'ok' => false,
            'error' => 'Too many requests. Please wait a minute and try again.',
        ]);
    }
}
