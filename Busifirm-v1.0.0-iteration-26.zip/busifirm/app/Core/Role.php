<?php
declare(strict_types=1);

namespace Busifirm\Core;

/**
 * Role — value object representing a user role.
 *
 * KISS: native PHP 8.3 enum with hardcoded capability helpers. No permissions
 * table, no policy classes, no RBAC framework. Four roles, three capabilities.
 *
 * When dynamic roles are needed (Phase 3 admin panel), refactor to a
 * roles + role_permissions table structure. The enum stays as the
 * type-safe value object; only the capability lookups become DB-driven.
 *
 * SOLID (SRP): this enum knows ONLY about role identity and the capabilities
 * directly implied by that identity. It does NOT know about resources, actions,
 * or contexts — those live in the services that call canCreateListings() etc.
 */
enum Role: string
{
    case Seller = 'seller';
    case Buyer = 'buyer';
    case Lawyer = 'lawyer';
    case Broker = 'broker';
    case Admin = 'admin';

    /**
     * Parse a role from a raw string (e.g. from the users.role column or from
     * session storage). Returns null on invalid input so the caller can decide
     * how to handle it (usually: deny access + 403).
     */
    public static function fromString(string $value): ?self
    {
        foreach (self::cases() as $case) {
            if ($case->value === $value) {
                return $case;
            }
        }
        return null;
    }

    /**
     * Capability: can this role create/edit/delete listings?
     * Sellers list their own companies. Brokers list on behalf of sellers.
     * Buyers, Lawyers, and Admins do not list (they consume listings).
     * Admins have all capabilities but listing-creation is not one of them —
     * admins moderate, they don't sell.
     */
    public function canCreateListings(): bool
    {
        return $this === self::Seller || $this === self::Broker;
    }

    /**
     * Capability: can this role sign a document as a witness?
     * Only licensed lawyers can act as witnesses — Ghanaian contract law
     * requires an officer of the court or a notary public for certain
     * M&A instruments.
     */
    public function canSignAsWitness(): bool
    {
        return $this === self::Lawyer;
    }

    /**
     * Capability: can this role access the admin panel?
     * Admins can view all users, verify KYC, set paystack_plan_code,
     * and view the full audit log. Admins cannot create listings or
     * sign as witness (separation of duties).
     */
    public function isAdmin(): bool
    {
        return $this === self::Admin;
    }

    /**
     * Human-readable label for UI rendering.
     */
    public function label(): string
    {
        return match ($this) {
            self::Seller => 'Seller (Tech Founder)',
            self::Buyer => 'Buyer / Investor',
            self::Lawyer => 'Licensed Lawyer',
            self::Broker => 'Professional Broker',
            self::Admin => 'Administrator',
        };
    }
}
