<?php
declare(strict_types=1);

namespace Busifirm\Core;

use PDO;
use PDOException;

/**
 * Database — thin singleton PDO wrapper.
 *
 * KISS: no ORM, no query builder. Pure prepared statements. Single source of
 * truth for the PDO instance across the request lifecycle.
 *
 * SOLID (DIP): services receive this via constructor injection, so a test can
 * swap in an in-memory SQLite or a mock PDO. The class itself is final because
 * it is not designed for inheritance — extend by composition, not subclassing.
 */
final class Database
{
    private static ?PDO $instance = null;

    public static function connect(): PDO
    {
        if (self::$instance instanceof PDO) {
            return self::$instance;
        }

        $host = Config::get('DB_HOST', '127.0.0.1');
        $port = Config::get('DB_PORT', '3306');
        $name = Config::get('DB_NAME', 'busifirm');
        $user = Config::get('DB_USER', 'busifirm');
        $pass = Config::get('DB_PASSWORD', '');
        $charset = Config::get('DB_CHARSET', 'utf8mb4');

        $dsn = "mysql:host={$host};port={$port};dbname={$name};charset={$charset}";

        try {
            $pdo = new PDO($dsn, $user, $pass, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,  // real prepared statements
                PDO::ATTR_PERSISTENT => false,
            ]);
        } catch (PDOException $e) {
            throw new \RuntimeException('Database connection failed: ' . $e->getMessage(), 0, $e);
        }

        self::$instance = $pdo;
        return $pdo;
    }

    /** For tests / dependency injection. */
    public static function setInstance(PDO $pdo): void
    {
        self::$instance = $pdo;
    }

    /** Convenience helper — runs a prepared statement and returns the PDOStatement. */
    public static function run(string $sql, array $params = []): \PDOStatement
    {
        $stmt = self::connect()->prepare($sql);
        $stmt->execute($params);
        return $stmt;
    }
}
