<?php
declare(strict_types=1);

namespace Busifirm\Core;

use RuntimeException;

/**
 * StorageFactory — selects the storage backend based on STORAGE_DRIVER.
 *
 * M5 polish (v0.8.0): introduced so DocumentService receives a
 * StorageInterface via dependency injection (DIP) instead of calling
 * Storage:: directly. The factory is called once at boot (index.php) to
 * construct the singleton that all DocumentService instances share.
 *
 * Drivers:
 *   - 'local' (default): LocalStorage under STORAGE_PATH.
 *   - 's3': S3Storage (requires aws/aws-sdk-php + S3_* env vars).
 *   - 'memory': in-memory array (testing only — not for production).
 *
 * KISS: static factory. No DI container, no service locator. One method,
 * one return type.
 */
final class StorageFactory
{
    /**
     * Construct the configured storage backend.
     *
     * @throws RuntimeException if the configured driver is unknown or its
     *                          dependencies are missing.
     */
    public static function make(): StorageInterface
    {
        $driver = strtolower(Config::get('STORAGE_DRIVER', 'local'));
        return match ($driver) {
            'local', 'filesystem', 'fs' => new LocalStorage(),
            's3', 'aws', 'minio', 'spaces', 'r2' => new S3Storage(),
            default => throw new RuntimeException(
                'Unknown STORAGE_DRIVER "' . $driver . '". Supported: local, s3.'
            ),
        };
    }
}
