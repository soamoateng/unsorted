<?php
declare(strict_types=1);

namespace Busifirm\Core;

/**
 * LocalStorage — filesystem-backed implementation of StorageInterface.
 *
 * M5 polish (v0.8.0): refactored from the v0.7.0 `Storage` class. Same
 * behavior, now implementing StorageInterface so the backend can be
 * swapped to S3Storage via StorageFactory without touching DocumentService.
 *
 * KISS: files live under STORAGE_PATH / DOCUMENT_STORAGE_SUBDIR / {user_id} / {stored_filename}.
 * Chunk staging lives under STORAGE_PATH / chunks / {upload_id} / {index}.
 *
 * SOLID (SRP): this class ONLY moves file bytes around. It does NOT validate
 * MIME types, enforce size limits, or write to the documents table — that's
 * DocumentService's job.
 *
 * Security:
 *   - stored_filename is a UUID + extension; users never control the on-disk
 *     path, eliminating path traversal.
 *   - User-scoped subdirectories prevent one user from accessing another's
 *     files even if the download endpoint has a bug.
 *   - No executable permissions on saved files (chmod 0640).
 *   - STORAGE_PATH must NOT be inside public/ — enforced at boot.
 */
final class LocalStorage implements StorageInterface
{
    private static ?string $rootPath = null;
    private static ?string $chunksPath = null;

    /**
     * Get the absolute path to the user's storage directory, creating it
     * if it doesn't exist.
     */
    private function userDir(string $userId): string
    {
        $root = self::root();
        $dir = $root . '/' . $userId;
        if (!is_dir($dir)) {
            mkdir($dir, 0750, true);
        }
        return $dir;
    }

    private function chunkDir(string $uploadId): string
    {
        $root = self::chunksRoot();
        $dir = $root . '/' . $uploadId;
        if (!is_dir($dir)) {
            mkdir($dir, 0750, true);
        }
        return $dir;
    }

    public function save(string $userId, string $storedFilename, string $tmpPath): string
    {
        $dir = $this->userDir($userId);
        $dest = $dir . '/' . basename($storedFilename);

        if (!is_uploaded_file($tmpPath)) {
            throw new \RuntimeException('Not an uploaded file: ' . $tmpPath);
        }
        if (!move_uploaded_file($tmpPath, $dest)) {
            throw new \RuntimeException('Failed to move uploaded file to ' . $dest);
        }
        // SEC-25 fix: changed chmod from 0640 to 0600 — owner-only access.
        // The old 0640 allowed group-read, which on shared hosting lets other
        // sites on the same server read uploaded KYC documents.
        chmod($dest, 0600);
        return $dest;
    }

    public function stream(string $userId, string $storedFilename): bool
    {
        $path = $this->userDir($userId) . '/' . basename($storedFilename);
        if (!is_file($path) || !is_readable($path)) {
            return false;
        }
        $bytes = readfile($path);
        return $bytes !== false;
    }

    public function exists(string $userId, string $storedFilename): bool
    {
        $path = $this->userDir($userId) . '/' . basename($storedFilename);
        return is_file($path);
    }

    public function size(string $userId, string $storedFilename): int
    {
        $path = $this->userDir($userId) . '/' . basename($storedFilename);
        $size = @filesize($path);
        return $size === false ? 0 : (int)$size;
    }

    public function delete(string $userId, string $storedFilename): bool
    {
        $path = $this->userDir($userId) . '/' . basename($storedFilename);
        if (!is_file($path)) return true;
        return @unlink($path);
    }

    // ----- Chunked upload support -----

    public function saveChunk(string $uploadId, int $index, string $tmpPath): string
    {
        $dir = $this->chunkDir($uploadId);
        $dest = $dir . '/' . sprintf('%08d', $index) . '.chunk';
        if (!is_uploaded_file($tmpPath)) {
            throw new \RuntimeException('Not an uploaded chunk: ' . $tmpPath);
        }
        if (!move_uploaded_file($tmpPath, $dest)) {
            throw new \RuntimeException('Failed to move chunk to ' . $dest);
        }
        chmod($dest, 0600);  // SEC-25 fix: owner-only
        return $dest;
    }

    public function assembleChunks(string $userId, string $storedFilename, string $uploadId, int $totalChunks): string
    {
        $dir = $this->userDir($userId);
        $finalPath = $dir . '/' . basename($storedFilename);

        $out = fopen($finalPath, 'wb');
        if ($out === false) {
            throw new \RuntimeException('Failed to open final file for write: ' . $finalPath);
        }
        try {
            for ($i = 0; $i < $totalChunks; $i++) {
                $chunkPath = $this->chunkDir($uploadId) . '/' . sprintf('%08d', $i) . '.chunk';
                if (!is_file($chunkPath)) {
                    throw new \RuntimeException('Missing chunk ' . $i . ' for upload ' . $uploadId);
                }
                $in = fopen($chunkPath, 'rb');
                if ($in === false) {
                    throw new \RuntimeException('Failed to open chunk for read: ' . $chunkPath);
                }
                try {
                    while (!feof($in)) {
                        $buf = fread($in, 65536);
                        if ($buf === false) break;
                        fwrite($out, $buf);
                    }
                } finally {
                    fclose($in);
                }
            }
        } finally {
            fclose($out);
        }
        chmod($finalPath, 0600);  // SEC-25 fix: owner-only
        return $finalPath;
    }

    public function abortChunkedUpload(string $uploadId): void
    {
        $dir = $this->chunkDir($uploadId);
        if (!is_dir($dir)) return;
        // Best-effort recursive delete of chunk staging dir.
        $files = glob($dir . '/*') ?: [];
        foreach ($files as $f) {
            if (is_file($f)) @unlink($f);
        }
        @rmdir($dir);
    }

    public function chunkExists(string $uploadId, int $index): bool
    {
        $path = $this->chunkDir($uploadId) . '/' . sprintf('%08d', $index) . '.chunk';
        return is_file($path);
    }

    // ----- Path helpers -----

    private static function root(): string
    {
        if (self::$rootPath !== null) return self::$rootPath;
        $base = Config::get('STORAGE_PATH', '');
        $subdir = Config::get('DOCUMENT_STORAGE_SUBDIR', 'documents');
        if ($base === '') {
            throw new \RuntimeException('STORAGE_PATH is not configured. Set it in .env (see .env.example).');
        }
        $root = rtrim($base, '/') . '/' . trim($subdir, '/');
        if (!is_dir($root)) {
            mkdir($root, 0750, true);
        }
        // Guard against the storage directory being inside public/.
        $publicRoot = realpath(__DIR__ . '/../../public');
        $realRoot = realpath($root);
        if ($realRoot !== false && $publicRoot !== false && str_starts_with($realRoot, $publicRoot)) {
            throw new \RuntimeException(
                'STORAGE_PATH must NOT be inside public/. Move it outside the web root.'
            );
        }
        self::$rootPath = $root;
        return $root;
    }

    private static function chunksRoot(): string
    {
        if (self::$chunksPath !== null) return self::$chunksPath;
        $base = Config::get('STORAGE_PATH', '');
        if ($base === '') {
            throw new \RuntimeException('STORAGE_PATH is not configured.');
        }
        $chunksRoot = rtrim($base, '/') . '/chunks';
        if (!is_dir($chunksRoot)) {
            mkdir($chunksRoot, 0750, true);
        }
        self::$chunksPath = $chunksRoot;
        return $chunksRoot;
    }

    /** For tests / bootstrapping. */
    public static function setRootForTest(string $path): void
    {
        self::$rootPath = $path;
        self::$chunksPath = $path . '/chunks';
    }
}
