<?php
declare(strict_types=1);

namespace Busifirm\Core;

/**
 * Config — typed, immutable accessor over .env loaded once at boot.
 *
 * KISS: no vlucas/phpdotenv dependency. Reads a flat KEY=VALUE file with
 * optional quoting. Does not support variable interpolation (not needed here).
 *
 * SOLID (SRP): this class only loads + exposes config. It does not validate
 * business rules; that is the caller's responsibility.
 */
final class Config
{
    /** @var array<string,string>|null */
    private static ?array $cache = null;

    public static function load(string $path): void
    {
        if (self::$cache !== null) {
            return;
        }
        $values = [];
        if (!is_readable($path)) {
            throw new \RuntimeException("Config file not readable: {$path}");
        }
        $lines = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) ?: [];
        foreach ($lines as $line) {
            $line = trim($line);
            if ($line === '' || $line[0] === '#') {
                continue;
            }
            if (!str_contains($line, '=')) {
                continue;
            }
            [$k, $v] = explode('=', $line, 2);
            $k = trim($k);
            $v = trim($v);
            // strip surrounding quotes
            if (strlen($v) >= 2 && $v[0] === $v[strlen($v) - 1] && ($v[0] === '"' || $v[0] === "'")) {
                $v = substr($v, 1, -1);
            }
            $values[$k] = $v;
        }
        self::$cache = $values;
    }

    /**
     * Allow tests / bootstrapping to inject values directly without a file.
     *
     * @param array<string,string> $values
     */
    public static function setForTest(array $values): void
    {
        self::$cache = $values;
    }

    public static function get(string $key, ?string $default = null): ?string
    {
        if (self::$cache === null) {
            throw new \RuntimeException('Config::load() must be called first.');
        }
        return self::$cache[$key] ?? $default;
    }

    public static function getInt(string $key, int $default): int
    {
        $v = self::get($key);
        if ($v === null) return $default;
        // PHP-038 fix: validate with filter_var instead of silent (int) cast.
        // (int)"abc" returns 0, which could be passed to password_hash as bcrypt
        // cost 0 (invalid). filter_var returns false for non-numeric strings.
        $validated = filter_var($v, FILTER_VALIDATE_INT);
        if ($validated === false) {
            error_log("[busifirm] Config::getInt('{$key}') — invalid integer value: {$v}; using default {$default}");
            return $default;
        }
        return $validated;
    }

    public static function getBool(string $key, bool $default): bool
    {
        $v = self::get($key);
        if ($v === null) return $default;
        return in_array(strtolower($v), ['1', 'true', 'yes', 'on'], true);
    }
}
