<?php
declare(strict_types=1);

namespace Busifirm\Core;

/**
 * PaystackClient — thin HTTP client for the Paystack REST API.
 *
 * KISS: no SDK dependency. Paystack's REST API is simple enough that a 60-line
 * cURL wrapper is cleaner than pulling in a framework-coupled package
 * (unicodeveloper/laravel-paystack is Laravel-only; stephenjude/paystack is
 * Laravel+PHP 8.1 but adds a cache layer we don't need).
 *
 * SOLID (SRP): this class ONLY speaks HTTP to Paystack. It does NOT know about
 * our database, our subscriptions table, or our user model. The BillingService
 * owns that mapping. This separation lets us swap Paystack for another
 * processor (Stripe, Flutterwave) by writing a new class that implements the
 * same surface (initialize, verify, listPlans, etc.) — though we intentionally
 * don't extract a PaymentProcessor interface yet (KISS: one processor, no
 * polymorphism needed until we add a second).
 *
 * SOLID (DIP): callers (BillingService) depend on this concrete class. A test
 * can swap it via Database::setInstance-style injection — but we don't extract
 * an interface until there's a second implementation or a test that needs it.
 *
 * Webhook verification lives here (verifyWebhookSignature) because it's a
 * Paystack-specific cryptographic operation, not a billing business rule.
 *
 * All methods throw RuntimeException on HTTP failure, non-2xx response, or
 * missing fields in the response. Callers wrap in try/catch and map to the
 * right HTTP status for the API consumer.
 *
 * @see https://paystack.com/docs/api PHP SDK reference (Aug 2026)
 */
final class PaystackClient
{
    private string $secretKey;
    private string $publicKey;
    private string $apiBase;

    public function __construct()
    {
        $this->secretKey = Config::get('PAYSTACK_SECRET_KEY', '');
        $this->publicKey = Config::get('PAYSTACK_PUBLIC_KEY', '');
        $this->apiBase = rtrim(Config::get('PAYSTACK_API_BASE', 'https://api.paystack.co'), '/');

        if ($this->secretKey === '' || str_starts_with($this->secretKey, 'sk_test_change')) {
            throw new \RuntimeException(
                'PAYSTACK_SECRET_KEY is not configured. Set it in .env (see .env.example).'
            );
        }
    }

    /**
     * Initialize a transaction. Returns the authorization_url the user must
     * visit to complete payment, plus the reference we'll use to verify later.
     *
     * @param string $email    Customer email (Paystack requires this).
     * @param int    $amountKobo GHS amount in kobo (1 GHS = 100 kobo).
     * @param string $callbackUrl Where Paystack redirects after the popup.
     * @param array  $metadata  Optional metadata Paystack stores on the transaction.
     * @return array{reference: string, authorization_url: string, access_code: string}
     */
    public function initializeTransaction(string $email, int $amountKobo, string $callbackUrl, array $metadata = []): array
    {
        $body = [
            'email' => $email,
            'amount' => $amountKobo,  // Paystack expects kobo for GHS
            'currency' => 'GHS',
            'callback_url' => $callbackUrl,
        ];
        if (!empty($metadata)) {
            $body['metadata'] = $metadata;
        }

        $resp = $this->request('POST', '/transaction/initialize', $body);
        $data = $resp['data'] ?? null;
        if (!is_array($data) || empty($data['reference']) || empty($data['authorization_url'])) {
            throw new \RuntimeException('Paystack initialize returned unexpected response: missing reference or authorization_url.');
        }
        return [
            'reference' => (string)$data['reference'],
            'authorization_url' => (string)$data['authorization_url'],
            'access_code' => (string)($data['access_code'] ?? ''),
        ];
    }

    /**
     * Verify a transaction by reference. Call this BEFORE trusting any
     * client-side success callback. The webhook is the source of truth;
     * this method is for the redirect-back-to-app flow.
     *
     * @return array{status: string, amount: int, currency: string, channel: string, paid_at: string|null, metadata: array}
     */
    public function verifyTransaction(string $reference): array
    {
        $resp = $this->request('GET', '/transaction/verify/' . urlencode($reference));
        $data = $resp['data'] ?? null;
        if (!is_array($data)) {
            throw new \RuntimeException('Paystack verify returned no data.');
        }
        return [
            'status' => (string)($data['status'] ?? 'unknown'),  // 'success' on success
            'amount' => (int)($data['amount'] ?? 0),
            'currency' => (string)($data['currency'] ?? 'GHS'),
            'channel' => (string)($data['channel'] ?? ''),
            'paid_at' => isset($data['paid_at']) ? (string)$data['paid_at'] : null,
            'metadata' => is_array($data['metadata'] ?? null) ? $data['metadata'] : [],
        ];
    }

    /**
     * Verify the x-paystack-signature header on a webhook payload.
     *
     * Paystack signs the RAW request body (not a normalized form) with
     * HMAC-SHA512 using the webhook secret. We must compare with hash_equals()
     * to prevent timing attacks.
     *
     * @param string $rawBody  The raw php://input contents (do NOT json_decode first).
     * @param string $signature The value of the x-paystack-signature header.
     * @return bool True if the signature is valid.
     */
    public function verifyWebhookSignature(string $rawBody, string $signature): bool
    {
        $secret = Config::get('PAYSTACK_WEBHOOK_SECRET', '');
        if ($secret === '' || str_starts_with($secret, 'whk_change')) {
            throw new \RuntimeException('PAYSTACK_WEBHOOK_SECRET is not configured.');
        }
        if ($signature === '') {
            return false;
        }
        $expected = hash_hmac('sha512', $rawBody, $secret);
        return hash_equals($expected, $signature);
    }

    /**
     * Disable (cancel) a Paystack subscription so the user is not charged
     * again at the next billing cycle. The user retains access until the
     * current period ends.
     *
     * @param string $subscriptionCode The paystack_subscription_code from subscriptions table.
     * @param string $emailToken        The paystack_email_token (Paystack requires this for disable).
     */
    public function disableSubscription(string $subscriptionCode, string $emailToken): void
    {
        $body = [
            'code' => $subscriptionCode,
            'token' => $emailToken,
        ];
        $this->request('POST', '/subscription/disable', $body);
    }

    /**
     * Internal HTTP request helper. Uses cURL (always available in PHP 8.3).
     *
     * @param string $method HTTP method (GET, POST, PUT, DELETE).
     * @param string $path   Path under the API base (e.g. '/transaction/initialize').
     * @param array|null $body JSON-encodable body for POST/PUT.
     * @return array The decoded JSON response.
     * @throws RuntimeException on cURL error, non-2xx status, or JSON decode failure.
     */
    private function request(string $method, string $path, ?array $body = null): array
    {
        $url = $this->apiBase . $path;
        $ch = curl_init($url);

        $headers = [
            'Authorization: Bearer ' . $this->secretKey,
            'Content-Type: application/json',
            'Accept: application/json',
            'Cache-Control: no-cache',
        ];

        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CUSTOMREQUEST => $method,
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_CONNECTTIMEOUT => 10,
        ]);

        if ($body !== null) {
            $json = json_encode($body, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
            if ($json === false) {
                throw new \RuntimeException('Failed to encode Paystack request body: ' . json_last_error_msg());
            }
            curl_setopt($ch, CURLOPT_POSTFIELDS, $json);
        }

        $raw = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlError = curl_error($ch);
        curl_close($ch);

        if ($raw === false) {
            throw new \RuntimeException('Paystack cURL error: ' . $curlError);
        }

        $decoded = json_decode($raw, true);
        if (!is_array($decoded)) {
            throw new \RuntimeException('Paystack returned non-JSON response (HTTP ' . $httpCode . ').');
        }

        if ($httpCode < 200 || $httpCode >= 300) {
            $msg = $decoded['message'] ?? 'Unknown Paystack error';
            throw new \RuntimeException('Paystack API error (HTTP ' . $httpCode . '): ' . $msg);
        }

        // Paystack wraps responses in {status: bool, message: string, data: ...}.
        // We return the whole envelope; callers extract 'data'.
        if (($decoded['status'] ?? false) === false) {
            $msg = $decoded['message'] ?? 'Paystack returned status=false';
            throw new \RuntimeException('Paystack business error: ' . $msg);
        }

        return $decoded;
    }
}
