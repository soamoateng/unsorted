<?php
declare(strict_types=1);

namespace Busifirm\Core;

/**
 * Csrf — issue + verify per-session CSRF tokens using PHP native sessions.
 *
 * Token is bound to the session id (not just the user) so anonymous endpoints
 * like /auth/login still get CSRF protection — required because login is a
 * state-changing POST.
 *
 * KISS: single token per session, rotated on session id regeneration. No
 * per-form token registry; that complexity is not warranted for this app.
 */
final class Csrf
{
    private const SESSION_KEY = '_csrf_token';

    public static function issue(): string
    {
        self::ensureSession();
        if (empty($_SESSION[self::SESSION_KEY])) {
            $_SESSION[self::SESSION_KEY] = bin2hex(random_bytes(32));
        }
        return $_SESSION[self::SESSION_KEY];
    }

    public static function verify(?string $token): bool
    {
        self::ensureSession();
        $stored = $_SESSION[self::SESSION_KEY] ?? null;
        if ($stored === null || $token === null || $token === '') {
            return false;
        }
        return hash_equals($stored, $token);
    }

    /** Rotate the token after a privilege change (e.g. login). */
    public static function rotate(): string
    {
        self::ensureSession();
        $_SESSION[self::SESSION_KEY] = bin2hex(random_bytes(32));
        return $_SESSION[self::SESSION_KEY];
    }

    private static function ensureSession(): void
    {
        if (session_status() !== PHP_SESSION_ACTIVE) {
            throw new \RuntimeException('Session must be started before using Csrf.');
        }
    }
}
