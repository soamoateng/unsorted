<?php
declare(strict_types=1);

namespace Busifirm\Core;

/**
 * Validator — tiny rule engine, no external dependency.
 *
 * KISS: this is intentionally NOT a generic validation library. It exposes
 * exactly the checks the auth flow needs. Add methods as the app grows; do not
 * try to make this into Symfony Validator.
 *
 * SOLID (SRP): each method validates one field for one rule. Compose in the
 * caller; do not build a mega-rule-engine here.
 */
final class Validator
{
    public static function email(string $value): bool
    {
        return filter_var($value, FILTER_VALIDATE_EMAIL) !== false;
    }

    /**
     * Password policy:
     *   - minimum 8 chars (matches the HTML minlength attribute in index.html)
     *   - at least one letter and one number
     *   - SEC-10 fix: maximum 72 chars (bcrypt truncates at 72 bytes; longer
     *     passwords silently lose entropy). Users who want longer passphrases
     *     should use a password manager that generates 72-char passwords.
     *
     * Intentionally NOT forcing mixed case + symbol — NIST 800-63B discourages
     * arbitrary composition rules. Length + breached-password check is the
     * modern guidance. (A haveibeenpwned lookup is a Phase 3 item; see roadmap.)
     */
    public static function password(string $value): bool
    {
        $len = strlen($value);
        if ($len < 8) return false;
        if ($len > 72) return false;  // SEC-10 fix: bcrypt truncates at 72 bytes
        if (!preg_match('/[A-Za-z]/', $value)) return false;
        if (!preg_match('/[0-9]/', $value)) return false;
        return true;
    }

    public static function role(string $value): bool
    {
        // 'admin' is intentionally NOT accepted here — admin accounts are
        // created via direct SQL, not via the public registration endpoint.
        // This prevents a malicious client from registering as admin.
        return in_array($value, ['seller', 'buyer', 'lawyer', 'broker'], true);
    }

    public static function token(string $value): bool
    {
        // tokens are 64 hex chars (32 bytes). Strict format check rejects
        // anything that could be SQL injection or path traversal.
        return (bool)preg_match('/^[0-9a-f]{64}$/', $value);
    }
}
