<?php
declare(strict_types=1);

namespace Busifirm\Core;

use Aws\S3\S3Client;
use Aws\S3\Exception\S3Exception;
use RuntimeException;

/**
 * S3Storage — S3-compatible implementation of StorageInterface.
 *
 * M5 polish (v0.8.0): production storage backend for environments where
 * the local filesystem is not suitable (multi-server, ephemeral containers,
 * compliance-mandated object storage). Compatible with:
 *   - AWS S3
 *   - MinIO (self-hosted)
 *   - DigitalOcean Spaces
 *   - Cloudflare R2
 *   - Backblaze B2 (S3-compatible API)
 *   - Wasabi
 *
 * Configuration (via .env):
 *   S3_KEY, S3_SECRET, S3_REGION, S3_BUCKET, S3_ENDPOINT (optional — for
 *   non-AWS providers), S3_PATH_PREFIX (optional — for sharing a bucket).
 *
 * KISS trade-off: this is the FIRST non-dev Composer dependency in the
 * project. Justified because:
 *   1. SigV4 request signing is ~200 LOC of fiddly cryptography. Rolling
 *      our own is high-risk for security bugs.
 *   2. The AWS SDK is well-maintained, has stable interfaces, and supports
 *      every S3-compatible provider via the `endpoint` config.
 *   3. The alternative (direct cURL + SigV4) would be a maintenance burden
 *      that contradicts the project's KISS principle.
 *
 * SOLID (SRP): this class ONLY talks to S3. Same SRP as LocalStorage.
 *
 * Path semantics: objects are stored at {path_prefix}/{user_id}/{stored_filename}.
 * Chunks are stored at {path_prefix}/chunks/{upload_id}/{index}.chunk — but
 * chunked uploads to S3 use multipart upload in a future iteration. For now,
 * chunks are stored as individual objects and assembled via GetObject +
 * PutObject (works but is not optimal — Phase 4+ will switch to S3 multipart).
 *
 * Streaming: stream() uses the SDK's stream wrapper or a streamed GetObject
 * response to avoid loading large files into memory.
 */
final class S3Storage implements StorageInterface
{
    private readonly S3Client $client;
    private readonly string $bucket;
    private readonly string $prefix;

    public function __construct()
    {
        if (!class_exists(S3Client::class)) {
            throw new RuntimeException(
                'S3Storage requires the aws/aws-sdk-php Composer package. Run "composer require aws/aws-sdk-php".'
            );
        }
        $key = Config::get('S3_KEY', '');
        $secret = Config::get('S3_SECRET', '');
        $region = Config::get('S3_REGION', 'us-east-1');
        $bucket = Config::get('S3_BUCKET', '');
        $endpoint = Config::get('S3_ENDPOINT', '');
        $prefix = Config::get('S3_PATH_PREFIX', '');
        if ($key === '' || $secret === '' || $bucket === '') {
            throw new RuntimeException(
                'S3Storage requires S3_KEY, S3_SECRET, and S3_BUCKET in .env.'
            );
        }
        $this->bucket = $bucket;
        $this->prefix = $prefix === '' ? '' : trim($prefix, '/');

        $config = [
            'version' => 'latest',
            'region' => $region,
            'credentials' => ['key' => $key, 'secret' => $secret],
        ];
        if ($endpoint !== '') {
            $config['endpoint'] = $endpoint;
            // Required for non-AWS providers (MinIO, DigitalOcean, etc.).
            $config['use_path_style_endpoint'] = (bool)Config::getBool('S3_PATH_STYLE', false);
        }
        $this->client = new S3Client($config);
    }

    private function keyFor(string $userId, string $storedFilename): string
    {
        $base = $this->prefix === '' ? '' : $this->prefix . '/';
        return $base . $userId . '/' . basename($storedFilename);
    }

    private function chunkKey(string $uploadId, int $index): string
    {
        $base = $this->prefix === '' ? '' : $this->prefix . '/';
        return $base . 'chunks/' . $uploadId . '/' . sprintf('%08d', $index) . '.chunk';
    }

    public function save(string $userId, string $storedFilename, string $tmpPath): string
    {
        if (!is_uploaded_file($tmpPath)) {
            throw new RuntimeException('Not an uploaded file: ' . $tmpPath);
        }
        $key = $this->keyFor($userId, $storedFilename);
        try {
            $this->client->putObject([
                'Bucket' => $this->bucket,
                'Key' => $key,
                'SourceFile' => $tmpPath,
                'ContentType' => mime_content_type($tmpPath) ?: 'application/octet-stream',
            ]);
        } catch (S3Exception $e) {
            throw new RuntimeException('S3 putObject failed: ' . $e->getMessage(), 0, $e);
        }
        return $key;
    }

    public function stream(string $userId, string $storedFilename): bool
    {
        $key = $this->keyFor($userId, $storedFilename);
        try {
            // PHP-055 fix: the old code used the SDK's stream wrapper (s3:// URL)
            // which registers a GLOBAL default client — fragile if multiple S3Storage
            // instances exist with different credentials. Also, @fopen suppressed
            // errors so "wrapper not registered" was indistinguishable from "object
            // missing". Now we use GetObject with a stream context, which is
            // instance-scoped (no global state) and gives us proper error handling.
            $result = $this->client->getObject([
                'Bucket' => $this->bucket,
                'Key' => $key,
            ]);
            $body = $result->get('Body');
            if ($body === null) return false;
            // Stream the body to php://output in 64KB chunks.
            while (!$body->eof()) {
                $chunk = $body->read(65536);
                if ($chunk === '') break;
                echo $chunk;
            }
            return true;
        } catch (S3Exception $e) {
            error_log('[busifirm] S3 stream failed for key ' . $key . ': ' . $e->getMessage());
            return false;
        } catch (\Throwable $e) {
            // Catch-all for non-S3 errors (e.g. network timeouts).
            error_log('[busifirm] S3 stream unexpected error for key ' . $key . ': ' . $e->getMessage());
            return false;
        }
    }

    public function exists(string $userId, string $storedFilename): bool
    {
        $key = $this->keyFor($userId, $storedFilename);
        return $this->client->doesObjectExist($this->bucket, $key);
    }

    public function size(string $userId, string $storedFilename): int
    {
        $key = $this->keyFor($userId, $storedFilename);
        try {
            $result = $this->client->headObject([
                'Bucket' => $this->bucket,
                'Key' => $key,
            ]);
            return (int)($result['ContentLength'] ?? 0);
        } catch (S3Exception $e) {
            return 0;
        }
    }

    public function delete(string $userId, string $storedFilename): bool
    {
        $key = $this->keyFor($userId, $storedFilename);
        try {
            $this->client->deleteObject([
                'Bucket' => $this->bucket,
                'Key' => $key,
            ]);
            return true;
        } catch (S3Exception $e) {
            return false;
        }
    }

    public function saveChunk(string $uploadId, int $index, string $tmpPath): string
    {
        if (!is_uploaded_file($tmpPath)) {
            throw new RuntimeException('Not an uploaded chunk: ' . $tmpPath);
        }
        $key = $this->chunkKey($uploadId, $index);
        try {
            $this->client->putObject([
                'Bucket' => $this->bucket,
                'Key' => $key,
                'SourceFile' => $tmpPath,
            ]);
        } catch (S3Exception $e) {
            throw new RuntimeException('S3 putObject (chunk) failed: ' . $e->getMessage(), 0, $e);
        }
        return $key;
    }

    public function assembleChunks(string $userId, string $storedFilename, string $uploadId, int $totalChunks): string
    {
        // KISS: download each chunk to a tmp file, concatenate to a final
        // tmp file, then putObject to the final key. This is NOT optimal
        // for very large files — Phase 4+ should switch to S3 multipart
        // upload (CreateMultipartUpload → UploadPart → CompleteMultipartUpload).
        $finalKey = $this->keyFor($userId, $storedFilename);
        $tmpFinal = tempnam(sys_get_temp_dir(), 'busifirm_s3_assemble_');
        if ($tmpFinal === false) {
            throw new RuntimeException('Failed to create temp file for S3 assembly.');
        }
        $out = fopen($tmpFinal, 'wb');
        if ($out === false) {
            @unlink($tmpFinal);
            throw new RuntimeException('Failed to open temp file for write: ' . $tmpFinal);
        }
        try {
            for ($i = 0; $i < $totalChunks; $i++) {
                $chunkKey = $this->chunkKey($uploadId, $i);
                try {
                    $body = $this->client->getObject([
                        'Bucket' => $this->bucket,
                        'Key' => $chunkKey,
                    ])->get('Body');
                    $body->rewind();
                    while (!$body->eof()) {
                        fwrite($out, $body->read(65536));
                    }
                } catch (S3Exception $e) {
                    throw new RuntimeException('S3 chunk ' . $i . ' missing: ' . $e->getMessage(), 0, $e);
                }
            }
        } finally {
            fclose($out);
        }
        try {
            $this->client->putObject([
                'Bucket' => $this->bucket,
                'Key' => $finalKey,
                'SourceFile' => $tmpFinal,
            ]);
        } finally {
            @unlink($tmpFinal);
        }
        // Best-effort cleanup of chunk objects.
        for ($i = 0; $i < $totalChunks; $i++) {
            try {
                $this->client->deleteObject([
                    'Bucket' => $this->bucket,
                    'Key' => $this->chunkKey($uploadId, $i),
                ]);
            } catch (S3Exception $e) { /* ignore */ }
        }
        return $finalKey;
    }

    public function abortChunkedUpload(string $uploadId): void
    {
        // List all chunk objects for this uploadId and delete them.
        $prefix = ($this->prefix === '' ? '' : $this->prefix . '/') . 'chunks/' . $uploadId . '/';
        try {
            $results = $this->client->getIterator('ListObjects', [
                'Bucket' => $this->bucket,
                'Prefix' => $prefix,
            ]);
            foreach ($results as $obj) {
                $this->client->deleteObject([
                    'Bucket' => $this->bucket,
                    'Key' => $obj['Key'],
                ]);
            }
        } catch (S3Exception $e) {
            // Best-effort.
        }
    }

    public function chunkExists(string $uploadId, int $index): bool
    {
        return $this->client->doesObjectExist($this->bucket, $this->chunkKey($uploadId, $index));
    }
}
