<?php
declare(strict_types=1);

namespace Busifirm\Core;

/**
 * Mailer — minimal interface for sending transactional email.
 *
 * Phase 1: uses PHP mail() — fine for dev, NOT for production. Clearly marked.
 * Phase 3: swap implementation to SMTP (Sendgrid/Postmark). The interface
 * stays the same so no controller or service code changes.
 *
 * KISS / SOLID (DIP): callers depend on this interface, not on mail() or any
 * SMTP library directly. The implementation is swappable without touching
 * UserService or AuthController.
 */
interface Mailer
{
    /**
     * Send a transactional email.
     *
     * @param string      $to      Recipient email address.
     * @param string      $subject Subject line (plain text, no HTML).
     * @param string      $body    Plain-text body.
     * @param array       $headers Optional associative headers (e.g. ['Reply-To' => '...']).
     */
    public function send(string $to, string $subject, string $body, array $headers = []): bool;
}

/**
 * NativePhpMailer — Phase 1 dev/local implementation.
 *
 * WARNING: PHP mail() is unsuitable for production transactional email.
 * Replace with SmtpMailer in Phase 3 (roadmap). Do not delete this class —
 * keep it as a dev fallback / test double.
 *
 * OTH-05 fix: added a production guard. If APP_ENV is 'production' and
 * MAIL_ALLOW_NATIVE is not 'true', the constructor throws to prevent
 * silent use of mail() in production.
 */
final class NativePhpMailer implements Mailer
{
    public function __construct()
    {
        // OTH-05 fix: fail-fast in production unless explicitly overridden.
        // Blind-spot fix: wrapped in a log-only warning instead of throwing,
        // because throwing would break ALL API calls (NativePhpMailer is
        // instantiated in the front controller for every request). The
        // warning is logged so the sysadmin knows to configure SMTP.
        if (Config::get('APP_ENV', 'development') === 'production'
            && !Config::getBool('MAIL_ALLOW_NATIVE', false)) {
            error_log(
                '[busifirm] WARNING: NativePhpMailer (PHP mail()) is being used in production. '
                . 'This is unsuitable for transactional email. Configure an SMTP mailer or set MAIL_ALLOW_NATIVE=true to suppress this warning.'
            );
        }
    }

    public function send(string $to, string $subject, string $body, array $headers = []): bool
    {
        $fromEmail = Config::get('MAIL_FROM', 'no-reply@busifirm.com');
        $fromName = Config::get('MAIL_FROM_NAME', 'Busifirm');

        $headerLines = [
            "From: {$fromName} <{$fromEmail}>",
            'MIME-Version: 1.0',
            'Content-Type: text/plain; charset=utf-8',
            // OTH-06 fix: explicitly set Content-Transfer-Encoding to base64
            // for non-ASCII body content. The old '8bit' encoding garbled
            // non-ASCII characters (e.g., user names with accents) in older
            // email clients. Base64 is universally supported.
            'Content-Transfer-Encoding: base64',
        ];
        // SEC-04 fix: filter header values to prevent header injection.
        // Strip CR/LF from both keys and values — an attacker passing
        // "Bcc: evil@x.com\r\n" as a header value could inject recipients.
        foreach ($headers as $k => $v) {
            $cleanKey = str_replace(["\r", "\n", ':'], '', $k);
            $cleanVal = str_replace(["\r", "\n"], '', (string)$v);
            // Block known dangerous headers that could be used for injection.
            $lowerKey = strtolower($cleanKey);
            if (in_array($lowerKey, ['bcc', 'cc', 'to', 'from'], true) && $lowerKey !== 'from') {
                continue; // Skip BCC/CC/TO — only the caller's From is allowed
            }
            $headerLines[] = "{$cleanKey}: {$cleanVal}";
        }
        $headerStr = implode("\r\n", $headerLines);

        // OTH-06 fix: base64-encode the body to match the Content-Transfer-Encoding header.
        $encodedBody = base64_encode($body);
        // Chunk_split ensures the base64 output respects RFC 2045 line length limits.
        $encodedBody = chunk_split($encodedBody);

        // SEC-05 fix: check the return value of mail() and log if it fails.
        // The old code used @mail() which silently suppressed errors.
        $result = mail($to, '=?UTF-8?B?' . base64_encode($subject) . '?=', $encodedBody, $headerStr);
        if ($result === false) {
            error_log('[busifirm] mail() failed for recipient: ' . $to);
        }
        return $result;
    }
}
