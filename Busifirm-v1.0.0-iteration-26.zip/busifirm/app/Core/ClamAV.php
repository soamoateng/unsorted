<?php
declare(strict_types=1);

namespace Busifirm\Core;

use RuntimeException;

/**
 * ClamAV — virus scanner integration via the clamd INSTREAM protocol.
 *
 * M5 polish (v0.8.0): defense-in-depth layer for the document upload
 * pipeline. DocumentService calls ClamAV::scan() on the tmp file BEFORE
 * moving it to Storage. Infected files are rejected with a 422 response.
 *
 * Architecture:
 *   - ClamAV runs as a daemon (`clamd`) listening on a Unix socket or TCP
 *     port. We connect, send the file via the INSTREAM command, and read
 *     the scan response. No shell-out to the `clamscan` CLI — that would
 *     fork a fresh process per scan and be ~10x slower.
 *   - The daemon is expected to be installed separately (`apt install
 *     clamav-daemon` on Debian/Ubuntu). This class does NOT manage the
 *     daemon lifecycle.
 *
 * Configuration (via .env):
 *   - CLAMAV_ENABLED (default false). When false, scan() returns
 *     ['status' => 'skipped'] without touching the network. This lets
 *     dev environments run without ClamAV installed.
 *   - CLAMAV_SOCKET (default /var/run/clamav/clamd.ctl). Unix socket path.
 *     If empty, falls back to TCP via CLAMAV_HOST + CLAMAV_PORT.
 *   - CLAMAV_HOST, CLAMAV_PORT (default 127.0.0.1:3310). TCP fallback.
 *   - CLAMAV_TIMEOUT (default 30). Per-scan socket timeout in seconds.
 *   - CLAMAV_MAX_SIZE_MB (default 50). Files larger than this are scanned
 *     but logged — ClamAV has its own internal limit (StreamMaxLength in
 *     clamd.conf, default 25MB). Override CLAMAV_MAX_SIZE_MB to match.
 *
 * SOLID (SRP): this class ONLY talks to clamd. It does not enforce the
 * MIME whitelist, compute hashes, or write to the documents table.
 *
 * Protocol reference: https://docs.clamav.net/manual/OnInstall.html
 * (search "INSTREAM"). We send:
 *   "zINSTREAM\0" (or "nINSTREAM\n" — we use the null-terminated form)
 *   <4-byte big-endian chunk length><chunk bytes>
 *   ... repeat ...
 *   <4-byte zero-length chunk> (terminator)
 * Response: "stream: OK\0" or "stream: <VIRUSNAME>\0".
 */
final class ClamAV
{
    /** @var resource|null */
    private $socket = null;

    /**
     * Scan a file. Returns an array with:
     *   - status: 'clean' | 'infected' | 'skipped' | 'failed'
     *   - message: ClamAV response string or error message.
     *
     * @param string $filePath Path to the file to scan (typically $_FILES['x']['tmp_name']).
     * @return array{status: string, message: string}
     */
    public function scan(string $filePath): array
    {
        if (!Config::getBool('CLAMAV_ENABLED', false)) {
            return ['status' => 'skipped', 'message' => 'ClamAV disabled by CLAMAV_ENABLED=false.'];
        }
        if (!is_file($filePath) || !is_readable($filePath)) {
            return ['status' => 'failed', 'message' => 'File not readable: ' . $filePath];
        }
        $size = filesize($filePath);
        if ($size === false) {
            return ['status' => 'failed', 'message' => 'Could not determine file size.'];
        }
        $maxSize = Config::getInt('CLAMAV_MAX_SIZE_MB', 50) * 1024 * 1024;
        if ($size > $maxSize) {
            // ClamAV would reject the file anyway. We skip to avoid a false
            // 'failed' status — but the caller may want to reject large
            // files in DocumentService independently.
            return [
                'status' => 'skipped',
                'message' => 'File exceeds CLAMAV_MAX_SIZE_MB (' . Config::getInt('CLAMAV_MAX_SIZE_MB', 50) . 'MB).',
            ];
        }

        try {
            $this->connect();
            $this->sendCommand('zINSTREAM');
            $this->streamFile($filePath);
            $response = $this->readResponse();
            $this->disconnect();
        } catch (\Throwable $e) {
            $this->disconnect();
            return ['status' => 'failed', 'message' => 'ClamAV scan error: ' . $e->getMessage()];
        }

        // Response format: "stream: OK\0" or "stream: <VIRUSNAME>\0".
        $response = trim($response, "\0\r\n ");
        if (preg_match('/^stream:\s+OK$/i', $response)) {
            return ['status' => 'clean', 'message' => $response];
        }
        if (preg_match('/^stream:\s+(.+)$/i', $response, $m)) {
            return ['status' => 'infected', 'message' => $m[1]];
        }
        return ['status' => 'failed', 'message' => 'Unexpected ClamAV response: ' . $response];
    }

    private function connect(): void
    {
        $timeout = Config::getInt('CLAMAV_TIMEOUT', 30);
        $socketPath = Config::get('CLAMAV_SOCKET', '/var/run/clamav/clamd.ctl');
        if ($socketPath !== '') {
            $sock = @stream_socket_client('unix://' . $socketPath, $errno, $errstr, $timeout);
            if ($sock === false) {
                throw new RuntimeException("Cannot connect to clamd socket $socketPath: $errstr ($errno)");
            }
        } else {
            $host = Config::get('CLAMAV_HOST', '127.0.0.1');
            $port = Config::getInt('CLAMAV_PORT', 3310);
            $sock = @stream_socket_client("tcp://$host:$port", $errno, $errstr, $timeout);
            if ($sock === false) {
                throw new RuntimeException("Cannot connect to clamd TCP $host:$port: $errstr ($errno)");
            }
        }
        stream_set_timeout($sock, $timeout);
        $this->socket = $sock;
    }

    private function sendCommand(string $cmd): void
    {
        // z-prefix = null-terminated command.
        $cmd .= "\0";
        $written = fwrite($this->socket, $cmd);
        if ($written === false || $written !== strlen($cmd)) {
            throw new RuntimeException('Failed to send command to clamd.');
        }
    }

    private function streamFile(string $filePath): void
    {
        $in = fopen($filePath, 'rb');
        if ($in === false) {
            throw new RuntimeException('Failed to open file for ClamAV streaming: ' . $filePath);
        }
        try {
            while (!feof($in)) {
                $chunk = fread($in, 65536);
                if ($chunk === false || $chunk === '') break;
                $len = pack('N', strlen($chunk));  // 4-byte big-endian
                fwrite($this->socket, $len . $chunk);
            }
            // Terminating zero-length chunk.
            fwrite($this->socket, pack('N', 0));
        } finally {
            fclose($in);
        }
    }

    private function readResponse(): string
    {
        $response = '';
        while (!feof($this->socket)) {
            $buf = fread($this->socket, 4096);
            if ($buf === false) break;
            $response .= $buf;
            // Response ends with a null byte.
            if (str_contains($response, "\0")) break;
        }
        return $response;
    }

    private function disconnect(): void
    {
        if ($this->socket !== null) {
            @fclose($this->socket);
            $this->socket = null;
        }
    }
}
