<?php
declare(strict_types=1);

namespace Busifirm\Services;

use Busifirm\Core\Database;

/**
 * AuditService — read-side accessor over the audit_log table (M1 wrote the rows).
 *
 * KISS: read-only for now. The M1 UserService::audit() private method does the
 * writing. Phase 3 will extract that into this service so controllers and
 * background jobs can write audit events too.
 */
final class AuditService
{
    public function listForUser(string $userId, int $limit = 200): array
    {
        $rows = Database::run(
            'SELECT id, user_id, action, metadata, ip_hash, user_agent_hash, created_at
             FROM audit_log
             WHERE user_id = ?
             ORDER BY created_at DESC
             LIMIT ?',
            [$userId, $limit]
        )->fetchAll();
        return array_map(fn($r) => [
            'id' => $r['id'],
            'userId' => $r['user_id'],
            'action' => $r['action'],
            'details' => json_decode($r['metadata'] ?? '{}', true) ?: [],
            'ipHash' => $r['ip_hash'],
            'userAgentHash' => $r['user_agent_hash'],
            'timestamp' => date(DATE_ATOM, strtotime($r['created_at'])),
        ], $rows);
    }

    /**
     * Write an audit event from an authenticated user. Intentionally separate
     * from UserService::audit() (which is for auth-flow events that need
     * ip_hash + user_agent_hash). This public method is for domain events
     * (listing saved, deal updated, etc.) called from other services.
     *
     * For now it uses the same shape — ip_hash + user_agent_hash are derived
     * from the request. Phase 3 will refactor into a unified writer.
     */
    public function log(string $userId, string $action, array $details, string $ip, string $userAgent): void
    {
        $id = $this->uuid();
        Database::run(
            'INSERT INTO audit_log (id, session_id, user_id, action, metadata, ip_hash, user_agent_hash, created_at)
             VALUES (?, NULL, ?, ?, ?, ?, ?, NOW())',
            [
                $id,
                $userId,
                $action,
                json_encode($details, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
                hash('sha256', $ip),
                hash('sha256', $userAgent),
            ]
        );
    }

    private function uuid(): string
    {
        $bytes = random_bytes(16);
        $bytes[6] = chr((ord($bytes[6]) & 0x0f) | 0x40);
        $bytes[8] = chr((ord($bytes[8]) & 0x3f) | 0x80);
        return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($bytes), 4));
    }
}
