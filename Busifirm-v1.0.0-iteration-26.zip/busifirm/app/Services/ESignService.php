<?php
declare(strict_types=1);

namespace Busifirm\Services;

use Busifirm\Core\Database;
use Busifirm\Core\Role;
use RuntimeException;

/**
 * ESignService — e-signature documents (pending signature queue).
 *
 * KISS: audit_trail is a JSON column. parties is a JSON column. No separate
 * esign_events table until we need server-side queries on events.
 *
 * M3 RBAC:
 *   - save() (create/update document metadata): any role, owner-only.
 *   - signDocument() (owner signs own document): any role, owner-only.
 *     (The owner sign action is handled via save() with status='signed' +
 *     signedAt set; no separate method needed for the owner-sign flow.)
 *   - witnessSign() (lawyer co-signs as witness): lawyer-only, can sign any
 *     document. A lawyer cannot witness their own document (conflict of
 *     interest). A document can have at most one witness.
 */
final class ESignService
{
    public function listForUser(string $userId): array
    {
        $rows = Database::run(
            'SELECT id, user_id, title, document_id, status, parties, audit_trail,
                    signed_at, witness_id, witness_signed_at, witness_email,
                    created_at, updated_at
             FROM esigns
             WHERE user_id = ?
             ORDER BY created_at DESC',
            [$userId]
        )->fetchAll();
        return array_map(fn($r) => $this->rowToDto($r), $rows);
    }

    /**
     * List all esigns that a lawyer may witness-sign (i.e. documents owned
     * by other users that don't yet have a witness). Used by the lawyer UI
     * to find documents awaiting witness signature.
     */
    public function listAwaitingWitness(string $lawyerUserId): array
    {
        $rows = Database::run(
            'SELECT id, user_id, title, document_id, status, parties, audit_trail,
                    signed_at, witness_id, witness_signed_at, witness_email,
                    created_at, updated_at
             FROM esigns
             WHERE user_id <> ? AND witness_id IS NULL
             ORDER BY created_at DESC',
            [$lawyerUserId]
        )->fetchAll();
        return array_map(fn($r) => $this->rowToDto($r), $rows);
    }

    public function save(string $userId, array $doc): array
    {
        $id = $doc['id'] ?? null;
        $isNew = $id === null || $id === '';

        // M5: optional document_id — if provided, validate ownership.
        $documentId = null;
        if (isset($doc['documentId']) && $doc['documentId'] !== '' && $doc['documentId'] !== null) {
            $documentId = (string)$doc['documentId'];
            $docRow = Database::run(
                'SELECT id FROM documents WHERE id = ? AND user_id = ? AND deleted_at IS NULL LIMIT 1',
                [$documentId, $userId]
            )->fetch();
            if ($docRow === false) {
                throw new RuntimeException('Attached document not found or not owned by you.');
            }
        }

        if ($isNew) {
            $id = $this->uuid();
            Database::run(
                'INSERT INTO esigns (id, user_id, title, document_id, status, parties, audit_trail, signed_at, created_at, updated_at)
                 VALUES (?, ?, ?, ?, ?, ?, ?, NULL, NOW(), NOW())',
                [
                    $id, $userId,
                    (string)$doc['title'],
                    $documentId,
                    (string)($doc['status'] ?? 'pending'),
                    json_encode(array_map('strval', $doc['parties'] ?? []), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),  // PHP-041 fix: added JSON_UNESCAPED_SLASHES for consistency with witnessSign
                    json_encode($doc['auditTrail'] ?? [], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),  // PHP-041 fix: added JSON_UNESCAPED_SLASHES for consistency with witnessSign
                ]
            );
        } else {
            $existing = Database::run(
                'SELECT user_id FROM esigns WHERE id = ? LIMIT 1',
                [$id]
            )->fetch();
            if ($existing === false) {
                throw new RuntimeException('Document not found.');
            }
            if ($existing['user_id'] !== $userId) {
                throw new RuntimeException('You do not have permission to edit this document.');
            }
            Database::run(
                'UPDATE esigns
                 SET title = ?, document_id = ?, status = ?, parties = ?, audit_trail = ?, signed_at = ?, updated_at = NOW()
                 WHERE id = ?',
                [
                    (string)$doc['title'],
                    $documentId,
                    (string)($doc['status'] ?? 'pending'),
                    json_encode(array_map('strval', $doc['parties'] ?? []), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),  // PHP-041 fix: added JSON_UNESCAPED_SLASHES for consistency with witnessSign
                    json_encode($doc['auditTrail'] ?? [], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),  // PHP-041 fix: added JSON_UNESCAPED_SLASHES for consistency with witnessSign
                    isset($doc['signedAt']) ? date('Y-m-d H:i:s', strtotime($doc['signedAt'])) : null,
                    $id,
                ]
            );
        }
        $row = Database::run(
            'SELECT id, user_id, title, document_id, status, parties, audit_trail,
                    signed_at, witness_id, witness_signed_at, witness_email,
                    created_at, updated_at
             FROM esigns WHERE id = ? LIMIT 1',
            [$id]
        )->fetch();
        return $this->rowToDto($row);
    }

    /**
     * M3 RBAC: lawyer co-signs a document as a witness.
     *
     * Rules:
     *   - Caller role must be 'lawyer' (canSignAsWitness()).
     *   - Document must exist.
     *   - Document must not already have a witness (idempotency: re-witness
     *     is rejected with a clear error).
     *   - Lawyer cannot witness their own document (conflict of interest).
     *
     * @param string $docId        The document to witness-sign.
     * @param string $lawyerUserId The lawyer's user id.
     * @param string $lawyerEmail  The lawyer's email (denormalized for display).
     * @param string $role         The lawyer's role string ('lawyer' expected).
     *
     * @throws RuntimeException on any rule violation.
     */
    public function witnessSign(string $docId, string $lawyerUserId, string $lawyerEmail, string $role): array
    {
        $roleEnum = Role::fromString($role);
        if ($roleEnum === null || !$roleEnum->canSignAsWitness()) {
            throw new RuntimeException(
                'Your role (' . $role . ') cannot sign as a witness. Only licensed lawyers can.'
            );
        }

        // PHP-003 fix: wrap the read-check-update in a transaction with
        // SELECT ... FOR UPDATE to prevent the TOCTOU race where two lawyers
        // both read witness_id IS NULL, both pass the check, and both UPDATE.
        // The second UPDATE would overwrite the first lawyer's witness_id and
        // the first lawyer's audit-trail entry would be lost (overwritten by
        // the second's append from the stale read).
        $pdo = Database::connect();
        $pdo->beginTransaction();
        try {
            $existing = Database::run(
                'SELECT id, user_id, status, witness_id, audit_trail
                 FROM esigns
                 WHERE id = ?
                 LIMIT 1
                 FOR UPDATE',
                [$docId]
            )->fetch();
            if ($existing === false) {
                $pdo->rollBack();
                throw new RuntimeException('Document not found.');
            }
            // BL-28 fix: check the document is in a signable state. A 'draft' or
            // 'cancelled' document should not be witness-signable.
            $status = $existing['status'] ?? 'pending';
            if ($status === 'draft') {
                $pdo->rollBack();
                throw new RuntimeException('This document is still in draft status. The owner must finalize it before witness signing.');
            }
            if ($status === 'cancelled') {
                $pdo->rollBack();
                throw new RuntimeException('This document has been cancelled and cannot be witness-signed.');
            }
            if ($existing['user_id'] === $lawyerUserId) {
                $pdo->rollBack();
                throw new RuntimeException('You cannot witness-sign your own document.');
            }
            if ($existing['witness_id'] !== null) {
                $pdo->rollBack();
                throw new RuntimeException('This document has already been witness-signed.');
            }

            $audit = json_decode($existing['audit_trail'] ?? '[]', true) ?: [];
            $audit[] = [
                'action' => 'Witness signature applied',
                'timestamp' => date(DATE_ATOM),
                'by' => $lawyerEmail,
            ];

            // PHP-003 defense-in-depth: the UPDATE includes `AND witness_id IS NULL`
            // so even if the FOR UPDATE lock somehow doesn't serialize (e.g. a
            // different connection reads stale data before the lock), the UPDATE
            // is a no-op if another lawyer already claimed the witness slot.
            // Check rowCount() to detect this.
            $stmt = $pdo->prepare(
                'UPDATE esigns
                 SET witness_id = ?, witness_signed_at = NOW(), witness_email = ?,
                     audit_trail = ?, updated_at = NOW()
                 WHERE id = ? AND witness_id IS NULL'
            );
            $stmt->execute([
                $lawyerUserId,
                $lawyerEmail,
                json_encode($audit, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
                $docId,
            ]);
            if ($stmt->rowCount() === 0) {
                // Another lawyer beat us to it between the SELECT and the UPDATE.
                $pdo->rollBack();
                throw new RuntimeException('This document has already been witness-signed.');
            }

            $pdo->commit();
        } catch (RuntimeException $e) {
            // Already rolled back above; re-throw.
            throw $e;
        } catch (\Throwable $e) {
            $pdo->rollBack();
            throw $e;
        }

        $row = Database::run(
            'SELECT id, user_id, title, document_id, status, parties, audit_trail,
                    signed_at, witness_id, witness_signed_at, witness_email,
                    created_at, updated_at
             FROM esigns WHERE id = ? LIMIT 1',
            [$docId]
        )->fetch();
        return $this->rowToDto($row);
    }

    private function rowToDto(array $r): array
    {
        return [
            'id' => $r['id'],
            'userId' => $r['user_id'],
            'title' => $r['title'],
            'documentId' => $r['document_id'] ?? null,
            'status' => $r['status'],
            'parties' => json_decode($r['parties'] ?? '[]', true) ?: [],
            'auditTrail' => json_decode($r['audit_trail'] ?? '[]', true) ?: [],
            'signedAt' => $r['signed_at'] !== null ? date(DATE_ATOM, strtotime($r['signed_at'])) : null,
            'witnessId' => $r['witness_id'] ?? null,
            'witnessSignedAt' => $r['witness_signed_at'] !== null ? date(DATE_ATOM, strtotime($r['witness_signed_at'])) : null,
            'witnessEmail' => $r['witness_email'] ?? null,
            'createdAt' => date(DATE_ATOM, strtotime($r['created_at'])),
            'updatedAt' => date(DATE_ATOM, strtotime($r['updated_at'])),
        ];
    }

    private function uuid(): string
    {
        $bytes = random_bytes(16);
        $bytes[6] = chr((ord($bytes[6]) & 0x0f) | 0x40);
        $bytes[8] = chr((ord($bytes[8]) & 0x3f) | 0x80);
        return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($bytes), 4));
    }
}
