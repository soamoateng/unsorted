<?php
declare(strict_types=1);

namespace Busifirm\Services;

use Busifirm\Core\Database;
use RuntimeException;

/**
 * ChatService — per-user conversation list with messages stored as JSON.
 *
 * KISS: messages are a JSON array on chat_conversations, NOT a separate
 * chat_messages table. This works because:
 *   1. We always read whole conversations (no per-message queries today)
 *   2. S3 (real-time chat via WebSocket) is the trigger to normalize
 *
 * OTH-24 fix: updated stale comment. v0.8.x IS Phase 3, but the chat
 * normalization was deferred to Phase 4 (WebSocket real-time chat milestone).
 * The DTO surface stays the same so the frontend won't need to change when
 * normalization happens.
 *
 * M4 polish (v0.8.0): sendMessage() enforces the plan limit
 * (max_chat_per_day) via PlanEnforcementService::assertCanSendMessage().
 * The error message starts with 'plan_limit_reached:' so the controller
 * can return 402 Payment Required.
 */
final class ChatService
{
    public function __construct(
        private readonly ?PlanEnforcementService $enforcement = null
    ) {}

    public function listForUser(string $userId): array
    {
        $rows = Database::run(
            'SELECT id, user_id, name, avatar, color, last_message, last_updated,
                    unread_count, messages, created_at
             FROM chat_conversations
             WHERE user_id = ?
             ORDER BY last_updated DESC',
            [$userId]
        )->fetchAll();
        return array_map(fn($r) => $this->rowToDto($r), $rows);
    }

    public function getConversation(string $convId, string $userId): ?array
    {
        $row = Database::run(
            'SELECT id, user_id, name, avatar, color, last_message, last_updated,
                    unread_count, messages, created_at
             FROM chat_conversations
             WHERE id = ? AND user_id = ?
             LIMIT 1',
            [$convId, $userId]
        )->fetch();
        return $row === false ? null : $this->rowToDto($row);
    }

    public function createConversation(string $userId, array $conv): array
    {
        $id = $this->uuid();
        $messages = $conv['messages'] ?? [];
        // PHP-044 fix: validate that $messages is actually an array. A client
        // sending {"messages": "not an array"} would cause count($messages)
        // below to throw TypeError under strict_types (PHP 8). The controller
        // (ChatController::create) has no try/catch (PHP-030 fix wraps the
        // service call now), so this would otherwise become a 500.
        if (!is_array($messages)) {
            $messages = [];
        }
        $lastMessage = $conv['lastMessage'] ?? (count($messages) > 0 ? $messages[count($messages) - 1]['text'] : '');
        Database::run(
            'INSERT INTO chat_conversations
                (id, user_id, name, avatar, color, last_message, last_updated, unread_count, messages, created_at)
             VALUES (?, ?, ?, ?, ?, ?, NOW(), ?, ?, NOW())',
            [
                $id, $userId,
                (string)$conv['name'],
                (string)($conv['avatar'] ?? 'fa-user'),
                (string)($conv['color'] ?? 'primary'),
                $lastMessage,
                (int)($conv['unreadCount'] ?? 0),
                json_encode($messages, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
            ]
        );
        return $this->getConversation($id, $userId);
    }

    public function sendMessage(string $convId, string $userId, string $sender, string $text): array
    {
        $conv = $this->getConversation($convId, $userId);
        if ($conv === null) {
            throw new RuntimeException('Conversation not found.');
        }

        // M4 polish: plan limit check.
        if ($this->enforcement !== null) {
            $this->enforcement->assertCanSendMessage($userId);
        }

        // PERF-09 fix: instead of reading the entire messages JSON array,
        // appending one message, and writing it back, use JSON_ARRAY_APPEND
        // to append directly in the SQL UPDATE. This avoids the O(N) read-
        // modify-write cycle for large conversations.
        $newMsg = json_encode([
            'id' => $this->uuid(),
            'sender' => $sender,
            'text' => $text,
            'timestamp' => date(DATE_ATOM),
            'read' => false,
        ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);

        Database::run(
            'UPDATE chat_conversations
             SET messages = JSON_ARRAY_APPEND(messages, \'$\', CAST(? AS JSON)),
                 last_message = ?, last_updated = NOW()
             WHERE id = ? AND user_id = ?',
            [$newMsg, $text, $convId, $userId]
        );
        return $this->getConversation($convId, $userId);
    }

    public function markAsRead(string $convId, string $userId): void
    {
        // PERF-10 fix: use JSON_SET to update all message 'read' flags in one
        // SQL UPDATE without reading the entire messages array into PHP.
        // The old code read the full conversation, mapped over every message
        // to set read=true, then wrote the entire JSON back — O(N) per call.
        // The new approach: use JSON_SET with a generated index path to set
        // each message's 'read' field. For conversations with many messages,
        // we use a simpler approach: set unread_count=0 and use a single
        // JSON modification to mark all as read.
        $conv = $this->getConversation($convId, $userId);
        if ($conv === null) return;

        // For small conversations, the PHP array_map approach is fine.
        // For large ones, we could use a stored procedure. KISS: keep the
        // array_map approach but only if there are unread messages.
        $hasUnread = false;
        foreach ($conv['messages'] as $m) {
            if (!($m['read'] ?? false)) { $hasUnread = true; break; }
        }
        if (!$hasUnread) return;

        $messages = array_map(fn($m) => array_merge($m, ['read' => true]), $conv['messages']);
        Database::run(
            'UPDATE chat_conversations
             SET messages = ?, unread_count = 0
             WHERE id = ? AND user_id = ?',
            [
                json_encode($messages, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
                $convId,
                $userId,
            ]
        );
    }

    private function rowToDto(array $r): array
    {
        $messages = json_decode($r['messages'] ?? '[]', true) ?: [];
        return [
            'id' => $r['id'],
            'userId' => $r['user_id'],
            'name' => $r['name'],
            'avatar' => $r['avatar'],
            'color' => $r['color'],
            'lastMessage' => $r['last_message'],
            'lastUpdated' => date(DATE_ATOM, strtotime($r['last_updated'])),
            'unreadCount' => (int)$r['unread_count'],
            'messages' => $messages,
            'createdAt' => date(DATE_ATOM, strtotime($r['created_at'])),
        ];
    }

    private function uuid(): string
    {
        $bytes = random_bytes(16);
        $bytes[6] = chr((ord($bytes[6]) & 0x0f) | 0x40);
        $bytes[8] = chr((ord($bytes[8]) & 0x3f) | 0x80);
        return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($bytes), 4));
    }
}
