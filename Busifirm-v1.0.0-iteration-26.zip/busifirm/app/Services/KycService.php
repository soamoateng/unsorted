<?php
declare(strict_types=1);

namespace Busifirm\Services;

use Busifirm\Core\Database;
use RuntimeException;

/**
 * KycService — per-user KYC (Know Your Customer) status.
 *
 * M5 update: the `documents` JSON column now stores an array of document IDs
 * (UUIDs from the documents table) instead of display strings. The frontend
 * calls /api/documents to upload files first, then passes the returned IDs
 * to updateStatus(). On read, getStatus() resolves each ID to a full document
 * DTO (filename, downloadUrl, etc.) so the UI can show links.
 *
 * KISS: one row per user with documents as JSON array of document IDs.
 * Normalizing into a kyc_documents_links table would add a join for no gain
 * until we need per-document KYC status (Phase 3).
 */
final class KycService
{
    public const STATUS_UNVERIFIED = 'unverified';
    public const STATUS_PENDING = 'pending';
    public const STATUS_VERIFIED = 'verified';
    public const STATUS_REJECTED = 'rejected';

    public function getStatus(string $userId): array
    {
        $row = Database::run(
            'SELECT user_id, status, documents, last_updated, created_at
             FROM kyc_documents
             WHERE user_id = ?
             LIMIT 1',
            [$userId]
        )->fetch();
        if ($row === false) {
            // PHP-016 fix: the old code did a plain INSERT here to lazy-init
            // the row. Two concurrent getStatus() calls for a user with no
            // existing KYC row both INSERTed, and the second failed on the
            // PRIMARY KEY(user_id) constraint → unhandled PDOException → 500.
            //
            // Fix: use INSERT IGNORE — if another thread already created the
            // row between our SELECT and INSERT, the INSERT is silently
            // skipped. We then re-SELECT to get the row (whichever thread
            // created it). The re-SELECT is outside any transaction, so
            // there's a tiny window where the row could be deleted between
            // the INSERT IGNORE and the re-SELECT — but kyc_documents rows
            // are only deleted by ON DELETE CASCADE from users, which only
            // happens during GDPR hard-delete (30-day grace window). In
            // practice, this is safe.
            Database::run(
                'INSERT IGNORE INTO kyc_documents (user_id, status, documents, last_updated, created_at)
                 VALUES (?, ?, ?, NOW(), NOW())',
                [$userId, self::STATUS_UNVERIFIED, json_encode([], JSON_UNESCAPED_UNICODE)]
            );
            // Re-SELECT to get the row (either ours or the other thread's).
            $row = Database::run(
                'SELECT user_id, status, documents, last_updated, created_at
                 FROM kyc_documents
                 WHERE user_id = ?
                 LIMIT 1',
                [$userId]
            )->fetch();
            if ($row === false) {
                // Extremely unlikely: the row was deleted between INSERT IGNORE
                // and SELECT. Return the default unverified state.
                return [
                    'userId' => $userId,
                    'status' => self::STATUS_UNVERIFIED,
                    'documents' => [],
                    'lastUpdated' => date(DATE_ATOM),
                ];
            }
        }

        $docIds = json_decode($row['documents'] ?? '[]', true) ?: [];
        $documents = $this->resolveDocuments($userId, $docIds);

        return [
            'userId' => $row['user_id'],
            'status' => $row['status'],
            'documents' => $documents,
            'lastUpdated' => date(DATE_ATOM, strtotime($row['last_updated'])),
        ];
    }

    public function updateStatus(string $userId, string $status, array $documentIds = []): array
    {
        if (!in_array($status, [self::STATUS_UNVERIFIED, self::STATUS_PENDING, self::STATUS_VERIFIED, self::STATUS_REJECTED], true)) {
            throw new RuntimeException('Invalid KYC status.');
        }

        // BL-16 fix: users must NOT be able to self-verify. Only admins can
        // set status to 'verified' or 'rejected' (via AdminService). The
        // user-facing endpoint may only set 'pending' (submit for review)
        // or 'unverified' (reset). The AdminService methods call this same
        // service method but bypass this check via the $allowVerified flag.
        if ($status === self::STATUS_VERIFIED || $status === self::STATUS_REJECTED) {
            throw new RuntimeException(
                'You cannot set your own KYC status to "' . $status . '". '
                . 'Only an administrator can verify or reject KYC submissions. '
                . 'Set your status to "pending" to submit for admin review.'
            );
        }

        // M5: validate that all document IDs belong to this user and are not soft-deleted.
        // This prevents a malicious client from linking someone else's documents
        // to their KYC submission (which would let them "verify" with stolen docs).
        $cleanIds = [];
        foreach ($documentIds as $docId) {
            $docId = (string)$docId;
            if (!preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i', $docId)) {
                throw new RuntimeException('Invalid document ID format: ' . $docId);
            }
            $exists = Database::run(
                'SELECT id FROM documents WHERE id = ? AND user_id = ? AND deleted_at IS NULL LIMIT 1',
                [$docId, $userId]
            )->fetch();
            if ($exists === false) {
                throw new RuntimeException('Document not found or not owned by you: ' . $docId);
            }
            $cleanIds[] = $docId;
        }

        // Upsert: ensure the row exists, then update.
        $this->getStatus($userId);
        Database::run(
            'UPDATE kyc_documents
             SET status = ?, documents = ?, last_updated = NOW()
             WHERE user_id = ?',
            [
                $status,
                json_encode($cleanIds, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
                $userId,
            ]
        );
        return $this->getStatus($userId);
    }

    public function isVerified(string $userId): bool
    {
        return $this->getStatus($userId)['status'] === self::STATUS_VERIFIED;
    }

    /**
     * Resolve a list of document IDs to full document DTOs for the UI.
     * Skips any IDs that no longer exist (e.g. soft-deleted between KYC
     * submission and now) — the UI shows what's still retrievable.
     *
     * @param array<int, string> $docIds
     * @return array<int, array>
     */
    private function resolveDocuments(string $userId, array $docIds): array
    {
        if (empty($docIds)) return [];
        // SEC-21 fix: cap the number of document IDs to prevent DoS via huge IN clauses.
        if (count($docIds) > 50) {
            throw new RuntimeException('Too many document IDs (max 50).');
        }
        $placeholders = implode(',', array_fill(0, count($docIds), '?'));
        // SEC-21 fix: validate each ID is a UUID before using in the query.
        foreach ($docIds as $docId) {
            if (!preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i', (string)$docId)) {
                throw new RuntimeException('Invalid document ID format.');
            }
        }
        $params = array_merge($docIds, [$userId]);
        $rows = Database::run(
            "SELECT id, user_id, original_filename, stored_filename, mime_type,
                    size_bytes, purpose, sha256, created_at
             FROM documents
             WHERE id IN ({$placeholders}) AND user_id = ? AND deleted_at IS NULL",
            $params
        )->fetchAll();
        return array_map(fn($r) => [
            'id' => $r['id'],
            'originalFilename' => $r['original_filename'],
            'mimeType' => $r['mime_type'],
            'sizeBytes' => (int)$r['size_bytes'],
            'purpose' => $r['purpose'],
            'createdAt' => date(DATE_ATOM, strtotime($r['created_at'])),
            'downloadUrl' => '/api/documents/' . $r['id'],
        ], $rows);
    }
}
