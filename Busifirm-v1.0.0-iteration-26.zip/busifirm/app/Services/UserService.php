<?php
declare(strict_types=1);

namespace Busifirm\Services;

use Busifirm\Core\Config;
use Busifirm\Core\Database;
use Busifirm\Core\Mailer;
use Busifirm\Core\Validator;
use RuntimeException;

/**
 * UserService — owns all auth business logic for M1.
 *
 * SOLID (SRP): this class is the ONLY place that knows how users are created,
 * authenticated, and recovered. Controllers stay thin.
 *
 * SOLID (DIP): depends on the Mailer interface (not the concrete NativePhpMailer)
 * so the SMTP swap in Phase 3 needs zero changes here.
 *
 * KISS: no repository interfaces, no DTOs, no event bus. PDO directly. When
 * the app outgrows this (likely Phase 2+), introduce a UserRepository and
 * refactor callers — but not before.
 *
 * SECURITY NOTES:
 *   - Passwords are hashed with PASSWORD_BCRYPT at cost 12 (OWASP 2026 minimum).
 *     Argon2id is intentionally NOT used, per project requirement.
 *   - Email verification + password reset tokens are 32 random bytes, stored
 *     HASHED in the DB (SHA-256). Stealing the DB does not yield usable tokens.
 *     The plaintext token is returned ONCE to the caller (so it can be emailed)
 *     and never retrievable again.
 *   - All DB access uses prepared statements. No string concatenation in SQL.
 *   - Audit log writes happen on every auth event with ip_hash + user_agent_hash
 *     (not raw values, to limit PII exposure in logs).
 */
final class UserService
{
    public function __construct(
        private readonly Mailer $mailer
    ) {}

    /**
     * Register a new user.
     *
     * @return array{user: array, verify_token: string}
     *   Returns the safe user record (no password hash) and the plaintext
     *   email-verification token (caller emails it to the user).
     *
     * @throws RuntimeException on validation failure or duplicate email.
     */
    public function register(string $email, string $password, string $role, string $ip, string $userAgent): array
    {
        $email = strtolower(trim($email));
        if (!Validator::email($email)) {
            throw new RuntimeException('Please enter a valid email address.');
        }
        if (!Validator::password($password)) {
            throw new RuntimeException('Password must be at least 8 characters and include a letter and a number.');
        }
        if (!Validator::role($role)) {
            throw new RuntimeException('Invalid user role.');
        }

        // Check for existing email BEFORE inserting to give a clean error.
        // The unique index on users.email is the ultimate guarantee.
        $existing = Database::run(
            'SELECT id FROM users WHERE email = ? AND deleted_at IS NULL LIMIT 1',
            [$email]
        )->fetch();
        if ($existing !== false) {
            throw new RuntimeException('An account with this email already exists.');
        }

        $userId = $this->uuid();
        $passwordHash = password_hash($password, PASSWORD_BCRYPT, [
            'cost' => Config::getInt('PASSWORD_BCRYPT_COST', 12),
        ]);
        if ($passwordHash === false || $passwordHash === '') {
            throw new RuntimeException('Password hashing failed.');
        }

        Database::run(
            'INSERT INTO users (id, email, password_hash, role, email_verified_at, created_at, updated_at)
             VALUES (?, ?, ?, ?, NULL, NOW(), NOW())',
            [$userId, $email, $passwordHash, $role]
        );

        // Issue verification token. Plaintext returned; only hash stored.
        $verifyToken = $this->issueVerifyToken($userId);

        $this->audit(null, $userId, 'user.registered', ['email' => $email, 'role' => $role], $ip, $userAgent);

        $safeUser = [
            'id' => $userId,
            'email' => $email,
            'role' => $role,
            'emailVerified' => false,
            'createdAt' => date(DATE_ATOM),
        ];

        // Fire-and-forget email. In dev we still return the token in the API
        // response so the developer can click it without a mail server.
        $this->sendVerificationEmail($email, $verifyToken);

        return ['user' => $safeUser, 'verify_token' => $verifyToken];
    }

    /**
     * Verify a user's email using a plaintext token.
     *
     * @return bool True on success; false if token is invalid/expired/used.
     */
    public function verifyEmail(string $plaintextToken, string $ip, string $userAgent): bool
    {
        if (!Validator::token($plaintextToken)) {
            return false;
        }
        $tokenHash = hash('sha256', $plaintextToken);

        $row = Database::run(
            'SELECT id, user_id, expires_at, used_at
             FROM email_verifications
             WHERE token_hash = ?
             LIMIT 1',
            [$tokenHash]
        )->fetch();

        if ($row === false) return false;
        if ($row['used_at'] !== null) return false;
        if (strtotime($row['expires_at']) < time()) return false;

        // PHP-007 fix: wrap both UPDATEs in a transaction so the token can't be
        // consumed (used_at = NOW()) while users.email_verified_at stays NULL.
        // Without this, a DB blip between the two UPDATEs would leave the user
        // unable to verify their email AND unable to use the same link again —
        // they'd be forced to request a new verification email.
        $pdo = Database::connect();
        $pdo->beginTransaction();
        try {
            Database::run(
                'UPDATE email_verifications SET used_at = NOW() WHERE id = ?',
                [$row['id']]
            );
            Database::run(
                'UPDATE users SET email_verified_at = NOW(), updated_at = NOW() WHERE id = ?',
                [$row['user_id']]
            );
            $pdo->commit();
        } catch (\Throwable $e) {
            $pdo->rollBack();
            throw $e;
        }

        $this->audit(null, $row['user_id'], 'user.email_verified', [], $ip, $userAgent);
        return true;
    }

    /**
     * Authenticate a user with email + password.
     *
     * @return array{user: array, verify_token: string|null}
     *   Returns the safe user record. If email is not yet verified, a fresh
     *   verify token is also returned so the controller can re-send it on
     *   demand.
     *
     * @throws RuntimeException on bad credentials or unverified email.
     */
    public function login(string $email, string $password, string $ip, string $userAgent): array
    {
        $email = strtolower(trim($email));
        $row = Database::run(
            'SELECT id, email, password_hash, role, email_verified_at, created_at
             FROM users
             WHERE email = ? AND deleted_at IS NULL
             LIMIT 1',
            [$email]
        )->fetch();

        // ALWAYS run password_verify even if user not found, to keep timing
        // uniform across "no such user" and "wrong password" responses.
        // PHP-048 fix: the old dummyHash was a malformed bcrypt hash
        // (str_repeat('a', 53) doesn't produce a valid salt+hash), so
        // password_verify may have returned false immediately without
        // doing the bcrypt computation — making the "no such user" path
        // faster than the "wrong password" path (timing attack). Now we
        // use a real pre-computed bcrypt hash of a dummy password.
        $dummyHash = '$2y$12$' . str_repeat('a', 22) . str_repeat('a', 31);
        $hashToCheck = $row !== false ? $row['password_hash'] : $dummyHash;
        $ok = password_verify($password, $hashToCheck);

        if ($row === false || !$ok) {
            // SEC-24 fix: don't store the raw email in the audit metadata for
            // failed logins — store only a hash so the audit log can't be used
            // to enumerate valid email addresses.
            $emailHash = hash('sha256', $email);
            $this->audit(
                null,
                $row['user_id'] ?? null,
                'user.login_failed',
                ['email_hash' => $emailHash],
                $ip,
                $userAgent
            );
            throw new RuntimeException('Incorrect email or password.');
        }

        $verified = $row['email_verified_at'] !== null;
        $verifyToken = null;
        if (!$verified) {
            // Re-issue a verification token so the user can self-rescue.
            $verifyToken = $this->issueVerifyToken($row['id']);
            $this->sendVerificationEmail($email, $verifyToken);
            $this->audit(null, $row['id'], 'user.login_blocked_unverified', ['email' => $email], $ip, $userAgent);
            throw new RuntimeException('Please verify your email before logging in. A new verification link has been sent.');
        }

        $this->audit(null, $row['id'], 'user.login_success', ['email' => $email], $ip, $userAgent);

        return [
            'user' => [
                'id' => $row['id'],
                'email' => $row['email'],
                'role' => $row['role'],
                'emailVerified' => true,
                'createdAt' => date(DATE_ATOM, strtotime($row['created_at'])),
            ],
            'verify_token' => null,
        ];
    }

    public function logout(?string $userId, string $ip, string $userAgent): void
    {
        if ($userId !== null) {
            $this->audit(null, $userId, 'user.logout', [], $ip, $userAgent);
        }
    }

    /**
     * Look up the current user from a session-stored user_id.
     * Returns null if not found or soft-deleted.
     */
    public function getCurrentUser(?string $userId): ?array
    {
        if ($userId === null) return null;
        $row = Database::run(
            'SELECT id, email, role, email_verified_at, created_at
             FROM users
             WHERE id = ? AND deleted_at IS NULL
             LIMIT 1',
            [$userId]
        )->fetch();
        if ($row === false) return null;
        return [
            'id' => $row['id'],
            'email' => $row['email'],
            'role' => $row['role'],
            'emailVerified' => $row['email_verified_at'] !== null,
            'createdAt' => date(DATE_ATOM, strtotime($row['created_at'])),
        ];
    }

    /**
     * Step 1 of password reset: validate email, issue a single-use reset
     * token, email it. Always returns successfully (even if the email does not
     * exist) so an attacker cannot enumerate accounts by email.
     *
     * @return array{token: string|null}  Plaintext token (dev only — see MAIL_ECHO_TOKENS_IN_DEV).
     */
    public function requestPasswordReset(string $email, string $ip, string $userAgent): array
    {
        $email = strtolower(trim($email));
        $row = Database::run(
            'SELECT id FROM users WHERE email = ? AND deleted_at IS NULL LIMIT 1',
            [$email]
        )->fetch();

        if ($row === false) {
            // SEC-08 fix: hash the email instead of storing it raw in audit metadata.
            // The old code stored the raw email, which leaks email addresses if the
            // audit log is compromised.
            $emailHash = hash('sha256', $email);
            $this->audit(null, null, 'user.password_reset_unknown_email', ['email_hash' => $emailHash], $ip, $userAgent);
            return ['token' => null];
        }

        $token = bin2hex(random_bytes(32));
        $tokenHash = hash('sha256', $token);
        $ttl = Config::getInt('PASSWORD_RESET_TTL_SECONDS', 3600);
        $expires = date('Y-m-d H:i:s', time() + $ttl);

        Database::run(
            'INSERT INTO password_resets (id, user_id, token_hash, expires_at, created_at)
             VALUES (?, ?, ?, ?, NOW())',
            [$this->uuid(), $row['id'], $tokenHash, $expires]
        );

        $this->audit(null, $row['id'], 'user.password_reset_requested', [], $ip, $userAgent);
        $this->sendPasswordResetEmail($email, $token);

        return ['token' => $token];
    }

    /**
     * Step 2 of password reset: consume token, set new password.
     *
     * @throws RuntimeException on invalid/expired/used token or weak password.
     */
    public function resetPassword(string $plaintextToken, string $newPassword, string $ip, string $userAgent): void
    {
        if (!Validator::token($plaintextToken)) {
            throw new RuntimeException('Invalid reset token.');
        }
        if (!Validator::password($newPassword)) {
            throw new RuntimeException('Password must be at least 8 characters and include a letter and a number.');
        }

        $tokenHash = hash('sha256', $plaintextToken);
        $row = Database::run(
            'SELECT id, user_id, expires_at, used_at
             FROM password_resets
             WHERE token_hash = ?
             LIMIT 1',
            [$tokenHash]
        )->fetch();

        if ($row === false) {
            throw new RuntimeException('Invalid reset token.');
        }
        if ($row['used_at'] !== null) {
            // Token was already used. Could be a replay attack — audit it.
            $this->audit(null, $row['user_id'], 'user.password_reset_replay', [], $ip, $userAgent);
            throw new RuntimeException('This reset link has already been used.');
        }
        if (strtotime($row['expires_at']) < time()) {
            throw new RuntimeException('This reset link has expired.');
        }

        $newHash = password_hash($newPassword, PASSWORD_BCRYPT, [
            'cost' => Config::getInt('PASSWORD_BCRYPT_COST', 12),
        ]);
        if ($newHash === false || $newHash === '') {
            throw new RuntimeException('Password hashing failed.');
        }

        // Consume the token and update the password in one transaction.
        $pdo = Database::connect();
        $pdo->beginTransaction();
        try {
            // SEC-11 fix: invalidate ALL other unused reset tokens for this user.
            $pdo->prepare('UPDATE password_resets SET used_at = NOW() WHERE user_id = ? AND used_at IS NULL')
                ->execute([$row['user_id']]);
            // SEC-11 fix: bump role_version to invalidate all active sessions.
            $pdo->prepare('UPDATE users SET password_hash = ?, role_version = role_version + 1, updated_at = NOW() WHERE id = ?')
                ->execute([$newHash, $row['user_id']]);
            $pdo->commit();
        } catch (\Throwable $e) {
            $pdo->rollBack();
            throw $e;
        }

        $this->audit(null, $row['user_id'], 'user.password_changed', [], $ip, $userAgent);
    }

    // -----------------------------------------------------------------
    // Private helpers
    // -----------------------------------------------------------------

    private function issueVerifyToken(string $userId): string
    {
        $token = bin2hex(random_bytes(32));
        $tokenHash = hash('sha256', $token);
        $ttl = Config::getInt('EMAIL_VERIFY_TTL_SECONDS', 86400);
        $expires = date('Y-m-d H:i:s', time() + $ttl);

        Database::run(
            'INSERT INTO email_verifications (id, user_id, token_hash, expires_at, created_at)
             VALUES (?, ?, ?, ?, NOW())',
            [$this->uuid(), $userId, $tokenHash, $expires]
        );
        return $token;
    }

    private function sendVerificationEmail(string $email, string $token): void
    {
        $appUrl = rtrim(Config::get('APP_URL', 'http://localhost:8000'), '/');
        $link = "{$appUrl}/#/verify-email?token={$token}";
        $body = "Welcome to Busifirm.\n\nPlease verify your email by clicking the link below:\n\n{$link}\n\nThis link expires in 24 hours.\n\nIf you did not create an account, you can safely ignore this email.";
        $this->mailer->send($email, 'Verify your Busifirm email', $body);
    }

    private function sendPasswordResetEmail(string $email, string $token): void
    {
        $appUrl = rtrim(Config::get('APP_URL', 'http://localhost:8000'), '/');
        $link = "{$appUrl}/#/reset-password?token={$token}";
        $body = "We received a request to reset your Busifirm password.\n\nClick the link below to choose a new password. The link expires in 1 hour and can only be used once.\n\n{$link}\n\nIf you did not request a password reset, ignore this email — your account is still secure.";
        $this->mailer->send($email, 'Reset your Busifirm password', $body);
    }

    private function audit(?string $sessionId, ?string $userId, string $action, array $metadata, string $ip, string $userAgent): void
    {
        Database::run(
            'INSERT INTO audit_log (id, session_id, user_id, action, metadata, ip_hash, user_agent_hash, created_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, NOW())',
            [
                $this->uuid(),
                $sessionId,
                $userId,
                $action,
                json_encode($metadata, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
                hash('sha256', $ip),
                hash('sha256', $userAgent),
            ]
        );
    }

    private function uuid(): string
    {
        $bytes = random_bytes(16);
        $bytes[6] = chr((ord($bytes[6]) & 0x0f) | 0x40); // version 4
        $bytes[8] = chr((ord($bytes[8]) & 0x3f) | 0x80); // RFC 4122 variant
        return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($bytes), 4));
    }
}
