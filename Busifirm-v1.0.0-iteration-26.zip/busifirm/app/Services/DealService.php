<?php
declare(strict_types=1);

namespace Busifirm\Services;

use Busifirm\Core\Database;
use RuntimeException;

/**
 * DealService — per-user deal pipeline (Negotiation → Due Diligence → Close).
 *
 * KISS: no deal-stage state machine yet (S4 kanban is a Should-have).
 * Status + stage are free-form strings validated by the controller.
 */
final class DealService
{
    public function listForUser(string $userId): array
    {
        // PERF-18 fix: add LIMIT 200 to prevent unbounded result sets.
        $rows = Database::run(
            'SELECT id, user_id, name, type, value, status, stage, partner, created_at, updated_at
             FROM deals WHERE user_id = ? ORDER BY created_at DESC LIMIT 200',
            [$userId]
        )->fetchAll();
        return array_map(fn($r) => $this->rowToDto($r), $rows);
    }

    public function update(string $dealId, string $userId, array $updates): array
    {
        $existing = Database::run(
            'SELECT id, user_id, name, type, value, status, stage, partner, created_at, updated_at
             FROM deals WHERE id = ? AND user_id = ? LIMIT 1',
            [$dealId, $userId]
        )->fetch();
        if ($existing === false) {
            throw new RuntimeException('Deal not found.');
        }

        // Allow only specific fields to be updated.
        $fields = [];
        $params = [];
        foreach (['name', 'type', 'value', 'status', 'stage', 'partner'] as $f) {
            if (array_key_exists($f, $updates)) {
                $fields[] = "{$f} = ?";
                $params[] = $f === 'value' ? (int)$updates[$f] : (string)$updates[$f];
            }
        }
        if (!$fields) {
            return $this->rowToDto($existing);
        }
        $fields[] = 'updated_at = NOW()';
        $params[] = $dealId;
        $params[] = $userId;

        Database::run(
            'UPDATE deals SET ' . implode(', ', $fields) . ' WHERE id = ? AND user_id = ?',
            $params
        );

        $row = Database::run(
            'SELECT id, user_id, name, type, value, status, stage, partner, created_at, updated_at
             FROM deals WHERE id = ? AND user_id = ? LIMIT 1',
            [$dealId, $userId]
        )->fetch();
        return $this->rowToDto($row);
    }

    public function create(string $userId, array $deal): array
    {
        // SEC-22 fix: validate the value field — reject negative or absurdly large values.
        $value = (int)($deal['value'] ?? 0);
        if ($value < 0) {
            throw new RuntimeException('Deal value cannot be negative.');
        }
        if ($value > 2147483647) {
            // PHP-054 fix: clarified the unit. The deals.value column is BIGINT
            // storing GHS kobo (1 GHS = 100 kobo). Max INT value 2147483647 kobo
            // = GHS 21,474,836.47. The column is actually BIGINT so the real
            // limit is much higher, but this check uses INT_MAX as a sane
            // business cap.
            throw new RuntimeException('Deal value exceeds maximum allowed (GHS 21,474,836.47, stored in kobo).');
        }
        $id = $this->uuid();
        Database::run(
            'INSERT INTO deals (id, user_id, name, type, value, status, stage, partner, created_at, updated_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())',
            [
                $id, $userId,
                (string)$deal['name'],
                (string)$deal['type'],
                $value,  // SEC-22 fix: use validated value
                (string)($deal['status'] ?? 'active'),
                (string)($deal['stage'] ?? 'negotiation'),
                (string)$deal['partner'],
            ]
        );
        $row = Database::run(
            'SELECT id, user_id, name, type, value, status, stage, partner, created_at, updated_at
             FROM deals WHERE id = ? LIMIT 1',
            [$id]
        )->fetch();
        return $this->rowToDto($row);
    }

    public function delete(string $dealId, string $userId): void
    {
        $existing = Database::run(
            'SELECT id FROM deals WHERE id = ? AND user_id = ? LIMIT 1',
            [$dealId, $userId]
        )->fetch();
        if ($existing === false) {
            throw new RuntimeException('Deal not found.');
        }
        Database::run('DELETE FROM deals WHERE id = ? AND user_id = ?', [$dealId, $userId]);
    }

    private function rowToDto(array $r): array
    {
        return [
            'id' => $r['id'],
            'userId' => $r['user_id'],
            'name' => $r['name'],
            'type' => $r['type'],
            'value' => (int)$r['value'],
            'status' => $r['status'],
            'stage' => $r['stage'],
            'partner' => $r['partner'],
            'createdAt' => date(DATE_ATOM, strtotime($r['created_at'])),
            'updatedAt' => date(DATE_ATOM, strtotime($r['updated_at'])),
        ];
    }

    private function uuid(): string
    {
        $bytes = random_bytes(16);
        $bytes[6] = chr((ord($bytes[6]) & 0x0f) | 0x40);
        $bytes[8] = chr((ord($bytes[8]) & 0x3f) | 0x80);
        return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($bytes), 4));
    }
}
