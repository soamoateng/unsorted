<?php
declare(strict_types=1);

namespace Busifirm\Services;

use Busifirm\Core\Config;
use Busifirm\Core\Database;
use RuntimeException;

/**
 * AdminService — owns all M6 admin-panel business logic.
 *
 * SOLID (SRP): the ONLY class that performs cross-user queries. Regular
 * services (ListingService, KycService, etc.) are scoped to the calling
 * user; AdminService is the escape hatch for moderators.
 *
 * Security:
 *   - Every method assumes the caller is already verified as admin by
 *     AdminMiddleware (the front controller calls requireAdmin() before
 *     dispatching to AdminController). Defense in depth: AdminController
 *     also re-checks via requireAdmin() in case of routing misconfiguration.
 *   - KYC verify/reject writes to kyc_documents + audit_log.
 *   - setPlanCode writes to plans.paystack_plan_code + audit_log.
 *   - OTH-23 fix: updated stale comment. changeUserRole() CAN change roles
 *     (seller/buyer/lawyer/broker) but CANNOT promote TO admin — that stays
 *     SQL-only by design.
 *
 * M6 polish (v0.8.0):
 *   - changeUserRole() now allowed via UI (was SQL-only in v0.7.0). Increments
 *     users.role_version which invalidates the user's active session on next
 *     request (AuthMiddleware compares session-cached version to DB version).
 *     Admin cannot promote to 'admin' role via this endpoint — that stays
 *     SQL-only by design (super-admin pattern deferred to Phase 4+).
 *   - deleteUser() implements GDPR right-to-erasure (M9 precursor). Hard-deletes
 *     all user data EXCEPT audit_log entries, which are anonymized (user_id
 *     set to NULL) and retained for the legal retention period. The user row
 *     gets deleted_at + deletion_scheduled_for = NOW + 30 days for a soft-delete
 *     window (admin can cancel within 30 days); the GC cron hard-deletes after.
 *
 * KISS:
 *   - No pagination on users list (Phase 3+). Returns up to 500 rows.
 *   - Audit log has a hard 1000-row cap per query.
 *   - No advanced search — just user_id / action / date filters.
 */
final class AdminService
{
    /**
     * List all users with their KYC status + plan code. For the admin users table.
     *
     * UX-09 fix: added $includeDeleted parameter. When true, the query also
     * returns soft-deleted users (with deleted_at, deleted_by, deletion_scheduled_for
     * fields) so the admin can see and restore them within the 30-day window.
     *
     * @param bool $includeDeleted If true, include soft-deleted users in the result.
     * @return array<int, array>
     */
    public function listUsers(bool $includeDeleted = false): array
    {
        // BL-26 fix: the old LEFT JOIN on subscriptions could return duplicate
        // rows if a user has multiple subscription records (cancelled + active).
        // Although the UNIQUE constraint on user_id (now a regular KEY after
        // migration 008) previously prevented this, the query should be robust.
        // Added DISTINCT and an ORDER BY on subscriptions.created_at DESC with
        // a LIMIT 1 subquery pattern to ensure one row per user.
        $whereClause = $includeDeleted ? '' : ' WHERE u.deleted_at IS NULL';
        $rows = Database::run(
            'SELECT u.id, u.email, u.role, u.email_verified_at, u.created_at,
                    u.deleted_at, u.deleted_by, u.deletion_scheduled_for,
                    k.status AS kyc_status,
                    p.code AS plan_code
             FROM users u
             LEFT JOIN kyc_documents k ON k.user_id = u.id
             LEFT JOIN (
                SELECT s1.user_id, s1.plan_id
                FROM subscriptions s1
                INNER JOIN (
                    SELECT user_id, MAX(created_at) AS max_created
                    FROM subscriptions
                    WHERE status IN ("active", "trialing", "past_due")
                    GROUP BY user_id
                ) s2 ON s1.user_id = s2.user_id AND s1.created_at = s2.max_created
                WHERE s1.status IN ("active", "trialing", "past_due")
             ) latest_sub ON latest_sub.user_id = u.id
             LEFT JOIN plans p ON latest_sub.plan_id = p.id'
            . $whereClause .
            ' ORDER BY u.created_at DESC
             LIMIT 500'
        )->fetchAll();
        return array_map(fn($r) => [
            'id' => $r['id'],
            'email' => $r['email'],
            'role' => $r['role'],
            'emailVerified' => $r['email_verified_at'] !== null,
            'kycStatus' => $r['kyc_status'] ?? 'unverified',
            'planCode' => $r['plan_code'] ?? 'free',
            'createdAt' => date(DATE_ATOM, strtotime($r['created_at'])),
            // UX-09: include deletion fields so the frontend can show/restore deleted users.
            'deletedAt' => $r['deleted_at'] !== null ? date(DATE_ATOM, strtotime($r['deleted_at'])) : null,
            'deletionScheduledFor' => $r['deletion_scheduled_for'] !== null ? date(DATE_ATOM, strtotime($r['deletion_scheduled_for'])) : null,
        ], $rows);
    }

    /**
     * Admin verifies a user's KYC. Writes to kyc_documents + audit_log.
     * This replaces the dev-shortcut auto-verify in submitKycForVerification().
     */
    public function verifyKyc(string $adminUserId, string $targetUserId): array
    {
        $this->ensureUserExists($targetUserId);
        // PHP-015 fix: the old code did SELECT-then-INSERT-or-UPDATE (lazy-init).
        // Two admins verifying KYC simultaneously both saw existing===false,
        // both INSERTed, and the second INSERT failed on the PRIMARY KEY(user_id)
        // constraint → unhandled PDOException → 500.
        //
        // Fix: use INSERT ... ON DUPLICATE KEY UPDATE — a single atomic
        // statement that INSERTs if the row doesn't exist, or UPDATEs the
        // status if it does. No race window.
        Database::run(
            'INSERT INTO kyc_documents (user_id, status, documents, last_updated, created_at)
             VALUES (?, "verified", "[]", NOW(), NOW())
             ON DUPLICATE KEY UPDATE status = "verified", last_updated = NOW()',
            [$targetUserId]
        );
        $this->audit($adminUserId, 'admin.kyc_verified', ['targetUserId' => $targetUserId]);
        return ['userId' => $targetUserId, 'kycStatus' => 'verified'];
    }

    /**
     * Admin rejects a user's KYC. Writes to kyc_documents + audit_log.
     */
    public function rejectKyc(string $adminUserId, string $targetUserId): array
    {
        $this->ensureUserExists($targetUserId);
        // PHP-015 fix: same INSERT ... ON DUPLICATE KEY UPDATE pattern as
        // verifyKyc. The old code did UPDATE-then-check-INSERT which had the
        // same race in reverse.
        Database::run(
            'INSERT INTO kyc_documents (user_id, status, documents, last_updated, created_at)
             VALUES (?, "rejected", "[]", NOW(), NOW())
             ON DUPLICATE KEY UPDATE status = "rejected", last_updated = NOW()',
            [$targetUserId]
        );
        $this->audit($adminUserId, 'admin.kyc_rejected', ['targetUserId' => $targetUserId]);
        return ['userId' => $targetUserId, 'kycStatus' => 'rejected'];
    }

    /**
     * Admin sets the paystack_plan_code on a plan. This is the missing piece
     * for recurring billing — until an admin pastes the code from the Paystack
     * dashboard, BillingService uses one-time transactions.
     */
    public function setPlanCode(string $adminUserId, string $planCode, string $paystackPlanCode): array
    {
        if ($paystackPlanCode === '') {
            throw new RuntimeException('paystackPlanCode cannot be empty. Pass NULL to clear.');
        }
        $row = Database::run(
            'SELECT id, code, name FROM plans WHERE code = ? LIMIT 1',
            [$planCode]
        )->fetch();
        if ($row === false) {
            throw new RuntimeException('Plan not found: ' . $planCode);
        }
        Database::run(
            'UPDATE plans SET paystack_plan_code = ?, updated_at = NOW() WHERE id = ?',
            [$paystackPlanCode, $row['id']]
        );
        $this->audit($adminUserId, 'admin.plan_code_set', [
            'planCode' => $planCode,
            'paystackPlanCode' => $paystackPlanCode,
        ]);
        return ['planCode' => $planCode, 'paystackPlanCode' => $paystackPlanCode];
    }

    /**
     * Admin clears the paystack_plan_code on a plan (revert to one-time transactions).
     */
    public function clearPlanCode(string $adminUserId, string $planCode): array
    {
        Database::run(
            'UPDATE plans SET paystack_plan_code = NULL, updated_at = NOW()
             WHERE code = ?',
            [$planCode]
        );
        $this->audit($adminUserId, 'admin.plan_code_cleared', ['planCode' => $planCode]);
        return ['planCode' => $planCode, 'paystackPlanCode' => null];
    }

    /**
     * List all plans with their paystack_plan_code (for the admin plan editor).
     *
     * @return array<int, array>
     */
    public function listPlansWithCodes(): array
    {
        $rows = Database::run(
            'SELECT id, code, name, price_kobo, currency, billing_interval,
                    paystack_plan_code, is_active, sort_order
             FROM plans
             ORDER BY sort_order ASC'
        )->fetchAll();
        return array_map(fn($r) => [
            'id' => $r['id'],
            'code' => $r['code'],
            'name' => $r['name'],
            'priceKobo' => (int)$r['price_kobo'],
            'priceGhs' => round((int)$r['price_kobo'] / 100, 2),
            'currency' => $r['currency'],
            'billingInterval' => $r['billing_interval'],
            'paystackPlanCode' => $r['paystack_plan_code'],
            'isActive' => (bool)$r['is_active'],
            'sortOrder' => (int)$r['sort_order'],
        ], $rows);
    }

    /**
     * List audit events across ALL users (not scoped). For the admin audit panel.
     * Supports optional filters.
     *
     * @param array{userId?: string, action?: string, fromDate?: string, toDate?: string} $filters
     * @return array<int, array>
     */
    public function listAuditEvents(array $filters = [], int $limit = 500): array
    {
        $where = [];
        $params = [];
        if (!empty($filters['userId'])) {
            // BL-30 fix: validate the userId is a UUID before using it in the
            // query. A malformed UUID would return 0 rows with no error —
            // the admin would see "No audit events found" and conclude the
            // user has no activity, when in reality the filter was malformed.
            $uid = (string)$filters['userId'];
            if (!preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i', $uid)) {
                throw new RuntimeException(
                    'Invalid user ID format. Expected a UUID (e.g. 12345678-1234-4123-8123-123456789abc).'
                );
            }
            $where[] = 'user_id = ?';
            $params[] = $uid;
        }
        if (!empty($filters['action'])) {
            $where[] = 'action LIKE ?';
            $params[] = '%' . $filters['action'] . '%';
        }
        if (!empty($filters['fromDate'])) {
            $where[] = 'created_at >= ?';
            $params[] = $filters['fromDate'];
        }
        if (!empty($filters['toDate'])) {
            $where[] = 'created_at <= ?';
            $params[] = $filters['toDate'];
        }
        $sql = 'SELECT id, user_id, action, metadata, ip_hash, user_agent_hash, created_at
                FROM audit_log';
        if ($where) {
            $sql .= ' WHERE ' . implode(' AND ', $where);
        }
        $sql .= ' ORDER BY created_at DESC LIMIT ' . max(1, min(1000, $limit));

        $rows = Database::run($sql, $params)->fetchAll();
        return array_map(fn($r) => [
            'id' => $r['id'],
            'userId' => $r['user_id'],
            'action' => $r['action'],
            'details' => json_decode($r['metadata'] ?? '{}', true) ?: [],
            'ipHash' => $r['ip_hash'],
            'userAgentHash' => $r['user_agent_hash'],
            'timestamp' => date(DATE_ATOM, strtotime($r['created_at'])),
        ], $rows);
    }

    /**
     * M6 polish: Change a user's role. Increments role_version which
     * invalidates the user's active session on their next request.
     *
     * Restrictions:
     *   - Cannot promote to 'admin' via this endpoint (SQL-only by design).
     *   - Cannot demote another admin (defense in depth — super-admin
     *     pattern deferred to Phase 4+).
     *   - Cannot change own role (admins must use SQL on themselves).
     *
     * @param string $adminUserId  The admin performing the action.
     * @param string $targetUserId The user whose role is changing.
     * @param string $newRole      One of: seller, buyer, lawyer, broker.
     * @return array{userId: string, role: string, roleVersion: int}
     */
    public function changeUserRole(string $adminUserId, string $targetUserId, string $newRole): array
    {
        $newRole = strtolower(trim($newRole));
        $allowed = ['seller', 'buyer', 'lawyer', 'broker'];
        if (!in_array($newRole, $allowed, true)) {
            // SEC-33 fix: audit the FAILED attempt so probing is detectable.
            $this->audit($adminUserId, 'admin.role_change_failed', [
                'targetUserId' => $targetUserId,
                'attemptedRole' => $newRole,
                'reason' => 'Invalid role (admin promotion is SQL-only).',
            ]);
            throw new RuntimeException(
                'Invalid role. Allowed values: ' . implode(', ', $allowed) . '. '
                . 'Admin promotion is SQL-only by design.'
            );
        }
        $this->ensureUserExists($targetUserId);

        $target = Database::run(
            'SELECT id, role FROM users WHERE id = ? AND deleted_at IS NULL LIMIT 1',
            [$targetUserId]
        )->fetch();
        if ($target === false) {
            throw new RuntimeException('User not found: ' . $targetUserId);
        }
        if ($target['role'] === 'admin') {
            throw new RuntimeException('Cannot change the role of an admin user.');
        }
        if ($targetUserId === $adminUserId) {
            throw new RuntimeException('Cannot change your own role. Use SQL.');
        }
        if ($target['role'] === $newRole) {
            // PHP-046 fix: fetch() may return false if another admin soft-deleted
            // the target user between the SELECT above and this one. Dereferencing
            // false['role_version'] throws TypeError in PHP 8.
            $row = Database::run(
                'SELECT role_version FROM users WHERE id = ? LIMIT 1',
                [$targetUserId]
            )->fetch();
            return [
                'userId' => $targetUserId,
                'role' => $newRole,
                'roleVersion' => $row !== false ? (int)$row['role_version'] : 0,
            ];
        }

        // Update role + bump role_version in one UPDATE. The session
        // invalidation happens on the target user's NEXT request —
        // AuthMiddleware compares session-cached version to DB version.
        Database::run(
            'UPDATE users SET role = ?, role_version = role_version + 1, updated_at = NOW()
             WHERE id = ?',
            [$newRole, $targetUserId]
        );

        // PHP-046 fix: same null-check on the post-UPDATE SELECT.
        $verRow = Database::run(
            'SELECT role_version FROM users WHERE id = ? LIMIT 1',
            [$targetUserId]
        )->fetch();
        $newVersion = $verRow !== false ? (int)$verRow['role_version'] : 0;

        // BL-13 fix: check if the user has active listings/deals that may be
        // affected by the role change. Include a warning in the response so
        // the admin is aware of potential disruption.
        $warnings = [];
        if ($target['role'] === 'seller' || $target['role'] === 'broker') {
            if (!in_array($newRole, ['seller', 'broker'], true)) {
                $listingCount = (int)Database::run(
                    'SELECT COUNT(*) AS c FROM listings WHERE user_id = ?',
                    [$targetUserId]
                )->fetch()['c'];
                if ($listingCount > 0) {
                    $warnings[] = "User has $listingCount active listing(s) that they will no longer be able to edit.";
                }
            }
        }

        $this->audit($adminUserId, 'admin.role_changed', [
            'targetUserId' => $targetUserId,
            'oldRole' => $target['role'],
            'newRole' => $newRole,
            'newRoleVersion' => $newVersion,
            'warnings' => $warnings,
        ]);

        return [
            'userId' => $targetUserId,
            'role' => $newRole,
            'roleVersion' => $newVersion,
            'warnings' => $warnings,
        ];
    }

    /**
     * M6 polish + M9 precursor: GDPR right-to-erasure. Soft-deletes the user
     * (sets deleted_at + deletion_scheduled_for = NOW + 30 days). The user
     * cannot log in immediately (deleted_at IS NOT NULL fails the lookup).
     * After 30 days, the GC cron hard-deletes the row + all dependent data.
     *
     * Hard-delete is a two-phase commit:
     *   Phase 1 (this method): soft-delete user + cancel subscription + 
     *     anonymize audit_log entries (set user_id to NULL so the user
     *     cannot be re-identified, but the audit trail is preserved for
     *     the legal retention period — Ghana Companies Act 2019 requires
     *     7 years for financial records).
     *   Phase 2 (bin/gc-documents.php + bin/purge-deleted-users.php cron):
     *     hard-deletes documents (file bytes + rows), then the user row.
     *
     * @param string $adminUserId  The admin performing the delete.
     * @param string $targetUserId The user being deleted.
     * @return array{userId: string, deletionScheduledFor: string}
     */
    public function deleteUser(string $adminUserId, string $targetUserId): array
    {
        $this->ensureUserExists($targetUserId);
        if ($targetUserId === $adminUserId) {
            throw new RuntimeException('Cannot delete your own account.');
        }
        $target = Database::run(
            'SELECT id, role FROM users WHERE id = ? AND deleted_at IS NULL LIMIT 1',
            [$targetUserId]
        )->fetch();
        if ($target === false) {
            throw new RuntimeException('User not found or already deleted.');
        }
        if ($target['role'] === 'admin') {
            throw new RuntimeException('Cannot delete an admin user. Demote them first via SQL.');
        }

        $pdo = Database::connect();
        $pdo->beginTransaction();
        try {
            $scheduledFor = date('Y-m-d H:i:s', strtotime('+' . (int)Config::get('USER_DELETION_RETENTION_DAYS', '30') . ' days'));

            // 1. Soft-delete the user row. All FK-constrained tables (listings,
            //    deals, chat, esigns, integrations, kyc_documents, documents,
            //    subscriptions, invoices, email_verifications, password_resets)
            //    stay in place for the 30-day window. The user just can't log in.
            Database::run(
                'UPDATE users
                 SET deleted_at = NOW(),
                     deleted_by = ?,
                     deletion_scheduled_for = ?,
                     role_version = role_version + 1,
                     updated_at = NOW()
                 WHERE id = ?',
                [$adminUserId, $scheduledFor, $targetUserId]
            );

            // 2. Cancel any active subscription. The user's plan ends now,
            //    not at next_billing_at — they're being deleted.
            Database::run(
                'UPDATE subscriptions
                 SET status = "cancelled", cancelled_at = NOW(), updated_at = NOW(),
                     pending_plan_id = NULL
                 WHERE user_id = ? AND status IN ("active", "trialing", "past_due")',
                [$targetUserId]
            );

            // 3. Anonymize audit_log entries: set user_id to NULL so the
            //    audit trail can't be re-attached to a deleted user. The
            //    ip_hash and user_agent_hash are already anonymized (one-way).
            //    Set retained_until = NOW + 7 years for entries that look
            //    financial (action contains 'billing', 'invoice', 'payment').
            //    Other entries get retained_until = NOW + 1 year.
            $sevenYears = date('Y-m-d H:i:s', strtotime('+7 years'));
            $oneYear = date('Y-m-d H:i:s', strtotime('+1 year'));

            Database::run(
                'UPDATE audit_log
                 SET user_id = NULL,
                     retained_until = CASE
                         WHEN action LIKE "%billing%" OR action LIKE "%invoice%"
                              OR action LIKE "%payment%" OR action LIKE "%subscription%"
                              OR action LIKE "%admin.%" THEN ?
                         ELSE ?
                     END
                 WHERE user_id = ?',
                [$sevenYears, $oneYear, $targetUserId]
            );

            // SQL-002 fix: anonymize invoices the same way as audit_log.
            // The migration 012 changed invoices.user_id FK from ON DELETE
            // CASCADE to ON DELETE SET NULL, so when the GC cron hard-deletes
            // the user row, the invoice rows survive with user_id=NULL. But
            // we ALSO need to set retained_until here so the GC cron knows
            // when to purge them — paid invoices get +7 years (Ghana Companies
            // Act 2019 §288), others get +1 year. Without this, invoices would
            // be retained indefinitely (retained_until=NULL = never purge),
            // which is a GDPR data-minimisation violation.
            Database::run(
                'UPDATE invoices
                 SET user_id = NULL,
                     retained_until = CASE
                         WHEN status IN ("success", "refunded") THEN ?
                         ELSE ?
                     END
                 WHERE user_id = ?',
                [$sevenYears, $oneYear, $targetUserId]
            );

            $pdo->commit();
        } catch (\Throwable $e) {
            $pdo->rollBack();
            throw $e;
        }

        $this->audit($adminUserId, 'admin.user_deleted', [
            'targetUserId' => $targetUserId,
            'deletionScheduledFor' => $scheduledFor,
            // BL-22 fix: record whether a refund was issued. The system does
            // NOT automatically refund — the admin must manually process any
            // refund via Paystack. This audit entry ensures there's a record.
            'refundIssued' => false,
            'refundNote' => 'No automatic refund. Admin must manually process refund via Paystack if applicable.',
        ]);

        return [
            'userId' => $targetUserId,
            'deletionScheduledFor' => date(DATE_ATOM, strtotime($scheduledFor)),
            // BL-22 fix: include a refund note so the admin is aware.
            'refundNote' => 'No automatic refund was issued. If the user had an active paid subscription, process a manual refund via Paystack dashboard.',
        ];
    }

    /**
     * Cancel a pending user deletion (within the 30-day window).
     * Clears deleted_at, deleted_by, deletion_scheduled_for. Re-activates
     * the user's most recent cancelled subscription if it was cancelled by
     * the delete flow (heuristic: cancelled within 5 minutes of deleted_at).
     */
    public function cancelUserDeletion(string $adminUserId, string $targetUserId): array
    {
        $row = Database::run(
            'SELECT id, deleted_at, deletion_scheduled_for FROM users
             WHERE id = ? AND deleted_at IS NOT NULL LIMIT 1',
            [$targetUserId]
        )->fetch();
        if ($row === false) {
            throw new RuntimeException('User not found or not in a deleted state.');
        }

        Database::run(
            'UPDATE users
             SET deleted_at = NULL,
                 deleted_by = NULL,
                 deletion_scheduled_for = NULL,
                 role_version = role_version + 1,
                 updated_at = NOW()
             WHERE id = ?',
            [$targetUserId]
        );

        // BL-17 fix: restore the most recently cancelled subscription if it
        // was cancelled as part of the delete flow. The deleteUser() method
        // cancels all active/trialing/past_due subs. We re-activate the most
        // recent cancelled sub that has next_billing_at in the future.
        $cancelledSub = Database::run(
            'SELECT id, plan_id, started_at, next_billing_at, cancelled_at
             FROM subscriptions
             WHERE user_id = ? AND status = "cancelled"
             ORDER BY cancelled_at DESC
             LIMIT 1',
            [$targetUserId]
        )->fetch();
        if ($cancelledSub !== false) {
            // Only restore if the sub was cancelled recently (within the delete window)
            // and the next_billing_at is still in the future.
            $nextBilling = $cancelledSub['next_billing_at'] ?? null;
            $canRestore = $nextBilling !== null && strtotime($nextBilling) > time();
            if ($canRestore) {
                Database::run(
                    'UPDATE subscriptions
                     SET status = "active", cancelled_at = NULL, updated_at = NOW()
                     WHERE id = ?',
                    [$cancelledSub['id']]
                );
            }
        }

        $this->audit($adminUserId, 'admin.user_deletion_cancelled', [
            'targetUserId' => $targetUserId,
        ]);

        return ['userId' => $targetUserId, 'restoredAt' => date(DATE_ATOM)];
    }

    /**
     * Get aggregate stats for the admin dashboard. KISS: simple counts.
     */
    public function getStats(): array
    {
        // PERF-07 fix: consolidate 8 separate COUNT queries into 4.
        // KYC verified + pending can be done in one GROUP BY query.
        // Invoices total + paid + revenue can be done in one query.
        $totalUsers = (int)Database::run(
            'SELECT COUNT(*) AS c FROM users WHERE deleted_at IS NULL'
        )->fetch()['c'];

        // PERF-07: combine KYC counts into one query.
        $kycRows = Database::run(
            'SELECT status, COUNT(*) AS c FROM kyc_documents GROUP BY status'
        )->fetchAll();
        $verifiedKyc = 0;
        $pendingKyc = 0;
        foreach ($kycRows as $kr) {
            if ($kr['status'] === 'verified') $verifiedKyc = (int)$kr['c'];
            if ($kr['status'] === 'pending') $pendingKyc = (int)$kr['c'];
        }

        $activeSubs = (int)Database::run(
            'SELECT COUNT(*) AS c FROM subscriptions WHERE status = "active"'
        )->fetch()['c'];

        $totalListings = (int)Database::run(
            'SELECT COUNT(*) AS c FROM listings'
        )->fetch()['c'];

        // PERF-07: combine invoice counts + revenue into one query.
        $invRow = Database::run(
            'SELECT
                COUNT(*) AS total,
                SUM(CASE WHEN status = "success" THEN 1 ELSE 0 END) AS paid,
                COALESCE(SUM(CASE WHEN status = "success" THEN amount_kobo ELSE 0 END), 0) AS revenue
             FROM invoices'
        )->fetch();
        $totalInvoices = (int)$invRow['total'];
        $paidInvoices = (int)$invRow['paid'];
        $totalRevenueKobo = (int)$invRow['revenue'];

        return [
            'totalUsers' => $totalUsers,
            'verifiedKyc' => $verifiedKyc,
            'pendingKyc' => $pendingKyc,
            'activeSubscriptions' => $activeSubs,
            'totalListings' => $totalListings,
            'totalInvoices' => $totalInvoices,
            'paidInvoices' => $paidInvoices,
            'totalRevenueGhs' => round($totalRevenueKobo / 100, 2),
        ];
    }

    // -----------------------------------------------------------------
    // Helpers
    // -----------------------------------------------------------------

    private function ensureUserExists(string $userId): void
    {
        $row = Database::run(
            'SELECT id FROM users WHERE id = ? AND deleted_at IS NULL LIMIT 1',
            [$userId]
        )->fetch();
        if ($row === false) {
            throw new RuntimeException('User not found: ' . $userId);
        }
    }

    private function audit(string $adminUserId, string $action, array $details): void
    {
        Database::run(
            'INSERT INTO audit_log (id, session_id, user_id, action, metadata, ip_hash, user_agent_hash, created_at)
             VALUES (?, NULL, ?, ?, ?, ?, ?, NOW())',
            [
                $this->uuid(),
                $adminUserId,
                $action,
                json_encode($details, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
                hash('sha256', $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1'),
                hash('sha256', substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 512)),  // SQL-029 fix: consistent 512-char truncation (matches AuditService::log which also truncates at 512)
            ]
        );
    }

    private function uuid(): string
    {
        $bytes = random_bytes(16);
        $bytes[6] = chr((ord($bytes[6]) & 0x0f) | 0x40);
        $bytes[8] = chr((ord($bytes[8]) & 0x3f) | 0x80);
        return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($bytes), 4));
    }
}
