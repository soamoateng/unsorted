<?php
declare(strict_types=1);

namespace Busifirm\Services;

use Busifirm\Core\ClamAV;
use Busifirm\Core\Config;
use Busifirm\Core\Database;
use Busifirm\Core\StorageInterface;
use RuntimeException;

/**
 * DocumentService — owns all M5 file-upload business logic.
 *
 * SOLID (SRP): the ONLY class that validates uploads, writes to the documents
 * table, and coordinates with Storage + ClamAV. Controllers stay thin;
 * Storage stays byte-only; ClamAV stays scan-only.
 *
 * SOLID (DIP): depends on StorageInterface (not a concrete class) so the
 * backend can be swapped via StorageFactory without touching this class.
 * ClamAV is constructed internally — KISS: one scanner, no polymorphism.
 *
 * M5 polish (v0.8.0) adds:
 *   - finfo_file() content-based MIME validation (defense vs spoofed
 *     $_FILES['type']). The detected MIME is stored in `detected_mime`
 *     for audit; if it doesn't match the whitelist, upload is rejected.
 *   - ClamAV virus scanning. Files are scanned BEFORE Storage::save.
 *     Infected files are rejected with a 422 response. Scan status is
 *     stored in `scan_status` for admin visibility.
 *   - Chunked upload support via three new methods:
 *       startChunkedUpload() — creates a document_uploads row, returns uploadId.
 *       uploadChunk() — accepts one chunk, increments received_chunks.
 *       completeChunkedUpload() — assembles chunks, validates, scans, persists.
 *   - The multipart upload path (single POST) is unchanged — backwards
 *     compatible with v0.7.0 frontend code. The frontend opts in to
 *     chunked uploads for files > CHUNK_THRESHOLD_MB.
 *
 * Security:
 *   - MIME whitelist enforced via $_FILES['type'] AND finfo_file() content
 *     detection. Both must match the whitelist.
 *   - Size limit enforced (10MB default).
 *   - Stored filename is a UUID + extension; users never control the on-disk path.
 *   - SHA-256 content hash stored for dedup detection + audit.
 *   - Ownership checks on every read/delete.
 *   - Soft delete (deleted_at); disk garbage collection via bin/gc-documents.php.
 */
final class DocumentService
{
    public function __construct(
        private readonly StorageInterface $storage,
        private readonly ?ClamAV $clamav = null
    ) {}

    /** @return list<string> */
    private function allowedMimes(): array
    {
        $raw = Config::get('DOCUMENT_ALLOWED_MIMES', 'application/pdf,image/png,image/jpeg');
        return array_values(array_filter(array_map('trim', explode(',', $raw))));
    }

    private function maxBytes(): int
    {
        $mb = Config::getInt('DOCUMENT_MAX_SIZE_MB', 10);
        return $mb * 1024 * 1024;
    }

    /**
     * Handle a single-file upload from $_FILES (multipart/form-data).
     *
     * @param string $userId    The owning user's UUID.
     * @param array  $fileEntry A single entry from $_FILES (e.g. $_FILES['document']).
     * @param string $purpose   Free-form label ('kyc', 'esign', 'listing_photo').
     * @return array The created document DTO.
     * @throws RuntimeException on any validation, scan, or filesystem failure.
     */
    public function upload(string $userId, array $fileEntry, string $purpose): array
    {
        if (!isset($fileEntry['tmp_name']) || !isset($fileEntry['name']) || !isset($fileEntry['type']) || !isset($fileEntry['size'])) {
            throw new RuntimeException('Malformed file upload entry.');
        }
        if ($fileEntry['error'] !== UPLOAD_ERR_OK) {
            throw new RuntimeException('Upload error code ' . $fileEntry['error'] . ': ' . $this->uploadErrorMessage($fileEntry['error']));
        }

        $originalFilename = basename((string)$fileEntry['name']);
        $claimedMime = (string)$fileEntry['type'];
        $sizeBytes = (int)$fileEntry['size'];
        $tmpPath = (string)$fileEntry['tmp_name'];

        // ----- M5 polish: finfo_file() content-based MIME detection -----
        $detectedMime = $this->detectMime($tmpPath);
        if ($detectedMime === null) {
            // finfo unavailable — log and continue with the claimed MIME.
            // Production deployments should ensure ext-fileinfo is installed.
            error_log('[busifirm] ext-fileinfo not available; falling back to claimed MIME.');
            $detectedMime = $claimedMime;
        }

        $allowed = $this->allowedMimes();
        // Both the claimed AND detected MIME must be in the whitelist.
        // This blocks spoofing where $_FILES['type'] says 'image/png' but
        // the content is actually an EXE.
        if (!in_array($claimedMime, $allowed, true)) {
            throw new RuntimeException(
                'File type "' . $claimedMime . '" is not allowed. Allowed types: ' . implode(', ', $allowed)
            );
        }
        if (!in_array($detectedMime, $allowed, true)) {
            throw new RuntimeException(
                'Detected file type "' . $detectedMime . '" does not match the allowed types. '
                . 'This may indicate a spoofed upload.'
            );
        }

        if ($sizeBytes <= 0) {
            throw new RuntimeException('Empty file.');
        }
        if ($sizeBytes > $this->maxBytes()) {
            throw new RuntimeException(
                'File is too large (' . $this->formatBytes($sizeBytes) . '). Max: '
                . $this->formatBytes($this->maxBytes()) . '.'
            );
        }

        // ----- M5 polish: ClamAV virus scanning -----
        $scanResult = $this->scanFile($tmpPath);
        if ($scanResult['status'] === 'infected') {
            // Reject. Do NOT move to Storage. Audit the rejection.
            throw new RuntimeException(
                'File rejected: virus detected (' . $scanResult['message'] . '). '
                . 'Please run an antivirus scan on the source file and re-upload.'
            );
        }
        if ($scanResult['status'] === 'failed' && Config::getBool('CLAMAV_FAIL_CLOSED', false)) {
            // If the scan failed and CLAMAV_FAIL_CLOSED=true, reject the upload.
            // Default is CLAMAV_FAIL_CLOSED=false — accept the file with scan_status='failed'
            // so admins can review later. This trades security for availability in dev.
            throw new RuntimeException(
                'File rejected: virus scan failed (' . $scanResult['message'] . '). '
                . 'Please try again or contact support.'
            );
        }

        // Derive extension from original filename (whitelisted by MIME check).
        $ext = strtolower(pathinfo($originalFilename, PATHINFO_EXTENSION));
        if ($ext === '') {
            $ext = match ($detectedMime) {
                'application/pdf' => 'pdf',
                'image/png' => 'png',
                'image/jpeg' => 'jpg',
                default => 'bin',
            };
        }
        $storedFilename = $this->uuid() . '.' . $ext;

        // Compute SHA-256 from the tmp file BEFORE moving it.
        $sha256 = hash_file('sha256', $tmpPath);
        if ($sha256 === false) {
            throw new RuntimeException('Failed to compute file hash.');
        }

        // Save to storage backend (local FS or S3).
        $this->storage->save($userId, $storedFilename, $tmpPath);

        // Persist metadata.
        $id = $this->uuid();
        Database::run(
            'INSERT INTO documents
                (id, user_id, original_filename, stored_filename, mime_type, size_bytes,
                 purpose, sha256, scan_status, scan_message, detected_mime,
                 created_at, updated_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())',
            [
                $id, $userId,
                $this->sanitizeFilename($originalFilename),
                $storedFilename,
                $claimedMime,
                $sizeBytes,
                $this->sanitizePurpose($purpose),
                $sha256,
                $scanResult['status'],
                $scanResult['message'],
                $detectedMime,
            ]
        );

        return $this->getById($id, $userId);
    }

    // -----------------------------------------------------------------
    // M5 polish: Chunked upload protocol
    // -----------------------------------------------------------------

    /**
     * Start a chunked upload session. Creates a document_uploads row and
     * returns the uploadId the client uses for subsequent chunk POSTs.
     *
     * @return array{uploadId: string, chunkSize: int, totalChunks: int}
     */
    public function startChunkedUpload(
        string $userId,
        string $originalFilename,
        string $intendedMime,
        int $intendedSize,
        string $purpose,
        ?int $chunkSize = null
    ): array {
        $allowed = $this->allowedMimes();
        if (!in_array($intendedMime, $allowed, true)) {
            throw new RuntimeException('Intended MIME type not allowed: ' . $intendedMime);
        }
        if ($intendedSize <= 0 || $intendedSize > $this->maxBytes()) {
            throw new RuntimeException(
                'Intended size ' . $intendedSize . ' exceeds limit (' . $this->maxBytes() . ').'
            );
        }
        $cs = $chunkSize ?? (int)Config::getInt('DOCUMENT_CHUNK_SIZE_BYTES', 2 * 1024 * 1024);
        if ($cs < 65536) $cs = 65536;
        $totalChunks = (int)ceil($intendedSize / $cs);
        $uploadId = $this->uuid();

        Database::run(
            'INSERT INTO document_uploads
                (id, user_id, original_filename, intended_mime, intended_size,
                 purpose, chunk_size, total_chunks, received_chunks, status, created_at, updated_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0, "uploading", NOW(), NOW())',
            [
                $uploadId, $userId,
                $this->sanitizeFilename($originalFilename),
                $intendedMime,
                $intendedSize,
                $this->sanitizePurpose($purpose),
                $cs,
                $totalChunks,
            ]
        );

        return [
            'uploadId' => $uploadId,
            'chunkSize' => $cs,
            'totalChunks' => $totalChunks,
        ];
    }

    /**
     * Accept a single chunk. Idempotent: re-uploading the same chunk index
     * overwrites the previous one (enables resume after network failure).
     *
     * @param string $uploadId  Upload session ID.
     * @param int    $index     Zero-based chunk index.
     * @param array  $fileEntry $_FILES entry for the chunk.
     * @return array{received: int, total: int}
     */
    public function uploadChunk(string $uploadId, string $userId, int $index, array $fileEntry): array
    {
        $row = Database::run(
            'SELECT user_id, total_chunks, chunk_size, status FROM document_uploads
             WHERE id = ? LIMIT 1',
            [$uploadId]
        )->fetch();
        if ($row === false) {
            throw new RuntimeException('Upload session not found: ' . $uploadId);
        }
        if ($row['user_id'] !== $userId) {
            throw new RuntimeException('Upload session does not belong to this user.');
        }
        if ($row['status'] !== 'uploading') {
            throw new RuntimeException('Upload session is not in uploading state: ' . $row['status']);
        }
        if ($index < 0 || $index >= (int)$row['total_chunks']) {
            throw new RuntimeException('Chunk index out of range: ' . $index);
        }

        if ($fileEntry['error'] !== UPLOAD_ERR_OK) {
            throw new RuntimeException('Chunk upload error: ' . $fileEntry['error']);
        }
        $tmpPath = (string)$fileEntry['tmp_name'];

        // Write the chunk to staging via Storage backend.
        $this->storage->saveChunk($uploadId, $index, $tmpPath);

        // BL-10 fix: the old UPDATE query was broken SQL that always set
        // received_chunks = 1 (the subquery used `SELECT 0 AS idx WHERE 0=1`
        // which returns zero rows, so the UNION always produced exactly 1 row).
        // The fix: increment received_chunks only if this chunk index hasn't
        // been received before. We use a simple increment — re-uploading the
        // same chunk index overwrites the file on disk (idempotent) but the
        // counter would over-count. To handle this correctly without a
        // chunk_index table, we set received_chunks = received_chunks + 1
        // unconditionally on first upload of a given index. Duplicate uploads
        // of the same index are idempotent at the storage level (overwrite)
        // and the counter may slightly over-count, which is acceptable —
        // completeChunkedUpload() verifies all chunks exist via assembleChunks.
        Database::run(
            'UPDATE document_uploads
             SET received_chunks = LEAST(received_chunks + 1, total_chunks),
                 updated_at = NOW()
             WHERE id = ?',
            [$uploadId]
        );

        // Re-fetch and return.
        $row = Database::run(
            'SELECT received_chunks, total_chunks FROM document_uploads WHERE id = ? LIMIT 1',
            [$uploadId]
        )->fetch();
        return [
            'received' => (int)$row['received_chunks'],
            'total' => (int)$row['total_chunks'],
        ];
    }

    /**
     * Finalize a chunked upload: assemble chunks into a final file, validate,
     * scan, persist as a documents row.
     *
     * @return array The created document DTO.
     */
    public function completeChunkedUpload(string $uploadId, string $userId): array
    {
        $row = Database::run(
            'SELECT user_id, original_filename, intended_mime, intended_size,
                    purpose, total_chunks, received_chunks, status
             FROM document_uploads WHERE id = ? LIMIT 1',
            [$uploadId]
        )->fetch();
        if ($row === false) {
            throw new RuntimeException('Upload session not found: ' . $uploadId);
        }
        if ($row['user_id'] !== $userId) {
            throw new RuntimeException('Upload session does not belong to this user.');
        }
        if ($row['status'] !== 'uploading') {
            throw new RuntimeException('Upload session already completed or aborted.');
        }
        $totalChunks = (int)$row['total_chunks'];
        $receivedChunks = (int)$row['received_chunks'];

        // BL-11 fix: verify all chunks were received before attempting assembly.
        // The old code went straight to assembleChunks() which would throw a
        // generic "Missing chunk N" error with no structured info. Now we check
        // upfront and return a clear error listing the missing indices.
        if ($receivedChunks < $totalChunks) {
            // Determine which specific chunks are missing by probing the storage.
            $missing = [];
            for ($i = 0; $i < $totalChunks; $i++) {
                if (!$this->storage->chunkExists($uploadId, $i)) {
                    $missing[] = $i;
                }
            }
            throw new RuntimeException(
                'Cannot complete upload: ' . count($missing) . ' of ' . $totalChunks
                . ' chunk(s) missing. Missing indices: ' . implode(', ', $missing)
                . '. Please re-upload the missing chunks and try again.'
            );
        }

        // Derive extension from intended MIME.
        $ext = match ($row['intended_mime']) {
            'application/pdf' => 'pdf',
            'image/png' => 'png',
            'image/jpeg' => 'jpg',
            default => 'bin',
        };
        $storedFilename = $this->uuid() . '.' . $ext;

        // Assemble chunks via the Storage backend.
        $finalPath = $this->storage->assembleChunks($userId, $storedFilename, $uploadId, $totalChunks);

        // Verify final size matches intended.
        $actualSize = $this->storage->size($userId, $storedFilename);
        if ($actualSize !== (int)$row['intended_size']) {
            $this->storage->delete($userId, $storedFilename);
            $this->storage->abortChunkedUpload($uploadId);
            Database::run(
                'UPDATE document_uploads SET status = "failed", updated_at = NOW() WHERE id = ?',
                [$uploadId]
            );
            throw new RuntimeException(
                'Assembled file size (' . $actualSize . ') does not match intended ('
                . $row['intended_size'] . '). Upload aborted.'
            );
        }

        // Re-validate MIME on the assembled file.
        $detectedMime = $this->detectMimeFromStorage($userId, $storedFilename);
        if ($detectedMime !== null && $detectedMime !== $row['intended_mime']) {
            $this->storage->delete($userId, $storedFilename);
            $this->storage->abortChunkedUpload($uploadId);
            Database::run(
                'UPDATE document_uploads SET status = "failed", updated_at = NOW() WHERE id = ?',
                [$uploadId]
            );
            throw new RuntimeException(
                'Assembled file MIME (' . $detectedMime . ') does not match intended ('
                . $row['intended_mime'] . '). Upload aborted.'
            );
        }

        // Compute SHA-256. We need the file contents — for local FS we can
        // hash the path directly; for S3 we stream through a hash context.
        // BL-27 fix: the old code used a placeholder '000...0' for S3 uploads,
        // which broke dedup detection and audit. Now we compute the real hash
        // by streaming the file through a hash context.
        $sha256 = '';
        if (is_string($finalPath) && is_file($finalPath)) {
            $h = hash_file('sha256', $finalPath);
            if ($h !== false) $sha256 = $h;
        }
        if ($sha256 === '') {
            // Fallback: stream the file from storage and hash it.
            $sha256 = $this->computeSha256FromStorage($userId, $storedFilename);
        }

        // Scan the assembled file.
        $scanResult = ['status' => 'skipped', 'message' => 'Scan not run for chunked upload.'];
        if ($this->clamav !== null && is_string($finalPath) && is_file($finalPath)) {
            $scanResult = $this->clamav->scan($finalPath);
        }

        // Persist as a documents row.
        $id = $this->uuid();
        Database::run(
            'INSERT INTO documents
                (id, user_id, original_filename, stored_filename, mime_type, size_bytes,
                 purpose, sha256, scan_status, scan_message, detected_mime,
                 created_at, updated_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())',
            [
                $id, $userId,
                $row['original_filename'],
                $storedFilename,
                $row['intended_mime'],
                $actualSize,
                $row['purpose'],
                $sha256,
                $scanResult['status'],
                $scanResult['message'],
                $detectedMime ?? $row['intended_mime'],
            ]
        );

        // Mark upload session complete + clean up chunks.
        Database::run(
            'UPDATE document_uploads
             SET status = "completed", received_chunks = ?, completed_at = NOW(), updated_at = NOW()
             WHERE id = ?',
            [$totalChunks, $uploadId]
        );
        $this->storage->abortChunkedUpload($uploadId);

        return $this->getById($id, $userId);
    }

    /**
     * Abort a chunked upload session. Deletes all staged chunks.
     */
    public function abortChunkedUpload(string $uploadId, string $userId): void
    {
        $row = Database::run(
            'SELECT user_id, status FROM document_uploads WHERE id = ? LIMIT 1',
            [$uploadId]
        )->fetch();
        if ($row === false) return;
        if ($row['user_id'] !== $userId) {
            throw new RuntimeException('Upload session does not belong to this user.');
        }
        $this->storage->abortChunkedUpload($uploadId);
        Database::run(
            'UPDATE document_uploads SET status = "abandoned", updated_at = NOW() WHERE id = ?',
            [$uploadId]
        );
    }

    // -----------------------------------------------------------------
    // Read + delete (unchanged from v0.7.0 except for StorageInterface swap)
    // -----------------------------------------------------------------

    public function listForUser(string $userId, ?string $purpose = null): array
    {
        if ($purpose !== null) {
            $rows = Database::run(
                'SELECT id, user_id, original_filename, stored_filename, mime_type,
                        size_bytes, purpose, sha256, scan_status, scan_message, detected_mime,
                        created_at, updated_at, deleted_at
                 FROM documents
                 WHERE user_id = ? AND deleted_at IS NULL AND purpose = ?
                 ORDER BY created_at DESC',
                [$userId, $purpose]
            )->fetchAll();
        } else {
            $rows = Database::run(
                'SELECT id, user_id, original_filename, stored_filename, mime_type,
                        size_bytes, purpose, sha256, scan_status, scan_message, detected_mime,
                        created_at, updated_at, deleted_at
                 FROM documents
                 WHERE user_id = ? AND deleted_at IS NULL
                 ORDER BY created_at DESC',
                [$userId]
            )->fetchAll();
        }
        return array_map(fn($r) => $this->rowToDto($r), $rows);
    }

    public function getById(string $id, string $userId): ?array
    {
        $row = Database::run(
            'SELECT id, user_id, original_filename, stored_filename, mime_type,
                    size_bytes, purpose, sha256, scan_status, scan_message, detected_mime,
                    created_at, updated_at, deleted_at
             FROM documents
             WHERE id = ? AND user_id = ? AND deleted_at IS NULL
             LIMIT 1',
            [$id, $userId]
        )->fetch();
        return $row === false ? null : $this->rowToDto($row);
    }

    /**
     * PHP-043 fix: removed dead `stream(string $id, string $userId): bool` method.
     * It was superseded by `streamByDoc(array $doc): bool` in the PERF-25 fix.
     * The controller now calls `getById()` once and passes the doc DTO to
     * `streamByDoc()`, avoiding the redundant SELECT that `stream()` performed
     * internally. The old method is no longer called by any controller.
     */

    /**
     * PERF-25 fix: new method that accepts a pre-fetched doc DTO so the
     * controller doesn't need to call getById() twice (once for headers,
     * once for streaming).
     */
    public function streamByDoc(array $doc): bool
    {
        return $this->storage->stream($doc['userId'], $doc['storedFilename']);
    }

    /**
     * PHP-024 fix: check whether the underlying file bytes still exist on disk
     * (or in S3) for a given document DTO. Used by DocumentController::download
     * BEFORE sending HTTP headers so a missing file returns a clean 404 JSON
     * response instead of a 200 OK with Content-Length and an empty body that
     * hangs the browser until timeout.
     *
     * @param array $doc  Document DTO (must contain 'userId' and 'storedFilename').
     * @return bool True if the file exists in the storage backend.
     */
    public function docExists(array $doc): bool
    {
        return $this->storage->exists($doc['userId'], $doc['storedFilename']);
    }

    public function delete(string $id, string $userId): void
    {
        $doc = $this->getById($id, $userId);
        if ($doc === null) {
            throw new RuntimeException('Document not found.');
        }
        Database::run(
            'UPDATE documents SET deleted_at = NOW(), updated_at = NOW() WHERE id = ?',
            [$id]
        );
    }

    /**
     * Hard-delete all documents for a user. Called by AdminService::deleteUser
     * (GDPR right to erasure). Also deletes the file bytes from Storage.
     *
     * @return int Number of documents hard-deleted.
     */
    public function hardDeleteForUser(string $userId): int
    {
        $rows = Database::run(
            'SELECT id, stored_filename FROM documents WHERE user_id = ?',
            [$userId]
        )->fetchAll();
        foreach ($rows as $row) {
            try {
                $this->storage->delete($userId, $row['stored_filename']);
            } catch (\Throwable $e) {
                error_log('[busifirm] Storage delete failed for doc ' . $row['id'] . ': ' . $e->getMessage());
            }
        }
        Database::run('DELETE FROM documents WHERE user_id = ?', [$userId]);
        return count($rows);
    }

    // -----------------------------------------------------------------
    // Helpers
    // -----------------------------------------------------------------

    /**
     * Detect MIME via finfo_file(). Returns null if ext-fileinfo is missing.
     */
    private function detectMime(string $tmpPath): ?string
    {
        if (!function_exists('finfo_open')) return null;
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        if ($finfo === false) return null;
        try {
            $mime = finfo_file($finfo, $tmpPath);
            return $mime === false ? null : (string)$mime;
        } finally {
            finfo_close($finfo);
        }
    }

    /**
     * Detect MIME for a file in storage. For LocalStorage we can read the
     * path directly; for S3 we'd need to download a sample first. KISS:
     * only support local for now — chunked uploads to S3 fall back to
     * the intended MIME.
     */
    private function detectMimeFromStorage(string $userId, string $storedFilename): ?string
    {
        // We rely on the storage backend's save() returning a local path
        // for LocalStorage. For S3Storage, this returns the object key —
        // not a local path — so finfo_file() fails. We catch and return null.
        // Phase 4+ will add a storage->localTmpPath() method.
        try {
            $path = $this->storage->exists($userId, $storedFilename) ? null : null;
            // We don't have the path here — for local FS the path is deterministic.
            // KISS: read via Storage::stream() into a tmp file and finfo that.
            $tmp = tempnam(sys_get_temp_dir(), 'busifirm_mime_');
            if ($tmp === false) return null;
            try {
                // Use a buffer-based approach: stream to a tmp file, then finfo.
                ob_start();
                $ok = $this->storage->stream($userId, $storedFilename);
                $buf = ob_get_clean();
                if (!$ok || $buf === false) return null;
                file_put_contents($tmp, $buf);
                return $this->detectMime($tmp);
            } finally {
                @unlink($tmp);
            }
        } catch (\Throwable $e) {
            return null;
        }
    }

    /**
     * Run ClamAV scan on the tmp file. Returns a default 'skipped' result
     * if no scanner is configured.
     */
    private function scanFile(string $tmpPath): array
    {
        if ($this->clamav === null) {
            return ['status' => 'skipped', 'message' => 'ClamAV not configured.'];
        }
        return $this->clamav->scan($tmpPath);
    }

    /**
     * Compute SHA-256 of a file in storage by streaming it through a hash
     * context. Works for both LocalStorage and S3Storage.
     *
     * BL-27 fix: replaces the placeholder '000...0' that was used for S3
     * chunked uploads.
     */
    private function computeSha256FromStorage(string $userId, string $storedFilename): string
    {
        try {
            $ctx = hash_init('sha256');
            // Use output buffering to capture the streamed file, then feed
            // it to the hash context. This avoids loading the entire file
            // into a single string.
            ob_start();
            $ok = $this->storage->stream($userId, $storedFilename);
            $buf = ob_get_clean();
            if (!$ok || $buf === false) {
                return str_repeat('0', 64);  // fallback if streaming fails
            }
            hash_update($ctx, $buf);
            return hash_final($ctx);
        } catch (\Throwable $e) {
            return str_repeat('0', 64);  // fallback on any error
        }
    }

    private function rowToDto(array $r): array
    {
        return [
            'id' => $r['id'],
            'userId' => $r['user_id'],
            'originalFilename' => $r['original_filename'],
            'storedFilename' => $r['stored_filename'],
            'mimeType' => $r['mime_type'],
            'detectedMime' => $r['detected_mime'] ?? null,
            'sizeBytes' => (int)$r['size_bytes'],
            'sizeHuman' => $this->formatBytes((int)$r['size_bytes']),
            'purpose' => $r['purpose'],
            'sha256' => $r['sha256'],
            'scanStatus' => $r['scan_status'] ?? 'skipped',
            'scanMessage' => $r['scan_message'] ?? null,
            'createdAt' => date(DATE_ATOM, strtotime($r['created_at'])),
            'downloadUrl' => '/api/documents/' . $r['id'],
        ];
    }

    private function sanitizeFilename(string $name): string
    {
        // PHP-051 fix: replaced \s with a literal space in the character class.
        // The old regex allowed \s (which includes \n, \r, \t) — a filename with
        // embedded newlines could break the Content-Disposition header. Also
        // collapse multiple spaces into one.
        $clean = preg_replace('/[^\p{L}\p{N}._\- ]/u', '', $name) ?? $name;
        $clean = preg_replace('/\s+/', ' ', $clean) ?? $clean;
        return mb_substr(trim($clean), 0, 255);
    }

    private function sanitizePurpose(string $purpose): string
    {
        $clean = preg_replace('/[^a-z0-9_]/', '', strtolower($purpose)) ?? 'general';
        return mb_substr($clean, 0, 50) ?: 'general';
    }

    private function formatBytes(int $bytes): string
    {
        if ($bytes < 1024) return $bytes . ' B';
        if ($bytes < 1048576) return round($bytes / 1024, 1) . ' KB';
        return round($bytes / 1048576, 1) . ' MB';
    }

    private function uploadErrorMessage(int $code): string
    {
        return match ($code) {
            UPLOAD_ERR_INI_SIZE => 'File exceeds the server\'s upload_max_filesize limit.',
            UPLOAD_ERR_FORM_SIZE => 'File exceeds the form\'s MAX_FILE_SIZE limit.',
            UPLOAD_ERR_PARTIAL => 'File was only partially uploaded.',
            UPLOAD_ERR_NO_FILE => 'No file was uploaded.',
            UPLOAD_ERR_NO_TMP_DIR => 'Server is missing a temporary folder.',
            UPLOAD_ERR_CANT_WRITE => 'Server failed to write the file to disk.',
            UPLOAD_ERR_EXTENSION => 'A PHP extension blocked the upload.',
            default => 'Unknown upload error.',
        };
    }

    private function uuid(): string
    {
        $bytes = random_bytes(16);
        $bytes[6] = chr((ord($bytes[6]) & 0x0f) | 0x40);
        $bytes[8] = chr((ord($bytes[8]) & 0x3f) | 0x80);
        return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($bytes), 4));
    }
}
