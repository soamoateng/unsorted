<?php
declare(strict_types=1);

namespace Busifirm\Services;

use Busifirm\Core\Database;
use RuntimeException;

/**
 * IntegrationService — post-acquisition integration task tracking.
 *
 * KISS: one row per user with tasks as a JSON array. This is a single
 * document, not a collection — normalizing would add a table for no gain
 * until we need cross-user task analytics.
 */
final class IntegrationService
{
    public function getForUser(string $userId): array
    {
        $row = Database::run(
            'SELECT user_id, tasks, last_updated, created_at
             FROM integrations
             WHERE user_id = ?
             LIMIT 1',
            [$userId]
        )->fetch();
        if ($row === false) {
            // PHP-017 fix: the old code did a plain INSERT here to lazy-init
            // an empty task list. Two concurrent createTask() calls (e.g.
            // double-click) both called getForUser, both saw no row, both
            // INSERTed, and the second failed on the PRIMARY KEY(user_id)
            // constraint → unhandled PDOException → 500.
            //
            // Fix: use INSERT IGNORE — if another thread already created the
            // row, the INSERT is silently skipped. We then re-SELECT to get
            // the row (whichever thread created it).
            Database::run(
                'INSERT IGNORE INTO integrations (user_id, tasks, last_updated, created_at)
                 VALUES (?, ?, NOW(), NOW())',
                [$userId, json_encode([], JSON_UNESCAPED_UNICODE)]
            );
            // Re-SELECT to get the row (either ours or the other thread's).
            $row = Database::run(
                'SELECT user_id, tasks, last_updated, created_at
                 FROM integrations
                 WHERE user_id = ?
                 LIMIT 1',
                [$userId]
            )->fetch();
            if ($row === false) {
                // Extremely unlikely: the row was deleted between INSERT IGNORE
                // and SELECT. Return the default empty state.
                return ['userId' => $userId, 'tasks' => [], 'lastUpdated' => date(DATE_ATOM)];
            }
        }
        return [
            'userId' => $row['user_id'],
            'tasks' => json_decode($row['tasks'] ?? '[]', true) ?: [],
            'lastUpdated' => date(DATE_ATOM, strtotime($row['last_updated'])),
        ];
    }

    public function updateTask(string $userId, string $taskId, array $updates): array
    {
        $data = $this->getForUser($userId);
        $tasks = $data['tasks'];
        $task = null;
        foreach ($tasks as &$t) {
            if ($t['id'] === $taskId) {
                $task = &$t;
                break;
            }
        }
        unset($t);
        if ($task === null) {
            throw new RuntimeException('Task not found.');
        }
        foreach (['name', 'progress', 'status', 'category'] as $f) {
            if (array_key_exists($f, $updates)) {
                if ($f === 'progress') {
                    // SEC-23 fix: validate progress range (0-100).
                    $progress = (int)$updates[$f];
                    if ($progress < 0 || $progress > 100) {
                        throw new RuntimeException('Progress must be between 0 and 100.');
                    }
                    $task[$f] = $progress;
                } else {
                    $task[$f] = (string)$updates[$f];
                }
            }
        }
        Database::run(
            'UPDATE integrations SET tasks = ?, last_updated = NOW() WHERE user_id = ?',
            [json_encode($tasks, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE), $userId]
        );
        return $this->getForUser($userId);
    }

    public function createTask(string $userId, array $task): array
    {
        $data = $this->getForUser($userId);
        $tasks = $data['tasks'];
        // SEC-23 fix: validate progress range on create too.
        $progress = (int)($task['progress'] ?? 0);
        if ($progress < 0 || $progress > 100) {
            throw new RuntimeException('Progress must be between 0 and 100.');
        }
        $tasks[] = [
            'id' => $this->uuid(),
            'name' => (string)$task['name'],
            'progress' => $progress,
            'status' => (string)($task['status'] ?? 'in-progress'),
            'category' => (string)($task['category'] ?? 'it'),
        ];
        Database::run(
            'UPDATE integrations SET tasks = ?, last_updated = NOW() WHERE user_id = ?',
            [json_encode($tasks, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE), $userId]
        );
        return $this->getForUser($userId);
    }

    private function uuid(): string
    {
        $bytes = random_bytes(16);
        $bytes[6] = chr((ord($bytes[6]) & 0x0f) | 0x40);
        $bytes[8] = chr((ord($bytes[8]) & 0x3f) | 0x80);
        return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($bytes), 4));
    }
}
