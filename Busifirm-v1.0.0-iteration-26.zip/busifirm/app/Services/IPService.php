<?php
declare(strict_types=1);

namespace Busifirm\Services;

use Busifirm\Core\Database;

/**
 * IPService — read-only catalog of intellectual property for sale.
 *
 * IPs are system-seeded (see migration 20260904_002). Phase 2+ may allow
 * sellers to list their own IPs; until then this service is read-only.
 *
 * KISS: no repository, no DTOs. Search uses MySQL FULLTEXT index where
 * possible and falls back to LIKE for sector/type filters.
 */
final class IPService
{
    public function search(?string $query, array $filters = []): array
    {
        $sql = 'SELECT id, name, type, price, sector, owner, description, status, created_at FROM ips';
        $where = [];
        $params = [];

        if ($query !== null && $query !== '') {
            $where[] = '(MATCH(name, owner, description) AGAINST (? IN NATURAL LANGUAGE MODE)
                         OR name LIKE ? OR owner LIKE ? OR description LIKE ?)';
            $params[] = $query;
            $params[] = '%' . $query . '%';
            $params[] = '%' . $query . '%';
            $params[] = '%' . $query . '%';
        }
        if (!empty($filters['sector'])) {
            $where[] = 'sector = ?';
            $params[] = $filters['sector'];
        }
        if (!empty($filters['type'])) {
            $where[] = 'type = ?';
            $params[] = $filters['type'];
        }

        if ($where) {
            $sql .= ' WHERE ' . implode(' AND ', $where);
        }
        $sql .= ' ORDER BY created_at ASC';
        // PERF-16 fix: add LIMIT 500 to prevent unbounded result sets.
        $sql .= ' LIMIT 500';

        $rows = Database::run($sql, $params)->fetchAll();
        return array_map(fn($r) => $this->rowToDto($r), $rows);
    }

    public function getAll(): array
    {
        return $this->search(null);
    }

    public function getById(string $id): ?array
    {
        $row = Database::run(
            'SELECT id, name, type, price, sector, owner, description, status, created_at
             FROM ips WHERE id = ? LIMIT 1',
            [$id]
        )->fetch();
        return $row === false ? null : $this->rowToDto($row);
    }

    private function rowToDto(array $r): array
    {
        return [
            'id' => $r['id'],
            'name' => $r['name'],
            'type' => $r['type'],
            'price' => (int)$r['price'],
            'sector' => $r['sector'],
            'owner' => $r['owner'],
            'description' => $r['description'],
            'status' => $r['status'],
            'createdAt' => date(DATE_ATOM, strtotime($r['created_at'])),
        ];
    }
}
