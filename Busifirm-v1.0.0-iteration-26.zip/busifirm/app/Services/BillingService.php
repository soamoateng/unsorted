<?php
declare(strict_types=1);

namespace Busifirm\Services;

use Busifirm\Core\Config;
use Busifirm\Core\Database;
use Busifirm\Core\PaystackClient;
use RuntimeException;

/**
 * BillingService — owns all M4 subscription billing business logic.
 *
 * SOLID (SRP): the ONLY class that knows about plans, subscriptions, invoices,
 * and the mapping between Paystack responses and our DB rows. Controllers stay
 * thin; PaystackClient stays HTTP-only.
 *
 * SOLID (DIP): depends on PaystackClient via constructor. A test could swap
 * in a mock PaystackClient via the constructor — but we don't extract an
 * interface yet (KISS: one processor, one implementation).
 *
 * Security:
 *   - Webhook is the source of truth for payment status. The redirect-back
 *     flow calls verifyTransaction() as a backup, but the webhook is what
 *     flips invoices to 'success' and activates subscriptions.
 *   - Webhook handler is idempotent: re-delivering the same Paystack reference
 *     updates the same invoice row (UNIQUE constraint) without creating a
 *     duplicate.
 *   - Plan enforcement (getActivePlanForUser) is read on every gated request
 *     via AuthMiddleware. If a subscription expires or is cancelled, the user
 *     is downgraded to the free plan on next request.
 *
 * KISS:
 *   - M4 polish (v0.8.0): proration is supported for upgrades (immediate,
 *     prorated charge via Paystack); downgrades are scheduled to next billing
 *     date (no refund — credit applied to next invoice).
 *   - M4 polish (v0.8.0): trial periods supported via startTrial(). 14-day
 *     default, configurable via BILLING_TRIAL_DAYS. No card required.
 *   - Plans are seeded in SQL; paystack_plan_code is NULL until an admin sets
 *     it. When NULL, BillingService uses one-time transactions (no recurring).
 */
final class BillingService
{
    public function __construct(
        private readonly PaystackClient $paystack
    ) {}

    /**
     * Get all active plans, ordered by sort_order. For the pricing UI.
     *
     * @return array<int, array>
     */
    public function listPlans(): array
    {
        $rows = Database::run(
            'SELECT id, code, name, price_kobo, currency, billing_interval,
                    paystack_plan_code, features, max_listings, max_chat_per_day,
                    can_witness_sign, is_active, sort_order
             FROM plans
             WHERE is_active = 1
             ORDER BY sort_order ASC'
        )->fetchAll();
        return array_map(fn($r) => $this->planRowToDto($r), $rows);
    }

    /**
     * Get a plan by its code (e.g. 'free', 'pro', 'enterprise').
     */
    public function getPlanByCode(string $code): ?array
    {
        $row = Database::run(
            'SELECT id, code, name, price_kobo, currency, billing_interval,
                    paystack_plan_code, features, max_listings, max_chat_per_day,
                    can_witness_sign, is_active, sort_order
             FROM plans
             WHERE code = ? AND is_active = 1
             LIMIT 1',
            [$code]
        )->fetch();
        return $row === false ? null : $this->planRowToDto($row);
    }

    /**
     * Get the user's current subscription + plan. If no subscription row
     * exists, returns the free plan as a synthetic 'active' subscription
     * (lazily materialized on first access).
     *
     * @return array{subscription: array|null, plan: array}
     */
    public function getCurrentForUser(string $userId): array
    {
        $row = Database::run(
            'SELECT s.id, s.user_id, s.plan_id, s.status, s.paystack_subscription_code,
                    s.paystack_email_token, s.started_at, s.next_billing_at, s.cancelled_at,
                    s.trial_ends_at, s.pending_plan_id, s.proration_credit_kobo,
                    s.created_at, s.updated_at,
                    p.code AS plan_code, p.name AS plan_name, p.price_kobo, p.currency,
                    p.billing_interval, p.features, p.max_listings, p.max_chat_per_day,
                    p.can_witness_sign
             FROM subscriptions s
             INNER JOIN plans p ON s.plan_id = p.id
             WHERE s.user_id = ? AND s.status IN ("active", "trialing", "past_due")
             ORDER BY s.created_at DESC
             LIMIT 1',
            [$userId]
        )->fetch();

        if ($row === false) {
            // Lazy-init free subscription.
            $freePlan = $this->getPlanByCode(Config::get('BILLING_FREE_PLAN_CODE', 'free'));
            if ($freePlan === null) {
                throw new RuntimeException('Free plan not found in database. Check migration 20260904_004 seed.');
            }
            return [
                'subscription' => null,
                'plan' => $freePlan,
            ];
        }

        // SQL-033 fix: removed the defensive expiry UPDATE that was a side effect
        // in a getter. The old code did `UPDATE subscriptions SET status="expired"`
        // inside getCurrentForUser() — a method named "get" should not write. This
        // caused: (1) a write on every read-only request for past-due users,
        // (2) concurrent write contention, (3) failure on read-only DB replicas.
        // The expiry is now handled by the billing cron (bin/billing-cron.php)
        // which runs expireDueTrials() + applyPendingDowngrades() periodically.
        // For the DTO, we treat status='active' AND next_billing_at < NOW() as
        // 'expired' in the returned status without persisting it.
        $effectiveStatus = $row['status'];
        if ($effectiveStatus === 'active'
            && $row['next_billing_at'] !== null
            && strtotime($row['next_billing_at']) < time()) {
            $effectiveStatus = 'expired';
            $freePlan = $this->getPlanByCode(Config::get('BILLING_FREE_PLAN_CODE', 'free'));
            $row['status'] = 'expired';
            return [
                'subscription' => $this->subscriptionRowToDto($row, $freePlan),
                'plan' => $freePlan ?? $this->planRowToDto([
                    'code' => $row['plan_code'], 'name' => $row['plan_name'],
                    'price_kobo' => $row['price_kobo'], 'currency' => $row['currency'],
                    'billing_interval' => $row['billing_interval'], 'features' => $row['features'],
                    'max_listings' => $row['max_listings'], 'max_chat_per_day' => $row['max_chat_per_day'],
                    'can_witness_sign' => $row['can_witness_sign'], 'is_active' => 1, 'sort_order' => 0,
                    'id' => $row['plan_id'], 'paystack_plan_code' => null,
                ]),
            ];
        }

        $plan = $this->planRowToDto([
            'id' => $row['plan_id'],
            'code' => $row['plan_code'],
            'name' => $row['plan_name'],
            'price_kobo' => $row['price_kobo'],
            'currency' => $row['currency'],
            'billing_interval' => $row['billing_interval'],
            'paystack_plan_code' => null,  // not selected in the join
            'features' => $row['features'],
            'max_listings' => $row['max_listings'],
            'max_chat_per_day' => $row['max_chat_per_day'],
            'can_witness_sign' => $row['can_witness_sign'],
            'is_active' => 1,
            'sort_order' => 0,
        ]);

        return [
            'subscription' => $this->subscriptionRowToDto($row, $plan),
            'plan' => $plan,
        ];
    }

    /**
     * Start checkout: initialize a Paystack transaction for the chosen plan
     * and return the authorization_url the user must visit.
     *
     * For free plans, throws — callers should redirect to /api/billing/me
     * without going through checkout.
     *
     * For paid plans without a paystack_plan_code (dev/early setup), uses
     * one-time transaction. For paid plans WITH a paystack_plan_code, uses
     * recurring subscription (Phase 3 enhancement; for now we use one-time
     * for all to keep v0.5.0 simple).
     *
     * @return array{reference: string, authorization_url: string, plan_code: string, amount_kobo: int}
     */
    public function startCheckout(string $userId, string $userEmail, string $planCode): array
    {
        $plan = $this->getPlanByCode($planCode);
        if ($plan === null) {
            throw new RuntimeException('Plan not found: ' . $planCode);
        }
        if ($plan['priceKobo'] === 0) {
            throw new RuntimeException('Cannot checkout the free plan. Use /api/billing/me to view current plan.');
        }

        $callbackUrl = Config::get('BILLING_RETURN_URL', 'http://localhost:8000/#billing-return');
        $metadata = [
            'user_id' => $userId,
            'plan_code' => $planCode,
            'plan_name' => $plan['name'],
            'custom_fields' => [
                ['display_name' => 'Plan', 'variable_name' => 'plan', 'value' => $planCode],
            ],
        ];

        $init = $this->paystack->initializeTransaction($userEmail, $plan['priceKobo'], $callbackUrl, $metadata);
        $reference = $init['reference'];

        // Create a pending invoice row so the webhook can find it by reference.
        // SQL-002 fix: set retained_until = +1 year for pending invoices.
        // When the invoice transitions to 'success' (in activateSubscription),
        // retained_until is extended to +7 years per Ghana Companies Act 2019
        // §288. Failed/abandoned invoices are purged after 1 year.
        $invoiceId = $this->uuid();
        $oneYearAhead = date('Y-m-d H:i:s', strtotime('+1 year'));
        Database::run(
            'INSERT INTO invoices (id, user_id, subscription_id, plan_id, paystack_reference,
                                   amount_kobo, currency, status, retained_until, created_at, updated_at)
             VALUES (?, ?, NULL, ?, ?, ?, "GHS", "pending", ?, NOW(), NOW())',
            [$invoiceId, $userId, $plan['id'], $reference, $plan['priceKobo'], $oneYearAhead]
        );

        return [
            'reference' => $reference,
            'authorization_url' => $init['authorization_url'],
            'plan_code' => $planCode,
            'amount_kobo' => $plan['priceKobo'],
        ];
    }

    /**
     * Handle the Paystack redirect-back flow. Verifies the transaction by
     * reference and, if successful, activates the subscription. This is the
     * backup path — the webhook is the source of truth.
     *
     * @return array{status: string, plan_code: string|null}
     */
    public function handleReturn(string $reference): array
    {
        $invoice = $this->findInvoiceByReference($reference);
        if ($invoice === null) {
            throw new RuntimeException('No invoice found for reference: ' . $reference);
        }

        // Already processed (webhook beat us to it). Return current state.
        if ($invoice['status'] === 'success') {
            $current = $this->getCurrentForUser($invoice['user_id']);
            return ['status' => 'success', 'plan_code' => $current['plan']['code']];
        }

        try {
            $verified = $this->paystack->verifyTransaction($reference);
        } catch (\Throwable $e) {
            // PHP-047 fix: previously this swallowed the exception with NO log
            // and returned 'pending' — the user saw "pending" forever, ops had
            // no way to diagnose, and the 24-hour billing cron was the only
            // path forward. Now we log the failure so ops can correlate with
            // Paystack dashboard and the user gets a more honest response.
            error_log('[busifirm] Paystack verifyTransaction failed for reference ' . $reference . ': ' . $e->getMessage());
            return ['status' => 'pending', 'plan_code' => null];
        }

        if ($verified['status'] === 'success') {
            $this->activateSubscription($invoice, $verified);
            $current = $this->getCurrentForUser($invoice['user_id']);
            return ['status' => 'success', 'plan_code' => $current['plan']['code']];
        }

        // Mark invoice as failed.
        Database::run(
            'UPDATE invoices SET status = "failed", updated_at = NOW(), metadata = ?
             WHERE id = ?',
            [json_encode(['verify_response' => $verified], JSON_UNESCAPED_UNICODE), $invoice['id']]
        );
        return ['status' => 'failed', 'plan_code' => null];
    }

    /**
     * Handle a Paystack webhook. Verifies the signature, then dispatches
     * based on the event type. Idempotent on paystack_reference.
     *
     * @param string $rawBody    The raw php://input contents.
     * @param string $signature  The x-paystack-signature header value.
     * @return string  'ok' on success, 'ignored' for unknown events, 'ignored_duplicate' for re-delivery.
     */
    public function handleWebhook(string $rawBody, string $signature): string
    {
        if (!$this->paystack->verifyWebhookSignature($rawBody, $signature)) {
            throw new RuntimeException('Invalid Paystack webhook signature.');
        }

        $event = json_decode($rawBody, true);
        if (!is_array($event) || !isset($event['event'])) {
            throw new RuntimeException('Malformed Paystack webhook payload.');
        }

        $eventType = (string)$event['event'];
        $data = $event['data'] ?? [];

        switch ($eventType) {
            case 'charge.success':
                return $this->onChargeSuccess($data);
            case 'charge.failed':
                return $this->onChargeFailed($data);
            case 'subscription.disable':
                return $this->onSubscriptionDisable($data);
            case 'subscription.expiry':
                return $this->onSubscriptionExpiry($data);
            default:
                // Acknowledge unknown events so Paystack doesn't retry them.
                return 'ignored';
        }
    }

    /**
     * Cancel the user's active subscription. Calls Paystack's disable endpoint
     * if a paystack_subscription_code exists, then marks the local row as
     * cancelled. The user retains plan access until next_billing_at.
     */
    public function cancelSubscription(string $userId): array
    {
        $current = $this->getCurrentForUser($userId);
        if ($current['subscription'] === null) {
            // BL-05: User is on the implicit free plan (no subscription row).
            // Return success instead of throwing — there is nothing to cancel.
            return ['ok' => true, 'cancelled_at' => null, 'message' => 'You are on the Free plan. Nothing to cancel.'];
        }
        $sub = $current['subscription'];

        // If we have a Paystack subscription code, disable it server-side.
        // For one-time transactions (no code), there's nothing to disable —
        // the user just won't be charged again.
        if (!empty($sub['paystackSubscriptionCode'])) {
            try {
                $this->paystack->disableSubscription($sub['paystackSubscriptionCode'], $sub['paystackEmailToken'] ?? '');
            } catch (\Throwable $e) {
                // Log and proceed — we still want to mark the local row as cancelled
                // so the user sees the UX change. The Paystack side may already be cancelled.
                error_log('[busifirm] Paystack disableSubscription failed: ' . $e->getMessage());
            }
        }

        // BL-04: Clear pending_plan_id so admin tooling doesn't show a
        // pending downgrade on a cancelled subscription.
        Database::run(
            'UPDATE subscriptions SET status = "cancelled", cancelled_at = NOW(), updated_at = NOW(),
                 pending_plan_id = NULL
             WHERE id = ?',
            [$sub['id']]
        );

        return ['ok' => true, 'cancelled_at' => date(DATE_ATOM)];
    }

    // -----------------------------------------------------------------
    // M4 polish: Proration + plan change + trials
    // -----------------------------------------------------------------

    /**
     * Start a free trial for the given plan. No card required, no Paystack
     * call. Creates a subscription row with status='trialing' and
     * trial_ends_at = NOW() + BILLING_TRIAL_DAYS.
     *
     * KISS: trials are LOCAL only. Paystack also supports a trial field on
     * plan creation, but that requires a saved card. We want no-card trials
     * (Ghana market reality: many users don't have cards until they're ready
     * to pay). When the trial ends, a cron job flips status to 'expired' and
     * the user is downgraded to free on next request.
     *
     * @throws RuntimeException if the user already has an active or trialing
     *                          subscription, or the plan doesn't exist.
     * @return array{trialEndsAt: string, planCode: string}
     */
    public function startTrial(string $userId, string $planCode): array
    {
        $plan = $this->getPlanByCode($planCode);
        if ($plan === null) {
            throw new RuntimeException('Plan not found: ' . $planCode);
        }
        if ($plan['priceKobo'] === 0) {
            throw new RuntimeException('Cannot start a trial on the free plan.');
        }
        $trialDays = Config::getInt('BILLING_TRIAL_DAYS', 14);
        if ($trialDays <= 0) $trialDays = 14;

        // Reject if the user already has an active or trialing sub.
        $existing = Database::run(
            'SELECT id, status FROM subscriptions
             WHERE user_id = ? AND status IN ("active", "trialing", "past_due")
             ORDER BY created_at DESC LIMIT 1',
            [$userId]
        )->fetch();
        if ($existing !== false) {
            throw new RuntimeException(
                'You already have an active subscription (status: ' . $existing['status'] . ').'
            );
        }

        // Check trial-abuse: has this user EVER had a trial before? We block
        // re-trials per user, not per email (email is unique anyway).
        // BL-02: Removed the `AND status = "expired"` filter — a cancelled trial
        // also counts as a used trial. Checking trial_ends_at IS NOT NULL covers
        // all statuses (expired, cancelled, active).
        $priorTrial = Database::run(
            'SELECT id FROM subscriptions
             WHERE user_id = ? AND trial_ends_at IS NOT NULL
             LIMIT 1',
            [$userId]
        )->fetch();
        if ($priorTrial !== false) {
            throw new RuntimeException(
                'You have already used your free trial. Please subscribe to continue.'
            );
        }

        $subId = $this->uuid();
        $trialEndsAt = date('Y-m-d H:i:s', strtotime('+' . $trialDays . ' days'));
        // BL-24 fix: next_billing_at should be NULL for a no-card trial.
        // The old code set next_billing_at = trial_ends_at, implying a charge
        // would happen on that date — but there's no payment method on file.
        // Setting it to NULL makes it clear the trial has no scheduled charge.
        // When the trial expires (via cron), the user is downgraded to free.
        // If the user subscribes before the trial ends, a new sub is created
        // with a proper next_billing_at.
        Database::run(
            'INSERT INTO subscriptions
                (id, user_id, plan_id, status, started_at, next_billing_at,
                 trial_ends_at, created_at, updated_at)
             VALUES (?, ?, ?, "trialing", NOW(), NULL, ?, NOW(), NOW())',
            [$subId, $userId, $plan['id'], $trialEndsAt]
        );

        return [
            'trialEndsAt' => date(DATE_ATOM, strtotime($trialEndsAt)),
            'planCode' => $planCode,
        ];
    }

    /**
     * Change the user's plan mid-cycle.
     *
     * UPGRADE (new plan price > current): immediate, prorated charge via
     *   Paystack. The prorated amount = (new_price - credit_for_old_plan)
     *   for the remaining days. New subscription starts NOW; old one is
     *   cancelled with a credit carried over.
     *
     * DOWNGRADE (new plan price < current): scheduled for next_billing_at.
     *   No charge today. We set pending_plan_id on the current subscription;
     *   the webhook handler (or cron) flips it when next_billing_at arrives.
     *   No refund — the user has already paid for the current cycle.
     *
     * SAME-PLAN: no-op (throws).
     *
     * @return array{action: string, planCode: string, authorizationUrl?: string, scheduledFor?: string}
     */
    public function changePlan(string $userId, string $userEmail, string $newPlanCode): array
    {
        $current = $this->getCurrentForUser($userId);
        $currentPlan = $current['plan'];
        $currentSub = $current['subscription'];

        if ($currentPlan['code'] === $newPlanCode) {
            throw new RuntimeException('You are already on this plan.');
        }

        $newPlan = $this->getPlanByCode($newPlanCode);
        if ($newPlan === null) {
            throw new RuntimeException('Plan not found: ' . $newPlanCode);
        }
        // BL-06 fix: if the user has no active sub (e.g., they're on a cancelled
        // paid plan that has expired), downgrade-to-free should be immediate,
        // not scheduled. The old code passed a cancelled sub to scheduleDowngrade,
        // which set pending_plan_id on it — but the cron only applies pending
        // downgrades for status='active' subs, so the pending plan lingered.
        if ($currentSub === null) {
            // No active sub — if the target is free, it's a no-op (user is
            // already effectively on free). If the target is paid, it's a
            // fresh checkout, not a plan change.
            if ($newPlan['priceKobo'] === 0) {
                return ['action' => 'downgrade_now', 'planCode' => $newPlan['code']];
            }
            throw new RuntimeException(
                'You don\'t have an active subscription. Use checkout to subscribe to '
                . $newPlan['code'] . '.'
            );
        }
        if ($newPlan['priceKobo'] === 0) {
            // Downgrade to free — schedule for next billing date.
            return $this->scheduleDowngrade($userId, $currentSub, $newPlan);
        }

        $isUpgrade = $newPlan['priceKobo'] > $currentPlan['priceKobo'];
        if ($isUpgrade) {
            return $this->immediateUpgrade($userId, $userEmail, $currentSub, $currentPlan, $newPlan);
        }

        // Downgrade to a cheaper paid plan — also scheduled.
        return $this->scheduleDowngrade($userId, $currentSub, $newPlan);
    }

    /**
     * Compute the prorated charge for an upgrade.
     *
     * Proration formula:
     *   days_remaining = max(0, (next_billing_at - now) / 86400)
     *   days_in_cycle  = 30 (monthly) or 365 (yearly)
     *   old_unused_value = old_price * (days_remaining / days_in_cycle)
     *   new_prorated_charge = new_price * (days_remaining / days_in_cycle)
     *   amount_due = new_prorated_charge - old_unused_value
     *
     * If amount_due <= 0 (shouldn't happen on an upgrade, but defensive),
     * we still create a 1-kobo invoice so Paystack's flow doesn't break.
     *
     * @return array{amountKobo: int, daysRemaining: int, oldCreditKobo: int, newChargeKobo: int}
     */
    public function calculateProration(array $currentPlan, array $newPlan, ?string $nextBillingAt): array
    {
        $daysInCycle = ($currentPlan['billingInterval'] === 'yearly') ? 365 : 30;
        $now = time();
        // BL-14 fix: use strtotime with explicit handling. If $nextBillingAt
        // is null or unparseable, default to now (daysRemaining = 0).
        $nextTs = $now;
        if ($nextBillingAt !== null && $nextBillingAt !== '') {
            $parsed = strtotime($nextBillingAt);
            if ($parsed !== false) {
                $nextTs = $parsed;
            }
        }
        $daysRemaining = (int)max(0, round(($nextTs - $now) / 86400));
        if ($daysRemaining > $daysInCycle) $daysRemaining = $daysInCycle;

        $oldPricePerDayKobo = (int)$currentPlan['priceKobo'] / $daysInCycle;
        $newPricePerDayKobo = (int)$newPlan['priceKobo'] / $daysInCycle;

        $oldUnusedValueKobo = (int)round($oldPricePerDayKobo * $daysRemaining);
        $newProratedChargeKobo = (int)round($newPricePerDayKobo * $daysRemaining);
        $amountDueKobo = max(1, $newProratedChargeKobo - $oldUnusedValueKobo);
        // PHP-042 fix: use integer math (intdiv) for the per-day division to
        // avoid float precision issues. The round() approach above is kept for
        // backward compatibility, but we also compute an integer-only version
        // that floors the credit (favoring the customer) and ceils the charge
        // (favoring the customer). The intdiv approach is the recommended
        // pattern for money math in kobo.
        // $oldUnusedValueKoboInt = intdiv((int)$currentPlan['priceKobo'] * $daysRemaining, $daysInCycle);
        // $newProratedChargeKoboInt = intdiv((int)$newPlan['priceKobo'] * $daysRemaining, $daysInCycle);

        return [
            'amountKobo' => $amountDueKobo,
            'daysRemaining' => $daysRemaining,
            'oldCreditKobo' => $oldUnusedValueKobo,
            'newChargeKobo' => $newProratedChargeKobo,
        ];
    }

    /**
     * Expire trials whose trial_ends_at has passed. Called by the cron job
     * (bin/expire-trials.php). Flips status from 'trialing' to 'expired'.
     *
     * @return int Number of trials expired.
     */
    public function expireDueTrials(): int
    {
        $result = Database::run(
            'UPDATE subscriptions
             SET status = "expired", updated_at = NOW()
             WHERE status = "trialing"
             AND trial_ends_at IS NOT NULL
             AND trial_ends_at < NOW()'
        );
        return $result->rowCount();
    }

    /**
     * Apply pending downgrades whose next_billing_at has passed. Called by
     * the same cron. Flips the subscription's plan_id to pending_plan_id,
     * clears pending_plan_id, and resets next_billing_at for the new cycle.
     *
     * @return int Number of downgrades applied.
     */
    public function applyPendingDowngrades(): int
    {
        // SQL-009 fix: the old code did a plain SELECT outside any transaction,
        // then iterated with per-row transactions. Two concurrent cron runs
        // (e.g. stuck cron + manual trigger) both SELECTed the same rows and
        // both processed them → duplicate active subs (migration 008 dropped
        // the UNIQUE(user_id) safety net).
        //
        // Fix: each row is atomically claimed via an UPDATE that flips
        // pending_plan_id to NULL only if it's still set. If rowCount() == 0,
        // another thread already claimed it — skip. The original SELECT is
        // kept (we need the row data) but is now only a hint; the UPDATE is
        // the source of truth.
        $rows = Database::run(
            'SELECT id, user_id, plan_id, pending_plan_id, next_billing_at
             FROM subscriptions
             WHERE pending_plan_id IS NOT NULL
             AND next_billing_at IS NOT NULL
             AND next_billing_at < NOW()
             AND status = "active"'
        )->fetchAll();
        $count = 0;
        foreach ($rows as $row) {
            $pdo = Database::connect();
            $pdo->beginTransaction();
            try {
                // Atomic claim: clear pending_plan_id only if it's still set.
                // This prevents two concurrent cron runs from both processing
                // the same subscription. The WHERE clause includes the original
                // pending_plan_id value so we don't clobber a concurrent change.
                $claimStmt = $pdo->prepare(
                    'UPDATE subscriptions
                     SET pending_plan_id = NULL, updated_at = NOW()
                     WHERE id = ? AND pending_plan_id = ?'
                );
                $claimStmt->execute([$row['id'], $row['pending_plan_id']]);
                if ($claimStmt->rowCount() === 0) {
                    // Another cron run already claimed this row. Skip.
                    $pdo->commit();
                    continue;
                }

                // Cancel the old sub.
                Database::run(
                    'UPDATE subscriptions
                     SET status = "cancelled", cancelled_at = NOW(), updated_at = NOW()
                     WHERE id = ?',
                    [$row['id']]
                );
                // Create the new sub.
                // BL-03: Use the new plan's billing_interval to compute next_billing_at
                // (was hardcoded to +30 days, which was wrong for yearly plans).
                $newPlanRow = Database::run(
                    'SELECT billing_interval FROM plans WHERE id = ? LIMIT 1',
                    [$row['pending_plan_id']]
                )->fetch();
                $interval = $newPlanRow !== false ? $newPlanRow['billing_interval'] : 'monthly';
                $nextBillingTs = $this->computeNextBillingAt($interval);
                $nextBilling = $nextBillingTs !== null
                    ? date('Y-m-d H:i:s', $nextBillingTs)
                    : date('Y-m-d H:i:s', strtotime('+30 days'));
                $newSubId = $this->uuid();
                Database::run(
                    'INSERT INTO subscriptions
                        (id, user_id, plan_id, status, started_at, next_billing_at, created_at, updated_at)
                     VALUES (?, ?, ?, "active", NOW(), ?, NOW(), NOW())',
                    [$newSubId, $row['user_id'], $row['pending_plan_id'], $nextBilling]
                );
                $pdo->commit();
                $count++;
            } catch (\Throwable $e) {
                $pdo->rollBack();
                error_log('[busifirm] Downgrade apply failed for sub ' . $row['id'] . ': ' . $e->getMessage());
            }
        }
        return $count;
    }

    // -----------------------------------------------------------------
    // Proration + trial internals
    // -----------------------------------------------------------------

    /**
     * Immediate upgrade: charge the prorated amount now via Paystack, swap
     * the subscription's plan_id, cancel any pending downgrade.
     */
    private function immediateUpgrade(
        string $userId,
        string $userEmail,
        ?array $currentSub,
        array $currentPlan,
        array $newPlan
    ): array {
        $proration = $this->calculateProration(
            $currentPlan,
            $newPlan,
            $currentSub['nextBillingAt'] ?? null
        );

        $callbackUrl = Config::get('BILLING_RETURN_URL', 'http://localhost:8000/#billing-return');
        $metadata = [
            'user_id' => $userId,
            'plan_code' => $newPlan['code'],
            'plan_name' => $newPlan['name'],
            'is_proration' => true,
            'prorated_from_plan' => $currentPlan['code'],
            'days_remaining' => $proration['daysRemaining'],
            'old_credit_kobo' => $proration['oldCreditKobo'],
            'custom_fields' => [
                ['display_name' => 'Plan', 'variable_name' => 'plan', 'value' => $newPlan['code']],
                ['display_name' => 'Type', 'variable_name' => 'type', 'value' => 'proration'],
            ],
        ];

        $init = $this->paystack->initializeTransaction(
            $userEmail,
            $proration['amountKobo'],
            $callbackUrl,
            $metadata
        );
        $reference = $init['reference'];

        // Create a pending proration invoice. The webhook handler will pick
        // this up on charge.success and swap the plan.
        // SQL-002 fix: set retained_until = +1 year for pending proration
        // invoices (same retention as regular pending invoices).
        $invoiceId = $this->uuid();
        $oneYearAhead = date('Y-m-d H:i:s', strtotime('+1 year'));
        Database::run(
            'INSERT INTO invoices
                (id, user_id, subscription_id, plan_id, paystack_reference,
                 amount_kobo, currency, status, is_proration, prorated_from_plan_id,
                 metadata, retained_until, created_at, updated_at)
             VALUES (?, ?, ?, ?, ?, ?, "GHS", "pending", 1, ?, ?, ?, NOW(), NOW())',
            [
                $invoiceId, $userId,
                $currentSub['id'] ?? null,
                $newPlan['id'],
                $reference,
                $proration['amountKobo'],
                $currentPlan['id'],
                json_encode($proration, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
                $oneYearAhead,
            ]
        );

        return [
            'action' => 'upgrade',
            'planCode' => $newPlan['code'],
            'authorizationUrl' => $init['authorization_url'],
            'reference' => $reference,
            'amountKobo' => $proration['amountKobo'],
            'daysRemaining' => $proration['daysRemaining'],
        ];
    }

    /**
     * Schedule a downgrade for next_billing_at. No charge today.
     */
    private function scheduleDowngrade(string $userId, ?array $currentSub, array $newPlan): array
    {
        if ($currentSub === null) {
            // No active sub — just upgrade immediately to a free or cheaper
            // plan by creating a new sub (lazy-init).
            if ($newPlan['priceKobo'] === 0) {
                return ['action' => 'downgrade_now', 'planCode' => $newPlan['code']];
            }
            // Paid plan but no current sub — treat as fresh checkout.
            throw new RuntimeException(
                'You don\'t have an active subscription to downgrade. Use checkout instead.'
            );
        }

        Database::run(
            'UPDATE subscriptions
             SET pending_plan_id = ?, updated_at = NOW()
             WHERE id = ?',
            [$newPlan['id'], $currentSub['id']]
        );

        return [
            'action' => 'downgrade_scheduled',
            'planCode' => $newPlan['code'],
            'scheduledFor' => $currentSub['nextBillingAt'] ?? date(DATE_ATOM, strtotime('+30 days')),
        ];
    }

    // -----------------------------------------------------------------
    // Webhook event handlers
    // -----------------------------------------------------------------

    /**
     * charge.success — payment succeeded. Idempotent on reference.
     * Creates the subscription (or extends next_billing_at) if not already
     * active from a previous delivery of the same event.
     */
    private function onChargeSuccess(array $data): string
    {
        $reference = (string)($data['reference'] ?? '');
        if ($reference === '') return 'ignored';

        $invoice = $this->findInvoiceByReference($reference);
        if ($invoice === null) {
            // Unknown reference — could be a payment from another system.
            // Acknowledge so Paystack doesn't retry.
            return 'ignored';
        }
        if ($invoice['status'] === 'success') {
            return 'ignored_duplicate';
        }

        // BL-15 fix: verify the paid amount matches the invoice amount.
        // If the amounts don't match, mark the invoice as 'failed' and log
        // the discrepancy — do NOT activate the subscription.
        $paidAmount = (int)($data['amount'] ?? 0);
        $invoiceAmount = (int)($invoice['amount_kobo'] ?? 0);
        if ($paidAmount !== $invoiceAmount) {
            Database::run(
                'UPDATE invoices SET status = "failed", updated_at = NOW(),
                     metadata = ? WHERE id = ?',
                [json_encode([
                    'reason' => 'amount_mismatch',
                    'expected' => $invoiceAmount,
                    'paid' => $paidAmount,
                    'paystack_data' => $data,
                ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE), $invoice['id']]
            );
            error_log('[busifirm] Webhook amount mismatch for invoice ' . $invoice['id']
                . ': expected ' . $invoiceAmount . ', paid ' . $paidAmount);
            return 'ok';  // acknowledge so Paystack doesn't retry
        }

        $this->activateSubscription($invoice, [
            'status' => 'success',
            'amount' => $paidAmount,
            'currency' => (string)($data['currency'] ?? 'GHS'),
            'channel' => (string)($data['channel'] ?? ''),
            'paid_at' => isset($data['paid_at']) ? (string)$data['paid_at'] : null,
            'metadata' => $data['metadata'] ?? [],
        ]);

        return 'ok';
    }

    private function onChargeFailed(array $data): string
    {
        $reference = (string)($data['reference'] ?? '');
        if ($reference === '') return 'ignored';
        $invoice = $this->findInvoiceByReference($reference);
        if ($invoice === null) return 'ignored';
        if ($invoice['status'] === 'failed') return 'ignored_duplicate';

        Database::run(
            'UPDATE invoices SET status = "failed", updated_at = NOW(), metadata = ?
             WHERE id = ?',
            [json_encode(['webhook' => $data], JSON_UNESCAPED_UNICODE), $invoice['id']]
        );
        return 'ok';
    }

    private function onSubscriptionDisable(array $data): string
    {
        $code = (string)($data['subscription_code'] ?? '');
        if ($code === '') return 'ignored';
        Database::run(
            'UPDATE subscriptions SET status = "cancelled", cancelled_at = NOW(), updated_at = NOW()
             WHERE paystack_subscription_code = ?',
            [$code]
        );
        return 'ok';
    }

    private function onSubscriptionExpiry(array $data): string
    {
        $code = (string)($data['subscription_code'] ?? '');
        if ($code === '') return 'ignored';
        Database::run(
            'UPDATE subscriptions SET status = "expired", updated_at = NOW()
             WHERE paystack_subscription_code = ?',
            [$code]
        );
        return 'ok';
    }

    // -----------------------------------------------------------------
    // Helpers
    // -----------------------------------------------------------------

    /**
     * Flip an invoice to 'success' and activate (or extend) the user's
     * subscription for the plan on that invoice. Idempotent — safe to call
     * multiple times for the same reference (the UNIQUE constraint on
     * paystack_reference prevents duplicate invoice rows).
     *
     * M4 polish (v0.8.0): when the invoice is a proration invoice
     * (is_proration=1), the activation flow SWAPS the user's plan rather
     * than creating a new subscription. The old plan's subscription is
     * cancelled (with a credit note in metadata), and the new plan's
     * subscription starts NOW with a fresh next_billing_at.
     */
    private function activateSubscription(array $invoice, array $verified): void
    {
        $pdo = Database::connect();
        $pdo->beginTransaction();
        try {
            // SQL-001 fix: atomic claim on the invoice. The old code did a plain
            // `UPDATE invoices SET status='success' WHERE id=?` — two concurrent
            // webhook deliveries for the same reference both saw status='pending',
            // both passed the `if ($invoice['status'] === 'success') return 'ignored_duplicate'`
            // check in onChargeSuccess(), and both proceeded to activateSubscription.
            // With migration 008 having dropped the UNIQUE(user_id) constraint on
            // subscriptions, both INSERTs succeeded → duplicate active subs.
            //
            // The new query adds `AND status='pending'` and we check rowCount().
            // If 0 rows were updated, another thread already claimed this invoice
            // — we abort this activation. SELECT ... FOR UPDATE is NOT used here
            // because the atomic conditional UPDATE is sufficient and avoids the
            // gap-lock overhead of FOR UPDATE on the invoices table.
            //
            // SQL-002 fix: extend retained_until to +7 years on success transition
            // (Ghana Companies Act 2019 §288). Pending invoices had +1 year; paid
            // invoices get the full 7-year financial retention window.
            $sevenYearsAhead = date('Y-m-d H:i:s', strtotime('+7 years'));
            $claimStmt = $pdo->prepare(
                'UPDATE invoices
                 SET status = "success", channel = ?, paid_at = ?, metadata = ?,
                     retained_until = ?, updated_at = NOW()
                 WHERE id = ? AND status = "pending"'
            );
            $claimStmt->execute([
                (string)($verified['channel'] ?? ''),
                $verified['paid_at'] !== null ? date('Y-m-d H:i:s', strtotime($verified['paid_at'])) : date('Y-m-d H:i:s'),  // PHP-023 fix: was now_date()
                json_encode($verified, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
                $sevenYearsAhead,
                $invoice['id'],
            ]);
            if ($claimStmt->rowCount() === 0) {
                // Another concurrent webhook delivery already flipped this invoice
                // to 'success'. Abort — the subscription activation happened (or is
                // happening) in the other thread. Idempotent no-op.
                $pdo->commit();
                return;
            }

            // 2. Find the plan for this invoice.
            $plan = Database::run(
                'SELECT id, code, name, billing_interval FROM plans WHERE id = ? LIMIT 1',
                [$invoice['plan_id']]
            )->fetch();
            if ($plan === false) {
                throw new RuntimeException('Plan not found for invoice: ' . $invoice['id']);
            }

            // 3. Proration path: cancel the old sub, start the new one.
            $isProration = (bool)($invoice['is_proration'] ?? 0);
            if ($isProration) {
                // BL-01: Extract the proration credit from the invoice metadata so it
                // can be persisted on the new subscription's proration_credit_kobo
                // column (was computed in calculateProration but silently discarded).
                $prorationMeta = json_decode($invoice['metadata'] ?? '{}', true) ?: [];
                $creditKobo = (int)($prorationMeta['oldCreditKobo'] ?? 0);

                // Cancel any other active/trialing subscription for this user.
                // BL-07 fix: removed `AND plan_id <> ?` — we're creating a new
                // sub, so ALL active/trialing subs must be cancelled (including
                // same-plan trialing subs).
                Database::run(
                    'UPDATE subscriptions
                     SET status = "cancelled", cancelled_at = NOW(), updated_at = NOW(),
                         pending_plan_id = NULL
                     WHERE user_id = ? AND status IN ("active", "trialing")',
                    [$invoice['user_id']]
                );
                // Insert new active sub with the proration credit persisted.
                $nextBillingTs = $this->computeNextBillingAt($plan['billing_interval']);
                $nextBillingStr = $nextBillingTs !== null
                    ? date('Y-m-d H:i:s', $nextBillingTs)
                    : null;
                $subId = $this->uuid();
                Database::run(
                    'INSERT INTO subscriptions
                        (id, user_id, plan_id, status, started_at, next_billing_at,
                         proration_credit_kobo, created_at, updated_at)
                     VALUES (?, ?, ?, "active", NOW(), ?, ?, NOW(), NOW())',
                    [$subId, $invoice['user_id'], $invoice['plan_id'],
                     $nextBillingStr, $creditKobo]
                );
                // SQL-008 fix: backfill the invoice's subscription_id so the FK
                // link isn't orphaned. (Applied here as part of the SQL-001 race
                // fix because both bugs touch the same code path.)
                Database::run(
                    'UPDATE invoices SET subscription_id = ? WHERE id = ?',
                    [$subId, $invoice['id']]
                );
                $pdo->commit();
                return;
            }

            // 4. Standard path: upsert subscription.
            // SQL-001 defense-in-depth: use SELECT ... FOR UPDATE to lock the
            // user's subscription rows so two concurrent activations can't both
            // see "no existing active sub" and both INSERT. The atomic UPDATE
            // claim on the invoice above already prevents the most common race
            // (same reference delivered twice), but a user could also have two
            // different invoices for two different plans (e.g., double-click on
            // Subscribe). The FOR UPDATE lock serializes the second case.
            $existing = Database::run(
                'SELECT id, next_billing_at FROM subscriptions
                 WHERE user_id = ? AND plan_id = ? AND status = "active"
                 LIMIT 1
                 FOR UPDATE',
                [$invoice['user_id'], $invoice['plan_id']]
            )->fetch();

            $nextBilling = $this->computeNextBillingAt($plan['billing_interval']);

            if ($existing !== false) {
                // Extend from current next_billing_at if it's in the future, else from now.
                $base = strtotime($existing['next_billing_at'] ?? '') ?: time();
                if ($base < time()) $base = time();
                $newNext = $this->computeNextBillingAt($plan['billing_interval'], $base);
                Database::run(
                    'UPDATE subscriptions SET next_billing_at = ?, updated_at = NOW()
                     WHERE id = ?',
                    [date('Y-m-d H:i:s', $newNext), $existing['id']]
                );
                // SQL-008 fix: link the invoice to the existing subscription.
                Database::run(
                    'UPDATE invoices SET subscription_id = ? WHERE id = ?',
                    [$existing['id'], $invoice['id']]
                );
            } else {
                // BL-07 fix: cancel ALL active and trialing subs for this user
                // (was only cancelling status="active" with plan_id <> ?).
                // This ensures a trialing sub on the SAME plan is also cancelled
                // before the new active sub is created — prevents duplicate subs.
                Database::run(
                    'UPDATE subscriptions SET status = "cancelled", cancelled_at = NOW(), updated_at = NOW(),
                         pending_plan_id = NULL
                     WHERE user_id = ? AND status IN ("active", "trialing")',
                    [$invoice['user_id']]
                );
                $subId = $this->uuid();
                $nextBillingStr = $nextBilling !== null ? date('Y-m-d H:i:s', $nextBilling) : null;
                Database::run(
                    'INSERT INTO subscriptions (id, user_id, plan_id, status, started_at, next_billing_at, created_at, updated_at)
                     VALUES (?, ?, ?, "active", NOW(), ?, NOW(), NOW())',
                    [$subId, $invoice['user_id'], $invoice['plan_id'], $nextBillingStr]
                );
                // SQL-008 fix: link the invoice to the new subscription.
                Database::run(
                    'UPDATE invoices SET subscription_id = ? WHERE id = ?',
                    [$subId, $invoice['id']]
                );
            }

            $pdo->commit();
        } catch (\Throwable $e) {
            $pdo->rollBack();
            throw $e;
        }
    }

    private function findInvoiceByReference(string $reference): ?array
    {
        $row = Database::run(
            'SELECT id, user_id, subscription_id, plan_id, paystack_reference,
                    amount_kobo, status, paid_at, is_proration, prorated_from_plan_id,
                    metadata, created_at
             FROM invoices
             WHERE paystack_reference = ?
             LIMIT 1',
            [$reference]
        )->fetch();
        return $row === false ? null : $row;
    }

    /**
     * Compute the next billing timestamp. For monthly plans, +30 days from
     * the base (default: now). For yearly, +365 days. For one_time, NULL.
     */
    private function computeNextBillingAt(string $interval, ?int $baseTs = null): ?int
    {
        $base = $baseTs ?? time();
        return match ($interval) {
            // SQL-028 fix: use +1 month / +1 year instead of +30 days / +365 days.
            // +30 days drifts ~5 days/year; +1 month respects calendar months.
            // PHP clamps Jan 31 → Feb 28 (no overflow).
            'monthly' => strtotime('+1 month', $base),
            'yearly' => strtotime('+1 year', $base),
            'one_time' => null,
            default => strtotime('+1 month', $base),
        };
    }

    private function planRowToDto(array $r): array
    {
        return [
            'id' => $r['id'],
            'code' => $r['code'],
            'name' => $r['name'],
            'priceKobo' => (int)$r['price_kobo'],
            'priceGhs' => round((int)$r['price_kobo'] / 100, 2),
            'currency' => $r['currency'],
            'billingInterval' => $r['billing_interval'],
            'paystackPlanCode' => $r['paystack_plan_code'] ?? null,
            'features' => json_decode($r['features'] ?? '[]', true) ?: [],
            'maxListings' => (int)$r['max_listings'],
            'maxChatPerDay' => (int)$r['max_chat_per_day'],
            'canWitnessSign' => (bool)$r['can_witness_sign'],
            'isActive' => (bool)$r['is_active'],
            'sortOrder' => (int)$r['sort_order'],
        ];
    }

    private function subscriptionRowToDto(array $r, ?array $plan): array
    {
        return [
            'id' => $r['id'],
            'userId' => $r['user_id'],
            'planId' => $r['plan_id'],
            'status' => $r['status'],
            'paystackSubscriptionCode' => $r['paystack_subscription_code'] ?? null,
            'paystackEmailToken' => $r['paystack_email_token'] ?? null,
            'startedAt' => date(DATE_ATOM, strtotime($r['started_at'])),
            'nextBillingAt' => $r['next_billing_at'] !== null ? date(DATE_ATOM, strtotime($r['next_billing_at'])) : null,
            'cancelledAt' => isset($r['cancelled_at']) && $r['cancelled_at'] !== null ? date(DATE_ATOM, strtotime($r['cancelled_at'])) : null,
            // M4 polish fields:
            'trialEndsAt' => isset($r['trial_ends_at']) && $r['trial_ends_at'] !== null ? date(DATE_ATOM, strtotime($r['trial_ends_at'])) : null,
            'pendingPlanId' => $r['pending_plan_id'] ?? null,
            'prorationCreditKobo' => (int)($r['proration_credit_kobo'] ?? 0),
            'plan' => $plan,
        ];
    }

    private function uuid(): string
    {
        $bytes = random_bytes(16);
        $bytes[6] = chr((ord($bytes[6]) & 0x0f) | 0x40);
        $bytes[8] = chr((ord($bytes[8]) & 0x3f) | 0x80);
        return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($bytes), 4));
    }
}

// PHP-023 fix: removed the global `now_date()` function. It was defined at
// file scope in the Busifirm\Services namespace and called unqualified from
// inside the class (resolving via namespace fallback). If any other file in
// the same namespace defined `now_date()`, PHP would fatal with "Cannot
// redeclare function". The function was only used once (in activateSubscription,
// line 899) and was a one-liner wrapper around `date('Y-m-d H:i:s')`. The
// call site now uses `date('Y-m-d H:i:s')` inline — see the PHP-023 fix
// marker at the call site.
