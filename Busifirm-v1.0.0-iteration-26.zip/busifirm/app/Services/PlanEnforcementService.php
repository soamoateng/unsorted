<?php
declare(strict_types=1);

namespace Busifirm\Services;

use Busifirm\Core\Config;
use Busifirm\Core\Database;
use Busifirm\Core\PaystackClient;
use RuntimeException;

/**
 * PlanEnforcementService — owns M4-polish plan-limit enforcement.
 *
 * SOLID (SRP): the ONLY class that knows about plan limits (max_listings,
 * max_chat_per_day). ListingService and ChatService delegate to this when
 * they need to gate a write. BillingService stays focused on subscriptions
 * + Paystack; this service stays focused on "is this user allowed to do X
 * under their current plan?".
 *
 * KISS:
 *   - No middleware. Service methods called from the resource services
 *     (ListingService::save, ChatService::sendMessage). Defense in depth:
 *     even if a future middleware is bypassed, the service throws.
 *   - No Redis counter cache. We COUNT(*) on each gated write. Phase 4+
 *     may add a per-user daily counter row when traffic warrants it.
 *   - "Today" is computed in Africa/Accra (the project's primary market)
 *     via Config::get('APP_TIMEZONE'). The daily chat counter resets at
 *     midnight Accra time, not UTC.
 *   - 0 in max_listings / max_chat_per_day means UNLIMITED (matches the
 *     plans seed: Pro and Enterprise have 0/0).
 *
 * Limit semantics:
 *   - canCreateListing(userId): true if user's listings count < plan.max_listings
 *     OR plan.max_listings = 0 (unlimited). System listings (user_id IS NULL)
 *     do NOT count against the user's quota.
 *   - canSendMessage(userId): true if messages sent today < plan.max_chat_per_day
 *     OR plan.max_chat_per_day = 0. Counted from chat_conversations.messages
 *     JSON column — every entry with timestamp >= midnight Accra counts.
 *
 * Trial-period interaction:
 *   - Trialing subscriptions are treated as ACTIVE for enforcement. A user
 *     on a 14-day Pro trial gets Pro limits until the trial ends.
 */
final class PlanEnforcementService
{
    /** @var array<string, array{code: string, maxListings: int, maxChatPerDay: int}>|null */
    private static ?array $planCache = null;

    /**
     * Returns true if the user can create a new listing under their plan.
     * Reads the plan from BillingService::getCurrentForUser to stay DRY
     * (single source of truth for "what plan is this user on?").
     */
    public function canCreateListing(string $userId): bool
    {
        $plan = $this->currentPlanForUser($userId);
        $maxListings = (int)($plan['maxListings'] ?? 0);
        if ($maxListings === 0) return true;  // unlimited

        // BL-09 fix: the listings table has NO deleted_at column (migration 002
        // doesn't add one). The old query `WHERE deleted_at IS NULL` caused a
        // SQL error on every listing creation. Removed the non-existent column.
        $count = (int)Database::run(
            'SELECT COUNT(*) AS c FROM listings WHERE user_id = ?',
            [$userId]
        )->fetch()['c'];

        return $count < $maxListings;
    }

    /**
     * Throws RuntimeException with a clear message if the user has hit their
     * listing limit. Caller (ListingService::save) wraps in try/catch and
     * returns 402 Payment Required to the client.
     */
    public function assertCanCreateListing(string $userId): void
    {
        if (!$this->canCreateListing($userId)) {
            $plan = $this->currentPlanForUser($userId);
            $maxListings = (int)($plan['maxListings'] ?? 0);
            throw new RuntimeException(
                'plan_limit_reached: You have reached your plan\'s limit of '
                . $maxListings . ' listing(s). Upgrade to create more.'
            );
        }
    }

    /**
     * Returns true if the user can send another chat message today.
     * "Today" = midnight Africa/Accra to now (configurable via APP_TIMEZONE).
     */
    public function canSendMessage(string $userId): bool
    {
        $plan = $this->currentPlanForUser($userId);
        $maxChatPerDay = (int)($plan['maxChatPerDay'] ?? 0);
        if ($maxChatPerDay === 0) return true;  // unlimited

        // BL-08 fix: the old query used a broken JSON_EXTRACT path that always
        // returned 0 (the CONCAT produced an invalid JSON path like `$[2.timestamp`
        // instead of `$[2].timestamp`). It also counted CONVERSATIONS, not
        // individual messages. The fix counts actual message entries in the
        // JSON array that have a timestamp >= today's midnight Accra time.
        //
        // We use JSON_TABLE (MySQL 8.0+) to extract each message's timestamp
        // from the messages JSON array, then count those with timestamp >= today.
        $todayStart = $this->todayStartInAccra();
        $row = Database::run(
            "SELECT COUNT(*) AS c FROM chat_conversations c,
                JSON_TABLE(c.messages, '$[*]' COLUMNS (
                    ts VARCHAR(40) PATH '$.timestamp'
                )) AS jt
             WHERE c.user_id = ? AND jt.ts >= ?",
            [$userId, $todayStart]
        )->fetch();

        $count = $row !== false ? (int)$row['c'] : 0;
        return $count < $maxChatPerDay;
    }

    public function assertCanSendMessage(string $userId): void
    {
        if (!$this->canSendMessage($userId)) {
            $plan = $this->currentPlanForUser($userId);
            $maxChatPerDay = (int)($plan['maxChatPerDay'] ?? 0);
            throw new RuntimeException(
                'plan_limit_reached: You have reached your plan\'s daily chat limit of '
                . $maxChatPerDay . ' message(s). Upgrade for unlimited chat.'
            );
        }
    }

    /**
     * Returns the user's current plan as a DTO array (code, maxListings,
     * maxChatPerDay, etc). Reuses BillingService::getCurrentForUser via
     * a freshly-constructed BillingService — KISS: no shared state, no
     * service container.
     *
     * BL-25 fix: caches the plan per-user in $planCache so repeated calls
     * within the same request don't re-construct PaystackClient + BillingService.
     */
    private function currentPlanForUser(string $userId): array
    {
        // BL-25 fix: check the per-request cache first.
        if (self::$planCache !== null && isset(self::$planCache[$userId])) {
            return self::$planCache[$userId];
        }

        // If Paystack isn't configured (dev/early setup), we still need to
        // return the free plan. Construct PaystackClient defensively.
        try {
            $paystack = new PaystackClient();
            $billing = new BillingService($paystack);
        } catch (\Throwable $e) {
            // Paystack unset — query the free plan directly.
            $row = Database::run(
                'SELECT code, name, max_listings, max_chat_per_day FROM plans
                 WHERE code = ? LIMIT 1',
                [Config::get('BILLING_FREE_PLAN_CODE', 'free')]
            )->fetch();
            if ($row === false) {
                $plan = ['code' => 'free', 'maxListings' => 1, 'maxChatPerDay' => 5];
            } else {
                $plan = [
                    'code' => $row['code'],
                    'maxListings' => (int)$row['max_listings'],
                    'maxChatPerDay' => (int)$row['max_chat_per_day'],
                ];
            }
            self::$planCache[$userId] = $plan;
            return $plan;
        }

        $current = $billing->getCurrentForUser($userId);
        $plan = $current['plan'];
        $result = [
            'code' => $plan['code'],
            'maxListings' => $plan['maxListings'],
            'maxChatPerDay' => $plan['maxChatPerDay'],
        ];
        self::$planCache[$userId] = $result;
        return $result;
    }

    /**
     * Returns the SQL DATETIME string for "midnight today in Africa/Accra".
     * The project's primary market is Ghana, so daily counters reset on
     * Accra time, not UTC. This avoids the "user sends a message at 23:59
     * UTC, counter resets at 00:00 UTC = 1 minute later" footgun.
     *
     * Returns an ISO-8601 string (e.g. "2026-09-17T00:00:00+00:00") so it
     * can be compared lexicographically against the DATE_ATOM timestamps
     * stored in chat message entries.
     */
    private function todayStartInAccra(): string
    {
        $tz = Config::get('APP_TIMEZONE', 'Africa/Accra');
        try {
            $now = new \DateTimeImmutable('now', new \DateTimeZone($tz));
        } catch (\Throwable $e) {
            $now = new \DateTimeImmutable('now', new \DateTimeZone('Africa/Accra'));
        }
        $midnight = $now->setTime(0, 0, 0);
        // Return as ISO-8601 with timezone offset — chat message timestamps
        // are stored as DATE_ATOM (ISO-8601 with offset), so we compare
        // in the same format. Lexicographic comparison of ISO-8601 strings
        // with the same offset format is chronologically correct.
        return $midnight->format(DATE_ATOM);
    }
}
