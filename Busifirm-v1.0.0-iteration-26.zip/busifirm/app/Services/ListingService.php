<?php
declare(strict_types=1);

namespace Busifirm\Services;

use Busifirm\Core\Database;
use Busifirm\Core\Role;
use RuntimeException;

/**
 * ListingService — CRUD for company listings.
 *
 * SOLID (SRP): owns listings only. Does not know about IPs, deals, or chat.
 * KISS: no repository abstraction; PDO calls live here. When listings grow
 * complex (search, filters, pagination), extract a ListingRepository.
 *
 * M3 RBAC: save() and delete() require a role with canCreateListings()
 * capability (seller or broker). Buyers and lawyers can read listings but
 * cannot create or modify them. The role is passed in from the controller
 * (which reads it from the session) so the service stays stateless and
 * testable without session setup.
 *
 * M4 polish (v0.8.0): save() also enforces the plan limit (max_listings)
 * via PlanEnforcementService::assertCanCreateListing(). The error message
 * starts with 'plan_limit_reached:' so the controller can return 402
 * Payment Required (vs 403 for RBAC, 400 for validation).
 *
 * Security: every read/write is scoped by user_id. A user can only see/edit
 * their own listings. Public/system listings (user_id IS NULL) are visible
 * to all authenticated users.
 */
final class ListingService
{
    public function __construct(
        private readonly ?PlanEnforcementService $enforcement = null
    ) {}

    public function listForUser(string $userId): array
    {
        // PERF-17 fix: add LIMIT 200 to prevent unbounded result sets.
        $rows = Database::run(
            'SELECT id, user_id, company_name, sector, revenue, valuation,
                    description, status, created_at, updated_at
             FROM listings
             WHERE user_id = ? OR user_id IS NULL
             ORDER BY created_at DESC
             LIMIT 200',
            [$userId]
        )->fetchAll();
        return array_map(fn($r) => $this->rowToDto($r), $rows);
    }

    public function getById(string $id, ?string $userId): ?array
    {
        $row = Database::run(
            'SELECT id, user_id, company_name, sector, revenue, valuation,
                    description, status, created_at, updated_at
             FROM listings
             WHERE id = ? AND (user_id = ? OR user_id IS NULL)
             LIMIT 1',
            [$id, $userId]
        )->fetch();
        return $row === false ? null : $this->rowToDto($row);
    }

    public function isDuplicate(string $companyName, ?string $excludeId = null): bool
    {
        if ($excludeId !== null) {
            $row = Database::run(
                'SELECT id FROM listings WHERE LOWER(company_name) = LOWER(?) AND id <> ? LIMIT 1',
                [$companyName, $excludeId]
            )->fetch();
        } else {
            $row = Database::run(
                'SELECT id FROM listings WHERE LOWER(company_name) = LOWER(?) LIMIT 1',
                [$companyName]
            )->fetch();
        }
        return $row !== false;
    }

    /**
     * Create or update a listing.
     *
     * @param string $role  The caller's role string (e.g. 'seller', 'broker').
     *                      Required for M3 RBAC enforcement.
     * @throws RuntimeException if the role lacks canCreateListings capability,
     *                          the company name is a duplicate, or the caller
     *                          tries to edit a listing they do not own.
     */
    public function save(array $listing, string $userId, string $role): array
    {
        $roleEnum = Role::fromString($role);
        if ($roleEnum === null || !$roleEnum->canCreateListings()) {
            throw new RuntimeException(
                'Your role (' . $role . ') cannot create or edit listings. Only sellers and brokers can.'
            );
        }

        $id = $listing['id'] ?? null;
        $isNew = $id === null || $id === '';

        // M4 polish: plan limit check on CREATE only (updates don't count).
        if ($isNew && $this->enforcement !== null) {
            $this->enforcement->assertCanCreateListing($userId);
        }

        if ($this->isDuplicate((string)$listing['companyName'], $isNew ? null : $id)) {
            throw new RuntimeException('A listing with this company name already exists.');
        }

        if ($isNew) {
            $id = $this->uuid();
            Database::run(
                'INSERT INTO listings (id, user_id, company_name, sector, revenue, valuation, description, status, created_at, updated_at)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())',
                [
                    $id,
                    $userId,
                    (string)$listing['companyName'],
                    (string)$listing['sector'],
                    (int)$listing['revenue'],
                    (int)$listing['valuation'],
                    (string)$listing['description'],
                    (string)($listing['status'] ?? 'active'),
                ]
            );
        } else {
            // Ownership check: only the owner can edit. System listings
            // (user_id IS NULL) cannot be edited by anyone via this method.
            $existing = Database::run(
                'SELECT user_id FROM listings WHERE id = ? LIMIT 1',
                [$id]
            )->fetch();
            if ($existing === false) {
                throw new RuntimeException('Listing not found.');
            }
            if ($existing['user_id'] !== $userId) {
                throw new RuntimeException('You do not have permission to edit this listing.');
            }
            Database::run(
                'UPDATE listings
                 SET company_name = ?, sector = ?, revenue = ?, valuation = ?,
                     description = ?, status = ?, updated_at = NOW()
                 WHERE id = ?',
                [
                    (string)$listing['companyName'],
                    (string)$listing['sector'],
                    (int)$listing['revenue'],
                    (int)$listing['valuation'],
                    (string)$listing['description'],
                    (string)($listing['status'] ?? 'active'),
                    $id,
                ]
            );
        }
        return $this->getById($id, $userId);
    }

    /**
     * Delete a listing. Same RBAC as save() — only sellers and brokers can
     * delete, and only their own listings.
     */
    public function delete(string $id, string $userId, string $role): void
    {
        $roleEnum = Role::fromString($role);
        if ($roleEnum === null || !$roleEnum->canCreateListings()) {
            throw new RuntimeException(
                'Your role (' . $role . ') cannot delete listings. Only sellers and brokers can.'
            );
        }

        $existing = Database::run(
            'SELECT user_id FROM listings WHERE id = ? LIMIT 1',
            [$id]
        )->fetch();
        if ($existing === false) {
            throw new RuntimeException('Listing not found.');
        }
        if ($existing['user_id'] !== $userId) {
            throw new RuntimeException('You do not have permission to delete this listing.');
        }
        Database::run('DELETE FROM listings WHERE id = ?', [$id]);
    }

    private function rowToDto(array $r): array
    {
        return [
            'id' => $r['id'],
            'userId' => $r['user_id'],
            'companyName' => $r['company_name'],
            'sector' => $r['sector'],
            'revenue' => (int)$r['revenue'],
            'valuation' => (int)$r['valuation'],
            'description' => $r['description'],
            'status' => $r['status'],
            'createdAt' => date(DATE_ATOM, strtotime($r['created_at'])),
            'updatedAt' => date(DATE_ATOM, strtotime($r['updated_at'])),
        ];
    }

    private function uuid(): string
    {
        $bytes = random_bytes(16);
        $bytes[6] = chr((ord($bytes[6]) & 0x0f) | 0x40);
        $bytes[8] = chr((ord($bytes[8]) & 0x3f) | 0x80);
        return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($bytes), 4));
    }
}
