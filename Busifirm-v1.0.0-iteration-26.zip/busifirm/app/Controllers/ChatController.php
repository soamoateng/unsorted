<?php
declare(strict_types=1);

namespace Busifirm\Controllers;

use Busifirm\Services\AuditService;
use Busifirm\Services\ChatService;
use RuntimeException;

final class ChatController
{
    public function __construct(
        private readonly ChatService $chat,
        private readonly AuditService $audit
    ) {}

    /** GET /api/chat */
    public function list(): void
    {
        $this->json(200, ['ok' => true, 'conversations' => $this->chat->listForUser($this->userId())]);
    }

    /** GET /api/chat/{convId} */
    public function get(string $convId): void
    {
        $conv = $this->chat->getConversation($convId, $this->userId());
        if ($conv === null) {
            $this->json(404, ['ok' => false, 'error' => 'Conversation not found.']);
            return;
        }
        $this->json(200, ['ok' => true, 'conversation' => $conv]);
    }

    /** POST /api/chat — create new conversation */
    public function create(): void
    {
        // PHP-030 fix: every other mutating controller method (sendMessage,
        // save, delete, etc.) wraps the service call in try/catch and returns
        // a 400 on RuntimeException. create() previously did NOT, so any
        // service exception (TypeError on malformed messages field, DB
        // constraint violation, etc.) propagated to the front controller
        // and returned a generic 500. Now it returns a meaningful 400.
        try {
            $conv = $this->chat->createConversation($this->userId(), $this->jsonBody());
            $this->json(201, ['ok' => true, 'conversation' => $conv]);
        } catch (RuntimeException $e) {
            $this->json(400, ['ok' => false, 'error' => $e->getMessage()]);
        }
    }

    /** POST /api/chat/{convId}/message — send a message */
    public function sendMessage(string $convId): void
    {
        $body = $this->jsonBody();
        $text = (string)($body['text'] ?? '');
        if ($text === '') {
            $this->json(400, ['ok' => false, 'error' => 'text is required.']);
            return;
        }
        // PHP-011 fix: the old code trusted the client-supplied `sender` field
        // and stored it verbatim. A user could send messages with
        // sender: "Admin" or sender: "System" or impersonate another user.
        // The audit log entry also recorded the spoofed sender.
        //
        // Fix: ignore the client-supplied `sender` entirely. Derive the sender
        // display name from the authenticated session's email (set at login
        // by AuthController::startSession at line 222). The userId is already
        // enforced (ownership check in ChatService::sendMessage), but the
        // display name was not.
        $sender = (string)($_SESSION['_busifirm_user_email'] ?? '');
        if ($sender === '') {
            // Fallback: if the session email isn't set (shouldn't happen for
            // authenticated users, but defense-in-depth), use the userId.
            $sender = $this->userId();
        }
        try {
            $conv = $this->chat->sendMessage($convId, $this->userId(), $sender, $text);
            $this->audit->log($this->userId(), 'Chat message sent', ['convId' => $convId, 'sender' => $sender],
                $this->ip(), $this->userAgent());
            $this->json(200, ['ok' => true, 'conversation' => $conv]);
        } catch (RuntimeException $e) {
            $msg = $e->getMessage();
            // M4 polish: plan limit returns 402 Payment Required; other errors 400.
            $status = str_starts_with($msg, 'plan_limit_reached:') ? 402 : 400;
            // OTH-28 fix: strip the technical 'plan_limit_reached:' prefix from
            // the user-facing error message.
            $userMsg = str_starts_with($msg, 'plan_limit_reached:')
                ? substr($msg, strlen('plan_limit_reached: '))
                : $msg;
            $this->json($status, ['ok' => false, 'error' => $userMsg]);
        }
    }

    /** POST /api/chat/{convId}/read — mark all messages as read */
    public function markAsRead(string $convId): void
    {
        $this->chat->markAsRead($convId, $this->userId());
        $this->json(200, ['ok' => true]);
    }

    private function userId(): string { return (string)($_SESSION['_busifirm_user_id'] ?? ''); }
    private function ip(): string { return $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1'; }
    private function userAgent(): string { return substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 512); }
    private function jsonBody(): array
    {
        $raw = file_get_contents('php://input') ?: '';
        if ($raw === '') return [];
        $data = json_decode($raw, true);
        return is_array($data) ? $data : [];
    }
    private function json(int $status, array $payload): void
    {
        http_response_code($status);
        header('Content-Type: application/json; charset=utf-8');
        header('X-Content-Type-Options: nosniff');
        header('Cache-Control: no-store, no-cache, must-revalidate, private');
        echo json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    }
}
