<?php
declare(strict_types=1);

namespace Busifirm\Controllers;

use Busifirm\Services\AuditService;
use Busifirm\Services\DealService;
use RuntimeException;

final class DealController
{
    public function __construct(
        private readonly DealService $deals,
        private readonly AuditService $audit
    ) {}

    /** GET /api/deals */
    public function list(): void
    {
        $this->json(200, ['ok' => true, 'deals' => $this->deals->listForUser($this->userId())]);
    }

    /** POST /api/deals — create */
    public function create(): void
    {
        try {
            $deal = $this->deals->create($this->userId(), $this->jsonBody());
            $this->audit->log($this->userId(), 'Deal created', ['dealId' => $deal['id']],
                $this->ip(), $this->userAgent());
            $this->json(201, ['ok' => true, 'deal' => $deal]);
        } catch (RuntimeException $e) {
            $this->json(400, ['ok' => false, 'error' => $e->getMessage()]);
        }
    }

    /** POST /api/deals/{id} — update */
    public function update(string $id): void
    {
        try {
            $deal = $this->deals->update($id, $this->userId(), $this->jsonBody());
            $this->audit->log($this->userId(), 'Deal updated', ['dealId' => $id],
                $this->ip(), $this->userAgent());
            $this->json(200, ['ok' => true, 'deal' => $deal]);
        } catch (RuntimeException $e) {
            $this->json(400, ['ok' => false, 'error' => $e->getMessage()]);
        }
    }

    /** POST /api/deals/{id}/delete */
    public function delete(string $id): void
    {
        try {
            $this->deals->delete($id, $this->userId());
            $this->json(200, ['ok' => true]);
        } catch (RuntimeException $e) {
            $this->json(400, ['ok' => false, 'error' => $e->getMessage()]);
        }
    }

    private function userId(): string { return (string)($_SESSION['_busifirm_user_id'] ?? ''); }
    private function ip(): string { return $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1'; }
    private function userAgent(): string { return substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 512); }
    private function jsonBody(): array
    {
        $raw = file_get_contents('php://input') ?: '';
        if ($raw === '') return [];
        $data = json_decode($raw, true);
        return is_array($data) ? $data : [];
    }
    private function json(int $status, array $payload): void
    {
        http_response_code($status);
        header('Content-Type: application/json; charset=utf-8');
        header('X-Content-Type-Options: nosniff');
        header('Cache-Control: no-store, no-cache, must-revalidate, private');
        echo json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    }
}
