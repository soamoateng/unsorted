<?php
declare(strict_types=1);

namespace Busifirm\Controllers;

use Busifirm\Services\AuditService;

/**
 * AuditController — read-only access to the current user's audit log.
 *
 * Phase 3 will add an admin-only endpoint to view all users' events.
 */
final class AuditController
{
    public function __construct(
        private readonly AuditService $audit
    ) {}

    /** GET /api/audit?limit=200 */
    public function list(): void
    {
        $limit = isset($_GET['limit']) ? max(1, min(500, (int)$_GET['limit'])) : 200;
        $rows = $this->audit->listForUser($this->userId(), $limit);
        $this->json(200, ['ok' => true, 'entries' => $rows]);
    }

    /**
     * POST /api/audit — write an audit event from the client (for legacy
     * AuditTrail.log() calls that haven't been migrated to server-side
     * service calls yet). Subject to the same CSRF + auth as all mutations.
     *
     * SEC-03 fix: restrict allowed actions to a whitelist so users can't
     * forge misleading audit entries (e.g., "admin.kyc_verified").
     */
    public function log(): void
    {
        $body = $this->jsonBody();
        $action = (string)($body['action'] ?? '');
        $details = $body['details'] ?? [];
        if ($action === '') {
            $this->json(400, ['ok' => false, 'error' => 'action is required.']);
            return;
        }
        // SEC-03 fix: only allow client-side audit actions (no admin.* or user.* prefixes).
        // Admin and auth events are written server-side only.
        $blockedPrefixes = ['admin.', 'user.', 'billing.', 'system.'];
        foreach ($blockedPrefixes as $prefix) {
            if (str_starts_with($action, $prefix)) {
                $this->json(403, ['ok' => false, 'error' => 'This action type can only be written server-side.']);
                return;
            }
        }
        // Limit action length to prevent abuse.
        if (strlen($action) > 100) {
            $this->json(400, ['ok' => false, 'error' => 'Action too long (max 100 chars).']);
            return;
        }
        $this->audit->log($this->userId(), $action, $details, $this->ip(), $this->userAgent());
        $this->json(200, ['ok' => true]);
    }

    private function userId(): string { return (string)($_SESSION['_busifirm_user_id'] ?? ''); }
    private function ip(): string { return $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1'; }
    private function userAgent(): string { return substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 512); }
    private function jsonBody(): array
    {
        $raw = file_get_contents('php://input') ?: '';
        if ($raw === '') return [];
        $data = json_decode($raw, true);
        return is_array($data) ? $data : [];
    }
    private function json(int $status, array $payload): void
    {
        http_response_code($status);
        header('Content-Type: application/json; charset=utf-8');
        header('X-Content-Type-Options: nosniff');
        header('Cache-Control: no-store, no-cache, must-revalidate, private');
        echo json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    }
}
