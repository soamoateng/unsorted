<?php
declare(strict_types=1);

namespace Busifirm\Controllers;

use Busifirm\Services\AuditService;
use Busifirm\Services\IntegrationService;
use RuntimeException;

final class IntegrationController
{
    public function __construct(
        private readonly IntegrationService $integrations,
        private readonly AuditService $audit
    ) {}

    /** GET /api/integrations */
    public function get(): void
    {
        $data = $this->integrations->getForUser($this->userId());
        $this->json(200, ['ok' => true, 'integration' => $data]);
    }

    /** POST /api/integrations/tasks — create new task */
    public function createTask(): void
    {
        $data = $this->integrations->createTask($this->userId(), $this->jsonBody());
        $this->audit->log($this->userId(), 'Integration task created', [],
            $this->ip(), $this->userAgent());
        $this->json(200, ['ok' => true, 'integration' => $data]);
    }

    /** POST /api/integrations/tasks/{taskId} — update task */
    public function updateTask(string $taskId): void
    {
        try {
            $data = $this->integrations->updateTask($this->userId(), $taskId, $this->jsonBody());
            $this->audit->log($this->userId(), 'Integration task updated',
                ['taskId' => $taskId], $this->ip(), $this->userAgent());
            $this->json(200, ['ok' => true, 'integration' => $data]);
        } catch (RuntimeException $e) {
            $this->json(400, ['ok' => false, 'error' => $e->getMessage()]);
        }
    }

    private function userId(): string { return (string)($_SESSION['_busifirm_user_id'] ?? ''); }
    private function ip(): string { return $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1'; }
    private function userAgent(): string { return substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 512); }
    private function jsonBody(): array
    {
        $raw = file_get_contents('php://input') ?: '';
        if ($raw === '') return [];
        $data = json_decode($raw, true);
        return is_array($data) ? $data : [];
    }
    private function json(int $status, array $payload): void
    {
        http_response_code($status);
        header('Content-Type: application/json; charset=utf-8');
        header('X-Content-Type-Options: nosniff');
        header('Cache-Control: no-store, no-cache, must-revalidate, private');
        echo json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    }
}
