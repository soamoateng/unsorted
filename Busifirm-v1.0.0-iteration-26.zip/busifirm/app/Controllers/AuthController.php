<?php
declare(strict_types=1);

namespace Busifirm\Controllers;

use Busifirm\Core\Config;
use Busifirm\Core\Csrf;
use Busifirm\Services\UserService;
use RuntimeException;

/**
 * AuthController — thin HTTP layer over UserService.
 *
 * SOLID (SRP): parses request, calls service, returns JSON. No business logic
 * here. If you find yourself adding "if user is admin" or "check KYC status"
 * to this class, that belongs in a service.
 *
 * SOLID (DIP): depends on UserService via constructor. Tests can swap in a
 * mock service.
 */
final class AuthController
{
    public function __construct(
        private readonly UserService $users
    ) {}

    /** POST /api/auth/register — body: {email, password, role} */
    public function register(): void
    {
        $body = $this->jsonBody();
        $email = (string)($body['email'] ?? '');
        $password = (string)($body['password'] ?? '');
        $role = (string)($body['role'] ?? '');

        try {
            $result = $this->users->register($email, $password, $role, $this->ip(), $this->userAgent());
            // SEC-36 fix: DON'T start a full session for unverified users.
            // The old code called startSession() immediately after register(),
            // giving unverified users access to all authenticated endpoints.
            // Now we only set a minimal session for CSRF token issuance —
            // the user must verify their email before they can use the app.
            if (session_status() !== PHP_SESSION_ACTIVE) {
                session_start();
            }
            session_regenerate_id(true);
            $_SESSION['_busifirm_user_id'] = $result['user']['id'];
            $_SESSION['_busifirm_role'] = $result['user']['role'];
            $_SESSION['_busifirm_user_email'] = $result['user']['email'];
            $_SESSION['_busifirm_logged_in_at'] = time();
            $_SESSION['_busifirm_email_verified'] = false;  // SEC-36: flag for middleware
            $csrf = Csrf::issue();

            $payload = [
                'ok' => true,
                'user' => $result['user'],
                'csrfToken' => $csrf,
                'message' => 'Account created. Check your email for a verification link.',
            ];
            // Dev convenience: echo the token so the dev can click it without
            // a mail server. Never expose in production.
            // OTH-04 fix: also check APP_ENV is 'development' to prevent
            // accidental exposure if MAIL_ECHO_TOKENS_IN_DEV is left on in prod.
            if (Config::getBool('MAIL_ECHO_TOKENS_IN_DEV', false)
                && Config::get('APP_ENV', 'production') === 'development') {
                $payload['_dev_verify_token'] = $result['verify_token'];
            }
            $this->json(201, $payload);
        } catch (RuntimeException $e) {
            $this->json(400, ['ok' => false, 'error' => $e->getMessage()]);
        }
    }

    /** GET /api/auth/verify?token=... */
    public function verifyEmail(): void
    {
        $token = (string)($_GET['token'] ?? '');
        // SEC-37 fix: validate token format before sending to the service.
        // The old code passed the raw token directly — a malformed token would
        // still be hashed and queried, wasting DB resources.
        if (!preg_match('/^[0-9a-f]{64}$/', $token)) {
            $this->json(400, ['ok' => false, 'error' => 'Invalid token format.']);
            return;
        }
        $ok = $this->users->verifyEmail($token, $this->ip(), $this->userAgent());
        if ($ok) {
            // SEC-36 fix: update the session flag if the user is currently in a
            // pre-verification session (from register()).
            if (session_status() === PHP_SESSION_ACTIVE) {
                $_SESSION['_busifirm_email_verified'] = true;
            }
            $this->json(200, ['ok' => true, 'message' => 'Email verified. You can now log in.']);
        } else {
            $this->json(400, ['ok' => false, 'error' => 'Invalid or expired verification link.']);
        }
    }

    /** POST /api/auth/login — body: {email, password} */
    public function login(): void
    {
        $body = $this->jsonBody();
        $email = (string)($body['email'] ?? '');
        $password = (string)($body['password'] ?? '');

        try {
            $result = $this->users->login($email, $password, $this->ip(), $this->userAgent());
            $this->startSession($result['user']);
            // SEC-36 fix: set email_verified flag so AuthMiddleware knows this
            // user is verified (login() only succeeds for verified users).
            $_SESSION['_busifirm_email_verified'] = true;
            $csrf = Csrf::issue();

            $payload = [
                'ok' => true,
                'user' => $result['user'],
                'csrfToken' => $csrf,
                'message' => 'Welcome back.',
            ];
            // OTH-04 fix: check APP_ENV in addition to MAIL_ECHO_TOKENS_IN_DEV.
            if (Config::getBool('MAIL_ECHO_TOKENS_IN_DEV', false)
                && Config::get('APP_ENV', 'production') === 'development'
                && $result['verify_token'] !== null) {
                $payload['_dev_verify_token'] = $result['verify_token'];
            }
            $this->json(200, $payload);
        } catch (RuntimeException $e) {
            $this->json(401, ['ok' => false, 'error' => $e->getMessage()]);
        }
    }

    /** POST /api/auth/logout */
    public function logout(): void
    {
        $userId = $_SESSION['_busifirm_user_id'] ?? null;
        $this->users->logout($userId, $this->ip(), $this->userAgent());

        // Wipe session + regenerate id to prevent fixation.
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $p = session_get_cookie_params();
            // PHP-037 fix: use array form of setcookie to include SameSite=Strict
            // (matching the session cookie config in index.php). The positional form
            // doesn't support the samesite parameter.
            setcookie(session_name(), '', [
                'expires' => time() - 42000,
                'path' => $p['path'],
                'domain' => $p['domain'],
                'secure' => $p['secure'],
                'httponly' => $p['httponly'],
                'samesite' => $p['samesite'] ?? 'Strict',
            ]);
        }
        session_destroy();

        $this->json(200, ['ok' => true, 'message' => 'Logged out.']);
    }

    /** GET /api/auth/me — returns current user (or 401) */
    public function me(): void
    {
        $userId = $_SESSION['_busifirm_user_id'] ?? null;
        $user = $this->users->getCurrentUser($userId);
        if ($user === null) {
            $this->json(401, ['ok' => false, 'error' => 'Not authenticated.']);
            return;
        }
        $csrf = Csrf::issue();

        // M4: include the user's current plan code so the frontend can gate UI.
        // We read from the session cache (set at login) for speed; the frontend
        // calls /api/billing/me for the full subscription detail when needed.
        $planCode = $_SESSION['_busifirm_plan_code'] ?? 'free';

        $this->json(200, ['ok' => true, 'user' => $user, 'csrfToken' => $csrf, 'planCode' => $planCode]);
    }

    /** GET /api/auth/csrf — explicit CSRF token fetch (used by frontend on cold start) */
    public function csrf(): void
    {
        $csrf = Csrf::issue();
        $this->json(200, ['ok' => true, 'csrfToken' => $csrf]);
    }

    /** POST /api/auth/forgot — body: {email} */
    public function forgotPassword(): void
    {
        $body = $this->jsonBody();
        $email = (string)($body['email'] ?? '');
        $result = $this->users->requestPasswordReset($email, $this->ip(), $this->userAgent());

        // Always return success — do not leak whether the email exists.
        $payload = ['ok' => true, 'message' => 'If an account exists for that email, a reset link has been sent.'];
        // OTH-04 fix: check APP_ENV in addition to MAIL_ECHO_TOKENS_IN_DEV.
        if (Config::getBool('MAIL_ECHO_TOKENS_IN_DEV', false)
            && Config::get('APP_ENV', 'production') === 'development'
            && $result['token'] !== null) {
            $payload['_dev_reset_token'] = $result['token'];
        }
        $this->json(200, $payload);
    }

    /** POST /api/auth/reset — body: {token, password} */
    public function resetPassword(): void
    {
        $body = $this->jsonBody();
        $token = (string)($body['token'] ?? '');
        $password = (string)($body['password'] ?? '');

        try {
            $this->users->resetPassword($token, $password, $this->ip(), $this->userAgent());
            $this->json(200, ['ok' => true, 'message' => 'Password updated. You can now log in.']);
        } catch (RuntimeException $e) {
            $this->json(400, ['ok' => false, 'error' => $e->getMessage()]);
        }
    }

    // -----------------------------------------------------------------
    // Private helpers
    // -----------------------------------------------------------------

    private function startSession(array $user): void
    {
        if (session_status() === PHP_SESSION_ACTIVE) {
            // Regenerate ID on privilege change to prevent session fixation.
            session_regenerate_id(true);
        } else {
            session_start();
        }
        $_SESSION['_busifirm_user_id'] = $user['id'];
        $_SESSION['_busifirm_role'] = $user['role'];  // M3: cached for RBAC checks
        // SEC-01 fix: cache the user's email in session so ESignController::witnessSign
        // can use it instead of trusting the request body.
        $_SESSION['_busifirm_user_email'] = $user['email'];
        $_SESSION['_busifirm_logged_in_at'] = time();

        // M6 polish: cache the user's role_version at login. AuthMiddleware
        // compares this to the DB version on every authenticated request;
        // mismatch triggers session regeneration + role re-read. This closes
        // the stale-role risk documented in v0.7.0.
        try {
            $versionRow = \Busifirm\Core\Database::run(
                'SELECT role_version FROM users WHERE id = ? LIMIT 1',
                [$user['id']]
            )->fetch();
            $_SESSION['_busifirm_role_version'] = $versionRow !== false
                ? (int)$versionRow['role_version']
                : 1;
        } catch (\Throwable $e) {
            $_SESSION['_busifirm_role_version'] = 1;
        }

        // M4: cache the user's current plan code in the session so /api/auth/me
        // can return it without a DB hit on every request. The plan is
        // re-validated on /api/billing/me (the source of truth). If the user
        // upgrades mid-session, this cached value is stale until next login —
        // acceptable because the frontend calls /api/billing/me after a
        // successful checkout to refresh.
        $_SESSION['_busifirm_plan_code'] = 'free';
        try {
            $row = \Busifirm\Core\Database::run(
                'SELECT p.code FROM subscriptions s
                 INNER JOIN plans p ON s.plan_id = p.id
                 WHERE s.user_id = ? AND s.status IN (\'active\', \'trialing\', \'past_due\')
                 ORDER BY s.created_at DESC LIMIT 1',
                [$user['id']]
            )->fetch();
            if ($row !== false) {
                $_SESSION['_busifirm_plan_code'] = $row['code'];
            }
        } catch (\Throwable $e) {
            // Billing tables may not exist yet (pre-migration). Default to 'free'.
        }
    }

    private function ip(): string
    {
        // SEC-06 fix: support TRUSTED_PROXIES config for X-Forwarded-For.
        // Behind nginx/Cloudflare, REMOTE_ADDR is the proxy's IP, not the user's.
        // If TRUSTED_PROXIES is set, we check if REMOTE_ADDR is in the list and
        // use X-Forwarded-For instead.
        $remoteAddr = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
        $trustedProxies = Config::get('TRUSTED_PROXIES', '');
        if ($trustedProxies !== '') {
            $proxyList = array_map('trim', explode(',', $trustedProxies));
            if (in_array($remoteAddr, $proxyList, true)) {
                $forwarded = $_SERVER['HTTP_X_FORWARDED_FOR'] ?? '';
                if ($forwarded !== '') {
                    // X-Forwarded-For can be a comma-separated list; take the first (client) IP.
                    $parts = explode(',', $forwarded);
                    return trim($parts[0]);
                }
            }
        }
        return $remoteAddr;
    }

    private function userAgent(): string
    {
        return substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 512);
    }

    /** @return array<string,mixed> */
    private function jsonBody(): array
    {
        $raw = file_get_contents('php://input') ?: '';
        if ($raw === '') return [];
        $data = json_decode($raw, true);
        if (!is_array($data)) return [];
        return $data;
    }

    private function json(int $status, array $payload): void
    {
        http_response_code($status);
        header('Content-Type: application/json; charset=utf-8');
        header('X-Content-Type-Options: nosniff');
        header('Cache-Control: no-store, no-cache, must-revalidate, private');
        echo json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    }
}
