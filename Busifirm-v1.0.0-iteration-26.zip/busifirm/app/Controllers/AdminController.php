<?php
declare(strict_types=1);

namespace Busifirm\Controllers;

use Busifirm\Middleware\AdminMiddleware;
use Busifirm\Services\AdminService;
use RuntimeException;

/**
 * AdminController — thin HTTP layer over AdminService.
 *
 * Every endpoint requires admin role. The front controller calls
 * AdminMiddleware::requireAdmin() before dispatching, but we re-check
 * here as defense in depth.
 *
 * Endpoints:
 *   GET  /api/admin/stats               — aggregate counts
 *   GET  /api/admin/users               — list all users with KYC + plan
 *   POST /api/admin/users/{id}/verify-kyc   — verify a user's KYC
 *   POST /api/admin/users/{id}/reject-kyc   — reject a user's KYC
 *   GET  /api/admin/plans               — list plans with paystack_plan_code
 *   POST /api/admin/plans/{code}/set-code   — set paystack_plan_code
 *   POST /api/admin/plans/{code}/clear-code — clear paystack_plan_code
 *   GET  /api/admin/audit               — list all audit events (with filters)
 *   POST /api/admin/users/{id}/role     — change user role (M6 polish; invalidates session)
 *   POST /api/admin/users/{id}/delete   — GDPR soft-delete user (M6 polish + M9 precursor)
 *   POST /api/admin/users/{id}/cancel-deletion — restore a soft-deleted user (M6 polish)
 */
final class AdminController
{
    public function __construct(
        private readonly AdminService $admin
    ) {}

    /** GET /api/admin/stats */
    public function stats(): void
    {
        if (!AdminMiddleware::requireAdmin()) return;
        $this->json(200, ['ok' => true, 'stats' => $this->admin->getStats()]);
    }

    /** GET /api/admin/users?includeDeleted=true */
    public function listUsers(): void
    {
        if (!AdminMiddleware::requireAdmin()) return;
        // UX-09 fix: pass includeDeleted from the query string so the frontend
        // can request soft-deleted users for the "Show deleted users" toggle.
        $includeDeleted = isset($_GET['includeDeleted']) && $_GET['includeDeleted'] === 'true';
        $this->json(200, ['ok' => true, 'users' => $this->admin->listUsers($includeDeleted)]);
    }

    /** POST /api/admin/users/{id}/verify-kyc */
    public function verifyKyc(string $targetUserId): void
    {
        if (!AdminMiddleware::requireAdmin()) return;
        try {
            $result = $this->admin->verifyKyc($this->userId(), $targetUserId);
            $this->json(200, ['ok' => true] + $result);
        } catch (RuntimeException $e) {
            $this->json(400, ['ok' => false, 'error' => $e->getMessage()]);
        }
    }

    /** POST /api/admin/users/{id}/reject-kyc */
    public function rejectKyc(string $targetUserId): void
    {
        if (!AdminMiddleware::requireAdmin()) return;
        try {
            $result = $this->admin->rejectKyc($this->userId(), $targetUserId);
            $this->json(200, ['ok' => true] + $result);
        } catch (RuntimeException $e) {
            $this->json(400, ['ok' => false, 'error' => $e->getMessage()]);
        }
    }

    /** GET /api/admin/plans */
    public function listPlans(): void
    {
        if (!AdminMiddleware::requireAdmin()) return;
        $this->json(200, ['ok' => true, 'plans' => $this->admin->listPlansWithCodes()]);
    }

    /** POST /api/admin/plans/{code}/set-code — body: {paystackPlanCode} */
    public function setPlanCode(string $planCode): void
    {
        if (!AdminMiddleware::requireAdmin()) return;
        $body = $this->jsonBody();
        $paystackPlanCode = (string)($body['paystackPlanCode'] ?? '');
        try {
            $result = $this->admin->setPlanCode($this->userId(), $planCode, $paystackPlanCode);
            $this->json(200, ['ok' => true] + $result);
        } catch (RuntimeException $e) {
            $this->json(400, ['ok' => false, 'error' => $e->getMessage()]);
        }
    }

    /** POST /api/admin/plans/{code}/clear-code */
    public function clearPlanCode(string $planCode): void
    {
        if (!AdminMiddleware::requireAdmin()) return;
        try {
            $result = $this->admin->clearPlanCode($this->userId(), $planCode);
            $this->json(200, ['ok' => true] + $result);
        } catch (RuntimeException $e) {
            $this->json(400, ['ok' => false, 'error' => $e->getMessage()]);
        }
    }

    /**
     * POST /api/admin/users/{id}/role — body: {role}
     * M6 polish: change user role. Increments role_version which invalidates
     * the user's active session on next request.
     */
    public function changeUserRole(string $targetUserId): void
    {
        if (!AdminMiddleware::requireAdmin()) return;
        $body = $this->jsonBody();
        $newRole = (string)($body['role'] ?? '');
        try {
            $result = $this->admin->changeUserRole($this->userId(), $targetUserId, $newRole);
            $this->json(200, ['ok' => true] + $result);
        } catch (RuntimeException $e) {
            $this->json(400, ['ok' => false, 'error' => $e->getMessage()]);
        }
    }

    /**
     * POST /api/admin/users/{id}/delete — GDPR soft-delete user.
     * M6 polish + M9 precursor: marks the user as deleted, cancels their
     * subscription, anonymizes their audit_log entries. Hard-delete happens
     * after USER_DELETION_RETENTION_DAYS via the GC cron.
     */
    public function deleteUser(string $targetUserId): void
    {
        if (!AdminMiddleware::requireAdmin()) return;
        try {
            $result = $this->admin->deleteUser($this->userId(), $targetUserId);
            $this->json(200, ['ok' => true] + $result);
        } catch (RuntimeException $e) {
            $this->json(400, ['ok' => false, 'error' => $e->getMessage()]);
        }
    }

    /** POST /api/admin/users/{id}/cancel-deletion — restore a soft-deleted user. */
    public function cancelUserDeletion(string $targetUserId): void
    {
        if (!AdminMiddleware::requireAdmin()) return;
        try {
            $result = $this->admin->cancelUserDeletion($this->userId(), $targetUserId);
            $this->json(200, ['ok' => true] + $result);
        } catch (RuntimeException $e) {
            $this->json(400, ['ok' => false, 'error' => $e->getMessage()]);
        }
    }

    /**
     * GET /api/admin/audit?userId=...&action=...&fromDate=...&toDate=...&limit=...
     */
    public function audit(): void
    {
        if (!AdminMiddleware::requireAdmin()) return;
        $filters = [];
        if (!empty($_GET['userId'])) $filters['userId'] = (string)$_GET['userId'];
        if (!empty($_GET['action'])) $filters['action'] = (string)$_GET['action'];
        if (!empty($_GET['fromDate'])) $filters['fromDate'] = (string)$_GET['fromDate'];
        if (!empty($_GET['toDate'])) $filters['toDate'] = (string)$_GET['toDate'];
        $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 500;
        $entries = $this->admin->listAuditEvents($filters, $limit);
        $this->json(200, ['ok' => true, 'entries' => $entries]);
    }

    // -----------------------------------------------------------------
    // Shared helpers
    // -----------------------------------------------------------------

    private function userId(): string { return (string)($_SESSION['_busifirm_user_id'] ?? ''); }
    // XFILE-009 fix: removed dead `ip()` and `userAgent()` methods. They were
    // never called from this controller — AdminService::audit() reads
    // $_SERVER['REMOTE_ADDR'] and $_SERVER['HTTP_USER_AGENT'] directly (which
    // is itself a bug flagged as XFILE-008, but fixing that is a larger refactor
    // that requires a shared Request::ip() helper). These dead methods were
    // leftovers from a design that intended to pass ip/UA through the controller
    // layer but was never wired up.
    private function jsonBody(): array
    {
        $raw = file_get_contents('php://input') ?: '';
        if ($raw === '') return [];
        $data = json_decode($raw, true);
        return is_array($data) ? $data : [];
    }
    private function json(int $status, array $payload): void
    {
        http_response_code($status);
        header('Content-Type: application/json; charset=utf-8');
        header('X-Content-Type-Options: nosniff');
        header('Cache-Control: no-store, no-cache, must-revalidate, private');
        echo json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    }
}
