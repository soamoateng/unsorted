<?php
declare(strict_types=1);

namespace Busifirm\Controllers;

use Busifirm\Services\ListingService;
use RuntimeException;

/**
 * ListingController — thin HTTP layer over ListingService.
 *
 * All endpoints require an authenticated user (enforced by the front
 * controller's routing layer — every non-authless route calls
 * AuthMiddleware::requireUser() before dispatching).
 */
final class ListingController
{
    public function __construct(
        private readonly ListingService $listings,
        private readonly \Busifirm\Services\AuditService $audit
    ) {}

    /** GET /api/listings */
    public function list(): void
    {
        $userId = $this->userId();
        $rows = $this->listings->listForUser($userId);
        $this->json(200, ['ok' => true, 'listings' => $rows]);
    }

    /** GET /api/listings/{id} */
    public function get(string $id): void
    {
        $row = $this->listings->getById($id, $this->userId());
        if ($row === null) {
            $this->json(404, ['ok' => false, 'error' => 'Listing not found.']);
            return;
        }
        $this->json(200, ['ok' => true, 'listing' => $row]);
    }

    /** POST /api/listings — body: listing fields */
    public function save(): void
    {
        $body = $this->jsonBody();
        try {
            // M3 RBAC: role is read from session (cached at login) and passed
            // to the service. Service throws if role lacks canCreateListings().
            // M4 polish: service also throws 'plan_limit_reached:' if the user
            // has hit their plan's max_listings quota.
            $saved = $this->listings->save($body, $this->userId(), $this->role());
            $this->audit->log($this->userId(), 'Listing saved',
                ['listingId' => $saved['id'], 'name' => $saved['companyName']],
                $this->ip(), $this->userAgent());
            $this->json(200, ['ok' => true, 'listing' => $saved]);
        } catch (RuntimeException $e) {
            $msg = $e->getMessage();
            // Distinguish: RBAC denial (403), plan limit (402), validation (400).
            $status = str_starts_with($msg, 'plan_limit_reached:')
                ? 402
                : (str_contains($msg, 'role') ? 403 : 400);
            // OTH-28 fix: strip the technical 'plan_limit_reached:' prefix from
            // the user-facing error message — it's an internal routing hint, not
            // something the user should see.
            $userMsg = str_starts_with($msg, 'plan_limit_reached:')
                ? substr($msg, strlen('plan_limit_reached: '))
                : $msg;
            $this->json($status, ['ok' => false, 'error' => $userMsg]);
        }
    }

    /** POST /api/listings/{id}/delete (POST not DELETE because HTML forms only do GET/POST) */
    public function delete(string $id): void
    {
        try {
            $this->listings->delete($id, $this->userId(), $this->role());
            $this->audit->log($this->userId(), 'Listing deleted', ['listingId' => $id],
                $this->ip(), $this->userAgent());
            $this->json(200, ['ok' => true]);
        } catch (RuntimeException $e) {
            $status = str_contains($e->getMessage(), 'role') ? 403 : 400;
            $this->json($status, ['ok' => false, 'error' => $e->getMessage()]);
        }
    }

    /** GET /api/listings/duplicate?companyName=... */
    public function checkDuplicate(): void
    {
        $name = (string)($_GET['companyName'] ?? '');
        $excludeId = $_GET['excludeId'] ?? null;
        $isDup = $this->listings->isDuplicate($name, $excludeId);
        $this->json(200, ['ok' => true, 'duplicate' => $isDup]);
    }

    // OTH-07 fix: updated comment. The codebase now has 12 controllers, well past
    // the ≥5 threshold. The shared helpers (userId, ip, userAgent, jsonBody, json)
    // should be extracted to a trait. Tracked as tech debt — not extracted yet to
    // avoid breaking changes across all controllers in a bug-fix iteration.

    private function userId(): string
    {
        return (string)($_SESSION['_busifirm_user_id'] ?? '');
    }

    /**
     * M3 RBAC: read the cached role from the session. Set at login by
     * AuthController::startSession. Stale-role risk: if an admin promotes
     * a user without re-issuing the session, the cached role lags until
     * next login. Phase 3 admin panel will invalidate sessions on role change.
     */
    private function role(): string
    {
        return (string)($_SESSION['_busifirm_role'] ?? '');
    }

    private function ip(): string { return $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1'; }
    private function userAgent(): string { return substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 512); }

    private function jsonBody(): array
    {
        $raw = file_get_contents('php://input') ?: '';
        if ($raw === '') return [];
        $data = json_decode($raw, true);
        return is_array($data) ? $data : [];
    }

    private function json(int $status, array $payload): void
    {
        http_response_code($status);
        header('Content-Type: application/json; charset=utf-8');
        header('X-Content-Type-Options: nosniff');
        header('Cache-Control: no-store, no-cache, must-revalidate, private');
        echo json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    }
}
