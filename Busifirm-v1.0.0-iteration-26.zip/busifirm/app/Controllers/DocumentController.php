<?php
declare(strict_types=1);

namespace Busifirm\Controllers;

use Busifirm\Services\AuditService;
use Busifirm\Services\DocumentService;
use RuntimeException;

/**
 * DocumentController — thin HTTP layer over DocumentService.
 *
 * Endpoints:
 *   POST   /api/documents                  — multipart upload (file + purpose)
 *   GET    /api/documents                  — list user's documents (?purpose=kyc)
 *   GET    /api/documents/{id}             — download (streams file with headers)
 *   POST   /api/documents/{id}/delete      — soft-delete
 *   POST   /api/documents/chunk            — start chunked upload session (M5 polish)
 *   POST   /api/documents/chunk/{id}       — upload one chunk (M5 polish)
 *   POST   /api/documents/chunk/{id}/complete  — finalize chunked upload (M5 polish)
 *   POST   /api/documents/chunk/{id}/abort — abort chunked upload (M5 polish)
 *
 * Notes:
 *   - Upload uses multipart/form-data (not JSON) so the file field is in
 *     $_FILES, not php://input. The CSRF token comes through as a form field
 *     or header (front controller already verified it before dispatch).
 *   - Download sets Content-Disposition: inline for PDFs/images so the
 *     browser can preview; attachment for anything else.
 *   - Chunked upload protocol is sequential (not parallel) for KISS. The
 *     client uploads chunks one at a time; each gets a 200 back before the
 *     next is sent. Resume: if a chunk POST fails, the client re-uploads
 *     the same index — the server overwrites the staged chunk.
 */
final class DocumentController
{
    public function __construct(
        private readonly DocumentService $documents,
        private readonly AuditService $audit
    ) {}

    /** POST /api/documents — multipart upload. Form fields: file, purpose. */
    public function upload(): void
    {
        // SEC-35 fix: rate-limit uploads to 10 per minute per user.
        if (!\Busifirm\Middleware\RateLimitMiddleware::allow('doc_upload:' . $this->userId(), 10)) {
            \Busifirm\Middleware\RateLimitMiddleware::denyResponse();
            return;
        }
        if (empty($_FILES['file'])) {
            $this->json(400, ['ok' => false, 'error' => 'No file uploaded. Expected multipart/form-data with a "file" field.']);
            return;
        }
        $purpose = (string)($_POST['purpose'] ?? 'general');

        try {
            $doc = $this->documents->upload($this->userId(), $_FILES['file'], $purpose);
            $this->audit->log($this->userId(), 'Document uploaded',
                ['docId' => $doc['id'], 'purpose' => $purpose, 'filename' => $doc['originalFilename']],
                $this->ip(), $this->userAgent());
            $this->json(201, ['ok' => true, 'document' => $doc]);
        } catch (RuntimeException $e) {
            $this->json(400, ['ok' => false, 'error' => $e->getMessage()]);
        }
    }

    /** GET /api/documents?purpose=kyc */
    public function list(): void
    {
        $purpose = isset($_GET['purpose']) ? (string)$_GET['purpose'] : null;
        $docs = $this->documents->listForUser($this->userId(), $purpose);
        $this->json(200, ['ok' => true, 'documents' => $docs]);
    }

    /** GET /api/documents/{id} — streams the file. */
    public function download(string $id): void
    {
        // We need the metadata to set headers, so we re-fetch via the service.
        // The service's stream() method does the ownership check.
        $doc = $this->documents->getById($id, $this->userId());
        if ($doc === null) {
            $this->json(404, ['ok' => false, 'error' => 'Document not found.']);
            return;
        }

        // PHP-024 fix: BEFORE sending any headers, verify the file bytes still
        // exist on disk (or in S3). If the GC cron hard-deleted the file but
        // the DB row remains, OR the S3 object was evicted, return a clean
        // 404 JSON response. The old code sent 200 + Content-Length + an empty
        // body, which caused the browser to hang waiting for the promised
        // bytes until the connection timed out — no error visible to the user.
        if (!$this->documents->docExists($doc)) {
            error_log('[busifirm] Document file missing on disk for id=' . $id . ' (DB row exists; GC race or S3 eviction?).');
            $this->json(404, ['ok' => false, 'error' => 'File not found on disk. The database record exists but the underlying file is missing.']);
            return;
        }

        // Set headers for the browser.
        $mime = $doc['mimeType'];
        $filename = $doc['originalFilename'];
        $cacheAge = 3600; // PHP-039 fix: was (int)('3600') — pointless cast of a string literal. 1 hour cache.

        header('Content-Type: ' . $mime);
        header('Content-Length: ' . $doc['sizeBytes']);
        // SEC-20 fix: use 'attachment' for ALL files (was 'inline' for PDFs/images).
        // Inline PDFs can execute JavaScript in the browser's PDF viewer within
        // the app's origin. Attachment forces a download, preventing XSS.
        header('Content-Disposition: attachment; filename="' . $this->headerSafeFilename($filename) . '"');
        header('Cache-Control: private, max-age=' . $cacheAge);
        header('X-Content-Type-Options: nosniff');
        header('Accept-Ranges: bytes');

        // Stream the file. If streaming fails after the existence check (e.g.
        // a race where the file was deleted between the check and the stream),
        // we've already sent 200 + headers — the body will be empty. Log only.
        // PERF-25 fix: use streamByDoc() instead of stream() to avoid a redundant
        // getById() SELECT inside stream(). The controller already has the doc.
        $ok = $this->documents->streamByDoc($doc);
        if (!$ok) {
            error_log('[busifirm] Document stream failed for id=' . $id . ' (file disappeared between exists-check and stream?)');
        }
    }

    /** POST /api/documents/{id}/delete — soft-delete. */
    public function delete(string $id): void
    {
        try {
            $this->documents->delete($id, $this->userId());
            $this->audit->log($this->userId(), 'Document deleted', ['docId' => $id],
                $this->ip(), $this->userAgent());
            $this->json(200, ['ok' => true]);
        } catch (RuntimeException $e) {
            $this->json(400, ['ok' => false, 'error' => $e->getMessage()]);
        }
    }

    // -----------------------------------------------------------------
    // M5 polish: Chunked upload endpoints
    // -----------------------------------------------------------------

    /**
     * POST /api/documents/chunk — start a chunked upload session.
     * Body (JSON): {originalFilename, intendedMime, intendedSize, purpose, chunkSize?}
     */
    public function startChunk(): void
    {
        $body = $this->jsonBody();
        try {
            $result = $this->documents->startChunkedUpload(
                $this->userId(),
                (string)($body['originalFilename'] ?? ''),
                (string)($body['intendedMime'] ?? ''),
                (int)($body['intendedSize'] ?? 0),
                (string)($body['purpose'] ?? 'general'),
                isset($body['chunkSize']) ? (int)$body['chunkSize'] : null
            );
            $this->audit->log($this->userId(), 'Chunked upload started',
                ['uploadId' => $result['uploadId'], 'totalChunks' => $result['totalChunks']],
                $this->ip(), $this->userAgent());
            $this->json(201, ['ok' => true] + $result);
        } catch (RuntimeException $e) {
            $this->json(400, ['ok' => false, 'error' => $e->getMessage()]);
        }
    }

    /**
     * POST /api/documents/chunk/{id} — upload one chunk.
     * Multipart form fields: file (the chunk blob), index (zero-based).
     */
    public function uploadChunk(string $uploadId): void
    {
        if (empty($_FILES['file'])) {
            $this->json(400, ['ok' => false, 'error' => 'No chunk uploaded. Expected multipart with a "file" field.']);
            return;
        }
        $index = isset($_POST['index']) ? (int)$_POST['index'] : -1;
        if ($index < 0) {
            $this->json(400, ['ok' => false, 'error' => 'index form field is required and must be >= 0.']);
            return;
        }
        try {
            $result = $this->documents->uploadChunk($uploadId, $this->userId(), $index, $_FILES['file']);
            $this->json(200, ['ok' => true] + $result);
        } catch (RuntimeException $e) {
            $this->json(400, ['ok' => false, 'error' => $e->getMessage()]);
        }
    }

    /** POST /api/documents/chunk/{id}/complete — finalize chunked upload. */
    public function completeChunk(string $uploadId): void
    {
        try {
            $doc = $this->documents->completeChunkedUpload($uploadId, $this->userId());
            $this->audit->log($this->userId(), 'Chunked upload completed',
                ['docId' => $doc['id'], 'purpose' => $doc['purpose']],
                $this->ip(), $this->userAgent());
            $this->json(201, ['ok' => true, 'document' => $doc]);
        } catch (RuntimeException $e) {
            $this->json(400, ['ok' => false, 'error' => $e->getMessage()]);
        }
    }

    /** POST /api/documents/chunk/{id}/abort — abort chunked upload. */
    public function abortChunk(string $uploadId): void
    {
        try {
            $this->documents->abortChunkedUpload($uploadId, $this->userId());
            $this->audit->log($this->userId(), 'Chunked upload aborted',
                ['uploadId' => $uploadId],
                $this->ip(), $this->userAgent());
            $this->json(200, ['ok' => true]);
        } catch (RuntimeException $e) {
            $this->json(400, ['ok' => false, 'error' => $e->getMessage()]);
        }
    }

    // -----------------------------------------------------------------
    // Shared helpers
    // -----------------------------------------------------------------

    private function userId(): string { return (string)($_SESSION['_busifirm_user_id'] ?? ''); }
    private function ip(): string { return $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1'; }
    private function userAgent(): string { return substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 512); }

    /**
     * Parse the JSON request body into an array.
     *
     * XFILE-001 fix: DocumentController previously called $this->jsonBody()
     * from startChunk() but had no such method — every chunked upload >5MB
     * returned HTTP 500 with "Call to undefined method jsonBody()". This
     * helper mirrors the pattern in KycController::jsonBody and
     * ChatController::jsonBody.
     *
     * @return array  Decoded JSON body, or [] on empty/invalid input.
     */
    private function jsonBody(): array
    {
        $raw = file_get_contents('php://input') ?: '';
        if ($raw === '') return [];
        $data = json_decode($raw, true);
        return is_array($data) ? $data : [];
    }

    /**
     * Make a filename safe for the Content-Disposition header. RFC 6266
     * recommends using the filename* parameter with percent-encoding for
     * non-ASCII; for simplicity we use the bare filename with quotes escaped.
     */
    private function headerSafeFilename(string $name): string
    {
        $clean = str_replace(['"', '\\', "\r", "\n"], '', $name);
        return mb_substr($clean, 0, 200);
    }

    private function json(int $status, array $payload): void
    {
        http_response_code($status);
        header('Content-Type: application/json; charset=utf-8');
        header('X-Content-Type-Options: nosniff');
        header('Cache-Control: no-store, no-cache, must-revalidate, private');
        echo json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    }
}
