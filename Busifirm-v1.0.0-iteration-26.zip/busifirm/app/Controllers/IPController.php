<?php
declare(strict_types=1);

namespace Busifirm\Controllers;

use Busifirm\Services\IPService;

/**
 * IPController — read-only marketplace catalog.
 *
 * Public IPs are visible to all authenticated users (no per-user ownership
 * yet). Search uses query-string filters.
 */
final class IPController
{
    public function __construct(
        private readonly IPService $ips
    ) {}

    /** GET /api/ips?q=...&sector=...&type=... */
    public function search(): void
    {
        $q = isset($_GET['q']) ? (string)$_GET['q'] : null;
        $filters = [];
        if (!empty($_GET['sector'])) $filters['sector'] = (string)$_GET['sector'];
        if (!empty($_GET['type'])) $filters['type'] = (string)$_GET['type'];
        $rows = $this->ips->search($q, $filters);
        $this->json(200, ['ok' => true, 'ips' => $rows]);
    }

    /** GET /api/ips/all — full catalog, no filters */
    public function all(): void
    {
        $this->json(200, ['ok' => true, 'ips' => $this->ips->getAll()]);
    }

    /** GET /api/ips/{id} */
    public function get(string $id): void
    {
        $row = $this->ips->getById($id);
        if ($row === null) {
            $this->json(404, ['ok' => false, 'error' => 'IP not found.']);
            return;
        }
        $this->json(200, ['ok' => true, 'ip' => $row]);
    }

    private function json(int $status, array $payload): void
    {
        http_response_code($status);
        header('Content-Type: application/json; charset=utf-8');
        header('X-Content-Type-Options: nosniff');
        header('Cache-Control: no-store, no-cache, must-revalidate, private');
        echo json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    }
}
