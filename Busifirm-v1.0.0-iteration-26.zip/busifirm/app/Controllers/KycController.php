<?php
declare(strict_types=1);

namespace Busifirm\Controllers;

use Busifirm\Services\AuditService;
use Busifirm\Services\KycService;
use RuntimeException;

final class KycController
{
    public function __construct(
        private readonly KycService $kyc,
        private readonly AuditService $audit
    ) {}

    /** GET /api/kyc */
    public function getStatus(): void
    {
        $status = $this->kyc->getStatus($this->userId());
        $this->json(200, ['ok' => true, 'kyc' => $status]);
    }

    /** POST /api/kyc — update status (M5 will replace with file upload) */
    public function updateStatus(): void
    {
        $body = $this->jsonBody();
        $status = (string)($body['status'] ?? '');
        $documents = $body['documents'] ?? [];
        try {
            $result = $this->kyc->updateStatus($this->userId(), $status, $documents);
            $this->audit->log($this->userId(), 'KYC status updated', ['status' => $status],
                $this->ip(), $this->userAgent());
            $this->json(200, ['ok' => true, 'kyc' => $result]);
        } catch (RuntimeException $e) {
            $this->json(400, ['ok' => false, 'error' => $e->getMessage()]);
        }
    }

    private function userId(): string { return (string)($_SESSION['_busifirm_user_id'] ?? ''); }
    private function ip(): string { return $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1'; }
    private function userAgent(): string { return substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 512); }
    private function jsonBody(): array
    {
        $raw = file_get_contents('php://input') ?: '';
        if ($raw === '') return [];
        $data = json_decode($raw, true);
        return is_array($data) ? $data : [];
    }
    private function json(int $status, array $payload): void
    {
        http_response_code($status);
        header('Content-Type: application/json; charset=utf-8');
        header('X-Content-Type-Options: nosniff');
        header('Cache-Control: no-store, no-cache, must-revalidate, private');
        echo json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    }
}
