<?php
declare(strict_types=1);

namespace Busifirm\Controllers;

// XFILE-015 fix: removed `use Busifirm\Core\Database;` — it was imported but
// never referenced anywhere in this file. All DB access is delegated to
// BillingService / UserService / AuditService.
use Busifirm\Services\AuditService;
use Busifirm\Services\BillingService;
use Busifirm\Services\UserService;
use RuntimeException;

/**
 * BillingController — thin HTTP layer over BillingService.
 *
 * Endpoints:
 *   GET  /api/billing/plans             — public plan catalog (any auth user)
 *   GET  /api/billing/me                 — current subscription + plan
 *   POST /api/billing/checkout           — start Paystack checkout (returns authorization_url)
 *   GET  /api/billing/return?reference=  — Paystack redirect-back (verifies + activates)
 *   POST /api/billing/cancel             — cancel active subscription
 *   POST /api/billing/webhook            — Paystack webhook (CSRF-exempt + auth-exempt)
 *   POST /api/billing/trial              — start a no-card 14-day trial (M4 polish)
 *   POST /api/billing/change-plan        — upgrade (prorated) or schedule downgrade (M4 polish)
 *   GET  /api/billing/proration?planCode=— preview proration charge without committing
 *
 * The webhook endpoint is registered separately in the front controller
 * because it skips both CSRF and AuthMiddleware — Paystack has no session.
 * Signature verification replaces both.
 */
final class BillingController
{
    public function __construct(
        private readonly BillingService $billing,
        private readonly AuditService $audit,
        private readonly UserService $users
    ) {}

    /** GET /api/billing/plans */
    public function plans(): void
    {
        $this->json(200, ['ok' => true, 'plans' => $this->billing->listPlans()]);
    }

    /** GET /api/billing/me — current subscription + plan for the logged-in user */
    public function me(): void
    {
        try {
            $current = $this->billing->getCurrentForUser($this->userId());
            $this->json(200, ['ok' => true, 'subscription' => $current['subscription'], 'plan' => $current['plan']]);
        } catch (RuntimeException $e) {
            $this->json(500, ['ok' => false, 'error' => $e->getMessage()]);
        }
    }

    /** POST /api/billing/checkout — body: {planCode} */
    public function checkout(): void
    {
        $body = $this->jsonBody();
        $planCode = (string)($body['planCode'] ?? '');
        if ($planCode === '') {
            $this->json(400, ['ok' => false, 'error' => 'planCode is required.']);
            return;
        }

        // Fetch the user's email — needed by Paystack.initializeTransaction.
        $user = $this->users->getCurrentUser($this->userId());
        if ($user === null) {
            $this->json(401, ['ok' => false, 'error' => 'Not authenticated.']);
            return;
        }

        try {
            $result = $this->billing->startCheckout($this->userId(), $user['email'], $planCode);
            $this->audit->log($this->userId(), 'Billing checkout started',
                ['planCode' => $planCode, 'reference' => $result['reference']],
                $this->ip(), $this->userAgent());
            $this->json(200, ['ok' => true] + $result);
        } catch (RuntimeException $e) {
            $this->json(400, ['ok' => false, 'error' => $e->getMessage()]);
        }
    }

    /** GET /api/billing/return?reference=... */
    public function returnFromPaystack(): void
    {
        $reference = (string)($_GET['reference'] ?? '');
        if ($reference === '') {
            $this->json(400, ['ok' => false, 'error' => 'reference query parameter is required.']);
            return;
        }
        try {
            $result = $this->billing->handleReturn($reference);
            $this->audit->log($this->userId(), 'Billing return processed',
                ['reference' => $reference, 'status' => $result['status']],
                $this->ip(), $this->userAgent());
            $this->json(200, ['ok' => true] + $result);
        } catch (RuntimeException $e) {
            $this->json(400, ['ok' => false, 'error' => $e->getMessage()]);
        }
    }

    /** POST /api/billing/cancel */
    public function cancel(): void
    {
        try {
            $result = $this->billing->cancelSubscription($this->userId());
            $this->audit->log($this->userId(), 'Subscription cancelled', [],
                $this->ip(), $this->userAgent());
            $this->json(200, ['ok' => true] + $result);
        } catch (RuntimeException $e) {
            $this->json(400, ['ok' => false, 'error' => $e->getMessage()]);
        }
    }

    /**
     * POST /api/billing/trial — body: {planCode}
     * M4 polish: start a no-card 14-day trial. Returns the trial end date.
     */
    public function startTrial(): void
    {
        $body = $this->jsonBody();
        $planCode = (string)($body['planCode'] ?? '');
        if ($planCode === '') {
            $this->json(400, ['ok' => false, 'error' => 'planCode is required.']);
            return;
        }
        try {
            $result = $this->billing->startTrial($this->userId(), $planCode);
            $this->audit->log($this->userId(), 'Trial started',
                ['planCode' => $planCode, 'trialEndsAt' => $result['trialEndsAt']],
                $this->ip(), $this->userAgent());
            $this->json(200, ['ok' => true] + $result);
        } catch (RuntimeException $e) {
            $this->json(400, ['ok' => false, 'error' => $e->getMessage()]);
        }
    }

    /**
     * POST /api/billing/change-plan — body: {planCode}
     * M4 polish: upgrade (prorated, immediate) or schedule downgrade.
     */
    public function changePlan(): void
    {
        $body = $this->jsonBody();
        $planCode = (string)($body['planCode'] ?? '');
        if ($planCode === '') {
            $this->json(400, ['ok' => false, 'error' => 'planCode is required.']);
            return;
        }
        $user = $this->users->getCurrentUser($this->userId());
        if ($user === null) {
            $this->json(401, ['ok' => false, 'error' => 'Not authenticated.']);
            return;
        }
        try {
            $result = $this->billing->changePlan($this->userId(), $user['email'], $planCode);
            $this->audit->log($this->userId(), 'Plan change',
                ['planCode' => $planCode, 'action' => $result['action']],
                $this->ip(), $this->userAgent());
            $this->json(200, ['ok' => true] + $result);
        } catch (RuntimeException $e) {
            $this->json(400, ['ok' => false, 'error' => $e->getMessage()]);
        }
    }

    /**
     * GET /api/billing/proration?planCode=...
     * M4 polish: preview the prorated charge for upgrading to planCode.
     * Does NOT commit — useful for showing the user "You'll be charged X today".
     */
    public function previewProration(): void
    {
        $planCode = (string)($_GET['planCode'] ?? '');
        if ($planCode === '') {
            $this->json(400, ['ok' => false, 'error' => 'planCode query parameter is required.']);
            return;
        }
        try {
            $current = $this->billing->getCurrentForUser($this->userId());
            $currentPlan = $current['plan'];
            $currentSub = $current['subscription'];
            if ($currentPlan['code'] === $planCode) {
                $this->json(400, ['ok' => false, 'error' => 'You are already on this plan.']);
                return;
            }
            $newPlan = $this->billing->getPlanByCode($planCode);
            if ($newPlan === null) {
                $this->json(400, ['ok' => false, 'error' => 'Plan not found.']);
                return;
            }
            if ($newPlan['priceKobo'] <= $currentPlan['priceKobo']) {
                // Downgrade — no charge today.
                $this->json(200, [
                    'ok' => true,
                    'action' => 'downgrade_scheduled',
                    'planCode' => $planCode,
                    'amountKobo' => 0,
                    'scheduledFor' => $currentSub['nextBillingAt'] ?? date(DATE_ATOM, strtotime('+30 days')),
                ]);
                return;
            }
            $proration = $this->billing->calculateProration(
                $currentPlan,
                $newPlan,
                $currentSub['nextBillingAt'] ?? null
            );
            $this->json(200, [
                'ok' => true,
                'action' => 'upgrade',
                'planCode' => $planCode,
                'currentPlanCode' => $currentPlan['code'],
                'amountKobo' => $proration['amountKobo'],
                'amountGhs' => round($proration['amountKobo'] / 100, 2),
                'daysRemaining' => $proration['daysRemaining'],
                'oldCreditKobo' => $proration['oldCreditKobo'],
                'newChargeKobo' => $proration['newChargeKobo'],
            ]);
        } catch (RuntimeException $e) {
            $this->json(400, ['ok' => false, 'error' => $e->getMessage()]);
        }
    }

    /**
     * POST /api/billing/webhook — Paystack webhook.
     *
     * This endpoint is special: it does NOT require CSRF or AuthMiddleware.
     * Instead, it verifies the x-paystack-signature header. The front controller
     * routes /api/billing/webhook to this method directly, bypassing the
     * standard domain API pipeline.
     *
     * Returns 200 always (for valid signatures) so Paystack doesn't retry.
     */
    public function webhook(): void
    {
        // SEC-17 fix: limit the raw body size to 1MB. The old code read all of
        // php://input with no limit — a malicious peer could exhaust memory.
        $rawBody = file_get_contents('php://input', false, null, 0, 1048576) ?: '';
        $signature = (string)($_SERVER['HTTP_X_PAYSTACK_SIGNATURE'] ?? '');

        try {
            $result = $this->billing->handleWebhook($rawBody, $signature);
            // Always return 200 for valid signatures; Paystack retries on non-2xx.
            $this->json(200, ['ok' => true, 'result' => $result]);
        } catch (RuntimeException $e) {
            $msg = $e->getMessage();
            // SEC-34 fix: distinguish invalid signature (401) from malformed payload (400).
            // Invalid signature → 401 so Paystack knows the secret may need updating.
            // Malformed payload → 400 so Paystack doesn't retry garbage.
            // PHP-052 fix: "not configured" (missing PAYSTACK_WEBHOOK_SECRET) returns 500
            // (server misconfiguration) instead of 400. Paystack doesn't retry on 400,
            // so a config error would silently drop every webhook.
            if (str_contains($msg, 'not configured')) {
                http_response_code(500);
            } elseif (str_contains($msg, 'signature')) {
                http_response_code(401);
            } else {
                http_response_code(400);
            }
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode(['ok' => false, 'error' => $msg]);
        }
    }

    // -----------------------------------------------------------------
    // Shared helpers (same pattern as other controllers; KISS duplication)
    // -----------------------------------------------------------------

    private function userId(): string { return (string)($_SESSION['_busifirm_user_id'] ?? ''); }
    private function ip(): string { return $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1'; }
    private function userAgent(): string { return substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 512); }
    private function jsonBody(): array
    {
        $raw = file_get_contents('php://input') ?: '';
        if ($raw === '') return [];
        $data = json_decode($raw, true);
        return is_array($data) ? $data : [];
    }
    private function json(int $status, array $payload): void
    {
        http_response_code($status);
        header('Content-Type: application/json; charset=utf-8');
        header('X-Content-Type-Options: nosniff');
        header('Cache-Control: no-store, no-cache, must-revalidate, private');
        echo json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    }
}
