<?php
declare(strict_types=1);

namespace Busifirm\Controllers;

use Busifirm\Services\AuditService;
use Busifirm\Services\ESignService;
use RuntimeException;

/**
 * ESignController — thin HTTP layer over ESignService.
 *
 * M3 RBAC additions:
 *   - GET /api/esigns/awaiting-witness — lawyers only; lists documents
 *     owned by other users that don't yet have a witness.
 *   - POST /api/esigns/{id}/witness-sign — lawyers only; co-signs the
 *     document as a witness.
 */
final class ESignController
{
    public function __construct(
        private readonly ESignService $esigns,
        private readonly AuditService $audit
    ) {}

    /** GET /api/esigns */
    public function list(): void
    {
        $this->json(200, ['ok' => true, 'documents' => $this->esigns->listForUser($this->userId())]);
    }

    /**
     * GET /api/esigns/awaiting-witness — documents owned by other users
     * that don't yet have a witness signature. UI only shows this to lawyers;
     * the actual role enforcement happens at witnessSign().
     */
    public function listAwaitingWitness(): void
    {
        $docs = $this->esigns->listAwaitingWitness($this->userId());
        $this->json(200, ['ok' => true, 'documents' => $docs]);
    }

    /** POST /api/esigns — create or update */
    public function save(): void
    {
        try {
            $doc = $this->esigns->save($this->userId(), $this->jsonBody());
            $this->audit->log($this->userId(), 'ESign document saved', ['docId' => $doc['id']],
                $this->ip(), $this->userAgent());
            $this->json(200, ['ok' => true, 'document' => $doc]);
        } catch (RuntimeException $e) {
            $this->json(400, ['ok' => false, 'error' => $e->getMessage()]);
        }
    }

    /**
     * POST /api/esigns/{id}/witness-sign — lawyer co-signs as witness.
     * SEC-01 fix: the lawyer's email is now read from the session (cached at
     * login via AuthController::startSession which queries the users table)
     * instead of being accepted from the request body. This prevents a lawyer
     * from spoofing another lawyer's email in the audit trail.
     */
    public function witnessSign(string $id): void
    {
        // SEC-01 fix: get email from session instead of request body.
        $lawyerEmail = (string)($_SESSION['_busifirm_user_email'] ?? '');
        if ($lawyerEmail === '') {
            $this->json(400, ['ok' => false, 'error' => 'Unable to determine your email. Please log in again.']);
            return;
        }
        try {
            $doc = $this->esigns->witnessSign($id, $this->userId(), $lawyerEmail, $this->role());
            $this->audit->log($this->userId(), 'Document witness-signed',
                ['docId' => $id, 'lawyerEmail' => $lawyerEmail],
                $this->ip(), $this->userAgent());
            $this->json(200, ['ok' => true, 'document' => $doc]);
        } catch (RuntimeException $e) {
            $status = str_contains($e->getMessage(), 'role') ? 403 : 400;
            $this->json($status, ['ok' => false, 'error' => $e->getMessage()]);
        }
    }

    private function userId(): string { return (string)($_SESSION['_busifirm_user_id'] ?? ''); }
    private function role(): string { return (string)($_SESSION['_busifirm_role'] ?? ''); }
    private function ip(): string { return $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1'; }
    private function userAgent(): string { return substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 512); }
    private function jsonBody(): array
    {
        $raw = file_get_contents('php://input') ?: '';
        if ($raw === '') return [];
        $data = json_decode($raw, true);
        return is_array($data) ? $data : [];
    }
    private function json(int $status, array $payload): void
    {
        http_response_code($status);
        header('Content-Type: application/json; charset=utf-8');
        header('X-Content-Type-Options: nosniff');
        header('Cache-Control: no-store, no-cache, must-revalidate, private');
        echo json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    }
}
