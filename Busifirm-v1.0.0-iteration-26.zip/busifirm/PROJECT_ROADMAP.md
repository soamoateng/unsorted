# Busifirm — SaaS Roadmap (Agile, 4 Phases)

> **Project:** Busifirm — Ghana Tech M&A Platform
> **Current state (v0.9.2-iteration-20):** All Must-have items (M1–M10) implemented. M4/M5/M6 polish complete. v0.9.2 fixes 10 app workflow bugs. v0.9.1 fixed 9 performance bugs. v0.9.0 fixed all security bugs. v0.8.x fixed all BL/UX/UI/OTH bugs. Remaining: M9 GDPR export, M10 backups, infrastructure.
> **Target state:** Production SaaS with PHP 8.3 + MySQL 8.4 backend, server-side user authentication, Paystack payment integration, and the existing UI/UX preserved 1:1.
> **Versioning scheme:** Semantic Versioning — `MAJOR.MINOR.PATCH`. Current = `v0.9.2`. Each phase ships a tagged release.
> **Iteration cadence:** 2-week sprints. Each phase = 2–3 sprints.
> **Source-of-truth date:** August 2026. All library versions, SDK picks, and API references below were chosen against the August 2026 ecosystem state.

## Phase Status (as of v0.9.2)

| Phase | Status | Tag | Notes |
|-------|--------|-----|-------|
| Phase 0 — Foundation | ✅ Done | v0.1.0 | Repo restructure, env, CI baseline. |
| Phase 1 — DB / Auth / API | ✅ Done | v0.2.0–v0.6.0 | M1 (auth), M2 (MySQL migration), M3 (RBAC), M5 (document storage). |
| Phase 2 — Paystack | ✅ Done | v0.5.0 | M4 (subscription billing + webhook). |
| Phase 3 — Production Hardening | 🟡 Partial | — | M6 (admin panel) done. M4/M5/M6 polish done in v0.8.0. M9 GDPR export + M10 backup automation + infra (Nginx/SMTP/observability) remain. |
| Phase 4 — Post-Launch Iteration | ⏳ Pending | — | Starts after v1.0.0. |

## MoSCoW Spec Coverage (Must-have items)

| ID | Spec | Status | Iteration |
|----|------|--------|-----------|
| M1 | Server-side auth (bcrypt + email verify + password reset) | ✅ Done | iter-2 (v0.2.0) |
| M2 | MySQL migration of all localStorage stores | ✅ Done | iter-3 (v0.3.0) |
| M3 | RBAC (seller/broker for listings, lawyer for witness) | ✅ Done | iter-4 (v0.4.0) |
| M4 | Paystack subscription billing | ✅ Done | iter-5 (v0.5.0) |
| M5 | Document storage (KYC + esign file uploads) | ✅ Done | iter-6 (v0.6.0) |
| M6 | Admin audit panel (KYC verification + plan-code management) | ✅ Done | iter-7 (v0.7.0) |
| M7 | CSRF protection + rate limiting | ✅ Done | iter-2 (v0.2.0) |
| M8 | Paystack webhook signature verification | ✅ Done | iter-5 (v0.5.0) |
| M9 | Tamper-evident server-side audit log | ✅ Done (delete) / ⏳ Export pending | iter-2 + iter-8 (delete) |
| M10 | HTTPS-only + secure cookies + automated backups | ✅ HTTPS+cookies / ⏳ Backups pending | iter-2 |

## Polish Items (v0.8.0)

| ID | Polish Item | Status |
|----|-------------|--------|
| M4-polish-1 | Proration (immediate charge on upgrade; scheduled downgrade) | ✅ Done |
| M4-polish-2 | 14-day no-card trial periods | ✅ Done |
| M4-polish-3 | Plan enforcement on max_listings + max_chat_per_day (HTTP 402) | ✅ Done |
| M5-polish-1 | Pluggable storage backend (StorageInterface + LocalStorage + S3Storage) | ✅ Done |
| M5-polish-2 | finfo_file() content-based MIME validation | ✅ Done |
| M5-polish-3 | ClamAV virus scanning via clamd INSTREAM | ✅ Done |
| M5-polish-4 | Chunked upload protocol (3 endpoints + frontend helper) | ✅ Done |
| M5-polish-5 | Disk GC cron (hard-delete soft-deleted documents past retention) | ✅ Done |
| M6-polish-1 | GDPR user-delete (soft-delete + anonymized audit_log + GC cron) | ✅ Done |
| M6-polish-2 | Session invalidation on role change (role_version pattern) | ✅ Done |
| M6-polish-3 | Admin role-change UI (admin can change seller/buyer/lawyer/broker) | ✅ Done |

## Remaining Phase 3 Work

| ID | Item | Notes |
|----|------|-------|
| M9-export | `GET /api/account/export` — JSON export of all user data | Pairs with the existing delete endpoint. |
| M10-backup | Nightly `mysqldump` to off-box S3-compatible bucket; 30-day retention; restore drill | Documented in Phase 3 below. |
| Infra-Nginx | Ubuntu 24.04 LTS VPS, Nginx 1.26, PHP 8.3-FPM, Let's Encrypt | SSL A-grade target. |
| Infra-SMTP | SMTP via Sendgrid/Postmark for email deliverability | Replaces PHP `mail()`. Mailer interface already swap-ready. |
| Infra-Redis | Redis for rate-limiting + per-user daily chat counter cache | Replaces file-based rate limiter. |
| Infra-Sessions | DB-backed sessions for instant invalidation | Currently using PHP native sessions + role_version pattern. |
| Pen-test | OWASP Top 10 + sqlmap + XSS audit | Pre-launch checklist. |
| Load-test | k6 with 50 concurrent users | p95 < 500ms target. |

---

## Guiding Principles

1. **Preserve intent & UI 1:1.** The existing `index.html` / `style.css` structure stays. The PHP backend replaces the localStorage data layer behind the same JS calls — no new screens, no new CSS classes, no removed features.
2. **DRY / KISS / SOLID on the backend.** Single `Database` PDO wrapper. Thin controllers. One `PaystackClient` service. No abstract framework unless complexity demands it.
3. **Security-first defaults.** Argon2id password hashing (`PASSWORD_ARGON2ID`), prepared statements everywhere, CSRF tokens on every mutating form, rate-limited auth endpoints, HTTPS-only cookies, Paystack webhook signature verification.
4. **Ghana compliance posture.** Data Protection Act, 2012 (Act 843) awareness; Companies Act, 2019 (Act 992) for M&A flow; GDPR-style consent UX kept from the existing frontend.

---

## Phase 0 — Foundation & Hardening  *(Sprint 0, ~2 weeks)*

**Goal:** Lift the frontend into a server-served project without changing the UI; stand up the dev environment and CI baseline.

| # | Work item | Acceptance criteria |
|---|-----------|---------------------|
| 0.1 | Repo restructure to PHP project layout (see "Target folder layout" below) | `index.html` served via `public/index.php` front controller; static assets still resolve. |
| 0.2 | Introduce `composer.json` (PHP 8.3+) with `vlucas/phpdotenv` for env, `bramus/router` for routing (or equivalent minimal router) | `composer install` produces a working dev server; no framework lock-in. |
| 0.3 | Move secrets out of JS — the current `'busifirm-salt-2026'` SHA-256 scheme in `js/app.js` is **insecure and must be deleted** in Phase 1; here we only flag it via a `TODO(Phase-1)` comment. | Audit log entry added; no functional change yet. |
| 0.4 | Add `.env.example`, `.gitignore`, `README.md`, `phpunit.xml` | New contributor can clone + `composer install` + `cp .env.example .env` + run. |
| 0.5 | CI: GitHub Actions workflow running `php -l`, `phpunit`, `phpcs` (PSR-12) | Pipeline green on `main`. |

**Definition of Done (Phase 0):** the existing SPA renders identically through `php -S localhost:8000 -t public`, CI is green, no `dayleedeals` strings remain anywhere, project is now a PHP project in name and structure.

---

## Phase 1 — Database, Auth & API Backbone  *(Sprints 1–2, ~4 weeks)*

**Goal:** Replace `localStorage` persistence with MySQL; replace the client-side "hash + salt" mock with real server-side auth.

### 1A. Database schema (MySQL 8.4, utf8mb4 / utf8mb4_0900_ai_ci)

Tables (first normal form, FK-enforced):

- `users` — `id (CHAR(36) PK)`, `email (VARCHAR(255) UNIQUE)`, `password_hash (VARCHAR(255))`, `full_name`, `role ENUM('user','admin')`, `kyc_status ENUM('unverified','pending','verified','rejected')`, `created_at`, `updated_at`, `deleted_at NULL`
- `sessions` — `id (CHAR(36) PK)`, `user_id (FK)`, `csrf_token`, `expires_at`, `ip_hash`, `user_agent_hash`
- `listings` — `id`, `user_id (FK)`, `company_name`, `sector`, `revenue`, `valuation`, `description`, `status ENUM('draft','active','closed')`, timestamps
- `ips` — `id`, `listing_id (FK)`, `title`, `type`, `patent_no`, `description`, timestamps
- `deals` — `id`, `listing_id (FK)`, `buyer_id (FK)`, `status`, `agreed_price`, timestamps
- `esignatures` — `id`, `deal_id (FK)`, `signer_id (FK)`, `document_hash`, `signed_at`, `ip_hash`
- `audit_log` — `id`, `user_id (FK NULL)`, `action`, `metadata JSON`, `ip_hash`, `created_at`
- `chat_conversations` / `chat_messages` — normalized from the current `busifirm_chat` localStorage blob
- `integrations` — `id`, `user_id (FK)`, `provider`, `credentials_encrypted`, `created_at`
- `payments` — `id`, `user_id (FK)`, `paystack_reference UNIQUE`, `amount_kobo`, `currency CHAR(3)`, `status ENUM('pending','success','failed','refunded')`, `metadata JSON`, `paid_at NULL`, timestamps

Migrations: plain SQL files under `database/migrations/` numbered `YYYYMMDDHHMMSS_name.sql`; a tiny `bin/migrate.php` runner applies them in order and records applied migrations in a `migrations_applied` table.

### 1B. Backend service classes (SOLID, but KISS — no framework)

```
app/
  Core/
    Database.php          # PDO singleton, prepared-statement helper
    Config.php            # reads .env, typed accessors
    Csrf.php              # token issue + verify
    Validator.php         # small rule engine, no external dep
  Services/
    UserService.php       # registration, login, session, password reset
    ListingService.php    # CRUD + status transitions
    DealService.php
    AuditService.php
    ChatService.php
    PaystackClient.php    # Phase 2 — declared here as interface placeholder
  Controllers/
    AuthController.php
    ListingController.php
    DealController.php
    ChatController.php
    AuditController.php
  Middleware/
    AuthMiddleware.php
    RateLimitMiddleware.php
public/
  index.php               # front controller — wires router → controllers
```

Each controller is **thin** (parses request, calls service, returns JSON). Each service owns one business area (Single Responsibility). Controllers depend on service interfaces (Dependency Inversion via constructor injection). No abstract base classes unless ≥2 controllers share real behavior — keeping KISS.

### 1C. Auth flows

| Flow | Endpoint | Notes |
|------|----------|-------|
| Register | `POST /api/auth/register` | Argon2id hash; email verification token (signed, 24h). |
| Verify email | `GET /api/auth/verify?token=` | Marks `email_verified_at`. |
| Login | `POST /api/auth/login` | Rate-limited 5/minute/IP. Issues session cookie (`Secure`, `HttpOnly`, `SameSite=Lax`) + CSRF token. |
| Logout | `POST /api/auth/logout` | Destroys server session row. |
| Forgot / reset password | `POST /api/auth/forgot`, `POST /api/auth/reset` | Signed token, 1h expiry. |
| Me | `GET /api/auth/me` | Returns current user (or 401). |

**Migration of existing users:** none. The current `busifirm_users` localStorage blob uses the (insecure) client-side SHA-256 hash — those credentials cannot be migrated as-is. Phase 1 ships a **forced password reset** for any user who appears in a `busifirm_users` export; we email them a one-time reset link. This is documented in the upgrade guide.

### 1D. Frontend swap

The existing `js/app.js` calls `Storage.get('busifirm_*')` everywhere. We introduce a single **adapter shim** — `js/api.js` — that exposes the same surface the rest of `app.js` expects, but routes calls to `/api/*` via `fetch`. The Storage module is kept only for non-sensitive draft autosave (`busifirm_listing_draft`). This is the surgical change to `app.js`:

- Delete `Utils.hashPassword` and its `'busifirm-salt-2026'` constant entirely.
- Replace `Auth.register` / `Auth.login` / `Auth.logout` to call the new endpoints and store only the returned CSRF token + non-sensitive user object in memory (not localStorage).
- All `Storage.get('busifirm_users')`, `busifirm_listings`, `busifirm_deals`, `busifirm_chat`, `busifirm_ips`, `busifirm_esigns`, `busifirm_integrations`, `busifirm_kyc`, `busifirm_audit` calls become `await API.get('/listings')` etc.

**Definition of Done (Phase 1):** a user can register, verify email, log in, create a listing, see it persist after logout/login, and the data lives in MySQL. No password ever reaches the client. Tag `v0.2.0`.

---

## Phase 2 — Paystack Payments & Subscriptions  *(Sprints 3–4, ~4 weeks)*

**Goal:** Monetize. Tiered subscription (Free / Pro / Enterprise) billed monthly in GHS via Paystack.

### 2A. Paystack integration specifics (August 2026 reality)

- **SDK choice:** Use the official Paystack REST API directly via `PaystackClient` (cURL/PDO-free, PSR-7-friendly). The PHP SDK ecosystem for Paystack (`unicodeveloper/laravel-paystack`, `stephenjude/paystack` etc.) is Laravel- or framework-coupled; for our framework-less KISS setup, a 60-line `PaystackClient` calling `https://api.paystack.co` is the cleaner choice (DRY: one service, one responsibility; KISS: no SDK dependency for an already-simple REST API).
- **Initialization:** `POST /transaction/initialize` → returns `authorization_url` + `reference`.
- **Verification:** `GET /transaction/verify/:reference` — call this **before** trusting any client-side success callback.
- **Webhook:** `POST /webhook/paystack` — verify `x-paystack-signature` HMAC-SHA512 against the secret key **before** any DB write. Idempotent on `reference`.
- **Plans:** Create recurring plans via Paystack dashboard or `POST /plan` (GHS-denominated). Subscribe users to a plan; Paystack charges automatically each cycle.
- **Test mode:** Use test keys (`sk_test_…`) and Paystack test card `4084 0830 8315 3133` (GHS). Flip keys via `.env`.

### 2B. Schema additions

- `subscriptions` — `id`, `user_id (FK)`, `plan_code VARCHAR`, `paystack_subscription_code`, `status ENUM('active','cancelled','expired')`, `started_at`, `next_billing_at`
- `invoices` — `id`, `subscription_id (FK)`, `paystack_reference`, `amount_kobo`, `status`, `paid_at`

### 2C. Flows

| Flow | Endpoint | Notes |
|------|----------|-------|
| Start checkout | `POST /api/billing/checkout` | Body: `plan_code`. Calls Paystack `initialize`, returns `authorization_url`. |
| Paystack redirect | `GET /billing/return?reference=` | Server verifies via `transaction/verify`, marks `payments` + `subscriptions` rows, redirects to dashboard with toast. |
| Webhook | `POST /webhook/paystack` | HMAC-verified, idempotent, updates `payments`/`invoices`/`subscriptions`. |
| Cancel subscription | `POST /api/billing/cancel` | Calls Paystack `disable subscription`. |
| Current plan | `GET /api/billing/me` | Returns active subscription + invoice history. |

### 2D. Frontend changes

Add a single "Billing" screen (reuses existing card/list styles — no new CSS classes). Reuse the existing `Toast` and `loadingOverlay` components for the checkout-redirect UX. No new libraries.

**Definition of Done (Phase 2):** a real GHS payment can be made in test mode, the webhook updates the DB, the user's plan is enforced (Pro-only screens gated server-side via `AuthMiddleware`), and a refund webhook correctly flips `payments.status`. Tag `v0.3.0`.

---

## Phase 3 — Production Hardening, Observability & Launch  *(Sprints 5–6, ~4 weeks)*

**Goal:** Ship to production on a Ghana-hosted or EU-hosted VPS with proper backups, monitoring, and on-call readiness.

| # | Work item | Acceptance criteria |
|---|-----------|---------------------|
| 3.1 | Infra: Ubuntu 24.04 LTS VPS, Nginx 1.26, PHP 8.3-FPM, MySQL 8.4, Let's Encrypt | `https://app.busifirm.com` returns 200; SSL A-grade on ssllabs. |
| 3.2 | Backups: `mysqldump` nightly to off-box S3-compatible bucket; 30-day retention | Restore drill passed in staging. |
| 3.3 | Observability: structured JSON logs to `/var/log/busifirm/`, simple health endpoint `/api/health`, uptime monitor (UptimeRobot or equivalent) | Alert fires within 60s of downtime. |
| 3.4 | Email: SMTP via a Ghana-friendly provider (e.g. Sendgrid, Postmark, or local SMTP relay) for verification + password reset + invoice receipts | Verification email deliverability ≥ 95% to Gmail/Outlook. |
| 3.5 | Rate limiting + brute-force protection on `/api/auth/*` and `/api/billing/webhook` | 429 returned under load test; no false positives for legit users. |
| 3.6 | GDPR / Ghana DPA Act 843: data export (`GET /api/account/export` → JSON) + delete (`DELETE /api/account`) | OTH-26 fix: DELETE is done (v0.8.0, M6 polish). EXPORT (`GET /api/account/export`) is the remaining half — returns all user-related rows as JSON. |
| 3.7 | Load test: 50 concurrent users via k6 | p95 < 500ms on listing CRUD; < 1.2s on checkout. |
| 3.8 | Pen test checklist: OWASP Top 10 pass; SQLi via sqlmap locally; XSS audit on rendered listing descriptions | All findings resolved or accepted with documented risk. |

**Definition of Done (Phase 3):** production serves real users, backups verified, monitoring alerting, compliance exports work. Tag `v1.0.0`.

---

## Phase 4 — Post-Launch Iteration Loop  *(Ongoing, every 2 weeks)*

Not a "phase" in the build sense — this is the agile steady state after v1.0.0:

- Sprint planning fed by: Paystack dispute rate, conversion Free→Pro, listing-to-deal ratio, support tickets.
- Each sprint ships a `PATCH` release (`v1.0.x`); feature work bumps `MINOR` (`v1.x.0`).
- Quarterly security review + dependency audit (`composer audit`, `npm audit`).
- Annual penetration test.

---

## Target Folder Layout (post-Phase-0)

```
busifirm/
├── app/
│   ├── Core/
│   ├── Services/
│   ├── Controllers/
│   └── Middleware/
├── database/
│   ├── migrations/
│   └── seeders/
├── public/
│   ├── index.php            # front controller
│   ├── index.html           # current SPA shell, served by PHP
│   ├── css/style.css
│   └── js/
│       ├── app.js           # existing, lightly adapted
│       └── api.js           # NEW: thin fetch adapter
├── config/
│   └── routes.php
├── bin/
│   └── migrate.php
├── tests/
│   ├── Unit/
│   └── Integration/
├── .env.example
├── .gitignore
├── composer.json
├── phpunit.xml
├── README.md
├── PROJECT_ROADMAP.md       # this file
└── worklog.md
```

---

## Risk Register

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|------------|
| Paystack changes API or webhook signing scheme | Low | High | Pin integration to documented August 2026 contract; monitor Paystack developer changelog; webhook verifier is a single class — easy to swap. |
| Client-side SHA-256 hash migration alienates existing users | High | Medium | Force-reset email + clear in-app banner; no silent credential loss. |
| Ghana DPA Act 843 enforcement tightens | Medium | Medium | `DELETE /api/account` + export endpoints shipped in Phase 3, before paid launch. |
| Scope creep — adding features mid-phase | High | Medium | Strict sprint backlog; "No Unprompted Features" rule from refactor brief enforced on the PM side too. |
| Single-VPS downtime | Medium | High | Nightly off-box backups + 1-click restore runbook; Phase 4 candidate: HA pair. |

---

## Confidence Tiers (per the adversarial reviewer protocol)

- ✅ **Verified** — long-stable APIs/standards: Argon2id (`PASSWORD_ARGON2ID`, PHP 7.3+), PDO MySQL prepared statements, CSRF same-origin tokens, HMAC-SHA512 webhook verification, Paystack REST endpoints (`/transaction/initialize`, `/transaction/verify`, `/plan`, webhook), OWASP Top 10, Semantic Versioning.
- ⚠️ **Probable** — exact PHP/MySQL/Nginx minor versions to pin in production (PHP 8.3 vs 8.4, MySQL 8.4 vs 9.x). Verify at deploy time with `php -v` and `mysql --version`; pick whatever LTS is current on your VPS at the moment of Phase 3 provisioning.
- 🚩 **Cannot verify without live access** — exact Paystack test card number validity for GHS in August 2026 and current Paystack dashboard plan-creation UI. Confirm against `https://paystack.com/docs/payments/test-cards` and `https://paystack.com/docs/recurring-billing` at Phase 2 kickoff.

---

*This roadmap is a living document. Update it at the end of every sprint with what shipped, what slipped, and what was learned.*
