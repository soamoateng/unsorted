<?php
declare(strict_types=1);

/**
 * Routes — documentation-only. The actual routing happens in public/index.php
 * via two switch statements (one for /api/auth/* and one for /api/{domain}/*).
 *
 * OTH-22 fix: updated stale comment. The route count is now 50+ (well past
 * the ~30 threshold mentioned below). This file is kept in sync manually with
 * the switch statements in index.php. If you add a route to index.php, add
 * it here too.
 *
 * Format: 'METHOD /path' => [Controller::class, 'method']
 */

return [
    // --- M1: Auth ---
    'POST /api/auth/register' => [\Busifirm\Controllers\AuthController::class, 'register'],
    'GET  /api/auth/verify'   => [\Busifirm\Controllers\AuthController::class, 'verifyEmail'],
    'POST /api/auth/login'    => [\Busifirm\Controllers\AuthController::class, 'login'],
    'POST /api/auth/logout'   => [\Busifirm\Controllers\AuthController::class, 'logout'],
    'GET  /api/auth/me'       => [\Busifirm\Controllers\AuthController::class, 'me'],
    'GET  /api/auth/csrf'     => [\Busifirm\Controllers\AuthController::class, 'csrf'],
    'POST /api/auth/forgot'   => [\Busifirm\Controllers\AuthController::class, 'forgotPassword'],
    'POST /api/auth/reset'    => [\Busifirm\Controllers\AuthController::class, 'resetPassword'],

    // --- M2: Listings ---
    'GET  /api/listings'              => [\Busifirm\Controllers\ListingController::class, 'list'],
    'POST /api/listings'              => [\Busifirm\Controllers\ListingController::class, 'save'],
    'GET  /api/listings/duplicate'    => [\Busifirm\Controllers\ListingController::class, 'checkDuplicate'],
    'GET  /api/listings/{id}'         => [\Busifirm\Controllers\ListingController::class, 'get'],
    'POST /api/listings/{id}/delete'  => [\Busifirm\Controllers\ListingController::class, 'delete'],

    // --- M2: IPs (read-only marketplace) ---
    'GET /api/ips'        => [\Busifirm\Controllers\IPController::class, 'search'],
    'GET /api/ips/all'    => [\Busifirm\Controllers\IPController::class, 'all'],
    // XFILE-022 fix: removed 'GET /api/ips/search' — the frontend calls
    // GET /api/ips?q=... (not /api/ips/search). The route still exists in
    // index.php for backward compat but is not the primary entry point.
    'GET /api/ips/{id}'   => [\Busifirm\Controllers\IPController::class, 'get'],

    // --- M2: Deals ---
    'GET  /api/deals'              => [\Busifirm\Controllers\DealController::class, 'list'],
    'POST /api/deals'              => [\Busifirm\Controllers\DealController::class, 'create'],
    'POST /api/deals/{id}'         => [\Busifirm\Controllers\DealController::class, 'update'],
    'POST /api/deals/{id}/delete'  => [\Busifirm\Controllers\DealController::class, 'delete'],

    // --- M2: Chat ---
    'GET  /api/chat'                    => [\Busifirm\Controllers\ChatController::class, 'list'],
    'POST /api/chat'                    => [\Busifirm\Controllers\ChatController::class, 'create'],
    'GET  /api/chat/{id}'               => [\Busifirm\Controllers\ChatController::class, 'get'],
    'POST /api/chat/{id}/message'       => [\Busifirm\Controllers\ChatController::class, 'sendMessage'],
    'POST /api/chat/{id}/read'          => [\Busifirm\Controllers\ChatController::class, 'markAsRead'],

    // --- M2: ESigns ---
    'GET  /api/esigns'                    => [\Busifirm\Controllers\ESignController::class, 'list'],
    'GET  /api/esigns/awaiting-witness'   => [\Busifirm\Controllers\ESignController::class, 'listAwaitingWitness'],  // M3
    'POST /api/esigns'                    => [\Busifirm\Controllers\ESignController::class, 'save'],
    'POST /api/esigns/{id}/witness-sign'  => [\Busifirm\Controllers\ESignController::class, 'witnessSign'],  // M3

    // --- M2: Integrations ---
    'GET  /api/integrations'              => [\Busifirm\Controllers\IntegrationController::class, 'get'],
    'POST /api/integrations/tasks'        => [\Busifirm\Controllers\IntegrationController::class, 'createTask'],
    'POST /api/integrations/tasks/{id}'   => [\Busifirm\Controllers\IntegrationController::class, 'updateTask'],

    // --- M2: KYC ---
    'GET  /api/kyc' => [\Busifirm\Controllers\KycController::class, 'getStatus'],
    'POST /api/kyc' => [\Busifirm\Controllers\KycController::class, 'updateStatus'],

    // --- M2: Audit ---
    'GET  /api/audit' => [\Busifirm\Controllers\AuditController::class, 'list'],
    'POST /api/audit' => [\Busifirm\Controllers\AuditController::class, 'log'],

    // --- M4: Billing (Paystack) ---
    'GET  /api/billing/plans'              => [\Busifirm\Controllers\BillingController::class, 'plans'],
    'GET  /api/billing/me'                 => [\Busifirm\Controllers\BillingController::class, 'me'],
    'POST /api/billing/checkout'           => [\Busifirm\Controllers\BillingController::class, 'checkout'],
    'GET  /api/billing/return'             => [\Busifirm\Controllers\BillingController::class, 'returnFromPaystack'],
    'POST /api/billing/cancel'             => [\Busifirm\Controllers\BillingController::class, 'cancel'],
    'POST /api/billing/webhook'            => [\Busifirm\Controllers\BillingController::class, 'webhook'],  // CSRF-exempt + auth-exempt; signature-verified

    // M4 polish: trial + plan change + proration preview.
    'POST /api/billing/trial'              => [\Busifirm\Controllers\BillingController::class, 'startTrial'],
    'POST /api/billing/change-plan'        => [\Busifirm\Controllers\BillingController::class, 'changePlan'],
    'GET  /api/billing/proration'          => [\Busifirm\Controllers\BillingController::class, 'previewProration'],

    // --- M5: Documents (file storage) ---
    'POST /api/documents'              => [\Busifirm\Controllers\DocumentController::class, 'upload'],     // multipart/form-data
    'GET  /api/documents'              => [\Busifirm\Controllers\DocumentController::class, 'list'],
    'GET  /api/documents/{id}'         => [\Busifirm\Controllers\DocumentController::class, 'download'],  // streams file
    'POST /api/documents/{id}/delete'  => [\Busifirm\Controllers\DocumentController::class, 'delete'],    // soft-delete

    // M5 polish: chunked upload protocol.
    'POST /api/documents/chunk'                  => [\Busifirm\Controllers\DocumentController::class, 'startChunk'],
    'POST /api/documents/chunk/{id}'             => [\Busifirm\Controllers\DocumentController::class, 'uploadChunk'],
    'POST /api/documents/chunk/{id}/complete'    => [\Busifirm\Controllers\DocumentController::class, 'completeChunk'],
    'POST /api/documents/chunk/{id}/abort'       => [\Busifirm\Controllers\DocumentController::class, 'abortChunk'],

    // --- M6: Admin (admin role required; AdminMiddleware enforces) ---
    'GET  /api/admin/stats'                       => [\Busifirm\Controllers\AdminController::class, 'stats'],
    'GET  /api/admin/users'                       => [\Busifirm\Controllers\AdminController::class, 'listUsers'],
    'POST /api/admin/users/{id}/verify-kyc'       => [\Busifirm\Controllers\AdminController::class, 'verifyKyc'],
    'POST /api/admin/users/{id}/reject-kyc'       => [\Busifirm\Controllers\AdminController::class, 'rejectKyc'],
    'GET  /api/admin/plans'                       => [\Busifirm\Controllers\AdminController::class, 'listPlans'],
    'POST /api/admin/plans/{code}/set-code'       => [\Busifirm\Controllers\AdminController::class, 'setPlanCode'],
    'POST /api/admin/plans/{code}/clear-code'     => [\Busifirm\Controllers\AdminController::class, 'clearPlanCode'],
    'GET  /api/admin/audit'                       => [\Busifirm\Controllers\AdminController::class, 'audit'],

    // M6 polish: role change (invalidates session) + GDPR delete + restore.
    'POST /api/admin/users/{id}/role'             => [\Busifirm\Controllers\AdminController::class, 'changeUserRole'],
    'POST /api/admin/users/{id}/delete'           => [\Busifirm\Controllers\AdminController::class, 'deleteUser'],
    'POST /api/admin/users/{id}/cancel-deletion'  => [\Busifirm\Controllers\AdminController::class, 'cancelUserDeletion'],

    // --- Health ---
    'GET /api/health' => null,  // inline in front controller
];
