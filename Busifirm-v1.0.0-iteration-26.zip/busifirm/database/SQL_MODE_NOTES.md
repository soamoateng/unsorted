# Database Configuration Notes

## SQL Mode Requirement (OTH-03)

The Busifirm codebase uses double-quoted string literals in SQL queries
(e.g., `WHERE status IN ("active", "trialing")`). This is valid MySQL syntax
when `ANSI_QUOTES` SQL mode is OFF (the default).

**If you enable `ANSI_QUOTES` mode** (common in PostgreSQL-compatible setups),
double quotes become identifier delimiters and string literals must use single
quotes. All SQL queries in the following files will fail:

- `app/Controllers/AuthController.php` (fixed in v0.8.7 — uses single quotes)
- `app/Services/AdminService.php`
- `app/Services/BillingService.php`
- `app/Services/DocumentService.php`
- `app/Services/UserService.php`
- `app/Middleware/AuthMiddleware.php`

**Recommendation:** Do not enable `ANSI_QUOTES` mode. The default MySQL
configuration (`sql_mode=ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION`)
works correctly with this codebase.

If you must use `ANSI_QUOTES`, run a global search-replace of double-quoted
SQL string literals to single-quoted ones across all PHP files in `app/`.

## Timezone Handling (OTH-09)

All timestamp columns in the Busifirm schema use MySQL `DATETIME` type, which
stores the literal value with no timezone information. The application sets
`date_default_timezone_set('Africa/Accra')` in the front controller, and
MySQL's `NOW()` uses the session timezone.

**If the DB server timezone differs from PHP's timezone**, `NOW()` and PHP's
`date()` will produce different values, causing inconsistencies.

**Recommendation:** Ensure the MySQL server timezone matches `APP_TIMEZONE`
from `.env` (default: `Africa/Accra`). Set this in MySQL's configuration:
```sql
SET GLOBAL time_zone = '+00:00';  -- UTC (Accra is UTC+0, no DST)
SET SESSION time_zone = '+00:00';
```

For future schema changes, prefer `TIMESTAMP` (UTC-stored, session-timezone-
displayed) over `DATETIME` for new tables. Migrating existing `DATETIME`
columns to `TIMESTAMP` is a destructive change deferred to a major version.

## Seed Data Re-run (OTH-11)

The seed `INSERT ... ON DUPLICATE KEY UPDATE` in migration 002 only updates
the `name` column (for `ips`) or `company_name` (for `listings`). If you
update the seed data (e.g., price, sector, description) and re-run the
migration, the other columns are NOT updated.

**To re-seed with updated data:**
```sql
-- For ips:
DELETE FROM ips WHERE id LIKE '00000000-0000-0000-0000-20000000000%';
-- Then re-run the INSERT from migration 002.

-- For listings:
DELETE FROM listings WHERE id LIKE '00000000-0000-0000-0000-20000000001%';
-- Then re-run the INSERT from migration 002.
```

Alternatively, update the `ON DUPLICATE KEY UPDATE` clause to include all
columns you want to refresh.

