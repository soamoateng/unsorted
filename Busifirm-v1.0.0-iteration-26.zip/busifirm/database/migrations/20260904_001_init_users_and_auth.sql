-- =====================================================================
-- Busifirm — Migration 20260904_001
-- Phase 1 / M1: Users, email verifications, password resets, audit log.
--
-- Target: MySQL 8.4+ (uses utf8mb4_0900_ai_ci, JSON, NOW()).
-- All id columns are CHAR(36) UUID v4 (matches UserService::uuid()).
-- All token_hash columns store SHA-256(plaintext) — never the plaintext.
-- All ip/user_agent values are stored HASHED (sha256) to limit PII.
-- =====================================================================

CREATE TABLE IF NOT EXISTS users (
    id                  CHAR(36)     NOT NULL,
    email               VARCHAR(255) NOT NULL,
    password_hash       VARCHAR(255) NOT NULL,           -- bcrypt $2y$...
    role                ENUM('seller','buyer','lawyer','broker') NOT NULL,
    full_name           VARCHAR(255) NULL,
    email_verified_at   DATETIME     NULL,
    created_at          DATETIME     NOT NULL,
    updated_at          DATETIME     NOT NULL,
    deleted_at          DATETIME     NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_users_email (email),
    KEY idx_users_role (role),
    KEY idx_users_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS email_verifications (
    id          CHAR(36)     NOT NULL,
    user_id     CHAR(36)     NOT NULL,
    token_hash  CHAR(64)     NOT NULL,                   -- sha256 hex
    expires_at  DATETIME     NOT NULL,
    used_at     DATETIME     NULL,
    created_at  DATETIME     NOT NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_email_verifications_token_hash (token_hash),
    KEY idx_email_verifications_user_id (user_id),
    CONSTRAINT fk_email_verifications_user_id
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS password_resets (
    id          CHAR(36)     NOT NULL,
    user_id     CHAR(36)     NOT NULL,
    token_hash  CHAR(64)     NOT NULL,                   -- sha256 hex
    expires_at  DATETIME     NOT NULL,
    used_at     DATETIME     NULL,
    created_at  DATETIME     NOT NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_password_resets_token_hash (token_hash),
    KEY idx_password_resets_user_id (user_id),
    CONSTRAINT fk_password_resets_user_id
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS audit_log (
    id              CHAR(36)     NOT NULL,
    session_id      CHAR(36)     NULL,                   -- reserved for Phase 1B sessions table
    user_id         CHAR(36)     NULL,
    action          VARCHAR(100) NOT NULL,               -- e.g. 'user.login_success'
    metadata        JSON         NULL,
    ip_hash         CHAR(64)     NULL,                   -- sha256 hex of IP
    user_agent_hash CHAR(64)     NULL,                   -- sha256 hex of UA
    created_at      DATETIME     NOT NULL,

    PRIMARY KEY (id),
    KEY idx_audit_log_user_id (user_id),
    KEY idx_audit_log_action (action),
    KEY idx_audit_log_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS migrations_applied (
    id           BIGINT AUTO_INCREMENT PRIMARY KEY,
    filename     VARCHAR(255) NOT NULL,
    applied_at   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_migrations_applied_filename (filename)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
