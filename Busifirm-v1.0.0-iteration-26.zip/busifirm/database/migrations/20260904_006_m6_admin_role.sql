-- =====================================================================
-- Busifirm — Migration 20260904_006
-- Phase 3 / M6: Admin role + admin audit panel support.
--
-- Changes:
--   1. Extend users.role ENUM to include 'admin'.
--   2. Add is_admin boolean generated column for fast admin-only queries
--      (optional; the AdminMiddleware checks role='admin' directly).
--
-- No new tables. No data migration. Purely additive ALTER.
--
-- Admin role assignment: there is NO admin-promotion endpoint. To make a
-- user an admin, run SQL directly:
--   UPDATE users SET role = 'admin' WHERE email = 'admin@busifirm.com';
-- This is intentional — admin promotion is a rare, high-trust operation
-- that should require DB access, not a button in the UI. Phase 3+ may add
-- a super-admin role that can promote others.
-- =====================================================================

ALTER TABLE users
    MODIFY COLUMN role ENUM('seller','buyer','lawyer','broker','admin')
    NOT NULL;
