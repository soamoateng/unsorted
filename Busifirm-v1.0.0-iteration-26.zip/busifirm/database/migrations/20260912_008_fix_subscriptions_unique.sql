-- =====================================================================
-- Busifirm — Migration 20260912_008
-- Fix: Drop UNIQUE constraint on subscriptions.user_id (BL blind-spot)
--
-- The UNIQUE KEY uq_subscriptions_user_id (user_id) from migration 004
-- was too strict: it enforced ONE ROW per user_id, ever — not "one active
-- subscription per user" as the comment claimed. This made every upgrade
-- flow impossible:
--
--   1. activateSubscription() proration path (line ~799): cancels the old
--      sub (UPDATE → row stays with status='cancelled'), then INSERTs a
--      new sub for the same user_id → DUPLICATE KEY error.
--   2. activateSubscription() standard path (line ~836): same pattern.
--   3. applyPendingDowngrades() (line ~546): same pattern.
--   4. startTrial() (line ~397): if the user has ANY prior subscription
--      row (even cancelled/expired), the INSERT fails.
--
-- Fix: replace UNIQUE with a regular index. The application code
-- (BillingService) enforces the "one active sub per user" invariant via
-- the cancel-then-insert pattern. Historical rows (cancelled, expired,
-- trialing) are preserved for audit — which is the correct behavior for
-- a billing system.
--
-- Safe to run on a live v0.8.0 database: only changes the index type,
-- does not touch any data.
-- =====================================================================

-- SQL-006 fix: use DROP INDEX IF EXISTS and ADD KEY IF NOT EXISTS for
-- idempotency. On re-run (e.g. after a partial failure), the DROP is a no-op
-- if the index was already dropped, and the ADD is a no-op if the key already
-- exists.
ALTER TABLE subscriptions
    DROP INDEX IF EXISTS uq_subscriptions_user_id,
    ADD KEY IF NOT EXISTS idx_subscriptions_user_id (user_id);
