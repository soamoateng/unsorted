-- =====================================================================
-- Busifirm — Migration 20260904_005
-- Phase 1 / M5: Document storage for KYC + esign.
--
-- Tables added:
--   documents — file metadata for uploaded documents (PDF, PNG, JPEG)
--
-- Columns added:
--   esigns.document_id — nullable FK to documents; an esign can optionally
--   reference the file being signed (e.g. the PDF contract).
--
-- Design notes:
--   - The actual file bytes live on the local filesystem under storage/documents/{user_id}/.
--     Phase 3 will swap to S3-compatible storage. The documents table is the
--     only thing that stays the same — the Storage class is the swap point.
--   - stored_filename is a random UUID + original extension. Users never
--     control the on-disk filename, eliminating path traversal risk.
--   - Soft delete via deleted_at. Disk garbage collection is a Phase 3
--     cron job — for now, deleted files stay on disk (safe but space-wasteful).
--   - purpose is a free-form string ('kyc', 'esign', 'listing_photo', etc.)
--     used for filtering in the UI.
-- =====================================================================

CREATE TABLE IF NOT EXISTS documents (
    id                CHAR(36)     NOT NULL,
    user_id           CHAR(36)     NOT NULL,
    original_filename VARCHAR(255) NOT NULL,                   -- display name (sanitized)
    stored_filename   VARCHAR(255) NOT NULL,                   -- UUID + extension (disk path)
    mime_type         VARCHAR(100) NOT NULL,
    size_bytes        BIGINT       NOT NULL,
    purpose           VARCHAR(50)  NOT NULL DEFAULT 'general', -- 'kyc', 'esign', 'listing_photo', etc.
    sha256            CHAR(64)     NOT NULL,                   -- content hash for dedup/audit
    created_at        DATETIME     NOT NULL,
    updated_at        DATETIME     NOT NULL,
    deleted_at        DATETIME     NULL,

    PRIMARY KEY (id),
    KEY idx_documents_user_id (user_id),
    KEY idx_documents_purpose (purpose),
    KEY idx_documents_sha256 (sha256),
    CONSTRAINT fk_documents_user_id
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Add document_id to esigns (nullable — an esign doesn't require an attached file).
-- SQL-006 fix: use IF NOT EXISTS for COLUMN and KEY (MySQL 8.0.29+).
-- For CONSTRAINT, MySQL 8.x does NOT support IF NOT EXISTS — we rely on
-- migrate.php's per-statement error handling: if the FK already exists,
-- the ADD CONSTRAINT fails non-fatally and migrate.php logs + continues.
ALTER TABLE esigns
    ADD COLUMN IF NOT EXISTS document_id CHAR(36) NULL AFTER title,
    ADD KEY IF NOT EXISTS idx_esigns_document_id (document_id),
    ADD CONSTRAINT fk_esigns_document_id
        FOREIGN KEY (document_id) REFERENCES documents(id) ON DELETE SET NULL;
