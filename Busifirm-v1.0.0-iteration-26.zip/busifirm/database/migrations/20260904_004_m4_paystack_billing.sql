-- =====================================================================
-- Busifirm — Migration 20260904_004
-- Phase 2 / M4: Paystack subscription billing.
--
-- Tables added:
--   plans           — billing plan catalog (Free / Pro / Enterprise)
--   subscriptions   — per-user active subscription state
--   invoices        — per-payment record (one per Paystack transaction)
--
-- Design notes:
--   - Plans are seeded in SQL, NOT created via Paystack API at boot. This
--     avoids needing Paystack keys to run migrations. The paystack_plan_code
--     column is NULL until an admin creates the plan in Paystack dashboard
--     and pastes the code back via the admin panel (Phase 3). For dev, the
--     BillingService uses one-time transactions when paystack_plan_code is NULL.
--   - All money amounts are stored in GHS kobo (BIGINT, 1 GHS = 100 kobo).
--     No FLOAT columns for money — integer arithmetic only.
--   - Paystack reference is UNIQUE — idempotent webhook handling.
-- =====================================================================

CREATE TABLE IF NOT EXISTS plans (
    id                  CHAR(36)     NOT NULL,
    code                VARCHAR(50)  NOT NULL,                   -- 'free', 'pro', 'enterprise'
    name                VARCHAR(100) NOT NULL,
    price_kobo          BIGINT       NOT NULL,                   -- GHS kobo per billing cycle
    currency            CHAR(3)      NOT NULL DEFAULT 'GHS',
    billing_interval    ENUM('monthly','yearly','one_time') NOT NULL DEFAULT 'monthly',
    paystack_plan_code  VARCHAR(100) NULL,                       -- set by admin after creating plan in Paystack dashboard
    features            JSON         NOT NULL,                   -- array of feature strings for UI display
    max_listings        INT          NOT NULL DEFAULT 0,         -- 0 = unlimited
    max_chat_per_day    INT          NOT NULL DEFAULT 0,         -- 0 = unlimited
    can_witness_sign    TINYINT(1)   NOT NULL DEFAULT 1,         -- M3 capability gate (lawyers always allowed)
    is_active           TINYINT(1)   NOT NULL DEFAULT 1,
    sort_order          INT          NOT NULL DEFAULT 0,
    created_at          DATETIME     NOT NULL,
    updated_at          DATETIME     NOT NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_plans_code (code),
    KEY idx_plans_sort (sort_order)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS subscriptions (
    id                          CHAR(36)     NOT NULL,
    user_id                     CHAR(36)     NOT NULL,
    plan_id                     CHAR(36)     NOT NULL,
    status                      ENUM('active','cancelled','expired','past_due','trialing') NOT NULL DEFAULT 'active',
    paystack_subscription_code  VARCHAR(100) NULL,               -- returned by Paystack on subscription creation
    paystack_email_token        VARCHAR(255) NULL,               -- Paystack subscription email token (for cancel)
    started_at                  DATETIME     NOT NULL,
    next_billing_at             DATETIME     NULL,               -- NULL for free plan or one-time
    cancelled_at                DATETIME     NULL,
    created_at                  DATETIME     NOT NULL,
    updated_at                  DATETIME     NOT NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_subscriptions_user_id (user_id),               -- one active subscription per user
    KEY idx_subscriptions_status (status),
    KEY idx_subscriptions_next_billing (next_billing_at),
    CONSTRAINT fk_subscriptions_user_id
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_subscriptions_plan_id
        FOREIGN KEY (plan_id) REFERENCES plans(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS invoices (
    id                    CHAR(36)     NOT NULL,
    user_id               CHAR(36)     NOT NULL,
    subscription_id       CHAR(36)     NULL,
    plan_id               CHAR(36)     NOT NULL,
    paystack_reference    VARCHAR(100) NOT NULL,                 -- unique, used for idempotency
    amount_kobo           BIGINT       NOT NULL,
    currency              CHAR(3)      NOT NULL DEFAULT 'GHS',
    status                ENUM('pending','success','failed','refunded') NOT NULL DEFAULT 'pending',
    channel               VARCHAR(50)  NULL,                     -- 'card', 'mobile_money', 'bank_transfer', etc.
    paid_at               DATETIME     NULL,
    metadata              JSON         NULL,                     -- full Paystack transaction payload for audit
    created_at            DATETIME     NOT NULL,
    updated_at            DATETIME     NOT NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_invoices_paystack_reference (paystack_reference),
    KEY idx_invoices_user_id (user_id),
    KEY idx_invoices_subscription_id (subscription_id),
    KEY idx_invoices_status (status),
    CONSTRAINT fk_invoices_user_id
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_invoices_subscription_id
        FOREIGN KEY (subscription_id) REFERENCES subscriptions(id) ON DELETE SET NULL,
    CONSTRAINT fk_invoices_plan_id
        FOREIGN KEY (plan_id) REFERENCES plans(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- =====================================================================
-- Seed data: 3 plans.
--
-- Prices in GHS kobo (1 GHS = 100 kobo):
--   Free:       0     (0.00 GHS / month)
--   Pro:        9900  (99.00 GHS / month)
--   Enterprise: 99000 (990.00 GHS / month)
--
-- paystack_plan_code is NULL — admin sets it after creating matching plans
-- in the Paystack dashboard. Until then, BillingService uses one-time
-- transactions (no recurring billing) for testing.
-- =====================================================================
INSERT INTO plans (id, code, name, price_kobo, currency, billing_interval, paystack_plan_code, features, max_listings, max_chat_per_day, can_witness_sign, is_active, sort_order, created_at, updated_at) VALUES
('00000000-0000-0000-0000-200000000001', 'free', 'Free', 0, 'GHS', 'monthly', NULL,
 JSON_ARRAY('Browse marketplace','1 active listing','Basic chat','View public listings'),
 1, 5, 1, 1, 1, NOW(), NOW()),

('00000000-0000-0000-0000-200000000002', 'pro', 'Pro', 9900, 'GHS', 'monthly', NULL,
 JSON_ARRAY('Everything in Free','Unlimited listings','Unlimited chat','E-sign documents','Priority support','Advanced analytics'),
 0, 0, 1, 1, 2, NOW(), NOW()),

('00000000-0000-0000-0000-200000000003', 'enterprise', 'Enterprise', 99000, 'GHS', 'monthly', NULL,
 JSON_ARRAY('Everything in Pro','Dedicated account manager','Custom integrations','Bulk document signing','Legal witness network','API access','SLA guarantee'),
 0, 0, 1, 1, 3, NOW(), NOW()) AS new
ON DUPLICATE KEY UPDATE name = new.name, price_kobo = new.price_kobo, billing_interval = new.billing_interval, features = new.features, max_listings = new.max_listings, max_chat_per_day = new.max_chat_per_day, can_witness_sign = new.can_witness_sign, is_active = new.is_active, sort_order = new.sort_order;  -- SQL-031 fix: was only name=new.name (stale seed data on re-run)
