-- =====================================================================
-- Busifirm — Migration 20260911_007
-- Phase 3 polish: M4 (proration + trial + plan enforcement counters),
-- M5 (chunked uploads tracking + scan_status), M6 (user delete + role_version).
--
-- All changes are purely ADDITIVE — no data migration, no destructive ALTER.
-- This migration is safe to run on a live v0.7.0 database.
--
-- Changes by module:
--
-- M4 polish:
--   1. subscriptions: add trial_ends_at (DATETIME NULL) — for 14-day trials.
--   2. subscriptions: add pending_plan_id (CHAR(36) NULL) — for scheduled
--      downgrades (downgrade takes effect at next_billing_at, not immediately).
--   3. subscriptions: add proration_credit_kobo (BIGINT NOT NULL DEFAULT 0) —
--      credit carried over when a user upgrades mid-cycle and has unused days
--      on their previous plan. Deducted from the next invoice.
--   4. invoices: add prorated_from_plan_id (CHAR(36) NULL) — audit trail for
--      which plan the proration was computed from.
--   5. invoices: add is_proration (TINYINT(1) NOT NULL DEFAULT 0) — quick
--      filter for proration-only invoices in the admin panel.
--
-- M5 polish:
--   6. documents: add scan_status (ENUM('pending','clean','infected','skipped','failed')
--      NOT NULL DEFAULT 'pending') — ClamAV scan result.
--   7. documents: add scan_message (VARCHAR(255) NULL) — ClamAV response or
--      error message if the scan failed.
--   8. documents: add detected_mime (VARCHAR(100) NULL) — finfo_file() result,
--      kept separate from the user-supplied mime_type for audit.
--   9. NEW TABLE document_uploads — tracks chunked upload sessions (resumable).
--      One row per upload-init call; chunks themselves live on disk under
--      storage/chunks/{upload_id}/.
--
-- M6 polish:
--  10. users: add role_version (INT NOT NULL DEFAULT 1) — incremented every
--      time an admin changes a user's role. The session caches the version
--      at login; AuthMiddleware compares the cached version to the DB version
--      on every authenticated request. Mismatch → session regenerated.
--      This is the KISS pattern for session invalidation without a sessions
--      table.
--  11. users: add deleted_by (CHAR(36) NULL) — admin user_id who triggered
--      the GDPR delete (audit trail). The users.deleted_at column from M1
--      already exists; we now USE it for soft-delete-then-purge.
--  12. users: add deletion_scheduled_for (DATETIME NULL) — when the row will
--      be hard-deleted by the GC cron (deleted_at + 30 days).
--  13. audit_log: add retained_until (DATETIME NULL) — for GDPR compliance,
--      some audit entries must be retained for a fixed period (e.g. 7 years
--      for financial records under Ghana Companies Act 2019). NULL means
--      retain indefinitely. Non-NULL means the GC cron may hard-delete after
--      this date.
-- =====================================================================

-- ---------- M4 polish: subscriptions additions ----------
-- SQL-006 fix: use IF NOT EXISTS for COLUMN and KEY (MySQL 8.0.29+).
-- For CONSTRAINT, MySQL 8.x does NOT support IF NOT EXISTS — rely on
-- migrate.php's per-statement error handling.
ALTER TABLE subscriptions
    ADD COLUMN IF NOT EXISTS trial_ends_at        DATETIME     NULL AFTER next_billing_at,
    ADD COLUMN IF NOT EXISTS pending_plan_id      CHAR(36)     NULL AFTER trial_ends_at,
    ADD COLUMN IF NOT EXISTS proration_credit_kobo BIGINT      NOT NULL DEFAULT 0 AFTER pending_plan_id,
    ADD KEY IF NOT EXISTS idx_subscriptions_trial_ends (trial_ends_at),
    ADD KEY IF NOT EXISTS idx_subscriptions_pending_plan (pending_plan_id),
    ADD CONSTRAINT fk_subscriptions_pending_plan_id
        FOREIGN KEY (pending_plan_id) REFERENCES plans(id);

-- ---------- M4 polish: invoices additions ----------
ALTER TABLE invoices
    ADD COLUMN IF NOT EXISTS prorated_from_plan_id CHAR(36)    NULL AFTER plan_id,
    ADD COLUMN IF NOT EXISTS is_proration          TINYINT(1)  NOT NULL DEFAULT 0 AFTER prorated_from_plan_id,
    ADD KEY IF NOT EXISTS idx_invoices_is_proration (is_proration),
    ADD CONSTRAINT fk_invoices_prorated_from_plan_id
        FOREIGN KEY (prorated_from_plan_id) REFERENCES plans(id);

-- ---------- M5 polish: documents additions ----------
ALTER TABLE documents
    ADD COLUMN IF NOT EXISTS scan_status   ENUM('pending','clean','infected','skipped','failed')
                                 NOT NULL DEFAULT 'pending' AFTER sha256,
    ADD COLUMN IF NOT EXISTS scan_message  VARCHAR(255) NULL AFTER scan_status,
    ADD COLUMN IF NOT EXISTS detected_mime VARCHAR(100) NULL AFTER scan_message,
    ADD KEY IF NOT EXISTS idx_documents_scan_status (scan_status);

-- ---------- M5 polish: chunked upload sessions ----------
CREATE TABLE IF NOT EXISTS document_uploads (
    id              CHAR(36)     NOT NULL,                  -- upload session id (returned to client)
    user_id         CHAR(36)     NOT NULL,
    original_filename VARCHAR(255) NOT NULL,
    intended_mime   VARCHAR(100) NOT NULL,                  -- what the client claims (validated later via finfo)
    intended_size   BIGINT       NOT NULL,                  -- total expected size in bytes
    purpose         VARCHAR(50)  NOT NULL DEFAULT 'general',
    chunk_size      INT          NOT NULL,                  -- bytes per chunk
    total_chunks    INT          NOT NULL,
    received_chunks INT          NOT NULL DEFAULT 0,
    status          ENUM('uploading','completed','abandoned','failed')
                                 NOT NULL DEFAULT 'uploading',
    created_at      DATETIME     NOT NULL,
    updated_at      DATETIME     NOT NULL,
    completed_at    DATETIME     NULL,                      -- when the final chunk landed

    PRIMARY KEY (id),
    KEY idx_document_uploads_user_id (user_id),
    KEY idx_document_uploads_status (status),
    KEY idx_document_uploads_created_at (created_at),
    CONSTRAINT fk_document_uploads_user_id
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ---------- M6 polish: users additions ----------
-- SQL-006 fix: use IF NOT EXISTS clauses for idempotency.
ALTER TABLE users
    ADD COLUMN IF NOT EXISTS role_version          INT      NOT NULL DEFAULT 1 AFTER role,
    ADD COLUMN IF NOT EXISTS deleted_by            CHAR(36) NULL AFTER deleted_at,
    ADD COLUMN IF NOT EXISTS deletion_scheduled_for DATETIME NULL AFTER deleted_by,
    ADD KEY IF NOT EXISTS idx_users_role_version (role_version),
    ADD KEY IF NOT EXISTS idx_users_deletion_scheduled (deletion_scheduled_for);

-- ---------- M6 polish: audit_log retention ----------
ALTER TABLE audit_log
    ADD COLUMN IF NOT EXISTS retained_until DATETIME NULL AFTER created_at,
    ADD KEY IF NOT EXISTS idx_audit_log_retained_until (retained_until);
