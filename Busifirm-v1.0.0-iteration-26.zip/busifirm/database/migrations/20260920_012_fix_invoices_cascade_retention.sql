-- =====================================================================
-- Busifirm — Migration 20260920_012
-- SQL-002 fix: Stop CASCADE-deleting invoices when a user is hard-deleted.
--
-- Problem (from audit SQL-002):
--   The fk_invoices_user_id foreign key in migration 004 used
--   ON DELETE CASCADE. When bin/purge-deleted-users.php hard-deletes a
--   user row (after the 30-day grace window), every invoice for that
--   user is destroyed — including successful payment records.
--
--   Ghana Companies Act 2019 §288 requires 7-year retention of
--   financial records. CASCADE-deleting invoices violates this.
--   AdminService::deleteUser already anonymizes audit_log with a
--   retained_until timestamp, but invoices were left exposed.
--
-- Fix (3 parts):
--   1. Drop the CASCADE FK and replace it with ON DELETE SET NULL.
--      When the user row is hard-deleted, invoices.user_id becomes NULL
--      (orphaned but preserved). The invoice rows themselves stay.
--   2. Add a retained_until DATETIME column to invoices (nullable).
--      Paid/success invoices get +7 years; others get +1 year.
--      A future GC cron purges invoices WHERE retained_until < NOW().
--   3. Backfill retained_until for existing invoice rows based on
--      their status and created_at.
--
-- Companion code changes (in this same iteration):
--   - app/Services/AdminService.php::deleteUser — also anonymize invoices
--     (set user_id=NULL, set retained_until based on status) so the
--     financial records survive the GC hard-delete.
--   - bin/purge-deleted-users.php — also purge expired invoices.
--
-- Safe to run on a live v0.9.x database:
--   - ALTER TABLE on InnoDB with the FK change is online in MySQL 8.0+
--     (LOCK=NONE for SET NULL change).
--   - The ADD COLUMN is instant for InnoDB 8.0+.
--   - The UPDATE backfill touches all rows but is idempotent.
-- =====================================================================

-- Step 1: Drop the CASCADE FK and replace with SET NULL.
-- MySQL 8.0+ does not support INLINE alter of FK ON DELETE behavior;
-- we must DROP + ADD. The constraint name comes from migration 004.
--
-- SQL-006 fix: MySQL 8.x does NOT support `DROP FOREIGN KEY IF EXISTS` (that's
-- a MariaDB extension), and `DELIMITER`-based stored procedures don't work
-- with PDO::exec() (the SQL splitter splits on the `;` inside the procedure
-- body). Instead, we rely on migrate.php's per-statement error handling: if
-- the FK doesn't exist (e.g. this migration is re-run after a partial failure),
-- the DROP FOREIGN KEY statement fails with a non-fatal error that migrate.php
-- logs and continues past. The ADD CONSTRAINT then runs — if the constraint
-- already exists, that also fails non-fatally. The net effect is idempotent:
-- re-running this migration is safe.
ALTER TABLE invoices
    DROP FOREIGN KEY fk_invoices_user_id;

ALTER TABLE invoices
    ADD CONSTRAINT fk_invoices_user_id
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL;

-- Step 2: Add retained_until column + index.
-- Matches the pattern from migration 007 (audit_log.retained_until).
-- SQL-006 fix: use IF NOT EXISTS for idempotency (MySQL 8.0.29+).
ALTER TABLE invoices
    ADD COLUMN IF NOT EXISTS retained_until DATETIME NULL AFTER updated_at,
    ADD KEY IF NOT EXISTS idx_invoices_retained_until (retained_until);

-- Step 3: Backfill retained_until for existing rows.
--   - status='success' or 'refunded' (paid): +7 years from created_at
--     (financial records retention per Ghana Companies Act 2019 §288).
--   - status='pending' or 'failed' (never paid): +1 year from created_at
--     (forensic visibility for fraud investigation, then purge).
--   - Rows already past their retention window at migration time get
--     retained_until = NOW() so the next GC run purges them.
UPDATE invoices
SET retained_until = CASE
    WHEN status IN ('success', 'refunded') THEN
        CASE
            WHEN DATE_ADD(created_at, INTERVAL 7 YEAR) > NOW()
                THEN DATE_ADD(created_at, INTERVAL 7 YEAR)
            ELSE NOW()
        END
    ELSE
        CASE
            WHEN DATE_ADD(created_at, INTERVAL 1 YEAR) > NOW()
                THEN DATE_ADD(created_at, INTERVAL 1 YEAR)
            ELSE NOW()
        END
END
WHERE retained_until IS NULL;
