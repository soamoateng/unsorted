-- =====================================================================
-- Busifirm — Migration 20260904_003
-- Phase 1 / M3: RBAC witness-signature support on esigns.
--
-- Adds witness_id, witness_signed_at, witness_email to the esigns table so
-- a lawyer can co-sign a document as a witness. The witness signature is
-- independent of the owner signature (signed_at) — both can happen in any
-- order, but each can happen at most once.
--
-- No new tables. No data migration. Purely additive.
-- =====================================================================

-- SQL-006 fix: use ADD COLUMN IF NOT EXISTS and ADD KEY IF NOT EXISTS so the
-- migration is idempotent — re-running (e.g. after a partial failure) won't
-- fail with "Duplicate column name". MySQL 8.0.29+ supports these clauses.
ALTER TABLE esigns
    ADD COLUMN IF NOT EXISTS witness_id         CHAR(36)     NULL AFTER signed_at,
    ADD COLUMN IF NOT EXISTS witness_signed_at  DATETIME     NULL AFTER witness_id,
    ADD COLUMN IF NOT EXISTS witness_email      VARCHAR(255) NULL AFTER witness_signed_at,
    ADD KEY IF NOT EXISTS idx_esigns_witness_id (witness_id);
