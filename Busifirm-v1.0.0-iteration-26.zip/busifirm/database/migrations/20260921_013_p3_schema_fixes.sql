-- =====================================================================
-- Busifirm — Migration 20260921_013
-- P3 cleanup fixes: SQL-027, SQL-030, SQL-035
--
-- SQL-027: Change deals.partner from NOT NULL to NULL (early-stage deals
--          may not have a counterparty identified yet).
-- SQL-030: Add UNIQUE KEY on esigns (user_id, title) to prevent duplicate
--          esign titles per user (same class of bug as BL-18 for listings).
-- SQL-035: No schema change — the SET sql_mode/time_zone fix is in
--          migrate.php, not in a migration file.
-- =====================================================================

-- SQL-027 fix: allow NULL partner for early-stage deals.
ALTER TABLE deals
    MODIFY COLUMN partner VARCHAR(255) NULL;

-- SQL-030 fix: prevent duplicate esign titles per user.
-- Uses a UNIQUE KEY on (user_id, title) — same pattern as the listings
-- company_name unique check from BL-18/migration 009.
-- Note: if duplicate titles already exist, this ALTER will fail. The
-- migrate.php per-statement error handling (SQL-006 fix) will log the
-- error and continue — the operator must manually resolve duplicates
-- before re-running with --force.
ALTER TABLE esigns
    ADD UNIQUE KEY uq_esigns_user_title (user_id, title);
