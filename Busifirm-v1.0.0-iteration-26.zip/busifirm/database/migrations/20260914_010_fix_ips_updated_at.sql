-- =====================================================================
-- Busifirm — Migration 20260914_010
-- OTH-08 fix: Add updated_at column to the ips table for consistency.
--
-- The ips table (migration 002) was the only domain table without an
-- updated_at column. All other tables (listings, deals, esigns) have it.
-- This migration adds the column for schema consistency.
--
-- Safe to run on a live v0.8.x database (additive — only adds a column).
-- =====================================================================

-- SQL-006 fix: use ADD COLUMN IF NOT EXISTS for idempotency.
ALTER TABLE ips
    ADD COLUMN IF NOT EXISTS updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP AFTER created_at;
