-- =====================================================================
-- Busifirm — Migration 20260904_002
-- Phase 1 / M2: Migrate remaining localStorage stores to MySQL.
--
-- Tables added:
--   listings          — normalized (real columns)
--   ips               — normalized (public IP marketplace catalog)
--   deals             — normalized
--   chat_conversations — real columns + messages JSON (KISS: normalize
--                        only when WebSocket real-time chat lands in S3)
--   esigns            — real columns + audit_trail JSON
--   integrations      — one row per user, tasks JSON (single document)
--   kyc_documents     — one row per user, documents JSON (real uploads in M5)
--
-- All id columns are CHAR(36) UUID v4 (matches server-side uuid()).
-- All JSON columns use MySQL 8.4 native JSON type with CHECK-free design
-- (validation lives in PHP services).
-- =====================================================================

CREATE TABLE IF NOT EXISTS listings (
    id              CHAR(36)     NOT NULL,
    user_id         CHAR(36)     NULL,                   -- NULL = system seed listing
    company_name    VARCHAR(255) NOT NULL,
    sector          VARCHAR(100) NOT NULL,
    revenue         BIGINT       NOT NULL DEFAULT 0,     -- GHS, integer kobo-like (no floats for money)
    valuation       BIGINT       NOT NULL DEFAULT 0,
    description     TEXT         NULL,
    status          ENUM('draft','active','closed') NOT NULL DEFAULT 'active',
    created_at      DATETIME     NOT NULL,
    updated_at      DATETIME     NOT NULL,

    PRIMARY KEY (id),
    KEY idx_listings_user_id (user_id),
    KEY idx_listings_sector (sector),
    KEY idx_listings_status (status),
    KEY idx_listings_created_at (created_at),
    CONSTRAINT fk_listings_user_id
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS ips (
    id              CHAR(36)     NOT NULL,
    name            VARCHAR(255) NOT NULL,
    type            VARCHAR(50)  NOT NULL,               -- Patent, Software, Trademark, etc.
    price           BIGINT       NOT NULL DEFAULT 0,     -- GHS
    sector          VARCHAR(100) NOT NULL,
    owner           VARCHAR(255) NOT NULL,
    description     TEXT         NULL,
    status          ENUM('available','sold','withdrawn') NOT NULL DEFAULT 'available',
    created_at      DATETIME     NOT NULL,

    PRIMARY KEY (id),
    KEY idx_ips_sector (sector),
    KEY idx_ips_type (type),
    KEY idx_ips_status (status),
    FULLTEXT KEY ft_ips_search (name, owner, description)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS deals (
    id              CHAR(36)     NOT NULL,
    user_id         CHAR(36)     NOT NULL,
    name            VARCHAR(255) NOT NULL,
    type            VARCHAR(50)  NOT NULL,               -- 'IP Sale', 'M&A', 'License', etc.
    value           BIGINT       NOT NULL DEFAULT 0,     -- GHS
    status          ENUM('active','closed','cancelled') NOT NULL DEFAULT 'active',
    stage           VARCHAR(50)  NOT NULL,               -- 'negotiation','due-diligence','completed', etc.
    partner         VARCHAR(255) NOT NULL,
    created_at      DATETIME     NOT NULL,
    updated_at      DATETIME     NOT NULL,

    PRIMARY KEY (id),
    KEY idx_deals_user_id (user_id),
    KEY idx_deals_status (status),
    CONSTRAINT fk_deals_user_id
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS chat_conversations (
    id              CHAR(36)     NOT NULL,
    user_id         CHAR(36)     NOT NULL,               -- owner of this conversation list
    name            VARCHAR(255) NOT NULL,               -- counterparty display name
    avatar          VARCHAR(100) NULL,                   -- font-awesome icon class
    color           VARCHAR(50)  NULL,                   -- bootstrap color token
    last_message    TEXT         NULL,
    last_updated    DATETIME     NOT NULL,
    unread_count    INT          NOT NULL DEFAULT 0,
    messages        JSON         NOT NULL,               -- array of {id, sender, text, timestamp, read}
    created_at      DATETIME     NOT NULL,

    PRIMARY KEY (id),
    KEY idx_chat_user_id (user_id),
    KEY idx_chat_last_updated (last_updated),
    CONSTRAINT fk_chat_user_id
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS esigns (
    id              CHAR(36)     NOT NULL,
    user_id         CHAR(36)     NOT NULL,
    title           VARCHAR(255) NOT NULL,
    status          ENUM('pending','signed','rejected','expired') NOT NULL DEFAULT 'pending',
    parties         JSON         NOT NULL,               -- array of strings
    audit_trail     JSON         NOT NULL,               -- array of {action, timestamp, by}
    signed_at       DATETIME     NULL,
    created_at      DATETIME     NOT NULL,
    updated_at      DATETIME     NOT NULL,

    PRIMARY KEY (id),
    KEY idx_esigns_user_id (user_id),
    KEY idx_esigns_status (status),
    CONSTRAINT fk_esigns_user_id
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS integrations (
    user_id         CHAR(36)     NOT NULL,
    tasks           JSON         NOT NULL,               -- array of {id, name, progress, status, category}
    last_updated    DATETIME     NOT NULL,
    created_at      DATETIME     NOT NULL,

    PRIMARY KEY (user_id),
    CONSTRAINT fk_integrations_user_id
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS kyc_documents (
    user_id         CHAR(36)     NOT NULL,
    status          ENUM('unverified','pending','verified','rejected') NOT NULL DEFAULT 'unverified',
    documents       JSON         NOT NULL,               -- array of strings (filenames/refs; real uploads in M5)
    last_updated    DATETIME     NOT NULL,
    created_at      DATETIME     NOT NULL,

    PRIMARY KEY (user_id),
    CONSTRAINT fk_kyc_user_id
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- =====================================================================
-- Seed data for the public IP marketplace catalog.
-- These are global, system-owned IPs visible to all users.
-- =====================================================================
INSERT INTO ips (id, name, type, price, sector, owner, description, status, created_at) VALUES
('00000000-0000-0000-0000-000000000001', 'AI Fraud Detection Engine', 'Patent', 150000, 'Fintech', 'SecurePay GH', 'ML fraud detection with 99.2% accuracy.', 'available', NOW()),
('00000000-0000-0000-0000-000000000002', 'Crop AI Predictor', 'Software', 80000, 'Agritech', 'FarmIntel', 'Predicts crop yields using satellite imagery.', 'available', NOW()),
('00000000-0000-0000-0000-000000000003', 'TeleMed Platform', 'Trademark', 250000, 'Healthtech', 'HealthBridge', 'End-to-end telemedicine with pharmacy integration.', 'available', NOW()),
('00000000-0000-0000-0000-000000000004', 'Solar Grid Optimizer', 'Patent', 180000, 'Cleantech', 'GreenPower GH', 'AI-driven optimization for solar grid distribution.', 'available', NOW()),
('00000000-0000-0000-0000-000000000005', 'EduTech LMS', 'Software', 120000, 'Edtech', 'LearnGhana', 'Learning management system with offline sync.', 'available', NOW()) AS new
ON DUPLICATE KEY UPDATE name = new.name, type = new.type, price = new.price, sector = new.sector, owner = new.owner, description = new.description, status = new.status;  -- SQL-031 fix: was only name=new.name (stale seed data on re-run)

-- Seed sample listings (system-owned, user_id NULL)
INSERT INTO listings (id, user_id, company_name, sector, revenue, valuation, description, status, created_at, updated_at) VALUES
('00000000-0000-0000-0000-100000000001', NULL, 'AgriTech Solutions GH', 'Agritech', 250000, 1200000, 'AI-powered crop prediction platform serving 500+ farmers.', 'active', NOW() - INTERVAL 7 DAY, NOW() - INTERVAL 7 DAY),
('00000000-0000-0000-0000-100000000002', NULL, 'PaySwift Ghana', 'Fintech', 800000, 5000000, 'Mobile payment gateway processing GHS 2M monthly.', 'active', NOW() - INTERVAL 3 DAY, NOW() - INTERVAL 3 DAY) AS new
ON DUPLICATE KEY UPDATE company_name = new.company_name, sector = new.sector, revenue = new.revenue, valuation = new.valuation, description = new.description, status = new.status;  -- SQL-031 fix: was only company_name=new.company_name
