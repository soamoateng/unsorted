-- =====================================================================
-- Busifirm — Migration 20260914_011
-- OTH-10 fix: Add column comments to clarify money columns are in GHS kobo.
--
-- The listings.revenue and listings.valuation columns store integer values
-- in GHS kobo (1 GHS = 100 kobo), but the column names don't indicate this.
-- This migration adds COLUMN COMMENTS to clarify the unit.
--
-- Also adds comments to deals.value for the same reason.
--
-- SQL-003 fix: the original version of this migration used
-- `MODIFY COLUMN revenue BIGINT NOT NULL COMMENT '...'` which DROPPED the
-- `DEFAULT 0` that was present in migration 002's CREATE TABLE. Under
-- STRICT_TRANS_TABLES (the documented SQL mode), any INSERT that omits the
-- revenue/valuation/value column would fail with "Field doesn't have a
-- default value". The fix restores `DEFAULT 0` on all three columns.
--
-- Safe to run on a live v0.8.x database (metadata-only change — no data
-- modification).
-- =====================================================================

ALTER TABLE listings
    MODIFY COLUMN revenue BIGINT NOT NULL DEFAULT 0 COMMENT 'Annual revenue in GHS kobo (1 GHS = 100 kobo)',
    MODIFY COLUMN valuation BIGINT NOT NULL DEFAULT 0 COMMENT 'Valuation in GHS kobo (1 GHS = 100 kobo)';

ALTER TABLE deals
    MODIFY COLUMN value BIGINT NOT NULL DEFAULT 0 COMMENT 'Deal value in GHS kobo (1 GHS = 100 kobo)';
