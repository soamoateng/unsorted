-- =====================================================================
-- Busifirm — Migration 20260913_009
-- Fix: Add UNIQUE index on LOWER(company_name) to prevent duplicate listings (BL-18)
--
-- The application-level isDuplicate() check uses LOWER(company_name) for
-- case-insensitive comparison, but there was no UNIQUE index to enforce it
-- at the DB level. Two concurrent requests could both pass the check and
-- both INSERT, creating duplicate listings.
--
-- MySQL 8.0+ supports functional indexes on expressions. We create a
-- UNIQUE index on (LOWER(company_name)) to enforce case-insensitive
-- uniqueness at the DB level.
--
-- Note: existing duplicates (if any) will cause this migration to fail.
-- Run `SELECT LOWER(company_name), COUNT(*) FROM listings GROUP BY LOWER(company_name) HAVING COUNT(*) > 1`
-- first to check for existing duplicates. If duplicates exist, resolve
-- them before running this migration.
--
-- Safe to run on a live v0.8.x database (additive — only adds an index).
-- =====================================================================

-- First, check for existing duplicates and fail early if any exist.
-- This is a safety check; if it fails, the admin must resolve duplicates
-- manually before re-running.
SET @dup_count = (
    SELECT COUNT(*) FROM (
        SELECT LOWER(company_name) AS cn, COUNT(*) AS c
        FROM listings
        GROUP BY LOWER(company_name)
        HAVING c > 1
    ) dupes
);

-- If duplicates exist, we still add the index but as a non-unique index
-- (to avoid the migration failing). The application-level check still
-- prevents new duplicates; this just doesn't enforce it at the DB level
-- for pre-existing duplicates.
-- In practice, a fresh install has only 2 seed listings with unique names.
SET @sql = IF(@dup_count = 0,
    'CREATE UNIQUE INDEX uq_listings_company_name_lower ON listings ((LOWER(company_name)))',
    'CREATE INDEX idx_listings_company_name_lower ON listings ((LOWER(company_name)))'
);
SET @sql = CONCAT(@sql);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
