<?php
declare(strict_types=1);

namespace Busifirm\Tests\Unit;

use Busifirm\Core\Config;
use Busifirm\Core\Database;
use Busifirm\Core\Mailer;
use Busifirm\Services\UserService;
use PHPUnit\Framework\TestCase;
use RuntimeException;

/**
 * UserService smoke test.
 *
 * Requires a live MySQL test database (see phpunit.xml: DB_NAME=busifirm_test).
 * The test truncates the relevant tables before each method to keep tests
 * isolated. This is intentionally NOT a full integration test suite — it
 * covers the happy-path + critical failure modes for M1.
 */
final class UserServiceTest extends TestCase
{
    private UserService $service;
    private \PDO $pdo;
    private ArrayMailer $mailer;

    protected function setUp(): void
    {
        // Load .env from project root if running standalone; phpunit.xml
        // already injects DB_* via env vars.
        $root = dirname(__DIR__, 2);
        if (is_file($root . '/.env')) {
            Config::load($root . '/.env');
        } else {
            // Fall back to env vars (phpunit.xml sets these).
            Config::setForTest([
                'DB_HOST' => getenv('DB_HOST') ?: '127.0.0.1',
                'DB_PORT' => '3306',
                'DB_NAME' => getenv('DB_NAME') ?: 'busifirm_test',
                'DB_USER' => getenv('DB_USER') ?: 'busifirm_test',
                'DB_PASSWORD' => getenv('DB_PASSWORD') ?: '',
                'DB_CHARSET' => 'utf8mb4',
                'PASSWORD_BCRYPT_COST' => '4',  // speed up tests
                'EMAIL_VERIFY_TTL_SECONDS' => '86400',
                'PASSWORD_RESET_TTL_SECONDS' => '3600',
                'APP_URL' => 'http://localhost:8000',
                'MAIL_FROM' => 'no-reply@busifirm.com',
                'MAIL_FROM_NAME' => 'Busifirm',
            ]);
        }

        try {
            $this->pdo = Database::connect();
        } catch (\Throwable $e) {
            $this->markTestSkipped('MySQL test DB not available: ' . $e->getMessage());
        }

        $this->pdo->exec('DELETE FROM email_verifications');
        $this->pdo->exec('DELETE FROM password_resets');
        $this->pdo->exec('DELETE FROM audit_log');
        $this->pdo->exec('DELETE FROM users');

        $this->mailer = new ArrayMailer();
        $this->service = new UserService($this->mailer);
    }

    public function testRegisterCreatesUserAndHashesPassword(): void
    {
        $result = $this->service->register(
            'alice@busifirm.com',
            'password123',
            'seller',
            '127.0.0.1',
            'PHPUnit'
        );

        $this->assertSame('alice@busifirm.com', $result['user']['email']);
        $this->assertSame('seller', $result['user']['role']);
        $this->assertFalse($result['user']['emailVerified']);
        $this->assertNotEmpty($result['verify_token']);

        // Password must be bcrypt-hashed in DB, not stored as plaintext.
        $row = $this->pdo->query("SELECT password_hash FROM users WHERE email = 'alice@busifirm.com'")->fetch();
        $this->assertNotEmpty($row);
        $this->assertStringStartsWith('$2y$', $row['password_hash']);
        $this->assertTrue(password_verify('password123', $row['password_hash']));
        $this->assertFalse(password_verify('wrong-password', $row['password_hash']));

        // Verification email was sent.
        $this->assertCount(1, $this->mailer->sent);
        $this->assertSame('alice@busifirm.com', $this->mailer->sent[0]['to']);
    }

    public function testRegisterRejectsDuplicateEmail(): void
    {
        $this->service->register('bob@busifirm.com', 'password123', 'buyer', '127.0.0.1', 'PHPUnit');
        $this->expectException(RuntimeException::class);
        $this->expectExceptionMessage('already exists');
        $this->service->register('BOB@busifirm.com', 'password456', 'buyer', '127.0.0.1', 'PHPUnit');
    }

    public function testRegisterRejectsWeakPassword(): void
    {
        $this->expectException(RuntimeException::class);
        // No digit
        $this->service->register('carol@busifirm.com', 'password', 'buyer', '127.0.0.1', 'PHPUnit');
    }

    public function testVerifyEmailConsumesToken(): void
    {
        $result = $this->service->register('dave@busifirm.com', 'password123', 'lawyer', '127.0.0.1', 'PHPUnit');
        $token = $result['verify_token'];

        $ok = $this->service->verifyEmail($token, '127.0.0.1', 'PHPUnit');
        $this->assertTrue($ok);

        // User is now verified.
        $row = $this->pdo->query("SELECT email_verified_at FROM users WHERE email = 'dave@busifirm.com'")->fetch();
        $this->assertNotNull($row['email_verified_at']);

        // Token cannot be reused.
        $again = $this->service->verifyEmail($token, '127.0.0.1', 'PHPUnit');
        $this->assertFalse($again);
    }

    public function testLoginFailsForUnverifiedEmail(): void
    {
        $this->service->register('eve@busifirm.com', 'password123', 'broker', '127.0.0.1', 'PHPUnit');
        $this->expectException(RuntimeException::class);
        $this->expectExceptionMessage('verify your email');
        $this->service->login('eve@busifirm.com', 'password123', '127.0.0.1', 'PHPUnit');
    }

    public function testLoginSucceedsAfterVerification(): void
    {
        $r = $this->service->register('frank@busifirm.com', 'password123', 'seller', '127.0.0.1', 'PHPUnit');
        $this->service->verifyEmail($r['verify_token'], '127.0.0.1', 'PHPUnit');

        $result = $this->service->login('frank@busifirm.com', 'password123', '127.0.0.1', 'PHPUnit');
        $this->assertSame('frank@busifirm.com', $result['user']['email']);
        $this->assertTrue($result['user']['emailVerified']);
    }

    public function testLoginFailsWithWrongPassword(): void
    {
        $r = $this->service->register('grace@busifirm.com', 'password123', 'seller', '127.0.0.1', 'PHPUnit');
        $this->service->verifyEmail($r['verify_token'], '127.0.0.1', 'PHPUnit');

        $this->expectException(RuntimeException::class);
        $this->expectExceptionMessage('Incorrect email or password');
        $this->service->login('grace@busifirm.com', 'wrong-password', '127.0.0.1', 'PHPUnit');
    }

    public function testPasswordResetFlow(): void
    {
        $r = $this->service->register('heidi@busifirm.com', 'password123', 'buyer', '127.0.0.1', 'PHPUnit');
        $this->service->verifyEmail($r['verify_token'], '127.0.0.1', 'PHPUnit');

        // Step 1: request reset. Always-success (no leak).
        $reset = $this->service->requestPasswordReset('heidi@busifirm.com', '127.0.0.1', 'PHPUnit');
        $this->assertNotEmpty($reset['token']);

        // Old password stops working after reset (we change the hash).
        $this->service->resetPassword($reset['token'], 'newpassword456', '127.0.0.1', 'PHPUnit');

        // Old password fails.
        try {
            $this->service->login('heidi@busifirm.com', 'password123', '127.0.0.1', 'PHPUnit');
            $this->fail('Expected login with old password to fail.');
        } catch (RuntimeException $e) {
            $this->assertStringContainsString('Incorrect', $e->getMessage());
        }

        // New password works.
        $result = $this->service->login('heidi@busifirm.com', 'newpassword456', '127.0.0.1', 'PHPUnit');
        $this->assertSame('heidi@busifirm.com', $result['user']['email']);

        // Token cannot be reused.
        try {
            $this->service->resetPassword($reset['token'], 'yetanother789', '127.0.0.1', 'PHPUnit');
            $this->fail('Expected reset token reuse to fail.');
        } catch (RuntimeException $e) {
            $this->assertStringContainsString('already been used', $e->getMessage());
        }
    }

    public function testRequestPasswordResetDoesNotLeakEmailExistence(): void
    {
        // Real email — returns token.
        $r = $this->service->register('ivan@busifirm.com', 'password123', 'buyer', '127.0.0.1', 'PHPUnit');
        $realResult = $this->service->requestPasswordReset('ivan@busifirm.com', '127.0.0.1', 'PHPUnit');
        $this->assertNotNull($realResult['token']);

        // Non-existent email — returns null token but does NOT throw.
        $fakeResult = $this->service->requestPasswordReset('does-not-exist@busifirm.com', '127.0.0.1', 'PHPUnit');
        $this->assertNull($fakeResult['token']);
    }
}

/**
 * Test double for Mailer — captures sent emails in memory instead of using mail().
 */
final class ArrayMailer implements Mailer
{
    /** @var array<int, array{to: string, subject: string, body: string}> */
    public array $sent = [];

    public function send(string $to, string $subject, string $body, array $headers = []): bool
    {
        $this->sent[] = ['to' => $to, 'subject' => $subject, 'body' => $body, 'headers' => $headers];
        return true;
    }
}
