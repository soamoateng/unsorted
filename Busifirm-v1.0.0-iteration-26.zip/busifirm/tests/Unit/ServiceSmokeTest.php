<?php
declare(strict_types=1);

namespace Busifirm\Tests\Unit;

use PHPUnit\Framework\TestCase;

/**
 * OTH-21 fix: Added basic smoke tests for services that had zero coverage.
 * This is not comprehensive — it's a starting point. Each test verifies the
 * service can be instantiated and its public methods exist.
 *
 * Full integration tests require a test database (run `composer test-setup`).
 */
class ServiceSmokeTest extends TestCase
{
    /**
     * Verify that key service classes exist and can be referenced.
     * This catches autoloading issues and missing files.
     */
    public function testServiceClassesExist(): void
    {
        $this->assertTrue(class_exists(\Busifirm\Services\BillingService::class));
        $this->assertTrue(class_exists(\Busifirm\Services\ListingService::class));
        $this->assertTrue(class_exists(\Busifirm\Services\ChatService::class));
        $this->assertTrue(class_exists(\Busifirm\Services\DocumentService::class));
        $this->assertTrue(class_exists(\Busifirm\Services\AdminService::class));
        $this->assertTrue(class_exists(\Busifirm\Services\KycService::class));
        $this->assertTrue(class_exists(\Busifirm\Services\ESignService::class));
        $this->assertTrue(class_exists(\Busifirm\Services\PlanEnforcementService::class));
        $this->assertTrue(class_exists(\Busifirm\Services\AuditService::class));
        $this->assertTrue(class_exists(\Busifirm\Services\DealService::class));
        $this->assertTrue(class_exists(\Busifirm\Services\IPService::class));
        $this->assertTrue(class_exists(\Busifirm\Services\IntegrationService::class));
    }

    /**
     * Verify that core classes exist and can be referenced.
     */
    public function testCoreClassesExist(): void
    {
        $this->assertTrue(class_exists(\Busifirm\Core\Config::class));
        $this->assertTrue(class_exists(\Busifirm\Core\Database::class));
        $this->assertTrue(class_exists(\Busifirm\Core\Csrf::class));
        $this->assertTrue(class_exists(\Busifirm\Core\Validator::class));
        $this->assertTrue(class_exists(\Busifirm\Core\Role::class));
        $this->assertTrue(class_exists(\Busifirm\Core\PaystackClient::class));
        $this->assertTrue(class_exists(\Busifirm\Core\ClamAV::class));
        $this->assertTrue(interface_exists(\Busifirm\Core\StorageInterface::class));
        $this->assertTrue(class_exists(\Busifirm\Core\LocalStorage::class));
        $this->assertTrue(class_exists(\Busifirm\Core\S3Storage::class));
        $this->assertTrue(class_exists(\Busifirm\Core\StorageFactory::class));
        $this->assertTrue(interface_exists(\Busifirm\Core\Mailer::class));
        $this->assertTrue(class_exists(\Busifirm\Core\NativePhpMailer::class));
    }

    /**
     * Verify that middleware classes exist.
     */
    public function testMiddlewareClassesExist(): void
    {
        $this->assertTrue(class_exists(\Busifirm\Middleware\AuthMiddleware::class));
        $this->assertTrue(class_exists(\Busifirm\Middleware\AdminMiddleware::class));
        $this->assertTrue(class_exists(\Busifirm\Middleware\RateLimitMiddleware::class));
    }

    /**
     * Verify that controller classes exist.
     */
    public function testControllerClassesExist(): void
    {
        $this->assertTrue(class_exists(\Busifirm\Controllers\AuthController::class));
        $this->assertTrue(class_exists(\Busifirm\Controllers\ListingController::class));
        $this->assertTrue(class_exists(\Busifirm\Controllers\BillingController::class));
        $this->assertTrue(class_exists(\Busifirm\Controllers\DocumentController::class));
        $this->assertTrue(class_exists(\Busifirm\Controllers\AdminController::class));
        $this->assertTrue(class_exists(\Busifirm\Controllers\KycController::class));
        $this->assertTrue(class_exists(\Busifirm\Controllers\ESignController::class));
        $this->assertTrue(class_exists(\Busifirm\Controllers\ChatController::class));
        $this->assertTrue(class_exists(\Busifirm\Controllers\DealController::class));
        $this->assertTrue(class_exists(\Busifirm\Controllers\IPController::class));
        $this->assertTrue(class_exists(\Busifirm\Controllers\IntegrationController::class));
        $this->assertTrue(class_exists(\Busifirm\Controllers\AuditController::class));
    }

    /**
     * Verify Role enum has the expected cases.
     */
    public function testRoleEnumCases(): void
    {
        $this->assertEquals('seller', \Busifirm\Core\Role::Seller->value);
        $this->assertEquals('buyer', \Busifirm\Core\Role::Buyer->value);
        $this->assertEquals('lawyer', \Busifirm\Core\Role::Lawyer->value);
        $this->assertEquals('broker', \Busifirm\Core\Role::Broker->value);
        $this->assertEquals('admin', \Busifirm\Core\Role::Admin->value);
    }

    /**
     * Verify Role capability methods work correctly.
     */
    public function testRoleCapabilities(): void
    {
        $this->assertTrue(\Busifirm\Core\Role::Seller->canCreateListings());
        $this->assertTrue(\Busifirm\Core\Role::Broker->canCreateListings());
        $this->assertFalse(\Busifirm\Core\Role::Buyer->canCreateListings());
        $this->assertFalse(\Busifirm\Core\Role::Lawyer->canCreateListings());
        $this->assertFalse(\Busifirm\Core\Role::Admin->canCreateListings());

        $this->assertTrue(\Busifirm\Core\Role::Lawyer->canSignAsWitness());
        $this->assertFalse(\Busifirm\Core\Role::Seller->canSignAsWitness());

        $this->assertTrue(\Busifirm\Core\Role::Admin->isAdmin());
        $this->assertFalse(\Busifirm\Core\Role::Seller->isAdmin());
    }

    /**
     * Verify Role::fromString parser works.
     */
    public function testRoleFromString(): void
    {
        $this->assertEquals(\Busifirm\Core\Role::Seller, \Busifirm\Core\Role::fromString('seller'));
        $this->assertEquals(\Busifirm\Core\Role::Admin, \Busifirm\Core\Role::fromString('admin'));
        $this->assertNull(\Busifirm\Core\Role::fromString('invalid_role'));
    }

    /**
     * Verify Validator::email accepts valid emails and rejects invalid ones.
     */
    public function testValidatorEmail(): void
    {
        $this->assertTrue(\Busifirm\Core\Validator::email('user@example.com'));
        $this->assertTrue(\Busifirm\Core\Validator::email('test.user@busifirm.com'));
        $this->assertFalse(\Busifirm\Core\Validator::email('not-an-email'));
        $this->assertFalse(\Busifirm\Core\Validator::email(''));
    }

    /**
     * Verify Validator::password enforces the policy.
     */
    public function testValidatorPassword(): void
    {
        $this->assertTrue(\Busifirm\Core\Validator::password('password1'));
        $this->assertTrue(\Busifirm\Core\Validator::password('LongPassphrase123'));
        $this->assertFalse(\Busifirm\Core\Validator::password('short1')); // too short
        $this->assertFalse(\Busifirm\Core\Validator::password('allletters')); // no digit
        $this->assertFalse(\Busifirm\Core\Validator::password('12345678')); // no letter
    }

    /**
     * Verify Validator::role rejects 'admin'.
     */
    public function testValidatorRoleRejectsAdmin(): void
    {
        $this->assertTrue(\Busifirm\Core\Validator::role('seller'));
        $this->assertTrue(\Busifirm\Core\Validator::role('buyer'));
        $this->assertTrue(\Busifirm\Core\Validator::role('lawyer'));
        $this->assertTrue(\Busifirm\Core\Validator::role('broker'));
        $this->assertFalse(\Busifirm\Core\Validator::role('admin'));
        $this->assertFalse(\Busifirm\Core\Validator::role('invalid'));
    }

    /**
     * Verify Validator::token accepts 64-char hex strings only.
     */
    public function testValidatorToken(): void
    {
        $validToken = str_repeat('a', 64);
        $this->assertTrue(\Busifirm\Core\Validator::token($validToken));
        $this->assertFalse(\Busifirm\Core\Validator::token('short'));
        $this->assertFalse(\Busifirm\Core\Validator::token(str_repeat('g', 64))); // non-hex
        $this->assertFalse(\Busifirm\Core\Validator::token(''));
    }
}
