<?php
declare(strict_types=1);

/**
 * Busifirm — front controller.
 *
 * All HTTP traffic enters here. PHP's built-in dev server: `php -S localhost:8000 -t public`
 * Production (Nginx): point the root to public/ and `try_files $uri /index.php?$query_string;`.
 *
 * KISS: no router library. A small switch on REQUEST_METHOD + path prefix is
 * enough for the M1 surface area. When routes exceed ~30 (Phase 2+), swap in
 * bramus/router or nikic/fast-route without touching controllers.
 */

use Busifirm\Core\Config;
use Busifirm\Core\ClamAV;
use Busifirm\Core\Csrf;
use Busifirm\Core\PaystackClient;
use Busifirm\Core\Role;
use Busifirm\Core\StorageInterface;
use Busifirm\Core\StorageFactory;
use Busifirm\Controllers\AdminController;
use Busifirm\Controllers\AuditController;
use Busifirm\Controllers\AuthController;
use Busifirm\Controllers\BillingController;
use Busifirm\Controllers\ChatController;
use Busifirm\Controllers\DealController;
use Busifirm\Controllers\DocumentController;
use Busifirm\Controllers\ESignController;
use Busifirm\Controllers\IntegrationController;
use Busifirm\Controllers\IPController;
use Busifirm\Controllers\KycController;
use Busifirm\Controllers\ListingController;
use Busifirm\Core\NativePhpMailer;
use Busifirm\Middleware\AdminMiddleware;
use Busifirm\Middleware\AuthMiddleware;
use Busifirm\Middleware\RateLimitMiddleware;
use Busifirm\Services\AdminService;
use Busifirm\Services\AuditService;
use Busifirm\Services\BillingService;
use Busifirm\Services\ChatService;
use Busifirm\Services\DealService;
use Busifirm\Services\DocumentService;
use Busifirm\Services\ESignService;
use Busifirm\Services\IntegrationService;
use Busifirm\Services\IPService;
use Busifirm\Services\KycService;
use Busifirm\Services\ListingService;
use Busifirm\Services\PlanEnforcementService;
use Busifirm\Services\UserService;

// ---- Bootstrap --------------------------------------------------
$projectRoot = dirname(__DIR__);
require_once $projectRoot . '/app/Core/Config.php';
require_once $projectRoot . '/app/Core/Database.php';
require_once $projectRoot . '/app/Core/Csrf.php';
require_once $projectRoot . '/app/Core/Validator.php';
require_once $projectRoot . '/app/Core/Role.php';
require_once $projectRoot . '/app/Core/Mailer.php';
require_once $projectRoot . '/app/Core/PaystackClient.php';
// M5 polish: Storage is now an interface with LocalStorage + S3Storage implementations.
require_once $projectRoot . '/app/Core/StorageInterface.php';
require_once $projectRoot . '/app/Core/LocalStorage.php';
require_once $projectRoot . '/app/Core/S3Storage.php';
require_once $projectRoot . '/app/Core/StorageFactory.php';
require_once $projectRoot . '/app/Core/ClamAV.php';
require_once $projectRoot . '/app/Services/UserService.php';
require_once $projectRoot . '/app/Services/AuditService.php';
require_once $projectRoot . '/app/Services/ListingService.php';
require_once $projectRoot . '/app/Services/IPService.php';
require_once $projectRoot . '/app/Services/DealService.php';
require_once $projectRoot . '/app/Services/ChatService.php';
require_once $projectRoot . '/app/Services/ESignService.php';
require_once $projectRoot . '/app/Services/IntegrationService.php';
require_once $projectRoot . '/app/Services/KycService.php';
require_once $projectRoot . '/app/Services/BillingService.php';
require_once $projectRoot . '/app/Services/DocumentService.php';
require_once $projectRoot . '/app/Services/AdminService.php';
require_once $projectRoot . '/app/Services/PlanEnforcementService.php';
require_once $projectRoot . '/app/Controllers/AuthController.php';
require_once $projectRoot . '/app/Controllers/ListingController.php';
require_once $projectRoot . '/app/Controllers/IPController.php';
require_once $projectRoot . '/app/Controllers/DealController.php';
require_once $projectRoot . '/app/Controllers/ChatController.php';
require_once $projectRoot . '/app/Controllers/ESignController.php';
require_once $projectRoot . '/app/Controllers/IntegrationController.php';
require_once $projectRoot . '/app/Controllers/KycController.php';
require_once $projectRoot . '/app/Controllers/AuditController.php';
require_once $projectRoot . '/app/Controllers/BillingController.php';
require_once $projectRoot . '/app/Controllers/DocumentController.php';
require_once $projectRoot . '/app/Controllers/AdminController.php';
require_once $projectRoot . '/app/Middleware/AuthMiddleware.php';
require_once $projectRoot . '/app/Middleware/AdminMiddleware.php';
require_once $projectRoot . '/app/Middleware/RateLimitMiddleware.php';

// Autoload composer if present (dev only — Phase 3 hard-dependency).
if (is_file($projectRoot . '/vendor/autoload.php')) {
    require_once $projectRoot . '/vendor/autoload.php';
}

try {
    Config::load($projectRoot . '/.env');
} catch (\Throwable $e) {
    http_response_code(500);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['ok' => false, 'error' => 'Server configuration error.']);
    exit;
}

// XFILE-018 fix: set PHP's default timezone from APP_TIMEZONE so that date(),
// strtotime(), and other PHP time functions use the correct timezone. Without
// this, PlanEnforcementService::todayStartInAccra() uses Africa/Accra via
// DateTimeImmutable, but BillingService::startTrial() uses date() which
// defaults to UTC — cross-layer timezone inconsistency.
date_default_timezone_set(Config::get('APP_TIMEZONE', 'Africa/Accra'));

// ---- Session config ---------------------------------------------
$cookieLifetime = Config::getInt('SESSION_LIFETIME_SECONDS', 7200);
$cookieName = Config::get('SESSION_COOKIE_NAME', 'busifirm_session');
$isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
    || (($_SERVER['SERVER_PORT'] ?? 0) == 443);

session_set_cookie_params([
    'lifetime' => $cookieLifetime,
    'path' => '/',
    'domain' => '',
    'secure' => $isHttps,
    'httponly' => true,
    // SEC-32 fix: changed SameSite from Lax to Strict for a financial app.
    // Lax allows GET requests from cross-origin to carry the session cookie.
    // Strict blocks all cross-origin requests — safest for a billing platform.
    'samesite' => 'Strict',
]);
session_name($cookieName);
// session_start() is deferred — only started by endpoints that need it.

// ---- Error display ----------------------------------------------
if (Config::getBool('APP_DEBUG', false)) {
    error_reporting(E_ALL);
    ini_set('display_errors', '0');  // never echo errors to the response body
    ini_set('log_errors', '1');
} else {
    error_reporting(E_ALL & ~E_DEPRECATED & ~E_STRICT);
    ini_set('display_errors', '0');
    ini_set('log_errors', '1');
}

// ---- Routing ----------------------------------------------------
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
// Strip a possible /index.php prefix if Nginx rewrites weirdly.
if (str_starts_with($path, '/index.php')) {
    $path = substr($path, strlen('/index.php')) ?: '/';
}

// --- API routes (/api/auth/*) ---
if (str_starts_with($path, '/api/auth/')) {
    // Start session now — all auth endpoints need it (CSRF, login state).
    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_start();
    }

    // CSRF: required on every mutating method (POST/PUT/PATCH/DELETE).
    // /api/auth/csrf and /api/auth/verify are exempt (the former issues the
    // token; the latter is a one-shot GET-style link even though it is GET).
    $isMutating = in_array($method, ['POST', 'PUT', 'PATCH', 'DELETE'], true);
    if ($isMutating) {
        $csrfHeader = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
        // /api/auth/login and /api/auth/register and /api/auth/forgot and
        // /api/auth/reset may be called BEFORE a CSRF token is issued. To
        // avoid a chicken-and-egg problem, we issue a CSRF token on any GET
        // to /api/auth/csrf AND on every successful login/register response.
        // For unauthenticated mutating endpoints we accept either:
        //   (a) the CSRF token returned from a previous GET /api/auth/csrf, or
        //   (b) a one-time exemption for register/login/forgot/reset.
        $exemptPaths = ['/api/auth/register', '/api/auth/login', '/api/auth/forgot', '/api/auth/reset'];
        if (!in_array($path, $exemptPaths, true) && !Csrf::verify($csrfHeader)) {
            http_response_code(403);
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode(['ok' => false, 'error' => 'Invalid or missing CSRF token.']);
            exit;
        }
    }

    // Rate limit the bruteforce-prone endpoints.
    $rateLimited = [
        'POST /api/auth/login',
        'POST /api/auth/register',
        'POST /api/auth/forgot',
        'POST /api/auth/reset',
    ];
    $key = "{$method} {$path}";
    if (in_array($key, $rateLimited, true)) {
        if (!RateLimitMiddleware::allow('auth:' . $path)) {
            RateLimitMiddleware::denyResponse();
            exit;
        }
    }

    // Instantiate the controller with its dependencies.
    $mailer = new NativePhpMailer();
    $service = new UserService($mailer);
    $controller = new AuthController($service);

    try {
        switch ($key) {
            case 'POST /api/auth/register':
                $controller->register();
                break;
            case 'GET /api/auth/verify':
                $controller->verifyEmail();
                break;
            case 'POST /api/auth/login':
                $controller->login();
                break;
            case 'POST /api/auth/logout':
                $controller->logout();
                break;
            case 'GET /api/auth/me':
                $controller->me();
                break;
            case 'GET /api/auth/csrf':
                $controller->csrf();
                break;
            case 'POST /api/auth/forgot':
                $controller->forgotPassword();
                break;
            case 'POST /api/auth/reset':
                $controller->resetPassword();
                break;
            default:
                http_response_code(404);
                header('Content-Type: application/json; charset=utf-8');
                echo json_encode(['ok' => false, 'error' => 'Endpoint not found.']);
        }
    } catch (\Throwable $e) {
        error_log('[busifirm] ' . $e->getMessage() . "\n" . $e->getTraceAsString());
        http_response_code(500);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode([
            'ok' => false,
            'error' => Config::getBool('APP_DEBUG', false)
                ? $e->getMessage()
                : 'Internal server error.',
        ]);
    }
    exit;
}

// --- Health check ---
if ($path === '/api/health') {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['ok' => true, 'ts' => date(DATE_ATOM)]);
    exit;
}

// --- M4: Paystack webhook ---
// Special handling: NO CSRF, NO AuthMiddleware. Paystack has no session.
// Signature verification (HMAC-SHA512) replaces both.
if ($path === '/api/billing/webhook' && $method === 'POST') {
    // PHP-053 fix: removed the first try/catch block that called
    // `Config::get('PAYSTACK_SECRET_KEY')`. Config::get returns null if the
    // key is missing — it only throws if Config::load was never called (which
    // happened at line 102). So the first try/catch never caught anything.
    // The real validation happens in `PaystackClient::__construct` (which
    // throws if the key is missing) inside the try block below.
    try {
        $paystack = new PaystackClient();
        $billingService = new BillingService($paystack);
        $auditService = new AuditService();
        $userService = new UserService(new NativePhpMailer());
        $controller = new BillingController($billingService, $auditService, $userService);
        $controller->webhook();
    } catch (\Throwable $e) {
        error_log('[busifirm] Webhook error: ' . $e->getMessage());
        http_response_code(500);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['ok' => false, 'error' => 'Webhook processing error.']);
    }
    exit;
}

// --- M2: domain API routes (/api/{listings,ips,deals,chat,esigns,integrations,kyc,audit}) ---
// All non-auth API routes go through the SAME pipeline as auth:
//   1. start session
//   2. require CSRF on every mutating method (no exemptions — only auth bootstrap endpoints are exempt)
//   3. require authenticated user (AuthMiddleware::requireUser)
//   4. dispatch to the controller
$apiDomains = ['listings', 'ips', 'deals', 'chat', 'esigns', 'integrations', 'kyc', 'audit', 'billing', 'documents', 'admin'];
$isDomainApi = false;
foreach ($apiDomains as $d) {
    if ($path === "/api/{$d}" || str_starts_with($path, "/api/{$d}/")) {
        $isDomainApi = true;
        break;
    }
}
if ($isDomainApi) {
    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_start();
    }

    // CSRF: required on every mutating method. No exemptions for domain APIs
    // (the user is already authenticated and has a CSRF token from /api/auth/csrf
    // or /api/auth/login).
    $isMutating = in_array($method, ['POST', 'PUT', 'PATCH', 'DELETE'], true);
    if ($isMutating) {
        $csrfHeader = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
        if (!Csrf::verify($csrfHeader)) {
            http_response_code(403);
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode(['ok' => false, 'error' => 'Invalid or missing CSRF token.']);
            exit;
        }
    }

    // Auth: every domain API requires a logged-in user.
    if (!AuthMiddleware::requireUser()) {
        exit;
    }

    // Wire up shared services (KISS: shared audit service for all controllers).
    $auditService = new AuditService();

    // M4 polish: PlanEnforcementService — shared by ListingService + ChatService.
    // Constructed once; both services receive it via constructor injection.
    $enforcementService = new PlanEnforcementService();

    $listingService = new ListingService($enforcementService);
    $ipService = new IPService();
    $dealService = new DealService();
    $chatService = new ChatService($enforcementService);
    $esignService = new ESignService();
    $integrationService = new IntegrationService();
    $kycService = new KycService();
    // M4: Billing — PaystackClient is constructed fresh here. If PAYSTACK_SECRET_KEY
    // is unset, the constructor throws and the user sees a 500 for billing endpoints
    // only (other domain endpoints keep working). Front controller catches it.
    $paystackClient = null;
    try {
        $paystackClient = new PaystackClient();
    } catch (\Throwable $e) {
        // Billing endpoints will return 500 when called; other domains unaffected.
        error_log('[busifirm] PaystackClient not initialized: ' . $e->getMessage());
    }
    $billingService = $paystackClient !== null ? new BillingService($paystackClient) : null;

    $listingController  = new ListingController($listingService, $auditService);
    $ipController       = new IPController($ipService);
    $dealController     = new DealController($dealService, $auditService);
    $chatController     = new ChatController($chatService, $auditService);
    $esignController    = new ESignController($esignService, $auditService);
    $integrationController = new IntegrationController($integrationService, $auditService);
    $kycController      = new KycController($kycService, $auditService);
    $auditController    = new AuditController($auditService);
    // BillingController depends on BillingService (may be null if Paystack unconfigured).
    // The billing route cases below check for null and return a clear 503.
    $userServiceForBilling = new UserService(new NativePhpMailer());
    $billingController = $billingService !== null
        ? new BillingController($billingService, $auditService, $userServiceForBilling)
        : null;

    // M5 polish: DocumentService receives StorageInterface (selected via StorageFactory)
    // + ClamAV scanner (constructed unconditionally — its scan() returns 'skipped'
    // when CLAMAV_ENABLED=false, so dev environments work without a clamd daemon).
    $storage = StorageFactory::make();
    $clamav = new ClamAV();
    $documentService = new DocumentService($storage, $clamav);
    $documentController = new DocumentController($documentService, $auditService);

    // M6: AdminService + AdminController.
    $adminService = new AdminService();
    $adminController = new AdminController($adminService);

    // Path-parameter extraction for /api/{domain}/{id}/... patterns.
    // We split on '/' and ignore empty segments.
    $segments = array_values(array_filter(explode('/', $path), fn($s) => $s !== ''));
    // $segments[0] = 'api', $segments[1] = domain, $segments[2] = id (optional), $segments[3] = action (optional)
    $domain = $segments[1] ?? '';
    $id = $segments[2] ?? null;
    $action = $segments[3] ?? null;
    // PHP-036 fix: removed dead $key variable. It was computed on every domain
    // API request but never read — the switch below uses `switch (true)` with
    // case expressions that match on $path and $method directly.

    try {
        switch (true) {
            // --- Listings ---
            case $path === '/api/listings' && $method === 'GET':
                $listingController->list(); break;
            case $path === '/api/listings' && $method === 'POST':
                $listingController->save(); break;
            case $path === '/api/listings/duplicate' && $method === 'GET':
                $listingController->checkDuplicate(); break;
            case str_starts_with($path, '/api/listings/') && $id && $action === 'delete' && $method === 'POST':
                $listingController->delete($id); break;
            case str_starts_with($path, '/api/listings/') && $id && $method === 'GET':
                $listingController->get($id); break;

            // --- IPs ---
            case $path === '/api/ips' && $method === 'GET':
            case $path === '/api/ips/search' && $method === 'GET':
                $ipController->search(); break;
            case $path === '/api/ips/all' && $method === 'GET':
                $ipController->all(); break;
            case str_starts_with($path, '/api/ips/') && $id && $method === 'GET':
                $ipController->get($id); break;

            // --- Deals ---
            case $path === '/api/deals' && $method === 'GET':
                $dealController->list(); break;
            case $path === '/api/deals' && $method === 'POST':
                $dealController->create(); break;
            case str_starts_with($path, '/api/deals/') && $id && $action === 'delete' && $method === 'POST':
                $dealController->delete($id); break;
            case str_starts_with($path, '/api/deals/') && $id && $method === 'POST':
                $dealController->update($id); break;

            // --- Chat ---
            case $path === '/api/chat' && $method === 'GET':
                $chatController->list(); break;
            case $path === '/api/chat' && $method === 'POST':
                $chatController->create(); break;
            case str_starts_with($path, '/api/chat/') && $id && $action === 'message' && $method === 'POST':
                $chatController->sendMessage($id); break;
            case str_starts_with($path, '/api/chat/') && $id && $action === 'read' && $method === 'POST':
                $chatController->markAsRead($id); break;
            case str_starts_with($path, '/api/chat/') && $id && $method === 'GET':
                $chatController->get($id); break;

            // --- ESigns ---
            case $path === '/api/esigns' && $method === 'GET':
                $esignController->list(); break;
            case $path === '/api/esigns/awaiting-witness' && $method === 'GET':
                $esignController->listAwaitingWitness(); break;
            case $path === '/api/esigns' && $method === 'POST':
                $esignController->save(); break;
            case str_starts_with($path, '/api/esigns/') && $id && $action === 'witness-sign' && $method === 'POST':
                $esignController->witnessSign($id); break;

            // --- Integrations ---
            case $path === '/api/integrations' && $method === 'GET':
                $integrationController->get(); break;
            case $path === '/api/integrations/tasks' && $method === 'POST':
                $integrationController->createTask(); break;
            case str_starts_with($path, '/api/integrations/tasks/') && $id && $method === 'POST':
                $integrationController->updateTask($id); break;

            // --- KYC ---
            case $path === '/api/kyc' && $method === 'GET':
                $kycController->getStatus(); break;
            case $path === '/api/kyc' && $method === 'POST':
                $kycController->updateStatus(); break;

            // --- Audit ---
            case $path === '/api/audit' && $method === 'GET':
                $auditController->list(); break;
            case $path === '/api/audit' && $method === 'POST':
                $auditController->log(); break;

            // --- M4: Billing (webhook is handled separately above; these are the user-facing endpoints) ---
            case $path === '/api/billing/plans' && $method === 'GET':
                if ($billingController === null) { http_response_code(503); header('Content-Type: application/json; charset=utf-8'); echo json_encode(['ok' => false, 'error' => 'Billing is not configured. Set PAYSTACK_SECRET_KEY in .env']); break; }
                $billingController->plans(); break;
            case $path === '/api/billing/me' && $method === 'GET':
                if ($billingController === null) { http_response_code(503); header('Content-Type: application/json; charset=utf-8'); echo json_encode(['ok' => false, 'error' => 'Billing is not configured. Set PAYSTACK_SECRET_KEY in .env']); break; }
                $billingController->me(); break;
            case $path === '/api/billing/checkout' && $method === 'POST':
                if ($billingController === null) { http_response_code(503); header('Content-Type: application/json; charset=utf-8'); echo json_encode(['ok' => false, 'error' => 'Billing is not configured. Set PAYSTACK_SECRET_KEY in .env']); break; }
                $billingController->checkout(); break;
            case $path === '/api/billing/return' && $method === 'GET':
                if ($billingController === null) { http_response_code(503); header('Content-Type: application/json; charset=utf-8'); echo json_encode(['ok' => false, 'error' => 'Billing is not configured. Set PAYSTACK_SECRET_KEY in .env']); break; }
                $billingController->returnFromPaystack(); break;
            case $path === '/api/billing/cancel' && $method === 'POST':
                if ($billingController === null) { http_response_code(503); header('Content-Type: application/json; charset=utf-8'); echo json_encode(['ok' => false, 'error' => 'Billing is not configured. Set PAYSTACK_SECRET_KEY in .env']); break; }
                $billingController->cancel(); break;

            // M4 polish: trial + plan change + proration preview.
            case $path === '/api/billing/trial' && $method === 'POST':
                if ($billingController === null) { http_response_code(503); header('Content-Type: application/json; charset=utf-8'); echo json_encode(['ok' => false, 'error' => 'Billing is not configured. Set PAYSTACK_SECRET_KEY in .env']); break; }
                $billingController->startTrial(); break;
            case $path === '/api/billing/change-plan' && $method === 'POST':
                if ($billingController === null) { http_response_code(503); header('Content-Type: application/json; charset=utf-8'); echo json_encode(['ok' => false, 'error' => 'Billing is not configured. Set PAYSTACK_SECRET_KEY in .env']); break; }
                $billingController->changePlan(); break;
            case $path === '/api/billing/proration' && $method === 'GET':
                if ($billingController === null) { http_response_code(503); header('Content-Type: application/json; charset=utf-8'); echo json_encode(['ok' => false, 'error' => 'Billing is not configured. Set PAYSTACK_SECRET_KEY in .env']); break; }
                $billingController->previewProration(); break;

            // --- M5: Documents (file upload + download + list + delete) ---
            // Upload uses multipart/form-data; CSRF token comes via X-CSRF-Token
            // header (set by the frontend api.js wrapper), so the standard CSRF
            // check at the top of this block applies. Download streams the file
            // with proper Content-Type/Content-Disposition headers.
            case $path === '/api/documents' && $method === 'POST':
                $documentController->upload(); break;
            case $path === '/api/documents' && $method === 'GET':
                $documentController->list(); break;
            case str_starts_with($path, '/api/documents/') && $id && $action === 'delete' && $method === 'POST':
                $documentController->delete($id); break;
            case str_starts_with($path, '/api/documents/') && $id && $method === 'GET':
                $documentController->download($id); break;

            // M5 polish: Chunked upload protocol.
            //   POST /api/documents/chunk               — start session (JSON body)
            //   POST /api/documents/chunk/{uploadId}    — upload one chunk (multipart)
            //   POST /api/documents/chunk/{uploadId}/complete — finalize + assemble
            //   POST /api/documents/chunk/{uploadId}/abort    — abandon + cleanup
            //
            // NOTE: These paths are 4-5 segments deep (/api/documents/chunk/{id}[/action]),
            // so the generic $id/$action extraction (which assumes /api/{domain}/{id}/{action})
            // does NOT apply. We extract the uploadId from $segments[3] and the sub-action
            // from $segments[4] explicitly.
            case $path === '/api/documents/chunk' && $method === 'POST':
                $documentController->startChunk(); break;
            case str_starts_with($path, '/api/documents/chunk/')
                && ($segments[3] ?? null) !== null
                && ($segments[4] ?? null) === null
                && $method === 'POST':
                $documentController->uploadChunk($segments[3]); break;
            case str_starts_with($path, '/api/documents/chunk/')
                && ($segments[3] ?? null) !== null
                && ($segments[4] ?? null) === 'complete'
                && $method === 'POST':
                $documentController->completeChunk($segments[3]); break;
            case str_starts_with($path, '/api/documents/chunk/')
                && ($segments[3] ?? null) !== null
                && ($segments[4] ?? null) === 'abort'
                && $method === 'POST':
                $documentController->abortChunk($segments[3]); break;

            // --- M6: Admin (all endpoints require admin role; AdminController
            // re-checks via AdminMiddleware::requireAdmin() as defense in depth) ---
            // Path patterns:
            //   /api/admin/stats
            //   /api/admin/users
            //   /api/admin/users/{id}/verify-kyc
            //   /api/admin/users/{id}/reject-kyc
            //   /api/admin/plans
            //   /api/admin/plans/{code}/set-code
            //   /api/admin/plans/{code}/clear-code
            //   /api/admin/audit
            case $path === '/api/admin/stats' && $method === 'GET':
                $adminController->stats(); break;
            case $path === '/api/admin/users' && $method === 'GET':
                $adminController->listUsers(); break;
            case $path === '/api/admin/audit' && $method === 'GET':
                $adminController->audit(); break;
            case $path === '/api/admin/plans' && $method === 'GET':
                $adminController->listPlans(); break;
            // users/{id}/verify-kyc and users/{id}/reject-kyc
            case str_starts_with($path, '/api/admin/users/') && $id && $action === 'verify-kyc' && $method === 'POST':
                $adminController->verifyKyc($id); break;
            case str_starts_with($path, '/api/admin/users/') && $id && $action === 'reject-kyc' && $method === 'POST':
                $adminController->rejectKyc($id); break;
            // plans/{code}/set-code and plans/{code}/clear-code
            case str_starts_with($path, '/api/admin/plans/') && $id && $action === 'set-code' && $method === 'POST':
                $adminController->setPlanCode($id); break;
            case str_starts_with($path, '/api/admin/plans/') && $id && $action === 'clear-code' && $method === 'POST':
                $adminController->clearPlanCode($id); break;

            // M6 polish: user role change + GDPR delete + restore.
            //   POST /api/admin/users/{id}/role             — change role (invalidates session)
            //   POST /api/admin/users/{id}/delete          — GDPR soft-delete
            //   POST /api/admin/users/{id}/cancel-deletion — restore soft-deleted user
            case str_starts_with($path, '/api/admin/users/') && $id && $action === 'role' && $method === 'POST':
                $adminController->changeUserRole($id); break;
            case str_starts_with($path, '/api/admin/users/') && $id && $action === 'delete' && $method === 'POST':
                $adminController->deleteUser($id); break;
            case str_starts_with($path, '/api/admin/users/') && $id && $action === 'cancel-deletion' && $method === 'POST':
                $adminController->cancelUserDeletion($id); break;

            default:
                http_response_code(404);
                header('Content-Type: application/json; charset=utf-8');
                echo json_encode(['ok' => false, 'error' => 'Endpoint not found.']);
        }
    } catch (\Throwable $e) {
        error_log('[busifirm] ' . $e->getMessage() . "\n" . $e->getTraceAsString());
        http_response_code(500);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode([
            'ok' => false,
            'error' => Config::getBool('APP_DEBUG', false)
                ? $e->getMessage()
                : 'Internal server error.',
        ]);
    }
    exit;
}

// --- Static assets + SPA shell ---
// If the requested path maps to a real file under public/, serve it.
$realPath = realpath(__DIR__ . $path);
$publicRoot = realpath(__DIR__);
if ($realPath !== false && str_starts_with($realPath, $publicRoot) && is_file($realPath)) {
    // Let PHP's built-in server handle the actual file output. Under Nginx,
    // try_files will serve these directly without hitting index.php.
    $mime = mime_content_type($realPath) ?: 'application/octet-stream';
    header('Content-Type: ' . $mime);
    // SEC-31 fix: add nosniff header to ALL responses, including static files.
    // Without this, a browser could sniff a .svg file as text/html and execute
    // embedded JavaScript.
    header('X-Content-Type-Options: nosniff');
    readfile($realPath);
    exit;
}

// --- SPA fallback: serve index.html for any non-API, non-file path ---
$indexFile = __DIR__ . '/index.html';
if (is_file($indexFile)) {
    // SEC-15 fix: add security headers to the HTML response.
    header('Content-Type: text/html; charset=utf-8');
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: DENY');
    header("Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net https://cdnjs.cloudflare.com; style-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net https://cdnjs.cloudflare.com https://fonts.googleapis.com; img-src 'self' data: https:; font-src 'self' https://fonts.gstatic.com; connect-src 'self'; frame-ancestors 'none';");
    header('Referrer-Policy: strict-origin-when-cross-origin');
    // PHP-050 fix: add Strict-Transport-Security header (HSTS) for HTTPS.
    // Only send over HTTPS to avoid trapping users on a misconfigured HTTP-only deployment.
    if ($isHttps) {
        header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
    }
    readfile($indexFile);
    exit;
}

// --- Nothing matched ---
http_response_code(404);
header('Content-Type: application/json; charset=utf-8');
echo json_encode(['ok' => false, 'error' => 'Not found.']);
