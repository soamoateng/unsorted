/**
 * BusifirmApp - Ghana Tech M&A Platform
 * OTH-01 fix: removed the misleading "Fixed: All 76+ bugs" claim.
 * Multiple iterations have fixed many bugs, but the codebase is not bug-free.
 * See worklog.md for iteration history and bug_reports/ for known issues.
 * Date: August 2026 (last modified: September 2026)
 */

// ===== UTILITY MODULE =====
const Utils = {
    // OTH-31 fix: reuse a single div element for sanitization instead of
    // creating a new one per call. The old code called document.createElement
    // on every Utils.sanitize() invocation — ~5000 calls for a 1000-row table.
    _sanitizeDiv: null,
    generateId() {
        if (typeof crypto !== 'undefined' && crypto.randomUUID) return crypto.randomUUID();
        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
            const r = Math.random() * 16 | 0;
            return (c === 'x' ? r : (r & 0x3 | 0x8)).toString(16);
        });
    },
    sanitize(str) {
        if (typeof str !== 'string') return '';
        if (!this._sanitizeDiv) this._sanitizeDiv = document.createElement('div');
        this._sanitizeDiv.textContent = str;
        return this._sanitizeDiv.innerHTML;
    },
    isValidEmail(email) {
        // OTH-34 fix: use a more permissive regex that matches PHP's filter_var
        // (FILTER_VALIDATE_EMAIL) more closely. The old regex rejected quoted
        // local parts like "john doe"@example.com which the server accepts.
        // This regex allows: local@part with optional dots, +, %, and quoted strings.
        const re = /^[^\s@"]+@[^\s@"]+\.[^\s@"]+$/;
        // Also accept quoted local parts: "anything"@domain.tld
        const quotedRe = /^"[^"]*"@[^\s@"]+\.[^\s@"]+$/;
        const str = String(email).toLowerCase();
        return re.test(str) || quotedRe.test(str);
    },
    formatCurrency(amount) {
        // Bug 079 fix: guard against undefined/NaN inputs that produce "GHS NaN"
        if (typeof amount !== 'number' || isNaN(amount)) return 'GHS 0.00';
        // UI-01 fix: use minimumFractionDigits: 2, maximumFractionDigits: 2
        // so fractional amounts (e.g., prorated charges) display correctly.
        // The old maximumFractionDigits: 0 rounded GHS 445.50 to "GHS 446".
        // OTH-33 fix: add fallback for browsers that don't support 'en-GH'.
        try {
            return new Intl.NumberFormat('en-GH', {
                style: 'currency',
                currency: 'GHS',
                minimumFractionDigits: 2,
                maximumFractionDigits: 2
            }).format(amount);
        } catch (e) {
            // Fallback: use default locale with GHS currency code.
            return new Intl.NumberFormat(undefined, {
                style: 'currency',
                currency: 'GHS',
                minimumFractionDigits: 2,
                maximumFractionDigits: 2
            }).format(amount);
        }
    },
    // NOTE: Utils.hashPassword was REMOVED in iteration-2 (M1).
    // Password hashing now happens server-side via PHP password_hash() with
    // PASSWORD_BCRYPT (cost 12). The client never sees, sends, or stores a
    // password hash. See app/Services/UserService.php.
    debounce(fn, ms = 300) {
        let timer;
        return (...args) => { clearTimeout(timer); timer = setTimeout(() => fn(...args), ms); };
    },
    formatDate(date) {
        // OTH-32 fix: guard against Invalid Date. If date is null, undefined,
        // or unparseable, return a fallback string instead of throwing
        // RangeError from Intl.DateTimeFormat.format().
        const d = new Date(date);
        if (isNaN(d.getTime())) return '—';
        return new Intl.DateTimeFormat('en-GH', { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }).format(d);
    },
    deepClone(obj) {
        // OTH-35 fix: add try-catch around JSON deepClone to handle circular
        // refs (which throw TypeError). For circular refs, fall back to
        // shallow clone. Date objects are converted to ISO strings by
        // JSON.stringify — this is acceptable for audit trail entries.
        try {
            return JSON.parse(JSON.stringify(obj));
        } catch (e) {
            // Circular reference or other JSON error — fall back to shallow clone.
            return Array.isArray(obj) ? [...obj] : { ...obj };
        }
    }
};

// ===== TOAST MODULE =====
const Toast = {
    container: null,
    init() { this.container = document.getElementById('toastContainer'); },
    show(message, type = 'info', duration = 4000) {
        if (!this.container) this.init();
        const toast = document.createElement('div');
        toast.className = `toast ${type} show align-items-center mb-2`;
        toast.setAttribute('role', 'alert');
        toast.setAttribute('aria-live', 'assertive');
        const icons = { success: 'check-circle', error: 'times-circle', warning: 'exclamation-triangle', info: 'info-circle' };
        toast.innerHTML = `<div class="d-flex"><div class="toast-body"><i class="fas fa-${icons[type]} me-2"></i>${Utils.sanitize(message)}</div><button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button></div>`;
        this.container.appendChild(toast);

        // OTH-36 fix: use a timestamp-based check instead of raw setTimeout.
        // If the tab was backgrounded (setTimeout throttled), dismiss immediately
        // on visibility change instead of letting old toasts pile up.
        const createdAt = Date.now();
        const dismiss = () => {
            toast.classList.remove('show');
            setTimeout(() => toast.remove(), 300);
        };
        const timer = setTimeout(() => {
            dismiss();
            document.removeEventListener('visibilitychange', onVisible);
        }, duration);
        const onVisible = () => {
            if (!document.hidden && Date.now() - createdAt >= duration) {
                clearTimeout(timer);
                dismiss();
                document.removeEventListener('visibilitychange', onVisible);
            }
        };
        document.addEventListener('visibilitychange', onVisible);
    }
};

// ===== MODAL MODULE =====
// UX-04 fix: Modal.show now accepts optional confirmLabel and cancelLabel
// parameters so callers can specify action-specific button text (e.g.
// "Log out" instead of generic "Confirm"). Defaults remain "Confirm"/"Cancel".
const Modal = {
    show(title, message, onConfirm, onCancel = null, opts = {}) {
        const existing = document.querySelector('.modal-overlay');
        if (existing) existing.remove();
        const confirmLabel = opts.confirmLabel || 'Confirm';
        const cancelLabel = opts.cancelLabel || 'Cancel';
        const confirmClass = opts.confirmClass || 'btn-primary';
        const overlay = document.createElement('div');
        overlay.className = 'modal-overlay';
        overlay.innerHTML = `<div class="modal-content"><h4 class="fw-bold mb-3"><i class="fas fa-question-circle me-2 text-accent"></i>${Utils.sanitize(title)}</h4><div class="mb-4">${message}</div><div class="d-flex gap-3 justify-content-end"><button class="btn btn-outline-light" id="modalCancel">${Utils.sanitize(cancelLabel)}</button><button class="btn ${confirmClass}" id="modalConfirm">${Utils.sanitize(confirmLabel)}</button></div></div>`;
        document.body.appendChild(overlay);

        // OTH-37 fix: trap focus inside the modal. Store the previously focused
        // element so we can restore it when the modal closes.
        const previouslyFocused = document.activeElement;
        const confirmBtn = overlay.querySelector('#modalConfirm');
        const cancelBtn = overlay.querySelector('#modalCancel');
        const focusableElements = [cancelBtn, confirmBtn];

        // Focus the confirm button by default (or cancel if no confirm).
        setTimeout(() => (confirmBtn || cancelBtn)?.focus(), 0);

        const closeModal = (callback) => {
            // Bug 018 fix: capture input values BEFORE removing the overlay.
            // The old code removed the overlay first, then called the callback,
            // which meant getElementById returned null for any inputs in the modal.
            const modalInputs = {};
            overlay.querySelectorAll('input, textarea, select').forEach(el => {
                if (el.id) modalInputs[el.id] = el.value;
            });
            overlay.remove();
            document.removeEventListener('keydown', onKeyDown);
            // Restore focus to the element that opened the modal.
            if (previouslyFocused && previouslyFocused.focus) previouslyFocused.focus();
            if (callback) callback(modalInputs);
        };

        overlay.querySelector('#modalConfirm').addEventListener('click', () => closeModal(onConfirm));
        overlay.querySelector('#modalCancel').addEventListener('click', () => closeModal(onCancel));
        overlay.addEventListener('click', (e) => { if (e.target === overlay) closeModal(onCancel); });

        // OTH-37 fix: trap Tab key within the modal.
        overlay.addEventListener('keydown', (e) => {
            if (e.key !== 'Tab') return;
            const focusable = focusableElements.filter(el => el && el.offsetParent !== null);
            if (focusable.length === 0) return;
            const first = focusable[0];
            const last = focusable[focusable.length - 1];
            if (e.shiftKey) {
                if (document.activeElement === first) { e.preventDefault(); last.focus(); }
            } else {
                if (document.activeElement === last) { e.preventDefault(); first.focus(); }
            }
        });

        // OTH-38 fix: Escape key dismisses the modal (calls onCancel).
        const onKeyDown = (e) => {
            if (e.key === 'Escape') {
                e.preventDefault();
                closeModal(onCancel);
            }
        };
        document.addEventListener('keydown', onKeyDown);
    }
};

// ===== AUDIT TRAIL (M2: server-backed via /api/audit) =====
// Fire-and-forget write: callers do NOT await this. The server writes to
// audit_log with ip_hash + user_agent_hash (see AuditService::log).
// Reads are cached in-memory; call refresh() before reading.
const AuditTrail = {
    _cache: [],
    _loaded: false,
    async log(action, details = {}) {
        if (!window.API || !app?.user?.id) return; // not yet booted / not logged in
        try {
            await API.audit.log(action, details);
            // Optimistic local append so the UI feels instant.
            // OTH-16 fix: store the RAW action (not sanitized). Sanitization
            // should happen at RENDER time, not storage time. The old code
            // sanitized here, then refresh() returned raw actions from the
            // server — inconsistent cache state.
            this._cache.unshift({
                id: Utils.generateId(),
                timestamp: new Date().toISOString(),
                action: action,  // raw — sanitized at render time
                details: Utils.deepClone(details),
                userId: app.user.id,
            });
            if (this._cache.length > 500) this._cache.length = 500;
        } catch (e) { console.warn('AuditTrail.log failed:', e); }
    },
    async refresh() {
        if (!app?.user?.id) { this._cache = []; return []; }
        try {
            const resp = await API.audit.list(200);
            this._cache = resp.entries || [];
            this._loaded = true;
        } catch (e) { console.warn('AuditTrail.refresh failed:', e); }
        return this._cache;
    },
    getAll() { return this._cache; },
    getForUser(userId) { return this._cache.filter(e => e.userId === userId); },
    clear() { this._cache = []; }
};

// ===== STORAGE =====
const Storage = {
    set(key, value) { try { localStorage.setItem(key, JSON.stringify(value)); return true; } catch { Toast.show('Storage limit reached.', 'error'); return false; } },
    get(key, defaultValue = null) { try { const item = localStorage.getItem(key); return item ? JSON.parse(item) : defaultValue; } catch { return defaultValue; } },
    remove(key) { localStorage.removeItem(key); }
};

// ===== KYC (M2: server-backed via /api/kyc) =====
// Single-user cache: KYC is per-user, so we cache the current user's status.
const KYC = {
    STATUS: { VERIFIED: 'verified', PENDING: 'pending', UNVERIFIED: 'unverified' },
    _cache: { status: 'unverified', documents: [], lastUpdated: null },
    async refresh(userId) {
        try {
            const resp = await API.kyc.get();
            this._cache = resp.kyc || { status: this.STATUS.UNVERIFIED, documents: [], lastUpdated: null };
        } catch (e) { console.warn('KYC.refresh failed:', e); }
        return this._cache;
    },
    getStatus(userId) { return this._cache; },
    async updateStatus(userId, status, documents = []) {
        try {
            const resp = await API.kyc.updateStatus(status, documents);
            this._cache = resp.kyc || this._cache;
            AuditTrail.log('KYC status updated', { userId, status });
        } catch (e) {
            Toast.show('Failed to update KYC status.', 'error');
            console.warn('KYC.updateStatus failed:', e);
        }
        return this._cache;
    },
    isVerified(userId) { return this._cache.status === this.STATUS.VERIFIED; }
};

// ===== ESCROW =====
const Escrow = {
    COMMISSION_RATE: 0.02, MINIMUM_FEE: 5000,
    calculateFee(dealAmount) {
        // Bug 046 fix: reject negative deal amounts
        if (typeof dealAmount !== 'number' || isNaN(dealAmount) || dealAmount < 0) {
            return { dealAmount: 0, commissionRate: this.COMMISSION_RATE, platformFee: this.MINIMUM_FEE, sellerReceives: 0 };
        }
        // JS-047 fix + Bug 078 fix: round fee first, then derive sellerReceives
        // from dealAmount - fee WITHOUT re-rounding, so fee + sellerReceives === dealAmount always.
        const fee = Math.round(Math.max(dealAmount * this.COMMISSION_RATE, this.MINIMUM_FEE) * 100) / 100;
        const sellerReceives = Math.round((dealAmount - fee) * 100) / 100;
        return { dealAmount, commissionRate: this.COMMISSION_RATE, platformFee: fee, sellerReceives };
    }
};

// ===== CHAT STORE (M2: server-backed via /api/chat) =====
const ChatStore = {
    _cache: [],
    async refresh(userId) {
        try {
            const resp = await API.chat.list();
            this._cache = resp.conversations || [];
        } catch (e) { console.warn('ChatStore.refresh failed:', e); }
        return this._cache;
    },
    getConversations(userId) { return this._cache; },
    getConversation(userId, convId) { return this._cache.find(c => c.id === convId); },
    async saveConversation(userId, conv) {
        try {
            const resp = await API.chat.create(conv);
            if (resp.conversation) {
                const idx = this._cache.findIndex(c => c.id === resp.conversation.id);
                if (idx >= 0) this._cache[idx] = resp.conversation;
                else this._cache.push(resp.conversation);
            }
        } catch (e) { console.warn('ChatStore.saveConversation failed:', e); Toast.show('Failed to start conversation.', 'error'); }
    },
    async sendMessage(userId, convId, sender, text) {
        try {
            const resp = await API.chat.sendMessage(convId, sender, text);
            if (resp.conversation) {
                const idx = this._cache.findIndex(c => c.id === convId);
                if (idx >= 0) this._cache[idx] = resp.conversation;
            }
            AuditTrail.log('Chat message sent', { convId, sender });
            return true;
        } catch (e) { console.warn('ChatStore.sendMessage failed:', e); return false; }
    },
    async markAsRead(userId, convId) {
        try {
            await API.chat.markAsRead(convId);
            const conv = this._cache.find(c => c.id === convId);
            if (conv) { conv.unreadCount = 0; conv.messages.forEach(m => m.read = true); }
        } catch (e) { console.warn('ChatStore.markAsRead failed:', e); }
    },
    seedData(userId) { /* no-op — server does not seed per-user sample data */ }
};

// ===== LISTING STORE (M2: server-backed via /api/listings) =====
const ListingStore = {
    _cache: [],
    async refresh() {
        try {
            const resp = await API.listings.list();
            this._cache = resp.listings || [];
        } catch (e) { console.warn('ListingStore.refresh failed:', e); }
        return this._cache;
    },
    getAll() { return this._cache; },
    getByUser(userId) { return this._cache.filter(l => l.userId === userId); },
    getById(id) { return this._cache.find(l => l.id === id); },
    async save(listing) {
        const resp = await API.listings.save(listing);
        if (resp.listing) {
            const idx = this._cache.findIndex(l => l.id === resp.listing.id);
            if (idx >= 0) this._cache[idx] = resp.listing;
            else this._cache.push(resp.listing);
        }
        AuditTrail.log('Listing saved', { listingId: listing.id || resp.listing?.id, name: listing.companyName });
        return resp.listing;
    },
    async delete(id) {
        await API.listings.delete(id);
        this._cache = this._cache.filter(l => l.id !== id);
        AuditTrail.log('Listing deleted', { listingId: id });
    },
    async isDuplicate(companyName, excludeId = null) {
        try {
            const resp = await API.listings.checkDuplicate(companyName, excludeId);
            return !!resp.duplicate;
        } catch (e) { console.warn('ListingStore.isDuplicate failed:', e); return false; }
    },
    seedData() { /* no-op — server seeds via migration 20260904_002 */ }
};

// ===== IP STORE (M2: server-backed via /api/ips) =====
const IPStore = {
    _cache: [],
    _lastQuery: null,
    _lastFilters: {},
    async refresh(query = null, filters = {}) {
        try {
            this._lastQuery = query;
            this._lastFilters = filters;
            const resp = (query || filters.sector || filters.type)
                ? await API.ips.search(query, filters)
                : await API.ips.all();
            this._cache = resp.ips || [];
        } catch (e) { console.warn('IPStore.refresh failed:', e); }
        return this._cache;
    },
    getAll() { return this._cache; },
    search(query, filters = {}) { return this.refresh(query, filters); }, // returns a Promise; callers should await
    getById(id) { return this._cache.find(ip => ip.id === id); },
    async fetchById(id) {
        try { const resp = await API.ips.get(id); return resp.ip || null; }
        catch (e) { console.warn('IPStore.fetchById failed:', e); return null; }
    }
};

// ===== DOC TEMPLATES =====
const DocTemplates = {
    templates: {
        ownership: { name: 'Ownership Transfer', icon: 'file-signature', color: 'primary', generate(data) { return `OWNERSHIP TRANSFER AGREEMENT\n\nDate: ${Utils.formatDate(new Date())}\n\n1. PARTIES\nTransferor: ${data.transferor || '[Transferor]'}\nTransferee: ${data.transferee || '[Transferee]'}\n\n2. ASSET DESCRIPTION\n${data.asset || '[Asset]'}\n\n3. CONSIDERATION\n${data.price ? Utils.formatCurrency(data.price) : '[Amount]'}\n\n4. WARRANTIES\nThe Transferor warrants clear title and authority to transfer.\n\n5. GOVERNING LAW\nThis agreement is governed by the laws of the Republic of Ghana.\n\nSigned: _________________\nDate: _________________`; } },
        smart: { name: 'Smart Contract Terms', icon: 'robot', color: 'success', generate(data) { return `SMART CONTRACT TERMS\n\nContract ID: ${Utils.generateId().slice(0, 8)}\nCreated: ${Utils.formatDate(new Date())}\n\n1. AUTOMATED CONDITIONS\n- Payment release upon document verification\n- Escrow held for 14-day dispute period\n- Compliance check with GRA requirements\n\n2. PARTIES\nParty A: ${data.partyA || '[Party A]'}\nParty B: ${data.partyB || '[Party B]'}\n\n3. TERMS\n${data.terms || '[Terms]'}\n\n4. BLOCKCHAIN VERIFICATION\nThis contract will be hashed and stored on-chain.`; } },
        gra: { name: 'GRA Compliance Form', icon: 'check-circle', color: 'info', generate(data) { return `GHANA REVENUE AUTHORITY - COMPLIANCE FORM\n\nForm Date: ${Utils.formatDate(new Date())}\n\n1. TAXPAYER INFORMATION\nName: ${data.taxpayer || '[Name]'}\nTIN: ${data.tin || '[TIN]'}\n\n2. TRANSACTION DETAILS\nTransaction Type: Asset Transfer\nValue: ${data.value ? Utils.formatCurrency(data.value) : '[Value]'}\n\n3. TAX OBLIGATIONS\n- Stamp Duty: Applicable\n- Capital Gains Tax: Calculated per GRA rates\n- VAT: Exempt (if applicable)\n\n4. DECLARATION\nI declare that the information provided is true and accurate.\n\nSignature: _________________\nDate: _________________`; } }
    },
    getAll() { return Object.entries(this.templates).map(([key, t]) => ({ key, ...t })); },
    generate(key, data = {}) { const t = this.templates[key]; return t ? t.generate(data) : ''; }
};

// ===== E-SIGN STORE (M2: server-backed via /api/esigns) =====
const ESignStore = {
    _cache: [],
    async refresh(userId) {
        try {
            const resp = await API.esigns.list();
            this._cache = resp.documents || [];
        } catch (e) { console.warn('ESignStore.refresh failed:', e); }
        return this._cache;
    },
    getAll(userId) { return this._cache; },
    async save(userId, doc) {
        const resp = await API.esigns.save(doc);
        if (resp.document) {
            const idx = this._cache.findIndex(d => d.id === resp.document.id);
            if (idx >= 0) this._cache[idx] = resp.document;
            else this._cache.push(resp.document);
        }
        return resp.document;
    },
    seedData(userId) { /* no-op — server does not seed per-user sample data */ }
};

// ===== INTEGRATION STORE (M2: server-backed via /api/integrations) =====
const IntegrationStore = {
    _cache: { userId: null, tasks: [], lastUpdated: null },
    async refresh(userId) {
        try {
            const resp = await API.integrations.get();
            this._cache = resp.integration || { userId, tasks: [], lastUpdated: null };
        } catch (e) { console.warn('IntegrationStore.refresh failed:', e); }
        return this._cache;
    },
    getForUser(userId) { return this._cache; },
    async updateTask(userId, taskId, updates) {
        try {
            const resp = await API.integrations.updateTask(taskId, updates);
            this._cache = resp.integration || this._cache;
            AuditTrail.log('Integration task updated', { taskId, updates });
        } catch (e) { console.warn('IntegrationStore.updateTask failed:', e); }
        return this._cache;
    },
    async createTask(userId, task) {
        try {
            const resp = await API.integrations.createTask(task);
            this._cache = resp.integration || this._cache;
        } catch (e) { console.warn('IntegrationStore.createTask failed:', e); }
        return this._cache;
    }
};

// ===== DEAL STORE (M2: server-backed via /api/deals) =====
const DealStore = {
    _cache: [],
    async refresh(userId) {
        try {
            const resp = await API.deals.list();
            this._cache = resp.deals || [];
        } catch (e) { console.warn('DealStore.refresh failed:', e); }
        return this._cache;
    },
    getForUser(userId) { return this._cache; },
    async updateDeal(userId, dealId, updates) {
        try {
            const resp = await API.deals.update(dealId, updates);
            if (resp.deal) {
                const idx = this._cache.findIndex(d => d.id === dealId);
                if (idx >= 0) this._cache[idx] = resp.deal;
            }
            AuditTrail.log('Deal updated', { dealId, updates });
        } catch (e) { console.warn('DealStore.updateDeal failed:', e); }
        return this._cache;
    },
    async create(userId, deal) {
        try {
            const resp = await API.deals.create(deal);
            if (resp.deal) this._cache.push(resp.deal);
            return resp.deal;
        } catch (e) { console.warn('DealStore.create failed:', e); return null; }
    }
};

// ===== MAIN APP CLASS =====
class BusifirmApp {
    constructor() {
        this.user = null;
        this.currentChat = null;
        this.sessionTimer = null;
        this.idleTimer = null;
        this.autoSaveTimers = {};
        this.init();
    }

    async init() {
        // JS-029 fix: removed `ListingStore.seedData()` call. It was a no-op
        // (the method body is `/* no-op — server seeds via migration 20260904_002 */`)
        // but ran on every boot. The server is the source of truth — no
        // client-side seeding is needed.
        this.user = this.loadUser();
        // M6: toggle admin nav based on cached role (in case of page reload
        // while already logged in). verifyAuthState will re-confirm.
        this.toggleAdminNav();
        this.initComponents();
        this.initEventListeners();
        this.initRouter();
        this.initSessionTimeout();
        this.initKeyboardShortcuts();
        // M1: intercept auth deep links (#verify-email, #reset-password) sent
        // via email BEFORE the normal screen-routing logic.
        // M4: also intercept #billing-return (Paystack redirect-back).
        const hash = window.location.hash.slice(1);
        const deepLinkRoute = (hash || '').split('?')[0];
        if (deepLinkRoute === 'verify-email' || deepLinkRoute === 'reset-password') {
            // Defer one tick so initComponents() finishes first.
            setTimeout(() => this.handleAuthDeepLink(), 0);
        } else if (deepLinkRoute === 'billing-return' && this.user) {
            // WF-01 fix: warm caches BEFORE handling billing-return so the
            // billing screen has data when it renders after verification.
            await Promise.allSettled([
                ListingStore.refresh(),
                IPStore.refresh(),
                ChatStore.refresh(this.user.id),
                ESignStore.refresh(this.user.id),
                DealStore.refresh(this.user.id),
                IntegrationStore.refresh(this.user.id),
                KYC.refresh(this.user.id),
                AuditTrail.refresh(),
            ]);
            // M4: Paystack redirect-back. Defer so initComponents() finishes.
            setTimeout(() => this.handleBillingReturn(), 0);
        } else if (this.user) {
            // M2: warm all caches in parallel so the dashboard renders with
            // real data on first paint. If a refresh fails (network error),
            // the cache stays empty and the UI shows empty states.
            // PERF-23 fix: use Promise.allSettled instead of Promise.all so
            // that if one store fails to refresh, the others still load and
            // the app remains usable.
            await Promise.allSettled([
                ListingStore.refresh(),
                IPStore.refresh(),
                ChatStore.refresh(this.user.id),
                ESignStore.refresh(this.user.id),
                DealStore.refresh(this.user.id),
                IntegrationStore.refresh(this.user.id),
                KYC.refresh(this.user.id),
                AuditTrail.refresh(),
            ]);
            // JS-050 fix: use deepLinkRoute (stripped of query params) instead of
            // raw hash. The old code did `hash === 'auth'` which fails for
            // `#auth?mode=register` (hash includes the query string).
            if (deepLinkRoute && deepLinkRoute !== 'landing' && deepLinkRoute !== 'auth') this.showScreen(deepLinkRoute);
            else this.showScreen('dashboard');
            // M1: verify the cached session against the server on boot.
            // Fire-and-forget; verifyAuthState() handles 401 by routing to auth.
            this.verifyAuthState();
        } else {
            if (deepLinkRoute === 'auth') this.showScreen('auth', { mode: 'login' });
            else this.showScreen('landing');
        }
    }

    initComponents() {
        if (!customElements.get('app-dashboard')) customElements.define('app-dashboard', DashboardComponent);
        if (!customElements.get('app-listing')) customElements.define('app-listing', ListingComponent);
        if (!customElements.get('app-marketplace')) customElements.define('app-marketplace', MarketplaceComponent);
        if (!customElements.get('app-chat')) customElements.define('app-chat', ChatComponent);
        if (!customElements.get('app-docgen')) customElements.define('app-docgen', DocGenComponent);
        if (!customElements.get('app-esign')) customElements.define('app-esign', ESignComponent);
        if (!customElements.get('app-integration')) customElements.define('app-integration', IntegrationComponent);
        if (!customElements.get('app-billing')) customElements.define('app-billing', BillingComponent);
        if (!customElements.get('app-admin')) customElements.define('app-admin', AdminComponent);
    }

    initEventListeners() {
        const authForm = document.getElementById('authForm');
        if (authForm) authForm.addEventListener('submit', (e) => this.handleAuthSubmit(e));
        const toggleAuth = document.getElementById('toggleAuth');
        if (toggleAuth) toggleAuth.addEventListener('click', () => this.handleToggleAuth());
        // M1: forgot-password + reset-password forms (added to index.html).
        const forgotForm = document.getElementById('forgotForm');
        if (forgotForm) forgotForm.addEventListener('submit', (e) => this.handleForgotPasswordSubmit(e));
        const resetForm = document.getElementById('resetForm');
        if (resetForm) resetForm.addEventListener('submit', (e) => this.handleResetPasswordSubmit(e));
        const forgotLink = document.getElementById('forgotPasswordLink');
        if (forgotLink) forgotLink.addEventListener('click', (e) => { e.preventDefault(); this.showScreen('forgot-password'); });
        document.addEventListener('visibilitychange', () => this.handleVisibilityChange());
        ['mousedown', 'keydown', 'touchstart', 'scroll'].forEach(evt => {
            document.addEventListener(evt, () => this.resetIdleTimer(), { passive: true });
        });
    }

    initRouter() {
        window.addEventListener('popstate', () => {
            const hash = window.location.hash.slice(1) || 'landing';
            if (hash === 'landing' || (this.user && hash !== 'auth')) this.showScreen(hash, {}, false);
            else if (!this.user && hash !== 'landing') this.showScreen('auth', { mode: 'login' }, false);
        });
    }

    initSessionTimeout() {
        const TIMEOUT = 30 * 60 * 1000;
        this.resetIdleTimer();
        this.sessionTimer = setInterval(() => {
            if (this.user) {
                const lastActivity = Storage.get('busifirm_lastActivity', 0);
                if (Date.now() - lastActivity > TIMEOUT) {
                    // UX-03 fix: clear the user BEFORE showing the toast so
                    // the logout is immediate (no 3-second gap where the user
                    // can interact with stale state). The toast is shown for
                    // feedback but the session is already destroyed.
                    Toast.show('Session expired due to inactivity. You have been logged out.', 'warning', 6000);
                    this.logout();
                }
            }
        }, 60000);

        // UX-03 fix: listen for cross-tab activity via the 'storage' event.
        // When another tab updates 'busifirm_lastActivity', this tab receives
        // a storage event. This ensures all tabs share the same idle timer —
        // activity in tab B resets the timer in tab A. When one tab logs out
        // (clears busifirm_user), all other tabs detect it and log out too.
        window.addEventListener('storage', (e) => {
            if (e.key === 'busifirm_lastActivity') {
                // Another tab updated the activity timestamp — reset our local
                // idle warning timer so we don't fire a false "expiring soon" warning.
                clearTimeout(this.idleTimer);
                this.idleTimer = setTimeout(() => {
                    if (this.user) Toast.show('You have been idle for 25 minutes. Session will expire in 5 minutes.', 'warning', 8000);
                }, 25 * 60 * 1000);
            }
            if (e.key === 'busifirm_user' && e.newValue === null && this.user) {
                // Another tab logged out — log out this tab too.
                this.user = null;
                clearTimeout(this.idleTimer);
                this.showScreen('landing');
                Toast.show('You have been logged out from another tab.', 'info', 6000);
            }
        });
    }

    resetIdleTimer() {
        Storage.set('busifirm_lastActivity', Date.now());
        clearTimeout(this.idleTimer);
        this.idleTimer = setTimeout(() => {
            if (this.user) Toast.show('You have been idle for 25 minutes. Session will expire in 5 minutes.', 'warning', 8000);
        }, 25 * 60 * 1000);
    }

    handleVisibilityChange() {
        // WF-27 fix: do NOT reset the idle timer when the tab is hidden.
        // The old code called Storage.set('busifirm_lastActivity', Date.now())
        // when the tab was hidden, which effectively paused the idle timer —
        // a user who walked away with the tab in the background was never
        // logged out. Now we only update activity when the tab is VISIBLE.
        if (!document.hidden) {
            Storage.set('busifirm_lastActivity', Date.now());
        }
    }

    initKeyboardShortcuts() {
        document.addEventListener('keydown', (e) => {
            if (e.ctrlKey && e.key === 'Enter') {
                const activeForm = document.querySelector('.screen.active form');
                if (activeForm) { e.preventDefault(); activeForm.dispatchEvent(new Event('submit')); }
            }
            if (e.key === 'Escape' && this.user) {
                const current = document.querySelector('.screen.active');
                if (current && current.id !== 'dashboard') this.showScreen('dashboard');
            }
            if (e.ctrlKey && e.key === 'k') {
                const searchInput = document.querySelector('.screen.active #marketSearch');
                if (searchInput) { e.preventDefault(); searchInput.focus(); }
            }
        });
    }

    showScreen(screenId, params = {}, pushState = true) {
        const validScreens = ['landing', 'auth', 'dashboard', 'listing', 'marketplace', 'chat', 'docgen', 'esign', 'integration', 'forgot-password', 'reset-password', 'verify-email', 'billing', 'billing-return', 'admin'];  // JS-051 fix: added 'verify-email' (was in authlessScreens but missing from validScreens)
        if (!validScreens.includes(screenId)) { console.warn('Invalid screen:', screenId); screenId = 'landing'; }
        // M1: 'forgot-password' and 'reset-password' are auth-adjacent screens
        // — they are accessible without login (the user has explicitly lost
        // access to their account). All other non-landing screens require auth.
        const authlessScreens = ['landing', 'auth', 'forgot-password', 'reset-password', 'verify-email'];
        if (!authlessScreens.includes(screenId) && !this.user) { Toast.show('Please log in to access this page.', 'warning'); this.showScreen('auth', { mode: 'login' }); return; }
        document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
        const target = document.getElementById(screenId);
        if (target) target.classList.add('active');
        const showNav = !authlessScreens.includes(screenId);
        const nav = document.getElementById('mainNav');
        if (nav) nav.classList.toggle('hidden', !showNav);
        // screenContainer fix: the screenContainer wraps all non-landing screens
        // (dashboard, listing, marketplace, etc.) and starts hidden. It must be
        // unhidden when showing any screen inside it, and hidden when showing
        // the landing page (which is outside screenContainer).
        const screenContainer = document.getElementById('screenContainer');
        if (screenContainer) screenContainer.classList.toggle('hidden', screenId === 'landing');
        // Footer fix: footer should ALWAYS be visible (it was being hidden on
        // landing/auth screens via classList.toggle('hidden', !showNav) which
        // made it disappear when showNav was false). The footer contains
        // important company info, links, and copyright — it should show on
        // all screens including landing and auth.
        const footer = document.getElementById('mainFooter');
        if (footer) footer.classList.remove('hidden');
        window.scrollTo({ top: 0, behavior: 'smooth' });
        if (pushState) { const url = screenId === 'landing' ? window.location.pathname : `#${screenId}`; history.pushState({ screenId, params }, '', url); }
        if (screenId === 'auth') this.updateAuthUI(params.mode || 'login');
        this.announceToScreenReader(`Navigated to ${screenId} page`);
        // Screen refresh fix: re-render + re-attach events on the target component
        // when navigating to it. connectedCallback only fires ONCE (when the element
        // is first added to DOM), so without this, navigating back to a screen shows
        // stale data. This is the root cause of empty lists, missing data, and
        // "frozen" UI after navigation.
        const componentTag = `app-${screenId}`;
        const component = document.querySelector(componentTag);
        if (component && typeof component.render === 'function') {
            component.render();
            if (typeof component.attachEvents === 'function') {
                // Fix: some components have sync attachEvents (returns undefined),
                // others have async (returns Promise). Handle both.
                const result = component.attachEvents();
                if (result && typeof result.catch === 'function') {
                    result.catch(e => console.warn(`${componentTag} attachEvents failed:`, e));
                }
            }
        }
    }

    updateAuthUI(mode) {
        const title = document.getElementById('authTitle');
        const btn = document.getElementById('authBtn');
        const toggle = document.getElementById('toggleAuth');
        const btnText = btn?.querySelector('.btn-text');
        const roleField = document.getElementById('roleField');
        const confirmField = document.getElementById('confirmPasswordField');
        if (title) title.innerHTML = `<i class="fas fa-shield-alt me-2"></i>${mode === 'register' ? 'Sign Up' : 'Login'}`;
        if (btnText) btnText.textContent = mode === 'register' ? 'Sign Up' : 'Login';
        if (toggle) toggle.textContent = mode === 'register' ? 'Have account? Login' : 'Need account? Sign up';
        if (roleField) roleField.classList.toggle('hidden', mode !== 'register');
        if (confirmField) confirmField.classList.toggle('hidden', mode !== 'register');
        const form = document.getElementById('authForm');
        // Bug 089 fix: preserve email when toggling between login/register
        if (form) {
            const emailVal = document.getElementById('email')?.value || '';
            form.reset();
            form.classList.remove('was-validated');
            if (emailVal) { const e = document.getElementById('email'); if (e) e.value = emailVal; }
        }
        const formContainer = document.getElementById('auth');
        if (formContainer) formContainer.dataset.mode = mode;
    }

    async handleAuthSubmit(e) {
        e.preventDefault();
        const form = e.target;
        const mode = document.getElementById('auth')?.dataset.mode || 'login';
        if (!form.checkValidity()) { form.classList.add('was-validated'); Toast.show('Please fix the errors in the form.', 'error'); return; }
        const email = document.getElementById('email')?.value.trim();
        const password = document.getElementById('password')?.value;
        const role = document.getElementById('role')?.value;
        if (!Utils.isValidEmail(email)) { Toast.show('Please enter a valid email address.', 'error'); return; }
        // Bug 099 fix: only enforce password length on REGISTER, not login.
        // Login should accept any password and let the server verify.
        if (mode === 'register' && (!password || password.length < 8)) { Toast.show('Password must be at least 8 characters.', 'error'); return; }
        const spinner = document.getElementById('authSpinner');
        const btnText = document.querySelector('#authBtn .btn-text');
        const btn = document.getElementById('authBtn');
        // Bug 041 fix: disable submit button during async to prevent double-submit
        if (btn) btn.disabled = true;
        if (spinner) spinner.classList.remove('hidden');
        if (btnText) btnText.textContent = mode === 'register' ? 'Creating Account...' : 'Logging in...';
        try {
            let user;
            if (mode === 'register') {
                const confirmPassword = document.getElementById('confirmPassword')?.value;
                if (password !== confirmPassword) { Toast.show('Passwords do not match.', 'error'); return; }
                if (!role) { Toast.show('Please select a user type.', 'error'); return; }
                // Server-side auth (M1): password is hashed with bcrypt on the
                // server. The client sends the plaintext password over HTTPS
                // and never stores it.
                const resp = await API.register(email, password, role);
                user = resp.user;
                // Bug 052 fix: set this.user BEFORE AuditTrail.log so the guard passes.
                this.user = user;
                this.saveUser();
                AuditTrail.log('User registered', { userId: user.id, email, role });
                Toast.show('Account created. Check your email for a verification link.', 'success');
            } else {
                const resp = await API.login(email, password);
                user = resp.user;
                this.user = user;
                this.saveUser();
                AuditTrail.log('User logged in', { userId: user.id, email });
                Toast.show(`Welcome back, ${user.email}!`, 'success');
            }
            // Bug 040 fix: restart the session timeout timer after login.
            // initSessionTimeout runs once in the constructor; logout clears it;
            // without restarting, the idle-timeout check stops after one logout/login cycle.
            // Bug 087 fix: also reset the lastActivity timestamp so the first
            // interval tick after re-login doesn't immediately time out.
            Storage.set('busifirm_lastActivity', Date.now());
            this.initSessionTimeout();
            // M2: warm all caches before showing the dashboard so the first
            // render has real data. Non-blocking — failures leave cache empty
            // and the UI shows empty states.
            // PERF-23 fix: use Promise.allSettled for resilience.
            await Promise.allSettled([
                ListingStore.refresh(),
                IPStore.refresh(),
                ChatStore.refresh(user.id),
                ESignStore.refresh(user.id),
                DealStore.refresh(user.id),
                IntegrationStore.refresh(user.id),
                KYC.refresh(user.id),
                AuditTrail.refresh(),
            ]);
            this.showScreen('dashboard');
        } catch (err) {
            console.error('Auth error:', err);
            const msg = err?.message || 'An unexpected error occurred. Please try again.';
            // Suppress the deprecated browser alert if the legacy code in
            // initEventListeners still references it — we always use Toast.
            Toast.show(msg, 'error');
        } finally {
            if (btn) btn.disabled = false;  // Bug 041 fix: re-enable button
            if (spinner) spinner.classList.add('hidden');
            if (btnText) btnText.textContent = mode === 'register' ? 'Sign Up' : 'Login';
        }
    }

    handleToggleAuth() {
        const authSection = document.getElementById('auth');
        const currentMode = authSection?.dataset.mode || 'login';
        this.updateAuthUI(currentMode === 'register' ? 'login' : 'register');
    }

    confirmLogout() {
        // UX-04 fix: use specific button labels instead of generic "Confirm".
        Modal.show('Log Out', 'Are you sure you want to log out? Any unsaved changes may be lost.',
            () => this.logout(), null,
            { confirmLabel: 'Log Out', cancelLabel: 'Cancel', confirmClass: 'btn-outline-light' });
    }

    async logout() {
        if (this.user) AuditTrail.log('User logged out', { userId: this.user.id });
        // Best-effort server logout — destroys the server session and CSRF
        // token. Network errors are swallowed so a flaky connection never
        // traps the user in a logged-in state on the client.
        try { await API.logout(); } catch (e) { console.warn('Server logout failed:', e); }
        this.user = null;
        Storage.remove('busifirm_user');
        // JS-030 fix: clear both timers so they don't keep firing after logout.
        clearTimeout(this.idleTimer);
        clearInterval(this.sessionTimer);
        Toast.show('You have been logged out successfully.', 'info');
        this.showScreen('landing');
    }

    saveUser() {
        if (this.user) {
            // Cache ONLY the non-sensitive identity fields in localStorage.
            // This is a UX cache so the SPA can render the dashboard instantly
            // on the next page load while /api/auth/me is in flight. No
            // password, no password hash, no auth tokens ever touch storage.
            const safeUser = {
                id: this.user.id,
                email: this.user.email,
                role: this.user.role,
                createdAt: this.user.createdAt,
                emailVerified: !!this.user.emailVerified,
            };
            Storage.set('busifirm_user', safeUser);
            // M6: toggle admin nav visibility based on role.
            this.toggleAdminNav();
        }
    }

    /**
     * M6: Show/hide the admin nav item based on the current user's role.
     * Called after login, register, and verifyAuthState. The server enforces
     * admin-only endpoints; this is purely UX so non-admins don't see a
     * broken link.
     */
    toggleAdminNav() {
        const navItem = document.getElementById('adminNavItem');
        if (navItem) {
            navItem.classList.toggle('hidden', this.user?.role !== 'admin');
        }
    }

    loadUser() {
        // Synchronous cached read of the localStorage identity cache. The
        // server is the source of truth — verifyAuthState() runs on app boot
        // and silently logs the user out if the server says the session is
        // invalid (e.g. session expired server-side).
        //
        // JS-031 fix: removed the redundant try/catch. Storage.get already
        // try/catches JSON.parse internally and returns the defaultValue (null)
        // on any error. The outer try/catch was dead code — it could never fire.
        const stored = Storage.get('busifirm_user', null);
        return (stored && stored.id && stored.email) ? stored : null;
    }

    /**
     * M1: verify the cached user against the server on boot. If the server
     * says "not authenticated" (401), clear the stale cache so the user sees
     * the login screen instead of a broken dashboard. If the server returns
     * a fresher user object (e.g. emailVerified flipped since last login),
     * update the cache.
     */
    async verifyAuthState() {
        if (!this.user) return;
        // WF-02 fix: show a loading indicator while verifying, so the user
        // doesn't see a flash of dashboard data before being routed to auth.
        try {
            const resp = await API.me();
            if (resp && resp.user) {
                this.user = resp.user;
                this.saveUser();
            }
        } catch (err) {
            if (err?.status === 401) {
                // Server session is gone. Clear the stale client cache.
                this.user = null;
                Storage.remove('busifirm_user');
                Toast.show('Your session has expired. Please log in again.', 'info');
                this.showScreen('auth');
            } else {
                // Network error — keep the cached user so they can use the
                // localStorage-backed parts of the app offline.
                console.warn('Auth verification failed (non-401):', err);
            }
        }
    }

    /**
     * M1: handle email-verification and password-reset deep links sent by the
     * server via email. The links use the #verify-email / #reset-password hash
     * routes so the SPA can intercept them client-side.
     */
    async handleAuthDeepLink() {
        const hash = window.location.hash.slice(1);
        const [route, query] = hash.split('?');
        const params = new URLSearchParams(query || '');

        if (route === 'verify-email') {
            const token = params.get('token');
            if (!token) { Toast.show('Invalid verification link.', 'error'); return; }
            this.showLoading();
            try {
                await API.verifyEmail(token);
                Toast.show('Email verified! You can now log in.', 'success');
                // WF-07 fix: if the user is currently in a pre-verification session
                // (from register), update the cached user's emailVerified flag.
                if (this.user && !this.user.emailVerified) {
                    this.user.emailVerified = true;
                    this.saveUser();
                    Toast.show('Your email is now verified. You can continue using the app.', 'success', 6000);
                }
            } catch (err) {
                Toast.show(err?.message || 'Verification failed.', 'error');
            } finally {
                this.hideLoading();
                // WF-07 fix: only redirect to auth if the user is NOT logged in.
                // If they're in a pre-verification session, stay on the dashboard.
                if (!this.user) {
                    // JS-048 fix: removed window.location.hash = 'auth' — showScreen
                    // already calls history.pushState, so setting the hash manually
                    // created a duplicate history entry (Back button needed 2 presses).
                    this.showScreen('auth');
                } else {
                    this.showScreen('dashboard');
                }
            }
            return;
        }

        if (route === 'reset-password') {
            const token = params.get('token');
            if (!token) { Toast.show('Invalid reset link.', 'error'); return; }
            // WF-08 fix: if the user is logged in, log them out first before
            // showing the reset form. The old code showed the reset form while
            // the user was still in a logged-in session — confusing because
            // the new password isn't in effect until they log out and back in.
            if (this.user) {
                await this.logout();
                Toast.show('You have been logged out. Please set a new password.', 'info');
            }
            // Pre-fill the reset form and switch to it.
            this.pendingResetToken = token;
            this.showScreen('reset-password');
            return;
        }
    }

    /**
     * M1: submit the password-reset form (called from the reset-password
     * screen's submit button).
     */
    async handleResetPasswordSubmit(e) {
        e.preventDefault();
        const token = this.pendingResetToken;
        if (!token) { Toast.show('Invalid reset link. Please request a new one.', 'error'); return; }
        const newPassword = document.getElementById('resetPassword')?.value;
        const confirmPassword = document.getElementById('resetConfirmPassword')?.value;
        if (!newPassword || newPassword.length < 8) { Toast.show('Password must be at least 8 characters.', 'error'); return; }
        if (newPassword !== confirmPassword) { Toast.show('Passwords do not match.', 'error'); return; }
        if (!/[A-Za-z]/.test(newPassword) || !/[0-9]/.test(newPassword)) {
            Toast.show('Password must include a letter and a number.', 'error'); return;
        }
        const spinner = document.getElementById('resetSpinner');
        if (spinner) spinner.classList.remove('hidden');
        try {
            await API.resetPassword(token, newPassword);
            this.pendingResetToken = null;
            Toast.show('Password updated. You can now log in.', 'success');
            // JS-048 fix: removed window.location.hash = 'auth' (duplicate history entry).
            this.showScreen('auth');
        } catch (err) {
            Toast.show(err?.message || 'Reset failed.', 'error');
        } finally {
            if (spinner) spinner.classList.add('hidden');
        }
    }

    /**
     * M1: submit the forgot-password form (called from the forgot-password
     * screen's submit button).
     */
    async handleForgotPasswordSubmit(e) {
        e.preventDefault();
        const email = document.getElementById('forgotEmail')?.value.trim();
        if (!Utils.isValidEmail(email)) { Toast.show('Please enter a valid email address.', 'error'); return; }
        const spinner = document.getElementById('forgotSpinner');
        if (spinner) spinner.classList.remove('hidden');
        try {
            await API.forgotPassword(email);
            // Always-success response — server does not leak whether email exists.
            Toast.show('If an account exists for that email, a reset link has been sent.', 'success');
            // JS-048 fix: removed window.location.hash = 'auth' (duplicate history entry).
            this.showScreen('auth');
        } catch (err) {
            Toast.show(err?.message || 'Request failed.', 'error');
        } finally {
            if (spinner) spinner.classList.add('hidden');
        }
    }

    showLoading() { const overlay = document.getElementById('loadingOverlay'); if (overlay) overlay.classList.remove('hidden'); }
    hideLoading() { const overlay = document.getElementById('loadingOverlay'); if (overlay) overlay.classList.add('hidden'); }

    announceToScreenReader(message) {
        const liveRegion = document.getElementById('srLiveRegion') || (() => {
            const el = document.createElement('div');
            el.id = 'srLiveRegion';
            el.className = 'sr-live';
            el.setAttribute('aria-live', 'polite');
            el.setAttribute('aria-atomic', 'true');
            document.body.appendChild(el);
            return el;
        })();
        liveRegion.textContent = message;
    }

    setupAutoSave(formId, storageKey, fields) {
        clearInterval(this.autoSaveTimers[formId]);
        const saveDraft = () => {
            const draft = {};
            fields.forEach(field => { const el = document.getElementById(field); if (el) draft[field] = el.value; });
            Storage.set(storageKey, draft);
        };
        this.autoSaveTimers[formId] = setInterval(saveDraft, 5000);
        const draft = Storage.get(storageKey, null);
        if (draft) { fields.forEach(field => { const el = document.getElementById(field); if (el && draft[field]) el.value = draft[field]; }); }
        return () => { clearInterval(this.autoSaveTimers[formId]); Storage.remove(storageKey); };
    }

    // ===== Action Methods =====
    async deleteListing(listingId) {
        Modal.show('Delete Listing', 'Are you sure you want to delete this listing? This action cannot be undone.', async () => {
            try {
                await ListingStore.delete(listingId);
                Toast.show('Listing deleted successfully.', 'success');
                app.showScreen('listing');
            } catch (e) { Toast.show('Failed to delete listing.', 'error'); console.warn(e); }
        });
    }

    async initiateContact(ipId) {
        // Bug 081 fix: look up owner from cache instead of passing it via onclick
        // (which broke for owners with apostrophes in their names)
        if (!this.user) { Toast.show('Please log in to contact sellers.', 'warning'); return; }
        const ip = IPStore.getById(ipId) || await IPStore.fetchById(ipId);
        const ownerName = ip?.owner || 'Seller';
        const conv = { id: Utils.generateId(), name: ownerName, avatar: 'fa-user', color: 'primary', lastMessage: `Interested in ${ip?.name || 'your IP'}`, lastUpdated: new Date().toISOString(), unreadCount: 0, messages: [{ id: Utils.generateId(), sender: this.user.email, text: `Hello, I am interested in ${ip?.name || 'your IP listing'}. Can we discuss further?`, timestamp: new Date().toISOString(), read: true }] };
        await ChatStore.saveConversation(this.user.id, conv);
        Toast.show(`Started conversation with ${ownerName}`, 'success');
        this.showScreen('chat');
    }

    async makeOffer(ipId) {
        if (!this.user) { Toast.show('Please log in to make offers.', 'warning'); return; }
        const ip = IPStore.getById(ipId) || await IPStore.fetchById(ipId);
        // JS-027 fix: was prompt() — replaced with Modal for consistency.
        // JS-042 fix: validate parseFloat result directly instead of isNaN(offerAmount).
        // isNaN(" ") is false (Number(" ")===0), so whitespace passed the old guard.
        // JS-006 fix: was calc.total (undefined) → "GHS NaN". Now uses amount + platformFee.
        Modal.show('Make Offer', `
            <p class="mb-3">Enter your offer amount for <strong>${Utils.sanitize(ip?.name || 'this IP')}</strong>:</p>
            <input type="number" class="form-control mb-3" id="offerAmountInput" placeholder="GHS" value="${ip?.price || ''}" min="0" step="0.01" autocomplete="off">
        `, (inputs) => {
            const amount = parseFloat(inputs?.offerAmountInput || '');
            if (isNaN(amount) || amount <= 0) { Toast.show('Please enter a valid offer amount.', 'error'); return; }
            // Bug 043 fix: enforce minimum offer (at least 10% of asking price)
            if (ip?.price && amount < ip.price * 0.1) {
                Toast.show(`Offer must be at least 10% of the asking price (${Utils.formatCurrency(ip.price * 0.1)}).`, 'warning');
                return;
            }
            const calc = Escrow.calculateFee(amount);
            // Bug 019 fix: show what buyer pays (amount) and what seller receives (not amount + fee)
            Modal.show('Confirm Offer', `Your offer: ${Utils.formatCurrency(amount)}<br>Platform fee: ${Utils.formatCurrency(calc.platformFee)}<br>Seller receives: ${Utils.formatCurrency(calc.sellerReceives)}`, async () => {
                // Bug 054 fix: actually persist the offer as a deal
                try {
                    await DealStore.create(this.user.id, {
                        name: `Offer on ${ip?.name || 'IP'}`,
                        type: 'offer',
                        value: amount,
                        status: 'active',
                        stage: 'offer_made',
                        partner: ip?.owner || 'Unknown'
                    });
                    Toast.show('Offer submitted successfully! The seller will be notified.', 'success', 6000);
                    AuditTrail.log('Offer made', { ipId, amount, fee: calc.platformFee });
                } catch (err) {
                    Toast.show(err?.message || 'Failed to submit offer.', 'error');
                }
            });
        }, null, { confirmLabel: 'Continue' });
    }

    async selectConversation(convId) {
        if (!this.user) return;
        // JS-003 fix: assign this.currentChat so sendMessage() doesn't always
        // early-return on the `!this.currentChat` guard. The old code only set
        // chat._activeConv on the ChatComponent element, never on BusifirmApp —
        // the send button (onclick="app.sendMessage()") was a silent no-op.
        this.currentChat = convId;
        await ChatStore.markAsRead(this.user.id, convId);
        const chat = document.querySelector('app-chat');
        if (chat) { chat._activeConv = convId; chat.render(); chat.attachEvents(); }
    }

    async sendMessage() {
        if (!this.user || !this.currentChat) return;
        const input = document.getElementById('msgInput');
        const text = input?.value.trim();
        if (!text) return;
        input.value = '';
        await ChatStore.sendMessage(this.user.id, this.currentChat, this.user.email, text);
        const chat = document.querySelector('app-chat');
        if (chat) { chat.render(); chat.attachEvents(); }
    }

    selectTemplate(key) {
        const docgen = document.querySelector('app-docgen');
        if (docgen) { docgen._selectedTemplate = key; docgen.render(); docgen.attachEvents(); }
    }

    previewDocument() {
        const docgen = document.querySelector('app-docgen');
        if (!docgen || !docgen._selectedTemplate) { Toast.show('Please select a template first.', 'warning'); return; }
        const template = DocTemplates.templates[docgen._selectedTemplate];
        const data = { transferor: document.getElementById('docPartyA')?.value, transferee: document.getElementById('docPartyB')?.value, asset: document.getElementById('docDetails')?.value, price: document.getElementById('docAmount')?.value, partyA: document.getElementById('docPartyA')?.value, partyB: document.getElementById('docPartyB')?.value, terms: document.getElementById('docDetails')?.value, taxpayer: document.getElementById('docPartyA')?.value, tin: document.getElementById('docDetails')?.value, value: document.getElementById('docAmount')?.value };
        const preview = template.generate(data);
        const previewEl = document.getElementById('docPreview');
        if (previewEl) previewEl.textContent = preview;
    }

    generateDocument() {
        // UX-16 fix: the old code showed a fake "Document generated and downloaded!"
        // toast after a 1.2s setTimeout without actually generating or downloading
        // anything. Now we generate the document text, create a downloadable Blob,
        // and trigger a real download via an <a> element. If the generation fails,
        // we show an error toast instead.
        const docgen = document.querySelector('app-docgen');
        if (!docgen || !docgen._selectedTemplate) {
            Toast.show('Please select a template first.', 'warning');
            return;
        }
        const template = DocTemplates.templates[docgen._selectedTemplate];
        if (!template) {
            Toast.show('Selected template not found. Please choose a valid template.', 'error');
            return;
        }
        const data = {
            transferor: document.getElementById('docPartyA')?.value,
            transferee: document.getElementById('docPartyB')?.value,
            asset: document.getElementById('docDetails')?.value,
            price: document.getElementById('docAmount')?.value,
            partyA: document.getElementById('docPartyA')?.value,
            partyB: document.getElementById('docPartyB')?.value,
            terms: document.getElementById('docDetails')?.value,
            taxpayer: document.getElementById('docPartyA')?.value,
            tin: document.getElementById('docDetails')?.value,
            value: document.getElementById('docAmount')?.value,
        };
        const content = template.generate(data);
        const previewEl = document.getElementById('docPreview');
        if (previewEl) previewEl.textContent = content;

        const spinner = document.getElementById('docSpinner');
        const btnText = document.querySelector('#generateBtn .btn-text');
        if (spinner) spinner.classList.remove('hidden');
        if (btnText) btnText.textContent = 'Generating...';

        // Use setTimeout to allow the spinner to render before the (synchronous)
        // Blob creation + download trigger.
        setTimeout(() => {
            try {
                // Create a downloadable file from the generated content.
                const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = (template.name || 'document').replace(/[^a-z0-9_-]/gi, '_') + '.txt';
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                URL.revokeObjectURL(url);
                Toast.show('Document generated and downloaded!', 'success');
                AuditTrail.log('Document generated', { template: docgen._selectedTemplate });
            } catch (err) {
                console.warn('Document generation failed:', err);
                Toast.show('Failed to generate document. Please try again.', 'error');
            } finally {
                if (spinner) spinner.classList.add('hidden');
                if (btnText) btnText.textContent = 'Generate & Download';
            }
        }, 100);
    }

    async signDocument(docId) {
        if (!this.user) return;
        const kycStatus = KYC.getStatus(this.user.id);
        if (kycStatus.status !== KYC.STATUS.VERIFIED) { Toast.show('Please complete KYC verification before signing documents.', 'warning'); return; }
        Modal.show('Confirm Signature', 'You are about to electronically sign this document. This action is legally binding under Ghanaian law.', async () => {
            const docs = ESignStore.getAll(this.user.id);
            const doc = docs.find(d => d.id === docId);
            if (!doc) { Toast.show('Document not found.', 'error'); return; }
            doc.status = 'signed';
            doc.signedAt = new Date().toISOString();
            doc.auditTrail = doc.auditTrail || [];
            doc.auditTrail.push({ action: 'Document signed', timestamp: new Date().toISOString(), by: this.user.email });
            try {
                await ESignStore.save(this.user.id, doc);
                Toast.show('Document signed successfully!', 'success');
                AuditTrail.log('Document signed', { docId });
                this.showScreen('esign');
            } catch (e) {
                // WF-22 fix: rollback the optimistic update if the save fails.
                // The old code set doc.status = 'signed' BEFORE the save, so
                // on failure the cache showed 'signed' but the server had 'pending'.
                doc.status = 'pending';
                doc.signedAt = null;
                doc.auditTrail.pop();
                Toast.show('Failed to sign document.', 'error'); console.warn(e);
            }
        });
    }

    /**
     * M3 RBAC: lawyer co-signs a document as a witness. The lawyer's email
     * is sent in the request body so the server can record it in the audit
     * trail. Server enforces role === 'lawyer' via ESignService::witnessSign.
     */
    async signAsWitness(docId) {
        if (!this.user) return;
        if (this.user.role !== 'lawyer' && this.user.role !== 'admin') {  // Bug 068 fix: allow admins for testing
            Toast.show('Only licensed lawyers can sign as a witness.', 'error');
            return;
        }
        Modal.show('Confirm Witness Signature',
            'You are about to apply your witness signature to this document. This action is legally binding under Ghanaian contract law.',
            async () => {
                try {
                    // SEC-01 fix: don't pass witnessEmail — server reads it from session.
                    const resp = await API.esigns.witnessSign(docId);
                    Toast.show('Witness signature applied successfully!', 'success');
                    AuditTrail.log('Document witness-signed', { docId, lawyerId: this.user.id });  // JS-049 fix: was lawyer: this.user.email (raw PII in audit log)
                    // WF-04 fix: removed the double attachEvents() call. The old code
                    // called attachEvents() before render() (binding to soon-to-be-
                    // destroyed DOM) then again after render(). Just render + attach.
                    const esign = document.querySelector('app-esign');
                    if (esign) { await ESignStore.refresh(this.user.id); esign.render(); await esign.attachEvents(); }
                } catch (err) {
                    Toast.show(err?.message || 'Failed to apply witness signature.', 'error');
                    console.warn(err);
                }
            });
    }

    /**
     * M5: Upload a file to the documents endpoint. Returns the document DTO
     * on success. Used by KYC and ESign upload flows.
     */
    async uploadDocument(file, purpose = 'general') {
        if (!file) { Toast.show('No file selected.', 'error'); return null; }
        if (!this.user) { Toast.show('Please log in first.', 'warning'); return null; }
        // Bug 044 fix: validate file type and size before uploading
        const allowedMimes = ['application/pdf', 'image/png', 'image/jpeg'];
        if (!allowedMimes.includes(file.type)) {
            Toast.show('Only PDF, PNG, and JPEG files are allowed.', 'error');
            return null;
        }
        if (file.size > 10 * 1024 * 1024) {
            Toast.show('File size must not exceed 10MB.', 'error');
            return null;
        }
        this.showLoading();
        try {
            const resp = await API.documents.upload(file, purpose);
            Toast.show('File uploaded successfully.', 'success');
            return resp.document;
        } catch (err) {
            Toast.show(err?.message || 'Upload failed.', 'error');
            console.warn(err);
            return null;
        } finally {
            this.hideLoading();
        }
    }

    /**
     * M5: Upload a document for e-signing. Prompts for a file, uploads it,
     * then creates an esign record linked to the uploaded document.
     */
    async uploadEsignDocument() {
        if (!this.user) { Toast.show('Please log in first.', 'warning'); return; }
        // Use a hidden file input to trigger the picker.
        const input = document.createElement('input');
        input.type = 'file';
        input.accept = '.pdf,.png,.jpg,.jpeg,application/pdf,image/png,image/jpeg';
        input.onchange = async (e) => {
            const file = e.target.files?.[0];
            if (!file) return;
            const doc = await this.uploadDocument(file, 'esign');
            if (!doc) return;
            // Create an esign record linked to the uploaded document.
            // JS-027 fix: was prompt() — replaced with Modal for consistency.
            Modal.show('Title Document', `
                <p class="mb-3">Enter a title for this signing document:</p>
                <input type="text" class="form-control mb-3" id="esignTitleInput" value="${Utils.sanitize(doc.originalFilename)}" autocomplete="off">
            `, async (inputs) => {
                const title = inputs?.esignTitleInput?.trim() || doc.originalFilename;
                try {
                    await ESignStore.save(this.user.id, {
                        title: title,
                        documentId: doc.id,
                        status: 'pending',
                        parties: [this.user.email],
                        auditTrail: [
                            { action: 'Document uploaded', timestamp: new Date().toISOString(), by: this.user.email },
                        ],
                    });
                    Toast.show('Document uploaded and ready for signing.', 'success');
                    AuditTrail.log('ESign document created from upload', { docId: doc.id, title });
                    const esign = document.querySelector('app-esign');
                    if (esign) { await ESignStore.refresh(this.user.id); esign.render(); await esign.attachEvents(); }
                } catch (err) {
                    Toast.show(err?.message || 'Failed to create esign record.', 'error');
                }
            }, null, { confirmLabel: 'Save Document' });
        };
        input.click();
    }

    /**
     * M5: Triggered when the user picks a file in the KYC upload form.
     * Uploads the file, then refreshes the KYC status display.
     */
    async handleKycFileUpload(e) {
        const input = e.target;
        const file = input.files?.[0];
        if (!file) return;
        const doc = await this.uploadDocument(file, 'kyc');
        if (doc) {
            // After upload, refresh the KYC display so the new doc shows.
            await KYC.refresh(this.user.id);
            // Bug 085 fix: refresh whichever component is currently active
            // (dashboard OR esign — both have KYC upload forms)
            const activeScreen = document.querySelector('.screen.active');
            const activeComponent = activeScreen?.querySelector('app-dashboard, app-esign');
            if (activeComponent) { activeComponent.render(); await activeComponent.attachEvents(); }
        }
        // Clear the input so the same file can be re-selected if needed.
        input.value = '';
    }

    /**
     * M5: Submit KYC for verification. Uses the documents already uploaded
     * (KYC._cache.documents) instead of mock strings.
     *
     * M6: The auto-verify dev shortcut has been REMOVED. KYC is now verified
     * by an admin via the Admin Panel (AdminService::verifyKyc). The user
     * submits → status flips to 'pending' → admin reviews → status flips to
     * 'verified' or 'rejected'. The user sees the pending state until then.
     */
    async submitKycForVerification() {
        if (!this.user) return;
        const kycStatus = KYC.getStatus(this.user.id);
        const docIds = (kycStatus.documents || []).map(d => d.id);
        if (docIds.length === 0) {
            Toast.show('Please upload at least one document before submitting for KYC verification.', 'warning');
            return;
        }
        await KYC.updateStatus(this.user.id, KYC.STATUS.PENDING, docIds);
        Toast.show('KYC submitted for verification. An admin will review your documents shortly.', 'info', 6000);
        AuditTrail.log('KYC submitted', { userId: this.user.id, docCount: docIds.length });
        // No auto-verify — admin handles it now.
    }

    /**
     * M4: Start Paystack checkout for a plan. Calls /api/billing/checkout,
     * gets an authorization_url, and redirects the user to Paystack.
     * After payment, Paystack redirects back to #billing-return?reference=...
     */
    async startCheckout(planCode) {
        if (!this.user) { Toast.show('Please log in first.', 'warning'); return; }
        if (!planCode) { Toast.show('Invalid plan.', 'error'); return; }
        this.showLoading();
        try {
            const resp = await API.billing.checkout(planCode);
            if (resp.authorization_url) {
                Toast.show('Redirecting to Paystack...', 'info');
                // Full-page redirect — Paystack handles the payment UI.
                window.location.href = resp.authorization_url;
            } else {
                Toast.show('Paystack did not return an authorization URL.', 'error');
            }
        } catch (err) {
            Toast.show(err?.message || 'Failed to start checkout.', 'error');
            console.warn(err);
        } finally {
            this.hideLoading();
        }
    }

    /**
     * M4: Handle the Paystack redirect-back flow. The hash route
     * #billing-return?reference=... triggers this. Verifies the payment
     * server-side and updates the user's plan.
     */
    async handleBillingReturn() {
        const hash = window.location.hash.slice(1);
        const [route, query] = hash.split('?');
        const params = new URLSearchParams(query || '');
        const reference = params.get('reference');
        if (!reference) {
            Toast.show('No payment reference found in the redirect URL.', 'error');
            this.showScreen('billing');
            return;
        }
        this.showScreen('billing-return');

        // UX-05 fix: add a 30-second timeout. If the Paystack verification
        // API is slow or unresponsive, show a fallback message instead of
        // spinning forever. The user can manually navigate to the billing
        // screen to check their current plan.
        let timedOut = false;
        const timeoutId = setTimeout(() => {
            timedOut = true;
            Toast.show('Payment verification is taking longer than expected. Your payment may still be processing — check your billing page in a few minutes.', 'warning', 10000);
            this.showScreen('billing');
        }, 30000);

        try {
            const resp = await API.billing.returnFromPaystack(reference);
            if (timedOut) return; // already redirected to billing by the timeout
            clearTimeout(timeoutId);
            // JS-021 fix: API.billing.returnFromPaystack() calls request('GET', ...),
            // and request() returns `payload` — which is `null` if the server
            // returned a non-JSON body (e.g. a 502 HTML error page from a reverse
            // proxy, or an empty 204). The old code did `if (resp.status === ...)`
            // which throws TypeError: Cannot read properties of null (reading
            // 'status') — caught by the outer catch but the user saw the raw
            // TypeError message. Now we handle null explicitly.
            if (!resp) {
                Toast.show('Server returned an unexpected response. Please check your billing page in a few minutes.', 'warning', 8000);
            } else if (resp.status === 'success') {
                Toast.show(`Payment successful! You are now on the ${resp.plan_code} plan.`, 'success', 6000);
                // Refresh the cached plan code so the UI gates update immediately.
                if (this.user) {
                    try {
                        const meResp = await API.me();
                        if (meResp.planCode) {
                            this.user.planCode = meResp.planCode;
                            this.saveUser();
                        }
                    } catch (e) { /* non-fatal */ }
                }
            } else if (resp.status === 'pending') {
                Toast.show('Payment is still being verified. We will email you once it is confirmed.', 'info', 6000);
            } else {
                Toast.show('Payment failed. Please try again or contact support.', 'error', 6000);
            }
        } catch (err) {
            if (timedOut) return; // already redirected
            clearTimeout(timeoutId);
            Toast.show(err?.message || 'Failed to verify payment.', 'error');
        }
        // Always land on the billing screen so the user sees the current state.
        if (!timedOut) this.showScreen('billing');
    }

    /**
     * M4: Cancel the active subscription. The user retains plan access until
     * the current billing period ends (Paystack behavior).
     */
    async cancelBilling() {
        if (!this.user) return;
        // UX-13 fix: fetch the current subscription to show the specific
        // end date in the modal (was just "end of the current billing period").
        let endDateStr = 'the end of your current billing period';
        try {
            const meResp = await API.billing.me();
            const sub = meResp.subscription;
            if (sub && sub.nextBillingAt) {
                endDateStr = Utils.formatDate(sub.nextBillingAt);
            } else if (sub && sub.trialEndsAt) {
                endDateStr = `your trial end (${Utils.formatDate(sub.trialEndsAt)})`;
            }
        } catch (_) { /* non-fatal — fall back to generic message */ }

        Modal.show('Cancel Subscription',
            `Are you sure you want to cancel your subscription? You will retain access until <strong>${endDateStr}</strong>, after which your account will revert to the Free plan.`,
            async () => {
                try {
                    await API.billing.cancel();
                    Toast.show(`Subscription cancelled. Access continues until ${endDateStr}.`, 'info', 6000);
                    // Refresh the billing screen.
                    const billing = document.querySelector('app-billing');
                    if (billing) { billing.render(); await billing.attachEvents(); }
                } catch (err) {
                    Toast.show(err?.message || 'Failed to cancel subscription.', 'error');
                }
            },
            null,
            { confirmLabel: 'Cancel Subscription', cancelLabel: 'Keep Plan', confirmClass: 'btn-danger' });
    }

    /**
     * M4 polish: Start a 14-day free trial on the given plan. No card required.
     * The trial grants full plan features until trialEndsAt, after which the
     * user is downgraded to free (handled by the billing cron).
     */
    async startTrial(planCode) {
        if (!this.user) { Toast.show('Please log in first.', 'warning'); return; }
        if (!planCode) { Toast.show('Invalid plan.', 'error'); return; }
        // Blind-spot fix: sanitize planCode before interpolating into HTML
        // (Modal now trusts message as HTML, so we must sanitize user-influenced values).
        Modal.show('Start Free Trial',
            `Start a 14-day free trial of the <strong>${Utils.sanitize(planCode)}</strong> plan? No card required — you'll be downgraded to Free automatically when the trial ends.`,
            async () => {
                try {
                    const resp = await API.billing.startTrial(planCode);
                    // UX-10 fix: include the plan name in the toast so the user
                    // knows which plan they're trialing (was just "Active until <date>").
                    // Bug 096 fix: use plan name (not lowercase planCode) in the toast
                    const planName = plans.find(p => p.code === planCode)?.name || planCode;
                    Toast.show(`${planName} trial started! Active until ${Utils.formatDate(resp.trialEndsAt)}.`, 'success', 6000);
                    // Refresh cached plan code + billing screen.
                    try {
                        const meResp = await API.me();
                        if (meResp.planCode) { this.user.planCode = meResp.planCode; this.saveUser(); }
                    } catch (_) {}
                    const billing = document.querySelector('app-billing');
                    if (billing) { billing.render(); await billing.attachEvents(); }
                } catch (err) {
                    Toast.show(err?.message || 'Failed to start trial.', 'error');
                }
            });
    }

    /**
     * M4 polish: Change plan mid-cycle. For upgrades, the user is redirected
     * to Paystack to pay the prorated difference. For downgrades, the change
     * is scheduled for the next billing date (no charge today).
     */
    async changePlan(newPlanCode) {
        if (!this.user) { Toast.show('Please log in first.', 'warning'); return; }
        if (!newPlanCode) { Toast.show('Invalid plan.', 'error'); return; }

        // Preview the proration first so we can show the user what they'll pay.
        try {
            const preview = await API.billing.previewProration(newPlanCode);
            if (preview.action === 'downgrade_scheduled') {
                // UX-12 fix: explicitly tell the user they keep current plan
                // features until the downgrade takes effect.
                Modal.show('Schedule Downgrade',
                    `Downgrade to <strong>${Utils.sanitize(preview.planCode)}</strong>?<br><br>
                    <strong>Effective date:</strong> ${Utils.formatDate(preview.scheduledFor)} (your next billing date).<br>
                    <strong>Until then:</strong> You keep all current plan features at no extra charge.<br>
                    <strong>After:</strong> Your plan changes to ${Utils.sanitize(preview.planCode)}. No charge today.`,
                    async () => {
                        try {
                            const resp = await API.billing.changePlan(newPlanCode);
                            Toast.show(`Downgrade scheduled for ${Utils.formatDate(resp.scheduledFor)}.`, 'info', 6000);
                            const billing = document.querySelector('app-billing');
                            if (billing) { billing.render(); await billing.attachEvents(); }
                        } catch (err) {
                            Toast.show(err?.message || 'Failed to schedule downgrade.', 'error');
                        }
                    });
            } else if (preview.action === 'upgrade') {
                // UX-11 fix: mention the recurring charge starting next cycle,
                // not just the prorated amount today.
                Modal.show('Upgrade Now',
                    `Upgrade to <strong>${Utils.sanitize(preview.planCode)}</strong>?<br><br>
                    <strong>Today:</strong> Prorated charge of ${Utils.formatCurrency(preview.amountGhs)} (${preview.daysRemaining} days remaining in your current cycle).<br>
                    <strong>Next cycle:</strong> Full plan price charged at the start of each billing period.<br><br>
                    You can cancel anytime before the next billing date.`,
                    async () => {
                        try {
                            const resp = await API.billing.changePlan(newPlanCode);
                            if (resp.authorizationUrl) {
                                Toast.show('Redirecting to Paystack for prorated charge...', 'info');
                                window.location.href = resp.authorizationUrl;
                            } else {
                                Toast.show('Upgrade initiated.', 'success');
                            }
                        } catch (err) {
                            Toast.show(err?.message || 'Failed to start upgrade.', 'error');
                        }
                    });
            }
        } catch (err) {
            Toast.show(err?.message || 'Failed to preview proration.', 'error');
        }
    }

    // ===== M6: Admin action methods (admin role only; server enforces) =====

    async adminVerifyKyc(userId) {
        if (!this.user || this.user.role !== 'admin') { Toast.show('Admin access required.', 'error'); return; }
        try {
            await API.admin.verifyKyc(userId);
            Toast.show('User KYC verified.', 'success');
            await this._refreshAdminUsers();
            // WF-12 fix: also refresh stats so KYC verified/pending counts update.
            const admin = document.querySelector('app-admin');
            if (admin && admin.loadStats) await admin.loadStats();
        } catch (err) { Toast.show(err?.message || 'Failed to verify KYC.', 'error'); }
    }

    async adminRejectKyc(userId) {
        if (!this.user || this.user.role !== 'admin') { Toast.show('Admin access required.', 'error'); return; }
        Modal.show('Reject KYC',
            'Are you sure you want to reject this user\'s KYC? They will need to re-upload documents.',
            async () => {
                try {
                    await API.admin.rejectKyc(userId);
                    Toast.show('User KYC rejected.', 'info');
                    await this._refreshAdminUsers();
                    // WF-12 fix: also refresh stats.
                    const admin = document.querySelector('app-admin');
                    if (admin && admin.loadStats) await admin.loadStats();
                } catch (err) { Toast.show(err?.message || 'Failed to reject KYC.', 'error'); }
            });
    }

    async adminEditPlanCode(planCode, currentCode) {
        if (!this.user || this.user.role !== 'admin') { Toast.show('Admin access required.', 'error'); return; }
        // UX-07 fix: replaced native prompt() with a styled Modal containing
        // a text input. The old prompt() was inconsistent with the rest of the
        // admin UI and could be blocked by sandboxed iframes.
        const existing = document.querySelector('.modal-overlay');
        if (existing) existing.remove();
        const overlay = document.createElement('div');
        overlay.className = 'modal-overlay';
        overlay.innerHTML = `
            <div class="modal-content">
                <h4 class="fw-bold mb-3"><i class="fas fa-credit-card me-2 text-accent"></i>Paystack Plan Code</h4>
                <p class="text-white-50 mb-3">Enter the Paystack plan code for <strong>${Utils.sanitize(planCode)}</strong>. Leave empty to clear (revert to one-time transactions).</p>
                <input type="text" class="form-control mb-3" id="planCodeInput" value="${Utils.sanitize(currentCode || '').replace(/"/g, '&quot;')}" placeholder="e.g. PLN_abc12345" autocomplete="off">  <!-- JS-046 fix: escape " for HTML attribute context -->
                <div class="d-flex gap-3 justify-content-end">
                    <button class="btn btn-outline-light" id="planCodeCancel">Cancel</button>
                    <button class="btn btn-primary" id="planCodeSave">Save</button>
                </div>
            </div>`;
        document.body.appendChild(overlay);
        const input = overlay.querySelector('#planCodeInput');
        input.focus();
        input.select();

        const submit = async () => {
            const newCode = input.value.trim();
            overlay.remove();
            try {
                if (newCode === '') {
                    await API.admin.clearPlanCode(planCode);
                    Toast.show('Plan code cleared. Billing now uses one-time transactions.', 'info');
                } else {
                    await API.admin.setPlanCode(planCode, newCode);
                    Toast.show('Plan code updated. Recurring billing is now active for this plan.', 'success');
                }
                await this._refreshAdminPlans();
            } catch (err) { Toast.show(err?.message || 'Failed to update plan code.', 'error'); }
        };

        overlay.querySelector('#planCodeSave').addEventListener('click', submit);
        overlay.querySelector('#planCodeCancel').addEventListener('click', () => overlay.remove());
        overlay.addEventListener('click', (e) => { if (e.target === overlay) overlay.remove(); });
        input.addEventListener('keydown', (e) => { if (e.key === 'Enter') submit(); if (e.key === 'Escape') overlay.remove(); });
    }

    /**
     * M6 polish: Change a user's role. The user's active session will be
     * invalidated on their next request (role_version pattern).
     */
    async adminChangeUserRole(userId, currentRole) {
        if (!this.user || this.user.role !== 'admin') { Toast.show('Admin access required.', 'error'); return; }
        // UX-06 fix: replaced native prompt() with a styled Modal containing
        // a role dropdown. The old prompt() required typing the role exactly
        // and had no validation feedback. Now the admin selects from a dropdown.
        const roles = ['seller', 'buyer', 'lawyer', 'broker'];
        const existing = document.querySelector('.modal-overlay');
        if (existing) existing.remove();
        const overlay = document.createElement('div');
        overlay.className = 'modal-overlay';
        const options = roles.map(r =>
            `<option value="${r}" ${r === currentRole ? 'selected' : ''}>${r.charAt(0).toUpperCase() + r.slice(1)}</option>`
        ).join('');
        overlay.innerHTML = `
            <div class="modal-content">
                <h4 class="fw-bold mb-3"><i class="fas fa-user-edit me-2 text-accent"></i>Change User Role</h4>
                <p class="text-white-50 mb-2">User: <code>${Utils.sanitize(userId.slice(0, 8))}…</code></p>
                <p class="text-white-50 mb-3">Current role: <span class="badge bg-secondary">${Utils.sanitize(currentRole)}</span></p>
                <label class="text-white-50 mb-1">New role:</label>
                <select class="form-select mb-3" id="roleSelect">${options}</select>
                <p class="text-warning small mb-3"><i class="fas fa-exclamation-triangle me-1"></i>The user's active session will be invalidated on their next request. Admin promotion is SQL-only by design.</p>
                <div class="d-flex gap-3 justify-content-end">
                    <button class="btn btn-outline-light" id="roleCancel">Cancel</button>
                    <button class="btn btn-primary" id="roleSave">Change Role</button>
                </div>
            </div>`;
        document.body.appendChild(overlay);
        const select = overlay.querySelector('#roleSelect');
        select.focus();

        const submit = async () => {
            const newRole = select.value;
            overlay.remove();
            if (newRole === currentRole) {
                Toast.show('User is already on this role.', 'info');
                return;
            }
            try {
                await API.admin.changeUserRole(userId, newRole);
                Toast.show(`Role changed to ${newRole}. The user's session will be invalidated on next request.`, 'success', 6000);
                await this._refreshAdminUsers();
                // WF-13 fix: also refresh stats.
                const adminEl = document.querySelector('app-admin');
                if (adminEl && adminEl.loadStats) await adminEl.loadStats();
            } catch (err) { Toast.show(err?.message || 'Failed to change role.', 'error'); }
        };

        overlay.querySelector('#roleSave').addEventListener('click', submit);
        overlay.querySelector('#roleCancel').addEventListener('click', () => overlay.remove());
        overlay.addEventListener('click', (e) => { if (e.target === overlay) overlay.remove(); });
    }

    /**
     * M6 polish + M9 precursor: GDPR soft-delete a user. The user cannot
     * log in immediately; their data is hard-deleted after a 30-day window.
     */
    async adminDeleteUser(userId, email) {
        if (!this.user || this.user.role !== 'admin') { Toast.show('Admin access required.', 'error'); return; }
        // UX-08 fix: show more identifying info (user ID, email, role, KYC
        // status, plan) so the admin can confirm they're deleting the right
        // user. The old modal only showed the email, which could be confused
        // with similar-looking emails.
        // We fetch the user details from the cached users list to avoid an
        // extra API call. If not found, we fall back to just the email.
        let userDetails = null;
        try {
            const resp = await API.admin.listUsers();
            userDetails = (resp.users || []).find(u => u.id === userId);
        } catch (_) { /* non-fatal — fall back to email only */ }

        const infoRows = [];
        infoRows.push(`<tr><td class="text-white-50">Email</td><td class="text-white">${Utils.sanitize(email)}</td></tr>`);
        if (userDetails) {
            infoRows.push(`<tr><td class="text-white-50">User ID</td><td class="text-white"><code>${Utils.sanitize(userId)}</code></td></tr>`);
            infoRows.push(`<tr><td class="text-white-50">Role</td><td><span class="badge bg-secondary">${Utils.sanitize(userDetails.role)}</span></td></tr>`);
            infoRows.push(`<tr><td class="text-white-50">KYC</td><td>${userDetails.kycStatus === 'verified' ? '<span class="badge bg-success">verified</span>' : userDetails.kycStatus === 'pending' ? '<span class="badge bg-warning">pending</span>' : '<span class="badge bg-secondary">' + Utils.sanitize(userDetails.kycStatus || 'unverified') + '</span>'}</td></tr>`);
            infoRows.push(`<tr><td class="text-white-50">Plan</td><td class="text-white">${Utils.sanitize(userDetails.planCode || 'free')}</td></tr>`);
        }
        const infoTable = `<table class="table table-sm mb-3">${infoRows.join('')}</table>`;

        Modal.show('Delete User (GDPR)',
            `<p class="mb-3">Are you sure you want to delete this user? This action cannot be undone after 30 days.</p>
             ${infoTable}
             <p class="mb-2 text-warning"><i class="fas fa-exclamation-triangle me-1"></i>Consequences:</p>
             <ul class="text-white-50 small mb-3">
                <li>The user will be unable to log in immediately.</li>
                <li>Their data will be <strong>hard-deleted after 30 days</strong>.</li>
                <li>Audit log entries will be anonymized (user_id set to NULL) and retained for the legal period.</li>
                <li>You can cancel the deletion within the 30-day window if needed.</li>
             </ul>`,
            async () => {
                try {
                    const resp = await API.admin.deleteUser(userId);
                    Toast.show(`User deleted. Hard-delete scheduled for ${Utils.formatDate(resp.deletionScheduledFor)}.`, 'info', 8000);
                    await this._refreshAdminUsers();
                    // WF-14 fix: also refresh stats so total user count updates.
                    const adminEl = document.querySelector('app-admin');
                    if (adminEl && adminEl.loadStats) await adminEl.loadStats();
                } catch (err) { Toast.show(err?.message || 'Failed to delete user.', 'error'); }
            },
            null,
            { confirmLabel: 'Delete User', cancelLabel: 'Cancel', confirmClass: 'btn-danger' });
    }

    /**
     * M6 polish: Cancel a pending user deletion (within the 30-day window).
     */
    async adminCancelUserDeletion(userId) {
        if (!this.user || this.user.role !== 'admin') { Toast.show('Admin access required.', 'error'); return; }
        Modal.show('Cancel User Deletion',
            'Restore this user? Their login access will be reinstated. Note: their subscription was already cancelled at delete time and will need to be re-subscribed manually.',
            async () => {
                try {
                    await API.admin.cancelUserDeletion(userId);
                    Toast.show('User restored.', 'success');
                    await this._refreshAdminUsers();
                } catch (err) { Toast.show(err?.message || 'Failed to cancel deletion.', 'error'); }
            });
    }

    async refreshAdminAudit(clear = false) {
        const actionInput = document.getElementById('auditFilterAction');
        const userInput = document.getElementById('auditFilterUserId');
        const filters = {};
        if (!clear) {
            if (actionInput?.value) filters.action = actionInput.value;
            if (userInput?.value) filters.userId = userInput.value;
        } else {
            if (actionInput) actionInput.value = '';
            if (userInput) userInput.value = '';
        }
        const admin = document.querySelector('app-admin');
        if (admin && admin.loadAudit) {
            await admin.loadAudit(filters);
        }
    }

    async _refreshAdminUsers() {
        const admin = document.querySelector('app-admin');
        if (admin && admin.loadUsers) await admin.loadUsers();
    }

    async _refreshAdminPlans() {
        const admin = document.querySelector('app-admin');
        if (admin && admin.loadPlans) await admin.loadPlans();
    }

    // JS-002 fix: inline onclick="app._toggleDeletedUsers()" calls this method
    // on BusifirmApp, but the actual implementation lives on AdminComponent
    // (app.js:2967). The old code threw TypeError: app._toggleDeletedUsers is
    // not a function — the entire UX-09 deleted-user-restore flow was dead.
    // This proxy delegates to the AdminComponent element.
    _toggleDeletedUsers() {
        const admin = document.querySelector('app-admin');
        if (admin && typeof admin._toggleDeletedUsers === 'function') {
            admin._toggleDeletedUsers();
        }
    }

    viewAuditTrail(docId) {
        const entries = AuditTrail.getForUser(this.user?.id || 'anonymous');
        // Blind-spot fix: null-guard e.details before accessing e.details.docId.
        // The old code assumed every entry had a details object — if any entry
        // had details: null, the filter threw TypeError.
        const docEntries = entries.filter(e => {
            if (!e || !e.details) return false;
            return e.details.docId === docId || e.details.listingId === docId;
        });
        let html = '<div class="audit-trail">';
        if (docEntries.length === 0) html += '<p class="text-white-50">No audit trail entries found for this item.</p>';
        else {
            html += '<p class="text-white-50 small mb-3">' + docEntries.length + ' entr' + (docEntries.length === 1 ? 'y' : 'ies') + ' found.</p>';
            docEntries.forEach(e => {
                html += `<div class="audit-item"><div class="text-white small">${Utils.sanitize(e.action)}</div><div class="audit-time">${Utils.formatDate(e.timestamp)}</div></div>`;
            });
        }
        html += '</div>';

        // UX-14 fix: pass the HTML directly as the Modal message instead of
        // injecting it post-creation via a global selector. The old code:
        //   Modal.show('Audit Trail', '', ...);
        //   const modalContent = document.querySelector('.modal-content p');
        //   if (modalContent) modalContent.innerHTML = html;
        // had two bugs: (1) race condition — the querySelector might run before
        // the modal is in the DOM, (2) the selector '.modal-content p' targets
        // the <p> tag, but the Modal was changed in v0.8.3 to use a <div> for
        // the message container (UX-04 fix). The selector would return null.
        Modal.show('Audit Trail', html, () => {}, () => {});
    }

    /**
     * M5: Legacy entry point — the existing UI buttons call app.initiateKYC().
     * Now delegates to submitKycForVerification() which uses real uploaded docs.
     */
    async initiateKYC() {
        await this.submitKycForVerification();
    }

    calculateFee() {
        const input = document.getElementById('feeCalcInput');
        const result = document.getElementById('feeResult');
        if (!input || !result) return;
        const amount = parseFloat(input.value) || 0;
        if (amount <= 0) { result.innerHTML = '<span class="text-warning">Enter a valid amount</span>'; return; }
        const calc = Escrow.calculateFee(amount);
        // OTH-41 fix: use Escrow.MINIMUM_FEE directly instead of calc.MINIMUM_FEE
        // (which doesn't exist on the returned object — always fell back to 5000).
        result.innerHTML = `<div>Platform Fee: <strong>${Utils.formatCurrency(calc.platformFee)}</strong></div><div>Net to Seller: <strong class="text-success">${Utils.formatCurrency(calc.sellerReceives)}</strong></div><div class="mt-1 text-white-50">(${Math.round(calc.commissionRate * 100)}% or min ${Utils.formatCurrency(Escrow.MINIMUM_FEE)})</div>`;  // JS-007 fix: was calc.commissionRate * 100 → 2.0000000000000004%
    }

    resetMarketplaceFilters() {
        const search = document.getElementById('marketSearch');
        const sector = document.getElementById('marketSectorFilter');
        const type = document.getElementById('marketTypeFilter');
        if (search) search.value = '';
        if (sector) sector.value = '';
        if (type) type.value = '';
        const market = document.querySelector('app-marketplace');
        if (market) { market.render(); market.attachEvents(); }
    }

    acceptMatch(listingId) {
        Toast.show('Match accepted! The seller has been notified.', 'success');
        AuditTrail.log('Match accepted', { listingId });
    }

    rejectMatch(listingId) {
        Toast.show('Match rejected. We will find better matches for you.', 'info');
        AuditTrail.log('Match rejected', { listingId });
    }

    viewIntegrationDetails(taskId) {
        Toast.show('Integration details view coming soon.', 'info');
    }

    updateChecklist(index, checked) {
        Toast.show(`Checklist item ${checked ? 'completed' : 'updated'}.`, 'success');
    }
}

// ===== WEB COMPONENTS =====

// OTH-44 fix: BaseComponent now logs a warning if a subclass forgets to
// override render(). This helps developers catch missing render() methods
// that result in blank components.
class BaseComponent extends HTMLElement {
    // JS-052 fix: wrap async attachEvents in .catch() so unhandled promise
    // rejections don't silently disappear. connectedCallback is synchronous
    // and can't await, but we can at least log errors.
    connectedCallback() { this.render(); this.attachEvents().catch(e => console.warn('attachEvents failed:', e)); }
    render() {
        // OTH-44 fix: if a subclass forgets to override render(), log a warning.
        console.warn(`${this.tagName}: render() not overridden — component will be blank.`);
    }
    attachEvents() {}
}

class DashboardComponent extends BaseComponent {
    render() {
        if (!app.user) return;
        const deals = DealStore.getForUser(app.user.id);
        const activeDeals = deals.filter(d => d.status === 'active').length;
        const totalValue = deals.reduce((sum, d) => sum + (d.value || 0), 0);
        const matches = deals.filter(d => d.status === 'active' && d.stage === 'negotiation').length;
        const contacts = ChatStore.getConversations(app.user.id).length;
        const kycStatus = KYC.getStatus(app.user.id);
        const recentActivity = AuditTrail.getForUser(app.user.id).slice(0, 5);

        this.innerHTML = `
            <div class="mb-4">
                <nav class="breadcrumb-nav" aria-label="breadcrumb">
                    <span><i class="fas fa-home me-1"></i>Dashboard</span>
                </nav>
                <h2 class="text-white fw-bold mb-1">Welcome back, ${Utils.sanitize(app.user.email.split('@')[0])}</h2>
                <p class="text-white-50 mb-0">Here is an overview of your M&A activity</p>
            </div>
            <div class="row">
                <div class="col-md-3 mb-4">
                    <div class="glass-card p-4 text-center text-white card-modern">
                        <i class="fas fa-handshake fa-3x mb-3 text-accent"></i>
                        <h3 class="fw-bold">${activeDeals}</h3>
                        <p class="mb-0 text-white-50">Active Deals</p>
                    </div>
                </div>
                <div class="col-md-3 mb-4">
                    <div class="glass-card p-4 text-center text-white card-modern">
                        <i class="fas fa-bell fa-3x mb-3 text-info"></i>
                        <h3 class="fw-bold">${matches}</h3>
                        <p class="mb-0 text-white-50">New Matches</p>
                    </div>
                </div>
                <div class="col-md-3 mb-4">
                    <div class="glass-card p-4 text-center text-white card-modern">
                        <i class="fas fa-chart-line fa-3x mb-3 text-success"></i>
                        <h3 class="fw-bold">${Utils.formatCurrency(totalValue)}</h3>
                        <p class="mb-0 text-white-50">Total Pipeline</p>
                    </div>
                </div>
                <div class="col-md-3 mb-4">
                    <div class="glass-card p-4 text-center text-white card-modern">
                        <i class="fas fa-users fa-3x mb-3 text-warning"></i>
                        <h3 class="fw-bold">${contacts}</h3>
                        <p class="mb-0 text-white-50">Contacts</p>
                    </div>
                </div>
            </div>
            <div class="row mt-2">
                <div class="col-lg-8 mb-4">
                    <div class="glass-card p-4">
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <h4 class="text-white fw-bold mb-0"><i class="fas fa-list me-2"></i>Active Deals</h4>
                            <button class="btn btn-sm btn-outline-light" onclick="app.showScreen('marketplace')">Browse Marketplace</button>
                        </div>
                        <div class="table-responsive">
                            <table class="table table-dark table-hover">
                                <thead><tr><th>Deal</th><th>Type</th><th>Value</th><th>Stage</th><th>Partner</th><th>Actions</th></tr></thead>
                                <tbody>
                                    ${deals.filter(d => d.status === 'active').map(d => `
                                        <tr>
                                            <td>${Utils.sanitize(d.name)}</td>
                                            <td><span class="badge bg-info">${d.type}</span></td>
                                            <td>${Utils.formatCurrency(d.value)}</td>
                                            <td><span class="badge bg-${d.stage === 'negotiation' ? 'warning' : 'primary'}">${d.stage}</span></td>
                                            <td>${Utils.sanitize(d.partner)}</td>
                                            <td>
                                                <button class="btn btn-sm btn-primary me-1" onclick="app.showScreen('chat')" title="Message"><i class="fas fa-comment"></i></button>
                                                <button class="btn btn-sm btn-success" onclick="app.showScreen('esign')" title="Sign"><i class="fas fa-signature"></i></button>
                                            </td>
                                        </tr>
                                    `).join('') || '<tr><td colspan="6" class="text-center text-white-50">No active deals</td></tr>'}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 mb-4">
                    <div class="glass-card p-4">
                        <h4 class="text-white fw-bold mb-3"><i class="fas fa-shield-alt me-2"></i>KYC Status</h4>
                        <div class="kyc-badge ${kycStatus.status} mb-3">
                            <i class="fas fa-${kycStatus.status === 'verified' ? 'check-circle' : kycStatus.status === 'pending' ? 'clock' : 'times-circle'}"></i>
                            ${kycStatus.status.charAt(0).toUpperCase() + kycStatus.status.slice(1)}
                        </div>
                        <p class="text-white-50 small mb-3">Complete your KYC to unlock all platform features.</p>
                        <!-- M5: uploaded KYC documents with download links -->
                        ${(kycStatus.documents || []).length > 0 ? `
                            <h6 class="text-white small mb-2"><i class="fas fa-paperclip me-1"></i>Uploaded Documents</h6>
                            <ul class="list-unstyled mb-3 small">
                                ${kycStatus.documents.map(d => `
                                    <li class="mb-1">
                                        <a href="${d.downloadUrl && d.downloadUrl.startsWith('/') ? d.downloadUrl : '#'}" target="_blank" class="text-white-50 text-decoration-none">  <!-- JS-043 fix: validate URL starts with / to prevent javascript: XSS -->
                                            <!-- UI-02 fix: proper icon mapping for PDF, PNG/JPEG, and fallback -->
                                            <i class="fas fa-file-${d.mimeType === 'application/pdf' ? 'pdf' : d.mimeType === 'image/png' || d.mimeType === 'image/jpeg' ? 'image' : 'alt'} me-1"></i>
                                            ${Utils.sanitize(d.originalFilename)}
                                            <small class="text-white-50">(${d.sizeHuman || ''})</small>
                                        </a>
                                    </li>
                                `).join('')}
                            </ul>
                        ` : ''}
                        ${kycStatus.status !== 'verified' ? `
                            <!-- M5: file upload input -->
                            <div class="mb-2">
                                <label class="form-label text-white-50 small mb-1">Upload KYC Document (PDF, PNG, or JPEG, max 10MB)</label>
                                <input type="file" class="form-control form-control-sm" id="kycFileInput"
                                       accept=".pdf,.png,.jpg,.jpeg,application/pdf,image/png,image/jpeg"
                                       onchange="app.handleKycFileUpload(event)">
                            </div>
                            <button class="btn btn-sm btn-accent w-100 mb-2" style="background: var(--accent); color: white;" onclick="app.initiateKYC()">
                                <i class="fas fa-paper-plane me-1"></i>Submit for Verification
                            </button>
                        ` : ''}
                        <hr class="border-white border-opacity-25">
                        <h5 class="text-white fw-bold mb-2"><i class="fas fa-history me-2"></i>Recent Activity</h5>
                        <div class="audit-trail">
                            ${recentActivity.length > 0 ? recentActivity.map(a => `
                                <div class="audit-item">
                                    <div class="text-white small">${Utils.sanitize(a.action)}</div>
                                    <div class="audit-time">${Utils.formatDate(a.timestamp)}</div>
                                </div>
                            `).join('') : '<p class="text-white-50 small">No recent activity</p>'}
                        </div>
                    </div>
                </div>
            </div>
        `;
    }
}

class ListingComponent extends BaseComponent {
    render() {
        const userListings = app.user ? ListingStore.getByUser(app.user.id) : [];
        const clearDraft = app.setupAutoSave('listingForm', 'busifirm_listing_draft', ['companyName', 'listingSector', 'listingRevenue', 'listingValuation', 'listingDescription']);
        this._clearDraft = clearDraft;
        // M3 RBAC: only sellers and brokers can create listings. The server
        // enforces this too (ListingService.save throws), but the UI hides
        // the form for cleaner UX. Buyers/lawyers see a notice instead.
        // Bug 067 fix: allow admins to create listings too (was excluding them)
        const canCreateListing = app.user && ['seller', 'broker', 'admin'].includes(app.user.role);

        this.innerHTML = `
            <div class="mb-4">
                <nav class="breadcrumb-nav" aria-label="breadcrumb">
                    <a href="#" onclick="app.showScreen('dashboard'); return false;">Dashboard</a>
                    <span class="separator">/</span>
                    <span>Company Listing</span>
                </nav>
                <h2 class="text-white fw-bold"><i class="fas fa-building me-2"></i>Company Listing</h2>
                <p class="text-white-50">List your company or intellectual property for sale</p>
            </div>
            <div class="row">
                <div class="col-lg-8 mb-4">
                    <div class="glass-card p-5">
                        ${canCreateListing ? `
                        <h4 class="text-white fw-bold mb-4">Create New Listing</h4>
                        <form id="listingForm" class="listing-form" novalidate>
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Company Name *</label>
                                    <input class="form-control" id="companyName" placeholder="e.g. TechStart Ghana" required minlength="2" maxlength="100">
                                    <div class="invalid-feedback">Company name is required (2-100 characters).</div>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Sector *</label>
                                    <select class="form-select" id="listingSector" required>
                                        <option value="" disabled selected>Select sector</option>
                                        <option value="Fintech">Fintech</option>
                                        <option value="Agritech">Agritech</option>
                                        <option value="Healthtech">Healthtech</option>
                                        <option value="Edtech">Edtech</option>
                                        <option value="Cleantech">Cleantech</option>
                                        <option value="E-commerce">E-commerce</option>
                                        <option value="Other">Other</option>
                                    </select>
                                    <div class="invalid-feedback">Please select a sector.</div>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Annual Revenue (GHS)</label>
                                    <input class="form-control" id="listingRevenue" type="number" placeholder="e.g. 500000" min="0" step="1000">
                                    <div class="invalid-feedback">Revenue must be a positive number.</div>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Valuation (GHS) *</label>
                                    <input class="form-control" id="listingValuation" type="number" placeholder="e.g. 2000000" required min="1" step="1000">
                                    <div class="invalid-feedback">Valuation must be greater than 0.</div>
                                </div>
                                <div class="col-12 mb-3">
                                    <label class="form-label">Description *</label>
                                    <textarea class="form-control" id="listingDescription" rows="4" placeholder="Describe your company, products, team, and why you are selling..." required minlength="20" maxlength="2000"></textarea>
                                    <div class="invalid-feedback">Description is required (20-2000 characters).</div>
                                </div>
                            </div>
                            <div class="d-flex gap-3">
                                <button type="submit" class="btn btn-primary btn-lg flex-fill fw-semibold" id="listingSubmitBtn">
                                    <span class="btn-text">Publish Listing</span>
                                    <span class="spinner-border spinner-border-sm ms-2 hidden" id="listingSpinner"></span>
                                </button>
                                <button type="button" class="btn btn-outline-light btn-lg" onclick="document.getElementById('listingForm').reset()">
                                    <i class="fas fa-undo me-1"></i>Clear
                                </button>
                            </div>
                        </form>
                        ` : `
                        <div class="text-center py-4">
                            <i class="fas fa-info-circle fa-3x text-accent mb-3"></i>
                            <h4 class="text-white fw-bold mb-2">Read-only access</h4>
                            <p class="text-white-50">Your role (${app.user?.role || 'unknown'}) cannot create listings. Only sellers and brokers can publish companies for sale. Browse the marketplace to discover existing opportunities instead.</p>
                            <button class="btn btn-primary mt-2" onclick="app.showScreen('marketplace')"><i class="fas fa-store me-1"></i>Browse Marketplace</button>
                        </div>
                        `}
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="glass-card p-4 mb-4">
                        <h5 class="text-white fw-bold mb-3"><i class="fas fa-list me-2"></i>Your Listings</h5>
                        ${userListings.length > 0 ? userListings.map(l => `
                            <div class="p-3 mb-2 rounded-3" style="background: rgba(255,255,255,0.05);">
                                <div class="d-flex justify-content-between align-items-start">
                                    <div>
                                        <h6 class="text-white mb-1">${Utils.sanitize(l.companyName)}</h6>
                                        <span class="badge bg-info">${l.sector}</span>
                                        <span class="badge bg-${l.status === 'active' ? 'success' : 'secondary'} ms-1">${l.status}</span>
                                    </div>
                                    <button class="btn btn-sm btn-danger" onclick="app.deleteListing('${l.id}')" title="Delete">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </div>
                                <p class="text-white-50 small mb-0 mt-1">${Utils.formatCurrency(l.valuation)}</p>
                            </div>
                        `).join('') : '<p class="text-white-50">You have no listings yet.</p>'}
                    </div>
                    <div class="glass-card p-4">
                        <h5 class="text-white fw-bold mb-2"><i class="fas fa-calculator me-2"></i>Fee Calculator</h5>
                        <p class="text-white-50 small">Platform fee: 2% (min GHS 5,000)</p>
                        <div class="input-group mb-2">
                            <input type="number" class="form-control" id="feeCalcInput" placeholder="Deal amount" min="0">
                            <button class="btn btn-accent" style="background: var(--accent); color: white;" onclick="app.calculateFee()">Calculate</button>
                        </div>
                        <div id="feeResult" class="text-white small"></div>
                    </div>
                </div>
            </div>
        `;
    }

    attachEvents() {
        const form = this.querySelector('.listing-form');
        if (form) {
            form.addEventListener('submit', async (e) => {
                e.preventDefault();
                if (!form.checkValidity()) { form.classList.add('was-validated'); Toast.show('Please fix the errors in the form.', 'error'); return; }
                const companyName = document.getElementById('companyName')?.value.trim();
                const sector = document.getElementById('listingSector')?.value;
                const revenue = parseFloat(document.getElementById('listingRevenue')?.value) || 0;
                const valuation = parseFloat(document.getElementById('listingValuation')?.value) || 0;
                const description = document.getElementById('listingDescription')?.value.trim();
                // M2: isDuplicate is now async (server check). The id is now
                // assigned by the server on insert (omitted from the request).
                if (await ListingStore.isDuplicate(companyName)) { Toast.show('A listing with this company name already exists.', 'error'); return; }
                // Bug 045 fix: validate BEFORE showing spinner (was showing spinner then validating)
                if (valuation < 1) { Toast.show('Valuation must be at least GHS 1.', 'error'); return; }
                if (revenue < 0) { Toast.show('Revenue cannot be negative.', 'error'); return; }
                const spinner = document.getElementById('listingSpinner');
                const btnText = document.querySelector('#listingSubmitBtn .btn-text');
                const submitBtn = document.getElementById('listingSubmitBtn');
                // Bug 041 fix: disable button during async to prevent double-submit
                if (submitBtn) submitBtn.disabled = true;
                if (spinner) spinner.classList.remove('hidden');
                if (btnText) btnText.textContent = 'Publishing...';
                try {
                    const listing = { companyName: companyName, sector, revenue: Math.max(0, revenue), valuation: Math.max(1, valuation), description: description, status: 'active' };
                    await ListingStore.save(listing);
                    if (this._clearDraft) this._clearDraft();
                    form.reset(); form.classList.remove('was-validated');
                    Toast.show('Listing published successfully!', 'success');
                    app.announceToScreenReader('Your company listing has been published');
                    this.render(); this.attachEvents();
                } catch (err) {
                    Toast.show(err?.message || 'Failed to publish listing.', 'error');
                } finally {
                    // Bug 004 fix: re-enable button and hide spinner even on error
                    if (submitBtn) submitBtn.disabled = false;
                    if (spinner) spinner.classList.add('hidden');
                    if (btnText) btnText.textContent = 'Publish Listing';
                }
            });
        }
    }
}

class MarketplaceComponent extends BaseComponent {
    render() {
        const ips = IPStore.getAll();
        const sectors = [...new Set(ips.map(ip => ip.sector))];
        const types = [...new Set(ips.map(ip => ip.type))];
        this.innerHTML = `
            <div class="mb-4">
                <nav class="breadcrumb-nav" aria-label="breadcrumb">
                    <a href="#" onclick="app.showScreen('dashboard'); return false;">Dashboard</a>
                    <span class="separator">/</span>
                    <span>IP Marketplace</span>
                </nav>
                <h2 class="text-white fw-bold"><i class="fas fa-lightbulb me-2"></i>IP Marketplace</h2>
                <p class="text-white-50">Browse patents, software, and trademarks for sale</p>
            </div>
            <div class="row mb-4">
                <div class="col-lg-4 mb-3">
                    <div class="search-box">
                        <i class="fas fa-search"></i>
                        <input type="text" class="form-control" id="marketSearch" placeholder="Search IPs (Ctrl+K)..." autocomplete="off">
                    </div>
                </div>
                <div class="col-lg-3 mb-3">
                    <select class="form-select" id="marketSectorFilter">
                        <option value="">All Sectors</option>
                        ${sectors.map(s => `<option value="${s}">${s}</option>`).join('')}
                    </select>
                </div>
                <div class="col-lg-3 mb-3">
                    <select class="form-select" id="marketTypeFilter">
                        <option value="">All Types</option>
                        ${types.map(t => `<option value="${t}">${t}</option>`).join('')}
                    </select>
                </div>
                <div class="col-lg-2 mb-3">
                    <button class="btn btn-outline-light w-100" id="marketResetFilters"><i class="fas fa-undo me-1"></i>Reset</button>
                </div>
            </div>
            <div class="market-grid fade-in" id="ipGrid">${this.renderIPCards(ips)}</div>
            <div id="marketEmptyState" class="empty-state hidden"><i class="fas fa-search"></i><h5 class="text-white">No IPs Found</h5><p>Try adjusting your search or filters</p></div>
        `;
    }

    renderIPCards(ips) {
        if (ips.length === 0) return '';
        return ips.map(ip => `
            <div class="glass-card p-4 card-modern">
                <div class="d-flex justify-content-between align-items-start mb-3">
                    <h5 class="text-white fw-bold mb-0">${Utils.sanitize(ip.name)}</h5>
                    <span class="badge bg-${ip.status === 'available' ? 'success' : 'secondary'}">${ip.status}</span>
                </div>
                <div class="mb-3"><span class="badge bg-primary me-1">${ip.type}</span><span class="badge bg-info">${ip.sector}</span></div>
                <p class="text-white-50 small mb-3">${Utils.sanitize(ip.description)}</p>
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <div class="h4 text-warning mb-0 fw-bold">${Utils.formatCurrency(ip.price)}</div>
                    <small class="text-white-50">by ${Utils.sanitize(ip.owner)}</small>
                </div>
                <div class="d-flex gap-2">
                    <button class="btn btn-outline-light flex-fill" onclick="app.initiateContact('${ip.id}')"><i class="fas fa-comment me-1"></i>Contact Seller</button>
                    <button class="btn btn-primary flex-fill" onclick="app.makeOffer('${ip.id}')"><i class="fas fa-tag me-1"></i>Make Offer</button>
                </div>
            </div>
        `).join('');
    }

    attachEvents() {
        const searchInput = this.querySelector('#marketSearch');
        const sectorFilter = this.querySelector('#marketSectorFilter');
        const typeFilter = this.querySelector('#marketTypeFilter');
        const resetBtn = this.querySelector('#marketResetFilters');
        const grid = this.querySelector('#ipGrid');
        const emptyState = this.querySelector('#marketEmptyState');
        const filterIPs = Utils.debounce(async () => {
            const query = searchInput?.value || '';
            const sector = sectorFilter?.value || '';
            const type = typeFilter?.value || '';
            // M2: IPStore.search now returns a Promise (server-backed).
            const results = await IPStore.search(query, { sector, type });
            if (grid) grid.innerHTML = this.renderIPCards(results);
            if (emptyState) emptyState.classList.toggle('hidden', results.length > 0);
            if (grid) grid.classList.toggle('hidden', results.length === 0);
        }, 300);
        searchInput?.addEventListener('input', filterIPs);
        sectorFilter?.addEventListener('change', filterIPs);
        typeFilter?.addEventListener('change', filterIPs);
        resetBtn?.addEventListener('click', () => { if (searchInput) searchInput.value = ''; if (sectorFilter) sectorFilter.value = ''; if (typeFilter) typeFilter.value = ''; filterIPs(); });
    }
}

class ChatComponent extends BaseComponent {
    render() {
        if (!app.user) return;
        const conversations = ChatStore.getConversations(app.user.id);
        const activeConv = this._activeConv || (conversations[0]?.id || null);
        const activeConversation = conversations.find(c => c.id === activeConv);
        this.innerHTML = `
            <div class="mb-4">
                <nav class="breadcrumb-nav" aria-label="breadcrumb">
                    <a href="#" onclick="app.showScreen('dashboard'); return false;">Dashboard</a>
                    <span class="separator">/</span>
                    <span>Messages</span>
                </nav>
                <h2 class="text-white fw-bold"><i class="fas fa-comments me-2"></i>Messages</h2>
            </div>
            <div class="row h-100" style="min-height: 500px;">
                <div class="col-md-4 mb-4">
                    <div class="glass-card p-3 h-100 d-flex flex-column">
                        <h5 class="text-white fw-bold mb-3">Conversations</h5>
                        <div class="list-group list-group-flush flex-grow-1 overflow-auto" id="conversationList">
                            ${conversations.map(conv => `
                                <div class="list-group-item d-flex align-items-center cursor-pointer ${conv.id === activeConv ? 'active' : ''}" 
                                     style="background: ${conv.id === activeConv ? 'rgba(255,255,255,0.15)' : 'transparent'}; border: none; color: white;"
                                     onclick="app.selectConversation('${conv.id}')">
                                    <i class="fas ${/^fa-[\w-]+$/.test(conv.avatar) ? conv.avatar : 'fa-user'} text-${['primary','success','info','warning','danger'].includes(conv.color) ? conv.color : 'primary'} me-3 fs-4"></i>  <!-- JS-044 fix: whitelist avatar + color to prevent class-attribute XSS -->
                                    <div class="flex-grow-1">
                                        <div class="fw-medium">${Utils.sanitize(conv.name)}</div>
                                        <small class="text-white-50">${Utils.sanitize(conv.lastMessage?.substring(0, 30) || 'No messages yet')}</small>
                                    </div>
                                    ${conv.unreadCount > 0 ? `<span class="badge bg-primary ms-auto">${conv.unreadCount}</span>` : ''}
                                </div>
                            `).join('') || '<p class="text-white-50">No conversations yet</p>'}
                        </div>
                    </div>
                </div>
                <div class="col-md-8">
                    <div class="glass-card h-100 d-flex flex-column">
                        <div class="p-3 border-bottom border-white border-opacity-25 d-flex justify-content-between align-items-center">
                            <h5 class="text-white mb-0">${activeConversation ? `<i class="fas ${/^fa-[\w-]+$/.test(activeConversation.avatar) ? activeConversation.avatar : 'fa-user'} text-${['primary','success','info','warning','danger'].includes(activeConversation.color) ? activeConversation.color : 'primary'} me-2"></i>${Utils.sanitize(activeConversation.name)}` : 'Select a conversation'}</h5>  <!-- JS-044 fix: same whitelist on activeConversation -->
                            ${activeConversation ? `<span class="badge bg-success"><i class="fas fa-circle me-1" style="font-size: 0.5rem;"></i>Online</span>` : ''}
                        </div>
                        <div class="chat-bubble flex-grow-1 p-4 overflow-auto" id="chatMessages">
                            ${activeConversation ? activeConversation.messages.map(msg => `
                                <div class="chat-message ${msg.sender === app.user.email ? 'sent' : 'received'}">
                                    ${Utils.sanitize(msg.text)}
                                    <span class="timestamp">${Utils.formatDate(msg.timestamp)}</span>
                                </div>
                            `).join('') : '<div class="empty-state"><i class="fas fa-comments"></i><p>Select a conversation to start messaging</p></div>'}
                        </div>
                        <div class="p-3 border-top border-white border-opacity-25">
                            <div class="input-group">
                                <input class="form-control" id="msgInput" placeholder="Type message..." aria-label="Type your message" maxlength="1000">
                                <button class="btn btn-primary" onclick="app.sendMessage()" aria-label="Send message"><i class="fas fa-paper-plane"></i></button>
                            </div>
                            <small class="text-white-50 d-block mt-1"><span id="msgCount">0</span>/1000</small>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    attachEvents() {
        const msgInput = document.getElementById('msgInput');
        const msgCount = document.getElementById('msgCount');
        if (msgInput && msgCount) {
            msgInput.addEventListener('input', () => { msgCount.textContent = msgInput.value.length; });
            msgInput.addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); app.sendMessage(); } });
        }
    }
}

class DocGenComponent extends BaseComponent {
    render() {
        const templates = DocTemplates.getAll();
        const selected = this._selectedTemplate;
        this.innerHTML = `
            <div class="mb-4">
                <nav class="breadcrumb-nav" aria-label="breadcrumb">
                    <a href="#" onclick="app.showScreen('dashboard'); return false;">Dashboard</a>
                    <span class="separator">/</span>
                    <span>Document Generator</span>
                </nav>
                <h2 class="text-white fw-bold"><i class="fas fa-file-contract me-2"></i>Document Generator</h2>
                <p class="text-white-50">Generate legally compliant documents for your deals</p>
            </div>
            <div class="row justify-content-center">
                <div class="col-lg-10">
                    <div class="glass-card p-5">
                        <h4 class="text-white fw-bold mb-4">Select Template</h4>
                        <div class="row mb-4">
                            ${templates.map(t => `
                                <div class="col-md-4 mb-4">
                                    <div class="glass-card p-4 text-center cursor-pointer template-card ${selected === t.key ? 'border-accent' : ''}" 
                                         data-template="${t.key}" onclick="app.selectTemplate('${t.key}')"
                                         style="border: 2px solid ${selected === t.key ? 'var(--accent)' : 'transparent'}; transition: all 0.3s;">
                                        <i class="fas fa-${t.icon} fa-3x mb-3 text-${t.color}"></i>
                                        <h5 class="text-white">${t.name}</h5>
                                    </div>
                                </div>
                            `).join('')}
                        </div>
                        ${selected ? `
                            <div class="glass-card p-4 mb-4">
                                <h5 class="text-white fw-bold mb-3">Fill Details</h5>
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Party A Name</label>
                                        <input type="text" class="form-control" id="docPartyA" placeholder="Enter name">
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Party B Name</label>
                                        <input type="text" class="form-control" id="docPartyB" placeholder="Enter name">
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Amount (GHS)</label>
                                        <input type="number" class="form-control" id="docAmount" min="0" placeholder="Enter amount">
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Additional Details</label>
                                        <input type="text" class="form-control" id="docDetails" placeholder="Assets, conditions, etc.">
                                    </div>
                                </div>
                            </div>
                            <div class="mb-4">
                                <label class="form-label text-white fw-bold">Document Preview</label>
                                <div class="doc-preview" id="docPreview" style="min-height: 200px;"><em class="text-muted">Fill in details and click Preview to generate...</em></div>
                            </div>
                            <div class="d-flex gap-3">
                                <button class="btn btn-success btn-lg flex-fill" id="generateBtn" onclick="app.generateDocument()">
                                    <span class="btn-text"><i class="fas fa-magic me-2"></i>Generate & Download</span>
                                    <span class="spinner-border spinner-border-sm ms-2 hidden" id="docSpinner"></span>
                                </button>
                                <button class="btn btn-outline-light btn-lg" onclick="app.previewDocument()"><i class="fas fa-eye me-2"></i>Preview</button>
                            </div>
                        ` : '<p class="text-white-50">Select a template above to get started.</p>'}
                    </div>
                </div>
            </div>
        `;
    }

    attachEvents() {
        document.querySelectorAll('.template-card').forEach(card => {
            card.addEventListener('click', () => {
                document.querySelectorAll('.template-card').forEach(c => c.style.borderColor = 'transparent');
                card.style.borderColor = 'var(--accent)';
            });
        });
    }
}

class ESignComponent extends BaseComponent {
    render() {
        if (!app.user) return;
        const kycStatus = KYC.getStatus(app.user.id);
        const canSign = kycStatus.status === KYC.STATUS.VERIFIED;
        const documents = ESignStore.getAll(app.user.id);
        // M3 RBAC: only lawyers can sign as witness. UI hint; server enforces.
        const isLawyer = app.user.role === 'lawyer' || app.user.role === 'admin';  // Bug 068 fix
        this.innerHTML = `
            <div class="mb-4">
                <nav class="breadcrumb-nav" aria-label="breadcrumb">
                    <a href="#" onclick="app.showScreen('dashboard'); return false;">Dashboard</a>
                    <span class="separator">/</span>
                    <span>E-Sign Portal</span>
                </nav>
                <h2 class="text-white fw-bold"><i class="fas fa-signature me-2"></i>E-Sign Portal</h2>
                <p class="text-white-50">Electronically sign and manage your legal documents</p>
            </div>
            <div class="row">
                <div class="col-lg-8 mb-4">
                    <div class="glass-card p-5">
                        ${!canSign ? `
                            <div class="alert alert-warning mb-4" role="alert">
                                <i class="fas fa-exclamation-triangle me-2"></i>
                                <strong>KYC Required:</strong> Complete KYC verification before signing documents.
                                <button class="btn btn-sm btn-warning ms-3" onclick="app.initiateKYC()">Complete KYC</button>
                            </div>
                        ` : ''}
                        <h4 class="text-white fw-bold mb-3">Documents</h4>
                        <div class="list-group mb-4">
                            ${documents.map(doc => `
                                <div class="list-group-item d-flex justify-content-between align-items-center" style="background: rgba(255,255,255,0.05); border-color: rgba(255,255,255,0.1);">
                                    <div>
                                        <h6 class="text-white mb-1">${Utils.sanitize(doc.title)}</h6>
                                        <small class="text-white-50">
                                            ${doc.status === 'signed'
                                                ? `<i class="fas fa-check-circle text-success me-1"></i>Signed on ${Utils.formatDate(doc.signedAt)}`
                                                : `<i class="fas fa-clock text-warning me-1"></i>Pending signature`
                                            }
                                            ${doc.witnessSignedAt ? `<br><i class="fas fa-stamp text-info me-1"></i>Witnessed by ${Utils.sanitize(doc.witnessEmail || 'a lawyer')} on ${Utils.formatDate(doc.witnessSignedAt)}` : ''}
                                            ${doc.documentId ? `<br><i class="fas fa-paperclip text-accent me-1"></i><a href="${API.documents.downloadUrl(doc.documentId)}" target="_blank" class="text-white-50 text-decoration-none">View attached file</a>` : ''}
                                        </small>
                                    </div>
                                    <div class="d-flex gap-2">
                                        ${doc.status === 'pending' && canSign ? `
                                            <button class="btn btn-success btn-sm" onclick="app.signDocument('${doc.id}')"><i class="fas fa-pen me-1"></i>Sign</button>
                                        ` : doc.status === 'pending' ? `
                                            <button class="btn btn-secondary btn-sm" disabled title="Complete KYC to sign"><i class="fas fa-lock me-1"></i>Locked</button>
                                        ` : ''}
                                        <button class="btn btn-outline-light btn-sm" onclick="app.viewAuditTrail('${doc.id}')"><i class="fas fa-list me-1"></i>Audit</button>
                                    </div>
                                </div>
                            `).join('') || '<p class="text-white-50">No documents found.</p>'}
                        </div>
                        <div class="d-flex gap-3">
                            <button class="btn btn-success btn-lg flex-fill" onclick="app.uploadEsignDocument()"><i class="fas fa-upload me-2"></i>Upload Document for Signing</button>
                            <button class="btn btn-outline-light btn-lg flex-fill" onclick="app.viewAuditTrail('esign')"><i class="fas fa-history me-2"></i>View Audit Trail</button>
                        </div>
                    </div>
                </div>
                ${isLawyer ? `
                <div class="col-lg-12 mb-4">
                    <div class="glass-card p-5">
                        <h4 class="text-white fw-bold mb-3"><i class="fas fa-gavel me-2"></i>Documents Awaiting Witness (Lawyer Only)</h4>
                        <p class="text-white-50 small mb-3">These are documents owned by other users that have not yet been witness-signed. As a licensed lawyer, you can co-sign any of them as a witness.</p>
                        <div class="list-group" id="witnessAwaitingList">
                            <p class="text-white-50">Loading...</p>
                        </div>
                    </div>
                </div>
                ` : ''}
                <div class="col-lg-4">
                    <div class="glass-card p-4 mb-4">
                        <h5 class="text-white fw-bold mb-3"><i class="fas fa-id-card me-2"></i>KYC Status</h5>
                        <div class="kyc-badge ${kycStatus.status} mb-3">
                            <i class="fas fa-${kycStatus.status === 'verified' ? 'check-circle' : kycStatus.status === 'pending' ? 'clock' : 'times-circle'}"></i>
                            ${kycStatus.status.charAt(0).toUpperCase() + kycStatus.status.slice(1)}
                        </div>
                        <!-- M5: uploaded KYC documents with download links -->
                        ${(kycStatus.documents || []).length > 0 ? `
                            <h6 class="text-white small mb-2"><i class="fas fa-paperclip me-1"></i>Documents</h6>
                            <ul class="list-unstyled mb-3 small">
                                ${kycStatus.documents.map(d => `
                                    <li class="mb-1">
                                        <a href="${d.downloadUrl && d.downloadUrl.startsWith('/') ? d.downloadUrl : '#'}" target="_blank" class="text-white-50 text-decoration-none">  <!-- JS-043 fix: validate URL starts with / to prevent javascript: XSS -->
                                            <!-- UI-02 fix: proper icon mapping for PDF, PNG/JPEG, and fallback -->
                                            <i class="fas fa-file-${d.mimeType === 'application/pdf' ? 'pdf' : d.mimeType === 'image/png' || d.mimeType === 'image/jpeg' ? 'image' : 'alt'} me-1"></i>
                                            ${Utils.sanitize(d.originalFilename)}
                                        </a>
                                    </li>
                                `).join('')}
                            </ul>
                        ` : '<p class="text-white-50 small mb-3">No documents uploaded yet.</p>'}
                        ${kycStatus.status !== 'verified' ? `
                            <div class="mb-2">
                                <label class="form-label text-white-50 small mb-1">Upload Document (PDF/PNG/JPEG, max 10MB)</label>
                                <input type="file" class="form-control form-control-sm" id="esignKycFileInput"
                                       accept=".pdf,.png,.jpg,.jpeg,application/pdf,image/png,image/jpeg"
                                       onchange="app.handleKycFileUpload(event)">
                            </div>
                            <button class="btn btn-sm btn-warning w-100" onclick="app.initiateKYC()"><i class="fas fa-paper-plane me-1"></i>Submit for Verification</button>
                        ` : ''}
                    </div>
                    <div class="glass-card p-4">
                        <h5 class="text-white fw-bold mb-3"><i class="fas fa-flag me-2"></i>GRA Compliance</h5>
                        <div class="text-success mb-2"><i class="fas fa-check-circle me-1"></i>Tax Clearance: Valid</div>
                        <div class="text-success mb-2"><i class="fas fa-check-circle me-1"></i>VAT Registration: Active</div>
                        <div class="text-success"><i class="fas fa-check-circle me-1"></i>NHIL: Compliant</div>
                        <small class="text-white-50 d-block mt-2">Last checked: ${Utils.formatDate(new Date())}</small>
                    </div>
                </div>
            </div>
        `;
    }

    /**
     * M3 RBAC: if the current user is a lawyer, asynchronously load the
     * list of documents awaiting witness signature and render buttons to
     * sign them. Non-lawyers see nothing (the section isn't rendered at all
     * in render()).
     */
    async attachEvents() {
        if (!app.user || (app.user.role !== 'lawyer' && app.user.role !== 'admin')) return;  // Bug 068 fix
        const list = this.querySelector('#witnessAwaitingList');
        if (!list) return;
        try {
            const resp = await API.esigns.listAwaitingWitness();
            const docs = resp.documents || [];
            if (docs.length === 0) {
                list.innerHTML = '<p class="text-white-50">No documents are currently awaiting a witness signature.</p>';
                return;
            }
            list.innerHTML = docs.map(doc => `
                <div class="list-group-item d-flex justify-content-between align-items-center" style="background: rgba(255,255,255,0.05); border-color: rgba(255,255,255,0.1);">
                    <div>
                        <h6 class="text-white mb-1">${Utils.sanitize(doc.title)}</h6>
                        <small class="text-white-50">
                            <i class="fas fa-user me-1"></i>Owner: ${Utils.sanitize(doc.userId)}
                            ${doc.status === 'signed' ? `<br><i class="fas fa-check-circle text-success me-1"></i>Owner signed on ${Utils.formatDate(doc.signedAt)}` : `<br><i class="fas fa-clock text-warning me-1"></i>Awaiting owner signature`}
                        </small>
                    </div>
                    <button class="btn btn-info btn-sm" onclick="app.signAsWitness('${doc.id}')"><i class="fas fa-gavel me-1"></i>Sign as Witness</button>
                </div>
            `).join('');
        } catch (err) {
            list.innerHTML = '<p class="text-warning">Failed to load documents awaiting witness.</p>';
            console.warn('ESign attachEvents listAwaitingWitness failed:', err);
        }
    }
}

class IntegrationComponent extends BaseComponent {
    render() {
        if (!app.user) return;
        const data = IntegrationStore.getForUser(app.user.id);
        const tasks = data.tasks || [];
        this.innerHTML = `
            <div class="mb-4">
                <nav class="breadcrumb-nav" aria-label="breadcrumb">
                    <a href="#" onclick="app.showScreen('dashboard'); return false;">Dashboard</a>
                    <span class="separator">/</span>
                    <span>Post-Merger Integration</span>
                </nav>
                <h2 class="text-white fw-bold"><i class="fas fa-server me-2"></i>Post-Merger Integration</h2>
                <p class="text-white-50">Track your merger integration progress</p>
            </div>
            <div class="row">
                ${tasks.map(task => `
                    <div class="col-lg-4 mb-4">
                        <div class="glass-card p-4 card-modern">
                            <div class="d-flex align-items-center mb-3">
                                <i class="fas fa-${task.category === 'it' ? 'server' : task.category === 'users' ? 'users' : task.category === 'assets' ? 'database' : task.category === 'data' ? 'hdd' : 'user-plus'} fa-2x me-3 text-${task.progress >= 80 ? 'success' : task.progress >= 50 ? 'primary' : 'warning'}"></i>
                                <h5 class="text-white mb-0">${Utils.sanitize(task.name)}</h5>
                            </div>
                            <div class="d-flex justify-content-between mb-2">
                                <span class="text-white-50">Progress</span>
                                <span class="text-white fw-bold">${task.progress}%</span>
                            </div>
                            <div class="progress mb-3">
                                <div class="progress-bar bg-${task.progress >= 80 ? 'success' : task.progress >= 50 ? 'primary' : 'warning'}" style="width: ${task.progress}%">${task.progress}%</div>
                            </div>
                            <div class="d-flex justify-content-between">
                                <small class="text-white-50">${task.status === 'completed' ? 'Complete' : 'In Progress'}</small>
                                <small class="text-white-50">${task.status === 'completed' ? 'Done' : 'ETA: 2 weeks'}</small>
                            </div>
                        </div>
                    </div>
                `).join('')}
            </div>
            <div class="row mt-2">
                <div class="col-12">
                    <div class="glass-card p-4">
                        <h5 class="text-white fw-bold mb-3"><i class="fas fa-tasks me-2"></i>Integration Checklist</h5>
                        <div class="list-group">
                            ${[
                                { task: 'Transfer domain ownership', done: true },
                                { task: 'Migrate user databases', done: true },
                                { task: 'Consolidate cloud infrastructure', done: false },
                                { task: 'Merge code repositories', done: false },
                                { task: 'Update regulatory filings', done: false },
                                { task: 'Notify stakeholders', done: false }
                            ].map((item, idx) => `
                                <label class="list-group-item d-flex align-items-center cursor-pointer" style="background: rgba(255,255,255,0.05); border-color: rgba(255,255,255,0.1);">
                                    <input type="checkbox" class="form-check-input me-3" ${item.done ? 'checked' : ''} onchange="app.updateChecklist(${idx}, this.checked)">
                                    <span class="text-white ${item.done ? 'text-decoration-line-through text-white-50' : ''}">${item.task}</span>
                                </label>
                            `).join('')}
                        </div>
                    </div>
                </div>
            </div>
        `;
    }
}

// ===== M4: BILLING COMPONENT =====
class BillingComponent extends BaseComponent {
    render() {
        if (!app.user) return;
        // The actual plan data is loaded asynchronously in attachEvents() —
        // render() just sets up the skeleton. This matches the pattern used
        // by ESignComponent for the witness-awaiting list.
        this.innerHTML = `
            <div class="mb-4">
                <nav class="breadcrumb-nav" aria-label="breadcrumb">
                    <a href="#" onclick="app.showScreen('dashboard'); return false;">Dashboard</a>
                    <span class="separator">/</span>
                    <span>Billing &amp; Plans</span>
                </nav>
                <h2 class="text-white fw-bold"><i class="fas fa-credit-card me-2"></i>Billing &amp; Plans</h2>
                <p class="text-white-50">Manage your Busifirm subscription</p>
            </div>
            <div id="billingCurrentPlan" class="mb-4">
                <div class="glass-card p-4">
                    <p class="text-white-50">Loading your current plan...</p>
                </div>
            </div>
            <div id="billingPlansGrid" class="row">
                <div class="col-12 text-center py-5">
                    <div class="spinner-border text-accent" role="status">
                        <span class="visually-hidden">Loading plans...</span>
                    </div>
                </div>
            </div>
        `;
    }

    async attachEvents() {
        if (!app.user) return;
        try {
            // Load current plan + plan catalog in parallel.
            const [meResp, plansResp] = await Promise.all([
                API.billing.me(),
                API.billing.plans(),
            ]);
            this._currentSubscription = meResp.subscription;
            this._renderCurrentPlan(meResp.plan, meResp.subscription);
            this._renderPlansGrid(plansResp.plans, meResp.plan?.code, meResp.subscription);
        } catch (err) {
            const target = this.querySelector('#billingCurrentPlan');
            if (target) target.innerHTML = `
                <div class="glass-card p-4">
                    <p class="text-warning mb-0"><i class="fas fa-exclamation-triangle me-2"></i>Failed to load billing information. ${Utils.sanitize(err?.message || '')}</p>
                </div>`;
        }
    }

    _renderCurrentPlan(plan, subscription) {
        const target = this.querySelector('#billingCurrentPlan');
        if (!target) return;
        const isPaid = plan && plan.priceKobo > 0;
        const isTrialing = subscription && subscription.status === 'trialing';
        const trialEndsAt = subscription && subscription.trialEndsAt
            ? subscription.trialEndsAt
            : (isTrialing && subscription && subscription.nextBillingAt ? subscription.nextBillingAt : null);
        target.innerHTML = `
            <div class="glass-card p-4">
                <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">
                    <div>
                        <!-- UI-07 fix: changed bg-info to bg-primary for better contrast on dark theme -->
                        <!-- UI-08 fix: changed text-warning to fw-semibold for better readability -->
                        <h4 class="text-white fw-bold mb-1">${Utils.sanitize(plan?.name || 'Free')}
                            ${isTrialing ? '<span class="badge bg-primary text-white ms-2">Trial</span>' : ''}
                        </h4>
                        <p class="text-white-50 mb-0">
                            ${isPaid
                                ? `${Utils.formatCurrency(plan.priceGhs)} / ${plan.billingInterval === 'yearly' ? 'year' : 'month'}`
                                : 'No charge'}
                        </p>
                        ${isTrialing && trialEndsAt
                            ? `<small class="text-warning fw-semibold">Trial ends: ${Utils.formatDate(trialEndsAt)} — subscribe before then to keep access.</small>`
                            : (subscription && subscription.nextBillingAt
                                ? `<small class="text-white-50">Next billing: ${Utils.formatDate(subscription.nextBillingAt)}</small>`
                                : '')}
                        ${subscription && subscription.pendingPlanId
                            ? `<small class="text-warning fw-semibold d-block"><i class="fas fa-clock me-1"></i>Downgrade scheduled for next billing date.</small>`
                            : ''}
                        ${subscription && subscription.status === 'cancelled'
                            ? `<small class="text-warning fw-semibold">Cancelled — access ends on ${Utils.formatDate(subscription.nextBillingAt || subscription.cancelledAt)}</small>`
                            : ''}
                    </div>
                    <div>
                        <!-- UI-18 fix: changed btn-outline-light to btn-outline-danger for destructive action -->
                        ${isPaid && subscription && subscription.status === 'active'
                            ? `<button class="btn btn-outline-danger" onclick="app.cancelBilling()"><i class="fas fa-times me-1"></i>Cancel Subscription</button>`
                            : ''}
                    </div>
                </div>
            </div>
        `;
    }

    _renderPlansGrid(plans, currentPlanCode, subscription = null) {
        const target = this.querySelector('#billingPlansGrid');
        if (!target) return;
        if (!plans || plans.length === 0) {
            target.innerHTML = '<p class="text-white-50">No plans available.</p>';
            return;
        }
        // UX-02 fix: if the user is currently trialing or has an active sub,
        // hide the "Start Trial" button — they can't trial while already
        // on an active/trialing plan.
        const isTrialingOrActive = subscription && (subscription.status === 'trialing' || subscription.status === 'active');
        // UX-01 fix: if the user is trialing, the downgrade date should be
        // the trial end date, not next_billing_at (which may be null for
        // trials per BL-24 fix).
        const trialEndsAt = subscription && subscription.trialEndsAt ? subscription.trialEndsAt : null;
        target.innerHTML = plans.map(plan => {
            const isCurrent = plan.code === currentPlanCode;
            const isFree = plan.priceKobo === 0;
            const isPopular = plan.isPopular || plan.code === 'pro';  // Bug 095 fix: read from plan data, fallback to code
            // M4 polish: button logic.
            //   - Current plan → green "Current Plan" (disabled)
            //   - Free plan when not current → "Downgrade" (uses changePlan)
            //   - Paid plan, user on free → TWO buttons: "Start 14-day Trial" + "Upgrade Now"
            //   - Paid plan, user on paid → "Change Plan" (uses changePlan with proration preview)
            // UX-02 fix: hide Trial button if user is already trialing or active.
            let buttons;
            if (isCurrent) {
                buttons = '<button class="btn btn-success w-100" disabled><i class="fas fa-check me-1"></i>Current Plan</button>';
            } else if (isFree) {
                // UX-01 fix: if the user is trialing, show the trial end date
                // as the downgrade date instead of a generic message.
                const downgradeHint = isTrialingOrActive && trialEndsAt
                    ? `<small class="d-block text-white-50 mt-1">Takes effect when your trial ends (${Utils.formatDate(trialEndsAt)}).</small>`
                    : '';
                // UI-32 fix: standardized verb to "Change to" (was "Switch to" for Free, "Change to" for paid).
                // JS-025 fix: was previously an HTML-style `<!-- ... -->` comment which only parses under
                // V8/SpiderMonkey's web-compat hack and breaks under esbuild/swc/TypeScript.
                buttons = `<button class="btn btn-outline-light w-100" onclick="app.changePlan('${plan.code}')"><i class="fas fa-arrow-down me-1"></i>Change to Free</button>${downgradeHint}`;
            } else {
                const trialBtn = isTrialingOrActive
                    ? '' // UX-02: hide trial button for active/trialing users
                    : `<button class="btn btn-outline-info w-100 mb-2" onclick="app.startTrial('${plan.code}')"><i class="fas fa-clock me-1"></i>Start 14-day Trial</button>`;
                const upgradeBtn = `<button class="btn btn-primary w-100" onclick="app.changePlan('${plan.code}')"><i class="fas fa-exchange-alt me-1"></i>Change to ${Utils.sanitize(plan.name)}</button>`;
                buttons = trialBtn + upgradeBtn;
            }
            return `
                <div class="col-lg-4 mb-4">
                    <!-- UI-06 fix: added d-flex flex-column + mt-auto wrapper for buttons -->
                    <div class="glass-card p-4 h-100 d-flex flex-column ${isPopular ? 'border-accent' : ''}" style="${isPopular ? 'border: 2px solid var(--accent);' : ''}">
                        <!-- UI-27 fix: min-height on badge area so plan names align across cards -->
                        <div style="min-height: 28px;">
                            ${isPopular ? '<span class="badge bg-accent text-white mb-2">Most Popular</span>' : ''}
                        </div>
                        <h4 class="text-white fw-bold mb-1">${Utils.sanitize(plan.name)}</h4>
                        <div class="mb-3">
                            <span class="text-white fs-3 fw-bold">${isFree ? 'Free' : Utils.formatCurrency(plan.priceGhs)}</span>
                            ${!isFree ? `<span class="text-white-50">/${plan.billingInterval === 'yearly' ? 'yr' : 'mo'}</span>` : ''}
                        </div>
                        <ul class="list-unstyled mb-4">
                            <!-- UI-17 fix: changed text-white-50 to text-white-75 for WCAG AA contrast -->
                            ${plan.features.map(f => `<li class="mb-2 text-white-75"><i class="fas fa-check text-success me-2"></i>${Utils.sanitize(f)}</li>`).join('')}
                        </ul>
                        <div class="mt-auto">${buttons}</div>
                    </div>
                </div>
            `;
        }).join('');
    }
}

// ===== M6: ADMIN COMPONENT =====
class AdminComponent extends BaseComponent {
    render() {
        if (!app.user || app.user.role !== 'admin') {
            this.innerHTML = '<div class="glass-card p-5 text-center"><h3 class="text-white">Admin access required</h3></div>';
            return;
        }
        this.innerHTML = `
            <div class="mb-4">
                <!-- UI-25 fix: added a visible Back to Dashboard button for mobile users -->
                <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-2">
                    <nav class="breadcrumb-nav" aria-label="breadcrumb">
                        <a href="#" onclick="app.showScreen('dashboard'); return false;">Dashboard</a>
                        <span class="separator">/</span>
                        <span>Admin Panel</span>
                    </nav>
                    <button class="btn btn-sm btn-outline-light" onclick="app.showScreen('dashboard')">
                        <i class="fas fa-arrow-left me-1"></i>Back to Dashboard
                    </button>
                </div>
                <h2 class="text-white fw-bold"><i class="fas fa-shield-alt me-2"></i>Admin Panel</h2>
                <p class="text-white-50">Manage users, verify KYC, configure billing, and view audit log</p>
            </div>
            <div id="adminStats" class="row mb-4">
                <div class="col-12 text-center py-3"><div class="spinner-border text-accent" role="status"></div></div>
            </div>
            <div class="row">
                <div class="col-lg-7 mb-4">
                    <div class="glass-card p-4">
                        <!-- UI-35 fix: colored icons for section headings — Users=primary, Plans=success, Audit=info -->
                        <h4 class="text-white fw-bold mb-3"><i class="fas fa-users me-2 text-primary"></i>Users &amp; KYC</h4>
                        <div id="adminUsersTable" class="table-responsive">
                            <p class="text-white-50">Loading...</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-5 mb-4">
                    <div class="glass-card p-4 mb-4">
                        <!-- UI-35 fix: colored icon for Plan Codes heading -->
                        <h4 class="text-white fw-bold mb-3"><i class="fas fa-credit-card me-2 text-success"></i>Plan Codes (Paystack)</h4>
                        <div id="adminPlansTable"><p class="text-white-50">Loading...</p></div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12 mb-4">
                    <div class="glass-card p-4">
                        <!-- UI-35 fix: colored icon for Audit Log heading -->
                        <h4 class="text-white fw-bold mb-3"><i class="fas fa-history me-2 text-info"></i>Audit Log (All Users)</h4>
                        <!-- UI-26 fix: use flex-wrap with gap-2 for even wrapping on narrow viewports -->
                        <div class="mb-3 d-flex gap-2 flex-wrap align-items-center">
                            <input type="text" class="form-control form-control-sm" id="auditFilterAction" placeholder="Filter by action (e.g. user.login)" style="max-width: 250px;">
                            <input type="text" class="form-control form-control-sm" id="auditFilterUserId" placeholder="Filter by user ID" style="max-width: 250px;">
                            <button class="btn btn-sm btn-primary" onclick="app.refreshAdminAudit()"><i class="fas fa-search me-1"></i>Filter</button>
                            <button class="btn btn-sm btn-outline-light" onclick="app.refreshAdminAudit(true)"><i class="fas fa-sync me-1"></i>Clear</button>
                        </div>
                        <div id="adminAuditTable" class="table-responsive" style="max-height: 500px; overflow-y: auto;">
                            <p class="text-white-50">Loading...</p>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    async attachEvents() {
        if (!app.user || app.user.role !== 'admin') return;
        // Load everything in parallel.
        await Promise.all([
            this.loadStats(),
            this.loadUsers(),
            this.loadPlans(),
            this.loadAudit(),
        ]);
    }

    async loadStats() {
        try {
            const resp = await API.admin.stats();
            const s = resp.stats;
            const target = this.querySelector('#adminStats');
            if (!target) return;
            // UI-28 fix: semantically map icon colors to stat meaning.
            // Green = positive (verified, paid, revenue), Yellow = pending, 
            // Blue = neutral counts (users, listings), Cyan = subscriptions.
            const cards = [
                { label: 'Total Users', value: s.totalUsers, icon: 'users', color: 'primary' },
                { label: 'KYC Verified', value: s.verifiedKyc, icon: 'check-circle', color: 'success' },
                { label: 'KYC Pending', value: s.pendingKyc, icon: 'clock', color: 'warning' },
                { label: 'Active Subs', value: s.activeSubscriptions, icon: 'credit-card', color: 'info' },
                { label: 'Listings', value: s.totalListings, icon: 'building', color: 'primary' },
                { label: 'Paid Invoices', value: s.paidInvoices, icon: 'file-invoice', color: 'success' },
                { label: 'Revenue (GHS)', value: Utils.formatCurrency(s.totalRevenueGhs || 0), icon: 'money-bill', color: 'success' },  // JS-032 fix: || 0 to prevent "GHS NaN" if server omits the field
            ];
            // UI-09 fix: use fa-lg instead of fa-2x for better mobile rendering.
            // The old fa-2x icons were disproportionately large on narrow viewports.
            // UI-30 fix: show a welcome message for fresh installs (all stats zero).
            const allZero = s.totalUsers === 0 && s.totalListings === 0 && (s.paidInvoices === 0 || s.totalInvoices === 0);  // JS-033 fix: was s.totalInvoices (not in cards array); now checks paidInvoices OR totalInvoices
            if (allZero) {
                target.innerHTML = `
                    <div class="col-12">
                        <div class="glass-card p-5 text-center">
                            <i class="fas fa-rocket fa-3x text-accent mb-3"></i>
                            <h3 class="text-white fw-bold mb-2">Welcome to Busifirm!</h3>
                            <p class="text-white-50 mb-0">No data yet. Once users register and create listings, stats will appear here.</p>
                        </div>
                    </div>`;
                return;
            }
            target.innerHTML = cards.map(c => `
                <div class="col-lg-3 col-md-6 mb-3">
                    <div class="glass-card p-3 text-center">
                        <i class="fas fa-${c.icon} fa-lg text-${c.color} mb-2"></i>
                        <h4 class="text-white fw-bold mb-0">${c.value}</h4>
                        <small class="text-white-50">${c.label}</small>
                    </div>
                </div>
            `).join('');
        } catch (err) {
            // Bug 031 fix: show error state in UI instead of silently swallowing
            console.warn('Admin stats failed:', err);
            const target = this.querySelector('#adminStats');
            if (target) target.innerHTML = `<div class="col-12"><div class="glass-card p-4 text-center"><i class="fas fa-exclamation-triangle fa-2x text-warning mb-3"></i><p class="text-white-50 mb-0">Failed to load stats. ${Utils.sanitize(err?.message || '')}</p><button class="btn btn-outline-light btn-sm mt-2" onclick="document.querySelector('app-admin').loadStats()">Retry</button></div></div>`;
        }
    }

    async loadUsers() {
        try {
            // UX-09 fix: fetch ALL users including deleted ones. The frontend
            // filters them client-side via the "Show deleted users" toggle.
            // The old API call didn't pass includeDeleted, so deleted users
            // were never returned — the toggle would always show 0.
            const resp = await API.admin.listUsers({ includeDeleted: true });
            const users = resp.users || [];
            const target = this.querySelector('#adminUsersTable');
            if (!target) return;
            if (users.length === 0) {
                target.innerHTML = '<p class="text-white-50">No users found.</p>';
                return;
            }

            // UX-09 fix: render the users table and add a "Show deleted users"
            // toggle button. The old code only showed active users — if an admin
            // deleted a user and wanted to cancel the deletion within the 30-day
            // window, they had no way to find the user in the UI. Now the toggle
            // reveals deleted users with a "Restore" button.
            const renderTable = (showDeleted, allUsers) => {
                const visibleUsers = showDeleted
                    ? allUsers
                    : allUsers.filter(u => !u.deletedAt);
                const deletedCount = allUsers.filter(u => u.deletedAt).length;
                const toggleBtn = deletedCount > 0
                    ? `<button class="btn btn-sm btn-outline-info mb-2" onclick="app._toggleDeletedUsers()">${showDeleted ? 'Hide' : 'Show'} deleted users (${deletedCount})</button>`
                    : '';

                if (visibleUsers.length === 0) {
                    return `${toggleBtn}<p class="text-white-50">No ${showDeleted ? 'deleted ' : ''}users found.</p>`;
                }

                return `${toggleBtn}
                <!-- UI-05 fix: wrapped table in table-responsive for horizontal scroll on mobile -->
                <div class="table-responsive">
                <table class="table table-sm align-middle mb-0">
                    <thead><tr class="text-white-50 small">
                        <th>Email</th><th>Role</th><th>KYC</th><th>Plan</th><th>Actions</th>
                    </tr></thead>
                    <tbody>
                        ${visibleUsers.map(u => `
                            <tr style="color: rgba(255,255,255,${u.deletedAt ? '0.4' : '0.9'});">
                                <td>
                                    ${Utils.sanitize(u.email)}
                                    ${u.emailVerified ? '' : ' <small class="text-warning">(unverified email)</small>'}
                                    ${u.deletedAt ? ` <span class="badge bg-danger ms-1">deleted</span>` : ''}
                                </td>
                                <td>
                                    <!-- UI-15 fix: wrapped role badge + edit button in d-flex with gap-1 for spacing -->
                                    <div class="d-flex align-items-center gap-1">
                                        <span class="badge bg-secondary">${Utils.sanitize(u.role)}</span>
                                        ${u.role !== 'admin' && !u.deletedAt
                                            ? `<button class="btn btn-outline-light btn-sm py-0 px-1" onclick="app.adminChangeUserRole('${u.id}', '${Utils.sanitize(u.role)}')" title="Change role"><i class="fas fa-edit"></i></button>`
                                            : ''}
                                    </div>
                                </td>
                                <td>${this._kycBadge(u.kycStatus)}</td>
                                <td><small class="text-white-50"><!-- UI-23 fix: capitalize first letter of plan code -->${Utils.sanitize((u.planCode || 'free')).charAt(0).toUpperCase() + Utils.sanitize(u.planCode || 'free').slice(1)}</small></td>
                                <td>
                                    <!-- UI-04 fix: wrapped action buttons in d-flex gap-1 flex-wrap for proper spacing on narrow viewports -->
                                    <div class="d-flex gap-1 flex-wrap">
                                        ${u.deletedAt
                                            ? `<button class="btn btn-success btn-sm" onclick="app.adminCancelUserDeletion('${u.id}')" title="Restore user"><i class="fas fa-undo me-1"></i>Restore</button>`
                                            : `
                                                ${u.kycStatus === 'pending' ? `
                                                    <button class="btn btn-success btn-sm" onclick="app.adminVerifyKyc('${u.id}')" title="Verify KYC"><i class="fas fa-check"></i></button>
                                                    <button class="btn btn-danger btn-sm" onclick="app.adminRejectKyc('${u.id}')" title="Reject KYC"><i class="fas fa-times"></i></button>
                                                ` : u.kycStatus === 'verified' ? `
                                                    <button class="btn btn-outline-danger btn-sm" onclick="app.adminRejectKyc('${u.id}')" title="Revoke KYC"><i class="fas fa-undo"></i></button>
                                                ` : u.kycStatus === 'rejected' ? `
                                                    <button class="btn btn-success btn-sm" onclick="app.adminVerifyKyc('${u.id}')" title="Verify KYC"><i class="fas fa-check"></i></button>
                                                ` : ''}
                                                <!-- UI-19 fix: add ms-1 to separate delete from KYC buttons, and use btn-danger (filled) to distinguish from btn-outline-danger (reject KYC) -->
                                                <!-- UI-29 fix: add text label "Delete" to the button — was icon-only, ambiguous on mobile -->
                                                ${u.role !== 'admin'
                                                    ? `<button class="btn btn-danger btn-sm ms-1" onclick="app.adminDeleteUser('${u.id}', '${Utils.sanitize(u.email).replace(/'/g, "\\'").replace(/"/g, '&quot;')}')" title="Delete user (GDPR)"><i class="fas fa-trash me-1"></i>Delete</button>`  <!-- JS-045 fix: also escape " for HTML attribute context -->
                                                    : ''}
                                            `}
                                    </div>
                                </td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
                </div>`;
            };

            // Store users for toggling
            this._allUsers = users;
            this._showDeletedUsers = false;
            target.innerHTML = renderTable(false, users);
        } catch (err) {
            const target = this.querySelector('#adminUsersTable');
            if (target) target.innerHTML = `<p class="text-warning">Failed to load users: ${Utils.sanitize(err?.message || '')}</p>`;
        }
    }

    _toggleDeletedUsers() {
        // UX-09 fix: toggle between showing/hiding deleted users.
        this._showDeletedUsers = !this._showDeletedUsers;
        const target = this.querySelector('#adminUsersTable');
        if (!target || !this._allUsers) return;
        const showDeleted = this._showDeletedUsers;
        const allUsers = this._allUsers;
        const visibleUsers = showDeleted
            ? allUsers
            : allUsers.filter(u => !u.deletedAt);
        const deletedCount = allUsers.filter(u => u.deletedAt).length;
        const toggleBtn = deletedCount > 0
            ? `<button class="btn btn-sm btn-outline-info mb-2" onclick="app._toggleDeletedUsers()">${showDeleted ? 'Hide' : 'Show'} deleted users (${deletedCount})</button>`
            : '';
        if (visibleUsers.length === 0) {
            target.innerHTML = `${toggleBtn}<p class="text-white-50">No ${showDeleted ? 'deleted ' : ''}users found.</p>`;
            return;
        }
        target.innerHTML = `${toggleBtn}
        <table class="table table-sm align-middle mb-0">
            <thead><tr class="text-white-50 small">
                <th>Email</th><th>Role</th><th>KYC</th><th>Plan</th><th>Actions</th>
            </tr></thead>
            <tbody>
                ${visibleUsers.map(u => `
                    <tr style="color: rgba(255,255,255,${u.deletedAt ? '0.4' : '0.9'});">
                        <td>
                            ${Utils.sanitize(u.email)}
                            ${u.emailVerified ? '' : ' <small class="text-warning">(unverified email)</small>'}
                            ${u.deletedAt ? ` <span class="badge bg-danger ms-1">deleted</span>` : ''}
                        </td>
                        <td>
                            <span class="badge bg-secondary">${Utils.sanitize(u.role)}</span>
                        </td>
                        <td>${this._kycBadge(u.kycStatus)}</td>
                        <td><small class="text-white-50">${Utils.sanitize(u.planCode || 'free')}</small></td>
                        <td>
                            ${u.deletedAt
                                ? `<button class="btn btn-success btn-sm" onclick="app.adminCancelUserDeletion('${u.id}')" title="Restore user"><i class="fas fa-undo me-1"></i>Restore</button>`
                                : ''}
                        </td>
                    </tr>
                `).join('')}
            </tbody>
        </table>`;
    }

    _kycBadge(status) {
        // UI-13 fix: use human-readable labels with proper capitalization
        // instead of raw lowercase enum values.
        const map = {
            verified: '<span class="badge bg-success">Verified</span>',
            pending: '<span class="badge bg-warning">Pending</span>',
            rejected: '<span class="badge bg-danger">Rejected</span>',
            unverified: '<span class="badge bg-secondary">Unverified</span>',
        };
        return map[status] || map.unverified;
    }

    async loadPlans() {
        try {
            const resp = await API.admin.listPlans();
            const plans = resp.plans || [];
            const target = this.querySelector('#adminPlansTable');
            if (!target) return;
            // UI-22 fix: use text-white-50 (muted) instead of text-warning for
            // plans without a Paystack code — this is the default state, not a
            // problem. Warning color should only be used when there's an actual issue.
            target.innerHTML = plans.map(p => `
                <div class="d-flex justify-content-between align-items-center mb-2 pb-2 border-bottom border-white-50">
                    <div>
                        <strong class="text-white">${Utils.sanitize(p.name)}</strong>
                        <small class="text-white-50 d-block">${Utils.formatCurrency(p.priceGhs)}/${p.billingInterval === 'yearly' ? 'yr' : 'mo'}</small>
                        <small class="${p.paystackPlanCode ? 'text-success' : 'text-white-50'}">
                            ${p.paystackPlanCode ? 'Recurring: ' + Utils.sanitize(p.paystackPlanCode) : 'One-time (no recurring)'}
                        </small>
                    </div>
                    <button class="btn btn-sm btn-outline-light" onclick="app.adminEditPlanCode('${p.code}', '${Utils.sanitize(p.paystackPlanCode || '')}')">
                        <i class="fas fa-edit me-1"></i>Edit Code
                    </button>
                </div>
            `).join('');
        } catch (err) {
            const target = this.querySelector('#adminPlansTable');
            if (target) target.innerHTML = `<p class="text-warning">Failed to load plans: ${Utils.sanitize(err?.message || '')}</p>`;
        }
    }

    async loadAudit(filters = {}) {
        try {
            const resp = await API.admin.audit(filters);
            const entries = resp.entries || [];
            const target = this.querySelector('#adminAuditTable');
            if (!target) return;
            if (entries.length === 0) {
                target.innerHTML = '<p class="text-white-50">No audit events found.</p>';
                return;
            }
            target.innerHTML = `
                <table class="table table-sm align-middle mb-0">
                    <thead class="sticky-thead"><tr class="text-white-50 small">
                        <th>Timestamp</th><th>Action</th><th>User ID</th><th>Details</th>
                    </tr></thead>
                    <tbody>
                        ${entries.map(e => {
                            // UI-14 fix: show full JSON in a title tooltip so the admin
                            // can hover to see the complete details. Also truncate with
                            // ellipsis for display. The old code sliced at 120 chars with
                            // no indicator or way to see the full value.
                            //
                            // JS-018 fix: wrap JSON.stringify in try/catch. A circular
                            // reference or a non-serializable object would throw
                            // TypeError: Converting circular structure to JSON, which
                            // the outer try/catch catches but then the ENTIRE audit
                            // table renders as "Failed to load audit log: …" — one
                            // bad row nukes the whole table. Now we substitute
                            // '[unserializable]' for just the bad row.
                            let detailStr;
                            try { detailStr = JSON.stringify(e.details) ?? ''; }
                            catch { detailStr = '[unserializable]'; }
                            const truncated = detailStr.length > 120
                                ? detailStr.slice(0, 117) + '...'
                                : detailStr;
                            return `
                            <tr style="color: rgba(255,255,255,0.9);">
                                <td><small>${Utils.formatDate(e.timestamp)}</small></td>
                                <td><code class="text-info">${Utils.sanitize(e.action)}</code></td>
                                <!-- UI-33 fix: use ASCII '...' instead of Unicode '…' (U+2026) for broader font compatibility -->
                                <td><small class="text-white-50">${e.userId ? Utils.sanitize(e.userId).slice(0, 8) + '...' : '—'}</small></td>
                                <td><small class="text-white-50" title="${Utils.sanitize(detailStr)}" style="cursor: help;">${Utils.sanitize(truncated)}</small></td>
                            </tr>
                            `;
                        }).join('')}
                    </tbody>
                </table>
            `;
        } catch (err) {
            const target = this.querySelector('#adminAuditTable');
            if (target) target.innerHTML = `<p class="text-warning">Failed to load audit log: ${Utils.sanitize(err?.message || '')}</p>`;
        }
    }
}

// ===== APP INITIALIZATION =====
// OTH-29 fix: explicitly assign to window.app so it's clear this is a global.
// The old `const app` at top level creates a global in browsers but not on
// window — meaning `window.app` is undefined while `app` works in inline
// handlers. Now both work.
const app = new BusifirmApp();
window.app = app;
