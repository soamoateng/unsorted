/**
 * Busifirm API adapter.
 *
 * OTH-02 fix: updated stale comment. All localStorage-backed stores
 * (ListingStore, ChatStore, etc.) ARE migrated to this API adapter as of M2.
 * The old comment said "NOT migrated here — that is M2" which was stale.
 *
 * Single responsibility: wrap fetch() with CSRF header injection, JSON
 * (de)serialization, and a surface that mirrors what BusifirmApp needs.
 *
 * KISS: ~350 lines. No GraphQL, no query invalidation, no SWR.
 *
 * CSRF strategy:
 *   1. On boot, AuthBootstrap() GETs /api/auth/csrf to obtain a token.
 *   2. The token is cached in-memory (never localStorage) and sent as the
 *      X-CSRF-Token header on every POST/PUT/PATCH/DELETE.
 *   3. On 403 (token expired), the wrapper transparently re-fetches a token
 *      and retries the request once.
 */
// OTH-30 fix: documented the module pattern difference.
// api.js uses the IIFE pattern (window.API = (function(){...})()) because it
// needs to be available BEFORE app.js loads (app.js calls API methods during
// boot). app.js uses `const app = new BusifirmApp(); window.app = app;` because
// it only needs to be available to inline onclick handlers AFTER the DOM loads.
// Both patterns expose globals — they're intentionally different for load-order
// clarity.
window.API = (function () {
    let csrfToken = null;
    let csrfPromise = null;

    async function ensureCsrf() {
        if (csrfToken) return csrfToken;
        if (csrfPromise) return csrfPromise;
        csrfPromise = fetch('/api/auth/csrf', {
            method: 'GET',
            credentials: 'same-origin',
            headers: { 'Accept': 'application/json' },
        })
            .then((r) => r.json())
            .then((data) => {
                csrfToken = data.csrfToken || null;
                csrfPromise = null;
                return csrfToken;
            })
            .catch(() => {
                csrfPromise = null;
                return null;
            });
        return csrfPromise;
    }

    async function request(method, path, body) {
        await ensureCsrf();
        const headers = { 'Accept': 'application/json' };
        if (body !== undefined) {
            headers['Content-Type'] = 'application/json';
            if (csrfToken) headers['X-CSRF-Token'] = csrfToken;
        }
        const init = {
            method,
            headers,
            credentials: 'same-origin',
        };
        if (body !== undefined) init.body = JSON.stringify(body);

        // PERF-29 fix: add a 30-second timeout via AbortController so a slow
        // server doesn't hang the UI indefinitely. The old code had no timeout.
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 30000);
        init.signal = controller.signal;

        let resp;
        try {
            resp = await fetch(path, init);
        } catch (e) {
            clearTimeout(timeoutId);
            if (e.name === 'AbortError') {
                const err = new Error('Request timed out after 30 seconds. Please check your connection and try again.');
                err.status = 0;
                throw err;
            }
            throw e;
        }
        clearTimeout(timeoutId);

        // Single retry on CSRF rejection.
        if (resp.status === 403 && body !== undefined) {
            csrfToken = null;
            await ensureCsrf();
            if (csrfToken) {
                headers['X-CSRF-Token'] = csrfToken;
                // JS-039 fix: create a NEW AbortController for the retry — the
                // old one's timeout was already cleared, so the retry had no timeout.
                const retryController = new AbortController();
                const retryTimeoutId = setTimeout(() => retryController.abort(), 30000);
                init.signal = retryController.signal;
                try {
                    resp = await fetch(path, init);
                } catch (e) {
                    clearTimeout(retryTimeoutId);
                    if (e.name === 'AbortError') {
                        const err = new Error('Request timed out after 30 seconds. Please check your connection and try again.');
                        err.status = 0;
                        throw err;
                    }
                    throw e;
                }
                clearTimeout(retryTimeoutId);
            }
        }

        let payload = null;
        const ct = resp.headers.get('Content-Type') || '';
        if (ct.includes('application/json')) {
            payload = await resp.json().catch(() => null);
        }
        if (!resp.ok) {
            const msg = (payload && payload.error) || `HTTP ${resp.status}`;
            const err = new Error(msg);
            err.status = resp.status;
            err.payload = payload;
            throw err;
        }
        return payload;
    }

    return {
        // --- Auth (M1) ---
        register: (email, password, role) => request('POST', '/api/auth/register', { email, password, role }),
        login:    (email, password)        => request('POST', '/api/auth/login',    { email, password }),
        logout:   ()                        => request('POST', '/api/auth/logout',   {}),
        me:       ()                        => request('GET',  '/api/auth/me'),
        csrf:     ()                        => request('GET',  '/api/auth/csrf'),
        verifyEmail: (token)               => request('GET',  `/api/auth/verify?token=${encodeURIComponent(token)}`),
        forgotPassword: (email)            => request('POST', '/api/auth/forgot',  { email }),
        resetPassword:  (token, password)  => request('POST', '/api/auth/reset',   { token, password }),

        // --- Listings (M2) ---
        listings: {
            list:         ()             => request('GET',  '/api/listings'),
            get:          (id)           => request('GET',  `/api/listings/${encodeURIComponent(id)}`),
            save:         (listing)      => request('POST', '/api/listings', listing),
            delete:       (id)           => request('POST', `/api/listings/${encodeURIComponent(id)}/delete`),
            checkDuplicate: (name, excludeId) => {
                const q = new URLSearchParams();
                q.set('companyName', name);
                if (excludeId) q.set('excludeId', excludeId);
                return request('GET', `/api/listings/duplicate?${q.toString()}`);
            },
        },

        // --- IPs (M2 — read-only marketplace catalog) ---
        ips: {
            all:    ()                       => request('GET', '/api/ips/all'),
            search: (q, filters = {})        => {
                const params = new URLSearchParams();
                if (q) params.set('q', q);
                if (filters.sector) params.set('sector', filters.sector);
                if (filters.type) params.set('type', filters.type);
                return request('GET', `/api/ips?${params.toString()}`);
            },
            get:    (id)                     => request('GET', `/api/ips/${encodeURIComponent(id)}`),
        },

        // --- Deals (M2) ---
        deals: {
            list:   ()                  => request('GET',  '/api/deals'),
            create: (deal)              => request('POST', '/api/deals', deal),
            update: (id, updates)       => request('POST', `/api/deals/${encodeURIComponent(id)}`, updates),
            delete: (id)                => request('POST', `/api/deals/${encodeURIComponent(id)}/delete`),
        },

        // --- Chat (M2) ---
        chat: {
            list:        ()                 => request('GET',  '/api/chat'),
            get:         (convId)           => request('GET',  `/api/chat/${encodeURIComponent(convId)}`),
            create:      (conv)             => request('POST', '/api/chat', conv),
            sendMessage: (convId, sender, text) => request('POST', `/api/chat/${encodeURIComponent(convId)}/message`, { sender, text }),
            markAsRead:  (convId)           => request('POST', `/api/chat/${encodeURIComponent(convId)}/read`),
        },

        // --- ESigns (M2 + M3 witness) ---
        esigns: {
            list:      ()                          => request('GET',  '/api/esigns'),
            listAwaitingWitness: ()                => request('GET',  '/api/esigns/awaiting-witness'),
            save:      (doc)                       => request('POST', '/api/esigns', doc),
            // SEC-01 fix: no longer send witnessEmail — the server reads it from session.
            witnessSign: (id)                    => request('POST', `/api/esigns/${encodeURIComponent(id)}/witness-sign`, {}),
        },

        // --- Integrations (M2) ---
        integrations: {
            get:        ()                 => request('GET',  '/api/integrations'),
            createTask: (task)             => request('POST', '/api/integrations/tasks', task),
            updateTask: (taskId, updates)  => request('POST', `/api/integrations/tasks/${encodeURIComponent(taskId)}`, updates),
        },

        // --- KYC (M2) ---
        kyc: {
            get:          ()                 => request('GET',  '/api/kyc'),
            updateStatus: (status, documents) => request('POST', '/api/kyc', { status, documents }),
        },

        // --- Audit (M2) ---
        audit: {
            list: (limit)            => request('GET',  `/api/audit${limit ? `?limit=${limit}` : ''}`),
            log:  (action, details)  => request('POST', '/api/audit', { action, details }),
        },

        // --- Billing (M4 Paystack + M4 polish: trial / change-plan / proration) ---
        billing: {
            plans:    ()                       => request('GET',  '/api/billing/plans'),
            me:       ()                       => request('GET',  '/api/billing/me'),
            checkout: (planCode)               => request('POST', '/api/billing/checkout', { planCode }),
            returnFromPaystack: (reference)    => request('GET',  `/api/billing/return?reference=${encodeURIComponent(reference)}`),
            cancel:   ()                       => request('POST', '/api/billing/cancel'),
            // M4 polish:
            startTrial:  (planCode)            => request('POST', '/api/billing/trial', { planCode }),
            changePlan:  (planCode)            => request('POST', '/api/billing/change-plan', { planCode }),
            previewProration: (planCode)       => request('GET',  `/api/billing/proration?planCode=${encodeURIComponent(planCode)}`),
            // Webhook is server-only; not callable from the frontend.
        },

        // --- Documents (M5 file storage + M5 polish: chunked uploads) ---
        // Upload uses multipart/form-data (NOT JSON), so it can't go through
        // the standard request() helper. We build the FormData manually and
        // send the CSRF token via the X-CSRF-Token header.
        documents: {
            list:   ()                        => request('GET',  '/api/documents'),
            upload: async (file, purpose = 'general') => {
                await ensureCsrf();
                const fd = new FormData();
                fd.append('file', file);
                fd.append('purpose', purpose);
                const init = {
                    method: 'POST',
                    headers: { 'Accept': 'application/json' },
                    credentials: 'same-origin',
                    body: fd,
                };
                if (csrfToken) init.headers['X-CSRF-Token'] = csrfToken;
                // JS-038 fix: add AbortController with 120s timeout for uploads
                // (longer than the 30s default for JSON requests).
                const controller = new AbortController();
                const timeoutId = setTimeout(() => controller.abort(), 120000);
                init.signal = controller.signal;
                let resp;
                try {
                    resp = await fetch('/api/documents', init);
                } catch (e) {
                    clearTimeout(timeoutId);
                    if (e.name === 'AbortError') {
                        const err = new Error('Upload timed out after 120 seconds.');
                        err.status = 0;
                        throw err;
                    }
                    throw e;
                }
                clearTimeout(timeoutId);
                if (resp.status === 403) {
                    csrfToken = null;
                    await ensureCsrf();
                    if (csrfToken) {
                        init.headers['X-CSRF-Token'] = csrfToken;
                        resp = await fetch('/api/documents', init);
                    }
                }
                const ct = resp.headers.get('Content-Type') || '';
                const payload = ct.includes('application/json') ? await resp.json().catch(() => null) : null;
                if (!resp.ok) {
                    const msg = (payload && payload.error) || `HTTP ${resp.status}`;
                    const err = new Error(msg);
                    err.status = resp.status;
                    err.payload = payload;
                    throw err;
                }
                return payload;
            },
            // download is not a JSON endpoint — it streams the file. Return the
            // URL so the caller can open it in a new tab or use as an <a href>.
            downloadUrl: (id) => `/api/documents/${encodeURIComponent(id)}`,
            delete:  (id)                     => request('POST', `/api/documents/${encodeURIComponent(id)}/delete`),

            // M5 polish: chunked upload protocol. The frontend opts in to
            // chunked uploads for files > DOCUMENT_CHUNK_THRESHOLD_MB (default 5MB).
            //   1. startChunkedUpload() → returns {uploadId, chunkSize, totalChunks}
            //   2. uploadChunk(uploadId, index, blob) → returns {received, total}
            //   3. completeChunkedUpload(uploadId) → returns the document DTO
            //   4. abortChunkedUpload(uploadId) → cleanup on cancel/failure
            startChunkedUpload: (meta) => request('POST', '/api/documents/chunk', {
                originalFilename: meta.originalFilename,
                intendedMime: meta.intendedMime,
                intendedSize: meta.intendedSize,
                purpose: meta.purpose || 'general',
                chunkSize: meta.chunkSize || null,
            }),
            uploadChunk: async (uploadId, index, blob) => {
                await ensureCsrf();
                const fd = new FormData();
                fd.append('file', blob);
                fd.append('index', String(index));
                const init = {
                    method: 'POST',
                    headers: { 'Accept': 'application/json' },
                    credentials: 'same-origin',
                    body: fd,
                };
                if (csrfToken) init.headers['X-CSRF-Token'] = csrfToken;
                let resp = await fetch(`/api/documents/chunk/${encodeURIComponent(uploadId)}`, init);
                if (resp.status === 403) {
                    csrfToken = null;
                    await ensureCsrf();
                    if (csrfToken) {
                        init.headers['X-CSRF-Token'] = csrfToken;
                        resp = await fetch(`/api/documents/chunk/${encodeURIComponent(uploadId)}`, init);
                    }
                }
                const ct = resp.headers.get('Content-Type') || '';
                const payload = ct.includes('application/json') ? await resp.json().catch(() => null) : null;
                if (!resp.ok) {
                    const msg = (payload && payload.error) || `HTTP ${resp.status}`;
                    const err = new Error(msg);
                    err.status = resp.status;
                    throw err;
                }
                return payload;
            },
            completeChunkedUpload: (uploadId) => request('POST', `/api/documents/chunk/${encodeURIComponent(uploadId)}/complete`),
            abortChunkedUpload:    (uploadId) => request('POST', `/api/documents/chunk/${encodeURIComponent(uploadId)}/abort`),

            // Convenience: auto-select chunked vs direct based on file size.
            // Returns the final document DTO either way.
            uploadAuto: async (file, purpose = 'general', chunkThresholdMB = 5, onProgress = null) => {
                const sizeMB = file.size / (1024 * 1024);
                if (sizeMB <= chunkThresholdMB) {
                    if (onProgress) onProgress(0, file.size, 0);
                    const r = await API.documents.upload(file, purpose);
                    if (onProgress) onProgress(file.size, file.size, 1);
                    return r;
                }
                // Chunked path.
                const chunkSize = 2 * 1024 * 1024;  // 2MB chunks
                const start = await API.documents.startChunkedUpload({
                    originalFilename: file.name,
                    intendedMime: file.type,
                    intendedSize: file.size,
                    purpose,
                    chunkSize,
                });
                const totalChunks = start.totalChunks;
                const uploadId = start.uploadId;
                try {
                    let uploaded = 0;
                    for (let i = 0; i < totalChunks; i++) {
                        const startByte = i * chunkSize;
                        const endByte = Math.min(startByte + chunkSize, file.size);
                        const blob = file.slice(startByte, endByte);
                        await API.documents.uploadChunk(uploadId, i, blob);
                        uploaded = endByte;
                        if (onProgress) onProgress(uploaded, file.size, (i + 1) / totalChunks);
                    }
                    const result = await API.documents.completeChunkedUpload(uploadId);
                    return result;
                } catch (err) {
                    try { await API.documents.abortChunkedUpload(uploadId); } catch (_) {}
                    throw err;
                }
            },
        },

        // --- Admin (M6 + M6 polish: role change, user delete, cancel-deletion) ---
        admin: {
            stats:       ()                              => request('GET',  '/api/admin/stats'),
            // UX-09 fix: listUsers now accepts an opts object with includeDeleted.
            listUsers:   (opts = {})                     => {
                const params = new URLSearchParams();
                if (opts.includeDeleted) params.set('includeDeleted', 'true');
                const qs = params.toString();
                return request('GET', `/api/admin/users${qs ? '?' + qs : ''}`);
            },
            verifyKyc:   (userId)                        => request('POST', `/api/admin/users/${encodeURIComponent(userId)}/verify-kyc`),
            rejectKyc:   (userId)                        => request('POST', `/api/admin/users/${encodeURIComponent(userId)}/reject-kyc`),
            listPlans:   ()                              => request('GET',  '/api/admin/plans'),
            setPlanCode: (planCode, paystackPlanCode)    => request('POST', `/api/admin/plans/${encodeURIComponent(planCode)}/set-code`, { paystackPlanCode }),
            clearPlanCode: (planCode)                    => request('POST', `/api/admin/plans/${encodeURIComponent(planCode)}/clear-code`),
            // M6 polish:
            changeUserRole:    (userId, newRole)         => request('POST', `/api/admin/users/${encodeURIComponent(userId)}/role`, { role: newRole }),
            deleteUser:        (userId)                  => request('POST', `/api/admin/users/${encodeURIComponent(userId)}/delete`),
            cancelUserDeletion: (userId)                 => request('POST', `/api/admin/users/${encodeURIComponent(userId)}/cancel-deletion`),
            audit:       (filters = {})                  => {
                const params = new URLSearchParams();
                if (filters.userId) params.set('userId', filters.userId);
                if (filters.action) params.set('action', filters.action);
                if (filters.fromDate) params.set('fromDate', filters.fromDate);
                if (filters.toDate) params.set('toDate', filters.toDate);
                if (filters.limit) params.set('limit', filters.limit);
                const qs = params.toString();
                return request('GET', `/api/admin/audit${qs ? '?' + qs : ''}`);
            },
        },

        // --- Internals exposed for testing / debugging ---
        _setCsrf: (t) => { csrfToken = t; },
        _getCsrf: () => csrfToken,
        _request:  request,  // exposed for store modules that need raw fetch
    };
})();
