/**
 * MazeShooter — maze.js
 *
 * Procedural maze generation + grid utilities.
 * Adapted from the Nemesis boilerplate's static `map` array format:
 *   map[i][j] = 0  -> open floor
 *   map[i][j] = 1  -> wall (texture A: images/wall-1.jpg)
 *   map[i][j] = 2  -> wall (texture B: images/wall-2.jpg)
 *
 * Written UMD-style so the exact same code runs in the browser
 * (window.MazeLib) and in Node (module.exports) for automated testing.
 */
(function (root, factory) {
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = factory();
  } else {
    root.MazeLib = factory();
  }
}(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  /**
   * Generate a maze of w x h sectors (both MUST be odd).
   * Uses a recursive-backtracker (iterative stack) on odd cells, then
   * knocks out extra interior walls to create loops so the maze is not
   * strictly perfect — better for FPS combat and gives A* route choices.
   *
   * @param {number} w  width in sectors (odd)
   * @param {number} h  height in sectors (odd)
   * @param {number} loops  how many interior walls to open up for loops
   * @returns {number[][]} map[i][j]
   */
  function generateMaze(w, h, loops) {
    if (w % 2 === 0) w += 1;
    if (h % 2 === 0) h += 1;

    // Start fully solid; wall texture variant is chosen randomly (1 or 2)
    var map = [];
    for (var i = 0; i < w; i++) {
      map[i] = [];
      for (var j = 0; j < h; j++) {
        map[i][j] = Math.random() < 0.5 ? 1 : 2;
      }
    }

    // --- Recursive backtracker on odd cells ---
    var stack = [];
    var startI = 1, startJ = 1;
    map[startI][startJ] = 0;
    stack.push([startI, startJ]);

    var DIRS = [[-2, 0], [2, 0], [0, -2], [0, 2]];

    while (stack.length) {
      var cur = stack[stack.length - 1];
      var ci = cur[0], cj = cur[1];

      // Collect unvisited neighbors (odd cells still solid)
      var options = [];
      for (var d = 0; d < 4; d++) {
        var ni = ci + DIRS[d][0];
        var nj = cj + DIRS[d][1];
        if (ni > 0 && ni < w - 1 && nj > 0 && nj < h - 1 && map[ni][nj] !== 0) {
          options.push([ni, nj]);
        }
      }

      if (options.length) {
        var next = options[Math.floor(Math.random() * options.length)];
        // Carve the wall between current and next, then the next cell
        var wi = ci + (next[0] - ci) / 2;
        var wj = cj + (next[1] - cj) / 2;
        map[wi][wj] = 0;
        map[next[0]][next[1]] = 0;
        stack.push(next);
      } else {
        stack.pop();
      }
    }

    // --- Carve loops: open random interior walls with two open sides ---
    var opened = 0, guard = 0;
    while (opened < loops && guard < loops * 60) {
      guard++;
      var x = 1 + Math.floor(Math.random() * (w - 2));
      var z = 1 + Math.floor(Math.random() * (h - 2));
      if (map[x][z] === 0) continue;
      // Keep border solid
      if (x <= 0 || x >= w - 1 || z <= 0 || z >= h - 1) continue;
      // Only open walls that connect two open cells (horizontally or vertically)
      var horizontal = map[x - 1][z] === 0 && map[x + 1][z] === 0;
      var vertical = map[x][z - 1] === 0 && map[x][z + 1] === 0;
      if (horizontal !== vertical) { // exactly one orientation connects
        map[x][z] = 0;
        opened++;
      }
    }

    return map;
  }

  /**
   * BFS flood-fill of step distances across open cells.
   * @returns {number[][]} dist[i][j] = steps from (sx,sz); -1 = wall/unreachable
   */
  function bfsDistances(map, w, h, sx, sz) {
    var dist = [];
    for (var i = 0; i < w; i++) {
      dist[i] = [];
      for (var j = 0; j < h; j++) dist[i][j] = -1;
    }
    if (map[sx][sz] !== 0) return dist;
    dist[sx][sz] = 0;
    var queue = [[sx, sz]];
    var head = 0;
    while (head < queue.length) {
      var cur = queue[head++];
      var x = cur[0], z = cur[1];
      var nd = dist[x][z] + 1;
      var nbrs = [[x - 1, z], [x + 1, z], [x, z - 1], [x, z + 1]];
      for (var k = 0; k < 4; k++) {
        var nx = nbrs[k][0], nz = nbrs[k][1];
        if (nx >= 0 && nx < w && nz >= 0 && nz < h && map[nx][nz] === 0 && dist[nx][nz] === -1) {
          dist[nx][nz] = nd;
          queue.push([nx, nz]);
        }
      }
    }
    return dist;
  }

  /**
   * Find the open cell farthest (by BFS steps) from a start cell —
   * used to place the exit portal at the deepest point of the maze.
   * @returns {{x:number, z:number, dist:number}}
   */
  function farthestCell(map, w, h, sx, sz) {
    var dist = bfsDistances(map, w, h, sx, sz);
    var best = { x: sx, z: sz, dist: 0 };
    for (var i = 0; i < w; i++) {
      for (var j = 0; j < h; j++) {
        if (dist[i][j] > best.dist) best = { x: i, z: j, dist: dist[i][j] };
      }
    }
    return best;
  }

  /**
   * Pick n random open cells whose BFS distance from (sx,sz) is at least
   * minDist — used for enemy spawns and health-pack placement.
   * @returns {Array<{x:number, z:number}>}
   */
  function pickOpenCells(map, w, h, sx, sz, n, minDist) {
    var dist = bfsDistances(map, w, h, sx, sz);
    var pool = [];
    for (var i = 1; i < w - 1; i++) {
      for (var j = 1; j < h - 1; j++) {
        if (map[i][j] === 0 && dist[i][j] >= minDist) pool.push({ x: i, z: j });
      }
    }
    // Shuffle
    for (var s = pool.length - 1; s > 0; s--) {
      var t = Math.floor(Math.random() * (s + 1));
      var tmp = pool[s]; pool[s] = pool[t]; pool[t] = tmp;
    }
    // Spread picks apart so they don't clump (greedy min separation)
    var picks = [];
    var minSep = Math.max(2, Math.floor((w + h) / 12));
    for (var p = 0; p < pool.length && picks.length < n; p++) {
      var c = pool[p];
      var ok = true;
      for (var q = 0; q < picks.length; q++) {
        if (Math.abs(picks[q].x - c.x) + Math.abs(picks[q].z - c.z) < minSep) { ok = false; break; }
      }
      if (ok) picks.push(c);
    }
    // Fallback: relax separation if the maze is too small
    if (picks.length < n) {
      for (var p2 = 0; p2 < pool.length && picks.length < n; p2++) {
        if (picks.indexOf(pool[p2]) === -1) picks.push(pool[p2]);
      }
    }
    return picks;
  }

  /**
   * Render map to compact ASCII (debugging / tests).
   */
  function toAscii(map, w, h) {
    var out = '';
    for (var j = 0; j < h; j++) {
      var row = '';
      for (var i = 0; i < w; i++) row += map[i][j] === 0 ? '.' : '#';
      out += row + '\n';
    }
    return out;
  }

  return {
    generateMaze: generateMaze,
    bfsDistances: bfsDistances,
    farthestCell: farthestCell,
    pickOpenCells: pickOpenCells,
    toAscii: toAscii
  };
}));
