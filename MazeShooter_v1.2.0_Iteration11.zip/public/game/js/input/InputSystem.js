/**
 * MazeShooter · input/InputSystem.js
 *
 * Aggregates continuous input from attached controllers into one snapshot
 * per frame. Controllers are interchangeable behind a tiny role interface
 * (Interface Segregation + Dependency Inversion):
 *
 *   attach() / detach()
 *   update(dt, out)   // write continuous values into the snapshot
 *   enabled           // boolean flag, polled each frame
 *
 * Discrete UI intents (pause, mute) are emitted by controllers directly
 * onto the EventBus, keeping the snapshot purely continuous.
 */
export class InputSystem {
  constructor() {
    /** @type {Array<{attach:Function, detach:Function, update:Function, enabled:boolean}>} */
    this._controllers = [];
    this._snapshot = { forward: 0, strafe: 0, lookDX: 0, lookDY: 0, firing: false, jump: false };
  }

  /**
   * @param {{attach:Function, detach:Function, update:Function, enabled:boolean}} c
   */
  addController(c) {
    this._controllers.push(c);
    return c;
  }

  attachAll() {
    this._controllers.forEach((c) => c.attach());
  }

  detachAll() {
    this._controllers.forEach((c) => c.detach());
  }

  /**
   * @param {number} dt seconds
   * @param {boolean} active when false, returns a neutral snapshot (paused/dead)
   * @returns {{forward:number, strafe:number, lookDX:number, lookDY:number, firing:boolean, jump:boolean}}
   */
  update(dt, active) {
    const out = this._snapshot;
    out.forward = 0; out.strafe = 0; out.lookDX = 0; out.lookDY = 0;
    out.firing = false; out.jump = false;
    if (!active) return out;

    for (let i = 0; i < this._controllers.length; i++) {
      const c = this._controllers[i];
      if (c.enabled) c.update(dt, out);
    }
    // Clamp accumulated values to sane ranges.
    out.forward = clamp(out.forward, -1, 1);
    out.strafe = clamp(out.strafe, -1, 1);
    out.firing = !!out.firing;
    out.jump = !!out.jump;
    return out;
  }
}

function clamp(v, lo, hi) {
  return v < lo ? lo : (v > hi ? hi : v);
}
