/**
 * MazeShooter · input/TouchController.js
 *
 * Mobile / tablet controls (Pointer Events, works for touch pens too):
 *
 *   - Left virtual joystick  -> movement (up = forward)
 *   - Right side drag        -> look (same lon/lat convention as mouse)
 *   - FIRE button            -> hold to fire
 *   - JUMP button            -> tap to loft the player into the air
 *
 * The DOM (joystick, nub, fire, jump, look pad) is static in game.html;
 * this class only binds behavior (SRP: input, not layout). The look pad is
 * a dedicated layer below the buttons, so touches on controls never leak
 * into look-drag.
 */
import { CONFIG } from '../core/Config.js';

export class TouchController {
  /** Coarse pointer or any touch capability; decides the mobile UI. */
  static isTouchDevice() {
    return (
      (window.matchMedia && window.matchMedia('(pointer: coarse)').matches) ||
      'ontouchstart' in window ||
      (navigator.maxTouchPoints || 0) > 0
    );
  }

  /**
   * @param {import('../core/EventBus.js').EventBus} bus
   * @param {{joystick:Element, nub:Element, lookPad:Element, fire:Element, jump:Element}} els
   */
  constructor(bus, els) {
    this._bus = bus;
    this._els = els;
    this.enabled = true;

    // Dependency-injected input state (mutated externally, read here):
    this.sensitivity = 1.0;
    this.invertY = false;

    this._joyId = null;       // pointerId owning the joystick
    this._joyVec = { x: 0, y: 0 };
    this._lookId = null;      // pointerId owning look-drag
    this._lookDX = 0;         // accumulated px since last frame
    this._lookDY = 0;
    this._firing = false;
    this._jumping = false;
    this._lastTouch = { x: 0, y: 0 };

    this._onJoyDown = this._onJoyDown.bind(this);
    this._onLookDown = this._onLookDown.bind(this);
    this._onMove = this._onMove.bind(this);
    this._onUp = this._onUp.bind(this);
    this._onFireDown = this._onFireDown.bind(this);
    this._onFireUp = this._onFireUp.bind(this);
    this._onJumpDown = this._onJumpDown.bind(this);
    this._onJumpUp = this._onJumpUp.bind(this);
  }

  attach() {
    this._els.joystick.addEventListener('pointerdown', this._onJoyDown, false);
    this._els.lookPad.addEventListener('pointerdown', this._onLookDown, false);
    document.addEventListener('pointermove', this._onMove, false);
    document.addEventListener('pointerup', this._onUp, false);
    document.addEventListener('pointercancel', this._onUp, false);
    this._els.fire.addEventListener('pointerdown', this._onFireDown, false);
    document.addEventListener('pointerup', this._onFireUp, false);
    document.addEventListener('pointercancel', this._onFireUp, false);
    this._els.jump.addEventListener('pointerdown', this._onJumpDown, false);
    document.addEventListener('pointerup', this._onJumpUp, false);
    document.addEventListener('pointercancel', this._onJumpUp, false);
  }

  detach() {
    this._els.joystick.removeEventListener('pointerdown', this._onJoyDown, false);
    this._els.lookPad.removeEventListener('pointerdown', this._onLookDown, false);
    document.removeEventListener('pointermove', this._onMove, false);
    document.removeEventListener('pointerup', this._onUp, false);
    document.removeEventListener('pointercancel', this._onUp, false);
    this._els.fire.removeEventListener('pointerdown', this._onFireDown, false);
    document.removeEventListener('pointerup', this._onFireUp, false);
    document.removeEventListener('pointercancel', this._onFireUp, false);
    this._els.jump.removeEventListener('pointerdown', this._onJumpDown, false);
    document.removeEventListener('pointerup', this._onJumpUp, false);
    document.removeEventListener('pointercancel', this._onJumpUp, false);
  }

  _onJoyDown(e) {
    if (this._joyId !== null) return;
    this._joyId = e.pointerId;
    this._updateJoy(e);
    e.preventDefault();
  }

  _onLookDown(e) {
    if (this._lookId !== null) return;
    this._lookId = e.pointerId;
    this._lastTouch.x = e.clientX;
    this._lastTouch.y = e.clientY;
    this._bus.emit('touch:engaged'); // first use may switch UI into touch mode
    e.preventDefault();
  }

  _onMove(e) {
    if (e.pointerId === this._joyId) this._updateJoy(e);
    else if (e.pointerId === this._lookId) {
      this._lookDX += e.clientX - this._lastTouch.x;
      this._lookDY += e.clientY - this._lastTouch.y;
      this._lastTouch.x = e.clientX;
      this._lastTouch.y = e.clientY;
    }
  }

  _onUp(e) {
    if (e.pointerId === this._joyId) {
      this._joyId = null;
      this._joyVec.x = 0;
      this._joyVec.y = 0;
      this._setNub(0, 0);
    } else if (e.pointerId === this._lookId) {
      this._lookId = null;
    }
  }

  _onFireDown(e) {
    this._firing = true;
    this._bus.emit('touch:engaged');
    e.preventDefault();
  }

  _onFireUp() {
    this._firing = false;
  }

  _onJumpDown(e) {
    this._jumping = true;
    this._bus.emit('touch:engaged');
    e.preventDefault();
  }

  _onJumpUp() {
    this._jumping = false;
  }

  _updateJoy(e) {
    const rect = this._els.joystick.getBoundingClientRect();
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;
    const R = CONFIG.touch.JOY_RADIUS;

    let dx = e.clientX - cx;
    let dy = e.clientY - cy;
    const len = Math.sqrt(dx * dx + dy * dy);
    if (len > R) { dx = dx / len * R; dy = dy / len * R; }

    this._joyVec.x = dx / R;
    this._joyVec.y = dy / R;
    this._setNub(dx, dy);
  }

  _setNub(dx, dy) {
    const nub = this._els.nub;
    nub.style.transform = 'translate(' + dx + 'px,' + dy + 'px)';
  }

  /**
   * @param {number} _dt
   * @param {{forward:number, strafe:number, lookDX:number, lookDY:number, firing:boolean, jump:boolean}} out
   */
  update(_dt, out) {
    const dead = CONFIG.touch.DEADZONE;
    let fx = -this._joyVec.y; // screen up = forward
    let sx = this._joyVec.x;
    const mag = Math.sqrt(fx * fx + sx * sx);
    if (mag > 0 && mag < dead) { fx = 0; sx = 0; }

    out.forward += fx;
    out.strafe += sx;

    const speed = CONFIG.gameplay.TOUCH_LOOKSPEED * this.sensitivity;
    const inv = this.invertY ? -1 : 1;
    out.lookDX += this._lookDX * speed;
    out.lookDY += -this._lookDY * speed * inv;
    this._lookDX = 0;
    this._lookDY = 0;

    out.firing = out.firing || this._firing;
    out.jump = out.jump || this._jumping;
  }
}
