/**
 * MazeShooter · input/KeyboardMouseController.js
 *
 * Desktop controller: WASD/arrows + Space loft, pointer-lock mouse look
 * (with graceful fallback to the boilerplate's hover-look) and
 * hold-left-button fire. Discrete intents (pause, mute) go onto the bus;
 * continuous input goes into the snapshot.
 */
import { CONFIG } from '../core/Config.js';

export class KeyboardMouseController {
  /**
   * @param {import('../core/EventBus.js').EventBus} bus
   * @param {Function} getCanvas () => renderer DOM element (for pointer lock)
   */
  constructor(bus, getCanvas) {
    this._bus = bus;
    this._getCanvas = getCanvas;
    this.enabled = true;

    this._keys = Object.create(null);
    this._movementX = 0;   // accumulated pointer-lock deltas since last frame
    this._movementY = 0;
    this._mouse = { x: 0, y: 0 }; // fallback hover-look offsets (px from center)
    this.pointerLocked = false;
    this.fallbackLook = false;
    this.everLocked = false;

    // Dependency-injected input state (mutated externally, read here):
    this.sensitivity = 1.0;
    this.invertY = false;

    this._onKeyDown = this._onKeyDown.bind(this);
    this._onKeyUp = this._onKeyUp.bind(this);
    this._onMouseMove = this._onMouseMove.bind(this);
    this._onMouseDown = this._onMouseDown.bind(this);
    this._onMouseUp = this._onMouseUp.bind(this);
    this._onLockChange = this._onLockChange.bind(this);
    this._onLockError = this._onLockError.bind(this);
    this._onContextMenu = (e) => e.preventDefault();
  }

  attach() {
    document.addEventListener('keydown', this._onKeyDown, false);
    document.addEventListener('keyup', this._onKeyUp, false);
    document.addEventListener('mousemove', this._onMouseMove, false);
    document.addEventListener('mousedown', this._onMouseDown, false);
    document.addEventListener('mouseup', this._onMouseUp, false);
    document.addEventListener('contextmenu', this._onContextMenu, false);
    document.addEventListener('pointerlockchange', this._onLockChange, false);
    document.addEventListener('pointerlockerror', this._onLockError, false);
  }

  detach() {
    document.removeEventListener('keydown', this._onKeyDown, false);
    document.removeEventListener('keyup', this._onKeyUp, false);
    document.removeEventListener('mousemove', this._onMouseMove, false);
    document.removeEventListener('mousedown', this._onMouseDown, false);
    document.removeEventListener('mouseup', this._onMouseUp, false);
    document.removeEventListener('contextmenu', this._onContextMenu, false);
    document.removeEventListener('pointerlockchange', this._onLockChange, false);
    document.removeEventListener('pointerlockerror', this._onLockError, false);
  }

  requestLock() {
    const canvas = this._getCanvas();
    if (canvas && canvas.requestPointerLock) {
      try {
        canvas.requestPointerLock();
      } catch (e) {
        this._enableFallback();
      }
    } else {
      this._enableFallback();
    }
  }

  _enableFallback() {
    if (this.fallbackLook) return;
    this.fallbackLook = true;
    this._bus.emit('look:fallback');
  }

  /** Public safety net: hover-look when pointer lock never engages. */
  enableFallback() {
    this._enableFallback();
  }

  _onLockChange() {
    this.pointerLocked = (document.pointerLockElement === this._getCanvas());
    if (this.pointerLocked) {
      this.everLocked = true;
    }
    this._bus.emit('pointerlock:changed', { locked: this.pointerLocked });
  }

  _onLockError() {
    if (!this.everLocked) this.enableFallback();
    else this._bus.emit('ui:toast', { text: 'Click again to capture the mouse', ms: 1800 });
  }

  _onKeyDown(e) {
    // Discrete intents (mute, pause) must fire once per physical press;
    // held-key auto-repeat would otherwise toggle them dozens of times
    // per second and spam the settings API.
    if (e.repeat) {
      if (e.keyCode === 32) e.preventDefault();
      return;
    }
    switch (e.keyCode) {
      case 38: case 87: this._keys.fwd = true; e.preventDefault(); break; // W / up
      case 40: case 83: this._keys.back = true; e.preventDefault(); break; // S / down
      case 37: case 65: this._keys.left = true; e.preventDefault(); break; // A / left
      case 39: case 68: this._keys.right = true; e.preventDefault(); break; // D / right
      case 32: this._keys.jump = true; e.preventDefault(); break;          // Space (loft)
      case 77: this._bus.emit('ui:toggleMute'); break;                     // M
      case 27: if (this.fallbackLook) this._bus.emit('ui:togglePause'); break; // ESC
    }
  }

  _onKeyUp(e) {
    switch (e.keyCode) {
      case 38: case 87: this._keys.fwd = false; break;
      case 40: case 83: this._keys.back = false; break;
      case 37: case 65: this._keys.left = false; break;
      case 39: case 68: this._keys.right = false; break;
      case 32: this._keys.jump = false; break;
    }
  }

  _onMouseMove(e) {
    if (this.pointerLocked) {
      this._movementX += e.movementX || 0;
      this._movementY += e.movementY || 0;
    } else if (this.fallbackLook) {
      this._mouse.x = e.clientX - window.innerWidth / 2;
      this._mouse.y = e.clientY - window.innerHeight / 2;
    }
  }

  _onMouseDown(e) {
    if (e.button === 0) this._mouse.down = true;
  }

  _onMouseUp(e) {
    if (e.button === 0) this._mouse.down = false;
  }

  /**
   * @param {number} dt
   * @param {{forward:number, strafe:number, lookDX:number, lookDY:number, firing:boolean, jump:boolean}} out
   */
  update(dt, out) {
    const k = this._keys;
    out.forward += (k.fwd ? 1 : 0) - (k.back ? 1 : 0);
    out.strafe += (k.right ? 1 : 0) - (k.left ? 1 : 0);

    const sens = this.sensitivity;
    const inv = this.invertY ? -1 : 1;
    if (this.pointerLocked) {
      out.lookDX += this._movementX * CONFIG.gameplay.LOOKSENS * sens;
      out.lookDY += -this._movementY * CONFIG.gameplay.LOOKSENS * sens * inv;
      this._movementX = 0;
      this._movementY = 0;
    } else if (this.fallbackLook) {
      // Original FirstPersonControls feel: continuous turn while the cursor
      // is off-center (delta * 60 normalizes to per-second speed).
      const speed = CONFIG.gameplay.FALLBACK_LOOKSPEED * dt * 60;
      out.lookDX += -this._mouse.x * speed * sens;
      out.lookDY += -this._mouse.y * speed * sens * inv;
    }

    out.firing = out.firing || !!this._mouse.down;
    out.jump = out.jump || !!k.jump;
  }
}
