/**
 * MazeShooter · Game.js
 *
 * The composition root (Dependency Inversion entry point): builds the world,
 * wires every system to its dependencies, owns the run lifecycle and routes
 * events. It contains no gameplay rules of its own, because those live in
 * the systems, and no rendering of its own, because that lives in the views.
 *
 * Run flow:
 *   prepare()  -> intro screen (+ settings pulled from the server)
 *   start()    -> world built, state=playing, loop running
 *   pause()/resume() / _die() / _win()  -> end screens + score submission
 *   restart    -> location.reload() (a fresh maze every run)
 */
import { CONFIG } from './core/Config.js';
import { GameState, GameStateMachine } from './core/GameStateMachine.js';
import { Maze } from './world/Maze.js';
import { TextureLib } from './world/TextureLib.js';
import { SceneFactory } from './world/SceneFactory.js';
import { Player } from './entities/Player.js';
import { Enemy } from './entities/Enemy.js';
import { ExitPortal } from './entities/ExitPortal.js';
import { CollisionWorld } from './physics/CollisionWorld.js';
import { InputSystem } from './input/InputSystem.js';
import { KeyboardMouseController } from './input/KeyboardMouseController.js';
import { TouchController } from './input/TouchController.js';
import { CombatSystem } from './systems/CombatSystem.js';
import { EnemyAISystem } from './systems/EnemyAISystem.js';
import { PickupSystem } from './systems/PickupSystem.js';
import { ScoreCalculator } from './services/ScoreCalculator.js';

export class Game {
  /**
   * @param {{
   *   bus: import('./core/EventBus.js').EventBus,
   *   loop: import('./core/GameLoop.js').GameLoop,
   *   states: GameStateMachine,
   *   sfx: import('./core/Sfx.js').Sfx,
   *   hud: import('./ui/HudView.js').HudView,
   *   radar: import('./ui/RadarView.js').RadarView,
   *   screens: import('./ui/Screens.js').Screens,
   *   input: InputSystem,
   *   identity: import('./services/PlayerIdentity.js').PlayerIdentity,
   *   settings: import('./services/SettingsService.js').SettingsService,
   *   leaderboard: import('./services/LeaderboardService.js').LeaderboardService,
   * }} deps
   */
  constructor(deps) {
    this.bus = deps.bus;
    this.loop = deps.loop;
    this.states = deps.states;
    this.sfx = deps.sfx;
    this.hud = deps.hud;
    this.radar = deps.radar;
    this.screens = deps.screens;
    this.input = deps.input;
    this.identity = deps.identity;
    this.settings = deps.settings;
    this.leaderboard = deps.leaderboard;

    // World (built in start()).
    this.maze = null;
    this.collision = null;
    this.scene = null;
    this.renderer = null;
    this.player = null;
    this.exit = null;
    /** @type {import('./entities/Enemy.js').Enemy[]} */
    this.enemies = [];
    this.combat = null;
    this.ai = null;
    this.pickups = null;

    this.playTime = 0;
    this._radarAccum = 0;
    this._touchMode = false;
    this._kbController = null;
    this._touchController = null;
    this._nextWaveAt = CONFIG.gameplay.WAVE_INTERVAL_MS;
    this._enemyGeo = null;
    this._enemySkin = null;
    this._textures = null;

    this._bindEvents();
  }

  /**
   * Create n hunters at open cells spread away from (awayX, awayZ) and
   * register them with the world. Used for the opening squad and for every
   * timed wave (single spawn path, DRY).
   * @param {number} n
   * @param {{x:number, z:number}} awayFrom cell to spawn away from
   */
  _spawnEnemies(n, awayFrom) {
    const w = CONFIG.world;
    const g = CONFIG.gameplay;
    // Hard ceiling: waves never push the alive count past MAX_ENEMIES,
    // which bounds the per-frame O(n^2) separation cost on long runs.
    const room = Math.max(0, g.MAX_ENEMIES - this.enemies.length);
    if (room === 0) return;
    const cells = this.maze.pickOpenCells(awayFrom.x, awayFrom.z, Math.min(n, room), 8);
    if (!this._enemyGeo) {
      this._enemyGeo = new THREE.BoxGeometry(55, 55, 55);
      this._enemySkin = new THREE.MeshBasicMaterial({ color: 0x1a1a24 });
    }
    for (let i = 0; i < cells.length; i++) {
      const faceMat = new THREE.MeshBasicMaterial({ map: this._textures.get('face.png') });
      const mats = [this._enemySkin, this._enemySkin, this._enemySkin, this._enemySkin, faceMat, this._enemySkin]; // +z (index 4) carries the face
      const mesh = new THREE.Mesh(this._enemyGeo, mats);
      mesh.position.set(this.maze.centerX(cells[i].x), 60, this.maze.centerZ(cells[i].z));
      this.scene.add(mesh);
      this.enemies.push(new Enemy(mesh, g.AI_HEALTH, g.AI_SHOOT_COOLDOWN + Math.floor(Math.random() * 450)));
    }
    this.hud.syncEnemyBudget(this.enemies.length);
  }

  // ------------------------------------------------------------------
  // Wiring
  // ------------------------------------------------------------------

  _bindEvents() {
    this.bus.on('combat:enemyKilled', (p) => this._onEnemyKilled(p.enemy));
    this.bus.on('combat:playerDamaged', () => {
      this.sfx.hurt();
      this.hud.hurtFlash();
    });
    this.bus.on('combat:enemyDamaged', () => { this.sfx.hit(); this.hud.crosshairHit(); });
    this.bus.on('combat:enemyShoot', () => this.sfx.enemyShoot());
    this.bus.on('combat:playerDead', () => this._die());
    this.bus.on('pack:collected', (p) => {
      this.sfx.pickup();
      this.hud.showMsg('+' + p.heal + ' HEALTH', 1200);
    });
    this.bus.on('pointerlock:changed', (p) => {
      if (p.locked && this.states.is(GameState.PAUSED)) this.resume();
      else if (!p.locked && this.states.is(GameState.PLAYING) && !this._touchMode) this.pause();
    });
    this.bus.on('look:fallback', () => {
      if (this._touchMode) return; // touch look owns aiming, so no toast is needed
      this.hud.showMsg('Pointer lock unavailable, so hover look is enabled', 2500);
    });
    this.bus.on('ui:togglePause', () => {
      if (this.states.is(GameState.PLAYING)) this.pause();
      else if (this.states.is(GameState.PAUSED)) this.resume();
    });
    this.bus.on('ui:toggleMute', () => this._toggleMute());
    // Controllers emit ui:toast for hints the HUD should surface
    // (e.g. "Click again to capture the mouse" after a lock error).
    this.bus.on('ui:toast', (p) => {
      if (p && p.text) this.hud.showMsg(p.text, p.ms || 1600);
    });
    this.bus.on('touch:engaged', () => this._enableTouchMode());

    window.addEventListener('resize', () => this._onResize());
    window.addEventListener('orientationchange', () => setTimeout(() => this._onResize(), 250));
  }

  /** Pull remote settings, reflect identity + touch mode into the intro. */
  async prepare() {
    this.screens.renderName(this.identity.name);
    this._touchMode = TouchController.isTouchDevice();
    this.screens.setTouchMode(this._touchMode);
    try {
      await this.settings.load(this.identity.playerId);
    } catch (e) {
      // Not offline-first: the game still runs with defaults when the API
      // is unreachable; online features degrade gracefully.
    }
    this._applySettings(this.settings.current);
    this.screens.renderSettings(this.settings.current);
  }

  _applySettings(s) {
    if (this._kbController) {
      this._kbController.sensitivity = s.lookSensitivity;
      this._kbController.invertY = !!s.invertY;
    }
    if (this._touchController) {
      this._touchController.sensitivity = s.lookSensitivity;
      this._touchController.invertY = !!s.invertY;
    }
    this.sfx.setMuted(!s.soundOn);
    this.radar.setVisible(!!s.showRadar);
  }

  /** Public: re-apply the given settings snapshot (used by the intro UI). */
  applySettings(s) {
    this.settings._values = Object.assign({}, this.settings.current, s);
    this._applySettings(this.settings.current);
  }

  // ------------------------------------------------------------------
  // Lifecycle
  // ------------------------------------------------------------------

  start() {
    if (this.states.current !== GameState.INTRO) return;
    this.sfx.init(); // must run inside the click gesture (autoplay policy)

    // Note: the display tag is owned by the intro field's change handler
    // (server-first save in bootstrap.js); start() deliberately does not
    // commit names itself, so a run can never carry a tag the server
    // has not accepted (or that another player already owns).
    try {
      this._buildWorld();
    } catch (err) {
      console.error('[game] world build failed', err);
      this.screens.showFatalError('WebGL unavailable: ' + err.message);
      return;
    }

    this.states.transition(GameState.PLAYING);
    this.screens.hideIntro();
    this.loop.onUpdate((dt) => this._onFrame(dt));
    this.loop.start();

    if (!this._touchMode) {
      this._kbController.requestLock();
      // Safety net: if lock never engages, hover-look keeps aiming usable.
      setTimeout(() => {
        if (this._touchMode) return; // touch took over meanwhile
        if (!this._kbController.pointerLocked && !this._kbController.fallbackLook &&
            this.states.is(GameState.PLAYING)) {
          this._kbController.enableFallback();
        }
      }, 1500);
    }
  }

  _buildWorld() {
    const w = CONFIG.world;
    const g = CONFIG.gameplay;
    const WIDTH = window.innerWidth;
    const HEIGHT = window.innerHeight;

    // --- World model ---
    this.maze = Maze.generate(w.MAPW, w.MAPH, w.MAZE_LOOPS, w.UNITSIZE);
    this.collision = new CollisionWorld(this.maze);
    this.radar.setMaze(this.maze);
    this._textures = new TextureLib('./images');

    // --- Renderer & camera ---
    this.scene = new THREE.Scene();
    const built = new SceneFactory(this.maze, this._textures, w).build();
    this.scene = built.scene;

    const cam = new THREE.PerspectiveCamera(70, WIDTH / HEIGHT, 1, 10000);
    cam.position.set(
      this.maze.centerX(w.SPAWN_CELL.x), w.EYE_HEIGHT, this.maze.centerZ(w.SPAWN_CELL.z)
    );
    this.scene.add(cam);
    cam.add(built.torch);

    this.renderer = new THREE.WebGLRenderer({ antialias: true });
    this.renderer.setSize(WIDTH, HEIGHT);
    this.renderer.setClearColor(0x05060a, 1);
    this.renderer.domElement.id = 'game-canvas';
    this.renderer.domElement.style.backgroundColor = '#05060a';
    document.body.appendChild(this.renderer.domElement);
    // r128 handles MSAA correctly on modern ANGLE/Vulkan stacks (r49 did not).

    // --- Player ---
    this.player = new Player(cam, this.collision, {
      EYE_HEIGHT: w.EYE_HEIGHT,
      PLAYER_RADIUS: w.PLAYER_RADIUS,
      MOVESPEED: g.MOVESPEED,
      JUMP_SPEED: g.JUMP_SPEED,
      GRAVITY: g.GRAVITY,
    });
    this.player.kills = 0;
    this.player.orientToOpenCorridor(w.SPAWN_CELL, this.maze);

    // --- Objective ---
    this.exit = this._createExit();

    // --- Opening squad of hunters ---
    this._spawnEnemies(g.NUMAI, w.SPAWN_CELL);

    // --- Systems ---
    this.combat = new CombatSystem(this.scene, this.player, this.bus);
    this.combat.setEnemies(this.enemies);
    this.ai = new EnemyAISystem(
      this.enemies, this.player, this.maze, this.collision, this.combat, this.bus
    );
    this.pickups = new PickupSystem(
      this.scene, this.maze, this._textures, this.player, this.bus, w.SPAWN_CELL
    );

    // --- Input ---
    this._kbController = new KeyboardMouseController(this.bus, () => this.renderer.domElement);
    this._touchController = new TouchController(this.bus, {
      joystick: document.querySelector('#joy'),
      nub: document.querySelector('#joy-nub'),
      lookPad: document.querySelector('#look-pad'),
      fire: document.querySelector('#fire-btn'),
      jump: document.querySelector('#jump-btn'),
    });
    this._touchController.enabled = this._touchMode;
    this.input.addController(this._kbController);
    this.input.addController(this._touchController);
    this.input.attachAll();
    this._applySettings(this.settings.current);
  }

  _createExit() {
    const spawn = CONFIG.world.SPAWN_CELL;
    const cell = this.maze.farthestCell(spawn.x, spawn.z);
    const portal = new THREE.Mesh(
      new THREE.BoxGeometry(150, 280, 150),
      new THREE.MeshBasicMaterial({ color: 0xff2222, transparent: true, opacity: 0.3 })
    );
    portal.position.set(this.maze.centerX(cell.x), 140, this.maze.centerZ(cell.z));
    const core = new THREE.Mesh(
      new THREE.BoxGeometry(55, 55, 55),
      new THREE.MeshBasicMaterial({ color: 0xff6666, wireframe: true })
    );
    core.position.copy(portal.position);
    const light = new THREE.PointLight(0xff3333, 1.6, 1100);
    light.position.set(portal.position.x, 220, portal.position.z);
    this.scene.add(portal, core, light);
    return new ExitPortal(portal, core, light, { x: cell.x, z: cell.z });
  }

  pause() {
    if (!this.states.transition(GameState.PAUSED)) return;
    this.screens.showPause();
  }

  resume() {
    if (!this.states.transition(GameState.PLAYING)) return;
    this.screens.hidePause();
    if (!this._touchMode && !this._kbController.pointerLocked && !this._kbController.fallbackLook) {
      this._kbController.requestLock();
    }
  }

  _onEnemyKilled(enemy) {
    const idx = this.enemies.indexOf(enemy);
    if (idx === -1) return;
    this.scene.remove(enemy.mesh);
    // Free the per-enemy face material (the body material is shared and
    // stays alive for the whole run, so it must NOT be disposed).
    const mats = enemy.mesh.material;
    if (Array.isArray(mats)) {
      mats.forEach((m) => {
        if (m && m !== this._enemySkin && typeof m.dispose === 'function') m.dispose();
      });
    }
    this.enemies.splice(idx, 1);
    this.player.kills++;
    this.sfx.enemyDie();
    if (this.enemies.length === 0 && !this.exit.unlocked) {
      this.exit.unlock();
      this.sfx.unlock();
      this.hud.showMsg('ALL HUNTERS DOWN, EXIT UNLOCKED, RUN!', 3000);
      this.hud.showExitCompass(true);
    }
  }

  /**
   * Wave timer: while the exit is still locked, drop WAVE_SIZE extra
   * hunters into the maze every WAVE_INTERVAL_MS of play. Waves stop once
   * the exit opens, so the run to the exit stays winnable.
   * @param {number} dt
   */
  _updateWaves(dt) {
    if (this.exit.unlocked) return;
    if (this.playTime * 1000 < this._nextWaveAt) return;
    this._nextWaveAt += CONFIG.gameplay.WAVE_INTERVAL_MS;
    const pc = this.maze.sectorOf(this.player.position.x, this.player.position.z);
    this._spawnEnemies(CONFIG.gameplay.WAVE_SIZE, pc);
    this.sfx.wave();
    this.hud.showMsg(CONFIG.gameplay.WAVE_SIZE + ' MORE HUNTERS ENTERED THE MAZE!', 2400);
  }

  _die() {
    if (!this.states.transition(GameState.DEAD)) return;
    this._endCommon();
    this.sfx.lose();
    this.hud.hideForEndScreen();
    this.screens.showDeath(this._statsLine());
    this._submitRun(false, 'dead');
  }

  _win() {
    if (!this.states.transition(GameState.WON)) return;
    this._endCommon();
    this.sfx.win();
    this.hud.hideForEndScreen();
    const score = ScoreCalculator.finalScore({
      kills: this.player.kills, seconds: this.playTime, health: this.player.health, won: true,
    });
    this.screens.showWin(this._statsLine(), score);
    this._submitRun(true, 'win');
  }

  _endCommon() {
    this.input.detachAll();
    if (document.exitPointerLock) document.exitPointerLock();
  }

  _statsLine() {
    const p = this.player;
    const acc = p.accuracy();
    return 'Kills ' + p.kills +
      ' · Survived ' + ScoreCalculator.formatTime(this.playTime) +
      ' · Accuracy ' + (acc === null ? 'n/a' : acc + '%');
  }

  /**
   * Build the score entry from player stats and push it online.
   * @param {boolean} won
   * @param {'dead'|'win'} which end screen
   */
  _submitRun(won, which) {
    const score = ScoreCalculator.finalScore({
      kills: this.player.kills, seconds: this.playTime, health: this.player.health, won,
    });
    const entry = {
      playerId: this.identity.playerId,
      name: this.identity.displayName(),
      score,
      kills: this.player.kills,
      seconds: this.playTime,
      shotsFired: this.player.shotsFired,
      shotsHit: this.player.shotsHit,
      healthLeft: this.player.health,
      won,
    };
    this.leaderboard.submitRun(entry)
      .then((res) => {
        this.screens.renderSubmission(which, {
          status: 'Score saved',
          rank: res.rank,
          ownId: res.id,
        }, res.leaderboard);
      })
      .catch((err) => {
        this.screens.renderSubmission(which, {
          status: err && err.isOffline ? 'Leaderboard unavailable (offline)' : 'Score not saved: ' + err.message,
        });
      });
  }

  _toggleMute() {
    const next = !this.settings.get('soundOn');
    this.sfx.setMuted(!next);
    this.hud.showMsg(next ? 'SOUND ON' : 'SOUND OFF', 900);
    this.screens.renderSettings(Object.assign(this.settings.current, { soundOn: next }));
    this.settings.save(this.identity.playerId, { soundOn: next }).catch(() => {});
  }

  _enableTouchMode() {
    if (this._touchMode) return;
    this._touchMode = true;
    this.screens.setTouchMode(true);
    if (this._touchController) this._touchController.enabled = true;
  }

  // ------------------------------------------------------------------
  // Frame
  // ------------------------------------------------------------------

  _onFrame(dt) {
    if (this.states.is(GameState.PLAYING)) {
      this.playTime += dt;
      this._step(dt);
    } else {
      // Keep the world alive visually (portal pulse) behind overlays.
      this.exit.update(dt, Date.now());
    }
    this.renderer.render(this.scene, this.player.camera);
  }

  _step(dt) {
    const now = Date.now();
    const g = CONFIG.gameplay;

    // Input -> player.
    const snap = this.input.update(dt, true);
    this.player.applyLook(snap.lookDX, snap.lookDY);
    this.player.updateOrientation();
    this.player.move(snap.forward, snap.strafe, dt);

    // Loft: liftoff when the input asks for it, gravity the rest of the way.
    if (snap.jump && this.player.jump()) this.sfx.jump();
    if (this.player.updateVertical(dt)) this.sfx.land();

    // Shooting.
    if (this.combat.tryShoot(snap.firing, now)) this.sfx.shoot();

    // Systems.
    this.ai.update(dt, now);
    this.combat.update(dt, this.maze);
    this.pickups.update(dt, now);
    this.exit.update(dt, now);
    this._updateWaves(dt);

    // Objective check.
    if (this.exit.unlocked) {
      const c = this.maze.sectorOf(this.player.position.x, this.player.position.z);
      if (c.x === this.exit.cell.x && c.z === this.exit.cell.z) {
        this._win();
        return;
      }
    }

    // HUD + throttled radar.
    this.hud.update({
      health: this.player.health,
      kills: this.player.kills,
      enemies: this.enemies.length,
      seconds: this.playTime,
    });
    this._radarAccum += dt;
    if (this._radarAccum > 0.25) {
      this._radarAccum = 0;
      this._drawRadar();
      if (this.exit.unlocked) this.hud.updateExitCompass(this.player, this.exit.position);
    }
  }

  _drawRadar() {
    this.radar.draw({
      playerWorld: { x: this.player.position.x, z: this.player.position.z },
      lon: this.player.lon,
      enemies: this.enemies.map((e) => e.position),
      packs: this.pickups.packs.filter((p) => p.active).map((p) => p.position),
      exitCell: this.exit.cell,
      exitUnlocked: this.exit.unlocked,
    });
  }

  _onResize() {
    if (!this.renderer) return;
    const WIDTH = window.innerWidth;
    const HEIGHT = window.innerHeight;
    this.player.camera.aspect = WIDTH / HEIGHT;
    this.player.camera.updateProjectionMatrix();
    this.renderer.setSize(WIDTH, HEIGHT);
  }
}
