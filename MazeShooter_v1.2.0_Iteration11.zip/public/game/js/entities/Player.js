/**
 * MazeShooter · entities/Player.js
 *
 * The camera rig + player state. Responsibilities: orientation math
 * (the boilerplate's proven lon/lat -> lookAt convention), input-driven
 * movement through the CollisionWorld, vertical loft physics (jump arc
 * with gravity, grounded on the eye height), health and accuracy stats.
 * Rendering, shooting decisions and damage consequences belong elsewhere.
 */
export class Player {
  /**
   * @param {THREE.PerspectiveCamera} camera
   * @param {import('../physics/CollisionWorld.js').CollisionWorld} collision
   * @param {{EYE_HEIGHT:number, PLAYER_RADIUS:number, MOVESPEED:number, JUMP_SPEED:number, GRAVITY:number}} cfg
   */
  constructor(camera, collision, cfg) {
    this.camera = camera;
    this._collision = collision;
    this._cfg = cfg;

    this.health = 100;
    this.kills = 0;
    this.lon = 0;   // yaw degrees (FirstPersonControls convention)
    this.lat = 0;   // pitch degrees
    this.shotsFired = 0;
    this.shotsHit = 0;

    // Loft state: the eye rests at EYE_HEIGHT and rises while airborne.
    this.grounded = true;
    this._vy = 0;

    /** @type {THREE.Vector3} scratch target for lookAt */
    this._lookTarget = new THREE.Vector3();
  }

  get position() {
    return this.camera.position;
  }

  /**
   * Face an open corridor at spawn (avoids staring into a wall).
   * @param {{x:number,z:number}} cell
   * @param {import('../world/Maze.js').Maze} maze
   */
  orientToOpenCorridor(cell, maze) {
    let dx = 1, dz = 0;
    if (!maze.isWall(cell.x, cell.z + 1)) { dx = 0; dz = 1; }
    this.lon = Math.atan2(dz, dx) * 180 / Math.PI;
  }

  /**
   * Apply a look delta in degrees (already sensitivity- and invert-adjusted
   * by the input layer).
   */
  applyLook(dLon, dLat) {
    this.lon += dLon;
    this.lat += dLat;
    this.lat = Math.max(-85, Math.min(85, this.lat));
  }

  /**
   * Move by a normalized (forward, strafe) input vector.
   * @param {number} forward -1..1
   * @param {number} strafe -1..1
   * @param {number} dt seconds
   */
  move(forward, strafe, dt) {
    const theta = this.lon * Math.PI / 180;
    const fX = Math.cos(theta), fZ = Math.sin(theta);
    const rX = -fZ, rZ = fX;
    let mx = fX * forward + rX * strafe;
    let mz = fZ * forward + rZ * strafe;
    const len = Math.sqrt(mx * mx + mz * mz);
    if (len > 0.001) {
      mx /= len; mz /= len;
      this._collision.moveWithCollision(
        this.camera.position,
        mx * this._cfg.MOVESPEED * dt,
        mz * this._cfg.MOVESPEED * dt,
        this._cfg.PLAYER_RADIUS
      );
    }
  }

  /**
   * Lift off when grounded (hold-to-hop is fine; only liftoff is gated).
   * @returns {boolean} true when this call actually started a jump
   */
  jump() {
    if (!this.grounded) return false;
    this.grounded = false;
    this._vy = this._cfg.JUMP_SPEED;
    return true;
  }

  /**
   * Integrate the loft arc: rise, fall, and clamp onto the ground plane.
   * Horizontal collision never changes, so walls stay solid mid-air.
   * @param {number} dt seconds
   * @returns {boolean} true on the frame the player lands
   */
  updateVertical(dt) {
    if (this.grounded) return false;
    const p = this.camera.position;
    this._vy -= this._cfg.GRAVITY * dt;
    p.y += this._vy * dt;
    if (p.y <= this._cfg.EYE_HEIGHT) {
      p.y = this._cfg.EYE_HEIGHT;
      this._vy = 0;
      this.grounded = true;
      return true;
    }
    return false;
  }

  /** Orientation math (boilerplate lon/lat -> lookAt). */
  updateOrientation() {
    const phi = (90 - this.lat) * Math.PI / 180;
    const theta = this.lon * Math.PI / 180;
    const p = this.camera.position;
    this._lookTarget.set(
      p.x + 100 * Math.sin(phi) * Math.cos(theta),
      p.y + 100 * Math.cos(phi),
      p.z + 100 * Math.sin(phi) * Math.sin(theta)
    );
    this.camera.lookAt(this._lookTarget);
  }

  /**
   * World-space aim direction (camera looks down its local -Z) plus a
   * muzzle origin slightly in front of the eye.
   * @returns {{origin: THREE.Vector3, dir: THREE.Vector3}}
   */
  getAim() {
    this.camera.updateMatrixWorld();
    const el = this.camera.matrixWorld.elements;
    const dir = new THREE.Vector3(-el[8], -el[9], -el[10]).normalize();
    const origin = new THREE.Vector3(
      this.camera.position.x + dir.x * 30,
      this.camera.position.y + dir.y * 30 - 8,
      this.camera.position.z + dir.z * 30
    );
    return { origin, dir };
  }

  applyDamage(amount) {
    this.health = Math.max(0, this.health - amount);
  }

  heal(amount) {
    this.health = Math.min(100, this.health + amount);
  }

  registerShot() { this.shotsFired++; }
  registerHit()  { this.shotsHit++; }

  accuracy() {
    if (!this.shotsFired) return null;
    return Math.round((this.shotsHit / this.shotsFired) * 100);
  }
}
