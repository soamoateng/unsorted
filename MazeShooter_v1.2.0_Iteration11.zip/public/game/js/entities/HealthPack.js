/**
 * MazeShooter · entities/HealthPack.js
 *
 * Rotating health pickup with timed respawn (boilerplate's health.png).
 * Placement/relocation is the PickupSystem's job; this class only knows
 * its own state and animation.
 */
export class HealthPack {
  /**
   * @param {THREE.Mesh} mesh
   * @param {number} index stable index (animation phase offset)
   */
  constructor(mesh, index) {
    this.mesh = mesh;
    this.index = index;
    this.active = true;
    this.respawnAt = 0;
  }

  get position() {
    return this.mesh.position;
  }

  deactivate(respawnDelayMs) {
    this.active = false;
    this.respawnAt = Date.now() + respawnDelayMs;
    this.mesh.position.y = -500; // hide below the floor
  }

  respawnAtCell(cell, maze) {
    this.mesh.position.set(maze.centerX(cell.x), 46, maze.centerZ(cell.z));
    this.active = true;
  }

  update(_dt, now) {
    if (!this.active) return;
    this.mesh.rotation.y += 0.027; // ~1.6 rad/s at 60fps frames
    this.mesh.position.y = 46 + Math.sin(now * 0.003 + this.index) * 7;
  }
}
