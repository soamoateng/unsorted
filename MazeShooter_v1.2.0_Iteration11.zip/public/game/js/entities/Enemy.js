/**
 * MazeShooter · entities/Enemy.js
 *
 * A hunter cube carrying the boilerplate's face.png. Holds its own vitals
 * and A* navigation state; the AI system drives it.
 */
export class Enemy {
  /**
   * @param {THREE.Mesh} mesh mesh with face material at index 4 (+z)
   * @param {number} health
   * @param {number} shootDelay individualized fire cooldown (ms)
   */
  constructor(mesh, health, shootDelay) {
    this.mesh = mesh;
    this.health = health;
    this.maxHealth = health;
    this.faceMat = mesh.material[4];

    // Navigation state (owned here, driven by EnemyAISystem).
    this.path = [];
    this.nodeIdx = 1;
    this.lastPath = 0;
    this.lastShot = Date.now() + Math.floor(Math.random() * 900);
    this.shootDelay = shootDelay;
    this.lastPos = mesh.position.clone();
    this.lastStuckCheck = Date.now();
  }

  get position() {
    return this.mesh.position;
  }

  get dead() {
    return this.health <= 0;
  }

  /** @returns {boolean} true when this hit was lethal */
  takeDamage(amount) {
    this.health -= amount;
    const pct = Math.max(this.health, 0) / this.maxHealth;
    this.faceMat.color.setRGB(pct, pct * 0.85, pct * 0.85);
    return this.dead;
  }

  faceTowards(point, y) {
    this.mesh.lookAt(new THREE.Vector3(point.x, y, point.z));
  }
}
