/**
 * MazeShooter · entities/Bullet.js
 *
 * A projectile with velocity and time-to-live. Owner is 'player' | 'enemy'
 * (CombatSystem uses it to route damage).
 */
export class Bullet {
  /**
   * @param {THREE.Mesh} mesh
   * @param {'player'|'enemy'} owner
   * @param {THREE.Vector3} position
   * @param {THREE.Vector3} direction normalized
   * @param {number} speed units/s
   * @param {number} ttlMs
   */
  constructor(mesh, owner, position, direction, speed, ttlMs) {
    this.mesh = mesh;
    this.owner = owner;
    this.mesh.position.copy(position);
    this.vel = new THREE.Vector3(
      direction.x * speed, direction.y * speed, direction.z * speed
    );
    this.born = Date.now();
    this.ttlMs = ttlMs;
  }

  get position() {
    return this.mesh.position;
  }

  get expired() {
    return Date.now() - this.born > this.ttlMs;
  }

  /** Integrate one frame; returns false when it flew into a wall. */
  advance(dt, maze) {
    const p = this.mesh.position;
    p.x += this.vel.x * dt;
    p.y += this.vel.y * dt;
    p.z += this.vel.z * dt;
    return !maze.isWallAtWorld(p.x, p.z);
  }
}
