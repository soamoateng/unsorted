/**
 * MazeShooter · entities/ExitPortal.js
 *
 * The objective: a translucent portal + wireframe core + point light at the
 * farthest maze cell. Starts locked (red); unlock() turns it green when the
 * last enemy dies.
 */
export class ExitPortal {
  /**
   * @param {THREE.Mesh} portal
   * @param {THREE.Mesh} core
   * @param {THREE.PointLight} light
   * @param {{x:number,z:number}} cell
   */
  constructor(portal, core, light, cell) {
    this.portal = portal;
    this.core = core;
    this.light = light;
    this.cell = cell;
    this.unlocked = false;
  }

  get position() {
    return this.portal.position;
  }

  unlock() {
    if (this.unlocked) return;
    this.unlocked = true;
    this.portal.material.color.setHex(0x33ff55);
    this.core.material.color.setHex(0x88ffaa);
    this.light.color.setHex(0x33ff55);
  }

  update(dt, now) {
    // Bold pulse so the outlet is easy to spot across a dark maze.
    this.portal.material.opacity = 0.38 + 0.18 * Math.sin(now * 0.004);
    this.core.rotation.y += dt * 1.2;
    this.core.rotation.x += dt * 0.7;
  }
}
