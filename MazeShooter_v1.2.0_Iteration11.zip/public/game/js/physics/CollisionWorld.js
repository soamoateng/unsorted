/**
 * MazeShooter · physics/CollisionWorld.js
 *
 * Radius-based wall collision with axis-separated sliding (extracted
 * verbatim from the boilerplate heritage code, so the player never gets
 * stuck on corners). Single responsibility: "may I be there / move there?"
 */
export class CollisionWorld {
  /**
   * @param {import('../world/Maze.js').Maze} maze
   */
  constructor(maze) {
    this._maze = maze;
  }

  isWallAtWorld(x, z) {
    return this._maze.isWallAtWorld(x, z);
  }

  /** Any corner of a radius-r box centered at (x,z) inside a wall. */
  collides(x, z, r) {
    const m = this._maze;
    return (
      m.isWallAtWorld(x - r, z - r) || m.isWallAtWorld(x + r, z - r) ||
      m.isWallAtWorld(x - r, z + r) || m.isWallAtWorld(x + r, z + r)
    );
  }

  /**
   * Move with wall sliding: try X and Z axes independently.
   * @param {THREE.Vector3} pos mutated in place
   */
  moveWithCollision(pos, dx, dz, r) {
    const nx = pos.x + dx;
    if (!this.collides(nx, pos.z, r)) pos.x = nx;
    const nz = pos.z + dz;
    if (!this.collides(pos.x, nz, r)) pos.z = nz;
  }
}
