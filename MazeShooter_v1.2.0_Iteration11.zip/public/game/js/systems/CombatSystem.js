/**
 * MazeShooter · systems/CombatSystem.js
 *
 * Owns bullets and hit resolution (single responsibility). Spawns player
 * and enemy projectiles, integrates them, routes damage via events:
 *
 *   combat:enemyDamaged {enemy, killed}
 *   combat:enemyKilled  {enemy}
 *   combat:playerDamaged {amount, health}
 *   combat:playerDead
 *
 * Depends on abstractions injected at construction (DIP): CollisionWorld /
 * Maze come in through the ctx, the bullet visuals through this module's
 * tiny factory.
 */
import { Bullet } from '../entities/Bullet.js';
import { CONFIG } from '../core/Config.js';

export class CombatSystem {
  /**
   * @param {THREE.Scene} scene
   * @param {import('../entities/Player.js').Player} player
   * @param {import('../core/EventBus.js').EventBus} bus
   */
  constructor(scene, player, bus) {
    this._scene = scene;
    this._player = player;
    this._bus = bus;
    /** @type {Bullet[]} */
    this._bullets = [];
    this._lastShotAt = 0;

    this._geo = new THREE.SphereGeometry(9, 6, 6);
    this._mats = {
      player: new THREE.MeshBasicMaterial({ color: 0xffd24a }),
      enemy: new THREE.MeshBasicMaterial({ color: 0xff4444 }),
    };
  }

  /** @param {import('../entities/Enemy.js').Enemy[]} enemies */
  setEnemies(enemies) {
    this._enemies = enemies;
  }

  get bulletCount() {
    return this._bullets.length;
  }

  /**
   * Hold-to-fire with cooldown. Returns true when a shot went out.
   * @param {boolean} firing raw input
   * @param {number} now
   */
  tryShoot(firing, now) {
    if (!firing || now < this._lastShotAt + CONFIG.gameplay.FIRE_COOLDOWN) return false;
    this._lastShotAt = now;
    const aim = this._player.getAim();
    this.spawn('player', aim.origin, aim.dir, CONFIG.gameplay.PLAYER_BULLET_SPEED);
    this._player.registerShot();
    return true;
  }

  /**
   * @param {'player'|'enemy'} owner
   * @param {THREE.Vector3} origin
   * @param {THREE.Vector3} dir normalized
   * @param {number} speed
   */
  spawn(owner, origin, dir, speed) {
    const mesh = new THREE.Mesh(this._geo, this._mats[owner]);
    const bullet = new Bullet(
      mesh, owner, origin, dir, speed, CONFIG.gameplay.BULLET_TTL_MS
    );
    this._bullets.push(bullet);
    this._scene.add(mesh);
    return bullet;
  }

  _despawn(index) {
    this._scene.remove(this._bullets[index].mesh);
    this._bullets.splice(index, 1);
  }

  /**
   * @param {number} dt
   * @param {import('../world/Maze.js').Maze} maze
   */
  update(dt, maze) {
    for (let i = this._bullets.length - 1; i >= 0; i--) {
      const b = this._bullets[i];
      if (b.expired || !b.advance(dt, maze)) {
        this._despawn(i);
        continue;
      }

      if (b.owner === 'player') {
        if (this._hitEnemy(b)) this._despawn(i);
      } else if (this._hitPlayer(b)) {
        this._despawn(i);
      }
    }
  }

  _hitEnemy(bullet) {
    const p = bullet.position;
    for (let j = 0; j < this._enemies.length; j++) {
      const e = this._enemies[j];
      const ep = e.position;
      if (
        Math.abs(p.x - ep.x) < 34 && Math.abs(p.z - ep.z) < 34 &&
        Math.abs(p.y - ep.y) < 44
      ) {
        this._player.registerHit();
        const killed = e.takeDamage(CONFIG.gameplay.PROJECTILEDAMAGE);
        this._bus.emit('combat:enemyDamaged', { enemy: e, killed });
        if (killed) this._bus.emit('combat:enemyKilled', { enemy: e });
        return true;
      }
    }
    return false;
  }

  _hitPlayer(bullet) {
    const p = bullet.position;
    const c = this._player.position;
    const dxz = Math.sqrt((p.x - c.x) * (p.x - c.x) + (p.z - c.z) * (p.z - c.z));
    if (dxz < 40 && Math.abs(p.y - c.y) < 60) {
      this._player.applyDamage(CONFIG.gameplay.ENEMYPROJECTILEDAMAGE);
      this._bus.emit('combat:playerDamaged', { amount: CONFIG.gameplay.ENEMYPROJECTILEDAMAGE, health: this._player.health });
      if (this._player.health <= 0) this._bus.emit('combat:playerDead');
      return true;
    }
    return false;
  }

  clear() {
    while (this._bullets.length) this._despawn(0);
  }
}
