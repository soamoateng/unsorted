/**
 * MazeShooter · systems/EnemyAISystem.js
 *
 * Drives the hunters: periodic A* repathing, node following, attack mode
 * inside range, anti-stuck rerouting and pairwise separation. All state
 * lives on the Enemy entities; this system is the behavior (SRP).
 */
import { CONFIG } from '../core/Config.js';
import { PathfinderAdapter } from './PathfinderAdapter.js';

export class EnemyAISystem {
  /**
   * @param {import('../entities/Enemy.js').Enemy[]} enemies
   * @param {import('../entities/Player.js').Player} player
   * @param {import('../world/Maze.js').Maze} maze
   * @param {import('../physics/CollisionWorld.js').CollisionWorld} collision
   * @param {import('./CombatSystem.js').CombatSystem} combat
   * @param {import('../core/EventBus.js').EventBus} bus
   * @param {object} [pathfinder] defaults to PathfinderAdapter (injectable for tests)
   */
  constructor(enemies, player, maze, collision, combat, bus, pathfinder) {
    this._enemies = enemies;
    this._player = player;
    this._maze = maze;
    this._collision = collision;
    this._combat = combat;
    this._bus = bus;
    this._pathfinder = pathfinder || new PathfinderAdapter();
    this._scratch = new THREE.Vector3();
  }

  /** @returns {Array<number[]>} path from an enemy to the player's sector */
  _pathFor(enemy) {
    const from = this._maze.sectorOf(enemy.position.x, enemy.position.z);
    const to = this._maze.sectorOf(this._player.position.x, this._player.position.z);
    return this._pathfinder.findPath(this._maze, from, to);
  }

  /**
   * @param {number} dt
   * @param {number} now
   */
  update(dt, now) {
    const g = CONFIG.gameplay;
    const playerPos = this._player.position;

    for (let i = this._enemies.length - 1; i >= 0; i--) {
      const e = this._enemies[i];
      const distToPlayer = e.position.distanceTo(playerPos);
      const attacking = distToPlayer < g.AI_SHOOT_RANGE;

      // Recompute the A* route periodically.
      if (now - e.lastPath > g.AI_REPATH_MS) {
        e.path = this._pathFor(e);
        e.nodeIdx = 1;
        e.lastPath = now;
      }

      if (!attacking && e.path.length > 1) {
        this._followPath(e, dt);
      } else if (attacking) {
        this._attack(e, now, playerPos);
      }

      // Anti-stuck: barely moved while hunting -> force a reroute.
      if (now - e.lastStuckCheck > g.AI_STUCK_MS) {
        if (!attacking && e.position.distanceTo(e.lastPos) < 25) e.lastPath = 0;
        e.lastPos.copy(e.position);
        e.lastStuckCheck = now;
      }
    }

    this._separate(dt);
  }

  _followPath(e, dt) {
    const g = CONFIG.gameplay;
    const node = e.path[Math.min(e.nodeIdx, e.path.length - 1)];
    const tx = this._maze.centerX(node[0]);
    const tz = this._maze.centerZ(node[1]);
    let dx = tx - e.position.x;
    let dz = tz - e.position.z;
    const d = Math.sqrt(dx * dx + dz * dz);
    if (d < 28) {
      if (e.nodeIdx < e.path.length - 1) e.nodeIdx++;
    } else {
      dx /= d; dz /= d;
      this._collision.moveWithCollision(e.position, dx * g.ENEMYSPEED * dt, dz * g.ENEMYSPEED * dt, 48);
      this._scratch.set(tx, 60, tz);
      e.faceTowards(this._scratch, 60);
    }
  }

  _attack(e, now, playerPos) {
    e.faceTowards(playerPos, 60);
    if (now > e.lastShot + e.shootDelay) {
      const dir = new THREE.Vector3(
        playerPos.x - e.position.x,
        playerPos.y - e.position.y,
        playerPos.z - e.position.z
      ).normalize();
      const origin = new THREE.Vector3(
        e.position.x + dir.x * 45, e.position.y, e.position.z + dir.z * 45
      );
      this._combat.spawn('enemy', origin, dir, CONFIG.gameplay.ENEMY_BULLET_SPEED);
      this._bus.emit('combat:enemyShoot');
      // Original semantics: jitter only, because e.shootDelay already includes the
      // base AI_SHOOT_COOLDOWN.
      e.lastShot = now + rand(-250, 350);
    }
  }

  /** Push overlapping hunters apart so they don't stack into one cube. */
  _separate(dt) {
    void dt; // kept for signature stability across systems
    for (let m = 0; m < this._enemies.length; m++) {
      for (let n = m + 1; n < this._enemies.length; n++) {
        const A = this._enemies[m].position;
        const B = this._enemies[n].position;
        let dx = B.x - A.x, dz = B.z - A.z;
        const d = Math.sqrt(dx * dx + dz * dz);
        if (d > 0.001 && d < 70) {
          const push = (70 - d) * 0.5;
          dx /= d; dz /= d;
          this._collision.moveWithCollision(A, -dx * push, -dz * push, 48);
          this._collision.moveWithCollision(B, dx * push, dz * push, 48);
        }
      }
    }
  }
}

function rand(lo, hi) {
  return Math.floor(Math.random() * (hi - lo + 1)) + lo;
}
