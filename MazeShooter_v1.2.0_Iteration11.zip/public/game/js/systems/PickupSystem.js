/**
 * MazeShooter · systems/PickupSystem.js
 *
 * Spawns, animates, collects and respawns health packs (single
 * responsibility). Collection consequences are delegated: this system
 * heals the player and announces it on the bus.
 */
import { HealthPack } from '../entities/HealthPack.js';
import { CONFIG } from '../core/Config.js';

export class PickupSystem {
  /**
   * @param {THREE.Scene} scene
   * @param {import('../world/Maze.js').Maze} maze
   * @param {import('../world/TextureLib.js').TextureLib} textures
   * @param {import('../entities/Player.js').Player} player
   * @param {import('../core/EventBus.js').EventBus} bus
   * @param {{x:number,z:number}} spawnCell
   */
  constructor(scene, maze, textures, player, bus, spawnCell) {
    this._scene = scene;
    this._maze = maze;
    this._player = player;
    this._bus = bus;

    const g = CONFIG.gameplay;
    this._heal = g.PACK_HEAL;
    this._respawnMs = g.PACK_RESPAWN_MS;

    const geo = new THREE.BoxGeometry(36, 36, 36);
    const mat = new THREE.MeshBasicMaterial({ map: textures.get('health.png') });

    /** @type {HealthPack[]} */
    this.packs = [];
    const cells = maze.pickOpenCells(spawnCell.x, spawnCell.z, g.NUM_PACKS, 5);
    for (let i = 0; i < cells.length; i++) {
      const mesh = new THREE.Mesh(geo, mat);
      mesh.position.set(maze.centerX(cells[i].x), 46, maze.centerZ(cells[i].z));
      scene.add(mesh);
      this.packs.push(new HealthPack(mesh, i));
    }
  }

  /**
   * @param {number} dt
   * @param {number} now
   */
  update(dt, now) {
    void dt;
    const pos = this._player.position;
    for (let i = 0; i < this.packs.length; i++) {
      const pack = this.packs[i];
      if (!pack.active) {
        if (now > pack.respawnAt) this._relocate(pack);
        continue;
      }
      pack.update(dt, now);
      if (this._player.health < 100) {
        const p = pack.position;
        const dxz = (p.x - pos.x) * (p.x - pos.x) + (p.z - pos.z) * (p.z - pos.z);
        if (dxz < 110 * 110) {
          this._player.heal(this._heal);
          pack.deactivate(this._respawnMs);
          this._bus.emit('pack:collected', { heal: this._heal, health: this._player.health });
        }
      }
    }
  }

  _relocate(pack) {
    const sector = this._maze.sectorOf(
      this._player.position.x, this._player.position.z
    );
    const cells = this._maze.pickOpenCells(sector.x, sector.z, 1, 4);
    pack.respawnAtCell(cells.length ? cells[0] : { x: 1, z: 1 }, this._maze);
  }
}
