/**
 * MazeShooter · systems/PathfinderAdapter.js
 *
 * Thin seam over the vendored Pathfinder.js (PathFinding.js A*). Exists so
 * the AI system depends on an interface-shaped object instead of the global
 * PF library (Dependency Inversion): swap a different pathfinder in without
 * touching gameplay code.
 */
export class PathfinderAdapter {
  constructor() {
    this._finder = new PF.AStarFinder({ allowDiagonal: false });
  }

  /**
   * A* over the maze's cached wall matrix (orthogonal moves only).
   * @param {import('../world/Maze.js').Maze} maze
   * @param {{x:number,z:number}} from cell
   * @param {{x:number,z:number}} to cell
   * @returns {Array<number[]>} path of [x, z] grid nodes (may be empty)
   */
  findPath(maze, from, to) {
    const w = maze.w, h = maze.h;
    const sx = clampi(from.x, 0, w - 1), sz = clampi(from.z, 0, h - 1);
    const tx = clampi(to.x, 0, w - 1), tz = clampi(to.z, 0, h - 1);
    try {
      return this._finder.findPath(sx, sz, tx, tz, new PF.Grid(w, h, maze.pathMatrix()));
    } catch (e) {
      return [];
    }
  }
}

function clampi(v, lo, hi) {
  return v < lo ? lo : (v > hi ? hi : v);
}
