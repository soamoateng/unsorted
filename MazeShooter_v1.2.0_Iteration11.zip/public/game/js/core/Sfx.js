/**
 * MazeShooter · core/Sfx.js
 *
 * Tiny WebAudio synthesizer (no audio assets; every sound is generated
 * from oscillators/noise at runtime). Migrated from the UMD sfx.js into an
 * injectable ES module: the Game wires it to the settings service, so
 * muting is state (setMuted) rather than hidden toggling (SRP).
 * The AudioContext is created lazily on the first user gesture.
 */
export class Sfx {
  constructor() {
    this._ctx = null;
    this._master = null;
    this._noiseBuf = null;
    this._muted = false;
  }

  init() {
    if (this._ctx) {
      if (this._ctx.state === 'suspended') this._ctx.resume();
      return;
    }
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return; // No WebAudio, so the game stays silent with no errors
    try {
      this._ctx = new AC();
      this._master = this._ctx.createGain();
      this._master.gain.value = 0.22;
      this._master.connect(this._ctx.destination);
    } catch (e) {
      this._ctx = null;
    }
  }

  setMuted(muted) {
    this._muted = !!muted;
  }

  get muted() {
    return this._muted;
  }

  _noise() {
    if (!this._ctx) return null;
    if (this._noiseBuf) return this._noiseBuf;
    const len = this._ctx.sampleRate * 0.5;
    this._noiseBuf = this._ctx.createBuffer(1, len, this._ctx.sampleRate);
    const data = this._noiseBuf.getChannelData(0);
    for (let i = 0; i < len; i++) data[i] = Math.random() * 2 - 1;
    return this._noiseBuf;
  }

  /** Oscillator sweep with exponential decay envelope. */
  _tone(type, f0, f1, dur, vol, when) {
    if (!this._ctx || this._muted) return;
    const t = this._ctx.currentTime + (when || 0);
    const osc = this._ctx.createOscillator();
    const g = this._ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(f0, t);
    if (f1 && f1 !== f0) osc.frequency.exponentialRampToValueAtTime(Math.max(f1, 1), t + dur);
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    osc.connect(g); g.connect(this._master);
    osc.start(t); osc.stop(t + dur + 0.02);
  }

  /** Noise burst through a lowpass for impacts and explosions. */
  _burst(dur, vol, cutoff, when) {
    if (!this._ctx || this._muted) return;
    const buf = this._noise();
    if (!buf) return;
    const t = this._ctx.currentTime + (when || 0);
    const src = this._ctx.createBufferSource();
    src.buffer = buf;
    const g = this._ctx.createGain();
    const f = this._ctx.createBiquadFilter();
    f.type = 'lowpass';
    f.frequency.setValueAtTime(cutoff, t);
    f.frequency.exponentialRampToValueAtTime(Math.max(cutoff * 0.15, 40), t + dur);
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    src.connect(f); f.connect(g); g.connect(this._master);
    src.start(t); src.stop(t + dur + 0.02);
  }

  shoot()        { this._tone('sawtooth', 950, 160, 0.09, 0.5); this._burst(0.05, 0.18, 3200); }
  jump()         { this._tone('sine', 300, 560, 0.11, 0.22); }
  land()         { this._burst(0.05, 0.14, 900); }
  enemyShoot()   { this._tone('square', 420, 90, 0.12, 0.32); }
  hit()          { this._tone('square', 260, 120, 0.06, 0.35); this._burst(0.04, 0.12, 1800); }
  enemyDie()     { this._tone('sawtooth', 300, 40, 0.35, 0.4); this._burst(0.3, 0.35, 900); }
  hurt()         { this._tone('sawtooth', 140, 60, 0.22, 0.55); this._burst(0.12, 0.25, 700); }
  pickup()       { this._tone('sine', 520, 520, 0.09, 0.4); this._tone('sine', 780, 780, 0.12, 0.4, 0.09); }
  unlock() {
    this._tone('sine', 440, 440, 0.12, 0.4);
    this._tone('sine', 660, 660, 0.12, 0.4, 0.12);
    this._tone('sine', 880, 880, 0.2, 0.4, 0.24);
  }
  wave() {
    // Ominous two-note horn: a new hunter squad just entered the maze.
    this._tone('sawtooth', 220, 180, 0.3, 0.42);
    this._tone('sawtooth', 165, 130, 0.42, 0.42, 0.22);
  }
  win() {
    const notes = [523, 659, 784, 1047];
    for (let i = 0; i < notes.length; i++) this._tone('triangle', notes[i], notes[i], 0.18, 0.42, i * 0.13);
  }
  lose()         { this._tone('sawtooth', 220, 55, 0.8, 0.5); this._burst(0.5, 0.3, 500, 0.05); }
}
