/**
 * MazeShooter · core/GameStateMachine.js
 *
 * Finite state machine for the run lifecycle (single responsibility:
 * legal transitions + notification). States:
 *
 *   intro -> playing -> paused -> playing ... -> dead | won
 *
 * Consumers (HUD, screens, input) react to `state:changed` events instead
 * of polling flags.
 */

export const GameState = Object.freeze({
  INTRO: 'intro',
  PLAYING: 'playing',
  PAUSED: 'paused',
  DEAD: 'dead',
  WON: 'won',
});

/** @type {Map<string, string[]>} allowed transitions */
const TRANSITIONS = new Map([
  [GameState.INTRO, [GameState.PLAYING]],
  [GameState.PLAYING, [GameState.PAUSED, GameState.DEAD, GameState.WON]],
  [GameState.PAUSED, [GameState.PLAYING]],
  [GameState.DEAD, []],
  [GameState.WON, []],
]);

export class GameStateMachine {
  /**
   * @param {import('./EventBus.js').EventBus} bus
   */
  constructor(bus) {
    this._bus = bus;
    this._state = GameState.INTRO;
  }

  get current() {
    return this._state;
  }

  is(...states) {
    return states.indexOf(this._state) !== -1;
  }

  /**
   * @param {string} next
   * @returns {boolean} whether the transition happened
   */
  transition(next) {
    const allowed = TRANSITIONS.get(this._state) || [];
    if (allowed.indexOf(next) === -1) {
      console.warn('[state] illegal transition:', this._state, '->', next);
      return false;
    }
    const prev = this._state;
    this._state = next;
    this._bus.emit('state:changed', { from: prev, to: next });
    return true;
  }
}
