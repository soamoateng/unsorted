/**
 * MazeShooter · core/Config.js
 *
 * The single source of truth for every tunable (DRY). Values are frozen,
 * and systems receive config via injection so they never mutate it.
 *
 * NOTE: `settings` must stay in sync with the server-side defaults in
 * public/api/index.php (SETTING_DEFAULTS). The server is authoritative
 * and returns these keys merged with stored values.
 */
export const CONFIG = Object.freeze({
  world: Object.freeze({
    MAPW: 21,
    MAPH: 21,
    MAZE_LOOPS: 14,
    UNITSIZE: 250,
    WALLHEIGHT: 300,
    EYE_HEIGHT: 110,
    PLAYER_RADIUS: 55,
    SPAWN_CELL: Object.freeze({ x: 1, z: 1 }),
  }),

  gameplay: Object.freeze({
    MOVESPEED: 380,
    ENEMYSPEED: 215,
    LOOKSENS: 0.14,          // pointer-lock: degrees per pixel
    FALLBACK_LOOKSPEED: 0.11,
    TOUCH_LOOKSPEED: 0.28,   // degrees per CSS pixel dragged
    PROJECTILEDAMAGE: 25,
    ENEMYPROJECTILEDAMAGE: 10,
    PLAYER_BULLET_SPEED: 1600,
    ENEMY_BULLET_SPEED: 850,
    NUMAI: 8,
    AI_HEALTH: 60,
    AI_SHOOT_RANGE: 520,
    AI_SHOOT_COOLDOWN: 850,
    FIRE_COOLDOWN: 170,
    NUM_PACKS: 3,
    PACK_HEAL: 40,
    PACK_RESPAWN_MS: 30000,
    AI_REPATH_MS: 700,
    AI_STUCK_MS: 2000,
    BULLET_TTL_MS: 3000,
    // Hunter waves: every WAVE_INTERVAL_MS of play, WAVE_SIZE more hunters
    // enter the maze while the exit is still locked, so long runs stay
    // competitive and every kill keeps mattering.
    WAVE_SIZE: 8,            // hunters added per wave
    WAVE_INTERVAL_MS: 30000, // milliseconds between waves of new hunters
    MAX_ENEMIES: 80,         // hard ceiling: waves stop spawning at this many
                             // alive hunters, bounding the per-frame O(n^2)
                             // separation cost on very long runs
    // Player loft: jumping lifts the eye ~70 units at apex, which stays
    // under the 300-unit walls and clears the 60-unit bullet hit gate,
    // so a well-timed hop dodges incoming shots.
    JUMP_SPEED: 320,         // upward velocity at liftoff (units/s)
    GRAVITY: 720,            // downward pull (units/s^2)
  }),

  score: Object.freeze({
    KILL: 100,
    TIME_BONUS_MAX: 2000,
    TIME_BONUS_RATE: 10,     // points lost per survived second
    HEALTH: 5,
  }),

  touch: Object.freeze({
    JOY_RADIUS: 52,          // px, max nub offset
    DEADZONE: 0.12,          // fraction of radius
  }),

  api: Object.freeze({
    // The API base URL is auto-derived from ApiClient.js's own location
    // (../../api/), so it stays correct at a domain root and inside a
    // subfolder. Pass { base } to the ApiClient to override it.
    timeoutMs: 8000,
    leaderboardLimit: 10,
  }),

  storage: Object.freeze({
    playerIdKey: 'mzs.playerId',
    playerNameKey: 'mzs.playerName',
    tagModalSkippedKey: 'mzs.tagModalSkipped', // Anonymous skipper nudge guard
  }),

  /** Client-side defaults; server may override with stored values. */
  settings: Object.freeze({
    lookSensitivity: 1.0,
    invertY: false,
    soundOn: true,
    showRadar: true,
  }),
});
