/**
 * MazeShooter · core/EventBus.js
 *
 * Minimal synchronous pub/sub. Systems talk through events instead of
 * holding references to each other (Dependency Inversion): e.g. the HUD
 * reacts to `player:damaged` without knowing who shot the player.
 */
export class EventBus {
  constructor() {
    /** @type {Map<string, Set<Function>>} */
    this._handlers = new Map();
  }

  /**
   * @param {string} type
   * @param {Function} fn
   * @returns {Function} unsubscribe
   */
  on(type, fn) {
    if (!this._handlers.has(type)) this._handlers.set(type, new Set());
    this._handlers.get(type).add(fn);
    return () => this.off(type, fn);
  }

  /**
   * Subscribe exactly once, then auto-unsubscribe.
   * @param {string} type
   * @param {Function} fn
   */
  once(type, fn) {
    const off = this.on(type, (payload) => {
      off();
      fn(payload);
    });
    return off;
  }

  off(type, fn) {
    const set = this._handlers.get(type);
    if (set) set.delete(fn);
  }

  /**
   * @param {string} type
   * @param {*} [payload]
   */
  emit(type, payload) {
    const set = this._handlers.get(type);
    if (!set) return;
    // Copy: handlers may unsubscribe while we iterate.
    for (const fn of Array.from(set)) {
      try {
        fn(payload);
      } catch (err) {
        console.error('[bus] handler failed for "' + type + '"', err);
      }
    }
  }
}
