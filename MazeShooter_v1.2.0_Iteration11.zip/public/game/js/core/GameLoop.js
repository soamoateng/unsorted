/**
 * MazeShooter · core/GameLoop.js
 *
 * requestAnimationFrame wrapper. Single responsibility: tick timing.
 * Systems register an update callback and receive a frame delta clamped
 * to 50ms (survives tab switches without physics explosions).
 */
export class GameLoop {
  constructor() {
    this._onUpdate = null;
    this._running = false;
    this._rafId = 0;
    this._lastTime = 0;
    this._tick = this._tick.bind(this);
  }

  /**
   * @param {Function} fn receives (deltaSeconds)
   */
  onUpdate(fn) {
    this._onUpdate = fn;
  }

  start() {
    if (this._running) return;
    this._running = true;
    this._lastTime = performance.now();
    this._rafId = requestAnimationFrame(this._tick);
  }

  stop() {
    this._running = false;
    if (this._rafId) cancelAnimationFrame(this._rafId);
    this._rafId = 0;
  }

  get running() {
    return this._running;
  }

  _tick(now) {
    if (!this._running) return;
    const delta = Math.min((now - this._lastTime) / 1000, 0.05);
    this._lastTime = now;
    if (this._onUpdate) this._onUpdate(delta);
    this._rafId = requestAnimationFrame(this._tick);
  }
}
