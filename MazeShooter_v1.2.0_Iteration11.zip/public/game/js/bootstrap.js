/**
 * MazeShooter · bootstrap.js
 *
 * Entry point. Assembles the object graph once (composition) and hands
 * control to the Game. Everything after this file is wiring-free: classes
 * receive what they need through constructors.
 */
import { CONFIG } from './core/Config.js';
import { EventBus } from './core/EventBus.js';
import { GameLoop } from './core/GameLoop.js';
import { GameState, GameStateMachine } from './core/GameStateMachine.js';
import { Sfx } from './core/Sfx.js';
import { HudView } from './ui/HudView.js';
import { LoftView } from './ui/LoftView.js';
import { RadarView } from './ui/RadarView.js';
import { Screens } from './ui/Screens.js';
import { InputSystem } from './input/InputSystem.js';
import { PlayerIdentity } from './services/PlayerIdentity.js';
import { ApiClient } from './services/ApiClient.js';
import { GamerTag } from './services/GamerTag.js';
import { SettingsService } from './services/SettingsService.js';
import { LeaderboardService } from './services/LeaderboardService.js';
import { Game } from './Game.js';

function main() {
  const bus = new EventBus();
  const loop = new GameLoop();
  const states = new GameStateMachine(bus);
  const sfx = new Sfx();
  const identity = new PlayerIdentity();
  const client = new ApiClient();
  const settings = new SettingsService(client);
  const leaderboard = new LeaderboardService(client);
  let pendingSettingsSave = null;

  const hud = new HudView(document, CONFIG.gameplay.NUMAI);
  const radar = new RadarView(document.querySelector('#radar'));
  const input = new InputSystem();

  let game;
  const screens = new Screens({
    onStart: () => {
      // body.playing hides the bottom bar (and its Gamer Loft entry)
      // during a live run, so the loft never opens over a hunt. It is set
      // only when the run actually reached PLAYING: a failed world build
      // (no WebGL) must leave the bar visible as the way out.
      game.start();
      if (states.is(GameState.PLAYING)) document.body.classList.add('playing');
    },
    onResume: () => game.resume(),
    onPauseRequest: () => game.pause(),
    onLoftRequest: () => {
      // Death/win funnel: put the end screen away and open the loft,
      // where the fresh run is already on the board.
      screens.hideEndScreens();
      loft.show();
    },
    onNameChange: (raw) => {
      const check = GamerTag.validate(raw);
      if (!check.ok) {
        screens.showNameHint(check.error);
        screens.renderName(identity.name); // revert the committed input
        return;
      }
      // Server-first, matching the tag modal and the loft form: the tag
      // is stored locally only once the server accepted it (a 409 keeps
      // the previous tag, so a run can never carry a rejected name).
      // Offline (or API down) the local tag still saves so the game
      // stays playable and syncs on the next change.
      settings.save(identity.playerId, {}, check.name)
        .then(() => {
          identity.setName(check.name);
          screens.clearNameHint();
          screens.renderName(identity.name);
        })
        .catch((err) => {
          if (err && err.status === 409) {
            screens.showNameHint('That tag is already taken. Pick another one.');
            screens.renderName(identity.name); // keep the owned tag
          } else {
            // Network/offline fallback (non-409 errors included).
            identity.setName(check.name);
            screens.clearNameHint();
            screens.renderName(identity.name);
          }
        });
    },
    onTagSave: (raw) => {
      const check = GamerTag.validate(raw);
      if (!check.ok) {
        screens.showTagModalError(check.error); // modal stays open
        return;
      }
      screens.setTagModalBusy(true);
      screens.clearTagModalError();
      // Server first, so a taken tag is caught before anything is stored;
      // offline (or if the API is down) the local tag still saves so the
      // game stays playable and syncs on a later visit.
      settings.save(identity.playerId, {}, check.name)
        .then(() => {
          identity.setName(check.name);
          screens.hideTagModal();
          screens.renderName(identity.name);
        })
        .catch((err) => {
          if (err && err.status === 409) {
            screens.showTagModalError('That tag is already taken. Pick another one.');
          } else if (err && err.status === 422) {
            screens.showTagModalError(err.message || 'That tag is not allowed.');
          } else {
            identity.setName(check.name);
            screens.hideTagModal();
            screens.renderName(identity.name);
          }
        })
        .finally(() => screens.setTagModalBusy(false));
    },
    onTagSkip: () => {
      // Remember the decline so Anonymous skippers are not re-prompted on
      // every visit; the Gamer Loft stays available for choosing a tag.
      identity.markTagModalSkipped();
    },
    onSettingsChange: (partial) => {
      // Apply locally first (instant feedback), then persist the FULL
      // snapshot debounced: dragging the slider fires `input` per pixel,
      // and every save sends the complete merged value set, so even
      // out-of-order responses cannot mix half-updated settings.
      settings.merge(partial);
      game.applySettings(settings.current);
      clearTimeout(pendingSettingsSave);
      pendingSettingsSave = setTimeout(() => {
        settings.save(identity.playerId, {}).catch(() => {}); // offline: retry on next change
      }, 300);
    },
  });

  game = new Game({
    bus, loop, states, sfx, hud, radar, screens, input,
    identity, settings, leaderboard,
  });

  // The Gamer Loft lives in the game now: five menus over the same
  // identity and API client the run itself uses. Closing it returns to
  // the intro when one is already showing, and takes the same clean
  // reload the old NEW MAZE button used after a finished run.
  const loft = new LoftView({
    identity,
    client,
    leaderboard,
    onClose: () => {
      loft.hide();
      // Hand control back to whatever the loft opened over, instead of
      // assuming a finished run. A paused run must survive closing the
      // loft (keyboard users can reach the bar button while paused), and
      // a finished run returns to its death/win screen; NEW MAZE in the
      // loft header remains the explicit fresh-maze action.
      if (states.is(GameState.INTRO)) return;
      if (states.is(GameState.PAUSED)) { screens.showPause(); return; }
      if (states.is(GameState.DEAD)) { screens.revealEndScreen('dead'); return; }
      if (states.is(GameState.WON)) { screens.revealEndScreen('win'); return; }
      window.location.reload(); // defensive: loft open over a live run
    },
    onNameSaved: (name) => screens.renderName(name),
  });

  // E2E/test seam: lets verification tooling drive the composed graph.
  // Not used by game code; harmless in production.
  window.__MZ = { game, bus, CONFIG };

  game.prepare().then(() => {
    // First visit on this browser: ask for a gamer tag before the intro —
    // unless a tag exists or the visitor already declined once.
    if (!identity.name && !identity.hasSkippedTagModal()) {
      screens.offerTagModal(identity.name);
    }
  });
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', main);
} else {
  main();
}
