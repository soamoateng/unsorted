/**
 * MazeShooter · services/SettingsService.js
 *
 * Player settings live server-side (players.settings JSON), keyed by the
 * local player id, so the server is the single source of truth (the game
 * is explicitly NOT offline-first). Loads on boot, saves on change, keeps the
 * last-known values in memory for the current session.
 */
import { CONFIG } from '../core/Config.js';

export class SettingsService {
  /**
   * @param {import('./ApiClient.js').ApiClient} client
   */
  constructor(client) {
    this._client = client;
    this._values = Object.assign({}, CONFIG.settings);
    // Bumped on every local change; lets an older in-flight response
    // recognize itself as stale and skip overwriting newer values.
    this._rev = 0;
  }

  get current() {
    return Object.assign({}, this._values);
  }

  get(name) {
    return this._values[name];
  }

  /**
   * Merge a partial change locally (no network). Used by the settings UI
   * for instant feedback before the debounced save round-trip.
   * @param {Partial<typeof CONFIG.settings>} partial
   */
  merge(partial) {
    this._rev++;
    this._values = Object.assign({}, this._values, partial);
    return this.current;
  }

  /**
   * Pull settings (+ existence flag) from the server.
   * @param {string} playerId
   * @returns {Promise<{exists:boolean}>}
   */
  async load(playerId) {
    const rev = this._rev;
    const data = await this._client.get('/player/' + encodeURIComponent(playerId));
    const incoming = (data && data.settings) || {};
    if (rev === this._rev) {
      this._values = Object.assign({}, this._values, incoming);
    }
    return { exists: !!(data && data.exists) };
  }

  /**
   * Persist the full local value set (optionally updating the display
   * name in the same round-trip). Sends the COMPLETE snapshot, so even
   * out-of-order responses can never leave the server with a mix of old
   * and new values (last write wins with whole documents).
   * @param {string} playerId
   * @param {Partial<typeof CONFIG.settings>} partial merged locally first
   * @param {string} [name]
   * @returns {Promise<object>} saved server settings
   */
  async save(playerId, partial, name) {
    this.merge(partial);
    const rev = this._rev;
    const body = { settings: this._values };
    if (typeof name === 'string' && name.trim() !== '') body.name = name;
    const data = await this._client.send(
      '/player/' + encodeURIComponent(playerId),
      body,
      'PUT'
    );
    // Ignore stale responses: a newer local merge (higher rev) means this
    // snapshot is outdated and must not clobber the newer values.
    if (rev === this._rev) {
      this._values = Object.assign({}, this._values, (data && data.settings) || {});
    }
    return this.current;
  }
}
