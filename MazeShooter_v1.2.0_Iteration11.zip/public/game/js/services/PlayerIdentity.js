/**
 * MazeShooter · services/PlayerIdentity.js
 *
 * Stable local identity for the online leaderboard: a UUID persisted in
 * localStorage plus the chosen display name. localStorage is used ONLY for
 * identity continuity (so players keep their leaderboard history), while game
 * settings themselves live server-side (not offline-first).
 */
import { CONFIG } from '../core/Config.js';
import { GamerTag } from './GamerTag.js';

export class PlayerIdentity {
  constructor() {
    this.playerId = this._load(CONFIG.storage.playerIdKey) || this._create();
    this.name = this._load(CONFIG.storage.playerNameKey) || '';
  }

  /**
   * Whether the visitor already declined the first-run tag modal (so the
   * modal does not nag Anonymous skippers on every reload). The loft stays
   * available for choosing a tag later.
   */
  hasSkippedTagModal() {
    return this._load(CONFIG.storage.tagModalSkippedKey) === '1';
  }

  /** Remember the skip decision for this browser. */
  markTagModalSkipped() {
    this._save(CONFIG.storage.tagModalSkippedKey, '1');
  }

  _load(key) {
    try {
      return window.localStorage.getItem(key) || '';
    } catch (e) {
      return '';
    }
  }

  _save(key, value) {
    try {
      window.localStorage.setItem(key, value);
    } catch (e) { /* private mode etc. leaves identity session-only */ }
  }

  _create() {
    const uuid = (window.crypto && window.crypto.randomUUID)
      ? window.crypto.randomUUID()
      : 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
          const r = Math.random() * 16 | 0;
          const v = c === 'x' ? r : (r & 0x3 | 0x8);
          return v.toString(16);
        });
    this._save(CONFIG.storage.playerIdKey, uuid);
    return uuid;
  }

  /**
   * Persist a display name. Every write goes through the shared GamerTag
   * hygiene (no ad-hoc slicing here), so identity can never hold a value
   * the modal, the intro field or the loft form would have rejected.
   */
  setName(name) {
    this.name = GamerTag.clean(name).slice(0, GamerTag.MAX_LENGTH);
    this._save(CONFIG.storage.playerNameKey, this.name);
    return this.name;
  }

  displayName() {
    return this.name || 'Anonymous';
  }
}
