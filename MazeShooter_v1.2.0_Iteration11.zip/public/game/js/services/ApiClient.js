/**
 * MazeShooter · services/ApiClient.js
 *
 * JSON transport over fetch (single responsibility: HTTP). Normalizes
 * network/HTTP failures into ApiError so services above it never touch
 * response plumbing.
 *
 * The API base is derived from THIS module's own location (../../api/), so
 * every call works unchanged at a domain root and inside a subfolder
 * (XAMPP htdocs/mazeshooter, cPanel add-on domains), and stays correct no
 * matter which page (landing or game) imports it.
 */
import { CONFIG } from '../core/Config.js';

export class ApiError extends Error {
  /**
   * @param {string} message
   * @param {number} [status] 0 = network/offline
   */
  constructor(message, status) {
    super(message);
    this.name = 'ApiError';
    this.status = status || 0;
  }

  get isOffline() {
    return this.status === 0;
  }
}

export class ApiClient {
  /**
   * @param {{base?:string, timeoutMs?:number}} [options]
   */
  constructor(options) {
    const o = options || {};
    this._base = o.base || ApiClient.defaultBase();
    this._timeoutMs = o.timeoutMs || CONFIG.api.timeoutMs;
  }

  /** <site root>/api, derived from this module file's own URL. */
  static defaultBase() {
    try {
      // This file lives at <root>/game/js/services/ApiClient.js, so three
      // levels up reach the site root, where the api/ folder sits.
      return new URL('../../../api/', import.meta.url).pathname.replace(/\/+$/, '');
    } catch (e) {
      return '/api';
    }
  }

  /**
   * @param {string} path under the API base, e.g. '/leaderboard'
   * @param {Record<string, string|number>} [params] query string
   */
  get(path, params) {
    let url = this._base + path;
    if (params) {
      const qs = new URLSearchParams();
      Object.keys(params).forEach((k) => qs.set(k, String(params[k])));
      url += '?' + qs.toString();
    }
    return this._request('GET', url);
  }

  /**
   * @param {string} path
   * @param {object} body
   * @param {string} [method] defaults to POST
   */
  send(path, body, method) {
    return this._request(method || 'POST', this._base + path, body);
  }

  async _request(method, url, body) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), this._timeoutMs);
    try {
      const res = await fetch(url, {
        method,
        headers: body ? { 'Content-Type': 'application/json' } : undefined,
        body: body ? JSON.stringify(body) : undefined,
        signal: controller.signal,
      });
      const data = await res.json().catch(() => null);
      if (!res.ok) {
        const msg = (data && data.error) || ('HTTP ' + res.status);
        throw new ApiError(msg, res.status);
      }
      return data;
    } catch (err) {
      if (err instanceof ApiError) throw err;
      throw new ApiError(err.name === 'AbortError' ? 'Request timed out' : 'Network unavailable', 0);
    } finally {
      clearTimeout(timer);
    }
  }
}
