/**
 * MazeShooter · services/LeaderboardService.js
 *
 * Leaderboard use-cases over the API (single responsibility: translate
 * game results into API calls and shape responses for the UI). The score
 * itself is computed by ScoreCalculator at the composition root, so this
 * service never re-derives game math (DRY).
 */
export class LeaderboardService {
  /**
   * @param {import('./ApiClient.js').ApiClient} client
   */
  constructor(client) {
    this._client = client;
  }

  /**
   * @param {number} [limit]
   * @returns {Promise<Array<{rank:number, name:string, score:number, kills:number, timeMs:number, won:boolean, accuracy?:number|null}>>}
   */
  async top(limit) {
    const data = await this._client.get('/leaderboard', { limit: limit || 10 });
    // Null-safe: a corrupted/non-JSON 200 (e.g. a host echoing PHP notices
    // into the body) resolves null instead of failing hard here.
    return (((data && data.scores) || [])).map((s, i) => Object.assign({ rank: i + 1 }, s));
  }

  /**
   * Every recorded run, best first (the leaderboard shows all scores).
   * @returns {Promise<Array<{rank:number, name:string, score:number, kills:number, timeMs:number, won:boolean, accuracy?:number|null}>>}
   */
  async all() {
    const data = await this._client.get('/leaderboard', { all: 1 });
    return (((data && data.scores) || [])).map((s, i) => Object.assign({ rank: i + 1 }, s));
  }

  /**
   * Submit a finished run.
   * @param {{playerId:string, name:string, score:number, kills:number,
   *          seconds:number, shotsFired:number, shotsHit:number,
   *          healthLeft:number, won:boolean}} entry
   * @returns {Promise<{rank:number, id:number, leaderboard:Array}>}
   */
  async submitRun(entry) {
    const payload = {
      playerId: entry.playerId,
      name: entry.name,
      score: entry.score,
      kills: entry.kills,
      timeMs: Math.round(entry.seconds * 1000),
      shotsFired: entry.shotsFired,
      shotsHit: entry.shotsHit,
      healthLeft: entry.healthLeft,
      won: entry.won,
    };
    const data = await this._client.send('/scores', payload);
    const saved = (data && data.entry) || {};
    return {
      rank: saved.rank,
      id: saved.id,
      leaderboard: (data && data.leaderboard) || [],
    };
  }
}
