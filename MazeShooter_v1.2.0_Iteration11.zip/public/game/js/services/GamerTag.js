/**
 * MazeShooter · services/GamerTag.js
 *
 * One source of truth for the gamer tag rules, shared by the tag modal,
 * the intro name field and the Gamer Loft form, so every surface (and the
 * server, which enforces the same rule again) agrees on what a valid tag
 * is: 3 to 24 characters after trimming and control/invisible-character
 * removal (zero-width, bidi and variation-selector Unicode stripped).
 */
export const GamerTag = {
  MIN_LENGTH: 3,
  MAX_LENGTH: 24,

  // Invisible Unicode that must never survive into a tag: zero-width
  // spaces/joiners (U+200B..D), the byte-order mark (U+FEFF), bidi
  // overrides + isolates (U+202A..E, U+2066..9) and variation selectors
  // (U+FE00..F). They render as nothing, so 'Player' and 'Player\u200B'
  // would look identical on the leaderboard while staying different
  // strings — an impersonation vector (mirrors the server's hygiene step).
  INVISIBLE: /[\u0000-\u001F\u007F\u200B-\u200D\uFEFF\u202A-\u202E\u2066-\u2069\uFE00-\uFE0F]/g,

  /** Trim + strip control and invisible characters (mirrors the server). */
  clean(raw) {
    return String(raw === null || typeof raw === 'undefined' ? '' : raw)
      .replace(GamerTag.INVISIBLE, '')
      .trim();
  },

  /**
   * Validate a tag.
   * @param {string} raw
   * @returns {{ok: boolean, name: string, error: string}}
   */
  validate(raw) {
    const name = this.clean(raw).slice(0, this.MAX_LENGTH);
    if (name.length < this.MIN_LENGTH) {
      return {
        ok: false,
        name,
        error: 'Gamer tags are at least ' + this.MIN_LENGTH + ' characters.',
      };
    }
    return { ok: true, name, error: '' };
  },
};
