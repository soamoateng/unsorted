/**
 * MazeShooter · services/ScoreCalculator.js
 *
 * Pure scoring math (DRY: used by the HUD, the end screens and the score
 * submission). A win scores kills + time bonus + remaining health; a death
 * scores kills only.
 */
import { CONFIG } from '../core/Config.js';

export const ScoreCalculator = {
  /** Faster escapes earn more; bonus reaches 0 at 200s. */
  timeBonus(seconds) {
    return Math.max(0, CONFIG.score.TIME_BONUS_MAX - Math.floor(seconds) * CONFIG.score.TIME_BONUS_RATE);
  },

  /**
   * @param {{kills:number, seconds:number, health:number, won:boolean}} r
   * @returns {number}
   */
  finalScore(r) {
    const base = r.kills * CONFIG.score.KILL;
    if (!r.won) return base;
    return base + this.timeBonus(r.seconds) + r.health * CONFIG.score.HEALTH;
  },

  /** "m:ss" formatting shared by HUD and end screens. */
  formatTime(seconds) {
    const m = Math.floor(seconds / 60);
    const s = Math.floor(seconds % 60);
    return m + ':' + (s < 10 ? '0' : '') + s;
  },
};
