/**
 * MazeShooter, ui/Screens.js
 *
 * Full-screen UI states (tag modal, intro, pause, death, win) plus the
 * touch UI and end-of-run score submission display. Pure view + DOM
 * wiring: user intents are forwarded as callbacks (onStart, onResume,
 * onLoftRequest, onNameChange, onTagSave, onSettingsChange); game data is
 * pushed in via methods. All user-supplied text is rendered with
 * textContent (XSS-safe by construction), and the only decorated markup
 * is static Font Awesome icon elements.
 */
import { ScoreCalculator } from '../services/ScoreCalculator.js';

export class Screens {
  /**
   * @param {{
   *   onStart:Function, onResume:Function, onLoftRequest:Function,
   *   onNameChange:Function, onTagSave:Function, onTagSkip:Function,
   *   onSettingsChange:Function
   * }} callbacks
   */
  constructor(callbacks) {
    this._cb = callbacks;
    this._q = (sel) => document.querySelector(sel);
    this._el = {
      body: document.body,
      intro: this._q('#intro'),
      nameInput: this._q('#player-name'),
      nameHint: this._q('#name-hint'),
      tagModal: this._q('#tag-modal'),
      tagModalInput: this._q('#tag-modal-input'),
      tagModalError: this._q('#tag-modal-error'),
      tagModalSave: this._q('#tag-modal-form button[type="submit"]'),
      paused: this._q('#paused'),
      dead: this._q('#dead'),
      win: this._q('#win'),
      deadStats: this._q('#dead .stats'),
      deadBoard: this._q('#dead-board'),
      winStats: this._q('#win .stats'),
      winScore: this._q('#win .score'),
      winBoard: this._q('#win-board'),
    };

    this._wire();
  }

  _wire() {
    // Intro.
    this._el.intro.querySelector('#start-btn').addEventListener('click', (e) => {
      e.preventDefault();
      this._cb.onStart();
    });
    this._el.nameInput.addEventListener('change', () => {
      this._cb.onNameChange(this._el.nameInput.value);
    });

    // Gamer tag modal (fires before the intro on a fresh browser).
    this._el.tagModal.querySelector('#tag-modal-form').addEventListener('submit', (e) => {
      e.preventDefault();
      this._cb.onTagSave(this._el.tagModalInput.value);
    });
    this._el.tagModal.querySelector('#tag-modal-skip').addEventListener('click', () => {
      this.hideTagModal();
      if (typeof this._cb.onTagSkip === 'function') this._cb.onTagSkip();
    });

    // Settings controls.
    const sens = this._q('#set-sens');
    sens.addEventListener('input', () => {
      this._cb.onSettingsChange({ lookSensitivity: parseFloat(sens.value) });
    });
    const bindToggle = (sel, key) => {
      const el = this._q(sel);
      el.addEventListener('change', () => {
        const partial = {};
        partial[key] = el.checked;
        this._cb.onSettingsChange(partial);
      });
    };
    bindToggle('#set-invert', 'invertY');
    bindToggle('#set-sound', 'soundOn');
    bindToggle('#set-radar', 'showRadar');

    // Pause overlay + button.
    this._el.paused.addEventListener('click', () => this._cb.onResume());
    this._q('#btn-pause').addEventListener('click', () => this._cb.onPauseRequest());

    // End screens: both funnel back to the Gamer Loft (LoftView owns
    // the new-maze action from there).
    this._el.dead.querySelector('#loft-dead').addEventListener('click', () => this._cb.onLoftRequest());
    this._el.win.querySelector('#loft-win').addEventListener('click', () => this._cb.onLoftRequest());
  }

  /** Reflect settings into the intro controls (also used after server load). */
  renderSettings(settings) {
    this._q('#set-sens').value = String(settings.lookSensitivity);
    this._q('#set-invert').checked = !!settings.invertY;
    this._q('#set-sound').checked = !!settings.soundOn;
    this._q('#set-radar').checked = !!settings.showRadar;
  }

  renderName(name) {
    this._el.nameInput.value = name || '';
  }

  getName() {
    return this._el.nameInput.value || '';
  }

  /**
   * Prompt for a gamer tag before the intro when none is stored yet.
   * @param {string} currentName identity name (empty on a fresh browser)
   */
  offerTagModal(currentName) {
    if (currentName) return; // a tag already exists in localStorage
    this._el.tagModalInput.value = '';
    this.clearTagModalError();
    if (typeof this._el.tagModal.showModal === 'function') {
      this._el.tagModal.showModal();
      this._el.tagModalInput.focus();
    }
  }

  /** Inline reason why the typed tag was not accepted (modal stays open). */
  showTagModalError(message) {
    if (!this._el.tagModalError) return;
    this._el.tagModalError.textContent = message;
    this._el.tagModalError.hidden = false;
  }

  clearTagModalError() {
    if (!this._el.tagModalError) return;
    this._el.tagModalError.textContent = '';
    this._el.tagModalError.hidden = true;
  }

  /** Prevent double submits while the tag save round-trip is in flight. */
  setTagModalBusy(busy) {
    if (this._el.tagModalSave) this._el.tagModalSave.disabled = !!busy;
  }

  /** Inline hint under the intro name field (too short, taken, ...). */
  showNameHint(message) {
    if (!this._el.nameHint) return;
    this._el.nameHint.textContent = message;
    this._el.nameHint.hidden = false;
  }

  clearNameHint() {
    if (!this._el.nameHint) return;
    this._el.nameHint.textContent = '';
    this._el.nameHint.hidden = true;
  }

  /** Close the tag modal and carry the tag into the intro input. */
  hideTagModal() {
    if (typeof this._el.tagModal.close === 'function' && this._el.tagModal.open) {
      this._el.tagModal.close();
    }
  }

  /** WebGL/boot failure surfaced on the intro overlay. */
  showFatalError(message) {
    const go = this._el.intro.querySelector('.go');
    if (go) go.textContent = message;
    this._el.intro.classList.remove('hidden');
  }

  /** body.touch toggles the touch UI (joystick, fire) via CSS media queries too. */
  setTouchMode(on) {
    this._el.body.classList.toggle('touch', !!on);
  }

  showIntro() {
    this._el.intro.classList.remove('hidden');
    // The bottom bar rides above the intro overlay only while the intro
    // actually shows, so its Gamer Loft entry stays clickable there and
    // stays buried under the pause/end/loft overlays everywhere else.
    this._el.body.classList.add('intro-open');
  }

  hideIntro() {
    this._el.intro.classList.add('hidden');
    this._el.body.classList.remove('intro-open');
  }

  showPause() {
    this._el.paused.classList.remove('hidden');
  }

  hidePause() {
    this._el.paused.classList.add('hidden');
  }

  showDeath(stats) {
    this._el.deadStats.textContent = stats;
    this._setBoardLoading(this._el.deadBoard);
    this._el.dead.classList.remove('hidden');
  }

  /**
   * Put both end screens away (used when the Gamer Loft takes over
   * after a run; the loft close path decides what comes next).
   */
  hideEndScreens() {
    this._el.dead.classList.add('hidden');
    this._el.win.classList.add('hidden');
  }

  /**
   * Bring one end screen back untouched (no re-render, so the run's
   * stats line and the submitted leaderboard stay exactly as they were).
   * Used when the Gamer Loft closes over a finished run.
   * @param {'dead'|'win'} which
   */
  revealEndScreen(which) {
    (which === 'win' ? this._el.win : this._el.dead).classList.remove('hidden');
  }

  showWin(stats, score) {
    this._el.winStats.textContent = stats;
    this._el.winScore.textContent = 'SCORE ' + score;
    this._setBoardLoading(this._el.winBoard);
    this._el.win.classList.remove('hidden');
  }

  _setBoardLoading(board) {
    board.textContent = '';
    const loading = document.createElement('div');
    loading.className = 'board-status';
    loading.textContent = '...';
    board.appendChild(loading);
  }

  /**
   * Render the submission outcome under the death/win screen: the full
   * leaderboard with tag, kills, time survived, accuracy and score
   * columns. The player's own row is highlighted when the API returns it.
   * @param {'dead'|'win'} which
   * @param {{status:string, rank?:number, ownId?:number}} result
   * @param {Array<{id:number, name:string, score:number, kills:number,
   *          timeMs:number, accuracy?:number|null, won:boolean}>} [leaderboard]
   */
  renderSubmission(which, result, leaderboard) {
    const board = which === 'win' ? this._el.winBoard : this._el.deadBoard;
    board.textContent = '';

    const status = document.createElement('div');
    status.className = 'board-status';
    status.textContent = result.status;
    board.appendChild(status);

    if (result.rank) {
      const rank = document.createElement('div');
      rank.className = 'board-rank';
      rank.textContent = 'World rank #' + result.rank;
      board.appendChild(rank);
    }

    if (!Array.isArray(leaderboard) || !leaderboard.length) return;

    const list = document.createElement('ol');
    list.className = 'board-list';
    list.appendChild(this._boardRow(['Gamer tag', 'Kills', 'Time', 'Accuracy', 'Score'], true, 0));
    leaderboard.forEach((row) => {
      const acc = (row.accuracy === null || typeof row.accuracy === 'undefined')
        ? 'n/a' : Math.round(row.accuracy * 100) + '%';
      const li = this._boardRow([
        row.name || 'Anonymous',
        String(row.kills),
        ScoreCalculator.formatTime((row.timeMs || 0) / 1000),
        acc,
        String(row.score),
      ], false, row.id);
      if (result.ownId && row.id === result.ownId) li.classList.add('board-own');
      if (row.won) li.querySelector('.col-tag').appendChild(this._icon('fa-check', 'escaped'));
      list.appendChild(li);
    });
    board.appendChild(list);
  }

  /**
   * One leaderboard line (header or data) as a grid row of spans.
   * @param {string[]} cells
   * @param {boolean} isHeader
   * @param {number} rowId
   */
  _boardRow(cells, isHeader, rowId) {
    const li = document.createElement('li');
    li.className = isHeader ? 'board-head' : 'board-row';
    if (rowId) li.dataset.rowId = String(rowId);
    const classes = ['col-tag', 'col-num', 'col-num', 'col-num', 'col-num col-score'];
    cells.forEach((text, i) => {
      const span = document.createElement('span');
      span.className = classes[i];
      span.textContent = text;
      li.appendChild(span);
    });
    return li;
  }

  /** Static Font Awesome icon element (never carries user data). */
  _icon(faClass, label) {
    const icon = document.createElement('i');
    icon.className = 'fa-solid ' + faClass;
    icon.setAttribute('aria-label', label);
    icon.setAttribute('aria-hidden', 'false');
    return icon;
  }
}
