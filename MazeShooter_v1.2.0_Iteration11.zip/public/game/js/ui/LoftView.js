/**
 * MazeShooter · ui/LoftView.js
 *
 * The Gamer Loft: an in-game overlay with five menus (leaderboard,
 * profile, career stats, play time, recent runs). It shares the game's
 * own identity and API services (same player, same client) so the loft,
 * the end screens and the leaderboard always agree on who you are.
 *
 * Pure view + DOM wiring: closing is forwarded as the onClose callback
 * (the composition root decides whether to reveal the intro or restart);
 * a successful tag save is forwarded via onNameSaved. All API data lands
 * in the DOM through textContent, never HTML, and badges are static
 * Font Awesome icon elements.
 *
 * Name updates send only the name, so stored game settings are never
 * touched (the server keeps them when the settings key is absent). Tag
 * rules (unique, 3+ characters) come from the shared GamerTag helper and
 * are enforced again by the server, which answers 409 when a tag is
 * already taken.
 */
import { ScoreCalculator } from '../services/ScoreCalculator.js';
import { GamerTag } from '../services/GamerTag.js';

export class LoftView {
  /**
   * @param {{
   *   identity: import('../services/PlayerIdentity.js').PlayerIdentity,
   *   client: import('../services/ApiClient.js').ApiClient,
   *   leaderboard: import('../services/LeaderboardService.js').LeaderboardService,
   *   onClose: Function, onNameSaved: Function
   * }} deps
   */
  constructor(deps) {
    this._cb = deps;
    this._identity = deps.identity;
    this._client = deps.client;
    this._leaderboard = deps.leaderboard;

    this._el = {
      root: document.querySelector('#loft'),
      close: document.querySelector('#loft-close'),
      newMaze: document.querySelector('#loft-new-maze'),
      tabs: Array.prototype.slice.call(document.querySelectorAll('.loft-tab')),
      panels: {
        board: document.getElementById('panel-board'),
        profile: document.getElementById('panel-profile'),
        stats: document.getElementById('panel-stats'),
        time: document.getElementById('panel-time'),
        recent: document.getElementById('panel-recent'),
      },
      board: document.getElementById('leaderboard'),
      refresh: document.getElementById('board-refresh'),
      tagCurrent: document.getElementById('tag-current'),
      tagInput: document.getElementById('tag-input'),
      tagStatus: document.getElementById('tag-status'),
      tagForm: document.getElementById('tag-form'),
      statFields: {
        games: document.getElementById('stat-games'),
        wins: document.getElementById('stat-wins'),
        best: document.getElementById('stat-best'),
        kills: document.getElementById('stat-kills'),
        accuracy: document.getElementById('stat-accuracy'),
      },
      statRows: document.getElementById('stat-rows'),
      statEmpty: document.getElementById('stats-empty'),
      timeFields: {
        total: document.getElementById('time-total'),
        longest: document.getElementById('time-longest'),
        avg: document.getElementById('time-avg'),
        last: document.getElementById('time-last'),
      },
      timeRows: document.getElementById('time-rows'),
      timeEmpty: document.getElementById('time-empty'),
      memberSince: document.getElementById('profile-member-since'),
      runsRecorded: document.getElementById('profile-runs'),
      recent: document.getElementById('recent-runs'),
    };

    this._wire();
  }

  _wire() {
    // Entry point: the Gamer Loft button in the bottom bar. It only
    // exists on non-playing screens (body.playing hides the bar during
    // a live run), so opening the loft never interrupts a hunt.
    const entry = document.getElementById('btn-loft');
    if (entry) entry.addEventListener('click', () => this.show());

    // Tabs (ARIA tabs pattern, arrow keys).
    this._el.tabs.forEach((tab) => {
      tab.addEventListener('click', () => this._selectTab(tab.dataset.panel));
      tab.addEventListener('keydown', (event) => {
        const i = this._el.tabs.indexOf(tab);
        let next = null;
        if (event.key === 'ArrowRight') next = this._el.tabs[(i + 1) % this._el.tabs.length];
        else if (event.key === 'ArrowLeft') next = this._el.tabs[(i - 1 + this._el.tabs.length) % this._el.tabs.length];
        else if (event.key === 'Home') next = this._el.tabs[0];
        else if (event.key === 'End') next = this._el.tabs[this._el.tabs.length - 1];
        if (next) {
          event.preventDefault();
          this._selectTab(next.dataset.panel, true);
        }
      });
    });

    if (this._el.refresh) {
      this._el.refresh.addEventListener('click', () => {
        this._loadBoard();
        this._el.refresh.blur();
      });
    }

    // Tag form: same rules as the intro field and the first-run modal.
    if (this._el.tagForm) {
      this._el.tagForm.addEventListener('submit', async (event) => {
        event.preventDefault();
        await this._saveTag(this._el.tagInput.value);
      });
    }

    if (this._el.close) {
      this._el.close.addEventListener('click', () => this._cb.onClose());
    }
    if (this._el.newMaze) {
      // A fresh maze, same as the old end-screen restart: a clean reload.
      this._el.newMaze.addEventListener('click', () => window.location.reload());
    }

    // Escape closes the loft. Safe next to the game's own Escape
    // handling: the loft only opens on intro/death/win screens, where
    // the game ignores Escape.
    this._onKey = (event) => {
      if (event.key === 'Escape' && this.isOpen()) this._cb.onClose();
    };
    document.addEventListener('keydown', this._onKey);
  }

  /** @returns {boolean} whether the loft overlay is currently open */
  isOpen() {
    return this._el.root && !this._el.root.classList.contains('hidden');
  }

  /** Open the loft and refresh every panel with live data. */
  show() {
    this._el.root.classList.remove('hidden');
    this._showTag(this._identity.displayName());
    this._selectTab('board', true); // focus lands inside the dialog
    this._loadBoard();
    this._loadPlayer();
  }

  /** Close the overlay; the composition root decides what happens next. */
  hide() {
    this._el.root.classList.add('hidden');
    // Bump both generations so any in-flight load knows its response is
    // stale: rapid open/close/open must never let an older response
    // render over a newer one.
    this._boardGen = (this._boardGen || 0) + 1;
    this._playerGen = (this._playerGen || 0) + 1;
  }

  _selectTab(name, focus) {
    this._el.tabs.forEach((tab) => {
      const on = tab.dataset.panel === name;
      tab.setAttribute('aria-selected', on ? 'true' : 'false');
      tab.tabIndex = on ? 0 : -1;
      if (on && focus) tab.focus();
    });
    Object.keys(this._el.panels).forEach((key) => {
      if (this._el.panels[key]) this._el.panels[key].hidden = key !== name;
    });
  }

  // ---------------- Data loading ----------------

  async _loadBoard() {
    const host = this._el.board;
    if (!host) return;
    const gen = (this._boardGen = (this._boardGen || 0) + 1);
    this._boardMessage('Loading...');
    try {
      const rows = await this._leaderboard.all();
      if (gen !== this._boardGen) return; // a newer load (or a close) superseded us
      this._renderBoard(rows);
    } catch (err) {
      if (gen !== this._boardGen) return;
      this._boardMessage('Leaderboard unavailable right now.');
    }
  }

  async _loadPlayer() {
    const gen = (this._playerGen = (this._playerGen || 0) + 1);
    try {
      const data = await this._client.get('/player/' + encodeURIComponent(this._identity.playerId));
      if (gen !== this._playerGen) return; // superseded while in flight
      const serverName = data && data.player && data.player.name;
      if (serverName && !this._identity.name) {
        this._identity.setName(serverName);
        this._showTag(this._identity.displayName());
      }
      const stats = (data && data.stats) || null;
      this._renderProfile(data && data.player, stats);
      this._renderStats(stats);
      this._renderRecent((data && data.recent) || []);
    } catch (err) {
      if (gen !== this._playerGen) return;
      // API unreachable: the loft still works, the panels show why not.
      this._el.statEmpty.hidden = false;
      this._el.statRows.hidden = true;
      this._el.statEmpty.textContent = 'Stats are resting right now. Play a run and check back.';
      this._el.timeEmpty.hidden = false;
      this._el.timeRows.hidden = true;
      this._el.timeEmpty.textContent = 'Play time is resting right now. Play a run and check back.';
      this._el.memberSince.textContent = 'Not yet';
      this._el.runsRecorded.textContent = '0';
      if (this._el.recent) {
        this._el.recent.textContent = '';
        this._el.recent.appendChild(this._message('Recent runs are resting right now. Play a run and check back.'));
      }
    }
  }

  // ---------------- Leaderboard ----------------

  _boardMessage(text) {
    this._el.board.textContent = '';
    this._el.board.appendChild(this._message(text));
  }

  _message(text) {
    const p = document.createElement('p');
    p.className = 'board-empty';
    p.textContent = text;
    return p;
  }

  _renderBoard(rows) {
    const host = this._el.board;
    host.textContent = '';
    if (!Array.isArray(rows) || !rows.length) {
      host.appendChild(this._message('No runs yet, so be the first to escape.'));
      return;
    }

    const table = document.createElement('table');
    table.className = 'board-table';

    const thead = document.createElement('thead');
    const headRow = document.createElement('tr');
    ['Gamer tag', 'Kills', 'Time survived', 'Accuracy', 'Score'].forEach((label) => {
      const th = document.createElement('th');
      th.scope = 'col';
      th.textContent = label;
      headRow.appendChild(th);
    });
    thead.appendChild(headRow);
    table.appendChild(thead);

    const tbody = document.createElement('tbody');
    rows.forEach((row) => {
      const tr = document.createElement('tr');
      const tag = this._cell(row.name || 'Anonymous', 'col-tag');
      if (row.won) {
        const badge = document.createElement('i');
        badge.className = 'fa-solid fa-check';
        badge.title = 'Escaped the maze';
        badge.setAttribute('aria-label', 'Escaped the maze');
        tag.appendChild(badge);
      }
      tr.appendChild(tag);
      tr.appendChild(this._cell(String(row.kills), 'col-num'));
      tr.appendChild(this._cell(ScoreCalculator.formatTime((row.timeMs || 0) / 1000), 'col-num'));
      tr.appendChild(this._cell(this._ratio(row.accuracy), 'col-num'));
      tr.appendChild(this._cell(String(row.score), 'col-num col-score'));
      tbody.appendChild(tr);
    });
    table.appendChild(tbody);
    host.appendChild(table);
  }

  // ---------------- Tag form ----------------

  _setStatus(message, kind) {
    if (!this._el.tagStatus) return;
    this._el.tagStatus.textContent = message;
    this._el.tagStatus.className = kind ? 'status ' + kind : 'status';
  }

  _showTag(tag) {
    if (!this._el.tagCurrent || !this._el.tagInput) return;
    this._el.tagCurrent.textContent = tag;
    this._el.tagInput.value = tag === 'Anonymous' ? '' : tag;
  }

  async _saveTag(raw) {
    const check = GamerTag.validate(raw);
    if (!check.ok) {
      this._setStatus(check.error, 'err');
      return;
    }
    const button = this._el.tagForm.querySelector('button');
    if (button) button.disabled = true;
    try {
      // The server answers 409 when another player owns the tag, so a
      // save only lands locally once the tag is really ours.
      await this._client.send('/player/' + encodeURIComponent(this._identity.playerId), { name: check.name }, 'PUT');
      this._identity.setName(check.name);
      this._showTag(this._identity.displayName());
      this._setStatus('Saved! Leaderboard runs will now show as ' + this._identity.displayName() + '.', 'ok');
      this._cb.onNameSaved(this._identity.displayName());
    } catch (err) {
      if (err && err.status === 409) {
        this._setStatus('That gamer tag is already taken. Pick another one.', 'err');
      } else if (err && err.status === 422) {
        this._setStatus(err.message || 'That tag is not allowed.', 'err');
      } else {
        // Offline: the tag still saves on this device and syncs later.
        this._identity.setName(check.name);
        this._showTag(this._identity.displayName());
        this._setStatus('Saved on this device, but the server could not be reached just now.', 'err');
        this._cb.onNameSaved(this._identity.displayName());
      }
    } finally {
      if (button) button.disabled = false;
    }
  }

  // ---------------- Career stats + play time ----------------

  _pct(pct) {
    if (pct === null || typeof pct === 'undefined') return 'n/a';
    return pct + '%';
  }

  _ratio(ratio) {
    if (ratio === null || typeof ratio === 'undefined') return 'n/a';
    return Math.round(ratio * 100) + '%';
  }

  _renderStats(stats) {
    if (!stats || !stats.games) return; // keep the friendly empty states
    this._el.statFields.games.textContent = String(stats.games);
    this._el.statFields.wins.textContent = String(stats.wins);
    this._el.statFields.best.textContent = String(stats.bestScore);
    this._el.statFields.kills.textContent = String(stats.totalKills);
    this._el.statFields.accuracy.textContent = this._pct(stats.accuracyPct);
    this._el.statEmpty.hidden = true;
    this._el.statRows.hidden = false;

    this._el.timeFields.total.textContent = this._duration(stats.totalTimeMs);
    this._el.timeFields.longest.textContent = ScoreCalculator.formatTime((stats.longestRunMs || 0) / 1000);
    this._el.timeFields.avg.textContent = ScoreCalculator.formatTime((stats.avgRunMs || 0) / 1000);
    this._el.timeFields.last.textContent = stats.lastPlayedAt ? this._date(stats.lastPlayedAt) : 'Never';
    this._el.timeEmpty.hidden = true;
    this._el.timeRows.hidden = false;
  }

  // ---------------- Profile ----------------

  _renderProfile(player, stats) {
    this._el.memberSince.textContent = player && player.createdAt ? this._date(player.createdAt) : 'Not yet';
    this._el.runsRecorded.textContent = String((stats && stats.games) || 0);
  }

  // ---------------- Recent runs ----------------

  _renderRecent(rows) {
    const host = this._el.recent;
    if (!host) return;
    host.textContent = '';
    if (!Array.isArray(rows) || !rows.length) {
      host.appendChild(this._message('No runs recorded yet, so be the first to escape.'));
      return;
    }
    const table = document.createElement('table');
    table.className = 'board-table';
    const thead = document.createElement('thead');
    const headRow = document.createElement('tr');
    ['When', 'Result', 'Kills', 'Time', 'Accuracy', 'Score'].forEach((label) => {
      const th = document.createElement('th');
      th.scope = 'col';
      th.textContent = label;
      headRow.appendChild(th);
    });
    thead.appendChild(headRow);
    table.appendChild(thead);

    const tbody = document.createElement('tbody');
    rows.forEach((row) => {
      const tr = document.createElement('tr');
      const when = this._cell(this._when(row.createdAt), 'col-when');
      const result = this._cell(row.won ? 'Escaped' : 'Fell', 'col-result');
      if (row.won) {
        const badge = document.createElement('i');
        badge.className = 'fa-solid fa-check';
        badge.title = 'Escaped the maze';
        badge.setAttribute('aria-label', 'Escaped the maze');
        result.appendChild(badge);
      }
      tr.appendChild(when);
      tr.appendChild(result);
      tr.appendChild(this._cell(String(row.kills), 'col-num'));
      tr.appendChild(this._cell(ScoreCalculator.formatTime((row.timeMs || 0) / 1000), 'col-num'));
      tr.appendChild(this._cell(this._ratio(row.accuracy), 'col-num'));
      tr.appendChild(this._cell(String(row.score), 'col-num col-score'));
      tbody.appendChild(tr);
    });
    table.appendChild(tbody);
    host.appendChild(table);
  }

  // ---------------- Formatting helpers ----------------

  _duration(ms) {
    // Floor, not round: 30-89 s of play is still "<1 min" or the correct
    // whole minute — rounding made every 30 s+ look like a full minute.
    const minutes = Math.floor((ms || 0) / 60000);
    if (minutes < 1) return '<1 min';
    if (minutes < 60) return minutes + ' min';
    const hours = Math.floor(minutes / 60);
    return hours + ' h ' + (minutes % 60) + ' min';
  }

  _date(iso) {
    if (!iso) return 'Not yet';
    const d = new Date(iso);
    if (isNaN(d.getTime())) return String(iso);
    try {
      return d.toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });
    } catch (err) {
      return d.toDateString();
    }
  }

  _when(iso) {
    const d = new Date(iso);
    if (isNaN(d.getTime())) return '';
    try {
      if (d.toDateString() === new Date().toDateString()) {
        return d.toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' });
      }
      return d.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
    } catch (err) {
      return d.toDateString();
    }
  }

  _cell(text, cls) {
    const td = document.createElement('td');
    if (cls) td.className = cls;
    td.textContent = text;
    return td;
  }
}
