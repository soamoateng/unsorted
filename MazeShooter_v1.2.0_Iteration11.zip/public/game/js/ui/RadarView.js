/**
 * MazeShooter · ui/RadarView.js
 *
 * Canvas minimap inherited from the Nemesis radar: walls, player + facing
 * tick, enemies, health packs, exit state. Pure view: the composition
 * root supplies a snapshot every ~250ms.
 */
import { ScoreCalculator } from '../services/ScoreCalculator.js';

export class RadarView {
  /**
   * @param {HTMLCanvasElement} canvas
   * @param {import('../world/Maze.js').Maze} [maze] optional, may arrive
   *        later via setMaze() (the maze is built when the game starts)
   */
  constructor(canvas, maze) {
    this._canvas = canvas;
    this._ctx = canvas.getContext('2d');
    this._size = canvas.width; // square canvas
    if (maze) this.setMaze(maze);
  }

  /** @param {import('../world/Maze.js').Maze} maze */
  setMaze(maze) {
    this._maze = maze;
    this._cs = Math.floor(this._size / maze.w);
    this._ox = Math.floor((this._size - this._cs * maze.w) / 2);
    this._oy = Math.floor((this._size - this._cs * maze.h) / 2);
  }

  setVisible(visible) {
    this._canvas.style.display = visible ? '' : 'none';
  }

  /**
   * @param {{playerCell:{x:number,z:number}, lon:number, enemies:THREE.Vector3[],
   *          packs:THREE.Vector3[], exitCell:{x:number,z:number}, exitUnlocked:boolean,
   *          playerWorld:{x:number,z:number}}} s
   */
  draw(s) {
    const ctx = this._ctx;
    const m = this._maze;
    const cs = this._cs, ox = this._ox, oy = this._oy;

    ctx.fillStyle = '#0b0b10';
    ctx.fillRect(0, 0, this._size, this._size);

    for (let i = 0; i < m.w; i++) {
      for (let j = 0; j < m.h; j++) {
        ctx.fillStyle = m.grid[i][j] > 0 ? '#3c3c46' : '#16161d';
        ctx.fillRect(ox + i * cs, oy + j * cs, cs, cs);
      }
    }

    // Exit.
    ctx.fillStyle = s.exitUnlocked ? '#33ff55' : '#cc4422';
    ctx.fillRect(ox + s.exitCell.x * cs, oy + s.exitCell.z * cs, cs, cs);

    // Health packs.
    ctx.fillStyle = '#ff66cc';
    for (let k = 0; k < s.packs.length; k++) {
      const cell = m.sectorOf(s.packs[k].x, s.packs[k].z);
      ctx.fillRect(ox + cell.x * cs, oy + cell.z * cs, cs, cs);
    }

    // Enemies.
    ctx.fillStyle = '#ff3333';
    for (let e = 0; e < s.enemies.length; e++) {
      const cell = m.sectorOf(s.enemies[e].x, s.enemies[e].z);
      ctx.fillRect(ox + cell.x * cs, oy + cell.z * cs, cs, cs);
    }

    // Player + facing tick (uses the original world-sector projection).
    const cell = m.sectorOf(s.playerWorld.x, s.playerWorld.z);
    const theta = s.lon * Math.PI / 180;
    const fX = Math.cos(theta), fZ = Math.sin(theta);
    const cx = ox + (cell.x + 0.5) * cs, cy = oy + (cell.z + 0.5) * cs;
    ctx.fillStyle = '#00e5ff';
    ctx.fillRect(ox + cell.x * cs, oy + cell.z * cs, cs, cs);
    ctx.strokeStyle = '#00e5ff';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(cx, cy);
    ctx.lineTo(cx + fX * cs * 1.4, cy + fZ * cs * 1.4);
    ctx.stroke();
  }
}
