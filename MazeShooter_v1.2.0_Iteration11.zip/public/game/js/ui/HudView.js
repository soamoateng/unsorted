/**
 * MazeShooter · ui/HudView.js
 *
 * In-game HUD (health bar, score, enemy count, timer, messages, hurt flash,
 * crosshair hit marker). Pure view: reads a stats snapshot each frame and
 * reacts to bus events; diffs DOM writes (same behavior as the original
 * jQuery HUD, without jQuery).
 */
import { ScoreCalculator } from '../services/ScoreCalculator.js';
import { CONFIG } from '../core/Config.js';

export class HudView {
  /**
   * @param {HTMLElement} root document root to query within
   * @param {number} initialEnemies
   */
  constructor(root, initialEnemies) {
    this._q = (sel) => root.querySelector(sel);
    this._el = {
      hp: this._q('#health'),
      hfill: this._q('#hfill'),
      score: this._q('#score'),
      enemies: this._q('#enemies'),
      time: this._q('#time'),
      msg: this._q('#msg'),
      hurt: this._q('#hurt'),
      crosshair: this._q('#crosshair'),
      compass: this._q('#exit-compass'),
      compassIcon: this._q('#exit-compass i'),
      compassDist: this._q('#exit-dist'),
    };
    this._last = { health: -1, score: -1, enemies: initialEnemies, time: '' };
    this._msgTimer = 0;
    this._hitTimer = 0;
    this._compassIcon = '';
  }

  /**
   * @param {{health:number, kills:number, enemies:number, seconds:number}} s
   */
  update(s) {
    if (s.health !== this._last.health) {
      this._last.health = s.health;
      const low = s.health < 25;
      // DOM-built (never innerHTML with interpolated values), so the HUD
      // stays XSS-safe by construction even if health ever stopped being
      // a plain number. Keeps the same structure the CSS expects: a .low
      // span nested inside #health when the value is critical.
      this._el.hp.textContent = '';
      if (low) {
        const lowSpan = document.createElement('span');
        lowSpan.className = 'low';
        lowSpan.textContent = String(s.health);
        this._el.hp.appendChild(lowSpan);
      } else {
        this._el.hp.textContent = String(s.health);
      }
      this._el.hfill.style.width = Math.max(0, s.health) + '%';
      this._el.hfill.style.background = low ? '#ff3b30' : (s.health < 60 ? '#ffb340' : '#43d17a');
    }
    const score = s.kills * CONFIG.score.KILL;
    if (score !== this._last.score) {
      this._last.score = score;
      this._el.score.textContent = String(score);
    }
    if (s.enemies !== this._last.enemies) {
      this._last.enemies = s.enemies;
      this._el.enemies.textContent = String(s.enemies);
    }
    const ts = ScoreCalculator.formatTime(s.seconds);
    if (ts !== this._last.time) {
      this._last.time = ts;
      this._el.time.textContent = ts;
    }
  }

  /**
   * Force the hunter counter to a known value (used when a wave spawns so
   * the very next frame is already correct).
   * @param {number} count
   */
  syncEnemyBudget(count) {
    this._last.enemies = count;
    this._el.enemies.textContent = String(count);
  }

  /**
   * Show or hide the exit compass (the way out once the portal opens).
   * @param {boolean} on
   */
  showExitCompass(on) {
    this._el.compass.hidden = !on;
  }

  /**
   * Point the compass from the player toward the portal: a straight, left
   * or right arrow plus the distance in meters (10 world units each).
   * @param {import('../entities/Player.js').Player} player
   * @param {THREE.Vector3} exitPos
   */
  updateExitCompass(player, exitPos) {
    const p = player.position;
    const dx = exitPos.x - p.x;
    const dz = exitPos.z - p.z;
    let rel = Math.atan2(dz, dx) * 180 / Math.PI - player.lon;
    while (rel > 180) rel -= 360;
    while (rel < -180) rel += 360;
    const icon = Math.abs(rel) <= 20 ? 'fa-up-long' : (rel > 0 ? 'fa-right-long' : 'fa-left-long');
    if (this._compassIcon !== icon) {
      this._compassIcon = icon;
      this._el.compassIcon.className = 'fa-solid ' + icon;
    }
    this._el.compassDist.textContent = Math.round(Math.sqrt(dx * dx + dz * dz) / 10) + 'm';
  }

  showMsg(text, ms) {
    const el = this._el.msg;
    el.textContent = text;
    el.classList.add('visible');
    clearTimeout(this._msgTimer);
    this._msgTimer = setTimeout(() => el.classList.remove('visible'), ms || 1400);
  }

  hurtFlash() {
    const el = this._el.hurt;
    el.classList.remove('flash');
    void el.offsetWidth; // restart CSS animation
    el.classList.add('flash');
  }

  crosshairHit() {
    const el = this._el.crosshair;
    el.classList.add('hit');
    clearTimeout(this._hitTimer);
    this._hitTimer = setTimeout(() => el.classList.remove('hit'), 90);
  }

  hideForEndScreen() {
    this._el.crosshair.style.display = 'none';
    this._el.msg.classList.remove('visible');
    this._el.compass.hidden = true;
  }
}
