/**
 * MazeShooter · world/Maze.js
 *
 * The maze as a model: wraps the Nemesis-format grid and exposes every
 * query the game needs (collision lookup, cell/world conversion, spawn
 * picking, exit placement, pathfinding matrix). Previously this logic was
 * smeared across maze.js free functions and main.js globals, and now it lives
 * in exactly one place (DRY) with one responsibility: answer grid questions.
 */
import { generateMaze } from './MazeGenerator.js';

export class Maze {
  /**
   * @param {number[][]} grid Nemesis-format grid
   * @param {number} unitSize world units per cell
   */
  constructor(grid, unitSize) {
    this.grid = grid;
    this.w = grid.length;
    this.h = grid[0].length;
    this.unitSize = unitSize;
    this._pathMatrix = null; // lazy: only built if an A* consumer asks
  }

  /**
   * @param {number} w odd width
   * @param {number} h odd height
   * @param {number} loops loop-carving count
   * @param {number} unitSize
   * @returns {Maze}
   */
  static generate(w, h, loops, unitSize) {
    return new Maze(generateMaze(w, h, loops), unitSize);
  }

  isWall(i, j) {
    return i < 0 || i >= this.w || j < 0 || j >= this.h || this.grid[i][j] > 0;
  }

  isOpen(i, j) {
    return !this.isWall(i, j);
  }

  /** World X center of cell i. */
  centerX(i) {
    return (i - this.w / 2 + 0.5) * this.unitSize;
  }

  /** World Z center of cell j. */
  centerZ(j) {
    return (j - this.h / 2 + 0.5) * this.unitSize;
  }

  /** Sector (cell) containing world coordinates x,z. */
  sectorOf(x, z) {
    return {
      x: Math.floor(x / this.unitSize + this.w / 2),
      z: Math.floor(z / this.unitSize + this.h / 2),
    };
  }

  /** Wall test for world coordinates. */
  isWallAtWorld(x, z) {
    const c = this.sectorOf(x, z);
    return this.isWall(c.x, c.z);
  }

  /**
   * BFS flood-fill of step distances across open cells.
   * @returns {number[][]} dist[i][j] = steps from (sx,sz); -1 = wall/unreachable
   */
  bfsDistances(sx, sz) {
    const dist = [];
    for (let i = 0; i < this.w; i++) {
      dist[i] = [];
      for (let j = 0; j < this.h; j++) dist[i][j] = -1;
    }
    if (!this.isOpen(sx, sz)) return dist;
    dist[sx][sz] = 0;
    const queue = [[sx, sz]];
    let head = 0;
    while (head < queue.length) {
      const cur = queue[head++];
      const x = cur[0], z = cur[1];
      const nd = dist[x][z] + 1;
      const nbrs = [[x - 1, z], [x + 1, z], [x, z - 1], [x, z + 1]];
      for (let k = 0; k < 4; k++) {
        const nx = nbrs[k][0], nz = nbrs[k][1];
        if (nx >= 0 && nx < this.w && nz >= 0 && nz < this.h &&
            this.isOpen(nx, nz) && dist[nx][nz] === -1) {
          dist[nx][nz] = nd;
          queue.push([nx, nz]);
        }
      }
    }
    return dist;
  }

  /**
   * Open cell farthest (by BFS steps) from (sx,sz); the exit placement.
   * @returns {{x:number, z:number, dist:number}}
   */
  farthestCell(sx, sz) {
    const dist = this.bfsDistances(sx, sz);
    let best = { x: sx, z: sz, dist: 0 };
    for (let i = 0; i < this.w; i++) {
      for (let j = 0; j < this.h; j++) {
        if (dist[i][j] > best.dist) best = { x: i, z: j, dist: dist[i][j] };
      }
    }
    return best;
  }

  /**
   * Pick n random open cells at least `minDist` BFS steps from (sx,sz),
   * spread apart (greedy min separation); used for enemy and health-pack spawns.
   * @returns {Array<{x:number, z:number}>}
   */
  pickOpenCells(sx, sz, n, minDist) {
    const dist = this.bfsDistances(sx, sz);
    const pool = [];
    for (let i = 1; i < this.w - 1; i++) {
      for (let j = 1; j < this.h - 1; j++) {
        if (this.isOpen(i, j) && dist[i][j] >= minDist) pool.push({ x: i, z: j });
      }
    }
    // Shuffle.
    for (let s = pool.length - 1; s > 0; s--) {
      const t = Math.floor(Math.random() * (s + 1));
      const tmp = pool[s]; pool[s] = pool[t]; pool[t] = tmp;
    }
    // Spread picks apart so they don't clump.
    const picks = [];
    const minSep = Math.max(2, Math.floor((this.w + this.h) / 12));
    for (let p = 0; p < pool.length && picks.length < n; p++) {
      const c = pool[p];
      let ok = true;
      for (let q = 0; q < picks.length; q++) {
        if (Math.abs(picks[q].x - c.x) + Math.abs(picks[q].z - c.z) < minSep) { ok = false; break; }
      }
      if (ok) picks.push(c);
    }
    // Fallback: relax separation if the maze is too small.
    for (let p2 = 0; p2 < pool.length && picks.length < n; p2++) {
      if (picks.indexOf(pool[p2]) === -1) picks.push(pool[p2]);
    }
    return picks;
  }

  /**
   * Wall matrix for PF.Grid (rows = z, cols = x; 1 = wall).
   * Cached: the maze never changes during a run.
   * @returns {number[][]}
   */
  pathMatrix() {
    if (!this._pathMatrix) {
      this._pathMatrix = [];
      for (let z = 0; z < this.h; z++) {
        this._pathMatrix[z] = [];
        for (let x = 0; x < this.w; x++) {
          this._pathMatrix[z][x] = this.grid[x][z] > 0 ? 1 : 0;
        }
      }
    }
    return this._pathMatrix;
  }
}
