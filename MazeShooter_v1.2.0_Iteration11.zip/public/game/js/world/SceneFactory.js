/**
 * MazeShooter · world/SceneFactory.js
 *
 * Builds the static environment (floor, walls, fog, lights) from a Maze.
 * Single responsibility: Three.js assembly, with no gameplay logic here,
 * so the world can be re-skinned or re-shaped without touching systems.
 *
 * Renderer note: the boilerplate shipped Three.js r49, which misrenders on
 * modern ANGLE/Vulkan GPU stacks; the vendored build is r128 (drop-in, same
 * architecture; see vendor/Three.js.
 */
export class SceneFactory {
  /**
   * @param {Maze} maze
   * @param {import('./TextureLib.js').TextureLib} textures
   * @param {{WALLHEIGHT:number}} worldConfig slice of CONFIG.world
   */
  constructor(maze, textures, worldConfig) {
    this._maze = maze;
    this._tex = textures;
    this._world = worldConfig;
  }

  /**
   * @returns {{scene: THREE.Scene, torch: THREE.PointLight}}
   */
  build() {
    const maze = this._maze;
    const scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2(0x05060a, 0.0021);

    this._buildFloor(scene);
    this._buildWalls(scene);
    this._buildLights(scene);

    // Torch that follows the camera (attached by Game to the camera rig).
    const torch = new THREE.PointLight(0xffe0b0, 1.55, 1050);
    torch.position.set(0, 30, 0);
    return { scene, torch };
  }

  _buildFloor(scene) {
    const m = this._maze;
    const floor = new THREE.Mesh(
      new THREE.BoxGeometry(m.w * m.unitSize, 10, m.h * m.unitSize),
      new THREE.MeshLambertMaterial({ map: this._tex.floor(m.w, m.h) })
    );
    floor.position.y = -5;
    scene.add(floor);
  }

  _buildWalls(scene) {
    const m = this._maze;
    const wallH = this._world.WALLHEIGHT;
    const cube = new THREE.BoxGeometry(m.unitSize, wallH, m.unitSize);
    const materials = {
      1: new THREE.MeshLambertMaterial({ map: this._tex.get('wall-1.jpg') }),
      2: new THREE.MeshLambertMaterial({ map: this._tex.get('wall-2.jpg') }),
    };
    for (let i = 0; i < m.w; i++) {
      for (let j = 0; j < m.h; j++) {
        if (m.grid[i][j] > 0) {
          const wall = new THREE.Mesh(cube, materials[m.grid[i][j]] || materials[1]);
          wall.position.set(m.centerX(i), wallH / 2, m.centerZ(j));
          scene.add(wall);
        }
      }
    }
  }

  _buildLights(scene) {
    scene.add(new THREE.AmbientLight(0x33333d));
    const sun = new THREE.DirectionalLight(0x8899bb, 0.18);
    sun.position.set(0.4, 1, 0.3);
    scene.add(sun);
  }
}
