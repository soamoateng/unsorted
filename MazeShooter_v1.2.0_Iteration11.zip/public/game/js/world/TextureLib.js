/**
 * MazeShooter · world/TextureLib.js
 *
 * Loads and caches the boilerplate's textures once (single responsibility:
 * texture IO). r128 TextureLoader replaces the boilerplate's r49
 * ImageUtils.loadTexture.
 */
export class TextureLib {
  /**
   * @param {string} baseUrl directory containing the images
   */
  constructor(baseUrl) {
    this._loader = new THREE.TextureLoader();
    this._base = baseUrl.replace(/\/$/, '') + '/';
    this._cache = new Map();
  }

  /**
   * @param {string} name file name, e.g. 'floor-1.jpg'
   * @returns {THREE.Texture}
   */
  get(name) {
    if (!this._cache.has(name)) {
      this._cache.set(name, this._loader.load(this._base + name));
    }
    return this._cache.get(name);
  }

  /** Floor texture preconfigured for per-sector tiling. */
  floor(repeatX, repeatY) {
    const tex = this.get('floor-1.jpg');
    tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
    tex.repeat.set(repeatX, repeatY);
    return tex;
  }
}
