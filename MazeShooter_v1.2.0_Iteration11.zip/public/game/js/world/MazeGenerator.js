/**
 * MazeShooter · world/MazeGenerator.js
 *
 * Pure maze-generation algorithm (no THREE and no DOM, so it is trivially
 * testable in Node). Produces the Nemesis-compatible grid format:
 *
 *   grid[i][j] = 0  ->  open floor
 *   grid[i][j] = 1  ->  wall, texture A (images/wall-1.jpg)
 *   grid[i][j] = 2  ->  wall, texture B (images/wall-2.jpg)
 *
 * i indexes x (east), j indexes z (south).
 *
 * Recursive backtracker (iterative stack) on odd cells, then extra interior
 * walls are opened to create loops so the maze is not strictly perfect,
 * which plays better for FPS combat and gives A* route choices.
 */

/**
 * @param {number} w width in sectors (odd; even input is bumped by 1)
 * @param {number} h height in sectors (odd)
 * @param {number} loops how many interior walls to open for loops
 * @returns {number[][]} grid[i][j]
 */
export function generateMaze(w, h, loops) {
  if (w % 2 === 0) w += 1;
  if (h % 2 === 0) h += 1;

  // Start fully solid; wall texture variant is chosen randomly (1 or 2).
  const grid = [];
  for (let i = 0; i < w; i++) {
    grid[i] = [];
    for (let j = 0; j < h; j++) {
      grid[i][j] = Math.random() < 0.5 ? 1 : 2;
    }
  }

  // --- Recursive backtracker on odd cells ---
  const stack = [[1, 1]];
  grid[1][1] = 0;
  const DIRS = [[-2, 0], [2, 0], [0, -2], [0, 2]];

  while (stack.length) {
    const cur = stack[stack.length - 1];
    const ci = cur[0], cj = cur[1];

    // Collect unvisited neighbors (odd cells still solid).
    const options = [];
    for (let d = 0; d < 4; d++) {
      const ni = ci + DIRS[d][0];
      const nj = cj + DIRS[d][1];
      if (ni > 0 && ni < w - 1 && nj > 0 && nj < h - 1 && grid[ni][nj] !== 0) {
        options.push([ni, nj]);
      }
    }

    if (options.length) {
      const next = options[Math.floor(Math.random() * options.length)];
      // Carve the wall between current and next, then the next cell.
      grid[ci + (next[0] - ci) / 2][cj + (next[1] - cj) / 2] = 0;
      grid[next[0]][next[1]] = 0;
      stack.push(next);
    } else {
      stack.pop();
    }
  }

  // --- Carve loops: open random interior walls with two open sides ---
  let opened = 0, guard = 0;
  while (opened < loops && guard < loops * 60) {
    guard++;
    const x = 1 + Math.floor(Math.random() * (w - 2));
    const z = 1 + Math.floor(Math.random() * (h - 2));
    if (grid[x][z] === 0) continue;
    if (x <= 0 || x >= w - 1 || z <= 0 || z >= h - 1) continue; // keep border solid
    const horizontal = grid[x - 1][z] === 0 && grid[x + 1][z] === 0;
    const vertical = grid[x][z - 1] === 0 && grid[x][z + 1] === 0;
    if (horizontal !== vertical) { // exactly one orientation connects
      grid[x][z] = 0;
      opened++;
    }
  }

  return grid;
}
