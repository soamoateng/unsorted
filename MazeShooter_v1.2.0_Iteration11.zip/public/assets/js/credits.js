/**
 * MazeShooter, credits.js (shared by landing + game).
 *
 * Opens and closes the "Open Source Credits" modal. Native <dialog>
 * gives us focus handling and the Escape key for free; tapping the
 * backdrop closes it too. Rendering uses textContent only, with no
 * HTML injection, so the attribution text stays exactly as authored.
 */
(function () {
  'use strict';

  var modal = document.getElementById('credits-modal');
  if (!modal) return;

  var openBtn = document.getElementById('open-credits');
  var closeBtn = document.getElementById('close-credits');

  if (openBtn) {
    openBtn.addEventListener('click', function () {
      if (typeof modal.showModal === 'function') modal.showModal();
      else modal.setAttribute('open', '');
    });
  }

  if (closeBtn) {
    closeBtn.addEventListener('click', function () { modal.close(); });
  }

  // A click on the dialog itself (not its children) is the backdrop.
  modal.addEventListener('click', function (e) {
    if (e.target === modal) modal.close();
  });
})();
