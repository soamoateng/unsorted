/**
 * MazeShooter, site.js (landing page chrome).
 *
 * Mobile menu toggle for the sticky header. Nav links close the menu
 * after tapping so the tapped section stays in view. The credits modal
 * lives in credits.js, shared with the game shell.
 */
(function () {
  'use strict';

  var burger = document.getElementById('burger');
  var nav = document.getElementById('nav');
  if (!burger || !nav) return;

  burger.addEventListener('click', function () {
    var open = nav.classList.toggle('open');
    burger.setAttribute('aria-expanded', open ? 'true' : 'false');
  });

  nav.addEventListener('click', function (e) {
    if (e.target && e.target.tagName === 'A') {
      nav.classList.remove('open');
      burger.setAttribute('aria-expanded', 'false');
    }
  });
})();
