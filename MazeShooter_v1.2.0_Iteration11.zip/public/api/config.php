<?php
/**
 * MazeShooter API · configuration.
 *
 * Storage driver is selected here (Dependency Inversion at the composition
 * root): 'sqlite' works out of the box on any PHP host (a file under
 * api/data/), while 'mysql' uses the credentials below. That is handy because most
 * cPanel shared hosts provision MySQL more prominently than SQLite.
 *
 * Every value can be overridden with an environment variable, so the same
 * file works in dev, preview and production without edits.
 */

declare(strict_types=1);

return [
    // 'sqlite' | 'mysql'
    'driver' => getenv('MAZESHOOTER_DB_DRIVER') ?: 'sqlite',

    'sqlite' => [
        'path' => __DIR__ . '/data/mazeshooter.sqlite',
    ],

    'mysql' => [
        'host'     => getenv('MAZESHOOTER_DB_HOST') ?: 'localhost',
        'port'     => getenv('MAZESHOOTER_DB_PORT') ?: '3306',
        'database' => getenv('MAZESHOOTER_DB_NAME') ?: 'mazeshooter',
        'user'     => getenv('MAZESHOOTER_DB_USER') ?: 'mazeshooter',
        'password' => getenv('MAZESHOOTER_DB_PASS') ?: '',
        'charset'  => 'utf8mb4',
    ],

    'leaderboard' => [
        'default_limit' => 10,
        'max_limit'     => 50,
    ],

    // Set to true only while debugging, and error payloads then include details.
    'debug' => (bool) (getenv('MAZESHOOTER_DEBUG') ?: false),
];
