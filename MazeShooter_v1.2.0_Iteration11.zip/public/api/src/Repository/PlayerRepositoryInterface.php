<?php

declare(strict_types=1);

namespace MazeShooter\Repository;

use MazeShooter\Database\ConnectionInterface;

/**
 * Player identity + settings persistence contract (Interface Segregation).
 */
interface PlayerRepositoryInterface
{
    /**
     * @return array{player_id:string, name:string, settings:array<string, mixed>, created_at:string, updated_at:string}|null
     */
    public function find(string $playerId): ?array;

    /**
     * Insert-or-update (server is the source of truth for settings).
     * Returns the stored row.
     */
    public function upsert(string $playerId, ?string $name, ?array $settings): array;

    /**
     * The player id that currently owns a gamer tag (case-insensitive),
     * excluding $exceptPlayerId, or null when the tag is free. Used to
     * keep gamer tags unique across players.
     */
    public function nameOwner(string $name, string $exceptPlayerId = ''): ?string;
}
