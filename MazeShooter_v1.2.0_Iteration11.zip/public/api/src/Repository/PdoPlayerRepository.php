<?php

declare(strict_types=1);

namespace MazeShooter\Repository;

use MazeShooter\Database\ConnectionInterface;

/**
 * PDO implementation of the player contract (portable SQL for both drivers).
 * Settings are stored as a JSON document: the game can evolve its settings
 * schema without migrations (Open/Closed at the storage boundary).
 */
final class PdoPlayerRepository implements PlayerRepositoryInterface
{
    /** @var ConnectionInterface */
    private $db;

    public function __construct(ConnectionInterface $db)
    {
        $this->db = $db;
    }

    public function find(string $playerId): ?array
    {
        $stmt = $this->db->pdo()->prepare(
            'SELECT player_id, name, settings, created_at, updated_at
             FROM players WHERE player_id = :pid'
        );
        $stmt->execute([':pid' => $playerId]);
        $row = $stmt->fetch();
        if (!$row) {
            return null;
        }
        return $this->hydrate($row);
    }

    public function upsert(string $playerId, ?string $name, ?array $settings): array
    {
        $existing = $this->find($playerId);
        $now      = gmdate('c');

        // Portable upsert (works on SQLite and MySQL alike): UPDATE first,
        // INSERT when the row does not exist yet. Two parallel first requests
        // can both see "missing" on a busy shared host, so a duplicate-key
        // failure on the INSERT falls back to the UPDATE branch (the winner
        // of the race keeps its values; the loser just updates the same row).
        if ($existing === null) {
            try {
                $stmt = $this->db->pdo()->prepare(
                    'INSERT INTO players (player_id, name, settings, created_at, updated_at)
                     VALUES (:pid, :name, :settings, :created, :updated)'
                );
                $stmt->execute([
                    ':pid'      => $playerId,
                    ':name'     => $name ?? 'Anonymous',
                    ':settings' => json_encode($settings ?? [], JSON_UNESCAPED_UNICODE),
                    ':created'  => $now,
                    ':updated'  => $now,
                ]);
                /** @var array<string, mixed> $row */
                $row = $this->find($playerId);
                return $row;
            } catch (\PDOException $e) {
                $existing = $this->find($playerId);
                if ($existing === null) {
                    throw $e; // a real error (lock timeout, connectivity), not the race
                }
            }
        }

        $stmt = $this->db->pdo()->prepare(
            'UPDATE players
             SET name = :name, settings = :settings, updated_at = :updated
             WHERE player_id = :pid'
        );
        $stmt->execute([
            ':pid'      => $playerId,
            ':name'     => $name ?? $existing['name'],
            ':settings' => json_encode($settings ?? $existing['settings'], JSON_UNESCAPED_UNICODE),
            ':updated'  => $now,
        ]);

        /** @var array<string, mixed> $row */
        $row = $this->find($playerId);
        return $row;
    }

    /**
     * Case-insensitive tag ownership lookup. MySQL's LOWER() is Unicode
     * aware with utf8mb4; SQLite's is ASCII-only, so on SQLite the query
     * uses the ms_lower() function registered by SqliteConnection::boot()
     * (mb_strtolower folding), which is also what the uniqueness index is
     * built on. The uniqueness rule itself is additionally backed by a
     * DB constraint so concurrent saves cannot both slip through.
     */
    public function nameOwner(string $name, string $exceptPlayerId = ''): ?string
    {
        $fold = $this->db->driver() === 'sqlite' ? 'ms_lower' : 'LOWER';
        $stmt = $this->db->pdo()->prepare(
            "SELECT player_id FROM players
             WHERE {$fold}(name) = {$fold}(:name) AND player_id <> :pid
             ORDER BY created_at ASC
             LIMIT 1"
        );
        $stmt->execute([':name' => $name, ':pid' => $exceptPlayerId]);
        $owner = $stmt->fetchColumn();
        return $owner === false ? null : (string) $owner;
    }

    /**
     * @param array<string, string> $row
     * @return array{player_id:string, name:string, settings:array<string, mixed>, created_at:string, updated_at:string}
     */
    private function hydrate(array $row): array
    {
        $decoded = json_decode((string) $row['settings'], true);
        return [
            'player_id'  => (string) $row['player_id'],
            'name'       => (string) $row['name'],
            'settings'   => is_array($decoded) ? $decoded : [],
            'created_at' => (string) $row['created_at'],
            'updated_at' => (string) $row['updated_at'],
        ];
    }
}
