<?php

declare(strict_types=1);

namespace MazeShooter\Repository;

use PDO;
use MazeShooter\Database\ConnectionInterface;

/**
 * PDO implementation of the score contract. Written against the portable
 * SQL subset supported by both SQLite and MySQL, so the same code serves
 * either driver (the ConnectionInterface it depends on is the DIP seam).
 */
final class PdoScoreRepository implements ScoreRepositoryInterface
{
    /** @var ConnectionInterface */
    private $db;

    public function __construct(ConnectionInterface $db)
    {
        $this->db = $db;
    }

    public function top(int $limit, int $offset = 0): array
    {
        $stmt = $this->db->pdo()->prepare(
            'SELECT id, name, score, kills, time_ms, shots_fired, shots_hit,
                    health_left, won, created_at
             FROM scores
             ORDER BY score DESC, time_ms ASC, created_at ASC
             LIMIT :lim OFFSET :off'
        );
        $stmt->bindValue(':lim', $limit, PDO::PARAM_INT);
        $stmt->bindValue(':off', $offset, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll() ?: [];
    }

    public function all(): array
    {
        $stmt = $this->db->pdo()->query(
            'SELECT id, name, score, kills, time_ms, shots_fired, shots_hit,
                    health_left, won, created_at
             FROM scores
             ORDER BY score DESC, time_ms ASC, created_at ASC'
        );
        return $stmt->fetchAll() ?: [];
    }

    public function add(array $entry): int
    {
        $stmt = $this->db->pdo()->prepare(
            'INSERT INTO scores
                (player_id, name, score, kills, time_ms, shots_fired, shots_hit,
                 health_left, won, created_at)
             VALUES
                (:player_id, :name, :score, :kills, :time_ms, :shots_fired, :shots_hit,
                 :health_left, :won, :created_at)'
        );
        $stmt->execute([
            ':player_id'   => (string) $entry['player_id'],
            ':name'        => (string) $entry['name'],
            ':score'       => (int) $entry['score'],
            ':kills'       => (int) $entry['kills'],
            ':time_ms'     => (int) $entry['time_ms'],
            ':shots_fired' => (int) $entry['shots_fired'],
            ':shots_hit'   => (int) $entry['shots_hit'],
            ':health_left' => (int) $entry['health_left'],
            ':won'         => (int) $entry['won'],
            ':created_at'  => (string) $entry['created_at'],
        ]);
        return (int) $this->db->pdo()->lastInsertId();
    }

    public function rankOfScore(int $score): int
    {
        $stmt = $this->db->pdo()->prepare('SELECT COUNT(*) + 1 FROM scores WHERE score > :score');
        $stmt->execute([':score' => $score]);
        return (int) $stmt->fetchColumn();
    }

    public function statsForPlayer(string $playerId): array
    {
        $stmt = $this->db->pdo()->prepare(
            'SELECT COUNT(*) AS games,
                    COALESCE(SUM(won), 0) AS wins,
                    COALESCE(MAX(score), 0) AS best_score,
                    COALESCE(SUM(kills), 0) AS total_kills,
                    COALESCE(SUM(time_ms), 0) AS total_time_ms,
                    COALESCE(MAX(time_ms), 0) AS longest_run_ms,
                    COALESCE(AVG(time_ms), 0) AS avg_run_ms,
                    COALESCE(SUM(shots_fired), 0) AS total_shots_fired,
                    COALESCE(SUM(shots_hit), 0) AS total_shots_hit,
                    MAX(created_at) AS last_played_at
             FROM scores WHERE player_id = :pid'
        );
        $stmt->execute([':pid' => $playerId]);
        $row = $stmt->fetch() ?: [];

        $fired = (int) ($row['total_shots_fired'] ?? 0);
        $hit   = (int) ($row['total_shots_hit'] ?? 0);

        return [
            'games'          => (int) ($row['games'] ?? 0),
            'wins'           => (int) ($row['wins'] ?? 0),
            'bestScore'      => (int) ($row['best_score'] ?? 0),
            'totalKills'     => (int) ($row['total_kills'] ?? 0),
            'totalTimeMs'    => (int) ($row['total_time_ms'] ?? 0),
            'longestRunMs'   => (int) ($row['longest_run_ms'] ?? 0),
            'avgRunMs'       => (int) round((float) ($row['avg_run_ms'] ?? 0)),
            'accuracyPct'    => $fired > 0 ? round(($hit / $fired) * 100, 1) : null,
            'totalShotsHit'  => $hit,
            'lastPlayedAt'   => (string) ($row['last_played_at'] ?? ''),
        ];
    }

    public function recentForPlayer(string $playerId, int $limit = 10): array
    {
        // created_at is an ISO-8601 UTC string, so lexicographic order is
        // chronological order on both SQLite and MySQL; id breaks ties.
        // Both params are bound explicitly (mixing bindValue with an
        // execute() array trips the SQLite driver's type checks).
        $stmt = $this->db->pdo()->prepare(
            'SELECT id, name, score, kills, time_ms, shots_fired, shots_hit,
                    health_left, won, created_at
             FROM scores
             WHERE player_id = :pid
             ORDER BY created_at DESC, id DESC
             LIMIT :lim'
        );
        $stmt->bindValue(':pid', $playerId, PDO::PARAM_STR);
        $stmt->bindValue(':lim', max(1, $limit), PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll() ?: [];
    }
}
