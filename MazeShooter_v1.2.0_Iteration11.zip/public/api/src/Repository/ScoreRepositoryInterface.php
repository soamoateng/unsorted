<?php

declare(strict_types=1);

namespace MazeShooter\Repository;

/**
 * Score persistence contract (Interface Segregation).
 * Consumers see exactly the operations the leaderboard needs, nothing more.
 */
interface ScoreRepositoryInterface
{
    /**
     * Top scores ordered by score DESC, completion time ASC.
     *
     * @return array<int, array<string, mixed>>
     */
    public function top(int $limit, int $offset = 0): array;

    /**
     * Every recorded score, ordered like top() (best first, no limit).
     *
     * @return array<int, array<string, mixed>>
     */
    public function all(): array;

    /**
     * Insert one finished run; returns the new row id.
     *
     * @param array<string, mixed> $entry
     */
    public function add(array $entry): int;

    /** 1-based leaderboard rank of a score value (ties share a rank). */
    public function rankOfScore(int $score): int;

    /**
     * Aggregated career stats for a player (finished runs only).
     *
     * @return array{games:int, wins:int, bestScore:int, totalKills:int,
     *               totalTimeMs:int, longestRunMs:int, avgRunMs:int,
     *               accuracyPct:float|null, totalShotsHit:int, lastPlayedAt:string}
     */
    public function statsForPlayer(string $playerId): array;

    /**
     * A player's most recent runs, newest first.
     *
     * @return array<int, array<string, mixed>>
     */
    public function recentForPlayer(string $playerId, int $limit = 10): array;
}
