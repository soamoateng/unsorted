<?php

declare(strict_types=1);

namespace MazeShooter\Database;

/**
 * Driver registry / factory (Open-Closed Principle in practice).
 * To support a new backend: add a ConnectionInterface implementation and
 * register it here. No consumer code changes.
 */
final class ConnectionFactory
{
    /** @var array<string, callable> driver => factory(config): ConnectionInterface */
    private static $drivers = [
        'sqlite' => [self::class, 'buildSqlite'],
        'mysql'  => [self::class, 'buildMysql'],
    ];

    /**
     * @param array<string, mixed> $config full API config
     */
    public static function create(array $config): ConnectionInterface
    {
        $driver = (string) ($config['driver'] ?? 'sqlite');
        if (!isset(self::$drivers[$driver])) {
            throw new \InvalidArgumentException('Unknown storage driver: ' . $driver);
        }
        return (self::$drivers[$driver])($config);
    }

    /**
     * Runtime extension point (keeps the factory open for extension without
     * editing this file, e.g. from a test bootstrap).
     */
    public static function register(string $driver, callable $builder): void
    {
        self::$drivers[$driver] = $builder;
    }

    private static function buildSqlite(array $config): ConnectionInterface
    {
        $path = (string) ($config['sqlite']['path'] ?? (__DIR__ . '/../../data/mazeshooter.sqlite'));
        return new SqliteConnection($path);
    }

    private static function buildMysql(array $config): ConnectionInterface
    {
        return new MysqlConnection((array) ($config['mysql'] ?? []));
    }
}
