<?php

declare(strict_types=1);

namespace MazeShooter\Database;

use PDO;

/**
 * SQLite backend: the zero-config default.
 * The database is a single file under api/data/ (protected by .htaccess).
 */
final class SqliteConnection extends AbstractPdoConnection
{
    /** @var string */
    private $path;

    public function __construct(string $path)
    {
        $this->path = $path;
    }

    public function driver(): string
    {
        return 'sqlite';
    }

    protected function dsn(): string
    {
        $dir = dirname($this->path);
        if (!is_dir($dir)) {
            // 0775: the web server user (www-data / cpanel user) needs write access.
            if (!mkdir($dir, 0775, true) && !is_dir($dir)) {
                throw new \RuntimeException('Cannot create database directory: ' . $dir);
            }
        }
        return 'sqlite:' . $this->path;
    }

    protected function boot(\PDO $pdo): void
    {
        // WAL = concurrent reads while writing; busy_timeout = survive locks
        // from parallel requests on busy shared hosting.
        $pdo->exec('PRAGMA journal_mode = WAL');
        $pdo->exec('PRAGMA busy_timeout = 5000');
        $pdo->exec('PRAGMA foreign_keys = ON');

        // Unicode-aware case folding for tag uniqueness. SQLite's built-in
        // LOWER() folds ASCII only, so 'Arger'/'ärger' (or Cyrillic pairs)
        // would bypass the case-insensitive match. Every connection this
        // class opens registers ms_lower, which the uniqueness index and
        // the ownership lookup both use. (Third-party sqlite3 CLI tools
        // will not know the function; the API itself always does.)
        $fold = static function ($s) {
            return mb_strtolower((string) $s, 'UTF-8');
        };
        // DETERMINISTIC is mandatory: SQLite only allows deterministic
        // functions inside index expressions (the uniqueness index below).
        if (class_exists('\Pdo\Sqlite') && $pdo instanceof \Pdo\Sqlite) {
            $pdo->createFunction('ms_lower', $fold, 1, \Pdo\Sqlite::DETERMINISTIC);
        } else {
            $pdo->sqliteCreateFunction('ms_lower', $fold, 1, \Pdo\Sqlite::DETERMINISTIC);
        }
    }

    protected function schemaStatements(): array
    {
        return [
            'CREATE TABLE IF NOT EXISTS players (
                player_id  TEXT PRIMARY KEY,
                name       TEXT NOT NULL DEFAULT \'Anonymous\',
                settings   TEXT NOT NULL DEFAULT \'{}\',
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            )',
            'CREATE TABLE IF NOT EXISTS scores (
                id           INTEGER PRIMARY KEY AUTOINCREMENT,
                player_id    TEXT NOT NULL,
                name         TEXT NOT NULL DEFAULT \'Anonymous\',
                score        INTEGER NOT NULL DEFAULT 0,
                kills        INTEGER NOT NULL DEFAULT 0,
                time_ms      INTEGER NOT NULL DEFAULT 0,
                shots_fired  INTEGER NOT NULL DEFAULT 0,
                shots_hit    INTEGER NOT NULL DEFAULT 0,
                health_left  INTEGER NOT NULL DEFAULT 0,
                won          INTEGER NOT NULL DEFAULT 0,
                created_at   TEXT NOT NULL
            )',
            'CREATE INDEX IF NOT EXISTS idx_scores_score ON scores (score DESC)',
            'CREATE INDEX IF NOT EXISTS idx_scores_player ON scores (player_id)',
        ];
    }

    public function migrate(): void
    {
        parent::migrate();
        // Uniqueness backstop for the controller's check-then-act 409: two
        // concurrent PUTs with the same new tag can both pass the lookup,
        // and this partial expression index is what stops the second one.
        // It is created here (not in schemaStatements) so a legacy database
        // with duplicate rows logs a warning instead of bricking the API —
        // the controller-level check remains the friendly path.
        try {
            $this->pdo()->exec(
                "CREATE UNIQUE INDEX IF NOT EXISTS idx_players_name_ci
                 ON players (ms_lower(name))
                 WHERE ms_lower(name) <> 'anonymous'"
            );
        } catch (\PDOException $e) {
            error_log('[MazeShooter] tag-uniqueness index not created (duplicate tags in data?): ' . $e->getMessage());
        }
    }
}
