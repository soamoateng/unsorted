<?php

declare(strict_types=1);

namespace MazeShooter\Database;

use PDO;

/**
 * Lazy PDO connection base (Template Method).
 *
 * Subclasses describe HOW to connect (dsn/options) and WHICH schema to create;
 * the base class handles WHEN (lazily, once per request) and runs migrations.
 * Single responsibility: own PDO lifecycle + migration orchestration.
 */
abstract class AbstractPdoConnection implements ConnectionInterface
{
    /** @var PDO|null */
    private $pdo;

    /** @var bool */
    private $migrated = false;

    final public function pdo(): PDO
    {
        if ($this->pdo === null) {
            $this->pdo = new PDO(
                $this->dsn(),
                $this->username(),
                $this->password(),
                $this->options()
            );
            $this->boot($this->pdo);
        }
        return $this->pdo;
    }

    /**
     * Runs the driver's schemaStatements() once per request. No longer
     * final: a driver may append its own idempotent step after the base
     * schema (SQLite adds the tag-uniqueness expression index here, in a
     * guarded migrate() override).
     */
    public function migrate(): void
    {
        if ($this->migrated) {
            return;
        }
        $pdo = $this->pdo();
        foreach ($this->schemaStatements() as $sql) {
            $pdo->exec($sql);
        }
        $this->migrated = true;
    }

    /** PDO DSN string. */
    abstract protected function dsn(): string;

    protected function username(): string
    {
        return '';
    }

    protected function password(): string
    {
        return '';
    }

    /**
     * @return array<int, int>
     */
    protected function options(): array
    {
        return [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ];
    }

    /** Driver-specific session setup (PRAGMAs, charset, ...). */
    protected function boot(PDO $pdo): void
    {
    }

    /**
     * Idempotent DDL statements (CREATE TABLE IF NOT EXISTS / CREATE INDEX
     * IF NOT EXISTS), which stays portable across the supported drivers.
     *
     * @return array<int, string>
     */
    abstract protected function schemaStatements(): array;
}
