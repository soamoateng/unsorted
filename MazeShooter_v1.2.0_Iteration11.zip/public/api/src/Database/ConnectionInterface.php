<?php

declare(strict_types=1);

namespace MazeShooter\Database;

use PDO;

/**
 * Storage abstraction (Dependency Inversion Principle).
 *
 * The domain (repositories, controllers) depends on this interface, never on
 * a concrete PDO driver. Adding a new backend (e.g. PostgreSQL) means adding
 * one class + one factory-map entry, with no existing code changes (Open/Closed).
 */
interface ConnectionInterface
{
    public function pdo(): PDO;

    /** @return string 'sqlite' | 'mysql' | ... */
    public function driver(): string;

    /** Create tables when missing (idempotent, safe to call every request). */
    public function migrate(): void;
}
