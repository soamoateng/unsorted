<?php

declare(strict_types=1);

namespace MazeShooter\Database;

/**
 * MySQL backend, a first-class alternative for cPanel hosts where MySQL is
 * the more familiar option. Switching drivers is a one-line config change
 * ('driver' => 'mysql' plus credentials), never a code change (OCP/DIP).
 */
final class MysqlConnection extends AbstractPdoConnection
{
    /** @var array<string, string> */
    private $config;

    /**
     * @param array<string, string> $config host/port/database/user/password/charset
     */
    public function __construct(array $config)
    {
        $this->config = $config;
    }

    public function driver(): string
    {
        return 'mysql';
    }

    protected function dsn(): string
    {
        return sprintf(
            'mysql:host=%s;port=%s;dbname=%s;charset=%s',
            $this->config['host'] ?? 'localhost',
            $this->config['port'] ?? '3306',
            $this->config['database'] ?? 'mazeshooter',
            $this->config['charset'] ?? 'utf8mb4'
        );
    }

    protected function username(): string
    {
        return (string) ($this->config['user'] ?? '');
    }

    protected function password(): string
    {
        return (string) ($this->config['password'] ?? '');
    }

    protected function schemaStatements(): array
    {
        // The name_ci generated column + UNIQUE key back the controller's
        // tag-uniqueness 409 against concurrent saves (MySQL's LOWER() is
        // already Unicode-aware with utf8mb4). Note for databases created
        // before this column existed: add it manually once with
        //   ALTER TABLE players
        //     ADD COLUMN name_ci VARCHAR(32) GENERATED ALWAYS AS (LOWER(name)) STORED,
        //     ADD UNIQUE KEY idx_players_name_ci (name_ci);
        // CREATE TABLE IF NOT EXISTS cannot retrofit an existing table.
        return [
            'CREATE TABLE IF NOT EXISTS players (
                player_id  VARCHAR(64) NOT NULL PRIMARY KEY,
                name       VARCHAR(32) NOT NULL DEFAULT \'Anonymous\',
                name_ci    VARCHAR(32) GENERATED ALWAYS AS (LOWER(name)) STORED,
                settings   TEXT NOT NULL,
                created_at VARCHAR(32) NOT NULL,
                updated_at VARCHAR(32) NOT NULL,
                UNIQUE KEY idx_players_name_ci (name_ci)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4',
            'CREATE TABLE IF NOT EXISTS scores (
                id           BIGINT UNSIGNED NOT NULL PRIMARY KEY AUTO_INCREMENT,
                player_id    VARCHAR(64) NOT NULL,
                name         VARCHAR(32) NOT NULL DEFAULT \'Anonymous\',
                score        INT NOT NULL DEFAULT 0,
                kills        INT NOT NULL DEFAULT 0,
                time_ms      INT NOT NULL DEFAULT 0,
                shots_fired  INT NOT NULL DEFAULT 0,
                shots_hit    INT NOT NULL DEFAULT 0,
                health_left  INT NOT NULL DEFAULT 0,
                won          TINYINT NOT NULL DEFAULT 0,
                created_at   VARCHAR(32) NOT NULL,
                INDEX idx_scores_score (score DESC),
                INDEX idx_scores_player (player_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4',
        ];
    }
}
