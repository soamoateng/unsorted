<?php

declare(strict_types=1);

namespace MazeShooter\Support;

/**
 * Shapes a raw score row into the public API payload. Extracted from
 * LeaderboardController so every controller that returns score rows
 * (leaderboard, player profile, recent runs) presents them identically
 * and DB column names stay out of the API contract (DRY).
 */
final class ScorePresenter
{
    /**
     * @param array<string, mixed> $row
     * @return array<string, mixed>
     */
    public static function present(array $row): array
    {
        $fired = (int) ($row['shots_fired'] ?? 0);
        $hit   = (int) ($row['shots_hit'] ?? 0);
        return [
            'id'         => (int) ($row['id'] ?? 0),
            'name'       => (string) $row['name'],
            'score'      => (int) $row['score'],
            'kills'      => (int) $row['kills'],
            'timeMs'     => (int) $row['time_ms'],
            'accuracy'   => $fired > 0 ? round($hit / $fired, 3) : null,
            'healthLeft' => (int) ($row['health_left'] ?? 0),
            'won'        => (int) ($row['won'] ?? 0) === 1,
            'createdAt'  => (string) ($row['created_at'] ?? ''),
        ];
    }

    /**
     * @param array<int, array<string, mixed>> $rows
     * @return array<int, array<string, mixed>>
     */
    public static function presentAll(array $rows): array
    {
        return array_map([self::class, 'present'], $rows);
    }
}
