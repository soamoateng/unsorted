<?php

declare(strict_types=1);

namespace MazeShooter\Support;

/**
 * Thrown by the Validator when untrusted request data fails a check.
 * Lives in its own file so the PSR-4 autoloader can always resolve it,
 * even before the Validator class itself has been loaded.
 */
class ValidationError extends \RuntimeException
{
}
