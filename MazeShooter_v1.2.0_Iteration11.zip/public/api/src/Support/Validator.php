<?php

declare(strict_types=1);

namespace MazeShooter\Support;

/**
 * Input validation. Single responsibility: turn untrusted request data into
 * typed, range-checked values or throw ValidationError (see the sibling
 * ValidationError.php, one class per file for the autoloader).
 */
final class Validator
{
    /**
     * Settings whitelist: keys the server accepts, with sanitizers.
     * Unknown keys from the client are dropped (the client cannot smuggle
     * arbitrary data into storage), new keys are added here + in the client
     * Config.js defaults.
     *
     * @return array<string, mixed>
     */
    public static function settings($raw): array
    {
        if (!is_array($raw)) {
            return [];
        }
        $out = [];
        if (isset($raw['lookSensitivity'])) {
            $out['lookSensitivity'] = self::float($raw['lookSensitivity'], 0.2, 3.0, 1.0);
        }
        if (isset($raw['invertY'])) {
            $out['invertY'] = self::bool($raw['invertY'], false);
        }
        if (isset($raw['soundOn'])) {
            $out['soundOn'] = self::bool($raw['soundOn'], true);
        }
        if (isset($raw['showRadar'])) {
            $out['showRadar'] = self::bool($raw['showRadar'], true);
        }
        return $out;
    }

    public static function playerId($raw): string
    {
        $id = is_string($raw) ? trim($raw) : '';
        if (strlen($id) < 8 || strlen($id) > 64 || !preg_match('/^[A-Za-z0-9_-]+$/', $id)) {
            throw new ValidationError('playerId must be 8-64 chars of [A-Za-z0-9_-]');
        }
        return $id;
    }

    /**
     * Gamer tag rules, the strict variant used wherever a tag is being
     * CHOSEN (player save). A tag is at least 3 and at most 24 characters
     * after trimming and control-character removal; anything shorter is a
     * ValidationError so the client can show a helpful message. The
     * lenient playerName() below is only for passive places (score
     * submissions from clients that never chose a tag).
     */
    public static function gamerTag($raw): string
    {
        $name = self::cleanName($raw);
        if (mb_strlen($name) < 3) {
            throw new ValidationError('Gamer tags are at least 3 characters long');
        }
        return mb_strlen($name) > 24 ? mb_substr($name, 0, 24) : $name;
    }

    public static function playerName($raw, string $default = 'Anonymous'): string
    {
        if ($raw === null) {
            return $default;
        }
        $name = self::cleanName($raw);
        // Tags are 3+ characters now; a short value from a stale client
        // degrades to the shared default instead of landing on the board.
        if (mb_strlen($name) < 3) {
            return $default;
        }
        if (mb_strlen($name) > 24) {
            $name = mb_substr($name, 0, 24);
        }
        return $name;
    }

    /**
     * Shared name hygiene: cast to string, strip control characters AND
     * invisible Unicode (zero-width spaces/joiners U+200B-200D, byte-order
     * mark U+FEFF, bidi overrides U+202A-202E, isolates U+2066-2069,
     * variation selectors U+FE00-FE0F), then trim. Mirrors the client-side
     * GamerTag.clean() so both sides agree: 'Player' and 'Player' with an
     * embedded zero-width space must be the SAME tag, or the leaderboard
     * becomes trivially spoofable.
     */
    private static function cleanName($raw): string
    {
        $name = trim((string) $raw);
        $name = preg_replace(
            '/[\x00-\x1F\x7F\x{200B}-\x{200D}\x{FEFF}\x{202A}-\x{202E}\x{2066}-\x{2069}\x{FE00}-\x{FE0F}]/u',
            '',
            $name
        );
        return $name ?? '';
    }

    public static function int($raw, int $min, int $max, int $default = 0): int
    {
        if (!is_numeric($raw)) {
            return $default;
        }
        return max($min, min($max, (int) $raw));
    }

    public static function float($raw, float $min, float $max, float $default): float
    {
        if (!is_numeric($raw)) {
            return $default;
        }
        return round(max($min, min($max, (float) $raw)), 2);
    }

    public static function bool($raw, bool $default): bool
    {
        if (is_bool($raw)) {
            return $raw;
        }
        if (is_numeric($raw)) {
            return ((int) $raw) === 1;
        }
        return $default;
    }
}
