<?php

declare(strict_types=1);

namespace MazeShooter\Http;

/**
 * JSON response value object.
 * Single responsibility: carry status + payload and know how to emit itself.
 */
final class Response
{
    /** @var int */
    private $status;

    /** @var array<string, mixed> */
    private $data;

    /** @var array<string, string> */
    private $headers;

    /**
     * @param array<string, mixed> $data
     * @param array<string, string> $headers
     */
    public function __construct(array $data, int $status = 200, array $headers = [])
    {
        $this->data    = $data;
        $this->status  = $status;
        $this->headers = $headers;
    }

    /**
     * @param array<string, mixed> $data
     */
    public static function json(array $data, int $status = 200): self
    {
        return new self($data, $status);
    }

    public static function error(string $message, int $status = 400, array $extra = []): self
    {
        return self::json(array_merge(['ok' => false, 'error' => $message], $extra), $status);
    }

    public function status(): int
    {
        return $this->status;
    }

    public function send(): void
    {
        http_response_code($this->status);
        header('Content-Type: application/json; charset=utf-8');
        foreach ($this->headers as $name => $value) {
            header($name . ': ' . $value);
        }
        echo json_encode($this->data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    }
}
