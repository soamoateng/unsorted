<?php

declare(strict_types=1);

namespace MazeShooter\Http;

/**
 * Minimal pattern router.
 * Single responsibility: match "METHOD /path/{param}" against handlers.
 *
 * Handlers are callables receiving (Request, array<string,string> $params)
 * and returning a Response, while the router knows nothing about controllers,
 * storage or the domain (Dependency Inversion).
 */
final class Router
{
    /** @var array<string, array<string, callable>> route => method => handler */
    private $routes = [];

    public function add(string $method, string $pattern, callable $handler): void
    {
        $method = strtoupper($method);
        $this->routes[$pattern][$method] = $handler;
    }

    public function get(string $pattern, callable $handler): void
    {
        $this->add('GET', $pattern, $handler);
    }

    public function post(string $pattern, callable $handler): void
    {
        $this->add('POST', $pattern, $handler);
    }

    public function put(string $pattern, callable $handler): void
    {
        $this->add('PUT', $pattern, $handler);
    }

    public function dispatch(Request $request): Response
    {
        foreach ($this->routes as $pattern => $handlers) {
            $params = $this->match($pattern, $request->path());
            if ($params === null) {
                continue;
            }
            $method = $request->method();
            if ($method === 'OPTIONS') {
                return Response::json(['ok' => true], 204);
            }
            if (isset($handlers[$method])) {
                return ($handlers[$method])($request, $params);
            }
            // Path matched but verb did not.
            $allowed = implode(', ', array_keys($handlers));
            return Response::error('Method not allowed', 405, ['allow' => $allowed]);
        }

        return Response::error('Not found', 404);
    }

    /**
     * @return array<string, string>|null named params, or null when no match
     */
    private function match(string $pattern, string $path): ?array
    {
        $regex = '#^' . preg_replace('#\{([a-zA-Z_]+)\}#', '(?P<$1>[^/]+)', $pattern) . '/?$#';
        if (preg_match($regex, $path, $m) !== 1) {
            return null;
        }
        $params = [];
        foreach ($m as $key => $value) {
            if (is_string($key)) {
                $params[$key] = $value;
            }
        }
        return $params;
    }
}
