<?php

declare(strict_types=1);

namespace MazeShooter\Http;

/**
 * Immutable-ish value object around the incoming HTTP request.
 * Single responsibility: expose request data in a normalized way.
 */
final class Request
{
    /** @var string */
    private $method;

    /** @var string */
    private $path;

    /** @var array<string, mixed> */
    private $query;

    /** @var array<string, mixed>|null */
    private $jsonBody;

    public function __construct()
    {
        $this->method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');

        $uri  = (string) parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH);
        $path = $uri;

        // When Apache rewrites /<subdir>/api/... to index.php (or index.php is
        // hit directly), SCRIPT_NAME carries the real installation prefix, so
        // stripping dirname(SCRIPT_NAME) makes routes work at a domain root
        // and inside any subfolder. The built-in dev server reports the raw
        // request path instead, which the legacy rules below handle.
        $scriptName = (string) ($_SERVER['SCRIPT_NAME'] ?? '');
        if (substr($scriptName, -10) === '/index.php') {
            $base = substr($scriptName, 0, -9); // ".../api/" including prefix
            if ($base !== '/' && strpos($path, $base) === 0) {
                $path = substr($path, strlen($base) - 1);
            }
        }
        // Normalize when the front controller is hit directly (/api/index.php)
        // or routed through /api/* (dev router and root Apache installs).
        if (strpos($path, '/api') === 0) {
            $path = substr($path, 4);
        }
        if (strpos($path, '/index.php') === 0) {
            $path = substr($path, 10);
        }
        $this->path  = '/' . trim($path, '/');
        $this->query = $_GET;
    }

    public function method(): string
    {
        return $this->method;
    }

    public function path(): string
    {
        return $this->path;
    }

    public function query(string $name, $default = null)
    {
        return $this->query[$name] ?? $default;
    }

    public function header(string $name): string
    {
        $key = 'HTTP_' . strtoupper(str_replace('-', '_', $name));
        return (string) ($_SERVER[$key] ?? '');
    }

    public function ip(): string
    {
        return (string) ($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0');
    }

    /**
     * Decoded JSON body (cached). Returns [] for empty or invalid bodies, so
     * validation decides whether required fields are missing.
     *
     * @return array<string, mixed>
     */
    public function json(): array
    {
        if ($this->jsonBody === null) {
            $raw = file_get_contents('php://input') ?: '';
            $decoded = json_decode($raw, true);
            $this->jsonBody = is_array($decoded) ? $decoded : [];
        }
        return $this->jsonBody;
    }

    public function input(string $name, $default = null)
    {
        return $this->json()[$name] ?? $default;
    }
}
