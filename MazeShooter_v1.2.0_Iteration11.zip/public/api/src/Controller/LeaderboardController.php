<?php

declare(strict_types=1);

namespace MazeShooter\Controller;

use MazeShooter\Http\Request;
use MazeShooter\Http\Response;
use MazeShooter\Repository\PlayerRepositoryInterface;
use MazeShooter\Repository\ScoreRepositoryInterface;
use MazeShooter\Support\ScorePresenter;
use MazeShooter\Support\ValidationError;
use MazeShooter\Support\Validator;

/**
 * Leaderboard use-cases. Single responsibility: translate HTTP requests
 * into repository calls and JSON responses, with no SQL and no PDO here.
 */
final class LeaderboardController
{
    private const MAX_SCORE     = 1000000;
    private const MAX_KILLS     = 1000;
    private const MAX_TIME_MS   = 86400000;
    private const MAX_SHOTS     = 100000;
    private const MAX_SEED_LEN  = 32;

    /**
     * Cross-field invariants (the game's own math, mirrored server-side):
     * a win requires clearing the opening squad (client CONFIG.gameplay.NUMAI
     * = 8) before the exit unlocks, so won runs have at least this many
     * kills; score is always at least kills x KILL (100) and at most
     * kills x KILL + max time bonus (2000) + max health bonus (100 x 5).
     */
    private const MIN_WIN_KILLS = 8;
    private const MAX_SCORE_BONUS = 2500;

    /**
     * The submission response carries the top of the board (not every run
     * ever recorded): the end screen needs the leaders and the player's own
     * rank (returned separately), so the payload stays bounded as history
     * grows. The explicit ?all=1 view keeps returning the full board.
     */
    private const SUBMIT_BOARD_LIMIT = 50;

    /** @var ScoreRepositoryInterface */
    private $scores;

    /** @var PlayerRepositoryInterface|null */
    private $players;

    /** @var int */
    private $defaultLimit;

    /** @var int */
    private $maxLimit;

    public function __construct(
        ScoreRepositoryInterface $scores,
        int $defaultLimit = 10,
        int $maxLimit = 50,
        ?PlayerRepositoryInterface $players = null
    ) {
        $this->scores       = $scores;
        $this->players      = $players;
        $this->defaultLimit = $defaultLimit;
        $this->maxLimit     = $maxLimit;
    }

    public function top(Request $request): Response
    {
        $offset = Validator::int($request->query('offset'), 0, 10000, 0);

        // all=1 returns every recorded run (the leaderboard shows all
        // scores, not just the top few); otherwise the classic paging
        // window applies.
        $all = Validator::bool($request->query('all'), false);
        if ($all) {
            $rows = $this->scores->all();
            return Response::json([
                'ok'      => true,
                'count'   => count($rows),
                'offset'  => 0,
                'scores'  => ScorePresenter::presentAll($rows),
            ]);
        }

        $limit = Validator::int($request->query('limit'), 1, $this->maxLimit, $this->defaultLimit);
        return Response::json([
            'ok'      => true,
            'count'   => $limit,
            'offset'  => $offset,
            'scores'  => ScorePresenter::presentAll($this->scores->top($limit, $offset)),
        ]);
    }

    public function submit(Request $request): Response
    {
        try {
            $body = $request->json();
            $entry = [
                'player_id'   => Validator::playerId($body['playerId'] ?? null),
                'name'        => Validator::playerName($body['name'] ?? null),
                'score'       => Validator::int($body['score'] ?? null, 0, self::MAX_SCORE),
                'kills'       => Validator::int($body['kills'] ?? null, 0, self::MAX_KILLS),
                'time_ms'     => Validator::int($body['timeMs'] ?? null, 0, self::MAX_TIME_MS),
                'shots_fired' => Validator::int($body['shotsFired'] ?? null, 0, self::MAX_SHOTS),
                'shots_hit'   => Validator::int($body['shotsHit'] ?? null, 0, self::MAX_SHOTS),
                'health_left' => Validator::int($body['healthLeft'] ?? null, 0, 100),
                'won'         => Validator::bool($body['won'] ?? false, false) ? 1 : 0,
                'created_at'  => gmdate('c'),
            ];
            self::assertCrossField($entry);
        } catch (ValidationError $e) {
            return Response::error($e->getMessage(), 422);
        }

        // Tag integrity: a score may only carry a tag its submitter owns.
        // Everything else degrades to the shared Anonymous default, so a
        // crafted request (or an offline tag that lost its 409 race) can
        // never place an impersonating name on the board.
        if ($this->players !== null
            && $entry['name'] !== 'Anonymous'
            && $this->players->nameOwner($entry['name'], $entry['player_id']) !== null
        ) {
            $entry['name'] = 'Anonymous';
        }

        $id   = $this->scores->add($entry);
        $rank = $this->scores->rankOfScore((int) $entry['score']);

        return Response::json([
            'ok'          => true,
            // present($entry) first so the real id/rank win the merge.
            'entry'       => array_merge(
                ScorePresenter::present($entry),
                ['id' => $id, 'rank' => $rank]
            ),
            // Top of the board (bounded; see SUBMIT_BOARD_LIMIT).
            'leaderboard' => ScorePresenter::presentAll(
                $this->scores->top(self::SUBMIT_BOARD_LIMIT, 0)
            ),
        ], 201);
    }

    /**
     * Cross-field rules: every field is range-checked individually above;
     * these are the consistency rules BETWEEN fields that crafted requests
     * violate but real play (ScoreCalculator) never can.
     *
     * @param array<string, mixed> $e
     * @throws ValidationError
     */
    private static function assertCrossField(array $e): void
    {
        if ($e['shots_hit'] > $e['shots_fired']) {
            throw new ValidationError('shotsHit cannot exceed shotsFired');
        }
        if ($e['won'] === 1) {
            if ($e['kills'] < self::MIN_WIN_KILLS) {
                throw new ValidationError('A won run must clear every hunter in the opening squad');
            }
            if ($e['time_ms'] <= 0) {
                throw new ValidationError('A won run must have a positive survival time');
            }
        }
        $min = $e['kills'] * 100;
        if ($e['score'] < $min || $e['score'] > $min + self::MAX_SCORE_BONUS) {
            throw new ValidationError('Score is inconsistent with kills/won for this game');
        }
    }
}
