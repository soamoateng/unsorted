<?php

declare(strict_types=1);

namespace MazeShooter\Controller;

use MazeShooter\Http\Request;
use MazeShooter\Http\Response;
use MazeShooter\Repository\PlayerRepositoryInterface;
use MazeShooter\Repository\ScoreRepositoryInterface;
use MazeShooter\Support\ScorePresenter;
use MazeShooter\Support\ValidationError;
use MazeShooter\Support\Validator;

/**
 * Player identity + settings use-cases.
 * GET returns stored settings (or the caller's defaults when unseen),
 * PUT upserts name and/or settings.
 */
final class PlayerController
{
    /** @var PlayerRepositoryInterface */
    private $players;

    /** @var ScoreRepositoryInterface */
    private $scores;

    /** @var array<string, mixed> */
    private $settingDefaults;

    /**
     * @param array<string, mixed> $settingDefaults must match Config.js on the client
     */
    public function __construct(
        PlayerRepositoryInterface $players,
        ScoreRepositoryInterface $scores,
        array $settingDefaults
    ) {
        $this->players         = $players;
        $this->scores          = $scores;
        $this->settingDefaults = $settingDefaults;
    }

    public function get(Request $request, array $params): Response
    {
        try {
            $playerId = Validator::playerId($params['id'] ?? null);
        } catch (ValidationError $e) {
            return Response::error($e->getMessage(), 422);
        }

        $row = $this->players->find($playerId);
        if ($row === null) {
            // No player row yet (Anonymous flow: runs are submitted without
            // ever saving a tag or settings). The runs themselves live in the
            // scores table keyed by the same player id, so career stats and
            // recent runs must still surface here -- gating them behind the
            // players row left those players with a permanently empty loft.
            return Response::json([
                'ok'       => true,
                'exists'   => false,
                'settings' => $this->settingDefaults,
                'stats'    => $this->scores->statsForPlayer($playerId),
                'recent'   => ScorePresenter::presentAll(
                    $this->scores->recentForPlayer($playerId, 10)
                ),
            ]);
        }

        return Response::json([
            'ok'       => true,
            'exists'   => true,
            'player'   => [
                'playerId'  => $row['player_id'],
                'name'      => $row['name'],
                'createdAt' => $row['created_at'],
            ],
            'settings' => array_merge($this->settingDefaults, $row['settings']),
            'stats'    => $this->scores->statsForPlayer($playerId),
            'recent'   => ScorePresenter::presentAll(
                $this->scores->recentForPlayer($playerId, 10)
            ),
        ]);
    }

    public function save(Request $request, array $params): Response
    {
        try {
            $playerId = Validator::playerId($params['id'] ?? null);
            $body     = $request->json();
            // An empty name must never wipe the stored one ('' -> null = keep).
            // A present name is a CHOSEN tag: strict length rules apply.
            $name     = null;
            if (isset($body['name']) && trim((string) $body['name']) !== '') {
                $name = Validator::gamerTag($body['name']);
            }
            $settings = isset($body['settings']) ? Validator::settings($body['settings']) : null;
        } catch (ValidationError $e) {
            return Response::error($e->getMessage(), 422);
        }

        // Gamer tags are unique per player (case-insensitive). The lookup
        // below is the friendly path; a partial UNIQUE index on the folded
        // name (SQLite: ms_lower expression index, MySQL: name_ci generated
        // column) backstops it, so two concurrent saves with the same new
        // tag cannot both persist — the losing request is translated into
        // the same 409 instead of a storage error.
        if ($name !== null) {
            $ownerId = $this->players->nameOwner($name, $playerId);
            if ($ownerId !== null) {
                return Response::error(
                    'That gamer tag is already taken. Pick another one.',
                    409
                );
            }
        }

        $existing = $this->players->find($playerId);

        try {
            $row = $this->players->upsert($playerId, $name, $settings);
        } catch (\PDOException $e) {
            if (self::isUniqueViolation($e)) {
                return Response::error(
                    'That gamer tag is already taken. Pick another one.',
                    409
                );
            }
            error_log('[MazeShooter] player save failed: ' . $e->getMessage());
            return Response::error('Could not save player data', 500);
        } catch (\Throwable $e) {
            error_log('[MazeShooter] player save failed: ' . $e->getMessage());
            return Response::error('Could not save player data', 500);
        }

        return Response::json([
            'ok'       => true,
            'player'   => [
                'playerId'  => $row['player_id'],
                'name'      => $row['name'],
                'createdAt' => $row['created_at'],
            ],
            'settings' => array_merge(
                $this->settingDefaults,
                $settings ?? $existing['settings'] ?? [],
                $row['settings']
            ),
        ]);
    }

    /**
     * Whether a PDOException looks like a unique-constraint hit (the tag
     * uniqueness backstop). Checked portably across SQLite/MySQL messages
     * and SQLSTATE 23000/23505.
     */
    private static function isUniqueViolation(\PDOException $e): bool
    {
        $code = (string) $e->getCode();
        if ($code === '23000' || $code === '23505') {
            return true;
        }
        $msg = strtolower($e->getMessage());
        return strpos($msg, 'unique') !== false
            || strpos($msg, 'duplicate entry') !== false;
    }
}
