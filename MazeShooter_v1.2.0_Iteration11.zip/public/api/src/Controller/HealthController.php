<?php

declare(strict_types=1);

namespace MazeShooter\Controller;

use MazeShooter\Http\Request;
use MazeShooter\Http\Response;

/**
 * Liveness/metadata endpoint. Single responsibility: tell clients the API
 * is up and which storage driver is active.
 */
final class HealthController
{
    public function index(Request $request): Response
    {
        return Response::json([
            'ok'      => true,
            'service' => 'mazeshooter-api',
            'version' => '1.2.0',
            'time'    => gmdate('c'),
        ]);
    }
}
