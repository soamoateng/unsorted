<?php

/**
 * MazeShooter API · front controller.
 *
 * The only PHP file the web server executes directly. Responsibilities:
 *   - autoload MazeShooter\ classes (no Composer needed on shared hosting)
 *   - CORS + security headers
 *   - JSON error handling
 *   - compose the object graph (config → connection → repositories →
 *     controllers → routes) and the Dependency Inversion composition root
 *   - dispatch and emit
 */

declare(strict_types=1);

// ---------------------------------------------------------------------------
// Output hardening (must run before ANY other code can emit output).
// A PHP notice/warning echoed into the response corrupts the JSON body
// (HTTP 200 + garbage), which the client reads as null and surfaces as a
// mysterious "leaderboard unavailable". Errors go to the log instead —
// the JSON exception handler below owns the response body.
// ---------------------------------------------------------------------------
ini_set('display_errors', '0');
ini_set('display_startup_errors', '0');
ini_set('log_errors', '1');

// ---------------------------------------------------------------------------
// Autoloader (PSR-4 style, Composer-free for cPanel friendliness)
// ---------------------------------------------------------------------------
spl_autoload_register(static function (string $class): void {
    $prefix = 'MazeShooter\\';
    if (strpos($class, $prefix) !== 0) {
        return;
    }
    $relative = substr($class, strlen($prefix));
    $file = __DIR__ . '/src/' . str_replace('\\', '/', $relative) . '.php';
    if (is_file($file)) {
        require $file;
    }
});

// ---------------------------------------------------------------------------
// Shared headers (CORS: the game may be served from another origin/domain)
// ---------------------------------------------------------------------------
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: same-origin');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
header('Access-Control-Max-Age: 600');

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'OPTIONS') {
    http_response_code(204);
    exit;
}

// ---------------------------------------------------------------------------
// JSON error handling
// ---------------------------------------------------------------------------
$config = require __DIR__ . '/config.php';
$debug  = !empty($config['debug']);

set_exception_handler(static function (Throwable $e) use ($debug): void {
    error_log('[MazeShooter] ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
    http_response_code(500);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'ok'    => false,
        'error' => 'Internal server error',
    ] + ($debug ? ['detail' => $e->getMessage()] : []), JSON_UNESCAPED_SLASHES);
    exit;
});

// ---------------------------------------------------------------------------
// Composition root
// ---------------------------------------------------------------------------
use MazeShooter\Controller\HealthController;
use MazeShooter\Controller\LeaderboardController;
use MazeShooter\Controller\PlayerController;
use MazeShooter\Database\ConnectionFactory;
use MazeShooter\Http\Request;
use MazeShooter\Http\Router;
use MazeShooter\Repository\PdoPlayerRepository;
use MazeShooter\Repository\PdoScoreRepository;

// Must match the client-side defaults in public/game/js/core/Config.js.
const SETTING_DEFAULTS = [
    'lookSensitivity' => 1.0,
    'invertY'         => false,
    'soundOn'         => true,
    'showRadar'       => true,
];

$connection = ConnectionFactory::create($config);
$connection->migrate();          // idempotent: creates tables on first hit

$scores  = new PdoScoreRepository($connection);
$players = new PdoPlayerRepository($connection);

$health = new HealthController();
$board  = new LeaderboardController(
    $scores,
    (int) ($config['leaderboard']['default_limit'] ?? 10),
    (int) ($config['leaderboard']['max_limit'] ?? 50),
    $players // tag integrity: score submissions may only carry an owned tag
);
$player = new PlayerController($players, $scores, SETTING_DEFAULTS);

// ---------------------------------------------------------------------------
// Routes (relative to /api, see Http\Request normalization)
// ---------------------------------------------------------------------------
$router = new Router();
$router->get('/health', [$health, 'index']);
$router->get('/leaderboard', [$board, 'top']);
$router->post('/scores', [$board, 'submit']);
$router->get('/player/{id}', [$player, 'get']);
$router->put('/player/{id}', [$player, 'save']);

$response = $router->dispatch(new Request());
$response->send();
