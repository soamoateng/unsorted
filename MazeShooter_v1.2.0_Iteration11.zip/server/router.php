<?php
/**
 * MazeShooter · dev/preview router for PHP's built-in server.
 *
 *   php -S 0.0.0.0:3000 -t public server/router.php
 *
 * Mirrors the production Apache + cPanel layout:
 *   - Everything under public/ is served statically (docroot).
 *   - /api/* is dispatched to the PHP front controller (public/api/index.php),
 *     the same file Apache routes to via public/api/.htaccess.
 *
 * Only used for local development and preview, never uploaded to hosting.
 */

declare(strict_types=1);

$uri = urldecode((string) parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH));

// ---- API: hand over to the front controller --------------------------------
if ($uri === '/api' || str_starts_with($uri, '/api/')) {
    // Never expose internals (Apache blocks these via .htaccess in production).
    if (
        str_starts_with($uri, '/api/data/')
        || str_starts_with($uri, '/api/src/')
        || str_contains($uri, '/.')          // .htaccess, .gitignore, dotfiles
    ) {
        http_response_code(403);
        header('Content-Type: text/plain; charset=utf-8');
        exit('Forbidden');
    }

    require dirname(__DIR__) . '/public/api/index.php';
    return true;
}

// ---- Static: let the built-in server stream files from docroot -------------
// Returning false = "serve the requested URI as-is from the docroot".
// The docroot is public/, and public/index.html is picked up for "/".
return false;
