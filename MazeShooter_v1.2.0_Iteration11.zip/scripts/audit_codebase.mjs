/**
 * MazeShooter · scripts/audit_codebase.mjs
 *
 * Static audit across the whole codebase after multiple modifications:
 *   1. Syntax errors     : node --check on every browser JS file, php -l on PHP
 *   2. Cross-file deps   : ES import specifiers resolve; named exports exist
 *   3. UI wiring         : every #id queried from JS exists in some HTML page
 *   4. Asset references  : script/link/img sources resolve to real files
 *   5. API contract      : client fetch paths match the PHP route table
 *   6. DB sanity         : data dir present, config driver value sane
 *
 * Run: node scripts/audit_codebase.mjs   (exit 1 on any finding)
 */
import { execFileSync } from 'node:child_process';
import { readFileSync, readdirSync, statSync, existsSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const PUB = join(ROOT, 'public');
const problems = [];
const notes = [];

function walk(dir, exts, out = []) {
  for (const name of readdirSync(dir)) {
    if (name === 'vendor' || name === 'fontawesome' || name.startsWith('.')) continue;
    const p = join(dir, name);
    const st = statSync(p);
    if (st.isDirectory()) walk(p, exts, out);
    else if (exts.some((e) => name.endsWith(e))) out.push(p);
  }
  return out;
}

// ---------- 1a. JS syntax (node --check) ----------
const jsFiles = [
  ...walk(join(PUB, 'game', 'js'), ['.js']),
  ...walk(join(PUB, 'assets', 'js'), ['.js']),
];
for (const f of jsFiles) {
  try {
    execFileSync(process.execPath, ['--check', f], { stdio: 'pipe' });
  } catch (e) {
    problems.push(`SYNTAX JS: ${f}\n${e.stderr.toString().slice(0, 400)}`);
  }
}
console.log(`js syntax checked: ${jsFiles.length} files`);

// ---------- 1b. PHP syntax (php -l) ----------
const PHP_BIN = join(ROOT, 'runtime', 'php');
const phpFiles = [
  ...walk(join(PUB, 'api'), ['.php']),
  join(ROOT, 'server', 'router.php'),
];
let phpOk = 0;
if (existsSync(PHP_BIN)) {
  for (const f of phpFiles) {
    try {
      execFileSync(PHP_BIN, ['-l', f], { stdio: 'pipe' });
      phpOk++;
    } catch (e) {
      problems.push(`SYNTAX PHP: ${f}\n${e.stderr.toString().slice(0, 400)}`);
    }
  }
  console.log(`php lint checked: ${phpOk} files`);
} else {
  notes.push('PHP binary not found; php -l skipped');
}

// ---------- 2. ES imports resolve + named exports exist ----------
const exportCache = new Map();
function exportsOf(file) {
  if (exportCache.has(file)) return exportCache.get(file);
  const src = readFileSync(file, 'utf8');
  const names = new Set();
  const re = /export\s+(?:const|let|var|function|class|async\s+function)\s+([A-Za-z_$][\w$]*)/g;
  let m;
  while ((m = re.exec(src))) names.add(m[1]);
  const braceRe = /export\s*\{([^}]*)\}/g;
  while ((m = braceRe.exec(src))) {
    m[1].split(',').forEach((part) => {
      const seg = part.trim().split(/\s+as\s+/).pop().trim();
      if (seg) names.add(seg);
    });
  }
  if (/export\s+default/.test(src)) names.add('default');
  exportCache.set(file, names);
  return names;
}

let importCount = 0;
for (const f of jsFiles) {
  const src = readFileSync(f, 'utf8');
  const re = /import\s+(?:([\w$]+)\s*,?\s*)?(?:\{([^}]*)\})?\s*from\s*['"]([^'"]+)['"]/g;
  let m;
  while ((m = re.exec(src))) {
    importCount++;
    const spec = m[3];
    if (!spec.startsWith('.')) continue; // bare specifier (none expected)
    const target = resolve(dirname(f), spec);
    if (!existsSync(target)) {
      problems.push(`IMPORT MISSING: ${f} -> ${spec}`);
      continue;
    }
    const available = exportsOf(target);
    const wanted = [];
    if (m[1]) wanted.push(m[1]);
    if (m[2]) {
      m[2].split(',').forEach((part) => {
        const seg = part.trim().split(/\s+as\s+/)[0].trim();
        if (seg) wanted.push(seg);
      });
    }
    for (const w of wanted) {
      if (!available.has(w)) problems.push(`EXPORT MISSING: ${f} imports { ${w} } from ${spec}`);
    }
  }
}
console.log(`import specifiers checked: ${importCount}`);

// ---------- 3. ID wiring: JS queries vs HTML ids ----------
const htmlIds = new Set();
for (const page of ['index.html', 'game/game.html']) {
  const src = readFileSync(join(PUB, page), 'utf8');
  const re = /\bid="([^"]+)"/g;
  let m;
  while ((m = re.exec(src))) htmlIds.add(m[1]);
}
let idQueries = 0;
for (const f of jsFiles) {
  const src = readFileSync(f, 'utf8');
  const re = /(?:getElementById\(\s*['"]#?([\w-]+)['"]\s*\)|querySelector\(\s*['"]#([\w-]+)['"]\s*\))/g;
  let m;
  while ((m = re.exec(src))) {
    idQueries++;
    const id = m[1] || m[2];
    if (!htmlIds.has(id)) problems.push(`ID NOT FOUND: ${f} references #${id}`);
  }
}
console.log(`id queries checked: ${idQueries} (pool: ${htmlIds.size} ids)`);

// ---------- 4. HTML asset references ----------
for (const page of ['index.html', 'game/game.html']) {
  const base = dirname(join(PUB, page));
  const src = readFileSync(join(PUB, page), 'utf8');
  const re = /(?:src|href)="([^"#]+)"/g;
  let m;
  while ((m = re.exec(src))) {
    const ref = m[1];
    if (/^(https?:|mailto:|data:)/.test(ref)) continue;
    if (ref.startsWith('//')) continue;
    const target = resolve(base, ref);
    if (!existsSync(target)) problems.push(`ASSET MISSING: ${page} -> ${ref}`);
  }
}
console.log('html asset references checked');

// ---------- 4b. Dead-file guard: every browser JS file must be reachable ----------
// A JS file that no HTML page loads, no other module imports and no test
// harness requires is dead weight that will drift out of sync (this is how
// the duplicate loft implementation slipped back onto disk once).
const referenced = new Set([
  join(PUB, 'game', 'maze.js'), // imported by scripts/test_maze.mjs (Node maze-math harness)
]);
const htmlPages = ['index.html', 'game/game.html'];
for (const page of htmlPages) {
  const base = dirname(join(PUB, page));
  const src = readFileSync(join(PUB, page), 'utf8');
  const re = /(?:src|href)="([^"#]+)"/g;
  let m;
  while ((m = re.exec(src))) {
    const ref = m[1];
    if (/^(https?:|mailto:|data:)/.test(ref)) continue;
    referenced.add(resolve(base, ref));
  }
}
for (const f of jsFiles) {
  const src = readFileSync(f, 'utf8');
  const re = /(?:from\s*|require\()\s*['"]([^'"]+)['"]/g;
  let m;
  while ((m = re.exec(src))) {
    const spec = m[1];
    if (!spec.startsWith('.')) continue;
    referenced.add(resolve(dirname(f), spec));
  }
}
const deadFiles = jsFiles.filter((f) => !referenced.has(f));
for (const f of deadFiles) problems.push(`UNREFERENCED JS: ${f.replace(PUB + '/', '')} (no HTML, import or harness reference)`);
console.log(`dead-file guard: ${jsFiles.length} browser JS files, ${deadFiles.length} unreferenced`);

// ---------- 5. API contract: client paths vs routes ----------
const routes = new Set(['/health', '/leaderboard', '/scores', '/player/{id}']);
const apiUses = [];
const clientFiles = [
  join(PUB, 'game', 'js', 'services', 'ApiClient.js'),
  join(PUB, 'game', 'js', 'services', 'SettingsService.js'),
  join(PUB, 'game', 'js', 'services', 'LeaderboardService.js'),
  join(PUB, 'game', 'js', 'ui', 'LoftView.js'),
];
for (const f of clientFiles) {
  const src = readFileSync(f, 'utf8');
  const re = /(?:get|send)\(\s*['"`]([^'"`]+)['"`]/g;
  let m;
  while ((m = re.exec(src))) apiUses.push([f.replace(PUB + '/', ''), m[1]]);
}
console.log('client api call sites:');
for (const [f, p] of apiUses) console.log(`  ${f}: ${p}`);

// ---------- 6. DB sanity ----------
const dbFile = join(PUB, 'api', 'data', 'mazeshooter.sqlite');
if (!existsSync(dbFile)) notes.push('sqlite file absent (created on first API call, fine)');
const cfg = readFileSync(join(PUB, 'api', 'config.php'), 'utf8');
if (!/driver/.test(cfg)) problems.push('CONFIG: driver key missing');

// ---------- report ----------
console.log('\n=== AUDIT REPORT ===');
if (notes.length) console.log('notes:');
notes.forEach((n) => console.log('  - ' + n));
if (problems.length) {
  console.log(`PROBLEMS: ${problems.length}`);
  problems.forEach((p) => console.log('  * ' + p));
  process.exit(1);
} else {
  console.log('no problems found');
}
