/**
 * MazeShooter · scripts/gen_blueprint.mjs
 *
 * Regenerates the landing-page maze blueprint from the REAL generator
 * (single source of truth: the SVG always matches what players face).
 * Patches public/index.html in place: fills the #maze-path `d` attribute.
 *
 * Run: node scripts/gen_blueprint.mjs
 */
import { readFileSync, writeFileSync } from 'node:fs';
import { generateMaze } from '../public/game/js/world/MazeGenerator.js';
import { Maze } from '../public/game/js/world/Maze.js';

const INDEX = new URL('../public/index.html', import.meta.url);
const html = readFileSync(INDEX, 'utf8');

const maze = new Maze(generateMaze(21, 21, 14), 250);
const parts = [];
for (let i = 0; i < maze.w; i++) {
  for (let j = 0; j < maze.h; j++) {
    if (maze.grid[i][j] > 0) parts.push(`M${i * 10} ${j * 10}h10v10h-10z`);
  }
}

// Replace whatever path data the #maze-path element currently carries, so
// the script is idempotent and can regenerate the blueprint on any run.
const re = /(id="maze-path" d=")[^"]*(")/;
if (!re.test(html)) {
  console.error('No #maze-path element found; the markup changed.');
  process.exit(1);
}
const next = html.replace(re, `$1${parts.join('')}$2`);
if (next === html) {
  console.log('Blueprint already matches the generated maze; nothing to do.');
  process.exit(0);
}
writeFileSync(INDEX, next);
console.log('Landing blueprint regenerated (' + parts.length + ' wall cells).');
