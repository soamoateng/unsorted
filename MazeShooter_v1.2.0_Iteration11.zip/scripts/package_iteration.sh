#!/usr/bin/env bash
# MazeShooter · scripts/package_iteration.sh
#
# Stages the shippable tree (public/ + docs/ + server/ + scripts + dev tooling)
# and zips it as download/MazeShooter_v<version>_Iteration<iteration>.zip.
# Runtime databases (*.sqlite, *.db) never travel; the server creates a
# fresh one on first hit.
#
# Usage: bash scripts/package_iteration.sh
set -e
cd "$(dirname "$0")/.."

VERSION=$(node -p "require('./package.json').version")
ITERATION=$(node -p "require('./package.json').iteration")
NAME="MazeShooter_v${VERSION}_Iteration${ITERATION}"
STAGE=".package-stage"
OUT="download/${NAME}.zip"

echo "packaging ${NAME} ..."

rm -rf "$STAGE" "download/${NAME}.zip"
mkdir -p "$STAGE"

# Shippable trees.
cp -r public "$STAGE/public"
cp -r docs "$STAGE/docs"
cp -r server "$STAGE/server"
mkdir -p "$STAGE/scripts" "$STAGE/.zscripts"
cp scripts/*.mjs scripts/*.sh scripts/*.php "$STAGE/scripts/" 2>/dev/null || true
cp .zscripts/dev.sh "$STAGE/.zscripts/"
cp package.json "$STAGE/"

# Never ship runtime data.
find "$STAGE" -type f \( -name '*.sqlite' -o -name '*.sqlite-*' -o -name '*.db' \) -delete

mkdir -p download
(cd "$STAGE" && zip -qr "../$OUT" .)

FILES=$(unzip -l "$OUT" | tail -1 | awk '{print $2}')
SIZE=$(du -h "$OUT" | cut -f1)
echo "done: $OUT ($FILES files, $SIZE)"
