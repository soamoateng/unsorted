/**
 * MazeShooter · scripts/test_maze.mjs
 *
 * Validates the procedural maze generator (the pure world/MazeGenerator.js
 * module) against the invariants the game depends on:
 *
 *   1. Border cells are always solid
 *   2. Every open cell is reachable from the spawn (full connectivity)
 *   3. The farthest cell exists and sits at a plausible depth
 *   4. Spawn picking returns N distinct open cells at min distance
 *
 * Run: node scripts/test_maze.mjs
 */
import { generateMaze } from '../public/game/js/world/MazeGenerator.js';
import { Maze } from '../public/game/js/world/Maze.js';

let failures = 0;
function check(cond, label) {
  if (!cond) {
    failures++;
    console.error('  FAIL:', label);
  }
}

const RUNS = 200;
for (let run = 0; run < RUNS; run++) {
  const maze = new Maze(generateMaze(21, 21, 14), 250);
  const spawn = { x: 1, z: 1 };

  // 1. Borders solid.
  let borderOk = true;
  for (let i = 0; i < maze.w; i++) {
    if (maze.isOpen(i, 0) || maze.isOpen(i, maze.h - 1)) borderOk = false;
  }
  for (let j = 0; j < maze.h; j++) {
    if (maze.isOpen(0, j) || maze.isOpen(maze.w - 1, j)) borderOk = false;
  }
  check(borderOk, `run ${run}: borders must be solid`);

  // 2. Full connectivity + reasonable open ratio.
  const dist = maze.bfsDistances(spawn.x, spawn.z);
  let open = 0, reachable = 0;
  for (let i = 0; i < maze.w; i++) {
    for (let j = 0; j < maze.h; j++) {
      if (maze.isOpen(i, j)) { open++; if (dist[i][j] >= 0) reachable++; }
    }
  }
  check(open === reachable, `run ${run}: all ${open} open cells reachable (got ${reachable})`);
  check(open >= 150 && open <= 320, `run ${run}: open ratio sane (${open})`);

  // 3. Exit placement depth.
  const exit = maze.farthestCell(spawn.x, spawn.z);
  check(exit.dist >= 20, `run ${run}: farthest cell deep enough (${exit.dist})`);

  // 4. Spawn picking: 8 distinct open cells, min BFS distance 8.
  const picks = maze.pickOpenCells(spawn.x, spawn.z, 8, 8);
  check(picks.length === 8, `run ${run}: picked 8 spawn cells (got ${picks.length})`);
  const uniq = new Set(picks.map((c) => c.x + ',' + c.z));
  check(uniq.size === 8, `run ${run}: spawn cells distinct`);
  check(picks.every((c) => maze.isOpen(c.x, c.z) && dist[c.x][c.z] >= 8),
    `run ${run}: spawn cells open & far enough`);
  // Path matrix shape (PF.Grid contract: rows = z, cols = x).
  const pm = maze.pathMatrix();
  check(pm.length === maze.h && pm[0].length === maze.w,
    `run ${run}: pathMatrix is [z][x]`);
}

if (failures) {
  console.error(`\n${failures} failure(s) across ${RUNS} mazes`);
  process.exit(1);
}
console.log(`OK · ${RUNS} mazes passed all invariants`);

// Bonus: emit the blueprint SVG path used by the landing page.
const maze = new Maze(generateMaze(21, 21, 14), 250);
const parts = [];
for (let i = 0; i < maze.w; i++) {
  for (let j = 0; j < maze.h; j++) {
    if (maze.grid[i][j] > 0) parts.push(`M${i * 10} ${j * 10}h10v10h-10z`);
  }
}
console.log('BLUEPRINT_PATH=' + parts.join(''));
