<?php
/**
 * MazeShooter · scripts/clean_test_data.php
 *
 * Removes API test leftovers so smoke tests never pollute the real
 * leaderboard: deletes the scores and player rows for the player ids
 * passed as arguments, plus any legacy rows named Alice or Bob.
 *
 * Usage:
 *   php scripts/clean_test_data.php [dbPath] [playerId1] [playerId2] ...
 * Defaults: dbPath=public/api/data/mazeshooter.sqlite (relative to the
 * repository root), no ids = only the legacy Alice/Bob rows are removed.
 */

$path = isset($argv[1]) ? $argv[1] : 'public/api/data/mazeshooter.sqlite';
$ids  = array_slice($argv, 2);

if (!file_exists($path)) {
    echo "clean: no database at $path, nothing to do\n";
    exit(0);
}

$db = new PDO('sqlite:' . $path);
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// The tag-uniqueness index is an expression index on ms_lower(name), so
// EVERY connection that writes to the players table must register the
// same function the API registers (SqliteConnection::boot). Raw sqlite3
// CLI writes to players hit the same requirement.
$fold = static function ($s) {
    return mb_strtolower((string) $s, 'UTF-8');
};
if (class_exists('\Pdo\Sqlite') && $db instanceof \Pdo\Sqlite) {
    $db->createFunction('ms_lower', $fold, 1, \Pdo\Sqlite::DETERMINISTIC);
} else {
    $db->sqliteCreateFunction('ms_lower', $fold, 1, \Pdo\Sqlite::DETERMINISTIC);
}

$deletedScores = 0;
$deletedPlayers = 0;

// Legacy named test rows (fixed tag names used by the smoke tests; a run
// interrupted before its cleanup leaves these behind and would collide
// with the next run otherwise).
$legacyNames = ['Alice', 'Bob', 'TagMaster', 'Ärger'];
$in = implode(',', array_fill(0, count($legacyNames), '?'));
$stmt = $db->prepare("DELETE FROM scores WHERE name IN ($in)");
$stmt->execute($legacyNames);
$deletedScores += $stmt->rowCount();
$stmt = $db->prepare("DELETE FROM players WHERE name IN ($in)");
$stmt->execute($legacyNames);
$deletedPlayers += $stmt->rowCount();

// This run's random test ids.
if ($ids) {
    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $stmt = $db->prepare("DELETE FROM scores WHERE player_id IN ($placeholders)");
    $stmt->execute($ids);
    $deletedScores += $stmt->rowCount();
    $stmt = $db->prepare("DELETE FROM players WHERE player_id IN ($placeholders)");
    $stmt->execute($ids);
    $deletedPlayers += $stmt->rowCount();
}

echo "clean: removed $deletedScores test score(s) and $deletedPlayers test player(s)\n";
