#!/usr/bin/env bash
# MazeShooter · scripts/test_api.sh
#
# Round-trip smoke tests for the PHP API (run against a live server).
#   BASE=http://localhost:3000 bash scripts/test_api.sh
set -e
BASE="${BASE:-http://localhost:3000}"
PASS=0; FAIL=0

check() { # check <label> <actual> <expected-substring>
  if echo "$2" | grep -q "$3"; then PASS=$((PASS+1)); echo "ok   - $1";
  else FAIL=$((FAIL+1)); echo "FAIL - $1"; echo "       got: $(echo "$2" | head -c 200)"; fi
}

check_not() { # check_not <label> <actual> <forbidden-substring>
  if echo "$2" | grep -q "$3"; then FAIL=$((FAIL+1)); echo "FAIL - $1"; echo "       got: $(echo "$2" | head -c 200)";
  else PASS=$((PASS+1)); echo "ok   - $1"; fi
}

echo "== pre-run cleanup (remove leftovers from any interrupted run) =="
if command -v php > /dev/null 2>&1; then
  php scripts/clean_test_data.php "${DB:-public/api/data/mazeshooter.sqlite}"
elif [ -x runtime/php ]; then
  ./runtime/php scripts/clean_test_data.php "${DB:-public/api/data/mazeshooter.sqlite}"
fi

echo "== health =="
R=$(curl -s "$BASE/api/health")
check "health ok" "$R" '"ok":true'

echo "== leaderboard reachable =="
R=$(curl -s "$BASE/api/leaderboard?limit=5")
check "list ok" "$R" '"ok":true'

UID1="aaaaaaaa$RANDOM"
UID2="bbbbbbbb$RANDOM"

echo "== submit valid scores (cross-field rule compliant) =="
# Score invariants mirrored server-side: won runs clear the opening squad
# (8+ kills), score sits in [kills*100, kills*100 + 2500].
# Alice: kills 100 -> 10000 + time bonus 1550 (45s) + health 475 (95x5) = 12025
R=$(curl -s -X POST "$BASE/api/scores" -H 'Content-Type: application/json' \
  -d "{\"playerId\":\"$UID1\",\"name\":\"Alice\",\"score\":12025,\"kills\":100,\"timeMs\":45000,\"shotsFired\":200,\"shotsHit\":150,\"healthLeft\":95,\"won\":true}")
check "alice saved + rank 1" "$R" '"rank":1'
# Bob: kills 8 -> 800 + time bonus 1400 (60s) + health 400 (80x5) = 2600
R=$(curl -s -X POST "$BASE/api/scores" -H 'Content-Type: application/json' \
  -d "{\"playerId\":\"$UID2\",\"name\":\"Bob\",\"score\":2600,\"kills\":8,\"timeMs\":60000,\"shotsFired\":40,\"shotsHit\":20,\"healthLeft\":80,\"won\":true}")
check "bob saved" "$R" '"name":"Bob"'
check_not "bob not rank 1" "$R" '"rank":1'

echo "== leaderboard ordering =="
R=$(curl -s "$BASE/api/leaderboard?limit=2")
check "alice first" "$R" '"scores":\[{"id":[0-9]*,"name":"Alice"'
check "limit honored" "$R" '"count":2'

echo "== full board (all runs) =="
R=$(curl -s "$BASE/api/leaderboard?all=1")
check "all ok" "$R" '"ok":true'
check "all returns rows" "$R" '"name":"Alice"'
check "accuracy present" "$R" '"accuracy":'

# Keep a handle for the end-of-run cleanup so the real leaderboard never
# carries smoke test rows.
TEST_UIDS="$UID1 $UID2"

echo "== player settings =="
R=$(curl -s -X PUT "$BASE/api/player/$UID1" -H 'Content-Type: application/json' \
  -d '{"name":"Alice","settings":{"lookSensitivity":1.6,"soundOn":false}}')
check "settings saved" "$R" '"lookSensitivity":1.6'
check "defaults merged" "$R" '"showRadar":true'
R=$(curl -s "$BASE/api/player/$UID1")
check "player stats present" "$R" '"bestScore":12025'
R=$(curl -s -X PUT "$BASE/api/player/$UID1" -H 'Content-Type: application/json' \
  -d '{"name":"Alice","settings":{"evilKey":1,"lookSensitivity":99}}')
check "unknown key clamped" "$R" '"lookSensitivity":3'
check_not "evil key dropped" "$R" 'evilKey'
R=$(curl -s -X PUT "$BASE/api/player/$UID1" -H 'Content-Type: application/json' -d '{"name":""}')
check "empty name keeps stored name" "$R" '"name":"Alice"'

UID3="cccccccc$RANDOM"
TEST_UIDS="$TEST_UIDS $UID3"

echo "== gamer tag rules (unique, 3+ chars) =="
R=$(curl -s -X PUT "$BASE/api/player/$UID3" -H 'Content-Type: application/json' -d '{"name":"AB"}')
check "2-char tag rejected" "$R" '"ok":false'
R=$(curl -s -o /dev/null -w '%{http_code}' -X PUT "$BASE/api/player/$UID3" -H 'Content-Type: application/json' -d '{"name":"AB"}')
check "2-char tag is 422" "$R" "422"
R=$(curl -s -X PUT "$BASE/api/player/$UID3" -H 'Content-Type: application/json' -d '{"name":"TagMaster"}')
check "valid tag saved" "$R" '"name":"TagMaster"'
R=$(curl -s -o /dev/null -w '%{http_code}' -X PUT "$BASE/api/player/$UID1" -H 'Content-Type: application/json' -d '{"name":"tagmaster"}')
check "duplicate tag (case-insensitive) is 409" "$R" "409"
R=$(curl -s -X PUT "$BASE/api/player/$UID1" -H 'Content-Type: application/json' -d '{"name":"tagmaster"}')
check "duplicate tag message" "$R" 'already taken'
R=$(curl -s -X PUT "$BASE/api/player/$UID1" -H 'Content-Type: application/json' -d '{"name":"Alice"}')
check "own tag re-save allowed" "$R" '"name":"Alice"'
R=$(curl -s -X PUT "$BASE/api/player/$UID2" -H 'Content-Type: application/json' -d '{"name":"Alice"}')
check "other player blocked from taken tag" "$R" '"ok":false'

UID4="dddddddd$RANDOM"
TEST_UIDS="$TEST_UIDS $UID4"

echo "== invisible-unicode tag hygiene (M-4) =="
# A zero-width space inside a taken tag must strip to the same tag -> 409
# (U+200B = e2 80 8b), not a lookalike tag that evades uniqueness.
ZW_TAG=$'TagM\xe2\x80\x8baster'
R=$(curl -s -o /dev/null -w '%{http_code}' -X PUT "$BASE/api/player/$UID1" -H 'Content-Type: application/json' -d "{\"name\":\"${ZW_TAG}\"}")
check "zero-width lookalike of taken tag is 409" "$R" "409"
# Bidi override (U+202E = e2 80 ae) must strip the same way.
BIDI_TAG=$'\xe2\x80\xaeTagMaster'
R=$(curl -s -o /dev/null -w '%{http_code}' -X PUT "$BASE/api/player/$UID1" -H 'Content-Type: application/json' -d "{\"name\":\"${BIDI_TAG}\"}")
check "bidi-override lookalike of taken tag is 409" "$R" "409"

echo "== unicode-aware case folding (M-5) =="
R=$(curl -s -X PUT "$BASE/api/player/$UID2" -H 'Content-Type: application/json' -d '{"name":"Ärger"}')
check "non-ascii tag saved" "$R" '"name":"Ärger"'
R=$(curl -s -o /dev/null -w '%{http_code}' -X PUT "$BASE/api/player/$UID4" -H 'Content-Type: application/json' -d '{"name":"ärger"}')
check "non-ascii case pair is 409 (unicode fold)" "$R" "409"

echo "== cross-field score validation (M-6) =="
SC="{\"playerId\":\"$UID1\",\"name\":\"Alice\""
R=$(curl -s -o /dev/null -w '%{http_code}' -X POST "$BASE/api/scores" -H 'Content-Type: application/json' \
  -d "$SC,\"score\":100,\"kills\":8,\"timeMs\":10000,\"shotsFired\":20,\"shotsHit\":25,\"healthLeft\":80,\"won\":false}")
check "shotsHit > shotsFired is 422" "$R" "422"
R=$(curl -s -X POST "$BASE/api/scores" -H 'Content-Type: application/json' \
  -d "$SC,\"score\":100,\"kills\":8,\"timeMs\":10000,\"shotsFired\":20,\"shotsHit\":25,\"healthLeft\":80,\"won\":false}")
check "cross-field rejection message" "$R" 'shotsHit'
R=$(curl -s -o /dev/null -w '%{http_code}' -X POST "$BASE/api/scores" -H 'Content-Type: application/json' \
  -d "$SC,\"score\":800,\"kills\":2,\"timeMs\":10000,\"shotsFired\":20,\"shotsHit\":10,\"healthLeft\":80,\"won\":true}")
check "won with < 8 kills is 422" "$R" "422"
R=$(curl -s -o /dev/null -w '%{http_code}' -X POST "$BASE/api/scores" -H 'Content-Type: application/json' \
  -d "$SC,\"score\":800,\"kills\":8,\"timeMs\":0,\"shotsFired\":20,\"shotsHit\":10,\"healthLeft\":80,\"won\":true}")
check "won with zero time is 422" "$R" "422"
R=$(curl -s -o /dev/null -w '%{http_code}' -X POST "$BASE/api/scores" -H 'Content-Type: application/json' \
  -d "$SC,\"score\":9999,\"kills\":8,\"timeMs\":10000,\"shotsFired\":20,\"shotsHit\":10,\"healthLeft\":80,\"won\":false}")
check "score inconsistent with kills is 422" "$R" "422"

echo "== score-tag integrity =="
# A submission carrying a tag owned by ANOTHER player degrades to Anonymous.
R=$(curl -s -X POST "$BASE/api/scores" -H 'Content-Type: application/json' \
  -d "{\"playerId\":\"$UID2\",\"name\":\"TagMaster\",\"score\":800,\"kills\":8,\"timeMs\":10000,\"shotsFired\":20,\"shotsHit\":10,\"healthLeft\":80,\"won\":false}")
check "impostor tag degraded to Anonymous" "$R" '"entry":{[^}]*"name":"Anonymous"'
# Own tag still rides along.
R=$(curl -s -X POST "$BASE/api/scores" -H 'Content-Type: application/json' \
  -d "{\"playerId\":\"$UID1\",\"name\":\"Alice\",\"score\":800,\"kills\":8,\"timeMs\":10000,\"shotsFired\":20,\"shotsHit\":10,\"healthLeft\":80,\"won\":false}")
check "own tag kept on submission" "$R" '"entry":{[^}]*"name":"Alice"'
# Submission response still carries a (bounded) board for the end screen.
check "submission board present" "$R" '"leaderboard":'

echo "== loft data (career stats + recent runs) =="
R=$(curl -s "$BASE/api/player/$UID1")
check "longest run present" "$R" '"longestRunMs":45000'
check "avg run present" "$R" '"avgRunMs":'
check "accuracy pct present" "$R" '"accuracyPct":'
check "last played present" "$R" '"lastPlayedAt":'
check "recent runs present" "$R" '"recent":'
check "recent has own run" "$R" '"name":"Alice"'
R=$(curl -s "$BASE/api/player/$UID3")
check "empty recent for new player" "$R" '"recent":\[\]'

echo "== validation =="
R=$(curl -s -X POST "$BASE/api/scores" -H 'Content-Type: application/json' -d '{"playerId":"bad id!","score":1}')
check "bad playerId rejected" "$R" '"ok":false'
R=$(curl -s -X POST "$BASE/api/scores" -H 'Content-Type: application/json' -d '{}')
check "missing fields rejected" "$R" '"ok":false'
R=$(curl -s "$BASE/api/player/short")
check "bad player id in path rejected" "$R" '"ok":false'
R=$(curl -s -o /dev/null -w '%{http_code}' "$BASE/api/nowhere")
check "404 for unknown route" "$R" "404"

echo "== security =="
C1=$(curl -s -o /dev/null -w '%{http_code}' "$BASE/api/data/mazeshooter.sqlite")
check "sqlite file blocked" "$C1" "403"
C2=$(curl -s -o /dev/null -w '%{http_code}' "$BASE/api/src/Http/Router.php")
check "src blocked" "$C2" "403"
C3=$(curl -s -o /dev/null -w '%{http_code}' "$BASE/api/.htaccess")
check "htaccess blocked" "$C3" "403"

echo
if [ "${SKIP_CLEANUP:-0}" != "1" ]; then
  echo "== cleanup (remove test rows) =="
  DB="${DB:-public/api/data/mazeshooter.sqlite}"
  if command -v php > /dev/null 2>&1; then
    php scripts/clean_test_data.php "$DB" $TEST_UIDS
  elif [ -x runtime/php ]; then
    runtime/php scripts/clean_test_data.php "$DB" $TEST_UIDS
  else
    echo "skip: no php binary found, run scripts/clean_test_data.php manually"
  fi
fi

echo
echo "passed: $PASS, failed: $FAIL"
[ "$FAIL" -eq 0 ]
