#!/usr/bin/env bash
# MazeShooter · scripts/verify_package.sh
#
# Extracts the freshly built zip and re-checks everything that must be
# true of a shippable package: syntax of every JS/PHP file, version
# metadata, no runtime databases, and the iteration's key markers.
#
# Usage: bash scripts/verify_package.sh [path/to/zip]
set -e
cd "$(dirname "$0")/.."

ZIP="${1:-download/MazeShooter_v$(node -p "require('./package.json').version")_Iteration$(node -p "require('./package.json').iteration").zip}"
STAGE=".verify-stage"
PHP=./runtime/php

FAIL=0
ok()   { echo "ok   - $1"; }
bad()  { echo "FAIL - $1"; FAIL=1; }

rm -rf "$STAGE" && mkdir -p "$STAGE"
unzip -q "$ZIP" -d "$STAGE"

# 1. Every browser JS file parses.
JS_COUNT=0
while IFS= read -r f; do
  node --check "$f" 2>/dev/null || bad "JS syntax: $f"
  JS_COUNT=$((JS_COUNT+1))
done < <(find "$STAGE/public" -name '*.js' -not -path '*/vendor/*' -not -path '*/fontawesome/*')
ok "node --check clean on $JS_COUNT project JS files"

# 2. Every PHP file lints.
PHP_COUNT=0
while IFS= read -r f; do
  "$PHP" -l "$f" >/dev/null 2>&1 || bad "PHP lint: $f"
  PHP_COUNT=$((PHP_COUNT+1))
done < <(find "$STAGE" -name '*.php')
ok "php -l clean on $PHP_COUNT PHP files"

# 3. Version metadata (the staged copy must match the project root).
ROOT_ITERATION=$(node -p "require('./package.json').iteration")
grep -q "\"iteration\": $ROOT_ITERATION" "$STAGE/package.json" && ok "package.json iteration $ROOT_ITERATION" || bad "iteration metadata"
grep -q '"version": "1.2.0"' "$STAGE/package.json" && ok "package.json version 1.2.0" || bad "version metadata"

# 4. No runtime databases ship.
if find "$STAGE" -type f \( -name '*.sqlite' -o -name '*.db' \) | grep -q .; then
  bad "runtime database found in zip"
else
  ok "no sqlite/db files in zip"
fi

# 5. Iteration 8 markers.
grep -q 'MIN_LENGTH: 3' "$STAGE/public/game/js/services/GamerTag.js" \
  && ok "GamerTag rules present" || bad "GamerTag service missing"
grep -q 'nameOwner' "$STAGE/public/api/src/Repository/PdoPlayerRepository.php" \
  && ok "tag ownership lookup present" || bad "nameOwner missing"
grep -q 'already taken' "$STAGE/public/api/src/Controller/PlayerController.php" \
  && ok "409 tag conflict message present" || bad "409 message missing"
grep -q 'recentForPlayer' "$STAGE/public/api/src/Repository/PdoScoreRepository.php" \
  && ok "recent runs endpoint present" || bad "recentForPlayer missing"
grep -q 'loft-tab' "$STAGE/public/game/game.html" \
  && ok "loft tab menu present in game screen" || bad "loft tabs missing"
grep -q 'panel-time' "$STAGE/public/game/game.html" \
  && ok "play time panel present" || bad "play time panel missing"
grep -q 'panel-recent' "$STAGE/public/game/game.html" \
  && ok "recent runs panel present" || bad "recent runs panel missing"
if grep -q 'loft-tab' "$STAGE/public/index.html"; then
  bad "loft still on the landing page"
else
  ok "loft removed from the landing page"
fi
grep -q '#btn-pause i { font-size: 14px' "$STAGE/public/game/css/game.css" \
  && ok "larger pause icon present" || bad "pause icon size unchanged"
grep -q 'Health Percentage' "$STAGE/public/game/game.html" \
  && ok "Health Percentage label intact" || bad "Health Percentage missing"
grep -q 'GamerTag.validate' "$STAGE/public/game/js/bootstrap.js" \
  && ok "modal + intro validation wired" || bad "bootstrap validation missing"
grep -q 'GamerTag.validate' "$STAGE/public/game/js/ui/LoftView.js" \
  && ok "loft form validation wired" || bad "loft validation missing"
grep -q 'RETURN TO GAMER LOFT' "$STAGE/public/game/game.html" \
  && ok "game over returns to the loft" || bad "game over loft button missing"
grep -q 'restart-dead\|restart-win' "$STAGE/public/game/game.html" \
  && bad "old NEW MAZE buttons still present" || ok "old restart buttons replaced"
if [ -f "$STAGE/public/assets/js/loft.js" ] || [ -f "$STAGE/public/assets/js/leaderboard.js" ]; then
  bad "dead landing loft scripts still shipped"
else
  ok "dead landing loft scripts removed"
fi
DEAD_COUNT=0
for dead in game/Three.js game/Pathfinder.js game/jquery-1.7.2.min.js game/main.js game/sfx.js; do
  [ -f "$STAGE/public/$dead" ] && { bad "dead file still shipped: $dead"; DEAD_COUNT=$((DEAD_COUNT+1)); }
done
[ "$DEAD_COUNT" -eq 0 ] && ok "no dead game-root scripts shipped"
grep -q 'assertCrossField' "$STAGE/public/api/src/Controller/LeaderboardController.php" \
  && ok "cross-field score validation present" || bad "cross-field validation missing"
grep -q 'isUniqueViolation' "$STAGE/public/api/src/Controller/PlayerController.php" \
  && ok "unique-constraint 409 backstop present" || bad "constraint backstop missing"
grep -q 'ms_lower' "$STAGE/public/api/src/Database/SqliteConnection.php" \
  && ok "unicode-aware tag folding present" || bad "ms_lower folding missing"
grep -q 'name_ci' "$STAGE/public/api/src/Database/MysqlConnection.php" \
  && ok "mysql generated name_ci column present" || bad "mysql name_ci missing"
grep -q "display_errors" "$STAGE/public/api/index.php" \
  && ok "api output hardening present" || bad "api display_errors hardening missing"
grep -q 'INVISIBLE' "$STAGE/public/game/js/services/GamerTag.js" \
  && ok "invisible-unicode tag hygiene present" || bad "tag hygiene missing"
grep -q 'MAX_ENEMIES' "$STAGE/public/game/js/core/Config.js" \
  && ok "enemy ceiling present" || bad "enemy ceiling missing"
grep -q 'tagModalSkippedKey' "$STAGE/public/game/js/core/Config.js" \
  && ok "tag-modal skip memory present" || bad "skip memory missing"
grep -q 'merge(partial)' "$STAGE/public/game/js/services/SettingsService.js" \
  && ok "settings local merge present" || bad "settings merge missing"
grep -q '_saveName' "$STAGE/public/game/js/Game.js" \
  && bad "old _saveName bypass still present" || ok "tag save path unified"

# 6. Banned strings never ship.
if grep -rn '£' "$STAGE/public" --include='*.html' --include='*.css' --include='*.js' >/dev/null 2>&1; then
  bad "£ symbol found"
else
  ok "no £ symbols"
fi

# 7. Docs travel with the zip.
for d in HOSTING_GUIDE.md QA_REPORT.md ARCHITECTURE.md; do
  [ -f "$STAGE/docs/$d" ] && ok "docs/$d present" || bad "docs/$d missing"
done

rm -rf "$STAGE"
echo
if [ "$FAIL" -eq 0 ]; then echo "PACKAGE VERIFY: all good ($ZIP)"; else echo "PACKAGE VERIFY: failures above"; exit 1; fi
