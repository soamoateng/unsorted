#!/usr/bin/env bash
#
# MazeShooter dev server (replaces the previous Next.js dev flow).
#
# The whole game is now a static vanilla-JS site (public/) plus a PHP backend
# (public/api/), which is exactly the layout that gets uploaded to cPanel
# shared hosting. The PHP built-in server serves both, so the preview
# environment mirrors production 1:1.
#
# Boot flow: start.sh runs this file instead of `bun run dev` whenever it
# exists. It is idempotent and self-healing (re-downloads the static PHP
# binary if it is missing).
#
set -e
cd "$(dirname "$0")/.."   # project root

PHP=./runtime/php

# --- Ensure the static PHP CLI binary exists ------------------------------
if [ ! -x "$PHP" ]; then
  echo "[dev.sh] PHP binary missing, downloading static build..."
  mkdir -p runtime
  curl -sL --max-time 180 -o runtime/php.tar.gz \
    "https://dl.static-php.dev/static-php-cli/common/php-8.4.8-cli-linux-x86_64.tar.gz"
  tar -xzf runtime/php.tar.gz -C runtime
  rm -f runtime/php.tar.gz
  # The tarball is either a flat `php` binary or a php/bin/php layout.
  if [ -f runtime/php.bin ]; then mv runtime/php.bin runtime/php; fi
  if [ -f runtime/php/bin/php ]; then mv runtime/php/bin/php runtime/php; rm -rf runtime/php/bin runtime/php.ini* 2>/dev/null || true; fi
  chmod +x "$PHP"
fi

chmod +x "$PHP" 2>/dev/null || true

# --- SQLite data directory (git-ignored, runtime-created) --------------------
mkdir -p public/api/data

echo "[dev.sh] MazeShooter · PHP ${PHP##*/} built-in server on 0.0.0.0:3000"
exec "$PHP" -S 0.0.0.0:3000 -t public server/router.php
