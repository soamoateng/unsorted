# MazeShooter v1.2.0 Architecture

v2 migrated MazeShooter from **Next.js + Three.js** to **vanilla JS +
Three.js + PHP/SQLite**, added **mobile-first touch controls** and refactored
the whole codebase around **DRY, SOLID and KISS**. The player **loft** (a
gravity-driven jump that can dodge incoming shots) and **vendored Font
Awesome** icons came next, iteration 4 rebuilt the landing page around
the **Gamer Loft** profile hub with player-facing copy that skips the
technical details, iteration 5 hardened the codebase after a full
static and runtime audit (see docs/QA_REPORT.md) and added the step-by-step
hosting guide (docs/HOSTING_GUIDE.md), iteration 6 put real portraits
of the people behind the product on the landing page, iteration 7
brought hunter waves (8 more hunters every 30 seconds while the exit is
locked), a gamer tag modal before the first run, an exit compass that
points the way out once the portal opens, a full leaderboard with
gamer tag, kills, time survived, accuracy and score columns, and the
Health Percentage HUD row with an inline pause button, and iteration 8
made gamer tags unique and at least 3 characters long (enforced on
every tag surface, with the API answering 409 for taken tags), gave
the pause icon a slightly larger size on the same Health Percentage
row, and turned the Gamer Loft into a multi-menu console with
leaderboard, profile, career stats, play time and recent runs panels
backed by an extended player endpoint, and iteration 9 moved the Gamer
Loft out of the landing page into the game screen itself (an overlay
with the same five menus, opened from the intro bar, the death screen
and the win screen, whose NEW MAZE buttons became RETURN TO GAMER
LOFT, with a NEW MAZE action inside the loft). There is no build step,
no framework and no runtime dependency: the browser loads ES modules,
the server is plain PHP.

```
public/                         ← upload this folder to cPanel
├── index.html                  ← landing: hero, how to play, FAQ, credits modal
├── assets/                     ← landing CSS/JS + vendored Font Awesome
└── game/
    ├── game.html               ← game shell (static HUD DOM, overlays, touch UI)
    ├── css/game.css            ← mobile-first styles + media queries
    ├── images/                 ← Nemesis boilerplate textures (GPL-3.0 lineage)
    ├── vendor/                 ← Three.js r128 (UMD), Pathfinder.js (A*)
    └── js/
        ├── bootstrap.js        ← entry: assembles the object graph once
        ├── Game.js             ← composition root: wiring + run lifecycle
        ├── core/               ← EventBus, Config, GameLoop, GameStateMachine, Sfx
        ├── world/              ← MazeGenerator (pure), Maze, TextureLib, SceneFactory
        ├── entities/           ← Entity base + Player, Enemy, Bullet, HealthPack, ExitPortal
        ├── physics/            ← CollisionWorld (sliding wall collision)
        ├── input/              ← InputSystem + KeyboardMouse / Touch controllers
        ├── systems/            ← Combat, EnemyAI (+PathfinderAdapter), Pickup
        ├── ui/                 ← HudView, RadarView, Screens
        └── services/           ← ApiClient, Leaderboard, Settings, Identity, ScoreCalculator
└── api/                        ← PHP backend (also under public/, .htaccess-guarded)
    ├── index.php               ← front controller + composition root
    ├── config.php              ← driver: sqlite | mysql
    └── src/                    ← Http (Request/Response/Router),
                                  Database (Interface/Abstract/Sqlite/Mysql/Factory),
                                  Repository (interfaces + PDO impls),
                                  Controller (Health/Leaderboard/Player),
                                  Support (Validator, ValidationError)
```

## How the principles map

**Single Responsibility.** Every class/module does exactly one thing:
`MazeGenerator` only carves grids; `Maze` only answers grid queries;
`CollisionWorld` only decides "can I stand/move here"; `CombatSystem` only
manages bullets and hit resolution; `HudView`/`RadarView`/`Screens` only
render; `ApiClient` only speaks HTTP; repositories only persist.

**Open-Closed.** New behavior means new code, not edits: storage drivers
register in `ConnectionFactory` (SQLite and MySQL today, PostgreSQL
tomorrow); settings keys are whitelisted in one array; the score formula
lives in one pure module.

**Liskov Substitution.** `Entity` subclasses are interchangeable through
the base contract; `SqliteConnection`/`MysqlConnection` are interchangeable
behind `ConnectionInterface`; the AI would accept any pathfinder that
honors the `PathfinderAdapter` shape.

**Interface Segregation.** Clients see small role interfaces:
`Controller` (attach/detach/update/enabled) for input, and the repository
interfaces expose exactly the leaderboard/player operations, nothing more.

**Dependency Inversion.** High-level policy (systems, controllers) never
touches low-level details (PDO, fetch, the DOM). Everything arrives through
constructors; `Game.js` and `api/index.php` are the only places that know
how to build concrete objects.

**DRY.** One `Config.js` for all tunables, one `ScoreCalculator` for all
score math, one `Maze` for all grid queries (radar, AI, spawns and
collision share it), CSS custom properties + shared components on both
pages, and the landing-page blueprint is generated by the *actual* game
generator (`scripts/gen_blueprint.mjs`).

**KISS.** No framework, no bundler, no ORM, no auth framework. ~30 small
files whose behavior you can read top-to-bottom in an afternoon.

## Mobile-first & input

- `game.css` is written phone-first: compact HUD, 44px+ touch targets,
  `env(safe-area-inset-*)` for notches, `min-width` media queries scale up
  to tablet/desktop, and a rotate hint appears on portrait phones.
- `TouchController` (Pointer Events): left thumb-stick moves, right-side
  drag looks, FIRE shoots, and the amber JUMP button lofts the player.
  It implements the same tiny controller role as the desktop keyboard/mouse
  controller, so `InputSystem` merges both, and hybrid devices (touch
  laptops) work automatically.
- Player loft: Space (desktop) or the JUMP button (touch) lifts the eye
  with `JUMP_SPEED` against `GRAVITY` until it lands back on `EYE_HEIGHT`
  (all in `Config.js`, integrated in `Player.updateVertical`). The apex
  stays under the wall tops, so the maze never opens up, and the rise is
  big enough to clear the bullet hit gate, which makes a well-timed hop a
  real dodge with its own jump/land sounds.
- Pointer lock stays desktop-only; on touch devices it is skipped, and a
  hover-look fallback still exists for locked-down desktop browsers.
- Icons: Font Awesome Free is vendored under `assets/fontawesome/`
  (no CDN call), and all UI glyph symbols (pause, check, cross, rotate,
  arrows) are icon fonts rather than text characters.

## Online features (not offline-first)

- Identity: a UUID in `localStorage` keeps a player's leaderboard history
  across visits; the display name travels with every score.
- Gamer Loft: an in-game overlay (ui/LoftView.js), now a multi-menu
  console. The menu
  panels are Leaderboard, Profile (gamer tag form, member since, runs
  recorded), Career stats, Play time and Recent runs, all fed by the
  same `GET /api/player/{id}` response (stats + recent in one round
  trip). The tag form validates through the shared `GamerTag` rules
  (unique, 3+ characters) and surfaces the server's 409 for taken tags.
  It reuses `PlayerIdentity` and `ApiClient`, so the loft and the game
  always share one identity. Entry points: the Gamer Loft button in the
  intro bottom bar, and RETURN TO GAMER LOFT on the death and win
  screens; closing it reveals the intro again (after a run it takes the
  same clean reload the old NEW MAZE button used).
- Settings (sensitivity, invert-Y, sound, radar) live server-side in the
  `players.settings` JSON column, so they follow the player to any device.
  When the API is unreachable the game still runs with last-known/default
  values and the UI says so (graceful degradation, not offline mode).
- Scores: `POST /api/scores` validates every field AND the cross-field
  invariants (shotsHit ≤ shotsFired, a won run cleared the 8-hunter opening
  squad with positive survival time, score consistent with kills), degrades
  a submitter who does not own their posted tag to Anonymous, stores, ranks
  and returns the top of the board for the end screen; the in-game loft
  reads `GET /api/leaderboard` (full history via `?all=1`).

## API surface

| Method | Path | Purpose |
|---|---|---|
| GET  | `/api/health` | liveness + driver name |
| GET  | `/api/leaderboard?limit=&offset=` | top scores (`?all=1` full history) |
| POST | `/api/scores` | submit a finished run → rank + board top 50; cross-field 422 on inconsistent stats |
| GET  | `/api/player/{id}` | name, settings, career stats, recent runs |
| PUT  | `/api/player/{id}` | upsert name and/or settings; 422 for tags under 3 characters, 409 when another player owns the tag (backed by a case-folding UNIQUE index, Unicode-aware on SQLite via `ms_lower`) |

## Local development

```bash
bash .zscripts/dev.sh          # PHP built-in server on :3000 (mirrors cPanel)
node scripts/test_maze.mjs     # maze invariants (200 mazes)
bash scripts/test_api.sh       # API round-trips against the running server
node scripts/gen_blueprint.mjs # regenerate the landing blueprint SVG
```
