# MazeShooter Hosting and Testing Guide

This guide walks you through running MazeShooter on your own machine with
XAMPP and deploying it to a live shared hosting server with cPanel support.
The whole game is plain files: static HTML, CSS and JavaScript in the front,
and a small PHP backend for the leaderboard, gamer tags and settings. There
is no Node.js, no build step and no Composer, so what you see locally is
exactly what runs in production.

Two storage drivers are supported and chosen with one line in `api/config.php`:

- **SQLite** (default): zero setup, the database is a single file created
  automatically at `api/data/mazeshooter.sqlite` on the first API call.
- **MySQL**: the familiar option on shared hosting, provisioned from cPanel
  (or phpMyAdmin on XAMPP).

Both XAMPP and cPanel sections below cover each driver, a full testing
checklist and the errors you are most likely to meet on the way.

---

## Part 1 · Local hosting and testing with XAMPP

### 1.1 Install XAMPP

1. Download XAMPP from `https://www.apachefriends.org` for your operating
   system (any recent build with PHP 7.4 or newer works; 8.1 to 8.4 is
   ideal) and run the installer with the default components. Apache and
   phpMyAdmin are the only required modules; MySQL is optional and only
   needed if you plan to test the MySQL driver locally.
2. Open the XAMPP Control Panel.
3. Click **Start** next to Apache. If you plan to use MySQL, click **Start**
   next to MySQL as well.
4. Confirm the modules turned green. Apache serves files from its document
   root, called `htdocs`:
   - Windows: `C:\xampp\htdocs`
   - macOS: `/Applications/XAMPP/htdocs`
   - Linux: `/opt/lampp/htdocs`

### 1.2 Check the PHP requirements

MazeShooter needs PHP 7.4+ with `pdo_sqlite` (enabled by default in XAMPP).
To confirm, create a quick probe file or use the command line:

```bash
# Windows (cmd)
C:\xampp\php\php.exe -m | findstr pdo

# macOS / Linux
/Applications/XAMPP/xamppfiles/bin/php -m | grep -i pdo
```

You want to see `pdo`, `pdo_sqlite` (and `pdo_mysql` if you will test
MySQL), plus `json` and `mbstring`. All of them ship with XAMPP. If
`pdo_sqlite` is ever missing, open `php.ini` (XAMPP Control Panel, Apache,
Config, `php.ini`) and remove the semicolon in front of
`extension=pdo_sqlite`, then restart Apache.

### 1.3 Put the game in place (two options)

**Option A, subfolder (recommended, matches how you will upload later).**
Copy the contents of the `public/` folder into a new folder inside
`htdocs`:

```
C:\xampp\htdocs\mazeshooter\
├── index.html
├── assets\
├── game\
└── api\
    ├── .htaccess
    ├── index.php
    ├── config.php
    ├── src\
    └── data\          (auto-created on first API call if missing)
```

**Option B, domain root.** Copy the contents of `public/` directly into
`htdocs`, so `index.html` sits at `C:\xampp\htdocs\index.html`. Everything
also works this way because every link and API call in the codebase is
relative to its own file.

> Tip for Linux/macOS: if Apache cannot write to `api/data/`, give the
> folder to the web user (`sudo chown -R daemon:daemon api/data` on XAMPP
> for macOS, `www-data` on most Linux stacks) or `chmod 775 api/data`.

### 1.4 Make sure Apache honors the API routing

The `api/.htaccess` file routes every non-file request under `api/` to the
PHP front controller, exactly like production. Two Apache settings must be
active (they are by default in XAMPP, so this is a check, not a chore):

1. **mod_rewrite enabled.** Open `httpd.conf` from the XAMPP Control Panel
   (Apache, Config, `httpd.conf`) and confirm this line is not commented
   out; remove the leading `#` and restart Apache if it is:
   ```apache
   LoadModule rewrite_module modules/mod_rewrite.so
   ```
2. **AllowOverride enabled for htdocs.** In the same file, the `<Directory`
   block for your htdocs path must contain:
   ```apache
   AllowOverride All
   ```
   Without it, Apache silently ignores `.htaccess` files and `/api/*`
   routes return 404.

### 1.5 Run the game locally

Open these URLs in your browser:

| What | URL | Expect |
|---|---|---|
| Landing page | `http://localhost/mazeshooter/` | Hero, How to play, FAQ cards |
| Game | `http://localhost/mazeshooter/game/game.html` | Intro overlay with gamer tag and settings, Gamer Loft button in the bottom bar |
| API health | `http://localhost/mazeshooter/api/health` | `{"ok":true,"service":"mazeshooter-api",...}` |
| Leaderboard | `http://localhost/mazeshooter/api/leaderboard` | `{"ok":true,"scores":[...]}` |
| Credits modal | Footer link on either page | The open source attribution pop-up |

If you installed at the domain root instead, drop the `/mazeshooter`
segment (`http://localhost/api/health`, and so on).

### 1.6 Test with SQLite (default)

Nothing to configure. Play one full run: finish a run (or die trying) and
the death or win screen should show **Score saved** with a world rank
within a second. Then:

1. Reload the landing page. The **Top runners** card lists the run.
2. In the **Your gamer tag** card, type a tag and press **Save tag**. The
   confirmation line appears and the game intro pre-fills the same tag.
3. Change a setting in the game intro (drag Sensitivity, tick Invert Y),
   reload the page, and confirm the control kept its value. Settings are
   stored server-side, so this proves the database round-trip works.
4. The database file now exists at `api/data/mazeshooter.sqlite`. Try to
   open `http://localhost/mazeshooter/api/data/mazeshooter.sqlite` in the
   browser: it must be refused (403), never downloaded.
5. Maintenance note: the tag-uniqueness index is an expression index on a
   custom `ms_lower()` function (Unicode-aware case folding). Every
   connection that WRITES to the `players` table must register it — the
   API and `scripts/clean_test_data.php` already do. Read-only inspection
   with the `sqlite3` CLI or a DB tool is unaffected; if a raw tool ever
   refuses a write to `players` with `unknown function: ms_lower()`, do
   that write through the API instead.

### 1.7 Test with MySQL (optional)

1. In the XAMPP Control Panel, start MySQL, then open
   `http://localhost/phpmyadmin`.
2. Create a database named `mazeshooter` with collation `utf8mb4_general_ci`
   (or `utf8mb4_unicode_ci`). You do not need to create tables; the API
   creates them on the first request.
3. Use the **root** user with an empty password locally, or create a
   dedicated user in phpMyAdmin with all privileges on `mazeshooter`.
4. Edit `api/config.php`:
   ```php
   'driver' => 'mysql',
   'mysql' => [
       'host'     => 'localhost',
       'port'     => '3306',
       'database' => 'mazeshooter',
       'user'     => 'root',
       'password' => '',
       'charset'  => 'utf8mb4',
   ],
   ```
5. Restart nothing; just reload the health URL. Tables appear in phpMyAdmin
   after the first API call. Repeat the SQLite test checklist from 1.6.
6. Only if you are reusing a database created by an OLDER MazeShooter
   version (before the `name_ci` column existed), run this once in
   phpMyAdmin so the tag-uniqueness constraint applies:
   ```sql
   ALTER TABLE players
     ADD COLUMN name_ci VARCHAR(32) GENERATED ALWAYS AS (LOWER(name)) STORED,
     ADD UNIQUE KEY idx_players_name_ci (name_ci);
   ```
   Fresh databases get the column automatically.

To switch back, set `'driver' => 'sqlite'` again.

### 1.8 Automated tests on your machine

The repository ships two test scripts (they need a running local server):

```bash
# From the project root (the folder that contains public/, scripts/, docs/).
# On Windows use Git Bash or WSL for the bash script.

# 1. Maze generator invariants (200 mazes), no server needed.
node scripts/test_maze.mjs

# 2. API round-trips against the running Apache server.
BASE=http://localhost/mazeshooter bash scripts/test_api.sh
```

`test_api.sh` prints `passed: 49, failed: 0` on a healthy install. It
checks ordering, validation errors, cross-field score rules, tag hygiene,
settings merging and the security blocks. The script cleans up after
itself (and clears leftovers from any previously interrupted run at
startup), so no test rows named Alice, Bob, TagMaster or Ärger remain
afterwards. To reset anyway, delete `api/data/mazeshooter.sqlite` (or
truncate the tables in phpMyAdmin).

### 1.9 XAMPP troubleshooting

| Symptom | Likely cause and fix |
|---|---|
| Landing loads, but `/api/...` returns 404 | `.htaccess` ignored: check `AllowOverride All` in `httpd.conf` and that `mod_rewrite` is loaded, then restart Apache. |
| API returns 500 with "could not find driver" | `pdo_sqlite` (or `pdo_mysql`) missing: edit `php.ini`, remove the `;` before the extension line, restart Apache. |
| API returns 500 immediately after install | The `api/data/` folder is not writable by Apache (mostly Linux/macOS). Fix ownership or `chmod 775`. |
| Browser offers the `.sqlite` file for download or shows PHP source | `.htaccess` files are not being honored (same as the 404 case). Never ignore this: the data file must be unreachable. |
| Apache does not start, port 80 busy | Another program (Skype, VMware, IIS) owns port 80. Change the listening port in `httpd.conf` (`Listen 8080`) and use `http://localhost:8080/...`, or stop the other program. |
| Leaderboard works, but scores never appear | Check the browser console (F12) for a failed request URL; the API base is derived automatically, so a wrong URL usually means the game was copied incompletely (the `api/` folder must sit next to `game/`). |
| PHP errors are silent | Enable display errors while testing: in `php.ini` set `display_errors = On`, restart Apache. The API also logs to Apache's `error.log` (XAMPP Control Panel, Apache, Logs). |

---

## Part 2 · Live deployment to shared hosting with cPanel

### 2.1 What to upload

Upload everything **inside `public/`** and nothing else. The `docs/`,
`scripts/`, `server/`, `runtime/` and `.zscripts/` folders are development
aids and must not go to the web server. The resulting layout in your web
root (`public_html/`) is:

```
public_html/
├── index.html            ← landing page
├── assets/               ← landing CSS/JS + vendored Font Awesome
├── game/                 ← the game shell, ES modules, vendor libs, textures
└── api/
    ├── .htaccess         ← routing + hardening rules (must be uploaded!)
    ├── index.php         ← front controller
    ├── config.php        ← storage driver selection
    ├── src/              ← PHP classes (autoloaded, never served directly)
    └── data/             ← SQLite file appears here, write-protected
```

> Hidden files matter. `.htaccess` files start with a dot, and some FTP
> clients hide them. After uploading, confirm in cPanel File Manager
> (Settings, Show Hidden Files) that `api/.htaccess`, `api/data/.htaccess`
> and `api/src/.htaccess` are present. Without them the API routes and the
> database protection will not work.

### 2.2 Upload with cPanel File Manager

1. Zip the **contents** of `public/` (select `index.html`, `assets/`,
   `game/`, `api/` and zip those, so the archive has no extra top folder).
2. In cPanel, open **File Manager** and enter `public_html/` (or the folder
   of the subdomain or add-on domain you want to use).
3. Click **Upload**, drop the zip in, then back in File Manager right-click
   the archive and choose **Extract**.
4. Delete the archive after extraction.

**Subfolder installs work with zero changes.** Extracting into
`public_html/mazeshooter/` gives you `https://yourdomain/mazeshooter/` and
everything (links, leaderboard widget, API calls) resolves correctly
because all paths are relative. This also applies to addon and subdomains.

### 2.3 Choose the PHP version and extensions

1. In cPanel open **MultiPHP Manager** (or **Select PHP Version** on older
   builds) and set your domain to PHP **8.1, 8.2 or 8.3** (7.4+ works too).
2. In **Select PHP Version**, open the **Extensions** tab and confirm
   `pdo_sqlite` is ticked (it almost always is). Tick `pdo_mysql` and
   `mbstring` if you plan to use MySQL.
3. If your host uses **PHP-FPM**, no extra settings are needed.

### 2.4 Go live with SQLite (default)

1. Do nothing in `config.php`; the driver already reads `'sqlite'`.
2. The first API call creates `api/data/mazeshooter.sqlite`. If the health
   check below returns HTTP 500, the web server user cannot write to the
   folder: in File Manager select `api/data` (and `api` if needed), click
   **Permissions**, set **775**, and apply to subdirectories if asked.
3. Visit `https://yourdomain/api/health`. You should see the JSON liveness
   response. The database file now exists and is protected by `.htaccess`.

### 2.5 Go live with MySQL (the cPanel way)

1. In cPanel open **MySQL Database Wizard**:
   - Step 1: create a database, e.g. `cpuser_mazeshooter` (cPanel prefixes
     your account name).
   - Step 2: create a user, e.g. `cpuser_mz`, with a strong password.
   - Step 3: grant the user **ALL PRIVILEGES** on the database.
2. Edit `api/config.php` (File Manager, right-click, **Edit**):
   ```php
   'driver' => 'mysql',
   'mysql' => [
       'host'     => 'localhost',
       'port'     => '3306',
       'database' => 'cpuser_mazeshooter',
       'user'     => 'cpuser_mz',
       'password' => 'your-strong-password',
       'charset'  => 'utf8mb4',
   ],
   ```
   Many hosts also let you set environment variables (Setup Node.js App,
   custom `php.ini` directives, or `.htaccess` `SetEnv`), in which case you
   can keep credentials out of the file by setting `MAZESHOOTER_DB_DRIVER`,
   `MAZESHOOTER_DB_NAME`, `MAZESHOOTER_DB_USER`, `MAZESHOOTER_DB_PASS` and
   friends.
3. Save. Tables are created automatically on the first request
   (`CREATE TABLE IF NOT EXISTS`), so there is nothing to import. Only if
   you are reusing a database from an older MazeShooter version, add the
   `name_ci` column once with the ALTER statement from section 1.7.

### 2.6 Post-deployment verification checklist

Work through this list top to bottom; it takes about five minutes:

| # | Check | How | Pass condition |
|---|---|---|---|
| 1 | Landing page loads | Visit `https://yourdomain/` | Hero, How to play and FAQ cards render, no missing styles |
| 2 | Game boots | Visit `https://yourdomain/game/game.html` | Intro overlay shows, Start builds the maze, Gamer Loft button sits in the bottom bar |
| 3 | API health | Visit `/api/health` | `{"ok":true,...}` |
| 4 | Leaderboard API | Visit `/api/leaderboard` | `{"ok":true,"scores":[...]}` (empty list is fine) |
| 5 | Score round-trip | Play one run to death or escape | End screen shows "Score saved" and a world rank within a second |
| 6 | Gamer Loft | On the end screen tap RETURN TO GAMER LOFT (or the bottom-bar button on the intro) | The five menus open with the fresh run on the leaderboard |
| 8 | Settings persistence | Change Sensitivity, reload the game | The slider kept its value |
| 9 | Database protection | Visit `/api/data/mazeshooter.sqlite` | 403 Forbidden, never a download |
| 10 | Source protection | Visit `/api/src/Http/Router.php` | 403 Forbidden (or blank, never the source) |
| 11 | HTTPS | Visit `https://yourdomain` with the padlock | No mixed-content warnings |

For check 5, the quickest path is dying on purpose: stand still and let the
hunters do their job, the submission flow is identical for deaths and wins.

### 2.7 Hardening and good practice on shared hosting

- **HTTPS is one click.** In cPanel open **SSL/TLS Status** and run
  **AutoSSL** (or Let's Encrypt) for your domain, so scores travel over
  HTTPS. The game works on both, but browsers increasingly flag plain HTTP.
- **Tighten CORS if you host everything on one domain.** The API sends
  `Access-Control-Allow-Origin: *` so it also works from other origins. If
  you never serve the game from another domain, change that header in
  `api/index.php` to your own origin.
- **Keep the .htaccess guards.** They block direct access to the database
  file and the PHP source. If your host ever disables `mod_rewrite`, ask
  them to enable it; the dedicated `data/` and `src/` `.htaccess` files
  keep protecting those folders even then.
- **Backups.** With SQLite, the whole database is one file: download
  `api/data/mazeshooter.sqlite` occasionally (cPanel jetBackup or File
  Manager). With MySQL, use cPanel's **Backup** or **phpMyAdmin Export**.
- **Watch the SQLite write concurrency.** SQLite in WAL mode with a 5s busy
  timeout comfortably serves a game leaderboard. If your community grows
  into hundreds of concurrent submissions, switch `'driver' => 'mysql'`.
- **Uploading a new version later.** Upload and extract the new zip into the
  same folder and overwrite. The database file lives under `api/data/` and
  the new package does not contain a database, so scores survive updates.

### 2.8 cPanel troubleshooting

| Symptom | Likely cause and fix |
|---|---|
| `api/health` returns 500 right after upload | `api/data/` not writable: set permissions 775 as in 2.4. Also confirm the PHP version is 7.4+. |
| Landing fine, but `/api/*` gives 404 | `mod_rewrite` unavailable or `.htaccess` not uploaded (hidden files!). Re-upload `api/.htaccess`; if it still 404s, ask the host to enable mod_rewrite. |
| "could not find driver" in the response or logs | Enable `pdo_sqlite`/`pdo_mysql` in Select PHP Version, Extensions. |
| 403 on the whole site after upload | Folder permissions were set too strictly during upload: reset `public_html` to 755 and files to 644 (File Manager or `chmod -R` via SSH/terminal). |
| Scores saved but the tag shows as Anonymous | The tag is saved per browser identity. Saving a tag in the Gamer Loft (game screen) before finishing a run ensures the name travels with the score. |
| Leaderboard empty in the Gamer Loft but scores exist | Check for a mixed-content or path error in the browser console (F12). All calls are relative, so this points to an incomplete upload (missing `api/` next to `game/`). |
| Emails about "cron" or "resource usage" | Not from MazeShooter; the game uses no cron jobs. The only background activity is normal PHP request handling. |

---

## Part 3 · How the pieces talk (mental model)

```
Browser                          Web server (Apache / XAMPP)
────────                         ───────────────────────────
index.html  ── GET /  ────────►  public_html/index.html
assets/js/... ────────────────►  static files
game/game.html ───────────────►  public_html/game/game.html
game/js/... (ES modules) ─────►  static files
fetch('api/leaderboard') ─────►  api/.htaccess → api/index.php
  ...and every other API call →  api/src/** (autoloaded PHP)
                                 api/data/mazeshooter.sqlite (or MySQL)
```

- The game derives the API base from its own module location, and the PHP
  front controller derives its route paths from `SCRIPT_NAME`. That pair is
  why the same files work at a domain root, in a subfolder, under XAMPP and
  under cPanel without a single configuration change.
- The only files that must be executable PHP are `api/index.php` and
  `api/config.php`; everything else under `api/` is either include-only
  source (blocked from the web) or data (blocked from the web).
- When something misbehaves, the browser console (F12, Network tab) and the
  server error log (XAMPP Apache `error.log` / cPanel **Errors** and
  **Metrics, Errors**) together identify the failing hop in seconds.
