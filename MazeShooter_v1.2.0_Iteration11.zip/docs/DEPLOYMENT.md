# MazeShooter on cPanel and Shared Hosting

The whole game is plain files, so there is **no Node.js, no build step and
no Composer**. What you upload is what runs.

## 1. What to upload

Everything **inside `public/`** goes into your hosting web root
(`public_html/` on cPanel):

```
public_html/
├── index.html            ← landing page + Gamer Loft
├── assets/               ← landing CSS/JS
├── game/                 ← the game (HTML, ES modules, vendor libs, textures)
└── api/                  ← the PHP backend
    ├── .htaccess         ← routes /api/* to index.php, blocks internals
    ├── index.php         ← front controller
    ├── config.php        ← storage driver config
    ├── src/              ← PHP classes (autoloaded, never served directly)
    └── data/             ← SQLite file lives here (auto-created, write-protected)
```

Via cPanel File Manager: upload the ZIP and use *Extract* inside
`public_html`, or FTP/SFTP the contents of `public/`.

**Subfolders work too.** You do not have to install at the domain root:
dropping the files into `public_html/mazeshooter/` (or an add-on domain's
folder) is fine. Every page link, the leaderboard widget and the game's
API calls use paths relative to their own files, and the API controller
reads the real installation prefix from the server, so
`https://yourdomain/mazeshooter/` works with zero config edits. The full
step-by-step walkthroughs for XAMPP and cPanel live in
[HOSTING_GUIDE.md](HOSTING_GUIDE.md).

## 2. PHP requirements

Any PHP **7.4+** with `pdo_sqlite` works (that driver is enabled by default
on nearly every host), and `pdo_mysql`, `json` and `mbstring` are also used
if present. In cPanel open *Select PHP Version*, pick 8.1/8.2/8.3, and make
sure `pdo_sqlite` is checked.

## 3. Storage: SQLite (default) or MySQL

Edit `api/config.php`:

**SQLite (zero setup).** The database is a single file:

```php
'driver' => 'sqlite',
```

The file is created automatically at `api/data/mazeshooter.sqlite` on the
first API call. If the API returns HTTP 500 immediately, the web server
user cannot write there. In cPanel File Manager, set the permissions of the
`api/data` folder (and the `api` folder if needed) to 775.

**MySQL (your cPanel package supports it).** Create a database and a user
in cPanel under *MySQL Databases*, grant the user ALL privileges, then:

```php
'driver' => 'mysql',
'mysql' => [
    'host'     => 'localhost',
    'port'     => '3306',
    'database' => 'cpuser_mazeshooter',
    'user'     => 'cpuser_mz',
    'password' => '••••••••',
    'charset'  => 'utf8mb4',
],
```

Tables are created automatically on the first request (idempotent
`CREATE TABLE IF NOT EXISTS`). Values can also come from environment
variables (`MAZESHOOTER_DB_DRIVER`, `MAZESHOOTER_DB_*`) if you prefer not
to commit credentials.

## 4. Verify the deployment

| Check | URL | Expect |
|---|---|---|
| Landing | `https://yourdomain/` | Hero + Gamer Loft cards |
| Game | `https://yourdomain/game/game.html` | Intro overlay |
| API health | `https://yourdomain/api/health` | `{"ok":true,...}` |
| Leaderboard | `https://yourdomain/api/leaderboard` | `{"ok":true,...}` |

Play one run end-to-end: the death/win screen should show **“Score saved”
+ world rank** within a second of finishing, and the landing leaderboard
should update.

## 5. Notes & hardening

- The API sends permissive CORS headers; if you host everything on one
  domain you can tighten `Access-Control-Allow-Origin` in
  `api/index.php`.
- SQLite on shared hosting uses WAL mode plus a 5s busy timeout, which is
  fine for a game leaderboard. If you expect very heavy traffic, switch to
  MySQL.
- `api/data/` and `api/src/` are blocked by `.htaccess` (and again inside
  the front controller). Do not remove those rules.
- Backups: copy `api/data/mazeshooter.sqlite` (SQLite) or use cPanel's
  MySQL backups.
- The `.zscripts/`, `server/`, `runtime/`, `scripts/` and `docs/` folders
  are development-only, so you do not need to upload them.
