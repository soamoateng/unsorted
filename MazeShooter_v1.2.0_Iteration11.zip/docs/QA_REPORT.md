# MazeShooter v1.2.0 · Iteration 5 QA Report

A full audit of the codebase after the multiple modifications of iterations
2 to 4, covering syntax errors, warnings, runtime errors, type and reference
errors, business logic errors, UI errors, workflow errors, database errors,
cross-file dependency errors, security vulnerabilities and performance
concerns. Every finding below was fixed, and the fix was verified with the
automated suites plus a headless browser end-to-end pass.

## How the audit was run

- `node --check` on all 37 browser JavaScript files (syntax errors).
- `php -l` on all 20 PHP files (compile errors).
- `scripts/audit_codebase.mjs` (new tool, kept in `scripts/`): resolves every
  ES import specifier and named export, checks every `getElementById` /
  `querySelector('#...')` call against the ids present in the HTML pages,
  verifies every `src` / `href` reference in both HTML pages, and lists all
  client API call sites against the PHP route table.
- Manual review of the PHP request pipeline, SQL repositories, game systems
  and both pages for business logic, workflow, UI, database, security and
  performance issues.
- Runtime verification: `test_maze.mjs` (200 mazes), `test_api.sh` (20 API
  round-trips), headless Chromium on the landing page and in the game
  (movement, loft, low-health HUD, mute repeat guard, organic death, win
  flow, score submission, Gamer Loft, credits modal).

## Findings and fixes

### Cross-file dependency errors

1. **Absolute paths broke subfolder installs.** The landing page linked to
   `/game/game.html` in five places, the leaderboard widget fetched
   `/api/leaderboard`, the game's `ApiClient` defaulted to `/api` and the
   game shell's home link pointed at `/`. All of these only worked with the
   site at a domain root, breaking XAMPP's usual `htdocs/mazeshooter/`
   layout and cPanel subfolder or add-on domain installs. Fixed everywhere:
   page links are now relative (`game/game.html`, `../`), the leaderboard
   fetch is document-relative (`api/leaderboard`), and `ApiClient` derives
   the API base from its own module location (`../../../api/` relative to
   `import.meta.url`), so any install depth works with zero configuration.
2. **API path derivation off-by-one.** The first version of the new base
   derivation used two `../` segments instead of three and produced
   `/game/api`. Caught immediately by the browser end-to-end run (the Gamer
   Loft tag save failed), corrected to three levels, and re-verified.
3. **Two PHP classes in one file.** `Support/Validator.php` declared both
   `ValidationError` and `Validator`. The PSR-4 style autoloader can only
   map one class per file, so `ValidationError` was only resolvable by luck
   of load order. `ValidationError` now lives in its own file
   (`src/Support/ValidationError.php`).
4. **Blueprint generator could not re-run.** `scripts/gen_blueprint.mjs`
   only replaced an empty `d=""` placeholder, so running it twice exited
   with an error. It now replaces whatever path data `#maze-path` carries
   and is idempotent.

### Runtime and database errors

5. **First-request race on the players table.** Two parallel requests for a
   brand new player could both see the row missing and both INSERT; the
   loser hit a duplicate primary key error and the API returned HTTP 500
   ("Could not save player data"). `PdoPlayerRepository::upsert` now catches
   the duplicate-key `PDOException` and falls back to the UPDATE branch, so
   the race resolves cleanly on SQLite and MySQL alike.
6. **PHP request path normalization assumed a root install.** The front
   controller stripped a fixed `/api` prefix from the request URI.
   `Request` now strips the real installation prefix from `SCRIPT_NAME`
   when Apache rewrites to `index.php`, keeping the legacy behavior for the
   development server. Routes resolve at a domain root and inside any
   subfolder.

### Workflow and UI errors

7. **Held-key auto-repeat spammed discrete actions.** Holding M re-toggled
   mute for every key repeat (flickering audio and firing a settings PUT
   tens of times per second), and holding ESC re-toggled pause under the
   hover-look fallback. `KeyboardMouseController` now ignores `e.repeat`
   for discrete intents while movement keys keep working.
8. **Dead event: "Click again to capture the mouse" never displayed.** The
   pointer-lock error path emitted `ui:toast`, but nothing listened for it.
   `Game` now handles `ui:toast` and shows the message on the HUD.
9. **Health HUD written with `innerHTML` concatenation.** The value was
   always an internal number, but it was the only interpolated `innerHTML`
   in the codebase. `HudView` now builds the same DOM (including the `.low`
   span) with `createElement` and `textContent`, keeping the XSS-safe
   rendering guarantee by construction. Verified in the browser: the
   `.low` class renders below 25 HP and restores cleanly.

### Security and hardening

10. **Missing `api/src/.htaccess`.** The documentation and `test_api.sh`
    both expected `api/src/` to be blocked over HTTP, but only the
    `mod_rewrite` rule in `api/.htaccess` enforced it. Without mod_rewrite,
    class files under `api/src/` would execute as blank pages. A dedicated
    `api/src/.htaccess` now denies access with Apache 2.4 and 2.2 syntax.
11. **`api/data/.htaccess` modernized** with the same dual-syntax block so
    the SQLite file (and WAL/SHM sidecars) stay unreachable on older
    Apache builds too.

### Warnings and documentation

12. `Screens.js` documented an `onToggleMute` callback that does not exist;
    the JSDoc was corrected. `docs/ARCHITECTURE.md` and `docs/DEPLOYMENT.md`
    were updated to reflect the new files and the subfolder compatibility.

## Verification results after the fixes

| Check | Result |
|---|---|
| `node --check`, 37 JS files | clean |
| `php -l`, 20 PHP files | clean |
| `audit_codebase.mjs` (imports, exports, ids, assets, API contract) | no problems |
| `test_maze.mjs`, 200 mazes, 5 invariant groups | pass |
| `test_api.sh`, 20 round-trips incl. security blocks | 20 / 20 |
| Browser E2E, landing page | zero page errors; Gamer Loft tag save persists server-side; credits modal shows the exact attribution |
| Browser E2E, game | world boots with 8 hunters; movement and loft input verified; organic death at 16s produced "Score saved", world rank #3 and a rendered board; seam-driven win produced SCORE 2500 (2000 time bonus + 100 x 5 health), world rank #2 and a correctly sorted board |
| Key-repeat guard | synthetic `repeat: true` M press leaves sound state untouched |
| Blueprint generator | re-runs idempotently |
