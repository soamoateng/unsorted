/**
 * app.js — Composition root for morbi.shop
 *
 * Routes (clean-path, no hash — Phase 6 Batch 0):
 *   /                    -> Morbi's landing page
 *   /morcenzs            -> Morcenzs storefront
 *   /dashboard           -> Admin panel (shows a login panel until signed in)
 *   /payment-callback    -> Phase 2: Paystack redirect-back handler
 *                            (Paystack redirects here with ?reference=XYZ)
 *   /reset-password      -> Phase 3 Batch 3: password recovery token consumer
 *
 * PHASE-0 change: data hydrates from the PHP/MySQL API before the router
 * starts. MorbiStore.init() NEVER rejects — on API failure it falls back to
 * the localStorage mirror, so the site still renders last-known content
 * (read-only). `.then(start, start)` boots the router either way.
 *
 * PHASE-1 change: after init() resolves, applyTokens() injects a
 * `<style id="morbi-tokens">:root { --bg-deep: ...; ... }</style>` block
 * into <head>. The block is appended AFTER the existing theme.css <link>,
 * so DB-stored colors override the hardcoded :root fallback in theme.css.
 * If the API was unreachable, the cached mirror (or DEFAULT_TOKENS) is
 * applied instead — the public site always renders with the right palette.
 *
 * PHASE-2 change: a fourth route /payment-callback is registered. Paystack
 * redirects customers back to it after they complete (or abandon) the
 * payment on Paystack's hosted page. The route handler reads
 * params.query.reference and calls api/orders.php?action=verify to confirm.
 *
 * PHASE-3 Batch 3 change: a fifth route /reset-password is registered. The
 * admin clicks a reset link in the email (sent by api/forgot-password.php)
 * → lands here with params.query.token=<64hex> → MorbiResetPassword.render
 * shows the new-password form → calls store.resetPassword(token, password)
 * → on success redirects to /dashboard for re-login.
 *
 * PHASE-6 Batch 0 change: switched from hash-based routing (`/#/foo`) to
 * HTML5 history routing (`/foo`). Old bookmarks/links with `#/...` in the
 * hash are auto-redirected to the clean path by the router on first load
 * (one-time `history.replaceState` — same-origin, no server round-trip).
 * The .htaccess mod_rewrite SPA-fallback rule serves index.html for any
 * non-file/dir request, so deep links work on browser refresh + on shared
 * links. Backward-compat is preserved indefinitely so external links keep
 * working.
 */
(function (global) {
  'use strict';

  function start() {
    // PHASE-1: inject the DB-stored design tokens (or cached/default values
    // if the API was unreachable). Safe to call before the router starts
    // because the call is sync and only mutates <head>.
    if (global.MorbiStore && typeof global.MorbiStore.applyTokens === 'function') {
      global.MorbiStore.applyTokens();
    }
    var router = global.MorbiRouter;
    router.register('/', function () { global.MorbiLanding.render(); });
    router.register('/morcenzs', function () { global.MorbiStorefront.render(); });
    router.register('/dashboard', function () { global.MorbiDashboard.render(); });
    // ★ Phase 9 Batch 5 (Task 64): wishlist route. Renders the saved-items
    //   view (defined in storefront.js — reuses the product card renderer).
    router.register('/wishlist', function () { global.MorbiStorefront.renderWishlist(); });
    // PHASE-2: Paystack redirect-back handler. The router parses the
    // ?reference=XYZ query and passes it via params.query.
    router.register('/payment-callback', function (params) { global.MorbiPaymentCallback.render(params); });
    // PHASE-3 Batch 3: password recovery handler. The router parses
    // ?token=<64hex> from the reset email link.
    router.register('/reset-password', function (params) { global.MorbiResetPassword.render(params); });
    router.default(function () { global.MorbiLanding.render(); });

    // ★ Phase 5 Batch 3: hide the WhatsApp floating button on the dashboard
    // route (the admin doesn't need a customer chat button). The button
    // itself lives in index.html (outside #app-root) so it persists across
    // route changes — we just toggle its visibility here.
    //
    // ★ UX-14 fix: switched from a denylist ("hide on /dashboard") to an
    // ALLOWLIST ("show only on / and /morcenzs"). The denylist leaked two
    // admin/auth contexts where a customer-support chat button is actively
    // wrong:
    //   - /reset-password — a security-sensitive recovery page where a
    //     pulsing green chat button is noise at best.
    //   - /payment-callback — a payment-verification page where the button
    //     tempted anxious customers to tap away mid-verification and never
    //     see the result.
    // Unknown routes fall back to the landing page (router.default), and an
    // empty path boot shows the landing page too — both normalize to '/'
    // below, so first-load FAB behavior is unchanged.
    //
    // ★ Phase 6 Batch 0: the path detection switched from window.location.hash
    // to window.location.pathname. The popstate event replaces hashchange
    // (the new router uses history.pushState, so popstate is the right
    // event; hashchange no longer fires on internal navigation).
    var waFab = document.getElementById('whatsapp-fab');
    if (waFab) {
      // ★ Feature 4: update the WhatsApp FAB link's href from the store's
      //   settings (read from api/settings.php's whatsapp_number field at
      //   boot). The link's placeholder href in index.html stays as the
      //   fallback so the button works even before JS loads. The number is
      //   digits-only (country code + local number, no +).
      if (global.MorbiStore && typeof global.MorbiStore.getWhatsAppNumber === 'function') {
        var waNumber = global.MorbiStore.getWhatsAppNumber();
        if (waNumber) {
          // Preserve the prefilled text query (?text=...). The placeholder
          // href in index.html has it; we keep it so Morbi's greeting shows
          // up when the customer taps the FAB.
          // ★ Phase 10 (2026-09-26): URL-encoded the apostrophe as %27
          //   for RFC 3986 compliance (matches index.html's href).
          var defaultText = "Hi%20Morbi%2C%20I%27m%20interested%20in%20your%20perfumes.";
          waFab.href = 'https://wa.me/' + encodeURIComponent(waNumber) + '?text=' + defaultText;
        }
      }
      // Strip the query string (e.g. '/payment-callback?reference=XYZ')
      // so route matching is on the path portion only.
      function waRoutePath(p) {
        var q = p.indexOf('?');
        return q === -1 ? p : p.substring(0, q);
      }
      function updateWaFab() {
        var rawPath = window.location.pathname || '/';
        // ★ Phase 6 Batch 0 fix-up (Task 57): strip the base path before
        // comparing to known route paths. Without this, the FAB would
        // be hidden on the storefront in subdirectory deployments
        // (window.location.pathname = '/morbi-shop/morcenzs' would NOT
        // match the literal '/morcenzs' check). Falls back to no-op
        // strip if MorbiRouter isn't loaded yet (shouldn't happen given
        // script load order, but defensive).
        var stripped = (global.MorbiRouter && typeof global.MorbiRouter.stripBasePath === 'function')
          ? global.MorbiRouter.stripBasePath(rawPath)
          : rawPath;
        var path = waRoutePath(stripped);
        var show = (path === '/' || path === '/morcenzs');
        waFab.style.display = show ? '' : 'none';
      }
      // ★ Phase 6 Batch 0: hook into the router's 'morbi:route' custom
      // event (emitted on every dispatch — initial, navigate(), AND
      // popstate). This replaces the old 'hashchange' listener + the
      // interim 250ms polling workaround. Covers back/forward, internal
      // navigation, and initial page load in one listener.
      updateWaFab();
      window.addEventListener('popstate', updateWaFab);
      window.addEventListener('morbi:route', updateWaFab);
    }

    router.start();
  }

  function boot() {
    global.MorbiStore.init().then(start, start);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})(window);
