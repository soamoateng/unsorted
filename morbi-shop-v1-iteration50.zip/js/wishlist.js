/**
 * wishlist.js — ★ Phase 9 Batch 5 (Task 64, 2026-09-23) anonymous wishlist.
 *
 * IIFE module managing a localStorage-persisted wishlist. No DB table, no
 * API endpoint, no auth — purely client-side. The wishlist survives page
 * reloads + route changes within the same browser. It does NOT sync across
 * devices (a customer on their phone doesn't see their desktop wishlist) —
 * cross-device sync is a future enhancement that would require Customer
 * Accounts (Batch 9.4) + a server-side wishlist table.
 *
 * Storage shape: localStorage['morbi:wishlist-v1'] = JSON array of:
 *   [{ product_id: int, variant_id: int|null, added_at: ISO-string }, ...]
 *
 * Dedup key: (product_id, variant_id). Adding the same product+variant twice
 * is a no-op (idempotent). If the customer adds the same product with a
 * DIFFERENT variant, both entries are kept (e.g., "Oud Royale (50ml)" +
 * "Oud Royale (100ml)" can both be in the wishlist).
 *
 * Public API (MorbiWishlist):
 *   getWishlist()                     -> [{product_id, variant_id, added_at}, ...]
 *   isInWishlist(productId, variantId?) -> boolean
 *   addToWishlist(productId, variantId?) -> {added: true, new: bool}
 *   removeFromWishlist(productId, variantId?) -> {removed: bool}
 *   toggleWishlist(productId, variantId?) -> {inWishlist: bool, new: bool}
 *   clearWishlist()                   -> {cleared: int}
 *   getWishlistCount()                -> int
 *
 * On every mutation (add/remove/clear), dispatches a 'morbi:wishlist' event
 * on window so listeners (storefront header's count badge, the wishlist view)
 * can re-render without polling. Same pattern as 'morbi:currency' (Task 60)
 * and 'morbi:route' (Task 57).
 *
 * Backward compat: none needed — this is a new module. The localStorage key
 * is versioned ('morbi:wishlist-v1') so future schema changes can bump to v2
 * + migrate v1 → v2 on first load.
 */
(function (global) {
  'use strict';

  var STORAGE_KEY = 'morbi:wishlist-v1';
  var wishlist = [];

  // ── Init: load from localStorage on module load ──────────────────────────
  // Runs once when the script is parsed. If localStorage is unavailable
  // (private mode, file:// origin, disabled cookies), wishlist stays []
  // and all mutations are no-ops (fire-and-forget — the customer's wishlist
  // just doesn't persist).
  var storageAvailable = true;
  try {
    var raw = global.localStorage.getItem(STORAGE_KEY);
    if (raw) {
      var parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        wishlist = parsed.filter(function (item) {
          // ★ Phase 10 (2026-09-26): accept BOTH number AND string product_id.
          //   Was: `typeof item.product_id === 'number'` — older schema
          //   versions stored product_id as a string (from DOM data attributes),
          //   and the strict check filtered them out → the user's saved
          //   wishlist silently disappeared on first load after the schema
          //   change. Now: accept any non-null product_id + coerce to Number
          //   on read so downstream comparisons (===) work consistently.
          //   The filter rejects: null, undefined, NaN, empty string.
          if (!item || item.product_id === null || item.product_id === undefined) return false;
          var pid = Number(item.product_id);
          return !isNaN(pid) && pid > 0;
        }).map(function (item) {
          // Coerce to Number for consistent downstream comparison.
          var pid = Number(item.product_id);
          return {
            product_id: pid,
            variant_id: item.variant_id != null ? Number(item.variant_id) : null,
            added_at: typeof item.added_at === 'string' ? item.added_at : new Date().toISOString()
          };
        });
        // ★ Phase 10: if the migration changed the shape, persist the
        //   normalized version so the next load doesn't re-migrate.
        if (JSON.stringify(wishlist) !== raw) {
          persist();
        }
      }
    }
  } catch (e) {
    // JSON parse error, security error, or storage disabled. Start empty.
    wishlist = [];
    storageAvailable = false;
  }

  function persist() {
    if (!storageAvailable) return;
    try {
      global.localStorage.setItem(STORAGE_KEY, JSON.stringify(wishlist));
    } catch (e) {
      // Storage full or disabled — the in-memory wishlist still works for
      // the current session; it just won't persist across reloads.
      // ★ Phase 10 (2026-09-26): was a fully silent catch. Now logs a
      //   console.warn so the user has at least one diagnostic signal that
      //   their wishlist won't survive a refresh (otherwise they add items,
      //   navigate away, come back — wishlist is empty, no clue why).
      if (typeof console !== 'undefined' && console.warn) {
        console.warn('[morbi] Wishlist persistence failed — storage quota exceeded or disabled. Wishlist will not survive a page reload.', e && e.message ? e.message : e);
      }
      storageAvailable = false;
    }
  }

  function dispatchChangeEvent() {
    try {
      var ev = new global.CustomEvent('morbi:wishlist', {
        detail: { count: wishlist.length }
      });
      global.dispatchEvent(ev);
    } catch (e) {
      // Very old browsers without CustomEvent — listeners can fall back to
      // polling getWishlistCount(). Not worth polyfilling.
      // ★ Phase 10 (2026-09-26): was a fully silent catch. Now logs so a
      //   buggy dispatch (rare, but possible if global is shadowed) is at
      //   least visible in devtools.
      if (typeof console !== 'undefined' && console.warn) {
        console.warn('[morbi] Could not dispatch morbi:wishlist event.', e && e.message ? e.message : e);
      }
    }
  }

  // ── Helpers ───────────────────────────────────────────────────────────────

  function findIndex(productId, variantId) {
    var vid = variantId || null;
    for (var i = 0; i < wishlist.length; i++) {
      if (wishlist[i].product_id === productId && wishlist[i].variant_id === vid) {
        return i;
      }
    }
    return -1;
  }

  // ── Public API ────────────────────────────────────────────────────────────

  function getWishlist() {
    // Return a defensive copy so callers can't mutate the internal array.
    return wishlist.slice();
  }

  function isInWishlist(productId, variantId) {
    return findIndex(productId, variantId) !== -1;
  }

  function addToWishlist(productId, variantId) {
    var idx = findIndex(productId, variantId);
    if (idx !== -1) {
      // Already in wishlist — idempotent. Return {added: true, new: false}
      // so the frontend can show "Already in your wishlist" if it wants.
      return { added: true, new: false };
    }
    wishlist.push({
      product_id: productId,
      variant_id: variantId || null,
      added_at: new Date().toISOString()
    });
    persist();
    dispatchChangeEvent();
    return { added: true, new: true };
  }

  function removeFromWishlist(productId, variantId) {
    var idx = findIndex(productId, variantId);
    if (idx === -1) {
      return { removed: false };
    }
    wishlist.splice(idx, 1);
    persist();
    dispatchChangeEvent();
    return { removed: true };
  }

  function toggleWishlist(productId, variantId) {
    var idx = findIndex(productId, variantId);
    if (idx !== -1) {
      // Already in wishlist → remove.
      wishlist.splice(idx, 1);
      persist();
      dispatchChangeEvent();
      return { inWishlist: false, new: false };
    }
    // Not in wishlist → add.
    wishlist.push({
      product_id: productId,
      variant_id: variantId || null,
      added_at: new Date().toISOString()
    });
    persist();
    dispatchChangeEvent();
    return { inWishlist: true, new: true };
  }

  function clearWishlist() {
    var count = wishlist.length;
    if (count === 0) return { cleared: 0 };
    wishlist = [];
    persist();
    dispatchChangeEvent();
    return { cleared: count };
  }

  function getWishlistCount() {
    return wishlist.length;
  }

  global.MorbiWishlist = {
    getWishlist: getWishlist,
    isInWishlist: isInWishlist,
    addToWishlist: addToWishlist,
    removeFromWishlist: removeFromWishlist,
    toggleWishlist: toggleWishlist,
    clearWishlist: clearWishlist,
    getWishlistCount: getWishlistCount,
    // Exposed for the smoke test (read-only — tests can verify the internal
    // state without going through localStorage).
    _storageKey: STORAGE_KEY,
    _storageAvailable: function () { return storageAvailable; }
  };
})(window);
