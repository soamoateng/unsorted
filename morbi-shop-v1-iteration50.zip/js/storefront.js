/**
 * storefront.js — Morcenzs storefront at #/morcenzs
 *
 * Product grid with category filter, cart, and checkout UI shell.
 * FIX-UX-1: Cart is now page-session persistent (survives category filter changes).
 * FIX-UX-5: Mobile cart bottom sheet only appears when item is added, not on scroll.
 * FIX-BL-3: Variable shadowing in clearCheckoutValidation removed.
 * FIX-BL-11: Cart total uses rounded arithmetic.
 * FIX-BL-17: Maximum cart quantity enforced (99 per item).
 *
 * Phase 1 Batch 3 (R1): `ChowMenuUI` / `ChowMenuRouter` global references
 *   renamed to `MorbiUI` / `MorbiRouter` (with backward-compat aliases kept
 *   in ui-helpers.js and router.js — see those files).
 * Phase 1 Batch 3 (R3): Audit pass — no further fixes required. Every
 *   earlier batch already addressed the file's known issues (FIX-UX-*,
 *   FIX-WF-*, FIX-BL-*). The clearCheckoutValidation shadowing that
 *   mirrored the landing.js bug was already fixed by FIX-BL-3.
 *   Read-only consumer of MorbiStore — no async changes needed.
 *
 * Phase 2 (Bicycle): the disabled "Pay with MoMo (Coming Soon)" button
 *   is replaced with a working "Pay with Paystack" button. submitCheckout()
 *   POSTs the cart to api/payments.php (server computes total from DB
 *   prices, never trusts client), then redirects to Paystack's hosted
 *   authorization_url. Paystack handles MoMo/card/bank/USSD, then
 *   redirects back to #/payment-callback?reference=XYZ (handled by
 *   payment-callback.js).
 *
 * Phase 5 Batch 1 (Sport Car): scent category gate. On every NEW browser
 *   session (sessionStorage — clears when tab closes), the customer sees
 *   a full-screen overlay with 3 big buttons: Male Scented Perfumes /
 *   Female Scented Perfumes / Unisex Scented Perfumes (+ "View All").
 *   The choice is stored in sessionStorage + filters the product grid.
 *   Products without a scent_category field show in ALL views (backward
 *   compat — the store isn't empty if Morbi hasn't tagged everything).
 */
(function (global) {
  'use strict';

  var ui = global.MorbiUI;
  var el = ui.el, clear = ui.clear, formatPrice = ui.formatPrice;
  var store = global.MorbiStore;
  var router = global.MorbiRouter;

  var ROOT_ID = 'app-root';
  var cart = []; // [{ id, name, price, qty, scent, imagePath }]
  var activeCategory = 'all';
  var MAX_QTY = 99;

  /* ★ WF-02 + WF-03 fix: cart + discount persistence across the Paystack
   *   round-trip. submitCheckout() full-page-navigates to Paystack's
   *   authorization_url; when Paystack redirects back, the SPA re-boots
   *   with cart = [] and appliedDiscount = null — so a declined/abandoned
   *   payment forced the customer to rebuild the cart AND re-discover the
   *   promo code before retrying (the server-side order row sat orphaned
   *   in `pending`). Fix: mirror both into sessionStorage (same scope as
   *   the scent choice — survives the same-tab full-page navigation to
   *   Paystack and back, does not leak into next-day visits like
   *   localStorage would; stale prices/stock are exactly why the cart
   *   should NOT outlive the browser session). restorePersistedState()
   *   runs ONCE on the first render() boot; payment-callback.js clears
   *   both keys when the payment SUCCEEDS so "Continue Shopping" doesn't
   *   resurrect items the customer already bought (failed/abandoned keeps
   *   them — that's the retry path this fix exists for).
   *   storageBroken mirrors UX-01's scentMemoryOnly pattern: private-mode
   *   Safari etc. flips the flag once and every persistence call becomes
   *   a silent no-op instead of throwing on every mutation. */
  var CART_KEY = 'morbi:cart-v1';
  var DISCOUNT_KEY = 'morbi:discount-code';
  var storageBroken = false;
  var persistRestored = false;

  function persistCart() {
    if (storageBroken) return;
    try {
      sessionStorage.setItem(CART_KEY, JSON.stringify(cart));
    } catch (e) { storageBroken = true; }
  }

  function persistDiscount() {
    if (storageBroken) return;
    try {
      if (appliedDiscount && appliedDiscount.code) {
        sessionStorage.setItem(DISCOUNT_KEY, String(appliedDiscount.code));
      } else {
        sessionStorage.removeItem(DISCOUNT_KEY);
      }
    } catch (e) { storageBroken = true; }
  }

  function restorePersistedState() {
    if (persistRestored) return;
    persistRestored = true;
    // Restore the cart (shape-guarded — never trust storage blindly).
    try {
      var rawCart = sessionStorage.getItem(CART_KEY);
      if (rawCart) {
        var saved = JSON.parse(rawCart);
        if (Object.prototype.toString.call(saved) === '[object Array]') {
          cart = saved.filter(function (c) {
            return c && typeof c === 'object'
              && typeof c.id !== 'undefined'
              && typeof c.price === 'number' && isFinite(c.price)
              && typeof c.qty === 'number' && c.qty > 0;
          }).map(function (c) {
            // Rebuild the composite key from id + variantId so items saved
            // by older code (or with a stale key shape) still merge right.
            // NOTE: plain products use 0 (NOT null) — addToCart stores
            // `variantId: selectedVariantId` where selectedVariantId = 0
            // for variant-less products; keeping the exact same shape
            // means a restored plain item and a freshly-added one share
            // the same key and merge instead of duplicating.
            var vid = (typeof c.variantId === 'number' && c.variantId > 0) ? c.variantId : 0;
            return {
              key: c.id + '-' + vid,
              id: c.id,
              variantId: vid,
              variantName: typeof c.variantName === 'string' ? c.variantName : '',
              name: typeof c.name === 'string' ? c.name : '',
              scent: typeof c.scent === 'string' ? c.scent : '',
              price: c.price,
              qty: Math.min(Math.floor(c.qty), MAX_QTY),
              imagePath: typeof c.imagePath === 'string' ? c.imagePath : ''
            };
          });
        }
      }
    } catch (e) {
      try { sessionStorage.removeItem(CART_KEY); } catch (e2) { /* ignore */ }
    }
    // Restore the discount code. The server re-validates it at checkout
    // (payments.php) — a code deleted or exhausted since it was applied
    // simply fails validation there, so restoring it blind is safe.
    try {
      var savedCode = sessionStorage.getItem(DISCOUNT_KEY);
      if (savedCode) appliedDiscount = { code: savedCode };
    } catch (e) { /* private mode — memory-only */ }
  }

  // ★ Phase 5 Batch 1: scent category gate state.
  // Stored in sessionStorage so it resets on every NEW tab/session.
  // Values: null (gate not yet shown this session), 'male', 'female', 'unisex', 'all'
  var SCENT_KEY = 'morbi:scent-choice';
  var activeScent = null;  // loaded in render()

  // ★ UX-01 fix: when sessionStorage is unavailable (Safari private mode,
  //   strict privacy settings, quota exceeded), the old render() re-read
  //   clobbered the in-memory choice back to null on EVERY render — so
  //   chooseScent('male') → render() → read fails → null → gate again →
  //   an infinite loop that trapped private-browsing customers at the gate.
  //   Fix: once a storage write/read fails, set scentMemoryOnly = true and
  //   render() stops re-reading — the in-memory activeScent becomes the
  //   single source of truth for the rest of the page session. The flag is
  //   reset by changeScent() so a later successful storage attempt works
  //   normally again.
  var scentMemoryOnly = false;

  // ★ UX-13 fix: mobile cart bottom sheet auto-open suppression.
  //   Timestamp (ms) until which addToCart() must NOT auto-open the cart
  //   popup. Set to now + 30s every time the popup is closed, so a customer
  //   who dismissed the popup can keep browsing without it re-popping on
  //   the next add. Default 0 = never suppressed (first add opens it).
  var mobileCartSuppressedUntil = 0;
  var MOBILE_CART_SUPPRESS_MS = 30000;

  /* ---- Public render ------------------------------------------------- */

  function render() {
    // ★ WF-02 + WF-03 fix: restore the persisted cart + discount code
    //   EXACTLY ONCE per page load (persistRestored guards re-entry —
    //   render() runs on every route navigation, and re-reading storage
    //   each time would resurrect items the customer removed moments ago).
    //   Runs BEFORE the scent-gate early-return so the cart is already
    //   hydrated when the customer picks a scent and enters the store.
    restorePersistedState();

    // ★ Phase 5: load the scent choice from sessionStorage.
    // If null/empty → show the scent gate overlay (full-screen).
    // If set → show the storefront filtered by the chosen scent.
    // ★ UX-01 fix: skip the re-read when a storage failure already forced
    //   memory-only mode — re-reading here was the loop's engine (it reset
    //   the in-memory choice to null on every render while storage was
    //   blocked, re-showing the gate forever). With the guard, the choice
    //   made in chooseScent() survives renders even when storage is dead.
    if (!scentMemoryOnly) {
      try {
        activeScent = sessionStorage.getItem(SCENT_KEY) || null;
      } catch (e) {
        // Private mode / sessionStorage disabled — fall back to whatever
        // is already in memory and stop trying storage for this session.
        scentMemoryOnly = true;
      }
    }

    // If no scent chosen this session → render the gate, not the store.
    if (!activeScent) {
      renderScentGate();
      return;
    }

    // FIX-UX-1: Do NOT reset cart on render — only reset category filter
    // Cart persists within the page session (navigating away and back still resets — KISS)
    activeCategory = 'all';
    var products = store.getAvailableProducts();
    var categories = store.getCategories();
    var currency = store.getCurrency();

    // FIX-WF-12: Clean up orphaned cart items (product deleted from store)
    // ★ WF-16 fix: the cleanup above only checked PRODUCT existence — a
    //   cart item whose variantId points at a deleted variant survived
    //   (because the product still exists) and then BLOCKED the entire
    //   checkout server-side ("Invalid variant for product", 422) with no
    //   visible reason. Variant ids rotate on every product save
    //   (products.php save_variants DELETE + re-insert) and CASCADE away
    //   on product delete, so orphaned variantIds are routine, not rare.
    //   Fix: after the product-level filter, drop any item whose
    //   variantId is no longer present in its product's variants array.
    //   map_product() ALWAYS attaches `variants` (empty array when the
    // ★ H9 fix (audit): only run cart cleanup when products is non-empty.
    //   If store.getAvailableProducts() returns [] (API hiccup, hydrate
    //   fallback to defaults() with string IDs), the old code dropped every
    //   cart line as "orphaned" + persistCart() cemented the loss into
    //   sessionStorage. Now: skip the cleanup entirely on empty products.
    if (products.length > 0) {
      var productIds = products.map(function (p) { return p.id; });
      cart = cart.filter(function (c) { return productIds.indexOf(c.id) !== -1; });
      cart = cart.filter(function (c) {
        if (!c.variantId) return true;  // plain product — nothing to verify
        var parent = null;
        for (var i = 0; i < products.length; i++) {
          // ★ Phase 10 (2026-09-26): use String() coercion so a restored
          //   cart id (could be string from older sessionStorage shape)
          //   still matches a server INT id. Was: `products[i].id === c.id`
          //   — strict === failed if types mismatched, the variant-orphan
          //   check returned false, and the orphaned variant stayed in the
          //   cart silently (checkout would 422 on it later).
          if (String(products[i].id) === String(c.id)) { parent = products[i]; break; }
        }
        if (!parent || !parent.variants || !parent.variants.length) return false;
        for (var j = 0; j < parent.variants.length; j++) {
          if (String(parent.variants[j].id) === String(c.variantId)) return true;
        }
        return false;  // variantId not found → orphaned → drop
      });
      // ★ WF-03 fix: the cleanup may have just dropped items — write the cleaned
      //   cart back so storage never disagrees with what the customer sees.
      persistCart();
    }

    // ★ Phase 8 Batch 3 (Task 60): wire up the currency-change event so
    //   switching the currency dropdown re-renders prices without a page
    //   reload. The listener is idempotent — guarded by a flag so multiple
    //   render() calls don't stack listeners.
    // ★ Phase 10 (2026-09-26): debounce the render() call so rapid currency
    //   changes (e.g. user clicks the dropdown twice fast) don't stack two
    //   full re-renders. The trailing render picks up the latest currency
    //   state, so the intermediate render is wasted work.
    if (!global._morbiCurrencyListenerWired) {
      global._morbiCurrencyListenerWired = true;
      var _currencyRenderTimer = null;
      global.addEventListener('morbi:currency', function () {
        // Debounce: 50ms is imperceptible to humans but collapses
        // multiple same-event renders into one. If the user clicks the
        // currency dropdown 3 times in 100ms, only ONE render fires.
        if (_currencyRenderTimer) clearTimeout(_currencyRenderTimer);
        _currencyRenderTimer = setTimeout(function () {
          _currencyRenderTimer = null;
          // Re-render with the new currency. Same path as the initial render
          // — products, categories, currency are all re-read. The currency
          // dropdown's selected <option> is set from localStorage in
          // renderStoreHeader(), so it stays in sync.
          try { render(); }
          catch (e) {
            if (typeof console !== 'undefined' && console.error) {
              console.error('[morbi] Currency-change re-render threw:', e && e.message ? e.message : e);
            }
          }
        }, 50);
      });
    }

    // ★ Phase 9 Batch 5 (Task 64): wire up the wishlist-change event so the
    //   header count badge updates when a product is added/removed from the
    //   wishlist. The listener is idempotent (guarded by a flag). Doesn't
    //   trigger a full re-render — just updates the badge's text + color.
    if (!global._morbiWishlistListenerWired) {
      global._morbiWishlistListenerWired = true;
      global.addEventListener('morbi:wishlist', function (ev) {
        var badge = document.getElementById('wishlist-count-badge');
        if (badge) {
          var count = (ev && ev.detail && typeof ev.detail.count === 'number')
            ? ev.detail.count
            : (global.MorbiWishlist ? global.MorbiWishlist.getWishlistCount() : 0);
          badge.textContent = String(count);
          badge.style.background = count > 0 ? '#dc2626' : 'transparent';
        }
      });
    }

    doRender(products, categories, currency);
  }

  /* ---- Phase 5: Scent category gate ---------------------------------- *
   * Full-screen overlay with 3 big buttons (Male / Female / Unisex) +
   * a "View All Scents" link. The choice is stored in sessionStorage
   * (clears when the tab closes → gate reappears on next visit).
   *
   * Products are filtered by their scent_category field:
   *   - 'male'    → show products where scent_category === 'male'
   *   - 'female'  → show products where scent_category === 'female'
   *   - 'unisex'  → show products where scent_category === 'unisex' (or null/empty — default)
   *   - 'all'     → show everything (no filter)
   *
   * Products WITHOUT a scent_category field show in ALL views (backward
   * compat — so the store isn't empty if Morbi hasn't tagged everything).
   * This means 'male' shows male-tagged + untagged products; 'female'
   * shows female-tagged + untagged; etc. Only 'all' shows truly everything.
   *
   * The user can change their choice at any time via the "Change Scent"
   * button in the storefront header (small, top-right). */

  function renderScentGate() {
    var root = document.getElementById(ROOT_ID);
    if (!root) return;
    clear(root);

    root.appendChild(
      el('div', { class: 'container scent-gate-container' }, [
        el('div', { class: 'scent-gate' }, [
          el('div', { class: 'scent-gate-logo' }, [
            el('h1', { class: 'scent-gate-brand' }, 'Morcenzs'),
            el('p', { class: 'scent-gate-tagline' }, 'Luxury Scents, Redefined.')
          ]),
          el('div', { class: 'scent-gate-content' }, [
            el('h2', { class: 'scent-gate-title' }, 'What are you looking for today?'),
            el('p', { class: 'scent-gate-subtitle' }, 'Choose a scent category to explore our collection.'),
            el('div', { class: 'scent-gate-buttons' }, [
              el('button', {
                class: 'scent-gate-btn scent-male',
                onclick: function () { chooseScent('male'); }
              }, [
                el('span', {}, 'Male Perfumes')
              ]),
              el('button', {
                class: 'scent-gate-btn scent-female',
                onclick: function () { chooseScent('female'); }
              }, [
                el('span', {}, 'Female Perfumes')
              ]),
              el('button', {
                class: 'scent-gate-btn scent-unisex',
                onclick: function () { chooseScent('unisex'); }
              }, [
                el('span', {}, 'Unisex Perfumes')
              ])
            ]),
            el('button', {
              class: 'scent-gate-all',
              onclick: function () { chooseScent('all'); }
            }, 'View All Scents')
          ])
        ])
      ])
    );
  }

  function chooseScent(scent) {
    try {
      sessionStorage.setItem(SCENT_KEY, scent);
    } catch (e) {
      // ★ UX-01 fix: the write failed (private mode / quota) — switch to
      //   memory-only mode BEFORE re-rendering so render() doesn't clobber
      //   the in-memory choice back to null and re-show the gate (the old
      //   infinite loop). The choice now persists for this page session
      //   even though it can't be persisted to sessionStorage.
      scentMemoryOnly = true;
    }
    activeScent = scent;
    // Re-render the full storefront now that a scent is chosen.
    render();
  }

  function changeScent() {
    // Clear the stored choice + re-show the gate.
    try {
      sessionStorage.removeItem(SCENT_KEY);
    } catch (e) { /* ignore */ }
    activeScent = null;
    // ★ UX-01 fix: re-arm storage — if it works on the next chooseScent()
    //   the choice persists normally again; if it's still broken the catch
    //   in chooseScent() flips scentMemoryOnly back on (no loop either way).
    scentMemoryOnly = false;
    render();
  }

  // ★ Phase 5: filter products by the chosen scent.
  // Products with no scent_category (null/empty) show in ALL scent views
  // (backward compat — the store isn't empty if products aren't tagged).
  function filterByScent(products) {
    if (!activeScent || activeScent === 'all') return products;
    return products.filter(function (p) {
      var sc = p.scentCategory || p.scent_category || '';
      // Show if: the product's scent matches the active scent, OR the
      // product has no scent_category set (untagged = shows everywhere).
      return sc === '' || sc === null || sc === activeScent;
    });
  }

  function doRender(products, categories, currency) {
    var root = document.getElementById(ROOT_ID);
    if (!root) return;

    // Save scroll position before re-render
    var scrollY = (typeof window !== 'undefined') ? window.scrollY : 0;

    clear(root);

    // ★ Phase 5: filter products by the chosen scent FIRST, then by category.
    var scented = filterByScent(products);

    // Filter products by active category.
    var filtered = activeCategory === 'all'
      ? scented
      : scented.filter(function (p) { return p.categoryId === activeCategory; });

    root.appendChild(
      el('div', { class: 'container' }, [
        renderStoreHeader(),
        // ★ Phase 6 Batch 1c (Task 50): render the 5 new section types
        // (promo_banner, cta_block, image_spot, text_block, spacer) ABOVE
        // the product grid. The 4 base types (hero, about, featured,
        // footer) stay on / only (the landing page) — they're filtered out
        // of the storefront by the renderStorefrontSections() loop. If
        // there are no storefront-applicable sections, this returns null +
        // the el() helper flattens it out — no empty wrapper div.
        renderStorefrontSections(),
        el('div', { class: 'main-body' }, [
          el('div', { class: 'main-menu' }, [
            // ★ UX-11 fix: pass `scented` (the scent-filtered subset), not
            //   the raw `products` list. Previously the category-bar counts
            //   were computed over ALL products while the grid showed only
            //   the scent-filtered subset — "Eau de Parfum (4)" could render
            //   just 1 card because the other 3 were hidden by the scent
            //   gate. Counts now always match what the grid can actually
            //   show. (With scent = 'all' the two lists are identical, so
            //   the un-gated experience is unchanged.)
            // ★ WF-12 fix: pass the FULL product list as a third argument —
            //   the "All (N)" badge now always shows the true store size,
            //   not the scent-filtered subset ("All (3)" in the Male view
            //   vs "All (12)" unfiltered read as if products vanished).
            //   Per-category counts intentionally stay scent-filtered (the
            //   UX-11 rule — clicking a category must not show "X (4)" with
            //   1 visible card), so the two compromises coexist: All =
            //   global truth, categories = what you'd get in this view.
            renderCategoryBar(categories, scented, products),
            renderProductGrid(filtered, currency)
          ]),
          el('div', { class: 'order' }, [
            renderCartSidebar(currency)
          ])
        ]),
        // FIX-UX-5: Mobile cart FAB + popup — only shown on mobile via CSS
        el('button', {
          class: 'cart-fab', id: 'cart-fab',
          'aria-label': 'Open cart',
          onclick: function () { toggleMobileCart(true); }
        }, [
          el('i', { class: 'fas fa-shopping-bag' }),
          el('span', { class: 'cart-fab-badge', id: 'cart-fab-badge' }, '0')
        ]),
        // ★ Phase 10 (2026-09-26): add role="button" + aria-label + tabindex
        //   so the overlay is keyboard-accessible + announced by screen
        //   readers as "Close cart" (was: a generic div with no semantics
        //   — clicking outside closed the cart, but keyboard users had no
        //   way to close it via the overlay, only via the × button).
        //   The onclick stays as-is — the overlay's click handler closes
        //   the cart. The keydown handler treats Enter/Space as a click.
        el('div', {
          class: 'cart-overlay',
          id: 'cart-overlay',
          role: 'button',
          tabindex: '0',
          'aria-label': 'Close cart',
          onclick: function () { toggleMobileCart(false); },
          onkeydown: function (ev) {
            if (ev.key === 'Enter' || ev.key === ' ' || ev.keyCode === 13 || ev.keyCode === 32) {
              ev.preventDefault();
              toggleMobileCart(false);
            }
          }
        }),
        el('div', { class: 'cart-popup', id: 'cart-popup' }, [
          renderCartPopupContent(currency)
        ]),
        // ★ UX-12 fix: dedicated cart/stock error slot. flashCartError()
        //   prefers #cart-error — but no element with that id was ever
        //   rendered, so "Only 3 of this item are available." / "Please
        //   select a size…" fell through to #co-name-error INSIDE the
        //   (usually closed) checkout modal — invisible while browsing, or
        //   misleading (under the Full Name field) when the modal was open.
        //   This banner is a fixed toast above the cart FAB, visible on
        //   desktop + mobile without touching any CSS file (the .form-error
        //   class supplies the red text + .show display toggle; inline
        //   styles supply the toast positioning).
        el('p', { class: 'form-error', id: 'cart-error', style: {
          position: 'fixed', left: '16px', right: '16px', bottom: '88px',
          margin: '0 auto', maxWidth: '420px', padding: '10px 14px',
          background: 'var(--bg-card, #1a1a1a)', border: '1px solid var(--danger, #dc2626)',
          borderRadius: '8px', textAlign: 'center', zIndex: '1300',
          fontSize: '13px', pointerEvents: 'none'
        } }, ''),
        // Checkout modal
        el('div', { class: 'checkout-modal', id: 'checkout-modal', onclick: function (e) {
          // FIX-UX-11: Click outside to close
          if (e.target.id === 'checkout-modal') closeCheckout();
        } }, [
          renderCheckoutCard(currency)
        ])
      ])
    );

    updateCartFAB();

    // Restore scroll position after re-render (unless first load)
    if (scrollY > 0) {
      try { window.scrollTo(0, scrollY); } catch (e) { /* ignore */ }
    }

    // FIX-UX-17: Escape key to close checkout
    bindGlobalKeys();

    // ★ Task 55: wire up the inline edit blur handler if admin is logged in.
    //   The storefront doesn't have an "Edit Mode" toggle — the admin just
    //   sees the dashed outlines when logged in + can click text to edit.
    // ★ Blind-spot fix (2026-09-26): bindStorefrontInlineEdit(root) was
    //   called on every render() and attached a NEW capture-phase `blur`
    //   listener to #app-root every time. Because #app-root persists across
    //   renders (only its children are cleared), after N renders there were
    //   N identical listeners → every blur fired N `store.updateSection`
    //   API calls → write amplification + memory leak. Now: guard with a
    //   per-element flag so the listener attaches EXACTLY once per #app-root
    //   instance (still works across page reloads because the flag is on the
    //   DOM node, which is recreated on reload).
    if (store && typeof store.isAdmin === 'function' && store.isAdmin()) {
      bindStorefrontInlineEdit(root);
    }

    // ★ Phase 9 Batch 1 (Task 61): wire up the search input listener.
    //   bindStorefrontSearch() is idempotent (guarded by
    //   global._morbiSearchBindPending) so calling it on every render() is
    //   safe. The actual listener attachment only happens once — on the
    //   first render after the search input exists in the DOM.
    bindStorefrontSearch();
  }

  // ★ Task 55: inline edit blur handler for the storefront. Same pattern
  //   as landing.js's bindInlineEditHandlers — delegated from #app-root.
  // ★ Blind-spot fix (2026-09-26): added a per-element guard flag
  //   (`root._morbiInlineEditBound`) so the listener attaches EXACTLY once
  //   per #app-root instance. Without this guard, every render() re-attached
  //   a fresh capture-phase `blur` listener on the SAME persistent
  //   #app-root, stacking N identical listeners after N renders → N
  //   duplicate `store.updateSection` API calls per blur.
  function bindStorefrontInlineEdit(root) {
    if (root._morbiInlineEditBound) return;  // idempotency guard
    root._morbiInlineEditBound = true;
    root.addEventListener('blur', function (e) {
      var target = e.target;
      if (!target.hasAttribute || !target.hasAttribute('contenteditable')) return;
      var sectionId = parseInt(target.getAttribute('data-section-id'), 10);
      var field = target.getAttribute('data-field');
      // ★ Phase 10 (2026-09-26): explicit isNaN + > 0 check (mirrors the
      //   landing.js fix). Was: `if (!sectionId || !field) return;` — same
      //   NaN-vs-0 ambiguity.
      if (isNaN(sectionId) || sectionId <= 0 || !field) return;
      var newText = target.textContent.trim();
      var sections = store.getSectionsPublic();
      var section = sections.find(function (s) { return s.id === sectionId; });
      if (!section) return;
      var currentText = (section.content && section.content[field]) || '';
      if (newText === currentText) return;
      var newContent = Object.assign({}, section.content || {});
      newContent[field] = newText;
      showStorefrontToast('Saving…');
      store.updateSection(sectionId, { content: newContent }).then(function () {
        showStorefrontToast('Saved ✓');
      }).catch(function (err) {
        showStorefrontToast('Save failed: ' + (err.message || 'error'), true);
        // ★ Phase 10 (2026-09-26): only revert if the user hasn't continued
        //   editing (mirrors the landing.js fix). Was: unconditional revert
        //   that wiped any edits the user typed between blur and the catch
        //   firing.
        if (target.textContent.trim() === newText) {
          target.textContent = currentText;
        }
      });
    }, true);
  }

  var storefrontToastEl = null;
  var storefrontToastTimer = null;
  function showStorefrontToast(msg, isError) {
    if (!storefrontToastEl) {
      storefrontToastEl = document.createElement('div');
      storefrontToastEl.style.cssText = 'position:fixed;bottom:20px;right:20px;padding:8px 16px;border-radius:6px;font-size:14px;font-weight:600;z-index:99999;box-shadow:0 2px 8px rgba(0,0,0,0.3);transition:opacity 0.3s;';
      document.body.appendChild(storefrontToastEl);
    }
    storefrontToastEl.textContent = msg;
    storefrontToastEl.style.background = isError ? '#dc2626' : '#2D8B4E';
    storefrontToastEl.style.color = '#fff';
    storefrontToastEl.style.opacity = '1';
    if (storefrontToastTimer) clearTimeout(storefrontToastTimer);
    storefrontToastTimer = setTimeout(function () {
      if (storefrontToastEl) storefrontToastEl.style.opacity = '0';
    }, 2000);
  }

  function bindGlobalKeys() {
    // FIX-UX-17: Bound once per render — removes old listener automatically
    // since we clear the DOM each time. Use document-level handler.
    // ★ RT-17 fix: was using `bindGlobalKeys._bound` flag on the function
    //   object to prevent duplicate listeners. The flag survives hot-reload
    //   (the function object is re-created by HMR, but the old listener is
    //   still on `document`). After HMR, the new module sees `_bound = true`
    //   (inherited from the old module's closure? No — the function is
    //   re-created, so `_bound` is undefined). Actually, the flag is on the
    //   function object itself, which is in the module's closure — HMR
    //   creates a NEW closure with a NEW function object, so the new
    //   function's `_bound` is undefined. The new module adds a new listener.
    //   The OLD listener is still on `document`, referencing the OLD
    //   `closeCheckout`/`toggleMobileCart` functions. Both fire on Escape.
    //   In production (no HMR), the listener is added once (the flag prevents
    //   re-binding on subsequent `bindGlobalKeys()` calls during re-render).
    //   Fix: remove the `_bound` flag. Instead, use a named function stored
    //   on `document` so it can be removed before re-adding. Each
    //   `bindGlobalKeys()` call removes the old handler (if any) and adds a
    //   new one — no stacking, no stale references after HMR.
    if (document.__morbiStorefrontKeydown) {
      document.removeEventListener('keydown', document.__morbiStorefrontKeydown);
    }
    document.__morbiStorefrontKeydown = function (e) {
      if (e.key === 'Escape') {
        var modal = document.getElementById('checkout-modal');
        if (modal && modal.classList.contains('open')) {
          closeCheckout();
        }
        var popup = document.getElementById('cart-popup');
        if (popup && popup.classList.contains('open')) {
          toggleMobileCart(false);
        }
      }
    };
    document.addEventListener('keydown', document.__morbiStorefrontKeydown);
  }

  /* ★ Phase 9 Batch 5 (Task 64): renderWishlist() — the /wishlist route handler.
   *   Renders the customer's saved wishlist items as a product grid. Reuses
   *   the existing product card renderer (renderProductGrid) by looking up
   *   each wishlist entry's product in the hydrated store products.
   *
   *   If the wishlist is empty, shows a friendly "Your wishlist is empty"
   *   message + a link to the storefront (/morcenzs).
   *
   *   Each product card has the heart button (filled red — items already in
   *   the wishlist). Clicking the heart removes the item from the wishlist +
   *   the card disappears (the morbi:wishlist event triggers a re-render).
   *
   *   The wishlist view does NOT show the scent gate, search bar, or sections
   *   — it's a focused view of saved items. The header (with its wishlist
   *   count badge + currency switcher + nav links) is rendered so the
   *   customer can navigate back to the store.
   */
  function renderWishlist() {
    var root = document.getElementById(ROOT_ID);
    if (!root) return;
    clear(root);

    var wishlistItems = (global.MorbiWishlist && global.MorbiWishlist.getWishlist()) || [];
    var allProducts = store.getAvailableProducts();

    // Build a set of wishlist product IDs for quick lookup.
    var wishlistProductIds = {};
    wishlistItems.forEach(function (item) {
      wishlistProductIds[item.product_id] = true;
    });

    // Filter the hydrated products to only those in the wishlist.
    var wishlistProducts = allProducts.filter(function (p) {
      return !!wishlistProductIds[p.id];
    });

    var currency = store.getCurrency();

    root.appendChild(
      el('div', { class: 'container' }, [
        renderStoreHeader(),
        el('div', { class: 'main-body' }, [
          el('div', { class: 'main-menu' }, [
            // Back-to-store link
            el('button', {
              class: 'btn-sm outline',
              style: { marginBottom: '12px' },
              onclick: function () { router.navigate('/morcenzs'); }
            }, [el('i', { class: 'fas fa-chevron-left', style: { marginRight: '4px' } }), 'Back to store']),
            // Wishlist heading + clear button
            el('div', { style: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px' } }, [
              el('h3', { style: { margin: '0' } }, [
                el('i', { class: 'fas fa-heart', style: { marginRight: '8px', color: '#dc2626' } }),
                'Your Wishlist',
                ' (' + wishlistProducts.length + ')'
              ]),
              wishlistProducts.length > 0 ? el('button', {
                class: 'btn-sm outline',
                style: { borderColor: '#dc2626', color: '#dc2626', fontSize: '13px' },
                onclick: function () {
                  if (!confirm('Clear your entire wishlist? This cannot be undone.')) return;
                  if (global.MorbiWishlist) global.MorbiWishlist.clearWishlist();
                  renderWishlist();  // re-render the now-empty view
                }
              }, [el('i', { class: 'fas fa-trash-can', style: { marginRight: '4px' } }), 'Clear all']) : null
            ]),
            // Product grid or empty-state message
            wishlistProducts.length > 0
              ? renderProductGrid(wishlistProducts, currency)
              : el('div', { style: { textAlign: 'center', padding: '48px 16px' } }, [
                  el('i', { class: 'fas fa-heart', style: { fontSize: '48px', color: 'var(--muted, #a0a0a0)', marginBottom: '16px', display: 'block' } }),
                  el('p', { style: { fontSize: '18px', marginBottom: '8px' } }, 'Your wishlist is empty'),
                  el('p', { class: 'muted', style: { marginBottom: '16px' } }, 'Save products you love by clicking the heart icon on any product card.'),
                  el('button', {
                    class: 'btn-md',
                    style: { background: 'var(--accent, #FFAA00)', color: '#000', border: 'none' },
                    onclick: function () { router.navigate('/morcenzs'); }
                  }, [el('i', { class: 'fas fa-store', style: { marginRight: '6px' } }), 'Browse products'])
                ])
          ])
        ])
      ])
    );

    // Wire up the wishlist event listener so removing an item from the
    // wishlist (via the heart button) triggers a re-render of this view.
    // The listener is idempotent — if it was already wired by render(),
    // this is a no-op. But we ALSO need to re-render THIS view on wishlist
    // change, which the render()-level listener doesn't do (it only updates
    // the count badge). So we add a one-time listener for the wishlist view.
    if (!global._morbiWishlistViewListenerWired) {
      global._morbiWishlistViewListenerWired = true;
      global.addEventListener('morbi:wishlist', function () {
        // Only re-render if we're currently on the /wishlist route.
        var path = global.location.pathname || '/';
        var stripped = global.MorbiRouter ? global.MorbiRouter.stripBasePath(path) : path;
        if (stripped === '/wishlist') {
          renderWishlist();
        }
      });
    }
  }

  /* ---- Store header -------------------------------------------------- */
  // FIX-UX-4: Added dashboard link to storefront header
  // ★ Phase 5: Added "Change Scent" button to re-open the scent gate

  function renderStoreHeader() {
    var scentLabel = activeScent === 'all'
      ? 'All Scents'
      : (activeScent ? (activeScent.charAt(0).toUpperCase() + activeScent.slice(1) + ' Scents') : '');
    // ★ Phase 8 Batch 3 (Task 60): currency switcher dropdown.
    //   Built from the hydrated currencies map. The selected value persists
    //   in localStorage (via store.setCurrentCurrencyCode). The change
    //   listener dispatches 'morbi:currency' event → storefront re-renders.
    var currencySelect = el('select', {
      class: 'btn-sm outline',
      id: 'storefront-currency-select',
      style: { fontSize: '13px', padding: '6px 8px', width: 'auto', height: 'auto', borderColor: 'var(--accent)', color: 'var(--accent)', cursor: 'pointer' },
      title: 'Display currency',
      onchange: function (ev) {
        var code = ev.target.value;
        store.setCurrentCurrencyCode(code);
        // Re-render — the new currency is now in localStorage; formatPriceIn
        // will use it on the next render cycle. The 'morbi:currency' event
        // listener (wired in render()) also fires + calls doRender().
      }
    });
    var currenciesMap = store.getCurrenciesMap();
    var currentCode = store.getCurrentCurrencyCode();
    Object.keys(currenciesMap).sort().forEach(function (code) {
      var c = currenciesMap[code];
      var option = el('option', { value: code }, code + ' (' + c.symbol + ')');
      if (code === currentCode) option.selected = true;
      currencySelect.appendChild(option);
    });
    // If only GHS is hydrated (no currencies configured yet), hide the
    // dropdown — no point showing a 1-option select.
    if (Object.keys(currenciesMap).length <= 1) {
      currencySelect.style.display = 'none';
    }

    // ★ Phase 9 Batch 1 (Task 61): search input + dropdown results container.
    //   Debounced 300ms in handleSearchInput (wired via bindStorefrontSearch
    //   below — uses setTimeout + clearTimeout pattern; no external lib).
    //   The dropdown is positioned absolute, hidden by default (display:none),
    //   shown when results arrive. Click-outside closes it (wired in bind).
    var searchInput = el('input', {
      type: 'search',
      id: 'storefront-search-input',
      class: 'btn-sm outline',
      placeholder: 'Search products…',
      autocomplete: 'off',
      style: {
        fontSize: '13px', padding: '6px 10px', width: '160px',
        height: 'auto', borderColor: 'var(--accent)',
        color: 'var(--accent)', borderRadius: '4px'
      },
      title: 'Search by name, scent, or description'
    });
    var searchDropdown = el('div', {
      id: 'storefront-search-dropdown',
      class: 'search-dropdown',
      style: {
        display: 'none',
        position: 'absolute', zIndex: '1000',
        background: '#1a1a1a', border: '1px solid #333',
        borderRadius: '4px', minWidth: '260px', maxHeight: '320px',
        overflow: 'auto', boxShadow: '0 4px 12px rgba(0,0,0,0.4)',
        marginTop: '2px'
      }
    });
    var searchWrapper = el('div', { style: { position: 'relative', display: 'inline-block' } }, [
      searchInput,
      searchDropdown
    ]);

    return el('header', { class: 'storefront-header' }, [
      el('div', {}, [
        el('div', { class: 'storefront-brand' }, 'Morcenzs'),
        el('div', { class: 'storefront-tagline' }, 'Luxury Scents, Redefined.')
      ]),
      el('div', { style: { display: 'flex', gap: '8px', alignItems: 'center', flexWrap: 'wrap' } }, [
        // ★ Phase 9 Batch 1: search input + dropdown (left-most so it's prominent).
        searchWrapper,
        // ★ Phase 8 Batch 3: currency switcher dropdown.
        currencySelect,
        // ★ Phase 9 Batch 5 (Task 64): wishlist link with count badge.
        //   Navigates to /wishlist. The count badge updates via the
        //   'morbi:wishlist' event listener (wired in render()).
        (function () {
          var count = (global.MorbiWishlist && global.MorbiWishlist.getWishlistCount()) || 0;
          return el('button', {
            class: 'btn-sm outline',
            id: 'storefront-wishlist-btn',
            style: {
              fontSize: '13px', padding: '6px 12px', width: 'auto', height: 'auto',
              position: 'relative', borderColor: 'var(--accent)', color: 'var(--accent)'
            },
            title: 'View wishlist',
            onclick: function () { router.navigate('/wishlist'); }
          }, [
            el('i', { class: 'fas fa-heart', style: { marginRight: '4px' } }),
            el('span', { id: 'wishlist-count-badge', style: {
              background: count > 0 ? '#dc2626' : 'transparent',
              color: '#fff', fontSize: '11px', padding: '1px 5px',
              borderRadius: '8px', marginLeft: '2px', minWidth: '14px',
              display: 'inline-block', textAlign: 'center'
            } }, String(count))
          ]);
        })(),
        // ★ Phase 5: Change Scent button — shows the current scent + lets the user re-choose
        el('button', {
          class: 'btn-sm outline scent-change-btn',
          style: { fontSize: '13px', padding: '6px 12px', width: 'auto', height: 'auto', borderColor: 'var(--accent)', color: 'var(--accent)' },
          title: 'Change scent category',
          onclick: function () { changeScent(); }
        }, [el('i', { class: 'fas fa-tag', style: { marginRight: '4px' } }), scentLabel]),
        // ★ Feature 1: replace the 2 separate buttons (Admin Panel icon,
        //   morbi.shop text) with a single hamburger menu containing:
        //     1. Admin Panel → /dashboard
        //     2. Back to Home → /
        //     3. Storefront → /morcenzs
        //   The shared helper (ui.renderHeaderMenu) handles outside-click +
        //   Escape-key + click-item-to-close. The button keeps the same
        //   btn-sm outline look the previous Admin Panel icon button had.
        ui.renderHeaderMenu([
          {
            label: 'Admin Panel',
            icon: 'fas fa-cog',
            onclick: function () { router.navigate('/dashboard'); }
          },
          {
            label: 'Back to Home',
            icon: 'fas fa-home',
            onclick: function () { router.navigate('/'); }
          },
          {
            label: 'Storefront',
            icon: 'fas fa-store',
            onclick: function () { router.navigate('/morcenzs'); }
          }
        ], 'btn-sm outline')
      ])
    ]);
  }

  /* ★ Phase 9 Batch 1 (Task 61): bind + render search dropdown.
   *
   * bindStorefrontSearch() — wires the input listener with a 300ms debounce.
   * Idempotent (guarded by global._morbiSearchWired) so re-renders don't
   * stack listeners. Also wires a click-outside handler to close the dropdown.
   *
   * handleSearchInput(query) — calls store.searchProducts, renders results
   * into #storefront-search-dropdown. Each result is a clickable row that
   * scrolls to the product card in the grid + flashes it. If the query is
   * empty, hides the dropdown. If no results, shows "No products found".
   *
   * The search does NOT change the product grid — it shows a dropdown of
   * quick results. The customer can click a result to jump to the product,
   * OR clear the search to keep browsing. (A future iteration could add a
   * "Show all results" link that filters the grid — deferred.)
   */
  if (!global._morbiSearchWired) {
    global._morbiSearchWired = true;
    // Defer the listener attachment until after DOMContentLoaded — the
    // #storefront-search-input element is created by renderStoreHeader()
    // which runs during render(). bindStorefrontSearch() is called from
    // doRender() AFTER renderStoreHeader() has populated the DOM.
    global._morbiSearchBindPending = true;
  }

  function bindStorefrontSearch() {
    if (!global._morbiSearchBindPending) return;
    var input = document.getElementById('storefront-search-input');
    if (!input) return;
    global._morbiSearchBindPending = false;

    var debounceTimer = null;
    input.addEventListener('input', function (ev) {
      var query = ev.target.value.trim();
      // Clear any pending search — the user typed another character.
      if (debounceTimer) clearTimeout(debounceTimer);
      debounceTimer = setTimeout(function () {
        handleSearchInput(query);
      }, 300);
    });

    // Click-outside closes the dropdown.
    // ★ L13 fix (audit): check document.contains(input) to self-clean when
    //   the input is detached (route change to /dashboard). The old code
    //   captured `input` in a closure that stayed on document forever —
    //   a listener leak. Now: if the input is no longer in the DOM, the
    //   handler removes itself.
    // ★ NEW-1 fix (audit): arguments.callee is forbidden in strict mode
    //   (storefront.js uses 'use strict' at line 37). Use a named function
    //   expression so we can reference it for removeEventListener.
    var clickOutsideHandler = function (ev) {
      if (!document.contains(input)) {
        document.removeEventListener('click', clickOutsideHandler);
        return;
      }
      var wrapper = input.parentElement;
      if (wrapper && !wrapper.contains(ev.target)) {
        var dd = document.getElementById('storefront-search-dropdown');
        if (dd) dd.style.display = 'none';
      }
    };
    document.addEventListener('click', clickOutsideHandler);

    // Escape key clears the input + hides the dropdown.
    input.addEventListener('keydown', function (ev) {
      if (ev.key === 'Escape' || ev.keyCode === 27) {
        input.value = '';
        var dd = document.getElementById('storefront-search-dropdown');
        if (dd) dd.style.display = 'none';
        input.blur();
      }
    });
  }

  function handleSearchInput(query) {
    var dropdown = document.getElementById('storefront-search-dropdown');
    if (!dropdown) return;

    if (query === '') {
      dropdown.style.display = 'none';
      clear(dropdown);
      return;
    }

    // Show a "Searching…" placeholder while the API call is in flight.
    clear(dropdown);
    dropdown.appendChild(el('div', {
      style: { padding: '8px 12px', color: '#999', fontSize: '13px' }
    }, 'Searching…'));
    dropdown.style.display = 'block';

    // ★ H7 fix (audit): track a request counter so stale responses from
    //   earlier queries don't overwrite newer results. Without this, a slow
    //   fetch for "ab" can resolve AFTER "abc" and render stale results.
    if (!global._morbiSearchReqId) global._morbiSearchReqId = 0;
    var myReqId = ++global._morbiSearchReqId;

    store.searchProducts({ q: query, limit: 10 }).then(function (data) {
      if (myReqId !== global._morbiSearchReqId) return; // stale — a newer request superseded us
      // ★ Phase 10 (2026-09-26): stale-response guard bailed without updating
      //   the dropdown — so the "Searching…" placeholder from the older query
      //   stayed visible forever (a newer query that itself failed would
      //   show its own error, but a newer query that succeeded would render
      //   results over the placeholder, leaving it correct). The edge case
      //   is: the user types "ab" (placeholder shows), then types "abc"
      //   before "ab"'s fetch returns. The "ab" fetch returns, sees it's
      //   stale, bails — but the placeholder is still showing for "ab".
      //   Meanwhile the "abc" fetch is in flight with NO placeholder (the
      //   placeholder was set ONCE outside the request-id guard, for "ab").
      //   The current render() shows "Searching…" + the "abc" fetch hasn't
      //   resolved yet → no result dropdown. When "abc" resolves, it
      //   replaces "Searching…" with results. So actually the placeholder
      //   stays visible until the latest query resolves — correct behavior.
      //   The "stale placeholder" concern was a false alarm — leaving as-is.
      renderSearchResults(dropdown, data.products || [], query);
    }).catch(function (err) {
      if (myReqId !== global._morbiSearchReqId) return; // stale
      clear(dropdown);
      dropdown.appendChild(el('div', {
        style: { padding: '8px 12px', color: '#dc2626', fontSize: '13px' }
      }, 'Search failed: ' + (err.message || 'network error')));
      dropdown.style.display = 'block';
    });
  }

  function renderSearchResults(dropdown, products, query) {
    clear(dropdown);
    if (!products.length) {
      dropdown.appendChild(el('div', {
        style: { padding: '8px 12px', color: '#999', fontSize: '13px' }
      }, 'No products found for "' + query + '".'));
      dropdown.style.display = 'block';
      return;
    }
    products.forEach(function (p) {
      var row = el('div', {
        class: 'search-result-row',
        style: {
          padding: '8px 12px', cursor: 'pointer', borderBottom: '1px solid #333',
          display: 'flex', alignItems: 'center', gap: '8px'
        },
        onmouseenter: function () { row.style.background = '#2a2a2a'; },
        onmouseleave: function () { row.style.background = 'transparent'; },
        onclick: function () {
          // Hide the dropdown + clear the input.
          dropdown.style.display = 'none';
          var input = document.getElementById('storefront-search-input');
          if (input) input.value = '';
          // Scroll to the product card + flash it. The card has id="product-N".
          var card = document.getElementById('product-' + p.id);
          if (card) {
            card.scrollIntoView({ behavior: 'smooth', block: 'center' });
            // Brief highlight to draw the eye.
            var orig = card.style.outline;
            card.style.outline = '3px solid #FFAA00';
            setTimeout(function () { card.style.outline = orig; }, 1500);
          } else {
            // Product not in the current filtered grid (e.g., the scent gate
            // is set to "male" but the search result is unisex). Surface a
            // hint to the customer.
            showStorefrontToast('Found "' + p.name + '" — switch to "All Scents" to see it in the grid.', false);
          }
        }
      }, [
        // Thumbnail (if image_path is set). Small 32x32 square.
        // ★ Phase 10 (2026-09-26): resolve image path against basePath (same fix as renderProductGrid).
        (p.image_path && store.resolveImagePath) ? el('img', {
          src: store.resolveImagePath(p.image_path),
          alt: p.name,
          style: { width: '32px', height: '32px', objectFit: 'cover', borderRadius: '4px' }
        }) : (p.image_path ? el('img', {
          src: p.image_path,
          alt: p.name,
          style: { width: '32px', height: '32px', objectFit: 'cover', borderRadius: '4px' }
        }) : el('div', {
          style: { width: '32px', height: '32px', background: '#333', borderRadius: '4px' }
        })),
        el('div', { style: { flex: '1', minWidth: '0' } }, [
          el('div', {
            style: { fontSize: '13px', fontWeight: 'bold', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }
          }, p.name + (p.scent ? ' — ' + p.scent : '')),
          el('div', {
            style: { fontSize: '12px', color: '#999', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }
          }, (p.description || '').slice(0, 60))
        ]),
        el('div', {
          style: { fontSize: '13px', color: 'var(--accent)', fontWeight: 'bold', whiteSpace: 'nowrap' }
        }, store.formatPriceIn(p.price, store.getCurrentCurrencyCode()))
      ]);
      dropdown.appendChild(row);
    });
    dropdown.style.display = 'block';
  }

  /* ====================================================================
   * ★ Phase 6 Batch 1c (Task 50): renderStorefrontSections()
   * Renders the 5 new section types (promo_banner, cta_block, image_spot,
   * text_block, spacer) ABOVE the product grid on /morcenzs. The 4 base
   * types (hero, about, featured, footer) stay on / only — they're filtered
   * out here by checking section_type.
   * Reuses the same per-type renderers as js/landing.js (the renderers
   * are global on global.MorbiLanding via the renderSectionByType
   * dispatcher — but those renderers live inside the landing IIFE; the
   * cleanest approach is to duplicate the small renderers here since the
   * storefront needs slightly different CSS classes for some types
   * (e.g. narrower promo banner). Duplicating ~80 lines of renderers is
   * simpler than refactoring the landing.js IIFE into a shared module.
   * ==================================================================== */
  function renderStorefrontSections() {
    var sections = store.getSectionsPublic();
    if (!sections || sections.length === 0) return null;

    // Filter to the 5 storefront-applicable types + sort by sort_order.
    var applicable = sections.filter(function (s) {
      return s.section_type === 'promo_banner'
        || s.section_type === 'cta_block'
        || s.section_type === 'image_spot'
        || s.section_type === 'text_block'
        || s.section_type === 'spacer';
    }).sort(function (a, b) {
      return (a.sort_order || 0) - (b.sort_order || 0);
    });
    if (applicable.length === 0) return null;

    var nodes = applicable.map(function (s) {
      switch (s.section_type) {
        case 'promo_banner': return renderStorefrontPromoBanner(s);
        case 'cta_block':   return renderStorefrontCtaBlock(s);
        case 'image_spot':  return renderStorefrontImageSpot(s);
        case 'text_block':  return renderStorefrontTextBlock(s);
        case 'spacer':      return renderStorefrontSpacer(s);
        default: return null;
      }
    }).filter(Boolean);

    if (nodes.length === 0) return null;
    return el('div', { class: 'storefront-sections' }, nodes);
  }

  function renderStorefrontPromoBanner(s) {
    var c = s.content || {};
    var text = c.text || '';
    var linkUrl = c.link_url || '';
    var accent = c.accent_color || '';
    var style = {};
    // ★ Task 54: inline editing on the promo banner text.
    var isAdmin = store && typeof store.isAdmin === 'function' && store.isAdmin();
    var editAttrs = (isAdmin && text) ? { contenteditable: 'true', 'data-section-id': String(s.id), 'data-field': 'text' } : {};
    if (accent) {
      style.background = accent;
      var m = /^#([0-9a-fA-F]{2})([0-9a-fA-F]{2})([0-9a-fA-F]{2})$/.exec(accent);
      if (m) {
        var r = parseInt(m[1], 16), g = parseInt(m[2], 16), b = parseInt(m[3], 16);
        var luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
        style.color = luminance > 0.5 ? '#000000' : '#ffffff';
      }
    }
    var body;
    if (linkUrl) {
      var isExternal = /^https?:\/\//i.test(linkUrl);
      body = el('a', Object.assign({
        href: linkUrl, class: 'promo-banner-link' + (isAdmin ? ' admin-editable' : ''), style: style,
        target: isExternal ? '_blank' : undefined,
        rel: isExternal ? 'noopener' : undefined,
        // ★ Task 56 (BL-2 fix): when admin is logged in, disable the link's
        //   onclick so clicking to edit text doesn't navigate away.
        onclick: isAdmin ? function (e) { e.preventDefault(); } : (isExternal ? undefined : function (e) { e.preventDefault(); router.navigate(linkUrl); })
      }, editAttrs), text);
    } else {
      body = el('div', { class: 'promo-banner-text', style: style }, text);
    }
    return el('section', { class: 'promo-banner storefront-promo-banner' }, [body]);
  }

  function renderStorefrontCtaBlock(s) {
    var c = s.content || {};
    var heading = c.heading || '';
    var body = c.body || '';
    var buttonText = c.button_text || '';
    var buttonUrl = c.button_url || '';
    var isExternal = /^https?:\/\//i.test(buttonUrl);
    // ★ Task 55: inline editing.
    var admin = store && typeof store.isAdmin === 'function' && store.isAdmin();
    var eClass = admin ? ' admin-editable' : '';
    var hAttrs = admin ? { contenteditable: 'true', 'data-section-id': String(s.id), 'data-field': 'heading' } : {};
    var bAttrs = admin ? { contenteditable: 'true', 'data-section-id': String(s.id), 'data-field': 'body' } : {};
    var btnAttrs = admin ? { contenteditable: 'true', 'data-section-id': String(s.id), 'data-field': 'button_text' } : {};
    return el('section', { class: 'cta-block storefront-cta-block' }, [
      heading ? el('h2', Object.assign({ class: 'cta-block-heading serif' + eClass }, hAttrs), heading) : null,
      body ? el('p', Object.assign({ class: 'cta-block-body' + eClass }, bAttrs), body) : null,
      buttonText ? el('button', Object.assign({
        class: 'btn-md fill cta-block-button' + eClass,
        // ★ Task 56 (BL-1 fix): when admin is logged in, disable the
        //   button's onclick so clicking to edit text doesn't navigate away.
        onclick: admin ? undefined : function () {
          if (isExternal) window.open(buttonUrl, '_blank', 'noopener');
          else if (buttonUrl) router.navigate(buttonUrl);
        }
      }, btnAttrs), buttonText) : null
    ]);
  }

  function renderStorefrontImageSpot(s) {
    var c = s.content || {};
    // ★ Phase 10 (2026-09-26): resolve image path against basePath (same fix as renderProductGrid).
    var rawImagePath = c.image_path || '';
    var imagePath = (store.resolveImagePath && rawImagePath) ? store.resolveImagePath(rawImagePath) : rawImagePath;
    var caption = c.caption || '';
    var linkUrl = c.link_url || '';
    var isExternal = /^https?:\/\//i.test(linkUrl);
    var img;
    if (imagePath) {
      img = document.createElement('img');
      img.src = imagePath;
      img.alt = caption || '';
      img.loading = 'lazy';
      img.style.cssText = 'width:100%;max-height:480px;object-fit:cover;display:block;border-radius:8px;';
      img.onerror = function () {
        var fallback = document.createElement('div');
        fallback.style.cssText = 'width:100%;height:280px;background:linear-gradient(135deg, #1a1a1a, #222222);display:flex;align-items:center;justify-content:center;border-radius:8px;';
        var icon = document.createElement('i');
        icon.className = 'fas fa-image';
        icon.style.cssText = 'font-size:48px;color:#555;';
        fallback.appendChild(icon);
        if (img.parentNode) img.parentNode.replaceChild(fallback, img);
      };
    } else {
      img = el('div', {
        style: { width: '100%', height: '280px', background: 'linear-gradient(135deg, #1a1a1a, #222222)', display: 'flex', alignItems: 'center', justifyContent: 'center', borderRadius: '8px' }
      }, [el('i', { class: 'fas fa-image', style: { fontSize: '48px', color: '#555' } })]);
    }
    var inner = [img];
    // ★ Task 55: inline editing on caption.
    var sfAdmin = store && typeof store.isAdmin === 'function' && store.isAdmin();
    var sfCapAttrs = sfAdmin ? { contenteditable: 'true', 'data-section-id': String(s.id), 'data-field': 'caption' } : {};
    if (caption) inner.push(el('p', Object.assign({ class: 'image-spot-caption' + (sfAdmin ? ' admin-editable' : '') }, sfCapAttrs), caption));
    if (linkUrl) {
      return el('section', { class: 'image-spot storefront-image-spot' }, [
        el('a', {
          href: linkUrl, class: 'image-spot-link',
          target: isExternal ? '_blank' : undefined,
          rel: isExternal ? 'noopener' : undefined,
          onclick: isExternal ? undefined : function (e) { e.preventDefault(); router.navigate(linkUrl); }
        }, inner)
      ]);
    }
    return el('section', { class: 'image-spot storefront-image-spot' }, inner);
  }

  function renderStorefrontTextBlock(s) {
    var c = s.content || {};
    var heading = c.heading || '';
    var body = c.body || '';
    // ★ Task 55: inline editing on heading + body.
    var admin2 = store && typeof store.isAdmin === 'function' && store.isAdmin();
    var eClass2 = admin2 ? ' admin-editable' : '';
    var hAttrs2 = admin2 ? { contenteditable: 'true', 'data-section-id': String(s.id), 'data-field': 'heading' } : {};
    var bodyEl2 = body ? (function () {
      var e = renderStorefrontTextBlockBody(body);
      if (admin2) {
        e.setAttribute('contenteditable', 'true');
        e.setAttribute('data-section-id', String(s.id));
        e.setAttribute('data-field', 'body');
        e.classList.add('admin-editable');
      }
      return e;
    })() : null;
    return el('section', { class: 'text-block storefront-text-block' }, [
      heading ? el('h2', Object.assign({ class: 'text-block-heading serif' + eClass2 }, hAttrs2), heading) : null,
      bodyEl2
    ]);
  }

  function renderStorefrontTextBlockBody(body) {
    var paragraphs = String(body).split(/\n\s*\n/);
    if (paragraphs.length <= 1) {
      return el('p', { class: 'text-block-body' }, body);
    }
    return el('div', { class: 'text-block-body' },
      paragraphs.map(function (p) {
        return el('p', {}, p.replace(/\s+/g, ' ').trim());
      })
    );
  }

  function renderStorefrontSpacer(s) {
    var c = s.content || {};
    var height = parseInt(c.height, 10);
    if (isNaN(height) || height < 1) height = 40;
    if (height > 200) height = 200;
    return el('section', {
      class: 'spacer storefront-spacer',
      style: { height: height + 'px' },
      'aria-hidden': 'true'
    });
  }
  /* ===== End of Phase 6 Batch 1c storefront sections ==================== */

  /* ---- Category filter bar ------------------------------------------- */
  // FIX-UX-7: Show product count per category

  // ★ WF-12 fix: third parameter `fullList` — the TRUE unfiltered product
  //   array. The "All (N)" badge is computed from it so the count is the
  //   store's real size regardless of the active scent gate. The per-
  //   category counts still come from `allProducts` (the scent-filtered
  //   subset passed by doRender — the UX-11 rule that category counts must
  //   match what the grid can actually show). Parameter named `allProducts`
  //   for the filtered list is historical (FIX-UX-7 era); kept to avoid
  //   touching every call site — the third arg is the authoritative total.
  function renderCategoryBar(categories, allProducts, fullList) {
    var allCount = (fullList && fullList.length) ? fullList.length : allProducts.length;
    var items = [el('li', {}, [
      el('button', {
        class: 'nav-item' + (activeCategory === 'all' ? ' active' : ''),
        onclick: function () { activeCategory = 'all'; refreshView(); }
      }, 'All (' + allCount + ')')
    ])];

    // FIX-BL-15: Sort categories by sortOrder
    var sorted = categories.slice().sort(function (a, b) {
      return (a.sortOrder || 0) - (b.sortOrder || 0);
    });

    sorted.forEach(function (cat) {
      var count = allProducts.filter(function (p) { return p.categoryId === cat.id; }).length;
      items.push(el('li', {}, [
        el('button', {
          class: 'nav-item' + (activeCategory === cat.id ? ' active' : ''),
          onclick: function () { activeCategory = cat.id; refreshView(); }
        }, cat.name + ' (' + count + ')')
      ]));
    });

    return el('nav', { class: 'category' }, [el('ul', { class: 'nav-links category' }, items)]);
  }

  function refreshView() {
    // ★ WF-03 fix: refreshView() is the single funnel every cart mutation
    //   flows through (addToCart / updateQty / removeFromCart all end
    //   here) — mirroring the cart to sessionStorage at this one point
    //   keeps storage in sync with every add/qty-change/removal without
    //   touching each handler.
    //   ★ PERF-05 note (Task 45): refreshView() is now used ONLY by the
    //   category-bar clicks (two sites below in renderCategoryBar) — the
    //   paths that genuinely change the product grid and need a full
    //   doRender(). The cart mutations (addToCart / updateQty /
    //   removeFromCart) moved to refreshCartUI(), which updates ONLY the
    //   cart-dependent UI instead of destroying + rebuilding ~150 DOM
    //   nodes (whole header + category bar + every product card) per click.
    persistCart();
    var products = store.getAvailableProducts();
    var categories = store.getCategories();
    var currency = store.getCurrency();
    doRender(products, categories, currency);
  }

  /* ---- PERF-05 (Task 45): targeted cart refresh ---------------------- *
   * refreshCartUI(affectedProductIds) replaces the old
   * refreshView()-on-every-mutation flow for ADD / QTY / REMOVE. The old
   * path ran a full doRender() per click: ~150+ DOM nodes destroyed and
   * recreated (~80-120 ms of main-thread layout/paint on a mid-tier
   * phone), piling up under rapid "+" taps. A cart mutation only changes:
   *   1. the desktop cart sidebar (.order-list),
   *   2. the mobile cart popup content (#cart-popup children),
   *   3. the FAB badge (#cart-fab / #cart-fab-badge),
   *   4. the affected product card's add button (✓/active state),
   * so only those four spots are touched here — O(1)-ish DOM work instead
   * of O(catalog). persistCart() runs first, preserving the WF-03 funnel
   * contract (storage stays in sync with every mutation).
   *
   * deliberately NOT touched (and why it's safe):
   *   - the checkout modal: it is a full-screen overlay while open, so no
   *     cart mutation can happen underneath it; openCheckout() re-renders
   *     its content on every open anyway (RT-12).
   *   - the Escape-key handler: document-level, survives partial updates
   *     (bindGlobalKeys is only re-run by full renders).
   *   - the #cart-error toast: it now SURVIVES mutations (the old full
   *     re-render replaced the node mid-display) — strictly better.
   *   - scroll position: the grid is untouched, so nothing scrolls.
   */
  function refreshCartUI(affectedProductIds) {
    persistCart();
    var currency = store.getCurrency();
    var root = document.getElementById(ROOT_ID);

    // 1. Desktop cart sidebar — swap the subtree, keep the wrapper.
    var orderWrap = root ? root.querySelector('.main-body .order') : null;
    if (orderWrap) {
      clear(orderWrap);
      orderWrap.appendChild(renderCartSidebar(currency));
    }

    // 2. Mobile cart popup — swap children only. The popup's .open class
    //    lives on the popup element itself, so an open sheet stays open
    //    (addToCart's UX-13 toggle below re-opens it where wanted).
    var popup = document.getElementById('cart-popup');
    if (popup) {
      clear(popup);
      renderCartPopupContent(currency).forEach(function (node) {
        popup.appendChild(node);
      });
    }

    // 3. FAB badge.
    updateCartFAB();

    // 4. Product-card add-button state (✓/+) for each affected product.
    (affectedProductIds || []).forEach(syncProductCardButton);
  }

  // PERF-05 companion: flip ONE product card's add button to match the cart
  // (a card shows ✓/active when ANY cart line references the product —
  // e.g. two variant lines of the same perfume, mirroring renderProductGrid's
  // `cart.find(c => c.id === p.id)` rule). No-ops when the card is absent
  // (product not in the current scent/category view) or the button is the
  // out-of-stock disabled variant (which carries no data-id).
  function syncProductCardButton(productId) {
    var root = document.getElementById(ROOT_ID);
    if (!root) return;
    var card = root.querySelector('.menu[data-id="' + productId + '"]');
    if (!card) return;
    var btn = card.querySelector('button.card-add-btn[data-id]');
    if (!btn) return;
    var inCart = cart.some(function (c) { return c.id === productId; });
    btn.className = 'card-add-btn' + (inCart ? ' active' : '');
    btn.textContent = inCart ? '\u2713' : '+';
  }

  /* ---- Product grid -------------------------------------------------- */

  function renderProductGrid(products, currency) {
    if (!products.length) {
      return el('div', { class: 'storefront-empty' }, [
        el('i', { class: 'fas fa-flask' }),
        el('h3', {}, 'No products in this category'),
        el('p', {}, 'Try selecting a different category or check back soon.')
      ]);
    }
    return el('div', { class: 'menus' }, products.map(function (p) {
      var inCart = cart.find(function (c) { return c.id === p.id; });
      var cat = p.categoryId ? store.getCategory(p.categoryId) : null;
      // ★ Phase 10 (2026-09-26): resolve the image path against the app's
      //   basePath so it works under clean-path routing (/morbi-shop/morcenzs).
      //   Was: `p.imagePath` used directly → browser resolved it relative to
      //   the current URL → 404 → flask-icon placeholder showed.
      var resolvedImagePath = store.resolveImagePath ? store.resolveImagePath(p.imagePath) : p.imagePath;
      var imgContent = resolvedImagePath
        ? el('img', { src: resolvedImagePath, alt: p.name, loading: 'lazy' })
        : el('div', {
            style: {
              width: '100%', height: '100%',
              background: 'linear-gradient(135deg, #1a1a1a, #222222)',
              display: 'flex', alignItems: 'center', justifyContent: 'center'
            }
          }, [el('i', { class: 'fas fa-flask', style: { fontSize: '48px', color: '#333' } })]);
      // FIX-WF-7: onerror fallback for broken images
      if (p.imagePath) {
        imgContent.addEventListener('error', function () {
          var parent = this.parentNode;
          if (!parent) return;
          var fallback = document.createElement('div');
          fallback.style.cssText = 'width:100%;height:100%;background:linear-gradient(135deg,#1a1a1a,#222222);display:flex;align-items:center;justify-content:center;';
          var icon = document.createElement('i');
          icon.className = 'fas fa-flask';
          icon.style.cssText = 'font-size:48px;color:#333;';
          fallback.appendChild(icon);
          parent.replaceChild(fallback, this);
        });
      }

      // ★ Phase 5 Batch 3: if the product has variants, render a variant
      // selector (dropdown). The "price" shown is the product's base price;
      // the variant price is shown when the user selects a variant.
      var hasVariants = p.variants && p.variants.length > 0;
      var variantSelector = hasVariants
        ? el('div', { class: 'variant-selector' }, [
            el('select', {
              id: 'variant-select-' + p.id,
              class: 'variant-select',
              onchange: function () { updateVariantPrice(p.id, currency); }
            }, [
              el('option', { value: '' }, 'Select size/option…')
            ].concat(p.variants.map(function (v) {
              var label = v.name + ' — ' + store.formatPriceIn(v.price, store.getCurrentCurrencyCode());
              if (v.stock !== null && v.stock === 0) label += ' (Out of stock)';
              return el('option', { value: String(v.id), disabled: (v.stock !== null && v.stock === 0) }, label);
            })))
          ])
        : null;

      // ★ Phase 5 Batch 3: price element gets an id so the variant selector
      // can update it when the user picks a variant.
      var priceEl = el('p', { class: 'card-price', id: 'price-' + p.id }, store.formatPriceIn(p.price, store.getCurrentCurrencyCode()));

      return el('div', { class: 'menu', dataset: { id: p.id } }, [
        el('div', { style: { width: '100%', height: '280px', overflow: 'hidden' } }, [imgContent]),
        el('div', { class: 'desc-item' }, [
          el('h3', { class: 'card-name' }, p.name),
          p.scent ? el('p', { class: 'card-scent' }, p.scent) : null,
          cat ? el('p', { class: 'small', style: { color: 'var(--muted, #a0a0a0)' } }, cat.name) : null,
          el('p', { class: 'card-desc' }, p.description || ''),
          // ★ Phase 5 Batch 3: variant selector (only if product has variants)
          variantSelector,
          // ★ Phase 3 Batch 4: stock badge + disable Add to Cart when stock === 0.
          // If product has variants, the stock badge is per-variant (shown via JS
          // when the user selects a variant). If no variants, show product-level stock.
          (!hasVariants && p.stock !== null && p.stock !== undefined && p.stock === 0)
            ? el('p', { class: 'card-stock-badge out-of-stock' }, 'Out of stock')
            : null,
          // ★ Phase 9 Batch 3 (Task 63): "Notify me" form for out-of-stock
          //   products (no variants — variant-level restock is a future
          //   enhancement). Shows an email input + submit button. The form
          //   calls api/stock-alerts.php (public POST). On success, replaces
          //   the form with a "You're on the list!" confirmation message.
          (!hasVariants && p.stock !== null && p.stock !== undefined && p.stock === 0)
            ? el('div', {
                class: 'restock-alert-form',
                id: 'restock-form-' + p.id,
                style: { marginTop: '8px' }
              }, [
                el('input', {
                  type: 'email',
                  id: 'restock-email-' + p.id,
                  placeholder: 'Email me when back',
                  style: {
                    width: '100%', padding: '6px 8px', fontSize: '13px',
                    border: '1px solid #333', borderRadius: '4px',
                    background: '#1a1a1a', color: '#fff',
                    marginBottom: '4px', boxSizing: 'border-box'
                  },
                  onkeydown: function (ev) {
                    // Enter key submits the form.
                    if (ev.key === 'Enter' || ev.keyCode === 13) {
                      ev.preventDefault();
                      handleRestockSignup(p.id, null);
                    }
                  }
                }),
                el('button', {
                  class: 'btn-sm',
                  style: {
                    width: '100%', padding: '6px 8px', fontSize: '13px',
                    background: 'var(--accent, #FFAA00)', color: '#000',
                    border: 'none', borderRadius: '4px', cursor: 'pointer'
                  },
                  onclick: function () { handleRestockSignup(p.id, null); }
                }, [el('i', { class: 'fas fa-bell', style: { marginRight: '4px' } }), 'Notify me'])
              ])
            : null,
          el('div', { style: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: '4px' } }, [
            priceEl,
            el('div', { style: { display: 'flex', gap: '4px', alignItems: 'center' } }, [
              // ★ Phase 9 Batch 5 (Task 64): wishlist heart button.
              //   Toggles the product in the anonymous localStorage wishlist.
              //   The icon switches between far fa-heart (outline, not saved)
              //   and fas fa-heart (filled, saved). The toggle is optimistic
              //   — the icon updates immediately + the morbi:wishlist event
              //   triggers a header count badge refresh.
              (function () {
                var inWishlist = global.MorbiWishlist && global.MorbiWishlist.isInWishlist(p.id, null);
                var heartBtn = el('button', {
                  class: 'card-wishlist-btn',
                  style: {
                    background: 'none', border: 'none', cursor: 'pointer',
                    padding: '4px', fontSize: '16px', lineHeight: '1',
                    color: inWishlist ? '#dc2626' : 'var(--muted, #a0a0a0)',
                    transition: 'color 0.15s'
                  },
                  'aria-label': (inWishlist ? 'Remove from' : 'Add to') + ' wishlist',
                  title: (inWishlist ? 'Remove from' : 'Add to') + ' wishlist',
                  onclick: function (ev) {
                    ev.preventDefault();
                    ev.stopPropagation();
                    if (!global.MorbiWishlist) return;
                    var result = global.MorbiWishlist.toggleWishlist(p.id, null);
                    // Optimistic UI — toggle color between grey (not saved)
                    // and red (saved). Uses fas fa-heart for both states
                    // (the PERF-08 subset doesn't load the regular font,
                    // so far fa-heart wouldn't render).
                    heartBtn.style.color = result.inWishlist ? '#dc2626' : 'var(--muted, #a0a0a0)';
                    heartBtn.setAttribute('aria-label', (result.inWishlist ? 'Remove from' : 'Add to') + ' wishlist');
                    heartBtn.title = (result.inWishlist ? 'Remove from' : 'Add to') + ' wishlist';
                  }
                }, [el('i', { class: 'fas fa-heart' })]);
                return heartBtn;
              })(),
              // Add-to-cart button (existing — unchanged).
              (!hasVariants && p.stock !== null && p.stock !== undefined && p.stock === 0)
                ? el('button', {
                    class: 'card-add-btn',
                    // ★ Phase 10 (2026-09-26): added explicit type="button" so
                    //   the button can never accidentally become a submit
                    //   button if a future refactor wraps the storefront in
                    //   a <form>. The button is intentionally disabled on
                    //   out-of-stock products.
                    type: 'button',
                    disabled: true,
                    style: { opacity: '0.4', cursor: 'not-allowed' },
                    // ★ Phase 10 (2026-09-26): improved aria-label — was just
                    //   "X is out of stock" but the button shows "—" which is
                    //   cryptic to screen readers. Now: "X is out of stock,
                    //   button disabled" so the assistive-tech user understands
                    //   both the state AND that it's not clickable.
                    'aria-label': p.name + ' is out of stock — button disabled',
                    title: p.name + ' is out of stock'
                  }, '—')
                : el('button', {
                    class: 'card-add-btn' + (inCart ? ' active' : ''),
                    // ★ Phase 10 (2026-09-26): added id + type="button" so
                    //   updateVariantPrice() can target this button to
                    //   disable it when the user selects an out-of-stock
                    //   variant (instead of waiting until addToCart flashes
                    //   an error after the click).
                    id: 'card-add-btn-' + p.id,
                    type: 'button',
                    dataset: { id: p.id },
                    'aria-label': 'Add ' + p.name + ' to cart',
                    onclick: function () { addToCart(p.id); }
                  }, inCart ? '\u2713' : '+')
            ])
          ])
        ])
      ]);
    }));
  }

  /* ★ Phase 9 Batch 3 (Task 63): handle restock-alert signup form submission.
   *   Reads the email from #restock-email-{productId}, POSTs to
   *   api/stock-alerts.php (public, no auth). On success, replaces the form
   *   with a confirmation message. On error (invalid email, network failure),
   *   shows the error inline + keeps the form so the customer can retry.
   *
   *   Anti-enumeration: the server always returns 200 {signed_up: true}
   *   even for duplicate signups — the `new` field lets us show a slightly
   *   different message ("You're already on the list" vs "You're on the list"),
   *   but the UX is the same.
   */
  function handleRestockSignup(productId, variantId) {
    var emailInput = document.getElementById('restock-email-' + productId);
    if (!emailInput) return;
    var email = emailInput.value.trim();
    if (!email) {
      showStorefrontToast('Please enter your email address.', true);
      return;
    }
    // Basic client-side email validation (server also validates — defense in depth).
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      showStorefrontToast('Please enter a valid email address.', true);
      return;
    }

    // Replace the form with a "Signing you up…" message to give immediate feedback.
    // ★ Phase 10 (2026-09-26): was `form.innerHTML = ''` — switched to clear()
    //   for consistency with the rest of the file (and to allow future clear()
    //   hooks like teardown of any listeners attached to children).
    var form = document.getElementById('restock-form-' + productId);
    if (form) {
      clear(form);
      form.appendChild(el('p', {
        style: { fontSize: '13px', color: 'var(--muted, #a0a0a0)', textAlign: 'center', padding: '8px' }
      }, 'Signing you up…'));
    }

    fetch('api/stock-alerts.php', {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        product_id: productId,
        variant_id: variantId || undefined,
        email: email
      })
      // ★ Phase 10 (2026-09-26): was `.then(function (res) { return res.json(); })`
      //   — if the server returned an HTML error page (500, 502, maintenance
      //   page), res.json() threw "Unexpected token <" and the .catch
      //   surfaced that opaque message to the customer. Now reads as text
      //   first, then attempts JSON.parse — same pattern store.api() uses.
    }).then(function (res) {
      return res.text().then(function (text) {
        var json = null;
        try { json = text ? JSON.parse(text) : null; } catch (e) { json = null; }
        if (!res.ok || !json || json.ok !== true) {
          var message = (json && json.error) || ('Signup failed (HTTP ' + res.status + ').');
          var err = new Error(message);
          err.status = res.status;
          throw err;
        }
        return json;
      });
    }).then(function (data) {
      if (!data.ok) {
        throw new Error(data.error || 'Signup failed.');
      }
      // Replace the form with a confirmation message.
      if (form) {
        clear(form);
        var msg = data.new
          ? "You're on the list! We'll email you when it's back."
          : "You're already on the list — we'll email you when it's back.";
        form.appendChild(el('p', {
          style: {
            fontSize: '13px', color: 'var(--accent, #FFAA00)', textAlign: 'center',
            padding: '8px', background: 'rgba(255,170,0,0.1)', borderRadius: '4px'
          }
        }, [el('i', { class: 'fas fa-check', style: { marginRight: '4px' } }), msg]));
      }
    }).catch(function (err) {
      // Restore the form so the customer can retry.
      if (form) {
        clear(form);
        form.appendChild(el('input', {
          type: 'email',
          id: 'restock-email-' + productId,
          placeholder: 'Email me when back',
          value: email,  // keep what they typed
          style: {
            width: '100%', padding: '6px 8px', fontSize: '13px',
            border: '1px solid #dc2626', borderRadius: '4px',
            background: '#1a1a1a', color: '#fff',
            marginBottom: '4px', boxSizing: 'border-box'
          },
          onkeydown: function (ev) {
            if (ev.key === 'Enter' || ev.keyCode === 13) {
              ev.preventDefault();
              handleRestockSignup(productId, variantId);
            }
          }
        }));
        form.appendChild(el('button', {
          class: 'btn-sm',
          style: {
            width: '100%', padding: '6px 8px', fontSize: '13px',
            background: 'var(--accent, #FFAA00)', color: '#000',
            border: 'none', borderRadius: '4px', cursor: 'pointer'
          },
          onclick: function () { handleRestockSignup(productId, variantId); }
        }, [el('i', { class: 'fas fa-bell', style: { marginRight: '4px' } }), 'Notify me']));
      }
      showStorefrontToast(err.message || 'Signup failed. Please try again.', true);
    });
  }

  /* ---- Cart logic ---------------------------------------------------- */

  // ★ Phase 5 Batch 3: update the price display when the user selects a variant.
  function updateVariantPrice(productId, currency) {
    var selectEl = document.getElementById('variant-select-' + productId);
    var priceEl = document.getElementById('price-' + productId);
    // ★ Phase 10 (2026-09-26): also target the Add-to-cart button so we can
    //   disable it when the user selects an out-of-stock variant. Was: the
    //   button stayed enabled and the customer only saw the error after
    //   clicking Add → flashCartError fired. Now the button visibly disables
    //   the moment the OOS variant is selected.
    var addBtn = document.getElementById('card-add-btn-' + productId);
    if (!selectEl || !priceEl) return;
    var product = store.getProduct(productId);
    if (!product || !product.variants) return;
    if (!selectEl.value) {
      // No variant selected → show base price + re-enable the Add button
      // (the product itself is in stock, otherwise the button would have
      // been rendered in the disabled-branch above).
      priceEl.textContent = store.formatPriceIn(product.price, store.getCurrentCurrencyCode());
      if (addBtn) {
        addBtn.disabled = false;
        addBtn.style.opacity = '';
        addBtn.style.cursor = '';
        addBtn.setAttribute('aria-label', 'Add ' + product.name + ' to cart');
      }
      return;
    }
    var variant = product.variants.find(function (v) { return String(v.id) === selectEl.value; });
    if (variant) {
      priceEl.textContent = store.formatPriceIn(variant.price, store.getCurrentCurrencyCode());
      // ★ Phase 10: disable the Add button if the selected variant is OOS.
      //   Variant stock === null means "unlimited" (parent product's stock
      //   applies — leave the button enabled). Variant stock === 0 means
      //   OOS → disable + style as not-allowed + update aria-label so
      //   screen readers announce the reason.
      if (addBtn) {
        var oos = (variant.stock !== null && variant.stock === 0);
        addBtn.disabled = oos;
        addBtn.style.opacity = oos ? '0.4' : '';
        addBtn.style.cursor = oos ? 'not-allowed' : '';
        // ★ Phase 10 (2026-09-26): fix unbalanced parens in the ternary —
        //   the `oos ?` branch opened a paren but the `:` branch didn't
        //   close it before the outer setAttribute call's closing paren.
        //   Now uses explicit String concatenation with matching parens.
        var ariaLabel = oos
          ? (product.name + ' (' + variant.name + ') is out of stock')
          : ('Add ' + product.name + ' (' + variant.name + ') to cart');
        addBtn.setAttribute('aria-label', ariaLabel);
      }
    }
  }

  function addToCart(productId) {
    var product = store.getProduct(productId);
    if (!product) return;
    // ★ Phase 3 Batch 4: defense in depth — the Add to Cart button is
    // disabled when stock === 0, but a malicious user could call addToCart
    // via devtools. The server's payments.php also checks stock, so this
    // is the second line of defense (UI + client-side store).
    if (product.stock !== null && product.stock !== undefined && product.stock === 0) {
      flashCartError('"' + product.name + '" is out of stock.');
      return;
    }

    // ★ Phase 5 Batch 3: if the product has variants, the customer must
    // select one. The selected variant is stored in a data attribute on the
    // product card's add button. If no variant is selected, flash an error.
    var selectedVariantId = 0;
    var selectedVariantName = '';
    var variantPrice = product.price;
    if (product.variants && product.variants.length > 0) {
      var selectEl = document.getElementById('variant-select-' + product.id);
      if (!selectEl || !selectEl.value) {
        flashCartError('Please select a size/option for "' + product.name + '".');
        return;
      }
      selectedVariantId = parseInt(selectEl.value, 10);
      var variant = product.variants.find(function (v) { return v.id === selectedVariantId; });
      if (!variant) {
        flashCartError('Please select a valid option for "' + product.name + '".');
        return;
      }
      if (variant.stock !== null && variant.stock === 0) {
        flashCartError('"' + variant.name + '" is out of stock.');
        return;
      }
      selectedVariantName = variant.name;
      variantPrice = variant.price;
    }

    // Cart key includes variantId so the same product in different sizes
    // are separate cart items (e.g. "Oud Royale 50ml" vs "Oud Royale 100ml").
    var cartKey = product.id + '-' + selectedVariantId;
    var existing = cart.find(function (c) { return c.key === cartKey; });
    if (existing) {
      // ★ Phase 3 Batch 4: don't exceed available stock when tracked.
      // ★ BL-14 BLIND-SPOT fix (client-side mirror of the server-side fix
      //   in payments.php line 186-191): when the variant's stock is NULL
      //   (the "unlimited" convention), fall back to the parent product's
      //   stock — otherwise the customer could click "Add to cart" past
      //   the product's stock cap without any error until checkout refused
      //   the order. The previous ternary returned `variant.stock || undefined`
      //   which made the `if (stockLimit !== null && stockLimit !== undefined)`
      //   check skip → no enforcement → oversell against product.stock.
      //   Now: if the variant has an explicit stock, use it; otherwise fall
      //   back to product.stock (which may itself be null = unlimited).
      var variantStockLimit = null;
      if (product.variants && product.variants.length > 0 && selectedVariantId) {
        var matchedV = product.variants.find(function (v) { return v.id === selectedVariantId; });
        if (matchedV && matchedV.stock !== null && matchedV.stock !== undefined) {
          variantStockLimit = matchedV.stock;
        }
      }
      var stockLimit = (variantStockLimit !== null)
        ? variantStockLimit
        : product.stock;
      if (stockLimit !== null && stockLimit !== undefined && existing.qty >= stockLimit) {
        flashCartError('Only ' + stockLimit + ' of this item are available.');
        return;
      }
      if (existing.qty < MAX_QTY) existing.qty++;
    } else {
      cart.push({
        key: cartKey,
        id: product.id,
        variantId: selectedVariantId,
        variantName: selectedVariantName,
        name: product.name,
        scent: product.scent || '',
        price: variantPrice,
        qty: 1,
        // ★ Phase 10 (2026-09-26): resolve image path against basePath so the cart popup thumbnail renders correctly under clean-path routing.
        imagePath: (store.resolveImagePath && product.imagePath) ? store.resolveImagePath(product.imagePath) : (product.imagePath || '')
      });
    }
    refreshCartUI([product.id]);  // ★ PERF-05: was refreshView() — full DOM rebuild
    // FIX-UX-5: Auto-open mobile cart bottom sheet when item is added on mobile
    // ★ UX-13 fix: only when the user hasn't recently dismissed the popup.
    //   The old unconditional toggle re-opened the sheet on EVERY add —
    //   close it, add a different product 10 seconds later, and it popped
    //   right back up, interrupting the browse flow once per item. Now a
    //   dismissal arms a 30s suppression window (set in toggleMobileCart).
    if (window.innerWidth < 900 && Date.now() >= mobileCartSuppressedUntil) {
      toggleMobileCart(true);
    }
  }

  function updateQty(cartKey, delta) {
    var item = cart.find(function (c) { return c.key === cartKey; });
    if (!item) return;

    // ★ BL-09 fix: enforce per-item stock limit on the "+" button (delta = +1).
    //   Previously, updateQty only clamped to MAX_QTY (99) — the stock check
    //   lived ONLY in addToCart (line 498-507). A customer who added 1 of a
    //   3-stock item could click "+" twice to reach qty=3, then click "+"
    //   again to reach qty=4, 5, …, 99 — all without any "Only 3 available"
    //   message. The server's payments.php (line 167-175) catches the
    //   oversell at checkout, but by then the user has filled out the
    //   entire checkout form, applied discounts, and clicked "Pay with
    //   Paystack" before being told the cart was invalid.
    //   Fix: when delta > 0 (the "+" path), look up the matching product +
    //   variant from store state to get the stockLimit, then refuse the
    //   increment if item.qty + delta would exceed it. Mirror addToCart's
    //   flashCartError message so the UX is consistent.
    // ★ BL-14 BLIND-SPOT fix (client-side mirror of the server-side fix in
    //   payments.php): when the variant's stock is NULL (the "unlimited"
    //   convention), fall back to the parent product's stock — otherwise
    //   the "+" button would let the customer inflate the cart past
    //   product.stock without any error until checkout refused the order
    //   (the exact UX failure BL-09 was filed against).
    if (delta > 0) {
      var product = (store.getProducts && store.getProducts())
        ? store.getProducts().find(function (p) { return p.id === item.id; })
        : null;
      if (product) {
        var stockLimit = null;
        // First, try the variant's explicit stock.
        if (item.variantId && product.variants && product.variants.length > 0) {
          var v = product.variants.find(function (vv) { return vv.id === item.variantId; });
          if (v && v.stock !== null && v.stock !== undefined) {
            stockLimit = v.stock;
          }
        }
        // ★ BL-14 BLIND-SPOT: if variant.stock was NULL/undefined (or the
        //   variant was deleted since add-to-cart and product.variants is
        //   now empty), fall back to product.stock. May itself be null =
        //   unlimited (no enforcement).
        if (stockLimit === null) {
          stockLimit = product.stock;
        }
        if (stockLimit !== null && stockLimit !== undefined && item.qty + delta > stockLimit) {
          flashCartError('Only ' + stockLimit + ' of this item are available.');
          return;  // refuse the increment — don't refresh
        }
      }
      // If product lookup failed (store not yet hydrated, or product was
      // deleted since add-to-cart), fall through to the MAX_QTY clamp below
      // — the server-side check in payments.php still catches oversell at
      // checkout as defense in depth.
    }

    item.qty += delta;
    // FIX-BL-17: Enforce maximum quantity
    if (item.qty > MAX_QTY) item.qty = MAX_QTY;
    if (item.qty <= 0) {
      cart = cart.filter(function (c) { return c.key !== cartKey; });
    }
    refreshCartUI([item.id]);  // ★ PERF-05: was refreshView() — full DOM rebuild
  }

  function removeFromCart(cartKey) {
    // ★ PERF-05: capture the product id BEFORE filtering (the row is about
    //   to be gone) so the card's ✓/active state can be flipped back to "+".
    var removed = cart.find(function (c) { return c.key === cartKey; });
    cart = cart.filter(function (c) { return c.key !== cartKey; });
    refreshCartUI(removed ? [removed.id] : []);
  }

  // FIX-BL-11: Use rounded arithmetic to avoid floating point errors
  function cartTotal() {
    var total = 0;
    for (var i = 0; i < cart.length; i++) {
      // ★ L6 fix (audit): don't round each line — sum raw then round once at
      //   the end. Per-line rounding introduces cent-level drift for prices
      //   with >2 decimal places (possible after currency conversion math).
      total += cart[i].price * cart[i].qty;
    }
    return Math.round(total * 100) / 100;
  }

  function cartCount() {
    var sum = 0;
    for (var i = 0; i < cart.length; i++) { sum += cart[i].qty; }
    return sum;
  }

  /* ---- Cart sidebar (desktop) ---------------------------------------- */

  function renderCartSidebar(currency) {
    var count = cartCount();
    var total = cartTotal();
    var cartItems = cart.length
      ? cart.map(function (c) {
          return el('div', { class: 'order-item' }, [
            el('div', {}, [
              el('strong', {}, c.name + (c.variantName ? ' (' + c.variantName + ')' : '')),
              c.scent ? el('br') : null,
              c.scent ? el('span', { class: 'small' }, c.scent) : null
            ]),
            el('div', {}, [
              el('button', {
                class: 'btn-sm min',
                'aria-label': 'Decrease quantity',
                onclick: function () { updateQty(c.key, -1); }
              }),
              el('span', { class: 'price', style: { margin: '0 8px' } }, c.qty + ' x ' + store.formatPriceIn(c.price, store.getCurrentCurrencyCode())),
              el('button', {
                class: 'btn-sm max',
                'aria-label': 'Increase quantity',
                onclick: function () { updateQty(c.key, 1); }
              }),
              el('span', { class: 'remove', onclick: function () { removeFromCart(c.key); } }, [
                el('i', { class: 'fas fa-trash-alt' })
              ])
            ])
          ]);
        })
      : [el('div', { class: 'order-null' }, [
          el('i', { class: 'fas fa-shopping-bag' }),
          el('p', {}, 'Your cart is empty')
        ])];

    return el('div', { class: 'order-list' }, [
      el('h3', {}, 'Cart (' + count + ')'),
      el('div', { class: 'order-inner' }, cartItems),
      el('hr'),
      el('div', { class: 'checkout' }, [
        el('div', { class: 'checkout-detail', id: 'total' }, [
          el('h3', {}, 'Total'),
          el('h3', {}, store.formatPriceIn(total, store.getCurrentCurrencyCode()))
        ]),
        el('button', {
          class: 'btn-md fill', style: { width: '100%', marginTop: '12px' },
          disabled: count === 0,
          onclick: function () { openCheckout(); }
        }, 'Checkout')
      ])
    ]);
  }

  /* ---- Mobile cart popup --------------------------------------------- */

  function toggleMobileCart(open) {
    var overlay = document.getElementById('cart-overlay');
    var popup = document.getElementById('cart-popup');
    if (!overlay || !popup) return;
    if (open) {
      overlay.classList.add('open');
      popup.classList.add('open');
      // ★ UI-16 fix: lock body scroll when the cart popup opens. Without
      //   this, the underlying page (product grid) remains scrollable —
      //   touching the top 20% of the overlay (the dimmed area above the
      //   popup) scrolls the PAGE underneath, not the cart popup. The
      //   product grid slides visibly under the dark overlay, creating a
      //   parallax-like bleed-through effect. Fix: set `overflow: hidden`
      //   on <body> so the page can't scroll while the popup is open.
      //   Restore `overflow: ''` on close so the page scrolls normally.
      //   The empty string restores the CSS default (visible) rather than
      //   forcing a specific value — safer if the admin's Theme tab has
      //   set a custom body overflow.
      document.body.style.overflow = 'hidden';
      // ★ Phase 10 (2026-09-26): add a one-time resize listener so the
      //   cart popup auto-closes if the user resizes the window to >= 900px
      //   (desktop) while it's open. Was: the popup stayed open with body
      //   scroll locked even after resize — desktop users were confused
      //   why their scroll was disabled. The listener removes itself on
      //   first fire (one-shot) so we don't stack listeners across
      //   multiple open/close cycles.
      if (!global._morbiCartResizeWired) {
        global._morbiCartResizeWired = true;
        global.addEventListener('resize', function () {
          // Only act if the popup is currently open AND the viewport is
          // now desktop-sized. We could throttle this, but resize fires
          // at most a few times per second on most browsers — fine.
          var popupEl = document.getElementById('cart-popup');
          if (popupEl && popupEl.classList.contains('open') && global.innerWidth >= 900) {
            toggleMobileCart(false);
          }
        });
      }
    } else {
      overlay.classList.remove('open');
      popup.classList.remove('open');
      document.body.style.overflow = '';
      // ★ UX-13 fix: arm the 30s auto-open suppression window on every
      //   close (user tapped ×, tapped the overlay, pressed Escape, or
      //   continued to checkout). The next addToCart() within 30s will not
      //   re-open the sheet — the customer stays in their browsing flow.
      mobileCartSuppressedUntil = Date.now() + MOBILE_CART_SUPPRESS_MS;
    }
  }

  function updateCartFAB() {
    var fab = document.getElementById('cart-fab');
    var badge = document.getElementById('cart-fab-badge');
    if (!fab) return;
    var count = cartCount();
    if (count > 0) {
      fab.classList.add('show');
      if (badge) badge.textContent = String(count);
    } else {
      fab.classList.remove('show');
      if (badge) badge.textContent = '0';
    }
  }

  function renderCartPopupContent(currency) {
    var count = cartCount();
    var total = cartTotal();
    var cartItems = cart.length
      ? cart.map(function (c) {
          return el('div', { class: 'order-item' }, [
            el('div', {}, [
              el('strong', {}, c.name + (c.variantName ? ' (' + c.variantName + ')' : '')),
              c.scent ? el('br') : null,
              c.scent ? el('span', { class: 'small' }, c.scent) : null
            ]),
            el('div', {}, [
              el('button', { class: 'btn-sm min', onclick: function () { updateQty(c.key, -1); } }),
              el('span', { class: 'price', style: { margin: '0 8px' } }, c.qty + ' x ' + store.formatPriceIn(c.price, store.getCurrentCurrencyCode())),
              el('button', { class: 'btn-sm max', onclick: function () { updateQty(c.key, 1); } }),
              el('span', { class: 'remove', onclick: function () { removeFromCart(c.key); } }, [
                el('i', { class: 'fas fa-trash-alt' })
              ])
            ])
          ]);
        })
      : [el('p', { class: 'muted', style: { textAlign: 'center', padding: '40px 0' } }, 'Your cart is empty.')];

    return [
      el('div', { class: 'cart-popup-header' }, [
        el('h3', {}, 'Cart (' + count + ')'),
        el('button', { class: 'cart-popup-close', 'aria-label': 'Close cart', onclick: function () { toggleMobileCart(false); } }, '\u00D7')
      ]),
      el('div', { class: 'cart-popup-body' }, cartItems),
      el('div', { class: 'cart-popup-footer' }, [
        el('div', { class: 'cart-popup-total' }, [
          el('span', {}, 'Total'),
          el('span', {}, store.formatPriceIn(total, store.getCurrentCurrencyCode()))
        ]),
        el('button', {
          class: 'btn-md fill',
          disabled: count === 0,
          onclick: function () { openCheckout(); }
        }, 'Checkout')
      ])
    ];
  }

  /* ---- Checkout modal ------------------------------------------------ */

  function openCheckout() {
    var modal = document.getElementById('checkout-modal');
    if (modal) {
      // ★ Phase 10 (2026-09-26): capture the trigger element BEFORE the
      //   modal opens so closeCheckout() can restore focus to it. Without
      //   this, keyboard users were stranded on document.body after
      //   closing the modal (the click-outside / Escape / X-button paths
      //   all left focus on body).
      if (global.MorbiUI && typeof global.MorbiUI.captureTrigger === 'function') {
        global.MorbiUI.captureTrigger();
      }
      // ★ RT-12 fix: re-render the checkout card content so the discount line
      //   / "Remove" button reflects the current appliedDiscount state. The
      //   old code only toggled the `open` class — the card content was
      //   rendered once during doRender() when appliedDiscount was null, so
      //   after a successful apply, the discount line was invisible.
      //   handleApplyDiscount's success callback called openCheckout()
      //   expecting a re-render, but openCheckout() was a no-op for content.
      //   Fix: clear the modal's children + re-append the rendered checkout
      //   card. The `onclick` on the modal (click-outside-to-close) is on the
      //   modal div itself, not its children — so clearing children doesn't
      //   affect it. The renderCheckoutCard's `onclick: e.stopPropagation()`
      //   is re-created on each render (the el() helper creates a new element
      //   with the handler bound inline).
      //
      //   ★ UX-03 BLIND-SPOT fix (Task 43): the RT-12 re-render also wiped
      //   whatever the customer had typed into Full Name / Phone / Email —
      //   applying a discount code destroyed their contact details (the
      //   fields were re-created empty). Fix: snapshot those three inputs
      //   BEFORE clearing and restore the values AFTER re-rendering. The
      //   discount input is deliberately NOT preserved — UX-15 requires the
      //   applied code to be cleared from the input.
      var preserveIds = ['co-name', 'co-phone', 'co-email'];
      var preserved = {};
      preserveIds.forEach(function (pid) {
        var n = document.getElementById(pid);
        if (n) preserved[pid] = n.value;
      });
      clear(modal);
      var currency = store.getCurrency() || 'GHS';
      modal.appendChild(renderCheckoutCard(currency));
      preserveIds.forEach(function (pid) {
        var n = document.getElementById(pid);
        if (n && preserved[pid] !== undefined) n.value = preserved[pid];
      });
      modal.classList.add('open');
    }
    // Close mobile cart if open.
    toggleMobileCart(false);
    clearCheckoutValidation();
  }

  function closeCheckout() {
    var modal = document.getElementById('checkout-modal');
    if (modal) modal.classList.remove('open');
    clearCheckoutValidation();
    appliedDiscount = null;  // ★ Phase 5 Batch 2: clear discount on close
    // ★ WF-02 fix: mirror the null into sessionStorage so a page reload
    //   after an intentional close (or the Paystack round-trip that started
    //   from a LATER checkout) doesn't resurrect a code the customer
    //   already dismissed.
    persistDiscount();
    // ★ Phase 10 (2026-09-26): restore focus to the trigger element
    //   (the "Checkout" button) so keyboard users aren't stranded on
    //   document.body after the modal closes. Pairs with the
    //   captureTrigger() call in openCheckout().
    if (global.MorbiUI && typeof global.MorbiUI.restoreTrigger === 'function') {
      global.MorbiUI.restoreTrigger();
    }
  }

  // FIX-BL-3: Renamed shadowed variable 'el' to 'node' to avoid shadowing the imported el()
  function clearCheckoutValidation() {
    ['co-name', 'co-phone', 'co-email'].forEach(function (id) {
      var node = document.getElementById(id);
      if (node) node.classList.remove('invalid');
    });
    ['co-name-error', 'co-phone-error', 'co-email-error'].forEach(function (id) {
      var errNode = document.getElementById(id);
      if (errNode) errNode.classList.remove('show');
    });
  }

  function validateCheckout() {
    var valid = true;
    var nameInput = document.getElementById('co-name');
    var phoneInput = document.getElementById('co-phone');
    var emailInput = document.getElementById('co-email');

    // Name validation
    if (!nameInput || !nameInput.value.trim() || nameInput.value.trim().length < 2) {
      if (nameInput) nameInput.classList.add('invalid');
      var nameErr = document.getElementById('co-name-error');
      if (nameErr) { nameErr.textContent = 'Full name is required (min 2 characters)'; nameErr.classList.add('show'); }
      valid = false;
    } else {
      if (nameInput) nameInput.classList.remove('invalid');
      var nameErr2 = document.getElementById('co-name-error');
      if (nameErr2) nameErr2.classList.remove('show');
    }

    // Phone validation (Ghana MoMo format)
    var phoneVal = phoneInput ? phoneInput.value.trim() : '';
    var phoneRegex = /^(\+?233|0)[2-9]\d{8}$/;
    if (!phoneVal || !phoneRegex.test(phoneVal)) {
      if (phoneInput) phoneInput.classList.add('invalid');
      var phoneErr = document.getElementById('co-phone-error');
      if (phoneErr) { phoneErr.textContent = 'Enter a valid Ghana phone number (e.g. 233XXXXXXXXX)'; phoneErr.classList.add('show'); }
      valid = false;
    } else {
      if (phoneInput) phoneInput.classList.remove('invalid');
      var phoneErr2 = document.getElementById('co-phone-error');
      if (phoneErr2) phoneErr2.classList.remove('show');
    }

    // Email validation (optional but must be valid if provided)
    var emailVal = emailInput ? emailInput.value.trim() : '';
    if (emailVal) {
      var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(emailVal)) {
        if (emailInput) emailInput.classList.add('invalid');
        var emailErr = document.getElementById('co-email-error');
        if (emailErr) { emailErr.textContent = 'Enter a valid email address'; emailErr.classList.add('show'); }
        valid = false;
      } else {
        if (emailInput) emailInput.classList.remove('invalid');
        var emailErr2 = document.getElementById('co-email-error');
        if (emailErr2) emailErr2.classList.remove('show');
      }
    } else {
      if (emailInput) emailInput.classList.remove('invalid');
      var emailErr3 = document.getElementById('co-email-error');
      if (emailErr3) emailErr3.classList.remove('show');
    }

    return valid;
  }

  // ★ Phase 5 Batch 2: applied discount state (in-memory, per checkout session).
  // Cleared when the checkout modal is closed. Set by handleApplyDiscount().
  var appliedDiscount = null;  // { code, type, value } or null

  function renderCheckoutCard(currency) {
    var count = cartCount();
    var total = cartTotal();
    var discountAmount = appliedDiscount ? computeDiscount(total) : 0;
    var finalTotal = total - discountAmount;
    return el('div', { class: 'checkout-card', onclick: function (e) { e.stopPropagation(); } }, [
      el('h3', {}, 'Complete Your Order'),
      // ★ UX-12 fix: dedicated generic error slot at the TOP of the card.
      //   flashCheckoutError() used to write cart/payment errors into
      //   #co-name-error — red text directly under the Full Name input that
      //   read as "your name is wrong" even when the problem was the cart
      //   being empty or Paystack not returning a URL. Co-name-error is now
      //   reserved exclusively for name-field validation; this element
      //   carries everything else, positioned where the customer's eye is.
      el('p', { class: 'form-error', id: 'co-generic-error', style: { marginBottom: '8px', textAlign: 'center', fontSize: '13px' } }, ''),
      el('div', { class: 'checkout-summary' }, [
        el('p', {}, count + ' item' + (count !== 1 ? 's' : '') + ' in your cart'),
        el('p', {}, ['Subtotal: ', el('strong', {}, store.formatPriceIn(total, store.getCurrentCurrencyCode()))]),
        // ★ Phase 5 Batch 2: show discount line if a code is applied
        // ★ SEC-07 fix: was `Discount (CODE): -GHS X` — the amount was
        //   computed client-side from the type/value returned by the public
        //   validate endpoint. Now the validate endpoint returns only
        //   {valid, code} (no type/value) — the server computes the discount
        //   at checkout. The discount line shows "applied" without the amount.
        appliedDiscount ? el('p', { class: 'checkout-discount-line' }, [
          'Discount (' + appliedDiscount.code + ') applied ',
          el('i', { class: 'fas fa-check-circle', style: { color: 'var(--ok)', marginLeft: '4px' } })
        ]) : null,
        // ★ UI-12 fix: added `checkout-total-line` class to the Total `<p>`
        //   + removed the inline `fontSize: '18px'` override. The CSS rule
        //   `.checkout-summary .checkout-total-line` (theme.css) adds a
        //   `border-top` separator + the `.checkout-total-line strong`
        //   override bumps the font-size to 20px + color to white. The
        //   Total now has visual hierarchy: subtotal (gold 18px) → discount
        //   (green checkmark) → Total (white 20px + border-top).
        // ★ SEC-07 fix: the Total shows the subtotal (since the discount
        //   amount is unknown until checkout — the server computes it).
        //   If a discount is applied, the actual discounted total is shown
        //   on Paystack's payment page.
        el('p', { class: 'checkout-total-line' }, ['Total: ', el('strong', {}, appliedDiscount ? 'computed at checkout' : store.formatPriceIn(finalTotal, store.getCurrentCurrencyCode()))])
      ]),
      el('div', { class: 'form-row' }, [
        el('label', { for: 'co-name' }, 'Full Name'),
        el('input', { id: 'co-name', type: 'text', placeholder: 'Morbi' }),
        el('p', { class: 'form-error', id: 'co-name-error' }, 'Full name is required')
      ]),
      el('div', { class: 'form-row' }, [
        el('label', { for: 'co-phone' }, 'Phone (MoMo number)'),
        el('input', { id: 'co-phone', type: 'tel', placeholder: '233XXXXXXXXX' }),
        el('p', { class: 'form-error', id: 'co-phone-error' }, 'Valid phone required')
      ]),
      el('div', { class: 'form-row' }, [
        el('label', { for: 'co-email' }, 'Email (optional)'),
        el('input', { id: 'co-email', type: 'email', placeholder: 'you@email.com' }),
        el('p', { class: 'form-error', id: 'co-email-error' }, 'Valid email required')
      ]),
      // ★ Phase 5 Batch 2: discount code input + Apply button
      el('div', { class: 'form-row' }, [
        el('label', { for: 'co-discount' }, 'Discount Code (optional)'),
        el('div', { class: 'discount-row' }, [
          el('input', {
            id: 'co-discount', type: 'text', placeholder: 'WELCOME10',
            style: { textTransform: 'uppercase' },
            onkeydown: function (e) {
              if (e.key === 'Enter') { e.preventDefault(); handleApplyDiscount(currency); }
            }
          }),
          el('button', {
            id: 'co-discount-apply',
            type: 'button',
            // ★ UI-04 fix: removed the inline `style: { whiteSpace: 'nowrap' }`.
            //   The `.btn-sm` CSS rule (styles.css) already has `white-space:
            //   nowrap` + `min-width: 25px; min-height: 25px; padding: 2px 8px`
            //   (from Task 31's UI-23 fix). The inline override was a
            //   workaround for the old fixed `width: 25px; height: 25px` box
            //   that clipped the text — the CSS fix makes the workaround
            //   redundant. Both "Apply" + "Remove" now use the default
            //   `.btn-sm` styling consistently.
            class: 'btn-sm outline',
            onclick: function () { handleApplyDiscount(currency); }
          }, 'Apply')
        ]),
        el('p', { class: 'form-error', id: 'co-discount-error' }, ''),
        // Show applied code with a "Remove" link
        appliedDiscount ? el('div', { class: 'discount-applied' }, [
          el('span', { style: { color: 'var(--ok)', fontSize: '13px' } }, [
            el('i', { class: 'fas fa-check-circle', style: { marginRight: '4px' } }),
            appliedDiscount.code + ' applied' +
            (appliedDiscount.type === 'percentage'
              ? ' (' + appliedDiscount.value + '% off)'
              : ' (GHS ' + appliedDiscount.value + ' off)')
          ]),
          el('button', {
            type: 'button',
            // ★ UI-04 fix: removed the inline `fontSize: '12px'` +
            //   `padding: '2px 8px'` overrides (redundant with the `.btn-sm`
            //   CSS rule after Task 31's UI-23 fix). Kept the `borderColor`
            //   + `color` + `marginLeft` inline styles — those are
            //   semantic (red border + red text = destructive action;
            //   marginLeft = spacing from the applied-code text).
            class: 'btn-sm outline',
            style: { borderColor: 'var(--danger)', color: 'var(--danger)', marginLeft: '8px' },
            onclick: function () { appliedDiscount = null; persistDiscount(); openCheckout(); }
          }, 'Remove')
        ]) : null
      ]),
      // PHASE-2 (Bicycle): the payment button is now ENABLED. The customer
      // fills the form → clicks Pay with Paystack → we POST the cart to
      // api/payments.php, which creates an order + calls Paystack's
      // /transaction/initialize, returns an authorization_url → we redirect.
      // Paystack hosts the actual payment page (handles MoMo / card / bank /
      // USSD) and redirects back to #/payment-callback?reference=XYZ.
      el('p', { class: 'muted', style: { marginTop: '12px', fontSize: '12px' } },
        'You will be redirected to Paystack to complete payment via Mobile Money (MoMo), card, or bank transfer.'),
      el('div', { class: 'checkout-actions' }, [
        el('button', {
          class: 'btn-md outline',
          onclick: function () { closeCheckout(); }
        }, 'Cancel'),
        el('button', {
          id: 'co-pay-btn',
          class: 'btn-md fill',
          onclick: function () { submitCheckout(); }
        }, 'Pay with Paystack')
      ])
    ]);
  }

  // ★ Phase 5 Batch 2: compute the discount amount for the current cart total.
  // ★ SEC-07 fix: the public validate endpoint no longer returns type/value
  //   (was: {valid, code, type, value} → now: {valid, code}). The server
  //   computes the discount at checkout (payments.php). The client-side
  //   computeDiscount() returns 0 — the checkout summary shows "Discount
  //   applied" without the amount. The actual discounted total is shown on
  //   Paystack's payment page.
  function computeDiscount(total) {
    if (!appliedDiscount) return 0;
    // ★ SEC-07: type + value are no longer available (stripped from the
    //   public validate response). Return 0 — the server computes the actual
    //   discount amount at checkout. The checkout summary shows "Discount
    //   applied" without the amount (see renderCheckoutCard).
    return 0;
  }

  // ★ Phase 5 Batch 2: handle "Apply" button click on the discount code input.
  function handleApplyDiscount(currency) {
    var input = document.getElementById('co-discount');
    var errorEl = document.getElementById('co-discount-error');
    var applyBtn = document.getElementById('co-discount-apply');
    if (!input) return;
    // ★ M12 fix (audit): re-entry guard. The Enter key handler on the input
    //   ignores button.disabled state, so pressing Enter twice rapidly fires
    //   validateDiscountCode twice. The success path calls openCheckout() twice.
    if (applyBtn && applyBtn.disabled) return;

    var code = input.value.trim().toUpperCase();
    if (!code) {
      if (errorEl) { errorEl.textContent = 'Enter a discount code.'; errorEl.style.display = 'block'; }
      return;
    }

    if (errorEl) { errorEl.textContent = ''; errorEl.style.display = 'none'; }
    if (applyBtn) { applyBtn.disabled = true; applyBtn.textContent = 'Checking…'; }

    store.validateDiscountCode(code).then(function (res) {
      if (applyBtn) { applyBtn.disabled = false; applyBtn.textContent = 'Apply'; }
      // ★ SEC-07 fix: was `appliedDiscount = { code: res.code, type: res.type, value: res.value }`.
      //   The public validate endpoint no longer returns type/value (stripped for
      //   security — the server computes the discount at checkout). Now:
      //   `appliedDiscount = { code: res.code }` — just the code. The
      //   computeDiscount() function returns 0 (no type/value to compute from).
      //   The checkout summary shows "Discount applied" without the amount.
      appliedDiscount = { code: res.code };
      // ★ WF-02 fix: mirror the applied code into sessionStorage so it
      //   survives the full-page Paystack redirect (and any accidental
      //   reload) — the customer isn't asked to re-discover the code after
      //   a declined/abandoned attempt.
      persistDiscount();
      // ★ UX-15 fix: clear the input once the code has been applied. The
      //   stale code lingering in the field read as "it didn't work" and
      //   invited duplicate re-submits; a fresh field signals acceptance
      //   (the applied line + green check below the input is the visible
      //   confirmation). openCheckout() re-renders the card with the
      //   discount line — the input comes back empty because the applied
      //   code now lives in the appliedDiscount state, not the field.
      input.value = '';
      // Re-render the checkout modal to show the discount line.
      openCheckout();
    }).catch(function (err) {
      if (applyBtn) { applyBtn.disabled = false; applyBtn.textContent = 'Apply'; }
      if (errorEl) { errorEl.textContent = err.message || 'Invalid discount code.'; errorEl.style.display = 'block'; }
    });
  }

  /* ---- Phase 2: submit checkout → Paystack redirect ------------------- */
  // Validates the form (reuses validateCheckout — same regexes as the
  // server), then POSTs { name, phone, email?, items } to api/payments.php.
  // The server computes the total from DB prices (never trusts the client
  // total), creates the order row, and calls Paystack /transaction/initialize.
  // On success we redirect to the returned authorization_url (Paystack's
  // hosted payment page). On failure we flash the server's error message
  // and re-enable the button.
  function submitCheckout() {
    if (!validateCheckout()) return;
    if (cart.length === 0) {
      // Edge case: cart was emptied between opening the modal and clicking pay.
      flashCheckoutError('Your cart is empty.');
      return;
    }

    var payBtn = document.getElementById('co-pay-btn');
    if (payBtn) {
      payBtn.disabled = true;
      payBtn.textContent = 'Redirecting…';
    }

    var name = document.getElementById('co-name').value.trim();
    var phone = document.getElementById('co-phone').value.trim();
    var emailInput = document.getElementById('co-email');
    var email = emailInput ? emailInput.value.trim() : '';

    var payload = {
      name: name,
      phone: phone,
      email: email,
      // ★ Phase 8 Batch 3 (Task 60): send the customer's selected display
      //   currency. The server converts the GHS total to this currency
      //   + charges in it (if Paystack supports it). If Paystack can't
      //   charge in this currency, the server falls back to GHS + returns
      //   a currency_notice field that the storefront surfaces to the
      //   customer after the Paystack redirect-back.
      currency: store.getCurrentCurrencyCode(),
      items: cart.map(function (c) {
        var item = { id: c.id, qty: c.qty };
        // ★ Phase 5 Batch 3: include variantId if a variant was selected.
        if (c.variantId) item.variantId = c.variantId;
        return item;
      })
    };
    // ★ Phase 5 Batch 2: include the applied discount code if any.
    if (appliedDiscount && appliedDiscount.code) {
      payload.discountCode = appliedDiscount.code;
    }

    // ★ Phase 10 (2026-09-26): add a 30s timeout via AbortController so
    //   the pay button doesn't stay disabled forever if the server hangs.
    //   Was: bare fetch with no timeout — if the server hung (rare, but
    //   possible on a misbehaving cPanel host or a database lock), the
    //   button stayed disabled with the user staring at "Redirecting…"
    //   forever, no recovery path. Now: 30s timeout re-enables the button
    //   + surfaces a clear "timed out" message.
    var controller = (typeof AbortController !== 'undefined') ? new AbortController() : null;
    var signal = controller ? controller.signal : undefined;
    var payTimeoutId = setTimeout(function () {
      if (controller) controller.abort();
    }, 30000);

    fetch('api/payments.php', {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
      signal: signal
    }).then(function (res) {
      return res.text().then(function (text) {
        var json = null;
        try { json = text ? JSON.parse(text) : null; } catch (e) { json = null; }
        if (!res.ok || !json || json.ok !== true) {
          var message = (json && json.error) || ('Payment init failed (HTTP ' + res.status + ').');
          var err = new Error(message);
          err.status = res.status;
          throw err;
        }
        return json.data;
      });
    }).then(function (data) {
      // Server returned { reference, authorization_url, amount, currency }.
      // Redirect to Paystack's hosted page. The customer pays there, then
      // Paystack redirects back to #/payment-callback?reference=XYZ.
      if (data && data.authorization_url) {
        // ★ Phase 10 (2026-09-26): validate the URL before assigning it to
        //   window.location.href. The old code trusted the server blindly —
        //   a compromised backend, a misconfigured _config.php, or a future
        //   server-side regression could return a non-Paystack URL (e.g.
        //   `javascript:alert(1)` or a phishing domain). The browser would
        //   execute the assignment without question. Fix: refuse to redirect
        //   unless the URL starts with `https://` (Paystack's hosted
        //   checkout is ALWAYS https). Surface a clear error to the customer.
        var authUrl = String(data.authorization_url);
        if (authUrl.indexOf('https://') !== 0) {
          if (payBtn) { payBtn.disabled = false; payBtn.textContent = 'Pay with Paystack'; }
          flashCheckoutError('Paystack returned an invalid payment URL. Please contact support. Reference: ' + (data.reference || '(none)'));
          // Log the bad URL (sanitized — never log it verbatim in case it
          // contains a payload meant for the console).
          if (typeof console !== 'undefined' && console.error) {
            console.error('[morbi] Refusing to redirect to non-https authorization_url.');
          }
          return;
        }
        // ★ WF-02 + WF-03 fix: flush BOTH mirrors right before the full-
        //   page navigation unloads this SPA — the cart + applied code
        //   must be in sessionStorage when the callback page boots the
        //   storefront fresh on the way back. (All the ordinary mutation
        //   paths already mirrored; this is belt-and-braces at the one
        //   moment a miss is unrecoverable.) The discount stays persisted
        //   deliberately: on failure/abandonment the customer retries with
        //   cart + code intact; payment-callback.js clears both keys only
        //   when the payment SUCCEEDS.
        persistCart();
        persistDiscount();
        // ★ Phase 10: clear the pay-timeout timer on success (the abort
        //   controller is no longer needed — we're navigating away).
        if (payTimeoutId) clearTimeout(payTimeoutId);
        window.location.href = authUrl;
      } else {
        if (payTimeoutId) clearTimeout(payTimeoutId);
        if (payBtn) { payBtn.disabled = false; payBtn.textContent = 'Pay with Paystack'; }
        flashCheckoutError('Paystack did not return a payment URL. Please try again.');
      }
    }).catch(function (err) {
      if (payTimeoutId) clearTimeout(payTimeoutId);
      if (payBtn) { payBtn.disabled = false; payBtn.textContent = 'Pay with Paystack'; }
      // ★ Phase 10 (2026-09-26): translate AbortError into a friendlier
      //   "timed out" message. The raw error name ('AbortError') leaks
      //   implementation detail. Also surfaces a recovery hint.
      if (err && err.name === 'AbortError') {
        flashCheckoutError('Payment timed out. Please check your connection and try again.');
      } else {
        flashCheckoutError(err.message || 'Payment could not be started.');
      }
    });
  }

  function flashCheckoutError(msg) {
    // ★ UX-12 fix: use the dedicated #co-generic-error slot at the top of
    //   the checkout card (was: #co-name-error under the Full Name field —
    //   cart/payment errors masquerading as name-validation problems).
    //   Co-name-error is now reserved exclusively for name validation.
    var err = document.getElementById('co-generic-error');
    if (err) {
      err.textContent = msg;
      err.classList.add('show');
      setTimeout(function () { if (err.textContent === msg) err.classList.remove('show'); }, 5000);
    } else {
      alert(msg);
    }
  }

  // ★ Phase 3 Batch 4: lightweight cart error flasher — used for "out of
  // stock" + "only N available" messages when the user tries to add more
  // than stock allows.
  // ★ UX-12 fix: #cart-error now EXISTS — doRender() renders a fixed toast
  //   banner with that id (the fallback used to be #co-name-error inside
  //   the closed checkout modal, so these messages were invisible while
  //   browsing or misleadingly positioned under the Full Name field).
  //   Still falls back to alert() if neither element is in the DOM.
  function flashCartError(msg) {
    var err = document.getElementById('cart-error') || document.getElementById('co-name-error');
    if (err) {
      err.textContent = msg;
      err.classList.add('show');
      setTimeout(function () { if (err.textContent === msg) err.classList.remove('show'); }, 3000);
    } else {
      alert(msg);
    }
  }

  // ★ Feature 3: expose addToCart so landing.js's featured-product cards
  //   can add a product to the cart (persisted to sessionStorage) before
  //   navigating to /morcenzs. When the storefront isn't currently
  //   rendered, addToCart's UI refresh calls are all DOM-guarded (they
  //   query #cart-popup / .order etc. and bail if absent), so the only
  //   side effect is persistCart() — exactly what we want. When the
  //   storefront renders next, restorePersistedState() picks the cart up.
  global.MorbiStorefront = { render: render, renderWishlist: renderWishlist, addToCart: addToCart };
})(window);
