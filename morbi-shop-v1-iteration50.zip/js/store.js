/**
 * store.js — Single Responsibility: data persistence for morbi.shop.
 * PHASE 0 (Unicycle): the source of truth moves from localStorage to the
 * PHP/MySQL API (api/*.php). This module becomes a thin fetch layer.
 *
 * ── How it works ────────────────────────────────────────────────────────
 *   * Boot:   init() loads {session, products, categories, landing, settings}
 *             from the API into an in-memory `state`, then mirrors `state`
 *             to localStorage (STORAGE_KEY) as an offline/read-only fallback.
 *   * Reads:  all getters stay SYNCHRONOUS and unchanged — they serve the
 *             in-memory state. landing.js / storefront.js are untouched.
 *   * Writes: mutations now return PROMISES. The server confirms first
 *             (commit-after-confirm), then memory + cache are updated, so
 *             ids are always the real DB ids. On failure, memory is left
 *             untouched and the promise rejects with the server message.
 *
 * ── Public API compatibility ────────────────────────────────────────────
 *   * Every method exposed before Phase 0 still exists with the same name
 *     and the same arguments. 21 of them keep their exact return shape.
 *   * The 8 mutating methods (saveLanding, addCategory, updateCategory,
 *     deleteCategory, addProduct, updateProduct, deleteProduct,
 *     saveCurrency) now return Promises instead of plain values — the only
 *     caller is dashboard.js, which was adapted in the same increment.
 *   * NEW additive methods: init, hydrate, login, logout, checkSession,
 *     isAdmin, adminUsername.
 *   * Ids from the server are INTs (old string ids "prod_1" were a
 *     localStorage artifact). getProduct/getCategory compare ids via
 *     String() so DOM string values ("3") still match INT ids everywhere.
 *
 * Changelog (Phase 0 increment 0b; earlier Batch 1 fixes retained where the
 * code path survives: UNSAFE_KEYS guard, O(n) mergeDeep, doc fixes):
 *   - PHASE-0: localStorage demoted to offline mirror; API is the truth.
 *   - PHASE-0: mutations are async (commit-after-confirm, real DB ids).
 *   - PHASE-0: session auth added (login/logout/checkSession/isAdmin).
 *   - PHASE-0: importJSON() now targets api/import.php (one-time migration).
 *   - PHASE-0: resetAll() resets the LOCAL cache/memory only — server data
 *     is intentionally untouched (no destructive endpoint exists in Phase 0).
 *   - PHASE-0: slug generation moved server-side (slugify_server); the old
 *     client-side slugify delegation to ui-helpers is gone.
 *
 * PHASE-1 (Scooter) changes — design tokens:
 *   - PHASE-1: getTokens() / saveTokens(patch) / resetTokens() added.
 *     Hydrate now also fetches api/tokens.php; app.js injects the result as a
 *     <style id="morbi-tokens">:root{...}</style> block AFTER theme.css loads,
 *     so DB-stored colors override the hardcoded :root fallback in theme.css.
 *     If the API is unreachable, the cached mirror (or theme.css defaults)
 *     still apply — the public site never breaks.
 *   - DEFAULT_TOKENS mirrors TOKEN_CATALOG in api/tokens.php (same 11 keys,
 *     same hex defaults). Single source of truth lives server-side; the
 *     JS-side object is the offline-fallback copy only.
 *
 * PHASE-3 (Motorcycle) Batch 1 changes — CSRF tokens:
 *   - PHASE-3-CSRF: a per-session CSRF token is fetched from api/csrf.php on
 *     init() AND on login() (because login.php calls session_regenerate_id,
 *     which rotates the server-side token). The token is attached as
 *     X-CSRF-Token on every non-GET request by the api() helper.
 *   - getCsrfToken() exposed for callers (e.g. dashboard.js's uploadImage,
 *     which uses FormData + fetch directly, bypassing api()) to attach the
 *     header manually. Token is null until the first successful fetchCsrf().
 *   - Backward compat: if the server doesn't yet enforce CSRF (Phase 2
 *     installs that haven't been upgraded), the token is sent but ignored —
 *     no breakage. If the server enforces and the frontend is stale, the
 *     request returns 403 with a friendly "refresh the page" message.
 *   - Logout does NOT clear the local token — the next init() will fetch a
 *     fresh one for the new (anonymous) session that _bootstrap.php mints.
 *
 * PHASE-3 (Motorcycle) Batch 2 changes — Orders tab (admin dashboard):
 *   - PHASE-3-ORDERS: getOrders/getOrder/deleteOrder added as thin wrappers
 *     over the existing api/orders.php admin paths (which were already in
 *     place from Phase 2 Batch 1). The dashboard's new "Orders" tab uses
 *     these to list/filter/inspect/soft-delete orders placed via Paystack.
 *     No backend change in Batch 2 — purely a UI feature.
 *   - deleteOrder uses the api() helper's auto-CSRF attachment (DELETE is
 *     non-GET, so X-CSRF-Token goes out automatically — no manual header).
 *
 * PHASE-3 (Motorcycle) Batch 3 changes — password recovery + session-expiry:
 *   - PHASE-3-RECOVERY: requestPasswordReset(email) + resetPassword(token,
 *     password) added as thin wrappers over the new api/forgot-password.php +
 *     api/reset-password.php endpoints. Both are public (no admin session)
 *     and CSRF-exempt (pre-auth, like login.php).
 *   - PHASE-3-SESSION: onSessionExpired callback added. dashboard.js sets
 *     store.onSessionExpired = showReAuthModal. When api() receives a 401
 *     AND authed===true (session expired mid-use), it fires the callback
 *     BEFORE rejecting the promise. The original request fails normally
 *     (user retries after re-auth), but the modal gives the user a clear
 *     path to re-authenticate without losing their place (form data stays
 *     in the DOM because the modal is an overlay, not a navigation).
 *
 * PHASE-3 (Motorcycle) Batch 4 changes — server-side reset + inventory:
 *   - PHASE-3-RESET: resetDefaults() added — POSTs to api/reset-defaults.php,
 *     which transactionally wipes + re-seeds the CMS tables (products,
 *     categories, landing_content, currency, design tokens) to their
 *     install-time defaults. Does NOT touch admin_users, orders, order_items,
 *     rate_limit_log, or password_resets (audit trails + active sessions stay).
 *     The old resetAll() (local-only) is deprecated but kept for backward compat.
 *   - PHASE-3-INVENTORY: 'stock' added to PRODUCT_FIELDS (the pickFields list
 *     for addProduct/updateProduct). Server returns stock: null (unlimited)
 *     or stock: <int> (tracked) in map_product. NULL = unlimited (backward
 *     compat for Phase 0-3 installs); 0 = out of stock; N = available.
 *     Stock is decremented automatically when an order transitions to 'paid'
 *     (in webhook.php + orders.php verify_and_return).
 */
(function (global) {
  'use strict';

  var STORAGE_KEY = 'morbi:shop:v1'; // now: offline mirror of last-known server state
  var DEFAULT_CURRENCY = 'GHS';
  var API_BASE = 'api/';             // relative to index.html: works in XAMPP subdir AND cPanel docroot

  /* ---- Default design tokens (offline fallback only — mirrors the
     TOKEN_CATALOG in api/tokens.php and the :root block in theme.css).
     DO NOT edit one without editing the other two. */
  var DEFAULT_TOKENS = {
    bg_deep:       '#000000',
    bg_mid:        '#111111',
    bg_card:       '#1a1a1a',
    accent:        '#D4AF37',
    accent_strong: '#C8A951',
    accent_hover:  '#E5C654',
    danger:        '#dc2626',
    muted:         '#a0a0a0',
    ok:            '#2D8B4E',
    border:        '#333333',
    green:         '#2D8B4E'
  };

  /** Map a token name (snake_case) -> CSS variable name (--kebab-case). */
  function tokenToCssVar(name) {
    return '--' + String(name).replace(/_/g, '-');
  }

  /** Build a `:root { --token: #hex; ... }` block from a tokens map. */
  function tokensToCss(tokens) {
    var keys = Object.keys(tokens);
    if (keys.length === 0) return '';
    var lines = keys.map(function (k) {
      return '  ' + tokenToCssVar(k) + ': ' + tokens[k] + ';';
    });
    return ':root {\n' + lines.join('\n') + '\n}';
  }

  /* ---- Default data (fallback ONLY: used when the API is unreachable and
           no cache exists — same shapes as the original app) ------------- */

  function defaults() {
    return {
      currency: DEFAULT_CURRENCY,
      // PHASE-1: tokens are an offline-fallback copy only. Server-side
      // TOKEN_CATALOG in api/tokens.php is the source of truth; this object
      // mirrors its defaults so the site renders correctly even when the
      // API is unreachable AND the localStorage cache is empty.
      tokens: Object.assign({}, DEFAULT_TOKENS),
      landing: {
        hero_title: 'Luxury Scents, Redefined.',
        hero_subtitle: 'Morcenzs, handcrafted perfumes and accessories for those who leave an impression.',
        about_heading: 'About Morbi',
        about_text_1: 'Morbi is a creative entrepreneur and the founder of Morcenzs, a homegrown fragrance brand born from a passion for self-expression through scent.',
        about_text_2: 'Every Morcenzs bottle is curated with care, from bold, attention-grabbing signatures to subtle everyday essentials.',
        featured_heading: 'Featured Scents',
        featured_sub: 'A selection from the Morcenzs collection. Visit the store for the full range.',
        footer_text: 'Morcenzs by Morbi. All rights reserved.'
      },
      // ★ Phase 6 Batch 1c: empty array fallback. The server hydrates this
      // from api/sections.php's public GET path (active + non-deleted only).
      // Empty array = no sections yet (pre-install OR admin deleted all) —
      // the storefront render path falls back to the legacy landing_content
      // key-value pairs in state.landing (the api/landing.php shim rebuilt
      // those from the 4 base sections, so the fallback renders the same
      // content even when state.sections is empty).
      sections: [],
      categories: [
        { id: 'cat_1', name: 'Eau de Parfum', slug: 'eau-de-parfum', description: 'Long-lasting signature scents', sortOrder: 0 },
        { id: 'cat_2', name: 'Body Mist', slug: 'body-mist', description: 'Light, everyday freshness', sortOrder: 1 },
        { id: 'cat_3', name: 'Accessories', slug: 'accessories', description: 'Perfume accessories and gift sets', sortOrder: 2 }
      ],
      products: [
        { id: 'prod_1', name: 'Oud Royale', scent: 'Woody, Spicy', description: 'A bold oriental blend of oud, amber, and black pepper. For the unapologetic.', price: 180, categoryId: 'cat_1', imagePath: '', available: true },
        { id: 'prod_2', name: 'Velvet Bloom', scent: 'Floral, Sweet', description: 'Rose, jasmine, and vanilla. Soft power in a bottle.', price: 150, categoryId: 'cat_1', imagePath: '', available: true },
        { id: 'prod_3', name: 'Citrus Pulse', scent: 'Fresh, Citrus', description: 'Bergamot, lemon zest, and green tea. Your morning ritual.', price: 120, categoryId: 'cat_1', imagePath: '', available: true },
        { id: 'prod_4', name: 'Ocean Breeze Mist', scent: 'Aquatic, Light', description: 'Sea salt, cucumber, and white musk. Fresh all day.', price: 65, categoryId: 'cat_2', imagePath: '', available: true }
      ]
    };
  }

  /* ---- In-memory state (hydrated from the API at boot) ----------------- */

  var state = defaults();
  var authed = false;      // session state as last reported by api/session.php
  // ★ Phase 8 Batch 2 (Task 59): the admin's role. Populated from
  //   session.php's response. null when not authenticated. Used by the
  //   dashboard to hide the Admins tab for non-super_admin admins.
  var adminRole = null;
  var adminName = null;
  var csrfToken = null;    // PHASE-3-CSRF: per-session token, fetched on init() + login()

  // PHASE-3-B3: session-expiry callback. Set by dashboard.js to a function
  // that shows a re-auth modal when the session expires mid-use. When api()
  // gets a 401 AND authed===true, it fires this callback BEFORE rejecting
  // the promise — so dashboard.js can show the modal, the original request
  // fails normally (user retries after re-auth), and the modal gives the
  // user a clear path to re-authenticate without losing their place.
  var onSessionExpired = null;

  /* ---- API transport ---------------------------------------------------- */

  /**
   * Single fetch wrapper for the JSON API.
   * Resolves with the `data` field of {ok:true, data:...}.
   * Rejects with Error(message) carrying .status on any failure.
   *
   * PHASE-3-CSRF: attaches the X-CSRF-Token header on every non-GET request
   * (POST/PUT/DELETE). The token is fetched on init() and rotated on login().
   * If the token is null (e.g. fetchCsrf hasn't run yet or the server is a
   * Phase 2 install without CSRF enforcement), the header is omitted — the
   * request still goes out, and the server's verify_csrf() either passes
   * (Phase 2) or 403s with a friendly message (Phase 3).
   */
  function api(method, file, body, qs) {
    var opts = { method: method, credentials: 'same-origin', headers: {} };
    if (body !== null && body !== undefined) {
      opts.headers['Content-Type'] = 'application/json';
      opts.body = JSON.stringify(body);
    }
    // ★ C4 fix (audit): CSRF token must be attached on ALL non-GET requests,
    //   including those with body=null (DELETE-by-query-string, POST actions
    //   with no body). The old code nested this inside the body check, so
    //   deleteOrder, deleteSection, deleteCurrency, deleteAdmin,
    //   deleteDiscountCode, restoreSection all silently omitted CSRF → 403.
    if (method !== 'GET' && method !== 'HEAD' && csrfToken) {
      opts.headers['X-CSRF-Token'] = csrfToken;
    }
    return fetch(API_BASE + file + (qs || ''), opts).then(function (res) {
      return res.text().then(function (text) {
        var json = null;
        try { json = text ? JSON.parse(text) : null; } catch (e) { json = null; }
        if (!res.ok || !json || json.ok !== true) {
          var message = (json && json.error) ? json.error : ('Request failed (HTTP ' + res.status + ').');
          var err = new Error(message);
          err.status = res.status;
          // PHASE-3-B3: session-expiry detection. If we get a 401 AND we
          // were previously authed, the session expired mid-use (not a
          // genuine unauth request). Fire the callback so dashboard.js can
          // show the re-auth modal BEFORE the rejection propagates. The
          // rejection still happens — the user's save fails normally — but
          // the modal gives them a clear path to re-authenticate without
          // losing their place (form data stays in the DOM because the
          // modal is an overlay, not a navigation).
          if (res.status === 401 && authed && typeof onSessionExpired === 'function') {
            authed = false;  // session is gone; mark unauthed so we don't loop
            try { onSessionExpired(); } catch (cbErr) { /* never let the callback break the request */ }
          }
          throw err;
        }
        return json.data;
      });
    });
  }

  /* ---- PHASE-3-CSRF: fetch + rotate the CSRF token ------------------------- *
   * Called on init() and again after a successful login() (because login.php
   * calls session_regenerate_id(true), which rotates the server-side token).
   * The token is then attached by api() to every non-GET request. */
  function fetchCsrf() {
    return api('GET', 'csrf.php').then(function (res) {
      csrfToken = (res && res.token) || null;
      return csrfToken;
    }).catch(function (err) {
      // Server doesn't have csrf.php (Phase 2 install) or is unreachable —
      // leave csrfToken null. api() omits the header; the server either
      // doesn't enforce CSRF (Phase 2) or 403s with a friendly message.
      // ★ Phase 10 (2026-09-26): was a fully silent .catch(function () { ... }).
      //   Now logs the failure so the admin has a signal that the CSRF bootstrap
      //   failed (otherwise the next write attempt 403s with "refresh the page"
      //   and the admin has no idea why). The behavior is otherwise unchanged.
      if (typeof console !== 'undefined' && console.warn) {
        console.warn('[morbi] CSRF token fetch failed — subsequent writes may 403.', err && err.message ? err.message : err);
      }
      csrfToken = null;
      return null;
    });
  }

  function getCsrfToken() {
    return csrfToken;
  }

  /* ---- Cache mirror (offline fallback; same JSON shape as the old store) - */

  function write(data) {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
      return true;
    } catch (e) {
      console.error('[morbi] cache write failed:', e);
      return false;
    }
  }

  // UNSAFE_KEYS guard retained from Batch 1 (CWE-1321) — the mirror is fed
  // by server JSON, but it is still user-writable storage.
  var UNSAFE_KEYS = { __proto__: true, constructor: true, prototype: true };

  function mergeDeep(target, source) {
    var out = Object.assign({}, target);
    var keys = Object.keys(source);
    for (var i = 0; i < keys.length; i++) {
      var key = keys[i];
      if (UNSAFE_KEYS[key]) continue;
      if (source[key] && typeof source[key] === 'object' && !Array.isArray(source[key])
          && target[key] && typeof target[key] === 'object' && !Array.isArray(target[key])) {
        out[key] = mergeDeep(target[key], source[key]);
      } else {
        out[key] = source[key];
      }
    }
    return out;
  }

  function readCache() {
    try {
      var raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return null;
      var parsed = JSON.parse(raw);
      if (!parsed || typeof parsed !== 'object') return null;
      return mergeDeep(defaults(), parsed);
    } catch (e) {
      return null;
    }
  }

  /* ---- Hydration --------------------------------------------------------- */

  /**
   * Loads everything from the API. includeHidden=true (admin) also fetches
   * unavailable products via ?all=1. Mirrors the result to the cache.
   *
   * ★ PERF-16 fix (Task 45): optional second parameter `only` — an array of
   * section names to re-fetch instead of all five:
   *   ['products', 'categories', 'landing', 'settings', 'tokens']
   * Selected sections are MERGED into the existing state (and the localStorage
   * mirror); unselected sections keep their current values. Omitting `only`
   * keeps the original full-hydration behavior byte-identical (used by init,
   * init's failure fallback, and resetDefaults — which genuinely replaces
   * everything). Call sites that only touched ONE slice on the server now
   * fetch only that slice:
   *   login()/logout()      → products only (auth scope changes visibility;
   *                           categories/landing/settings/tokens are public
   *                           and identical pre/post auth — 4 wasted calls saved)
   *   migrateBase64Images() → products only (only image_path changed — 4 saved)
   *   importJSON()          → only the sections the server says it replaced
   *                           (the import response reports them — see call site)
   * Defensive: an empty/invalid `only` array or a missing in-memory state
   * falls back to the full hydration (the merge path needs state to exist).
   */
  function hydrate(includeHidden, only) {
    var SECTIONS = ['products', 'categories', 'landing', 'sections', 'settings', 'tokens'];
    var want = null;
    if (Array.isArray(only) && only.length && state && typeof state === 'object') {
      want = {};
      SECTIONS.forEach(function (k) {
        if (only.indexOf(k) !== -1) want[k] = true;
      });
      if (Object.keys(want).length === 0) want = null;  // no valid names → full
      if (Object.keys(want).length === SECTIONS.length) want = null;  // all → full path
    }

    if (!want) {
      // ---- Full hydration (original path + Phase 6 Batch 1c: sections) ----
      return Promise.all([
        api('GET', 'products.php', null, includeHidden ? '?all=1' : ''),
        api('GET', 'categories.php'),
        api('GET', 'landing.php'),
        api('GET', 'sections.php'),                 // ★ Phase 6 Batch 1c: public path returns active + non-deleted sections in sort_order
        api('GET', 'settings.php'),
        api('GET', 'tokens.php')              // PHASE-1: design tokens (public)
      ]).then(function (results) {
        state = {
          currency: (results[4] && results[4].currency) || DEFAULT_CURRENCY,
          // ★ Feature 4: WhatsApp business number (digits-only). Defaults to
          //   the placeholder '233000000000' when the API didn't return a row
          //   (pre-seed install) or returned an empty string.
          whatsappNumber: (results[4] && results[4].whatsapp_number) || '233000000000',
          // PHASE-1: server-confirmed tokens win; defaults() fill any missing
          // keys (e.g. if a token_* row was deleted). Offline mirror uses the
          // last-known server values verbatim.
          tokens: Object.assign({}, DEFAULT_TOKENS, (results[5] && results[5].tokens) || {}),
          // Merge over defaults so pre-seeding installs render complete copy.
          landing: Object.assign({}, defaults().landing, results[2] || {}),
          // ★ Phase 6 Batch 1c: server-confirmed sections (active + non-deleted
          // only — the public GET path filters). Empty array fallback if the
          // table is missing (pre-install or pre-migration) so the storefront
          // render path's backward-compat fallback kicks in.
          sections: (results[3] && results[3].sections) || [],
          categories: results[1].categories,
          products: results[0].products
        };
        write(state);
        return state;
      });
    }

    // ---- Selective hydration (PERF-16): fetch only `want`, merge the rest
    var jobs = [];
    var names = [];
    if (want.products)   { names.push('products');   jobs.push(api('GET', 'products.php', null, includeHidden ? '?all=1' : '')); }
    if (want.categories) { names.push('categories'); jobs.push(api('GET', 'categories.php')); }
    if (want.landing)    { names.push('landing');    jobs.push(api('GET', 'landing.php')); }
    if (want.sections)   { names.push('sections');   jobs.push(api('GET', 'sections.php')); }
    if (want.settings)   { names.push('settings');   jobs.push(api('GET', 'settings.php')); }
    if (want.tokens)     { names.push('tokens');     jobs.push(api('GET', 'tokens.php')); }

    return Promise.all(jobs).then(function (results) {
      for (var i = 0; i < names.length; i++) {
        var name = names[i];
        var res = results[i];
        if (name === 'products')   state.products = (res && res.products) || [];
        if (name === 'categories') state.categories = (res && res.categories) || [];
        if (name === 'landing')    state.landing = Object.assign({}, defaults().landing, res || {});
        if (name === 'sections')   state.sections = (res && res.sections) || [];
        if (name === 'settings')   {
          state.currency = (res && res.currency) || DEFAULT_CURRENCY;
          // ★ Feature 4: also pick up the WhatsApp number on selective re-hydrate.
          state.whatsappNumber = (res && res.whatsapp_number) || '233000000000';
        }
        if (name === 'tokens')     state.tokens = Object.assign({}, DEFAULT_TOKENS, (res && res.tokens) || {});
      }
      write(state);
      return state;
    });
  }

  /**
   * Boot sequence. NEVER rejects (app.js boots the router unconditionally):
   *   1. fetch CSRF token (Phase 3) — needed before any state-changing
   *      request; fetched FIRST so subsequent calls have it.
   *   2. session probe  -> remember admin state
   *   3. hydrate        -> admin scope when signed in, public otherwise
   *   4. on total API failure -> serve the localStorage mirror (read-only)
   *
   * PHASE-3-CSRF: fetchCsrf is best-effort — if it fails (server is Phase 2
   * without csrf.php, or offline), csrfToken stays null and api() omits the
   * header. The site still works read-only; the first write either succeeds
   * (Phase 2) or returns a friendly 403 (Phase 3).
   */
  function init() {
    return fetchCsrf().then(function () {
      return api('GET', 'session.php');
    }).then(function (s) {
      authed = !!(s && s.authenticated);
      adminName = (s && s.username) || null;
      // ★ Phase 8 Batch 2 (Task 59): capture the role from session.php.
      //   session.php includes 'role' for authenticated admins (added in
      //   this batch). null for unauthenticated. Used by dashboard.js to
      //   decide whether to render the Admins tab.
      adminRole = (s && s.role) || null;
      // ★ Phase 8 Batch 3 (Task 60): hydrate currencies in PARALLEL with
      //   the rest of the data. The storefront needs the currencies map
      //   before rendering any price. Returns a Promise that resolves to
      //   the currencies object — the next .then() in the chain ignores it.
      return Promise.all([
        hydrate(authed),
        hydrateCurrencies()
      ]);
    }).then(function (results) {
      // hydrate() resolves with state; hydrateCurrencies() resolves with
      // { currencies, base }. We only need state here — the currencies
      // map is already populated in the module-scoped currenciesMap var.
      return state;
    }).catch(function () {
      authed = false;
      adminName = null;
      adminRole = null;
      return hydrate(false).catch(function (e2) {
        var cached = readCache();
        if (cached) state = cached;
        console.warn('[morbi] API unreachable — serving cached data (read-only).', e2);
        return state;
      });
    });
  }

  /* ---- Session (Phase 0 additive) ---------------------------------------- */

  function login(username, password) {
    // login.php is exempt from CSRF (pre-auth), so no X-CSRF-Token here.
    // After login succeeds, session_regenerate_id rotates the server-side
    // CSRF token — we MUST fetchCsrf() before any subsequent write.
    // ★ Phase 10 (2026-09-26): was `authed = true` set IMMEDIATELY after the
    //   login API call resolved, BEFORE the fetchCsrf + hydrate chain. If
    //   hydrate failed (network drop after login), the outer Promise rejected
    //   but authed stayed true. The next render() saw isAdmin() === true and
    //   routed to the admin panel with an empty product list — confusing
    //   state divergence. Fix: capture the authed/adminName/adminRole
    //   values from the login response into LOCAL vars, then set them on
    //   the module-scope state ONLY after the full chain succeeds. On
    //   failure, the caller's .catch() can handle the rejection knowing the
    //   module state is unchanged (still pre-login).
    var pendingAuthed = false;
    var pendingName = null;
    var pendingRole = null;
    return api('POST', 'login.php', { username: username, password: password }).then(function (res) {
      pendingAuthed = true;
      pendingName = (res && res.username) || username;
      // ★ Phase 8 Batch 2 (Task 59): capture the role from login.php's
      //   response (added in this batch). Used by dashboard.js to decide
      //   whether to render the Admins tab. Server-side require_role()
      //   remains the source of truth — this is informational only.
      // ★ C5 fix (audit): fail closed to the lesser role when the server
      //   omits 'role'. The old default 'super_admin' was a client-side
      //   privilege escalation — a missing role field (server bug, old install,
      //   network truncation) would show the Admins + Currencies tabs.
      pendingRole = (res && res.role) || 'admin';
      // PHASE-3-CSRF: rotate the token (server did session_regenerate_id).
      return fetchCsrf().then(function () {
        // Re-hydrate with admin scope: hidden products become visible.
        // ★ PERF-16: auth changes ONLY product visibility — the other four
        //   sections are public + identical pre/post auth. 1 call, was 5.
        return hydrate(true, ['products']).then(function () {
          // ★ Phase 10: only NOW that the full chain (login → CSRF → hydrate)
          //   has succeeded do we commit the authed state to the module
          //   scope. A failure in any of the three steps leaves authed=false
          //   → the next render() routes to the login panel + the caller's
          //   .catch() can show a useful error message.
          authed = pendingAuthed;
          adminName = pendingName;
          adminRole = pendingRole;
          return { username: adminName, role: adminRole };
        });
      });
    });
  }

  function logout() {
    // ★ Phase 10 (2026-09-26): was `authed = false` set BEFORE the API call.
    //   If logout.php failed (network drop), local state said logged-out
    //   but the server session was still alive. The user saw the login panel
    //   but a refresh re-logged them in. Confusing state divergence.
    //   Fix: keep the local authed/adminName/adminRole unchanged until the
    //   API call succeeds. On failure, the caller's .catch() can surface
    //   the error and the user is still correctly shown as logged-in.
    return api('POST', 'logout.php', {}).then(function () {
      authed = false;
      adminName = null;
      adminRole = null;
      // session_destroy on the server → next request mints a fresh session.
      // PHASE-3-CSRF: fetch a new token for the new (anonymous) session so
      // any subsequent write (e.g. user signs back in immediately) works.
      return fetchCsrf().then(function () {
        // Back to public scope: hidden products leave the working set.
        // ★ PERF-16: same as login — only products changes with auth scope.
        return hydrate(false, ['products']);
      });
    });
  }

  function checkSession() {
    return api('GET', 'session.php').then(function (s) {
      authed = !!(s && s.authenticated);
      adminName = (s && s.username) || null;
      // ★ Phase 8 Batch 2 (Task 59): capture role on session check too.
      adminRole = (s && s.role) || null;
      return { authenticated: authed, username: adminName, role: adminRole };
    });
  }

  function isAdmin() { return authed; }
  function adminUsername() { return adminName; }
  // ★ Phase 8 Batch 2 (Task 59): expose the role + a convenience helper
  //   for the most common check (is the current admin a super_admin?).
  //   Dashboard.js uses these to decide whether to render the Admins tab.
  function getAdminRole() { return adminRole; }
  function isSuperAdmin() { return adminRole === 'super_admin'; }

  /* ---- Id helpers ---------------------------------------------------------
     Old ids were strings ("prod_1"); DB ids are INTs. DOM values are always
     strings. Comparing via String() keeps every existing caller working. */

  function sameId(a, b) { return String(a) === String(b); }

  /* ---- Public API: Landing content --------------------------------------- */

  function getLanding() {
    return Object.assign({}, state.landing);
  }

  // ★ Phase 6 Batch 1c: sync accessor for the hydrated sections array.
  // Used by js/landing.js + js/storefront.js to render the new sections
  // dynamically. The async getSections(includeDeleted) is the admin-path
  // fetcher (used by the dashboard Sections tab in Batch 1b to refetch
  // after a save/delete/restore); this sync version reads from state so
  // the storefront render path doesn't double-fetch on every render.
  // Returns a defensive shallow copy so callers can't mutate state.
  function getSectionsPublic() {
    return (state.sections || []).slice();
  }

  // Now resolves with the merged landing object (same shape as the old
  // return); rejects with the server message on failure.
  function saveLanding(patch) {
    var keys = Object.keys(patch);
    return Promise.all(keys.map(function (key) {
      return api('PUT', 'landing.php', { key: key, value: String(patch[key]) });
    })).then(function () {
      // ★ L12 fix (audit): coerce patch values to String before writing to
      //   state — the server receives String(patch[key]) (line 555), so
      //   state must match. Without this, state stores null while the server
      //   stores "null" — a state inconsistency that causes stale data.
      var coercedPatch = {};
      Object.keys(patch).forEach(function (k) { coercedPatch[k] = String(patch[k]); });
      state.landing = Object.assign({}, state.landing, coercedPatch);
      write(state);
      return Object.assign({}, state.landing);
    });
  }

  /* ---- Public API: Categories --------------------------------------------- */

  var CATEGORY_FIELDS = ['name', 'description', 'sortOrder'];

  function pickFields(source, fields) {
    var out = {};
    for (var i = 0; i < fields.length; i++) {
      var k = fields[i];
      if (Object.prototype.hasOwnProperty.call(source, k)) out[k] = source[k];
    }
    return out;
  }

  function getCategories() {
    return state.categories.slice();
  }

  function getCategory(id) {
    return state.categories.find(function (c) { return sameId(c.id, id); }) || null;
  }

  // Resolves with the created category (real INT id) — same truthy shape the
  // dashboard always relied on. Slug is generated server-side now.
  function addCategory(cat) {
    var payload = pickFields(cat, CATEGORY_FIELDS);
    return api('POST', 'categories.php', payload).then(function (created) {
      state.categories.push(created);
      write(state);
      return created;
    });
  }

  function updateCategory(id, patch) {
    var payload = pickFields(patch, CATEGORY_FIELDS);
    payload.id = id;
    return api('PUT', 'categories.php', payload).then(function (updated) {
      var idx = state.categories.findIndex(function (c) { return sameId(c.id, id); });
      if (idx !== -1) state.categories[idx] = updated;
      write(state);
      return updated;
    });
  }

  // Server FK (ON DELETE SET NULL) uncategorizes products; mirrored locally
  // so the UI updates without a refetch — same visible behavior as before.
  function deleteCategory(id) {
    return api('DELETE', 'categories.php', { id: id }).then(function () {
      state.categories = state.categories.filter(function (c) { return !sameId(c.id, id); });
      state.products.forEach(function (p) {
        if (p.categoryId !== null && p.categoryId !== undefined && sameId(p.categoryId, id)) {
          p.categoryId = null;
        }
      });
      write(state);
      return true;
    });
  }

  /* ---- Public API: Products ------------------------------------------------ */

  // ★ Phase 3 Batch 4: added 'stock' to the picked fields. NULL = unlimited
  // (no tracking); INT = tracked (decremented on paid order); 0 = out of stock.
  // ★ Phase 5 Batch 3: added 'variants' so the dashboard's variant data
  // passes through pickFields to the API (otherwise it's silently dropped).
  // ★ BL-16 fix: added 'scentCategory' so the dashboard's p-scent-category
  // select value passes through pickFields to the API (otherwise the scent
  // gate filter is a no-op — the column is never populated).
  var PRODUCT_FIELDS = ['name', 'scent', 'scentCategory', 'description', 'price', 'categoryId', 'imagePath', 'available', 'stock', 'variants'];

  function getProducts() {
    return state.products.slice();
  }

  function getAvailableProducts() {
    return state.products.filter(function (p) { return p.available !== false; });
  }

  // ★ Phase 10 (2026-09-26): resolveImagePath — prefixes relative image paths
  //   (e.g. 'images/male/male-01.jpeg') with the app's basePath so they
  //   resolve correctly under clean-path routing.
  //   Without this, a product at URL /morbi-shop/morcenzs would have its
  //   <img src="images/male/male-01.jpeg"> resolved by the browser as
  //   /morbi-shop/morcenzs/images/male/male-01.jpeg → 404 → the onerror
  //   flask-icon placeholder shows instead of the real perfume photo.
  //   This is the root cause of the "Phase 1 placeholder image bug" the
  //   user reported — it's NOT a Phase 1 regression, it's a clean-path
  //   routing side-effect that was always there but only became visible
  //   when the user navigated to /morcenzs (clean path) instead of
  //   /#morcenzs (hash route, where relative paths resolve against the
  //   page URL which is always /morbi-shop/).
  //   Handles: absolute URLs (http://, https://, //, data:, /) → returned as-is.
  function resolveImagePath(path) {
    if (!path || typeof path !== 'string') return '';
    // Already absolute or protocol-relative — don't touch.
    if (/^(https?:)?\/\//.test(path)) return path;
    // Data URL — don't touch.
    if (path.indexOf('data:') === 0) return path;
    // Already root-absolute — don't touch (but this is rare for this app).
    if (path.charAt(0) === '/' && path.charAt(1) !== '/') return path;
    // Relative — prepend the basePath.
    var router = global.MorbiRouter;
    if (router && typeof router.prependBasePath === 'function') {
      // prependBasePath expects a path starting with '/' — prepend it.
      var p = path.charAt(0) === '/' ? path : '/' + path;
      return router.prependBasePath(p);
    }
    // Router not loaded yet (very early init) — return as-is.
    return path;
  }

  function getProduct(id) {
    return state.products.find(function (p) { return sameId(p.id, id); }) || null;
  }

  function addProduct(product) {
    var payload = pickFields(product, PRODUCT_FIELDS);
    return api('POST', 'products.php', payload).then(function (created) {
      state.products.push(created);
      write(state);
      return created;
    });
  }

  function updateProduct(id, patch) {
    var payload = pickFields(patch, PRODUCT_FIELDS);
    payload.id = id;
    return api('PUT', 'products.php', payload).then(function (updated) {
      var idx = state.products.findIndex(function (p) { return sameId(p.id, id); });
      if (idx !== -1) state.products[idx] = updated;
      write(state);
      return updated;
    });
  }

  function deleteProduct(id) {
    return api('DELETE', 'products.php', { id: id }).then(function () {
      state.products = state.products.filter(function (p) { return !sameId(p.id, id); });
      write(state);
      return true;
    });
  }

  /* ---- Public API: Utility -------------------------------------------------- */

  function getCurrency() {
    return state.currency || DEFAULT_CURRENCY;
  }

  /* ★ Feature 4: WhatsApp business number accessor.
   *   state.whatsappNumber is hydrated from api/settings.php's
   *   whatsapp_number field at boot (and on selective re-hydrate). Falls
   *   back to the placeholder '233000000000' when the API is unreachable
   *   or the row hasn't been seeded yet. app.js calls this after init()
   *   to update the #whatsapp-fab link's href. */
  function getWhatsAppNumber() {
    return state.whatsappNumber || '233000000000';
  }

  // ★ Feature 4: save the WhatsApp number via PUT api/settings.php.
  //   Returns a Promise that resolves with the saved number (the server
  //   echoes it back). Mirrors saveCurrency's pattern.
  function saveWhatsAppNumber(number) {
    var cleaned = String(number || '').replace(/[^0-9]/g, '');
    if (cleaned !== '' && (cleaned.length < 6 || cleaned.length > 15)) {
      return Promise.reject(new Error('WhatsApp number must be 6-15 digits (country code + local number, no + or punctuation).'));
    }
    return api('PUT', 'settings.php', { whatsapp_number: cleaned }).then(function (res) {
      state.whatsappNumber = (res && res.whatsapp_number) || cleaned || '233000000000';
      return state.whatsappNumber;
    });
  }

  // FIX-BL-9/18 validation retained client-side (same regex as the server).
  // Returns a Promise now; rejects with the validation/server message.
  function saveCurrency(currency) {
    if (!currency || !/^[A-Za-z$\u20A0-\u20CF\u00A2-\u00A5]{1,5}$/.test(currency)) {
      return Promise.reject(new Error('Invalid currency symbol/code (1-5 letters or currency symbols).'));
    }
    return api('PUT', 'settings.php', { currency: currency }).then(function () {
      state.currency = currency;
      write(state);
      return true;
    });
  }

  // FIX-BL-3 comment retained: first 3 available products in insertion order.
  // ★ Changed from 6 to 3 per user request (iteration 41).
  // ★ Iteration 42: now returns a curated mix of male + female scents
  //   (IDs 1, 7, 3 = Oud Royale male, Velvet Orchid female, Sahara Spice male)
  //   instead of just the first 3 by insertion order. Falls back to
  //   slice(0, 3) when any of those IDs is missing (e.g., admin deleted
  //   a product) so the featured grid is never empty.
  function getFeaturedProducts() {
    var available = getAvailableProducts();
    var featuredIds = [1, 7, 3];
    var result = [];
    featuredIds.forEach(function (id) {
      var found = available.find(function (p) { return sameId(p.id, id); });
      if (found) result.push(found);
    });
    return result.length ? result : available.slice(0, 3);
  }

  /* ---- Public API: Design tokens (Phase 1) -----------------------------------
     getTokens()    sync — returns the hydrated tokens map (DEFAULT_TOKENS merged
                              with the server-confirmed overrides).
     saveTokens(p)  async — PUT { tokens: patch } to api/tokens.php; on success
                              updates state.tokens and the cache, then injects
                              the new CSS block into <head> for an instant preview.
                              Rejects with the server's message (e.g. "Token
                              accent must be a hex color (e.g. #1a1a1a).").
     resetTokens()  async — POST { action: "reset" } to api/tokens.php; on success
                              state.tokens is replaced with DEFAULT_TOKENS and the
                              CSS block is re-injected so the theme snaps back.
     applyTokens()  sync  — re-injects (or replaces) the <style id="morbi-tokens">
                              block in <head>. Called by app.js after init() and by
                              the dashboard after save/reset. Idempotent.
     tokensToCss()  exposed too — dashboard uses it for the live-preview textarea
                              (no preview in Batch 1; reserved for future use). */

  function getTokens() {
    return Object.assign({}, state.tokens || DEFAULT_TOKENS);
  }

  /**
   * Inject (or replace) the `<style id="morbi-tokens">:root { ... }</style>`
   * block in <head>. Called by app.js after init(), and by the dashboard
   * after save/reset.
   *
   * @param {Object} [overrideMap] optional token map to apply INSTEAD of the
   *   hydrated state.tokens — used by the dashboard's Theme tab for live
   *   preview (form values that have not been saved yet). When omitted, the
   *   current state.tokens is used.
   * @returns {string} the injected CSS source (handy for tests).
   */
  function applyTokens(overrideMap) {
    var tokens = overrideMap || state.tokens || DEFAULT_TOKENS;
    var css = tokensToCss(tokens);
    var existing = document.getElementById('morbi-tokens');
    if (existing) {
      existing.textContent = css;
    } else {
      var style = document.createElement('style');
      style.id = 'morbi-tokens';
      style.textContent = css;
      document.head.appendChild(style);
    }
    return css;
  }

  function saveTokens(patch) {
    if (!patch || typeof patch !== 'object' || Array.isArray(patch)) {
      return Promise.reject(new Error('saveTokens expects a plain object.'));
    }
    // Mirror the server's hex validation client-side so the dashboard flash
    // fires before a wasted round-trip.
    var keys = Object.keys(patch);
    for (var i = 0; i < keys.length; i++) {
      var v = patch[keys[i]];
      // ★ Phase 10 (2026-09-26): tightened the hex regex from {3,8} to
      //   (?:[0-9a-fA-F]{3}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8}). The old {3,8}
      //   accepted 4, 5, and 7-char hexes which are INVALID CSS colors
      //   (#RRGGB and #RRGGBB without AA but 7 chars are not valid). The
      //   server re-validates, but this avoids the wasted round-trip + a
      //   confusing 422. Valid lengths: 3 (#RGB), 6 (#RRGGBB), 8 (#RRGGBBAA).
      if (!v || !/^#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})$/.test(String(v))) {
        return Promise.reject(new Error('Token ' + keys[i] + ' must be a hex color (3, 6, or 8 hex digits, e.g. #1a1a1a).'));
      }
    }
    return api('PUT', 'tokens.php', { tokens: patch }).then(function (res) {
      // Server returns the FULL merged token map; trust it as truth.
      state.tokens = Object.assign({}, DEFAULT_TOKENS, (res && res.tokens) || patch);
      write(state);
      applyTokens();
      return state.tokens;
    });
  }

  function resetTokens() {
    return api('POST', 'tokens.php', { action: 'reset' }).then(function (res) {
      state.tokens = Object.assign({}, DEFAULT_TOKENS, (res && res.tokens) || {});
      write(state);
      applyTokens();
      return state.tokens;
    });
  }

  /* ---- Public API: Base64 image migration (Phase 1 Batch 3) -------------------
     migrateBase64Images(dryRun) POSTs to api/migrate-images.php, which scans
     every product whose image_path is a base64 data URL, decodes the bytes,
     writes them to uploads/<safe-name>, and UPDATEs the row's image_path to
     the new uploads/<name> path. Returns a Promise resolving with the
     server's counts: { migrated: N, skipped: N, bytes: B, dryRun: bool,
     samples: [...] }. After a real run (dryRun=false), re-hydrates so the
     in-memory state reflects the new image_path values immediately.

     Why this exists: Phase 1 Batch 2 moved NEW uploads to real files, but
     legacy base64 rows were left untouched (read-compat via <img src>).
     This endpoint is the one-click bulk-migration path for the dashboard. */

  function migrateBase64Images(dryRun) {
    var payload = dryRun ? { dryRun: true } : {};
    return api('POST', 'migrate-images.php', payload).then(function (res) {
      // Only re-hydrate on a real run — a dry run writes nothing, so the
      // in-memory state is already accurate.
      // ★ PERF-16: migration changes ONLY products.image_path — re-fetch
      //   products, skip categories/landing/settings/tokens (4 saved).
      if (!dryRun) {
        return hydrate(authed, ['products']).then(function () {
          return res;
        });
      }
      return res;
    });
  }

  /* ---- Public API: Orders (Phase 3 Batch 2) ----------------------------------
     The dashboard's new Orders tab calls these to list/filter/inspect/soft-
     delete orders placed via Paystack. The backend (api/orders.php) has had
     the admin GET paths since Phase 2 Batch 1 — these are thin wrappers
     that ride the existing api() transport (so CSRF, error normalization,
     and credentials all work for free).

     getOrders(filter)  async  -> { orders: [...], count, limit, offset }
       filter is optional: { status?: 'pending'|'paid'|'failed'|'abandoned'|'deleted',
                             limit?: number (default 50, server caps at 200),
                             offset?: number (default 0) }
     getOrder(id)       async  -> full order with items (admin shape — includes
                                   customer phone, email, paystack_fees).
     deleteOrder(id)     async  -> { deleted: id } (soft-delete — sets
                                   paystack_status='deleted'; preserves the
                                   audit trail). Dashboard asks for confirm()
                                   before calling. Auto-attaches X-CSRF-Token
                                   (DELETE is non-GET, so api() handles it). */

  function getOrders(filter) {
    filter = filter || {};
    var qs = '?';
    if (filter.status) qs += 'status=' + encodeURIComponent(filter.status) + '&';
    qs += 'limit=' + encodeURIComponent(filter.limit || 50) + '&';
    qs += 'offset=' + encodeURIComponent(filter.offset || 0);
    return api('GET', 'orders.php', null, qs);
  }

  function getOrder(id) {
    return api('GET', 'orders.php', null, '?id=' + encodeURIComponent(id));
  }

  function deleteOrder(id) {
    return api('DELETE', 'orders.php', null, '?id=' + encodeURIComponent(id));
  }

  /* ---- Public API: Discount codes (Phase 5 Batch 2) ------------------------
     validateDiscountCode(code)  async → {valid, code, type, value}
       Public endpoint — validates a code without revealing usage data.
       Returns the type + value so the frontend can compute the discount.
     getDiscountCodes()         async → {codes: [...]} (admin only)
     createDiscountCode(data)   async → created code object (admin)
     updateDiscountCode(id, p)  async → updated code object (admin)
     deleteDiscountCode(id)     async → {deleted: id} (admin) */

  function validateDiscountCode(code) {
    return api('GET', 'discounts.php', null, '?code=' + encodeURIComponent(code.toUpperCase()));
  }

  function getDiscountCodes() {
    return api('GET', 'discounts.php');
  }

  function createDiscountCode(data) {
    return api('POST', 'discounts.php', data);
  }

  function updateDiscountCode(id, patch) {
    patch.id = id;
    return api('PUT', 'discounts.php', patch);
  }

  function deleteDiscountCode(id) {
    return api('DELETE', 'discounts.php', null, '?id=' + encodeURIComponent(id));
  }

  /* ---- Public API: Analytics (Phase 5 Batch 4) -----------------------------
     getAnalytics() async → { revenue, topProducts, trend, customerInsights, discountUsage }
     Admin-only endpoint. Returns aggregated sales data for the dashboard
     Analytics tab. X-CSRF-Token not needed (GET request). */

  function getAnalytics() {
    return api('GET', 'analytics.php');
  }

  /* ---- Public API: Landing Page Builder (Phase 6 Batch 1a/1b) ---------------
     Five thin wrappers around api/sections.php. The dashboard's new
     "Sections" tab (Batch 1b) uses these.

     getSections(includeDeleted)  async → { sections: [...], deleted_count? }
       Public path: returns only active + non-deleted sections in sort_order.
       Admin path with includeDeleted=true: returns all (incl. soft-deleted)
       + a deleted_count.
     saveSection(data)            async → { section: {...} } (201)
       Create a new section. data = { section_type, content, sort_order?, active? }.
       sort_order defaults to max+1 server-side if not provided.
     updateSection(id, patch)     async → { section: {...} }
       Patch-style: only the keys present in `patch` are updated (content /
       active / sort_order). section_type is NOT patchable.
     deleteSection(id)            async → { deleted: id } (soft-delete)
     restoreSection(id)           async → { restored: id, section: {...} } */

  function getSections(includeDeleted) {
    var qs = includeDeleted ? '?include_deleted=1' : '';
    return api('GET', 'sections.php', null, qs);
  }

  function saveSection(data) {
    return api('POST', 'sections.php', data);
  }

  function updateSection(id, patch) {
    patch.id = id;
    return api('PUT', 'sections.php', patch).then(function (res) {
      // ★ Task 56 (WF-1 fix): update state.sections locally after a
      //   successful PUT so getSectionsPublic() returns the updated
      //   content immediately — without this, a second inline edit on
      //   the same element would compare against the OLD text (from the
      //   pre-PUT state) and re-save (a redundant API call). Now the
      //   local state is kept in sync with the server.
      if (res && res.section && state.sections) {
        state.sections = state.sections.map(function (s) {
          if (s.id === id) {
            // Merge the server's response (which has the full updated
            // section object including content, active, sort_order, etc.)
            // with the existing local copy (preserves fields the server
            // might not return, like deleted_at).
            return Object.assign({}, s, res.section);
          }
          return s;
        });
      }
      return res;
    });
  }

  function deleteSection(id) {
    return api('DELETE', 'sections.php', null, '?id=' + encodeURIComponent(id));
  }

  function restoreSection(id) {
    return api('POST', 'sections.php', null, '?action=restore&id=' + encodeURIComponent(id));
  }

  /* ---- Public API: Admin accounts (Phase 8 Batch 2, Task 59) ---------------
   *
   * getAdmins()                          async -> { admins, count, current_admin_id, current_admin_role }
   * getAdmin(id)                          async -> { admin }
   * createAdmin({username, password, email?, role?}) async -> { admin } (role defaults to 'admin')
   * updateAdmin(id, {email?, role?})     async -> { admin }
   * setAdminPassword(id, password)        async -> { id, password_changed: true }
   * deleteAdmin(id)                       async -> { deleted: id }
   *
   * password_hash is NEVER returned by the API — see api/admins.php's
   * map_admin() for the response shape. The frontend only knows the admin
   * has a password (always true for current installs).
   */
  function getAdmins() {
    return api('GET', 'admins.php', null, '?all=1');
  }
  function getAdmin(id) {
    return api('GET', 'admins.php', null, '?id=' + encodeURIComponent(id));
  }
  function createAdmin(payload) {
    return api('POST', 'admins.php', payload, '?action=create');
  }
  function updateAdmin(id, patch) {
    return api('POST', 'admins.php', patch, '?action=update&id=' + encodeURIComponent(id));
  }
  function setAdminPassword(id, password) {
    return api('POST', 'admins.php', { password: password }, '?action=set_password&id=' + encodeURIComponent(id));
  }
  function deleteAdmin(id) {
    return api('POST', 'admins.php', null, '?action=delete&id=' + encodeURIComponent(id));
  }

  /* ---- Public API: Currencies (Phase 8 Batch 3, Task 60) -------------------
   *
   * Multi-currency support. The base currency is GHS (admin sets + maintains
   * the GHS-equivalent exchange_rate for each currency). The customer's
   * selected currency is persisted in localStorage + sent to payments.php
   * at checkout (the server converts + charges in that currency if
   * Paystack supports it).
   *
   * Public methods:
   *   getActiveCurrencies()                async -> { currencies, count, base }
   *   getAllCurrencies()                   async -> { currencies, count, base } (admin, includes inactive)
   *   getCurrency(code)                    async -> { currency } (public, active only)
   *   createCurrency({code, name, symbol, exchange_rate, paystack_supported, active})
   *                                        async -> { currency } (super_admin)
   *   updateCurrency(code, patch)          async -> { currency } (super_admin)
   *   deleteCurrency(id)                   async -> { deleted, code, orders_using } (super_admin)
   *
   * Client-side helpers (sync):
   *   getCurrentCurrencyCode()  -> 'GHS' | 'USD' | ... (from localStorage; default 'GHS')
   *   setCurrentCurrencyCode(code)  -> persists to localStorage + dispatches
   *                                     'morbi:currency' event so storefront.js
   *                                     can re-render prices.
   *   convertPrice(amountGhs, toCode)  -> number (amountGhs × exchange_rate)
   *                                       Returns null if toCode is not in the
   *                                       hydrated currencies map.
   *   formatPriceIn(amountGhs, toCode) -> string ("$12.50", "₵100.00")
   *   getCurrenciesMap()  -> { GHS: {code, name, symbol, rate, ...}, USD: {...} }
   *                          Sync snapshot for the storefront's render path.
   */
  var currenciesMap = {};        // code → currency object (hydrated)
  var baseCurrencyCode = 'GHS';
  var STORAGE_KEY_CURRENCY = 'morbi:currency-v1';

  function hydrateCurrencies() {
    // Public endpoint — returns only active currencies. The storefront only
    // ever needs active currencies (the switcher dropdown, price conversion).
    // The dashboard's Currencies tab uses getAllCurrencies() (admin path) to
    // include inactive ones for editing.
    return api('GET', 'currencies.php').then(function (res) {
      currenciesMap = {};
      if (res && Array.isArray(res.currencies)) {
        res.currencies.forEach(function (c) {
          currenciesMap[c.code] = c;
        });
      }
      baseCurrencyCode = (res && res.base) || 'GHS';
      return { currencies: res ? res.currencies : [], base: baseCurrencyCode };
    }).catch(function (err) {
      // API unreachable — fall back to GHS only. The storefront still works;
      // the currency switcher will show only GHS (the default).
      // ★ Phase 10 (2026-09-26): was a fully silent catch — now logs the
      //   failure so the admin has a signal that the currencies hydrate failed
      //   (otherwise multi-currency silently collapses to GHS-only with no
      //   diagnostic when the API hiccups).
      if (typeof console !== 'undefined' && console.warn) {
        console.warn('[morbi] Currency hydrate failed — falling back to GHS-only.', err && err.message ? err.message : err);
      }
      currenciesMap = { GHS: { code: 'GHS', name: 'Ghanaian Cedi', symbol: '₵', exchange_rate: 1, paystack_supported: true, is_base: true } };
      baseCurrencyCode = 'GHS';
      return { currencies: [currenciesMap.GHS], base: 'GHS' };
    });
  }

  function getActiveCurrencies() {
    return api('GET', 'currencies.php');
  }
  function getAllCurrencies() {
    return api('GET', 'currencies.php', null, '?all=1');
  }
  // ★ Fix: renamed from getCurrency to getCurrencyDetail to avoid shadowing
  //   the sync getCurrency() at line 692 (which returns state.currency string).
  //   The old name caused landing.js's `store.getCurrency()` to return a
  //   Promise (from the api() call) instead of a string — resulting in
  //   "[object Promise]180" being displayed as the price.
  function getCurrencyDetail(code) {
    return api('GET', 'currencies.php', null, '?code=' + encodeURIComponent(code));
  }
  function createCurrency(payload) {
    return api('POST', 'currencies.php', payload);
  }
  function updateCurrency(code, patch) {
    return api('PUT', 'currencies.php', Object.assign({ code: code }, patch));
  }
  function deleteCurrency(id) {
    return api('DELETE', 'currencies.php', null, '?id=' + encodeURIComponent(id));
  }

  /* ---- Public API: Product search (Phase 9 Batch 1, Task 61) ---------------
   *
   * searchProducts(query)  async -> { products, count, total, query, filters, engine }
   *
   * `query` is an object with any of:
   *   { q, category, min_price, max_price, scent, limit, offset }
   * All fields optional. The server returns `available=1` products only.
   *
   * The storefront debounces at 300ms (in storefront.js) so this is called
   * at most ~5 times per second per keystroke-burst. Server-side rate limit
   * is 30/min per IP (generous — matches typical search-as-you-type usage).
   */
  function searchProducts(query) {
    var q = query || {};
    var params = [];
    if (q.q)            params.push('q=' + encodeURIComponent(q.q));
    if (q.category)     params.push('category=' + encodeURIComponent(q.category));
    if (q.min_price != null) params.push('min_price=' + encodeURIComponent(q.min_price));
    if (q.max_price != null) params.push('max_price=' + encodeURIComponent(q.max_price));
    if (q.scent)        params.push('scent=' + encodeURIComponent(q.scent));
    if (q.limit)        params.push('limit=' + encodeURIComponent(q.limit));
    if (q.offset)       params.push('offset=' + encodeURIComponent(q.offset));
    var queryStr = params.length ? '?' + params.join('&') : '';
    return api('GET', 'search.php', null, queryStr);
  }

  // ── Client-side sync helpers ──────────────────────────────────────────────
  function getCurrentCurrencyCode() {
    try {
      var saved = localStorage.getItem(STORAGE_KEY_CURRENCY);
      if (saved && currenciesMap[saved]) return saved;
    } catch (e) { /* private mode */ }
    return baseCurrencyCode || 'GHS';
  }
  function setCurrentCurrencyCode(code) {
    if (!code || !currenciesMap[code]) {
      // ★ Phase 10 (2026-09-26): the old code silently returned false here,
      //   leaving the dropdown's selected option out of sync with localStorage
      //   when the requested code was invalid (e.g. after the admin
      //   deactivated a currency the customer had previously selected).
      //   Now logs a warning so the mismatch is at least visible in devtools.
      if (typeof console !== 'undefined' && console.warn) {
        console.warn('[morbi] setCurrentCurrencyCode: invalid code "' + code + '" — keeping the previous currency.');
      }
      return false;
    }
    try { localStorage.setItem(STORAGE_KEY_CURRENCY, code); } catch (e) {
      // ★ Phase 10: was a silent catch. localStorage can throw QuotaExceededError
      //   in private mode — now logged so the admin sees why the currency
      //   selection isn't persisting across page reloads.
      if (typeof console !== 'undefined' && console.warn) {
        console.warn('[morbi] Could not persist currency selection to localStorage.', e && e.message ? e.message : e);
      }
    }
    // Dispatch a custom event so storefront.js can re-render prices without
    // a full page reload. Same pattern as the router's 'morbi:route' event.
    try {
      var ev = new CustomEvent('morbi:currency', { detail: { code: code } });
      window.dispatchEvent(ev);
    } catch (e) {
      // Very old browsers without CustomEvent — silent fallback (listeners
      // can fall back to polling getCurrencyCode() on render).
      if (typeof console !== 'undefined' && console.warn) {
        console.warn('[morbi] Could not dispatch morbi:currency event.', e && e.message ? e.message : e);
      }
    }
    return true;
  }
  function getCurrenciesMap() {
    return Object.assign({}, currenciesMap);
  }
  function getBaseCurrencyCode() {
    return baseCurrencyCode;
  }
  // Convert a GHS amount to the target currency. Returns the converted amount
  // (a number, rounded to 2 dp) or null if the currency is not hydrated.
  function convertPrice(amountGhs, toCode) {
    var c = currenciesMap[toCode];
    if (!c) return null;
    var rate = parseFloat(c.exchange_rate);
    if (!isFinite(rate) || rate <= 0) return null;
    return Math.round((amountGhs * rate) * 100) / 100;
  }
  // Format a GHS amount in the target currency. Returns "₵100" or "$12.50".
  // Falls back to "GHS100" if the currency is not hydrated.
  function formatPriceIn(amountGhs, toCode) {
    var c = currenciesMap[toCode];
    if (!c) {
      // ★ M10 fix (audit): fall back to the base currency symbol (₵), not the
      //   currency CODE as a symbol. The old code rendered "USD180" instead of
      //   "₵180" when the currency wasn't hydrated — misleading the customer
      //   into thinking USD prices equal GHS prices.
      var baseC = currenciesMap[baseCurrencyCode] || { symbol: '₵' };
      var num = Number(amountGhs) || 0;
      var rounded = Math.round(num * 100) / 100;
      return baseC.symbol + rounded.toFixed(2).replace(/\.00$/, '');
    }
    var converted = convertPrice(amountGhs, toCode);
    if (converted === null) return String(amountGhs);
    return c.symbol + converted.toFixed(2).replace(/\.00$/, '');
  }

  /* ---- Public API: Password recovery (Phase 3 Batch 3) ---------------------
     Two methods that ride the new api/forgot-password.php +
     api/reset-password.php endpoints. Both are public (no admin session)
     and CSRF-exempt (pre-auth, like login.php).

     requestPasswordReset(email)  async  -> { sent: true }
       Always resolves with {sent: true} — the server deliberately returns
       200 even if the email doesn't exist (anti-enumeration). The only
       rejection is on 422 (invalid email format) or 429 (rate limited).

     resetPassword(token, password)  async  -> { reset: true }
       Rejects on 422 (token invalid/expired/used, or password < 8 chars)
       or 500 (DB failure — rare). On success, the admin can sign in at
       #/dashboard with the new password. */

  function requestPasswordReset(email) {
    return api('POST', 'forgot-password.php', { email: email });
  }

  function resetPassword(token, password) {
    return api('POST', 'reset-password.php', { token: token, password: password });
  }

  /* ---- Backup / migration ----------------------------------------------------- */

  // Serializes the CURRENT (server-hydrated) state — same JSON shape the old
  // app produced, so backups stay portable in both directions.
  function exportJSON() {
    return JSON.stringify(state, null, 2);
  }

  // One-time migration path: posts the old export shape to api/import.php
  // (transactional replace of the sections present), then re-hydrates.
  // Resolves with the server counts {categories, products, landing, currency}.
  // ★ PERF-16: import.php ALWAYS reports these four keys (initialized to 0
  // in its $result — api/import.php:40), so its response can't distinguish
  // "section absent" from "section replaced with an empty array". The safe
  // read: re-fetch exactly the four reported sections and skip ONLY tokens
  // (import.php never touches token_* rows — 1 saved call), rather than
  // risking a stale slice on a false-negative count. resetDefaults() keeps
  // the full 5-endpoint hydration because it DOES replace tokens too.
  function importJSON(jsonString) {
    var parsed;
    try {
      parsed = JSON.parse(jsonString);
    } catch (e) {
      return Promise.reject(new Error('Invalid JSON file.'));
    }
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
      return Promise.reject(new Error('Invalid backup format.'));
    }
    return api('POST', 'import.php', parsed).then(function (result) {
      var sections = [];
      if (result && typeof result === 'object') {
        if (Object.prototype.hasOwnProperty.call(result, 'categories')) sections.push('categories');
        if (Object.prototype.hasOwnProperty.call(result, 'products')) sections.push('products');
        if (Object.prototype.hasOwnProperty.call(result, 'landing')) sections.push('landing');
        if (Object.prototype.hasOwnProperty.call(result, 'currency')) sections.push('settings');
      }
      return hydrate(authed, sections).then(function () {
        return result;
      });
    });
  }

  // LOCAL reset only: clears the mirror and shows defaults for this session.
  // DEPRECATED in Phase 3 Batch 4 — prefer resetDefaults() which resets the
  // SERVER too. Kept for backward compat (the dashboard's old "Reset
  // Everything" button used this; the new "Reset to Defaults" button calls
  // resetDefaults()).
  function resetAll() {
    state = defaults();
    try {
      localStorage.removeItem(STORAGE_KEY);
    } catch (e) { /* private mode etc. — memory reset already applied */ }
  }

  /* ---- Public API: Server-side reset to defaults (Phase 3 Batch 4) -----------
     resetDefaults() POSTs to api/reset-defaults.php, which transactionally
     wipes + re-seeds the CMS tables (products, categories, landing_content,
     site_settings currency + token_* rows) to their install-time defaults.
     DOES NOT touch admin_users (your password stays), orders, order_items,
     rate_limit_log, or password_resets (audit trails + active sessions stay).

     On success: re-hydrates from the server (so the in-memory state reflects
     the reset) + re-applies the design tokens (so the dashboard's Theme tab
     shows the default palette). Returns the server's counts object:
     { categories: N, products: N, landing: N, settings: N, tokens: N }.

     The dashboard's "Reset to Defaults" button asks for confirm() before
     calling this — it's destructive (all CMS content is replaced). The
     confirm dialog shows the user what will be deleted (queried client-side
     before the call) so they have full context before committing.

     X-CSRF-Token is auto-attached by api() (POST is non-GET). */
  function resetDefaults() {
    return api('POST', 'reset-defaults.php', {}).then(function (res) {
      return hydrate(authed).then(function () {
        // Re-apply tokens so the dashboard's Theme tab + the live preview
        // snap back to the default palette immediately.
        applyTokens();
        return res;
      });
    });
  }

  /* ---- Demo data for preview ---------------------------------------------------- */

  // KISS guard retained: intentionally NOT derived from defaults().products —
  // deriving would change the generated demo ids, an observable state change.
  function getDemoProducts() {
    return [
      { id: 'demo-1', name: 'Oud Royale', scent: 'Woody, Spicy', description: 'A bold oriental blend of oud, amber, and black pepper. For the unapologetic.', price: 180, categoryId: 'cat_1', imagePath: '', available: true },
      { id: 'demo-2', name: 'Velvet Bloom', scent: 'Floral, Sweet', description: 'Rose, jasmine, and vanilla. Soft power in a bottle.', price: 150, categoryId: 'cat_1', imagePath: '', available: true },
      { id: 'demo-3', name: 'Citrus Pulse', scent: 'Fresh, Citrus', description: 'Bergamot, lemon zest, and green tea. Your morning ritual.', price: 120, categoryId: 'cat_1', imagePath: '', available: true },
      { id: 'demo-4', name: 'Ocean Breeze Mist', scent: 'Aquatic, Light', description: 'Sea salt, cucumber, and white musk. Fresh all day.', price: 65, categoryId: 'cat_2', imagePath: '', available: true },
      { id: 'demo-5', name: 'Midnight Jasmine Mist', scent: 'Floral, Musky', description: 'Night-blooming jasmine with sandalwood undertones.', price: 60, categoryId: 'cat_2', imagePath: '', available: true },
      { id: 'demo-6', name: 'Luxury Gift Set', scent: 'Assorted', description: '3 mini fragrances in a handcrafted box. The perfect gift.', price: 250, categoryId: 'cat_3', imagePath: '', available: true }
    ];
  }

  /* ---- Expose ---------------------------------------------------------------------- */

  global.MorbiStore = {
    // -- original API (names/arguments unchanged; mutations now Promises) --
    STORAGE_KEY: STORAGE_KEY,
    DEFAULT_CURRENCY: DEFAULT_CURRENCY,
    defaults: defaults,
    getLanding: getLanding,
    // ★ Phase 6 Batch 1c: sync accessor for the hydrated sections array.
    getSectionsPublic: getSectionsPublic,
    saveLanding: saveLanding,
    getCategories: getCategories,
    getCategory: getCategory,
    addCategory: addCategory,
    updateCategory: updateCategory,
    deleteCategory: deleteCategory,
    getProducts: getProducts,
    getAvailableProducts: getAvailableProducts,
    // ★ Phase 10 (2026-09-26): resolveImagePath — used by storefront.js +
    //   landing.js to prefix relative image paths with the basePath so
    //   they resolve correctly under clean-path routing.
    resolveImagePath: resolveImagePath,
    getProduct: getProduct,
    addProduct: addProduct,
    updateProduct: updateProduct,
    deleteProduct: deleteProduct,
    getCurrency: getCurrency,
    saveCurrency: saveCurrency,
    // ★ Feature 4: WhatsApp business number accessor + saver.
    getWhatsAppNumber: getWhatsAppNumber,
    saveWhatsAppNumber: saveWhatsAppNumber,
    getFeaturedProducts: getFeaturedProducts,
    exportJSON: exportJSON,
    importJSON: importJSON,
    resetAll: resetAll,
    getDemoProducts: getDemoProducts,
    // -- Phase 0 additive (API mode) --------------------------------------
    init: init,
    hydrate: hydrate,
    login: login,
    logout: logout,
    checkSession: checkSession,
    isAdmin: isAdmin,
    adminUsername: adminUsername,
    // ★ Phase 8 Batch 2 (Task 59): role helpers + admin CRUD methods.
    getAdminRole: getAdminRole,
    isSuperAdmin: isSuperAdmin,
    getAdmins: getAdmins,
    getAdmin: getAdmin,
    createAdmin: createAdmin,
    updateAdmin: updateAdmin,
    setAdminPassword: setAdminPassword,
    deleteAdmin: deleteAdmin,
    // ★ Phase 8 Batch 3 (Task 60): multi-currency methods + sync helpers.
    getActiveCurrencies: getActiveCurrencies,
    getAllCurrencies: getAllCurrencies,
    // ★ Fix: renamed to getCurrencyDetail to avoid shadowing the sync getCurrency() above
    getCurrencyDetail: getCurrencyDetail,
    createCurrency: createCurrency,
    updateCurrency: updateCurrency,
    deleteCurrency: deleteCurrency,
    hydrateCurrencies: hydrateCurrencies,
    getCurrentCurrencyCode: getCurrentCurrencyCode,
    setCurrentCurrencyCode: setCurrentCurrencyCode,
    getCurrenciesMap: getCurrenciesMap,
    getBaseCurrencyCode: getBaseCurrencyCode,
    convertPrice: convertPrice,
    formatPriceIn: formatPriceIn,
    // ★ Phase 9 Batch 1 (Task 61): product search.
    searchProducts: searchProducts,
    // -- Phase 1 additive (design tokens) ---------------------------------
    DEFAULT_TOKENS: DEFAULT_TOKENS,
    getTokens: getTokens,
    saveTokens: saveTokens,
    resetTokens: resetTokens,
    applyTokens: applyTokens,
    tokensToCss: tokensToCss,
    // -- Phase 1 Batch 3 additive (base64 image migration) ----------------
    migrateBase64Images: migrateBase64Images,
    // -- Phase 3 Batch 1 additive (CSRF) -----------------------------------
    getCsrfToken: getCsrfToken,
    // -- Phase 3 Batch 2 additive (Orders tab) -----------------------------
    getOrders: getOrders,
    getOrder: getOrder,
    deleteOrder: deleteOrder,
    // -- Phase 3 Batch 3 additive (password recovery + session-expiry) -----
    requestPasswordReset: requestPasswordReset,
    resetPassword: resetPassword,
    // -- Phase 3 Batch 4 additive (server-side reset + inventory) ----------
    resetDefaults: resetDefaults,
    // -- Phase 5 Batch 2 additive (discount codes) -------------------------
    validateDiscountCode: validateDiscountCode,
    getDiscountCodes: getDiscountCodes,
    createDiscountCode: createDiscountCode,
    updateDiscountCode: updateDiscountCode,
    deleteDiscountCode: deleteDiscountCode,
    // -- Phase 5 Batch 4 additive (analytics) -------------------------------
    getAnalytics: getAnalytics,
    // -- Phase 6 Batch 1a/1b additive (landing page builder) ----------------
    getSections: getSections,
    saveSection: saveSection,
    updateSection: updateSection,
    deleteSection: deleteSection,
    restoreSection: restoreSection,
    // -- Phase 3 Batch 3 callback (set by dashboard.js) -------------------
    // Set store.onSessionExpired = function() { ... } to be notified when a
    // 401 is received mid-session. dashboard.js uses this to show a re-auth
    // modal. The original failed request rejects normally — the modal just
    // gives the user a clear path to re-authenticate without losing context.
    set onSessionExpired(fn) { onSessionExpired = fn; },
    get onSessionExpired() { return onSessionExpired; }
  };
})(window);
