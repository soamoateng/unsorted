/**
 * landing.js — Morbi's personal landing page with Morcenzs hero.
 *
 * FIX-UX-3: Added dashboard link to header nav.
 * FIX-UI-9: Removed duplicate wave-green-bottom div and manual green bar.
 * FIX-UI-11: Featured section now has proper wave divider via CSS.
 *
 * Phase 1 Batch 3 (R1): `ChowMenuUI` / `ChowMenuRouter` global references
 *   renamed to `MorbiUI` / `MorbiRouter` (with backward-compat aliases kept
 *   in ui-helpers.js and router.js — see those files).
 * Phase 1 Batch 3 (R3): Fixed a variable-shadowing bug in renderHero's
 *   "View Featured" click handler — `var el = document.querySelector(...)`
 *   shadowed the imported `el` helper from line 12. Renamed to `featSec`
 *   to remove the shadow. Behavior is byte-identical (querySelector still
 *   returns a DOM element with `.scrollIntoView`), but the code is now
 *   readable and won't confuse future readers who expect `el` to be the
 *   helper.
 *
 * ★ Phase 6 Batch 1c (Task 50): DYNAMIC SECTION RENDERING. The render()
 *   function now reads from store.getSectionsPublic() (the hydrated
 *   sections array from api/sections.php's public GET path) and renders
 *   each section in sort_order via a render<type>() function per type.
 *   9 type renderers: renderHero, renderAbout, renderFeatured,
 *   renderFooter (the 4 base types — same DOM as before, but now driven
 *   by the section's content JSON instead of the 8-key landing_content
 *   shape) + renderPromoBanner, renderCtaBlock, renderImageSpot,
 *   renderTextBlock, renderSpacer (the 5 new types added in Batch 1b).
 *
 *   BACKWARD-COMPAT FALLBACK: if state.sections is empty (pre-install,
 *   pre-migration, OR admin deleted all sections), the render path
 *   falls back to the legacy 4-section hardcoded shape using the 8
 *   key-value pairs in state.landing (which api/landing.php's shim
 *   rebuilt from the 4 base sections in Batch 1a). So an upgrade from
 *   iteration 27 → 29 with no install.php re-run still renders byte-
 *   identically to iteration 27 — no blank page.
 *
 *   The 4 base sections render at their fixed sort_order positions
 *   (0/1/2/3) UNLESS Morbi has added other sections in between — in which
 *   case the new sections are interleaved at their sort_order positions.
 *   The featured section's product grid (the 4 default products) renders
 *   inside renderFeatured exactly as before; new section types render
 *   above or below it depending on sort_order.
 */
(function (global) {
  'use strict';

  var ui = global.MorbiUI;
  var el = ui.el, clear = ui.clear;
  var router = global.MorbiRouter;
  var store = global.MorbiStore;

  // ★ Task 54: inline editing state. When Morbi is logged in + edit mode
  //   is ON, text elements get contenteditable + a dashed gold outline.
  //   On blur (click away), the edited text is saved via store.updateSection.
  var adminEditMode = false;

  function isAdmin() {
    return store && typeof store.isAdmin === 'function' && store.isAdmin();
  }

  // Helper: returns contenteditable attribute for text elements when admin
  // edit mode is ON. Returns undefined otherwise (element is not editable).
  function editableAttrs(sectionId, field) {
    if (!isAdmin() || !adminEditMode) return undefined;
    return {
      contenteditable: 'true',
      'data-section-id': String(sectionId),
      'data-field': field
    };
  }

  function render() {
    var root = document.getElementById('app-root');
    clear(root);

    var sections = store.getSectionsPublic();
    var landing = store.getLanding();
    var featured = store.getFeaturedProducts();
    var currency = store.getCurrency();

    // Build the body: header + section blocks in sort_order + footer.
    // The footer is always LAST regardless of sort_order (semantically
    // it's the page footer — the dashboard allows sort_order on it but
    // the render path forces it to the bottom; this matches Morbi's
    // mental model of "footer = bottom of page").
    var body = [renderHeader()];
    var footerNode = null;

    if (sections && sections.length > 0) {
      // ★ Phase 6 Batch 1c: render sections dynamically.
      // Walk in sort_order (the server already returns them sorted, but
      // sort client-side too for safety — defense in depth). The footer
      // section is held back to render last.
      var sorted = sections.slice().sort(function (a, b) {
        return (a.sort_order || 0) - (b.sort_order || 0);
      });
      sorted.forEach(function (s) {
        if (s.section_type === 'footer') {
          footerNode = renderFooterFromSection(s);
          return;
        }
        var node = renderSectionByType(s, landing, featured, currency);
        if (node) body.push(node);
      });
    } else {
      // ★ Backward-compat fallback: render the legacy 4-section hardcoded
      // shape from the 8 landing_content keys. This is the path taken on
      // pre-install + pre-migration installs + when Morbi has deleted
      // ALL sections (rare). The DOM is byte-identical to iteration 27.
      body.push(renderHero(landing, featured, currency));
      body.push(renderAbout(landing));
      body.push(renderFeatured(landing, featured, currency));
      footerNode = renderFooter(landing);
    }

    if (footerNode) body.push(footerNode);

    root.appendChild(el('div', { class: 'landing' }, body));

    // ★ Task 54: wire up the inline edit blur handler if admin edit mode
    //   is ON. Uses event delegation — one listener on the root catches
    //   blur events from all contenteditable elements. On blur, reads
    //   the element's text + section id + field name, then calls
    //   store.updateSection to save the change.
    if (isAdmin() && adminEditMode) {
      bindInlineEditHandlers(root);
    }
  }

  // ★ Task 54: inline edit blur handler. Delegated from #app-root so it
  //   catches all contenteditable elements. On blur: extract the text,
  //   fetch the section's current content from store.getSectionsPublic(),
  //   patch the edited field, call store.updateSection. Shows a small
  //   "Saving…" → "Saved" floating toast.
  // ★ Blind-spot fix (2026-09-26): added a per-element guard flag
  //   (`root._morbiInlineEditBound`) so the listener attaches EXACTLY once
  //   per #app-root instance. Without this guard, every render() re-attached
  //   a fresh capture-phase `blur` listener on the SAME persistent
  //   #app-root, stacking N identical listeners after N renders → N
  //   duplicate `store.updateSection` API calls per blur (memory leak +
  //   write amplification).
  function bindInlineEditHandlers(root) {
    if (root._morbiInlineEditBound) return;  // idempotency guard
    root._morbiInlineEditBound = true;
    root.addEventListener('blur', function (e) {
      var target = e.target;
      if (!target.hasAttribute || !target.hasAttribute('contenteditable')) return;
      var sectionId = parseInt(target.getAttribute('data-section-id'), 10);
      var field = target.getAttribute('data-field');
      // ★ Phase 10 (2026-09-26): was just `if (!sectionId || !field) return;`
      //   — but parseInt('', 10) returns NaN, and `!NaN` is true, so the
      //   guard works. However, parseInt('0', 10) returns 0, and `!0` is
      //   also true — so a section_id of 0 (legitimate primary key in some
      //   MySQL configs, but not SQLite AUTOINCREMENT) would be silently
      //   rejected. Adding an explicit isNaN check for clarity + future
      //   safety. (The '!' guards on field are unchanged.)
      if (isNaN(sectionId) || sectionId <= 0 || !field) return;

      var newText = target.textContent.trim();
      // Find the section in the hydrated state.
      var sections = store.getSectionsPublic();
      var section = sections.find(function (s) { return s.id === sectionId; });
      if (!section) return;

      // If the text hasn't changed, skip the save.
      var currentText = (section.content && section.content[field]) || '';
      if (newText === currentText) return;

      // Patch the content with the new field value.
      var newContent = Object.assign({}, section.content || {});
      newContent[field] = newText;

      // Show "Saving…" toast.
      showInlineEditToast('Saving…');

      store.updateSection(sectionId, { content: newContent }).then(function () {
        showInlineEditToast('Saved ✓');
      }).catch(function (err) {
        showInlineEditToast('Save failed: ' + (err.message || 'error'), true);
        // ★ Phase 10 (2026-09-26): only revert the text content if the user
        //   hasn't continued editing in the meantime. Was: unconditional
        //   `target.textContent = currentText` — if the user typed more text
        //   between the blur (which fired the save) and the catch firing
        //   (typically 200-500ms later for a network error), their new edits
        //   were silently overwritten. Now: snapshot the text at blur-time +
        //   only revert if the text hasn't changed since.
        if (target.textContent.trim() === newText) {
          target.textContent = currentText;
        }
      });
    }, true); // useCapture: true so blur fires before other handlers
  }

  // Small floating toast for inline edit save status.
  // ★ Phase 10 (2026-09-26): added teardownInlineEditToast() so route changes
  //   can clean up the toast element + clear the timer. Was: the toast div
  //   was created once + appended to document.body, never removed — it
  //   survived navigation to /dashboard / /morcenzs as an invisible
  //   (opacity:0) div, leaking DOM + the timer firing after route change.
  var inlineEditToastEl = null;
  var inlineEditToastTimer = null;
  function showInlineEditToast(msg, isError) {
    if (!inlineEditToastEl) {
      inlineEditToastEl = document.createElement('div');
      inlineEditToastEl.style.cssText = 'position:fixed;bottom:20px;right:20px;padding:8px 16px;border-radius:6px;font-size:14px;font-weight:600;z-index:99999;box-shadow:0 2px 8px rgba(0,0,0,0.3);transition:opacity 0.3s;';
      document.body.appendChild(inlineEditToastEl);
    }
    inlineEditToastEl.textContent = msg;
    inlineEditToastEl.style.background = isError ? '#dc2626' : '#2D8B4E';
    inlineEditToastEl.style.color = '#fff';
    inlineEditToastEl.style.opacity = '1';
    if (inlineEditToastTimer) clearTimeout(inlineEditToastTimer);
    inlineEditToastTimer = setTimeout(function () {
      if (inlineEditToastEl) inlineEditToastEl.style.opacity = '0';
    }, 2000);
  }
  // ★ Phase 10: called on route change (the router can dispatch a teardown
  //   event, or the module can poll — for now this is exposed so app.js
  //   or any other module can call it explicitly. We also self-clean on
  //   popstate so Back-button navigation triggers cleanup.)
  function teardownInlineEditToast() {
    if (inlineEditToastTimer) {
      clearTimeout(inlineEditToastTimer);
      inlineEditToastTimer = null;
    }
    if (inlineEditToastEl && inlineEditToastEl.parentNode) {
      inlineEditToastEl.parentNode.removeChild(inlineEditToastEl);
      inlineEditToastEl = null;
    }
  }
  // Self-clean on route change (popstate fires for Back/Forward button).
  // The router's own dispatch is a CustomEvent — listen for that too.
  if (!global._morbiLandingToastTeardownWired) {
    global._morbiLandingToastTeardownWired = true;
    global.addEventListener('popstate', teardownInlineEditToast);
    global.addEventListener('morbi:route', teardownInlineEditToast);
  }

  /* ---- Section router ------------------------------------------------ */
  // Dispatches a single section to its type-specific renderer.
  function renderSectionByType(s, landing, featured, currency) {
    switch (s.section_type) {
      case 'hero':         return renderHeroFromSection(s, featured, currency);
      case 'about':        return renderAboutFromSection(s);
      case 'featured':     return renderFeaturedFromSection(s, featured, currency);
      case 'promo_banner': return renderPromoBanner(s);
      case 'cta_block':   return renderCtaBlock(s);
      case 'image_spot':  return renderImageSpot(s);
      case 'text_block':  return renderTextBlock(s);
      case 'spacer':      return renderSpacer(s);
      // footer is handled in render() so it always lands at the bottom.
      default:
        console.warn('[morbi] Unknown section type:', s.section_type);
        return null;
    }
  }

  /* ---- Header ------------------------------------------------------- */
  // FIX-UX-3: Added dashboard link

  function renderHeader() {
    // ★ Feature 1: replace the "Shop Morcenzs" text button + "Admin Panel"
    //   icon button with a single hamburger menu. The menu contains:
    //     1. Admin Panel → /dashboard
    //     2. Storefront → /morcenzs
    //   The shared helper (ui.renderHeaderMenu) handles outside-click +
    //   Escape-key + click-item-to-close. The Edit Mode toggle (admin only)
    //   is preserved — it's a state toggle, not navigation, so it stays as
    //   its own button before the hamburger.
    var navButtons = [];
    // ★ Task 54: Edit Mode toggle (admin only). When ON, text on the page
    //   becomes contenteditable with a dashed gold outline. Morbi clicks
    //   text, edits, clicks away → saves automatically.
    if (isAdmin()) {
      navButtons.push(el('button', {
        class: 'btn-md outline' + (adminEditMode ? ' active' : ''),
        style: adminEditMode ? { borderColor: 'var(--accent)', color: 'var(--accent)' } : {},
        title: 'Toggle inline editing',
        onclick: function () {
          // ★ Task 56 (UI-1 fix): preserve scroll position when toggling
          //   edit mode. Without this, render() clears the DOM + the browser
          //   scrolls to top — Morbi loses her place on the page.
          var scrollY = window.scrollY || window.pageYOffset || 0;
          adminEditMode = !adminEditMode;
          render();
          try { window.scrollTo(0, scrollY); } catch (e) { /* ignore */ }
        }
      }, [el('i', { class: 'fas fa-pencil-alt', style: { marginRight: '4px' } }),
          adminEditMode ? 'Edit ON' : 'Edit OFF']));
    }
    // The hamburger menu replaces the previous two nav buttons. The items
    // clear the sessionStorage scent choice before navigating to /morcenzs
    // so the scent gate always re-appears when entering the store from the
    // landing page (same UX fix the old Shop Morcenzs button had).
    navButtons.push(ui.renderHeaderMenu([
      {
        label: 'Admin Panel',
        icon: 'fas fa-cog',
        onclick: function () { router.navigate('/dashboard'); }
      },
      {
        label: 'Storefront',
        icon: 'fas fa-store',
        onclick: function () {
          try { sessionStorage.removeItem('morbi:scent-choice'); } catch (e) { /* private mode */ }
          router.navigate('/morcenzs');
        }
      }
    ], 'btn-md outline'));
    return el('header', { class: 'landing-header' }, [
      el('div', { class: 'landing-logo' }, 'morbi.shop'),
      el('div', { class: 'landing-nav' }, navButtons)
    ]);
  }

  /* ---- Hero section ------------------------------------------------- */
  // Two flavors: renderHero (legacy fallback — reads the 8 landing_content
  // keys) + renderHeroFromSection (dynamic — reads the section's content
  // JSON). Both produce the same DOM shape; the dynamic version is the
  // primary path, the legacy version is the fallback for empty state.sections.

  function renderHero(landing, featured, currency) {
    var heroTitle = landing.hero_title || 'A scent full of desire';
    // ★ Task 54: inline editing — if _editSectionId is set, make the
    //   heading + subtitle contenteditable.
    var editId = landing._editSectionId;
    var headingAttrs = editId ? { contenteditable: 'true', 'data-section-id': String(editId), 'data-field': 'heading' } : {};
    var subtitleAttrs = editId ? { contenteditable: 'true', 'data-section-id': String(editId), 'data-field': 'subtitle' } : {};

    // ★ Feature 5: apply per-section text_color + bg_color as inline styles
    //   on the section wrapper. Only set them when the value is non-empty
    //   (so the CSS defaults in theme.css still apply when Morbi hasn't
    //   picked a color yet — defense in depth, no surprise overrides).
    // ★ Feature 2: the hero now has TWO grid children — `.hero-copy` (the
    //   existing text block) and `.hero-image` (a new visual block). The
    //   `.landing-hero` CSS rule in theme.css is `display: grid; grid-
    //   template-columns: 1fr` on mobile and `1.2fr 1fr` on ≥900px, so the
    //   image sits below the copy on mobile and to the right on desktop.
    // ★ Hero image: a real <img> tag (better loading + LCP element) using
    //   the male-01 perfume photo. Falls back to the gradient + flask icon
    //   via onerror if the image fails to load (network/CSP edge cases).
    var sectionStyle = {};
    if (landing.text_color) sectionStyle.color = landing.text_color;
    if (landing.bg_color) sectionStyle.backgroundColor = landing.bg_color;

    return el('section', { class: 'landing-hero', style: sectionStyle }, [
      el('div', { class: 'hero-copy' }, [
        el('p', { class: 'muted', style: { fontSize: '14px', letterSpacing: '2px', textTransform: 'uppercase', marginBottom: '12px' } }, 'Morcenzs by Morbi'),
        el('h1', Object.assign({ class: 'serif' + (editId ? ' admin-editable' : '') }, headingAttrs), [
          el('span', { class: 'gold' }, heroTitle)
        ]),
        el('p', Object.assign({}, subtitleAttrs, editId ? { class: 'admin-editable' } : {}), landing.hero_subtitle || "Discover fragrances made to leave an impression. Find the fragrance that speaks for you. Shop long-lasting scents ranging from crisp florals to rich woody undertones, perfectly suited for any occasion. Delivered conveniently to Accra, Kumasi, and nationwide."),
        el('div', { class: 'hero-cta' }, [
          el('button', {
            class: 'btn-md fill',
            onclick: function () {
              try { sessionStorage.removeItem('morbi:scent-choice'); } catch (e) { /* private mode */ }
              router.navigate('/morcenzs');
            }
          }, 'Visit shop'),
          el('button', {
            class: 'btn-md outline',
            onclick: function () {
              var featSec = document.querySelector('.landing-featured');
              // ★ Phase 10 (2026-09-26): retry once after a short delay if
              //   the featured section hasn't rendered yet (sections still
              //   loading). Was: a single querySelector — if the section
              //   wasn't in the DOM yet, the click silently did nothing
              //   with no feedback. Now: schedule a 200ms retry; if the
              //   section still isn't there, log a console.info so the
              //   admin has a signal (and the user can click again).
              if (featSec) {
                featSec.scrollIntoView({ behavior: 'smooth' });
              } else {
                setTimeout(function () {
                  var retry = document.querySelector('.landing-featured');
                  if (retry) {
                    retry.scrollIntoView({ behavior: 'smooth' });
                  } else if (typeof console !== 'undefined' && console.info) {
                    console.info('[morbi] "View Featured" clicked but the featured section is not in the DOM. Sections may still be loading — click again in a moment.');
                  }
                }, 200);
              }
            }
          }, 'View Featured')
        ])
      ]),
      // ★ Hero image block. Uses an actual <img> tag (better LCP + loading
      //   semantics than a CSS background-image). The src points to the
      //   male-01 perfume photo. The onerror handler swaps to the original
      //   gradient + flask-icon placeholder if the image fails to load.
      el('div', { class: 'hero-image' }, [
        (function () {
          var img = document.createElement('img');
          // ★ Phase 10 (2026-09-26): resolve hero image against basePath so
          //   it renders under clean-path routing (/morbi-shop/dashboard etc.).
          var heroImgPath = 'images/male/male-01.jpeg';
          var router = global.MorbiRouter;
          if (router && typeof router.prependBasePath === 'function') {
            heroImgPath = router.prependBasePath('/' + heroImgPath);
          }
          img.src = heroImgPath;
          img.alt = 'Morcenzs signature perfume bottle';
          // Hero is the LCP element — keep EAGER loading (do NOT lazy-load).
          // ★ Phase 10 (2026-09-26): removed inline width/height/max-height —
          //   now controlled by the .hero-image img CSS rule in styles.css
          //   (max-width: 400px, height: auto, object-fit: contain). The
          //   inline style was overriding the CSS + causing overflow on desktop.
          img.style.cssText = 'display:block;';
          img.onerror = function () {
            var fallback = document.createElement('div');
            fallback.style.cssText = 'width:100%;height:100%;min-height:400px;background:transparent;display:flex;align-items:center;justify-content:center;';
            var icon = document.createElement('i');
            icon.className = 'fas fa-flask hero-image-icon';
            fallback.appendChild(icon);
            if (img.parentNode) img.parentNode.replaceChild(fallback, img);
          };
          return img;
        })()
      ])
    ]);
  }

  // ★ Phase 6 Batch 1c: dynamic hero renderer — reads from the section's
  // content JSON (heading + subtitle). Otherwise identical DOM to renderHero.
  // ★ Task 54: adds contenteditable to heading + subtitle when admin edit
  //   mode is ON. On blur, the text is saved via store.updateSection.
  // ★ Feature 5: passes text_color + bg_color through to renderHero so the
  //   section wrapper picks up Morbi's per-section color choices.
  function renderHeroFromSection(s, featured, currency) {
    var c = s.content || {};
    // Reuse the legacy renderer by adapting the section content into the
    // 8-key landing shape it expects. (Avoids duplicating the hero DOM code.)
    var fakeLanding = {
      hero_title: c.heading || 'A scent full of desire',
      hero_subtitle: c.subtitle || "Discover fragrances made to leave an impression. Find the fragrance that speaks for you. Shop long-lasting scents ranging from crisp florals to rich woody undertones, perfectly suited for any occasion. Delivered conveniently to Accra, Kumasi, and nationwide.",
      text_color: c.text_color || '',
      bg_color: c.bg_color || ''
    };
    // ★ Task 54: if admin edit mode is ON, pass the section id so the
    //   renderHero function can add contenteditable to the right elements.
    //   We do this by stashing the section id on the fakeLanding object —
    //   renderHero reads it from there (backward compat: if not set, the
    //   hero renders without contenteditable as before).
    if (isAdmin() && adminEditMode) {
      fakeLanding._editSectionId = s.id;
    }
    return renderHero(fakeLanding, featured, currency);
  }

  /* ---- About section ------------------------------------------------ */

  function renderAbout(landing) {
    // ★ Task 55: inline editing — contenteditable on heading + paragraphs.
    var editId = landing._editSectionId;
    var h2Attrs = editId ? { contenteditable: 'true', 'data-section-id': String(editId), 'data-field': 'heading' } : {};
    var p1Attrs = editId ? { contenteditable: 'true', 'data-section-id': String(editId), 'data-field': 'paragraph_1' } : {};
    var p2Attrs = editId ? { contenteditable: 'true', 'data-section-id': String(editId), 'data-field': 'paragraph_2' } : {};
    var editClass = editId ? ' admin-editable' : '';
    // ★ Feature 5: apply per-section text_color + bg_color. The about
    //   section's default is white-bg/black-text (theme.css) — Morbi's
    //   inline overrides win when set (CSS specificity: inline > class).
    var sectionStyle = {};
    if (landing.text_color) sectionStyle.color = landing.text_color;
    if (landing.bg_color) sectionStyle.backgroundColor = landing.bg_color;
    return el('section', { class: 'landing-about', style: sectionStyle }, [
      el('div', { class: 'landing-about-inner' }, [
        el('div', {}, [
          el('h2', Object.assign({ class: 'serif' + editClass }, h2Attrs), landing.about_heading || 'Founder & Curator-in-Chief'),
          el('p', Object.assign({ class: editClass.trim() || undefined }, p1Attrs), landing.about_text_1 || "Scent is the most powerful form of self-expression. At Morcenzs, we bring world-class, authentic luxury fragrances directly to perfume lovers across Ghana."),
          el('p', Object.assign({ class: editClass.trim() || undefined }, p2Attrs), landing.about_text_2 || "Every bottle in our collection is carefully sourced for its longevity and craftsmanship, ensuring you always leave a memorable mark—wherever you go, whatever the occasion.")
        ])
        // ★ Removed placeholder image (gradient + fa-user icon) per user request.
      ])
    ]);
  }

  // ★ Phase 6 Batch 1c: dynamic about renderer — adapts the section content
  // (heading + paragraph_1 + paragraph_2) into the 3-key landing shape
  // renderAbout expects.
  // ★ Feature 5: passes text_color + bg_color through to renderAbout.
  function renderAboutFromSection(s) {
    var c = s.content || {};
    var fakeLanding = {
      about_heading: c.heading || 'Founder & Curator-in-Chief',
      about_text_1: c.paragraph_1 || "Scent is the most powerful form of self-expression. At Morcenzs, we bring world-class, authentic luxury fragrances directly to perfume lovers across Ghana.",
      about_text_2: c.paragraph_2 || "Every bottle in our collection is carefully sourced for its longevity and craftsmanship, ensuring you always leave a memorable mark—wherever you go, whatever the occasion.",
      text_color: c.text_color || '',
      bg_color: c.bg_color || ''
    };
    // ★ Task 55: inline editing — stash the section id so renderAbout can
    //   add contenteditable to the heading + paragraph elements.
    if (isAdmin() && adminEditMode) {
      fakeLanding._editSectionId = s.id;
    }
    return renderAbout(fakeLanding);
  }

  /* ---- Featured products --------------------------------------------- */

  function renderFeatured(landing, featured, currency) {
    // ★ Feature 5: apply per-section text_color + bg_color as inline styles
    //   on the section wrapper. The featured section's CSS default is black-
    //   bg/white-text + gold heading; Morbi's inline overrides win when set.
    var sectionStyle = {};
    if (landing.text_color) sectionStyle.color = landing.text_color;
    if (landing.bg_color) sectionStyle.backgroundColor = landing.bg_color;

    var cards = featured.length ? featured.map(function (p) {
      var cat = p.categoryId ? store.getCategory(p.categoryId) : null;
      var imgContainer;
      // ★ Phase 10 (2026-09-26): resolve image path against basePath so the featured grid renders real images under clean-path routing.
      var resolvedImagePath = (store.resolveImagePath && p.imagePath) ? store.resolveImagePath(p.imagePath) : p.imagePath;
      if (resolvedImagePath) {
        // ★ UI-22 fix: switched from a `<div>` with CSS `background-image`
        //   to an `<img>` tag. The storefront's `.menu img:hover` rule
        //   (styles.css ~L143-147) scales the image to 1.05× on hover —
        //   but the CSS selector `img:hover` only matches `<img>` tags,
        //   not `<div>` elements. The previous `<div>` background-image
        //   approach meant hovering a featured card did nothing while
        //   hovering a storefront product card zoomed the image —
        //   inconsistent UX between the landing featured grid + the
        //   storefront product grid. Now both use `<img>` + both get the
        //   hover-zoom effect. The `onerror` fallback (FIX-WF-7) is
        //   preserved — the `<img>`'s onerror swaps to a gradient `<div>`
        //   if the image fails to load.
        var img = document.createElement('img');
        // ★ Phase 10 (2026-09-26): use the resolved (basePath-prefixed) image path.
        img.src = resolvedImagePath;
        img.alt = p.name;
        // ★ PERF-12 (Task 45): featured cards sit below the hero — defer
        // their download until scrolled near. The HERO image above (line
        // ~110) deliberately stays EAGER: it is the LCP element; lazy-loading
        // it would push the largest visible image to the back of the request
        // queue and REGRESS first paint (the audit's fix sketch said "every
        // <img>" — blindly applying it to the hero would have traded one
        // perf problem for a worse one).
        img.loading = 'lazy';
        img.style.cssText = 'width:100%;height:280px;object-fit:cover;display:block;';
        // FIX-WF-7: onerror fallback — swap the broken <img> for a
        // gradient <div> with a placeholder icon. Same visual as before.
        img.onerror = function () {
          var fallback = document.createElement('div');
          fallback.style.cssText = 'width:100%;height:280px;background:linear-gradient(135deg, #1a1a1a, #222222);display:flex;align-items:center;justify-content:center;';
          var icon = document.createElement('i');
          icon.className = 'fas fa-flask';
          icon.style.cssText = 'font-size:48px;color:#333;';
          fallback.appendChild(icon);
          // Replace the broken <img> in the DOM with the fallback <div>.
          if (img.parentNode) {
            img.parentNode.replaceChild(fallback, img);
          }
        };
        imgContainer = img;
      } else {
        imgContainer = el('div', {
          style: {
            width: '100%', height: '280px',
            background: 'linear-gradient(135deg, #1a1a1a, #222222)',
            display: 'flex', alignItems: 'center', justifyContent: 'center'
          }
        }, [el('i', { class: 'fas fa-flask', style: { fontSize: '48px', color: '#333' } })]);
      }
      return el('div', { class: 'menu' }, [
        imgContainer,
        el('div', { class: 'desc-item' }, [
          el('h3', { class: 'card-name' }, p.name),
          p.scent ? el('p', { class: 'card-scent' }, p.scent) : null,
          el('p', { class: 'card-price' }, ui.formatPrice(p.price, currency)),
          p.description ? el('p', { class: 'card-desc' }, p.description) : null
        ]),
        // ★ Feature 3: "+" add-to-cart button. Position: absolute, bottom-
        //   right corner of the .menu card (the .menu rule in styles.css
        //   already has `position: relative` so this anchors correctly).
        //   On click: add the product to the cart (via the exposed
        //   MorbiStorefront.addToCart — it persists to sessionStorage) and
        //   navigate to /morcenzs so the customer sees their cart + can
        //   check out. The button uses the accent color (#FFAA00 /
        //   var(--accent)) per the spec.
        el('button', {
          class: 'featured-add-btn',
          type: 'button',
          'aria-label': 'Add ' + p.name + ' to cart',
          title: 'Add ' + p.name + ' to cart',
          onclick: function () { addFeaturedToCart(p.id); }
        }, [el('i', { class: 'fas fa-plus', 'aria-hidden': 'true' })])
      ]);
    }) : [
      el('p', { class: 'muted', style: { gridColumn: '1 / -1', textAlign: 'center', padding: '40px 0' } },
        'No products yet. Add some in the admin panel.')
    ];

    return el('section', { class: 'landing-featured', style: sectionStyle }, [
      el('h2', Object.assign({ class: 'serif' + (landing._editSectionId ? ' admin-editable' : '') },
        landing._editSectionId ? { contenteditable: 'true', 'data-section-id': String(landing._editSectionId), 'data-field': 'heading' } : {}),
        landing.featured_heading || 'Featured Scents'),
      el('p', Object.assign({ class: 'muted' + (landing._editSectionId ? ' admin-editable' : '') },
        landing._editSectionId ? { contenteditable: 'true', 'data-section-id': String(landing._editSectionId), 'data-field': 'subtitle' } : {}),
        landing.featured_sub || 'A selection from the Morcenzs collection.'),
      el('div', { class: 'featured-grid' }, cards),
      el('div', { class: 'featured-cta' }, [
        el('button', {
          class: 'btn-md fill',
          onclick: function () {
            try { sessionStorage.removeItem('morbi:scent-choice'); } catch (e) { /* private mode */ }
            router.navigate('/morcenzs');
          }
        }, 'View Full Collection')
      ])
    ]);
  }

  // ★ Feature 3: add a featured product to the cart, then navigate to the
  //   storefront. The cart lives in storefront.js (MorbiStorefront.addToCart)
  //   and persists to sessionStorage, so calling it from the landing page
  //   (where the storefront isn't rendered yet) just persists the item —
  //   restorePersistedState() in storefront.js picks it up on the next
  //   render. We clear the scent-choice key first so the scent gate always
  //   appears (same UX fix the old Shop Morcenzs button had).
  function addFeaturedToCart(productId) {
    try { sessionStorage.removeItem('morbi:scent-choice'); } catch (e) { /* private mode */ }
    if (global.MorbiStorefront && typeof global.MorbiStorefront.addToCart === 'function') {
      try { global.MorbiStorefront.addToCart(productId); } catch (e) { /* swallow — still navigate */ }
    }
    router.navigate('/morcenzs');
  }

  // ★ Phase 6 Batch 1c: dynamic featured renderer — adapts the section
  // content (heading + subtitle) into the 2-key landing shape.
  // ★ Feature 5: passes text_color + bg_color through to renderFeatured.
  function renderFeaturedFromSection(s, featured, currency) {
    var c = s.content || {};
    var fakeLanding = {
      featured_heading: c.heading || 'Featured Scents',
      featured_sub: c.subtitle || 'A selection from the Morcenzs collection.',
      text_color: c.text_color || '',
      bg_color: c.bg_color || ''
    };
    if (isAdmin() && adminEditMode) {
      fakeLanding._editSectionId = s.id;
    }
    return renderFeatured(fakeLanding, featured, currency);
  }

  /* ---- Footer ------------------------------------------------------- */

  function renderFooter(landing) {
    // ★ Task 55: inline editing on footer text.
    var editId = landing._editSectionId;
    var textAttrs = editId ? { contenteditable: 'true', 'data-section-id': String(editId), 'data-field': 'text' } : {};
    return el('footer', { class: 'landing-footer' }, [
      el('p', {}, [
        el('span', { class: 'gold' }, 'Morcenzs'),
        ' by Morbi. ',
        el('span', Object.assign({ class: editId ? 'admin-editable' : undefined }, textAttrs), landing.footer_text || 'All rights reserved.')
      ])
    ]);
  }

  function renderFooterFromSection(s) {
    var c = s.content || {};
    var fakeLanding = {
      footer_text: c.text || 'All rights reserved.'
    };
    if (isAdmin() && adminEditMode) {
      fakeLanding._editSectionId = s.id;
    }
    return renderFooter(fakeLanding);
  }

  /* ====================================================================
   * ★ Phase 6 Batch 1c: NEW section type renderers (5 new types).
   * Each renderer takes a section object { content: {...}, ... } and
   * returns a DOM node. All text is plain-text (no innerHTML) — XSS-safe.
   * ==================================================================== */

  /* ---- Promo Banner ------------------------------------------------- */
  // A one-line promo banner with optional link + accent color.
  // ★ Feature 5: also supports text_color + bg_color (overrides the section
  //   wrapper's defaults). The existing accent_color continues to drive the
  //   inner link/text element's background (with auto-contrast text color).
  function renderPromoBanner(s) {
    var c = s.content || {};
    var text = c.text || '';
    var linkUrl = c.link_url || '';
    var accent = c.accent_color || '';
    var textColor = c.text_color || '';
    var bgColor = c.bg_color || '';
    // ★ Task 55: inline editing on the promo banner text.
    var editMode = isAdmin() && adminEditMode;
    var editAttrs = editMode ? { contenteditable: 'true', 'data-section-id': String(s.id), 'data-field': 'text' } : {};
    var editClass = editMode ? ' admin-editable' : '';

    var style = { };
    if (accent) {
      style.background = accent;
      // Auto-contrast the text color: if the accent is dark, use white text;
      // if light, use black. Simple luminance check.
      var m = /^#([0-9a-fA-F]{2})([0-9a-fA-F]{2})([0-9a-fA-F]{2})$/.exec(accent);
      if (m) {
        var r = parseInt(m[1], 16), g = parseInt(m[2], 16), b = parseInt(m[3], 16);
        var luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
        style.color = luminance > 0.5 ? '#000000' : '#ffffff';
      }
    }

    // ★ Feature 5: section-wrapper-level color overrides. bg_color wins
    //   over the .promo-banner CSS default (var(--accent)); text_color wins
    //   over the inner element's auto-contrasted color.
    var sectionStyle = {};
    if (textColor) sectionStyle.color = textColor;
    if (bgColor) sectionStyle.backgroundColor = bgColor;

    var body;
    if (linkUrl) {
      // Use a real <a href> so the link is reachable via right-click +
      // keyboard + middle-click. Internal paths (e.g. /morcenzs) work
      // because the router's popstate handler catches the navigation.
      // External URLs (https://...) open in a new tab via target=_blank
      // (with rel=noopener for safety).
      var isExternal = /^https?:\/\//i.test(linkUrl);
      body = el('a', Object.assign({
        // ★ Phase 10 (2026-09-26): in edit mode, use 'javascript:void(0)'
        //   instead of '#' so clicking the link doesn't change the URL hash
        //   (which the router's migrateHashBookmark could interpret as an
        //   old hash-route on next dispatch, triggering a spurious redirect).
        //   'javascript:void(0)' is the standard no-op href that keeps the
        //   <a> semantically a link (so screen readers announce it) without
        //   causing any navigation. Was: `href: editMode ? '#' : linkUrl`.
        href: editMode ? 'javascript:void(0)' : linkUrl,
        class: 'promo-banner-link' + editClass, style: style,
        target: isExternal ? '_blank' : undefined,
        rel: isExternal ? 'noopener' : undefined,
        // ★ Task 56 (BL-2 fix): when edit mode is ON, disable the link's
        //   onclick so clicking to edit text doesn't navigate away.
        onclick: editMode ? function (e) { e.preventDefault(); } : (isExternal ? undefined : function (e) { e.preventDefault(); router.navigate(linkUrl); })
      }, editAttrs), text);
    } else {
      body = el('div', Object.assign({ class: 'promo-banner-text' + editClass, style: style }, editAttrs), text);
    }

    return el('section', { class: 'promo-banner', style: sectionStyle }, [body]);
  }

  /* ---- CTA Block ---------------------------------------------------- */
  // A call-to-action block with heading, body, and a button.
  function renderCtaBlock(s) {
    var c = s.content || {};
    var heading = c.heading || '';
    var body = c.body || '';
    var buttonText = c.button_text || '';
    var buttonUrl = c.button_url || '';
    var isExternal = /^https?:\/\//i.test(buttonUrl);
    // ★ Task 55: inline editing on heading, body, button_text.
    var editMode = isAdmin() && adminEditMode;
    var editClass = editMode ? ' admin-editable' : '';
    var hAttrs = editMode ? { contenteditable: 'true', 'data-section-id': String(s.id), 'data-field': 'heading' } : {};
    var bAttrs = editMode ? { contenteditable: 'true', 'data-section-id': String(s.id), 'data-field': 'body' } : {};
    var btnAttrs = editMode ? { contenteditable: 'true', 'data-section-id': String(s.id), 'data-field': 'button_text' } : {};

    // ★ Feature 5: per-section text_color + bg_color overrides on the
    //   section wrapper. The .cta-block CSS default is var(--bg-card) bg /
    //   var(--accent) heading — inline overrides win when Morbi sets them.
    var sectionStyle = {};
    if (c.text_color) sectionStyle.color = c.text_color;
    if (c.bg_color) sectionStyle.backgroundColor = c.bg_color;

    return el('section', { class: 'cta-block', style: sectionStyle }, [
      heading ? el('h2', Object.assign({ class: 'cta-block-heading serif' + editClass }, hAttrs), heading) : null,
      body ? el('p', Object.assign({ class: 'cta-block-body' + editClass }, bAttrs), body) : null,
      buttonText ? el('button', Object.assign({
        class: 'btn-md fill cta-block-button' + editClass,
        // ★ Task 56 (BL-1 fix): when edit mode is ON, disable the button's
        //   onclick so clicking to edit button text doesn't navigate away.
        onclick: editMode ? undefined : function () {
          if (isExternal) { window.open(buttonUrl, '_blank', 'noopener'); }
          else if (buttonUrl) { router.navigate(buttonUrl); }
        }
      }, btnAttrs), buttonText) : null
    ]);
  }

  /* ---- Image Spot --------------------------------------------------- */
  // A single image with optional caption + link.
  function renderImageSpot(s) {
    var c = s.content || {};
    // ★ Phase 10 (2026-09-26): resolve image path against basePath (same fix as featured grid).
    var rawImagePath = c.image_path || '';
    var imagePath = (store.resolveImagePath && rawImagePath) ? store.resolveImagePath(rawImagePath) : rawImagePath;
    var caption = c.caption || '';
    var linkUrl = c.link_url || '';
    var isExternal = /^https?:\/\//i.test(linkUrl);
    // ★ Task 55: inline editing on caption only (image_path needs the
    //   dashboard form's file picker — can't inline-edit a file upload).
    var editMode = isAdmin() && adminEditMode;
    var editClass = editMode ? ' admin-editable' : '';
    var capAttrs = editMode ? { contenteditable: 'true', 'data-section-id': String(s.id), 'data-field': 'caption' } : {};

    var img;
    if (imagePath) {
      img = document.createElement('img');
      img.src = imagePath;
      img.alt = caption || '';
      img.loading = 'lazy';
      img.style.cssText = 'width:100%;max-height:480px;object-fit:cover;display:block;border-radius:8px;';
      img.onerror = function () {
        var fallback = document.createElement('div');
        fallback.style.cssText = 'width:100%;height:280px;background:linear-gradient(135deg, #1a1a1a, #222222);display:flex;align-items:center;justify-content:center;border-radius:8px;';
        var icon = document.createElement('i');
        icon.className = 'fas fa-image';
        icon.style.cssText = 'font-size:48px;color:#555;';
        fallback.appendChild(icon);
        if (img.parentNode) img.parentNode.replaceChild(fallback, img);
      };
    } else {
      img = el('div', {
        style: { width: '100%', height: '280px', background: 'linear-gradient(135deg, #1a1a1a, #222222)', display: 'flex', alignItems: 'center', justifyContent: 'center', borderRadius: '8px' }
      }, [el('i', { class: 'fas fa-image', style: { fontSize: '48px', color: '#555' } })]);
    }

    var inner = [img];
    if (caption) inner.push(el('p', Object.assign({ class: 'image-spot-caption' + editClass }, capAttrs), caption));
    else if (editMode) inner.push(el('p', Object.assign({ class: 'image-spot-caption' + editClass }, capAttrs), '(click to add caption)'));

    if (linkUrl) {
      // Wrap in an <a> for accessibility + middle-click support.
      return el('section', { class: 'image-spot' }, [
        el('a', {
          href: linkUrl,
          class: 'image-spot-link',
          target: isExternal ? '_blank' : undefined,
          rel: isExternal ? 'noopener' : undefined,
          onclick: isExternal ? undefined : function (e) {
            e.preventDefault();
            router.navigate(linkUrl);
          }
        }, inner)
      ]);
    }
    return el('section', { class: 'image-spot' }, inner);
  }

  /* ---- Text Block --------------------------------------------------- */
  // A free-form heading + body text block (plain text — no HTML).
  function renderTextBlock(s) {
    var c = s.content || {};
    var heading = c.heading || '';
    var body = c.body || '';
    // ★ Task 55: inline editing on heading + body.
    var editMode = isAdmin() && adminEditMode;
    var editClass = editMode ? ' admin-editable' : '';
    var hAttrs = editMode ? { contenteditable: 'true', 'data-section-id': String(s.id), 'data-field': 'heading' } : {};

    var bodyEl = body ? (function () {
      var e = renderTextBlockBody(body);
      if (editMode) {
        e.setAttribute('contenteditable', 'true');
        e.setAttribute('data-section-id', String(s.id));
        e.setAttribute('data-field', 'body');
        e.classList.add('admin-editable');
      }
      return e;
    })() : null;

    // ★ Feature 5: per-section text_color + bg_color overrides on the
    //   section wrapper. Only set them when non-empty so the .text-block
    //   CSS defaults (white body text + transparent bg) still apply when
    //   Morbi hasn't picked a color yet.
    var sectionStyle = {};
    if (c.text_color) sectionStyle.color = c.text_color;
    if (c.bg_color) sectionStyle.backgroundColor = c.bg_color;

    return el('section', { class: 'text-block', style: sectionStyle }, [
      heading ? el('h2', Object.assign({ class: 'text-block-heading serif' + editClass }, hAttrs), heading) : null,
      bodyEl
    ]);
  }

  function renderTextBlockBody(body) {
    // Split on double-newlines → paragraphs. Single newlines within a
    // paragraph become spaces (preserves the "plain text, no HTML" rule).
    var paragraphs = String(body).split(/\n\s*\n/);
    if (paragraphs.length <= 1) {
      return el('p', { class: 'text-block-body' }, body);
    }
    return el('div', { class: 'text-block-body' },
      paragraphs.map(function (p) {
        return el('p', {}, p.replace(/\s+/g, ' ').trim());
      })
    );
  }

  /* ---- Spacer ------------------------------------------------------- */
  // Vertical whitespace (1-200px). Server validates the range.
  function renderSpacer(s) {
    var c = s.content || {};
    var height = parseInt(c.height, 10);
    if (isNaN(height) || height < 1) height = 40;
    if (height > 200) height = 200;
    return el('section', {
      class: 'spacer',
      style: { height: height + 'px' },
      // aria-hidden so screen readers skip it (it's purely decorative).
      'aria-hidden': 'true'
    });
  }

  global.MorbiLanding = { render: render };
})(window);
