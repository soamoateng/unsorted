/**
 * payment-callback.js — Phase 2 (Bicycle) payment-callback route handler.
 *
 * Paystack redirects the customer back to the URL we passed as
 * PAYSTACK_CALLBACK_URL (api/_config.php), which lands them at
 * `#/payment-callback?reference=morbi-123-abc&trxref=...&status=...`.
 *
 * The router parses the query string and hands it to this module's render()
 * via params.query. We:
 *   1. Show a "Verifying your payment…" spinner.
 *   2. Call GET api/orders.php?action=verify&reference=XYZ — the server
 *      calls Paystack /transaction/verify/{reference} directly (defense in
 *      depth — the webhook may have fired first, but verifying via the API
 *      is authoritative per Paystack's docs).
 *   3. Render the success / failure / pending page based on the returned
 *      order.paystack_status.
 *   4. If status is still 'pending' after verify, the webhook may not have
 *      fired yet — show a "We're confirming your payment — check back in a
 *      moment" message + a "Refresh status" button.
 *
 * Public API: MorbiPaymentCallback.render(params) — matches the shape every
 * other route handler uses (router calls handler(matched.params)).
 */
(function (global) {
  'use strict';

  var ui = global.MorbiUI;
  var el = ui.el, clear = ui.clear, formatPrice = ui.formatPrice;
  var router = global.MorbiRouter;

  var ROOT_ID = 'app-root';
  var API_BASE = 'api/';

  /* ★ WF-02 + WF-03 fix: storage keys mirrored from js/storefront.js.
   *   When the payment SUCCEEDS, the persisted cart + discount code must
   *   be wiped — otherwise "Continue Shopping" boots the storefront with
   *   the sessionStorage restore (storefront.js restorePersistedState)
   *   resurrecting the very items the customer just BOUGHT, inviting an
   *   accidental duplicate order. On failed/abandoned outcomes the keys
   *   are deliberately KEPT: restoring cart + code is the whole point of
   *   the retry path (WF-02/03). Key literals are duplicated here (not
   *   imported) because the storefront module exposes no storage API —
   *   if you rename them there, rename them here too. */
  var PERSIST_CART_KEY = 'morbi:cart-v1';
  var PERSIST_DISCOUNT_KEY = 'morbi:discount-code';

  function clearPersistedPurchaseState() {
    try {
      sessionStorage.removeItem(PERSIST_CART_KEY);
      sessionStorage.removeItem(PERSIST_DISCOUNT_KEY);
    } catch (e) { /* private mode — nothing persisted anyway */ }
  }

  /* ---- UX-17: auto-refresh backoff state ------------------------------ *
   * MoMo settlements in Ghana routinely take 30+ seconds. The old code
   * scheduled exactly ONE auto-refresh 5s after landing; if that second
   * verify was still pending, the customer was stuck staring at "Payment
   * Confirming…" with only a manual button and no idea whether anything
   * was still happening. Now the page keeps checking on a backoff:
   *   - attempts 1-6   → every 5s   (covers the first ~30s)
   *   - attempts 7-13  → every 15s  (covers the next ~105s, ~2min total)
   *   - after attempt 13 → stop auto-refreshing and show a "still
   *     confirming — check your email/SMS or contact Morbi" message.
   * The manual Refresh button always resets the cycle (it passes no _auto
   * flag, so attempts restart from 0).
   */
  var AUTO_REFRESH_FAST_COUNT = 6;    // 6 × 5s ≈ 30s
  var AUTO_REFRESH_MAX = 13;          // +7 × 15s ≈ 105s → ~2min 15s total
  var autoRefreshAttempts = 0;
  var autoRefreshTimer = null;

  /* ---- Public render -------------------------------------------------- */
  function render(params) {
    var query = (params && params.query) || {};
    var reference = query.reference || query.trxref || '';

    // ★ UX-17 fix: manual visits (route entry, Refresh button, Continue
    //   Shopping → back) reset the backoff cycle; auto-refresh calls pass
    //   _auto=true and keep the attempt counter climbing. Also cancel any
    //   in-flight auto-refresh timer so re-renders never stack duplicates.
    if (!(params && params._auto)) {
      autoRefreshAttempts = 0;
    }
    if (autoRefreshTimer) {
      clearTimeout(autoRefreshTimer);
      autoRefreshTimer = null;
    }

    var root = document.getElementById(ROOT_ID);
    if (!root) return;
    clear(root);

    if (!reference) {
      renderError(root, 'No payment reference found in the URL.',
        'If you just completed a payment, please check your SMS or email for the order confirmation. ' +
        'If you think this is an error, please contact Morbi.');
      return;
    }

    // Step 1: render the spinner + start the verify round-trip.
    renderVerifying(root, reference);
    verifyOrder(reference).then(function (res) {
      // The server returns the FULL order + verified flag.
      var order = res && res.order;
      if (!order) {
        renderError(root, 'Order not found.',
          'Reference: ' + reference + '. This order may have been removed.');
        return;
      }
      renderResult(root, order, res.verified, res.verify_error);
    }).catch(function (err) {
      // ★ Phase 10 (2026-09-26): suppress the "Try Again" error UI when the
      //   rejection was just because a newer verify request superseded this
      //   one (the newer call's .then() is rendering the latest result; we
      //   don't want to flash the older call's stale error message).
      if (err && err.superseded) return;
      renderError(root, 'Could not verify your payment.',
        (err && err.message) || 'Network error. Please try again in a moment. Reference: ' + reference,
        // ★ Blind-spot fix (Task 43, UX-17 neighborhood): pass the reference
        //   so renderError can offer a "Try Again" retry — a network glitch
        //   during verification used to dead-end on an error page whose
        //   only way out was leaving the site, while the payment itself
        //   may have succeeded.
        reference);
    });
  }

  /* ---- Verifying spinner ---------------------------------------------- */
  function renderVerifying(root, reference) {
    root.appendChild(
      el('div', { class: 'container' }, [
        el('div', { class: 'main-body' }, [
          el('div', { class: 'payment-callback-panel', style: { textAlign: 'center', padding: '60px 20px' } }, [
            el('i', { class: 'fas fa-spinner fa-spin', style: { fontSize: '48px', color: 'var(--accent)', marginBottom: '20px' } }),
            el('h2', { style: { color: '#ffffff', marginBottom: '10px' } }, 'Verifying your payment…'),
            el('p', { class: 'muted' }, 'Please wait while we confirm with Paystack.'),
            el('p', { class: 'small', style: { marginTop: '12px' } }, 'Reference: ' + reference)
          ])
        ])
      ])
    );
  }

  /* ---- Result (success / failed / pending) ---------------------------- */
  function renderResult(root, order, verified, verifyError) {
    clear(root);
    // ★ WF-02 + WF-03 fix: a PAID outcome means the purchase is done —
    //   wipe the persisted cart + discount code NOW (before the customer
    //   clicks "Continue Shopping") so the storefront's boot-restore can't
    //   resurrect already-purchased items into a fresh cart. Deliberately
    //   NOT wiped for pending/failed/abandoned — those outcomes need the
    //   restored cart + code for the retry flow. Idempotent: re-renders
    //   of an already-paid order just re-remove the same keys.
    if (order.paystack_status === 'paid') {
      clearPersistedPurchaseState();
    }
    // ★ RT-05 fix: guard against null/undefined paystack_status. The column
    //   is VARCHAR(20) NOT NULL DEFAULT 'pending' in the schema, but the
    //   audit flags edge cases: a row inserted directly via SQL with
    //   paystack_status=NULL, or a future schema change. Without this guard,
    //   `status.toUpperCase()` on line ~134 throws TypeError → unhandled
    //   rejection → the callback page stays on the spinner forever.
    //   Fix: fall back to 'unknown' if status is falsy. The rendering below
    //   already handles non-paid/non-pending/non-abandoned statuses via the
    //   'Failed' fallback in the title/subtitle.
    var status = order.paystack_status || 'unknown';
    var isSuccess = status === 'paid';
    var isPending = status === 'pending';

    var iconClass = isSuccess ? 'fas fa-check-circle' : (isPending ? 'fas fa-clock' : 'fas fa-times-circle');
    var iconColor = isSuccess ? 'var(--ok)' : (isPending ? 'var(--accent)' : 'var(--danger)');
    var title = isSuccess ? 'Payment Successful!'
              : isPending ? 'Payment Confirming…'
              : 'Payment ' + (status === 'abandoned' ? 'Abandoned' : 'Failed');

    var subtitle = isSuccess
      ? 'Thank you, ' + order.customer_name + '! Your order has been confirmed.'
      : isPending
        ? (verifyError
            ? 'We could not reach Paystack to confirm. Please click "Refresh Status" below.'
            : 'We\u2019re still confirming your payment with Paystack. This usually takes a few seconds.')
        : (status === 'abandoned'
            ? 'You closed the payment window before completing. You can try again.'
            : 'The payment was not successful. Please try again or contact Morbi for help.');

    // ★ UX-17 fix: shown once the backoff cycle is exhausted (~2min) — the
    //   customer is no longer left wondering whether the page gave up.
    var gaveUpAutoRefresh = isPending && autoRefreshAttempts >= AUTO_REFRESH_MAX;
    var gaveUpNote = gaveUpAutoRefresh
      ? el('p', { class: 'muted', style: { marginTop: '10px', fontSize: '13px' } },
          'This is taking longer than usual. Mobile Money payments can take a few minutes to settle \u2014 '
          + 'your payment may still complete. Keep this page open and use "Refresh Status", '
          + 'or check your email/SMS confirmation, or contact Morbi for help.')
      : null;

    root.appendChild(
      el('div', { class: 'container' }, [
        el('div', { class: 'main-body' }, [
          el('div', { class: 'payment-callback-panel', style: { textAlign: 'center', padding: '40px 20px', maxWidth: '600px', margin: '0 auto' } }, [
            el('i', { class: iconClass, style: { fontSize: '64px', color: iconColor, marginBottom: '20px' } }),
            el('h2', { style: { color: '#ffffff', marginBottom: '10px' } }, title),
            el('p', { class: 'muted', style: { marginBottom: '20px' } }, subtitle),
            gaveUpNote,
            el('div', { class: 'panel', style: { textAlign: 'left', marginBottom: '20px' } }, [
              el('h3', { class: 'panel-title', style: { fontSize: '16px' } }, 'Order Summary'),
              el('div', { class: 'panel-body' }, [
                el('div', { style: { display: 'flex', justifyContent: 'space-between', marginBottom: '8px' } }, [
                  el('span', { class: 'muted' }, 'Reference'),
                  el('span', { style: { fontFamily: 'monospace' } }, order.reference)
                ]),
                el('div', { style: { display: 'flex', justifyContent: 'space-between', marginBottom: '8px' } }, [
                  el('span', { class: 'muted' }, 'Status'),
                  // ★ Phase 10 (2026-09-26): defense in depth — String(status)
                  //   guards against a future server regression returning an
                  //   integer status code (e.g. 200) instead of the documented
                  //   string ('paid'). Without the cast, status.toUpperCase()
                  //   would throw TypeError → unhandled rejection → the
                  //   callback page would hang on the spinner forever.
                  el('strong', { style: { color: iconColor } }, String(status).toUpperCase())
                ]),
                order.paystack_channel ? el('div', { style: { display: 'flex', justifyContent: 'space-between', marginBottom: '8px' } }, [
                  el('span', { class: 'muted' }, 'Channel'),
                  el('span', {}, order.paystack_channel)
                ]) : null,
                el('div', { style: { display: 'flex', justifyContent: 'space-between', marginBottom: '8px' } }, [
                  el('span', { class: 'muted' }, 'Total'),
                  el('strong', { style: { color: 'var(--accent)' } }, formatPrice(order.total_amount, order.currency))
                ]),
                el('hr', { style: { borderColor: 'var(--border)', margin: '12px 0' } }),
                // ★ RT-04 fix: guard against missing/null order.items. Was
                //   `order.items.map(...)` — if the server returned an order
                //   with no items field (legacy order whose order_items were
                //   cascaded out by ON DELETE CASCADE, or any code path where
                //   fetch_items() returns [] and map_order_public() happens to
                //   omit the key), `.map()` was invoked on undefined → TypeError
                //   → unhandled rejection → the callback page stays on the
                //   spinner forever. The customer thinks their payment failed.
                //   Fix: `(order.items || []).map(...)` — mirrors the guard
                //   pattern in dashboard.js line ~1569 (`(o.items || []).map`).
                (order.items || []).map(function (it) {
                  return el('div', { style: { display: 'flex', justifyContent: 'space-between', marginBottom: '6px' } }, [
                    el('span', {}, it.qty + '× ' + it.name),
                    el('span', { class: 'muted' }, formatPrice(it.price * it.qty, order.currency))
                  ]);
                })
              ])
            ]),
            el('div', { class: 'form-actions', style: { justifyContent: 'center', gap: '12px' } }, [
              isPending
                ? el('button', {
                    class: 'btn-md fill',
                    onclick: function () { render({ query: { reference: order.reference } }); }
                  }, [el('i', { class: 'fas fa-sync-alt', style: { marginRight: '8px' } }), 'Refresh Status'])
                : null,
              el('button', {
                class: 'btn-md outline',
                onclick: function () { router.navigate('/morcenzs'); }
              }, 'Continue Shopping'),
              el('button', {
                class: 'btn-md outline',
                onclick: function () { router.navigate('/'); }
              }, 'Home')
            ])
          ])
        ])
      ])
    );

    // ★ UX-17 fix: keep auto-refreshing while pending — 5s intervals for
    //   the first ~30s, then 15s intervals up to ~2min total, then stop
    //   (gaveUpNote above explains the situation and the manual button
    //   remains). The old one-shot timer left the customer stranded after
    //   a single retry. Each scheduled fire increments the attempt counter
    //   and re-renders with _auto=true so the cycle isn't reset. Skipped
    //   entirely when the tab is no longer on the payment-callback route.
    if (isPending && autoRefreshAttempts < AUTO_REFRESH_MAX) {
      var delay = autoRefreshAttempts < AUTO_REFRESH_FAST_COUNT ? 5000 : 15000;
      autoRefreshTimer = setTimeout(function () {
        autoRefreshTimer = null;
        // ★ L10 fix (audit): also check document visibility — if the customer
        //   switched tabs, the timer still fires but the re-render is wasted.
        //   The route check below already prevents the re-render; this just
        //   avoids scheduling unnecessary work. Also: clear the timer on
        //   route change via a one-time popstate listener.
        // ★ Phase 10 (2026-09-26): was `location.pathname.indexOf('payment-callback') !== -1`
        //   which matched ANY path containing the substring (e.g.
        //   /foo/payment-callback-bar). Now uses an exact-match OR
        //   path-with-segment-slash check (mirrors the dashboard's
        //   /dashboard guard). The router's stripBasePath is used if
        //   available so this works on /morbi-shop/payment-callback too.
        var p = (global.MorbiRouter && typeof global.MorbiRouter.stripBasePath === 'function')
          ? global.MorbiRouter.stripBasePath(global.location.pathname)
          : global.location.pathname;
        p = p || '';
        if (p === '/payment-callback' || p.indexOf('/payment-callback/') === 0) {
          autoRefreshAttempts++;
          render({ query: { reference: order.reference }, _auto: true });
        }
      }, delay);
    }

    // ★ L10 fix (audit): clean up the timer on route change. Without this,
    //   the timer fires 5-15s after the customer navigates away. The route
    //   check prevents the re-render, but the timer reference is held until
    //   it fires. This one-time popstate listener clears it on any navigation.
    // ★ Phase 10 (2026-09-26): also reset autoRefreshAttempts so a fresh
    //   /payment-callback visit (for a DIFFERENT order) starts the backoff
    //   cycle from 0. Was: only the timer was cleared — the attempt counter
    //   carried over, so if the customer had used up all attempts on order A
    //   and then came back to /payment-callback for order B, the auto-refresh
    //   never fired (attempts >= MAX) even though B was still pending.
    if (!global._morbiPaymentCallbackCleanupWired) {
      global._morbiPaymentCallbackCleanupWired = true;
      global.addEventListener('popstate', function () {
        if (autoRefreshTimer) {
          clearTimeout(autoRefreshTimer);
          autoRefreshTimer = null;
        }
        // ★ Phase 10: reset the attempt counter so the next /payment-callback
        //   visit starts a fresh backoff cycle. (render() also resets it on
        //   manual entry via the !params._auto check at line ~80, but the
        //   popstate listener covers the Back-button case where render()
        //   isn't called by the user.)
        autoRefreshAttempts = 0;
      });
      // ★ Phase 10: also listen for the router's morbi:route event so
      //   programmatic navigation (router.navigate(...)) also resets.
      global.addEventListener('morbi:route', function () {
        if (autoRefreshTimer) {
          clearTimeout(autoRefreshTimer);
          autoRefreshTimer = null;
        }
        autoRefreshAttempts = 0;
      });
    }
  }

  /* ---- Error fallback ------------------------------------------------- */
  // ★ Blind-spot fix (Task 43): optional 4th param `reference` — when the
  //   caller has one (i.e. the failure happened mid-verification, not a
  //   missing-reference deep-link), render a "Try Again" button that
  //   re-runs the verify round-trip instead of forcing the customer off
  //   the page to find out whether their payment went through.
  function renderError(root, title, message, reference) {
    root.appendChild(
      el('div', { class: 'container' }, [
        el('div', { class: 'main-body' }, [
          el('div', { class: 'payment-callback-panel', style: { textAlign: 'center', padding: '60px 20px' } }, [
            el('i', { class: 'fas fa-exclamation-triangle', style: { fontSize: '64px', color: 'var(--danger)', marginBottom: '20px' } }),
            el('h2', { style: { color: '#ffffff', marginBottom: '10px' } }, title),
            el('p', { class: 'muted' }, message),
            el('div', { class: 'form-actions', style: { justifyContent: 'center', marginTop: '20px' } }, [
              reference ? el('button', {
                class: 'btn-md fill',
                onclick: function () { render({ query: { reference: reference } }); }
              }, [el('i', { class: 'fas fa-rotate-right', style: { marginRight: '8px' } }), 'Try Again']) : null,
              el('button', {
                class: 'btn-md outline',
                onclick: function () { router.navigate('/morcenzs'); }
              }, 'Back to Store')
            ])
          ])
        ])
      ])
    );
  }

  /* ---- API call ------------------------------------------------------- */
  // ★ Phase 10 (2026-09-26): added request-id tracking + a 30s timeout via
  //   AbortController. Was: a bare fetch() with no timeout — if the server
  //   hung (rare, but possible on a misbehaving cPanel host), the verify
  //   Promise never resolved and the user was stuck on the spinner forever
  //   with no recovery path. Also: no request-id guard, so clicking
  //   "Try Again" rapidly could let an older fetch's success overwrite a
  //   newer fetch's pending state.
  var _verifyReqId = 0;
  function verifyOrder(reference) {
    var myReqId = ++_verifyReqId;
    // 30s timeout — generous for slow networks, short enough that the user
    // gets a clear "could not verify" message instead of an infinite spinner.
    // AbortController is supported on all modern browsers (Chrome 66+,
    // Firefox 57+, Safari 11.1+); fall back to a manual setTimeout if
    // AbortController is unavailable (very old browsers).
    var controller = (typeof AbortController !== 'undefined') ? new AbortController() : null;
    var signal = controller ? controller.signal : undefined;
    var timeoutId = setTimeout(function () {
      if (controller) controller.abort();
    }, 30000);

    return fetch(API_BASE + 'orders.php?action=verify&reference=' + encodeURIComponent(reference), {
      method: 'GET',
      credentials: 'same-origin',
      signal: signal
    }).then(function (res) {
      return res.text().then(function (text) {
        var json = null;
        try { json = text ? JSON.parse(text) : null; } catch (e) { json = null; }
        if (!res.ok || !json || json.ok !== true) {
          var message = (json && json.error) || ('Request failed (HTTP ' + res.status + ').');
          var err = new Error(message);
          err.status = res.status;
          throw err;
        }
        return json.data;
      });
    }).then(function (data) {
      // Stale-response guard: a newer verifyOrder() call superseded this one
      // (e.g. the user clicked "Try Again" before this fetch resolved).
      // Bail out — the newer call's .then() will render the correct result.
      if (myReqId !== _verifyReqId) {
        var stale = new Error('Superseded by a newer verify request.');
        stale.superseded = true;
        throw stale;
      }
      return data;
    }).catch(function (err) {
      // Translate AbortError into a friendlier message — the raw error name
      // ('AbortError') leaks implementation detail.
      if (err && err.name === 'AbortError') {
        var timeoutErr = new Error('Verification timed out. Please try again.');
        timeoutErr.timeout = true;
        throw timeoutErr;
      }
      // Stale-response guard: re-throw only if this call is still current.
      if (myReqId !== _verifyReqId && !(err && err.superseded)) {
        var swallow = new Error('Superseded by a newer verify request.');
        swallow.superseded = true;
        throw swallow;
      }
      throw err;
    }).then(function (data) {
      // Clear the timeout on success — the abort controller is no longer needed.
      if (timeoutId) clearTimeout(timeoutId);
      return data;
    }, function (err) {
      // Also clear on the error path so we don't leave a dangling timer.
      if (timeoutId) clearTimeout(timeoutId);
      throw err;
    });
  }

  global.MorbiPaymentCallback = { render: render };
})(window);
