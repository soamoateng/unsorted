/**
 * dashboard.js — Admin panel for morbi.shop
 *
 * Three tabs:
 *   1. Products CRUD (name, scent, price, category, image, description, available)
 *   2. Categories CRUD (name, description, sort order)
 *   3. Landing Content (editable sections)
 *
 * FIX-WF-4: flashStatus now uses inline status element instead of alert().
 * FIX-WF-5: loadDemoProducts checks for duplicate names.
 * FIX-WF-6: Photo preview updates on file selection.
 * FIX-BL-4/5: Price validation rejects empty/zero values.
 * FIX-BL-8: updateCategory no longer mutates caller's patch object.
 * FIX-BL-9: Currency validated (1-5 chars, letters/symbols only).
 * FIX-BL-18: Currency symbol stored as plain string with validation.
 * FIX-WF-8: Tab switch warns about unsaved data before re-rendering.
 * FIX-BL-16: Image compression preserves PNG format for transparency.
 *
 * PHASE-0 (Unicycle) changes — data lives in MySQL now:
 *   - PHASE-0-AUTH: dashboard renders a login panel until MorbiStore
 *     reports an admin session; a Logout button sits in the header.
 *   - PHASE-0-ASYNC: every store mutation is a server round-trip that
 *     returns a Promise. Save buttons disable while a request is in flight
 *     (double-submit guard — impossible when the store was synchronous).
 *   - PHASE-0-BACKUP: Export/Import Backup buttons in the Landing tab feed
 *     the one-time localStorage -> MySQL migration (api/import.php).
 *   - Failure flashes show the server's error message instead of
 *     'Save failed. Storage full?' (storage limits no longer apply).
 *
 * PHASE-1 (Scooter) changes — design tokens / Bootstrap activation:
 *   - PHASE-1-BS5: ensureBootstrap() lazily loads the vendored Bootstrap 5.3.8
 *     stylesheet into <head> the first time the dashboard renders, and only
 *     then (the public landing/storefront never load it). BS5 is scoped to
 *     the admin route per the locked decision in PROJECT-ROADMAP §3.
 *   - PHASE-1-THEME: a fourth tab 'Theme' is added with a color picker + hex
 *     text input for each of the 11 design tokens. Live preview fires on
 *     every input change via store.applyTokens(formMap) (no save needed to
 *     see the effect). Save commits to api/tokens.php; Reset to Defaults
 *     POSTs {action:'reset'} and the theme snaps back to the catalog values.
 *
 * PHASE-1 Batch 2 (Scooter) changes — image uploads to filesystem:
 *   - PHASE-1-UPLOAD: handleProductSave now uploads the photo to
 *     api/upload.php (multipart/form-data) and stores the returned
 *     uploads/<filename> path in products.image_path. Phase 0's
 *     base64-in-MEDIUMTEXT approach is retired for new products;
 *     legacy rows still render (read-compat — <img src> accepts both
 *     URLs and data URLs). compressImageToBlob() lives in ui-helpers.js
 *     and is the live image-resize helper for the upload path.
 *     ★ OTH-17 fix (iteration 25): the in-file `compressImage()` helper
 *     that used to live in this file (Phase 0-era, dead since Phase 1
 *     Batch 2 when the upload path switched to ui-helpers.compressImageToBlob
 *     + uploadImage) has been removed. It was never called by any code in
 *     the codebase (verified by grep). The file-header note that said
 *     "the old compressImage() is retained for diff readability — dead code
 *     is harmless" is updated here too.
 *
 * PHASE-1 Batch 3 (Scooter) changes — CMS polish:
 *   - PHASE-1-RENAME (R1): `ChowMenuUI` / `ChowMenuRouter` references
 *     updated to `MorbiUI` / `MorbiRouter` (the alias shims in those files
 *     keep any external code referencing the old names working).
 *   - PHASE-1-MIGRATE-IMAGES: a "Migrate Images" button in the Landing tab
 *     triggers a two-step flow — dry-run preview (scan + report counts,
 *     write nothing), then a confirm dialog + real migration. The endpoint
 *     api/migrate-images.php scans every products.image_path matching the
 *     base64 pattern, decodes the bytes, writes them to uploads/<safe-name>,
 *     and UPDATEs the row's image_path. Idempotent — safe to re-run.
 *     Existing base64 rows still render (read-compat) — this tool just
 *     converts them in bulk so the DB doesn't carry base64 bloat forever.
 *
 * PHASE-3 Batch 1 (Motorcycle) changes — CSRF:
 *   - PHASE-3-CSRF: uploadImage() now attaches X-CSRF-Token manually
 *     (multipart bypasses store.api() so the header doesn't go out
 *     automatically). Reads the token via store.getCsrfToken().
 *
 * PHASE-3 Batch 2 (Motorcycle) changes — Orders tab (NEW):
 *   - PHASE-3-ORDERS: a fifth tab "Orders" lets Morbi view every Paystack
 *     order without touching SQL. Filter by status (Pending/Paid/Failed/
 *     Abandoned/Deleted), click View to inspect the full order (customer
 *     phone + email + payment fees + items snapshot), and soft-delete
 *     orders for cleanup (the audit trail stays in the DB).
 *   - Replaces the manual phpMyAdmin workflow documented in PAYSTACK.md §5.
 *
 * PHASE-3 Batch 3 (Motorcycle) changes — password recovery + session-expiry:
 *   - PHASE-3-RECOVERY: the login panel now has a "Forgot password?" link
 *     that switches to an email-entry form. Calls store.requestPasswordReset
 *     (api/forgot-password.php). The server ALWAYS returns {sent: true}
 *     (anti-enumeration). The reset link points to #/reset-password?token=…
 *     which is handled by the new js/reset-password.js module.
 *   - PHASE-3-SESSION: when store.api() receives a 401 AND the user was
 *     previously authed (session expired mid-use), it fires
 *     store.onSessionExpired (set by dashboard.js to showReAuthModal).
 *     The modal asks the user to re-enter their password (username
 *     pre-filled from adminName). On success: close modal + re-render the
 *     current tab. On cancel: navigate to #/. Unsaved form data stays in
 *     the DOM (the modal is an overlay, not a navigation) — so edits are
 *     NOT lost. The original failed request rejects normally — the user
 *     retries after re-auth.
 *
 * PHASE-3 Batch 4 (Motorcycle) changes — server-side reset + inventory:
 *   - PHASE-3-RESET: the old local-only "Reset Everything" button (which
 *     only cleared localStorage) is replaced by "Reset to Defaults" which
 *     calls store.resetDefaults() → api/reset-defaults.php (transactional
 *     server-side reset of products + categories + landing + currency +
 *     design tokens to their install-time defaults). Admin account, orders,
 *     and audit trails are preserved. Two-step confirm dialog shows the
 *     user what will be deleted + what's preserved before committing.
 *   - PHASE-3-INVENTORY: the product editor gains a "Stock" field. Empty
 *     = unlimited (no tracking — backward compat for Phase 0-3 products).
 *     Number = tracked (decremented automatically when an order transitions
 *     to 'paid'). 0 = out of stock (checkout refused in payments.php with
 *     422 "X is out of stock"). Stock is read in handleProductSave,
 *     validated, sent to the server, and re-loaded in fillProductEditor.
 */
(function (global) {
  'use strict';

  var ui = global.MorbiUI;
  var el = ui.el, clear = ui.clear, formatPrice = ui.formatPrice,
      fileToDataURL = ui.fileToDataURL, compressImageToBlob = ui.compressImageToBlob;
  var store = global.MorbiStore;
  var router = global.MorbiRouter;

  var ROOT_ID = 'app-root';
  var activeTab = 'products';

  /* ---- Main render -------------------------------------------------- */

  function render() {
    // PHASE-0: the dashboard is admin-only. Until a session exists, render
    // the login panel instead of the admin tabs.
    if (!store.isAdmin()) {
      renderLogin();
      return;
    }
    doRender();
  }

  function doRender() {
    // PHASE-1: Bootstrap 5 CSS loads ONLY when the admin dashboard renders.
    // The public landing/storefront routes never trigger this, so their UI
    // is unaffected (locked decision in PROJECT-ROADMAP §3).
    ensureBootstrap();

    var root = document.getElementById(ROOT_ID);
    clear(root);

    root.appendChild(
      el('div', { class: 'container dashboard' }, [
        el('div', { class: 'main-body' }, [
          renderHeader(),
          el('div', { class: 'dash-content' }, buildDashContent())
        ])
      ])
    );

    bindActivePanel();
  }

  // ★ PERF-06 helpers (Task 45): the active tab's content nodes + binding
  // were inlined in doRender(); extracting them lets renderActivePanel()
  // rebuild JUST .dash-content (status span + tab bar + active panel) while
  // keeping the header — the difference between "one row changed" and
  // "rebuild the entire shell + re-attach everything" after every save,
  // delete, tab switch, import, or theme change. Element-for-element the
  // same nodes doRender() built, so behavior is identical.
  function buildDashContent() {
    return [
      // FIX-WF-4: Status text element for flashStatus
      el('span', { class: 'status-text', id: 'dash-status' }),
      renderTabs(),
      panelFor(activeTab)
    ];
  }

  function panelFor(tab) {
    if (tab === 'products') return renderProductsPanel();
    if (tab === 'categories') return renderCategoriesPanel();
    if (tab === 'landing') return renderSectionsPanel();
    if (tab === 'orders') return renderOrdersPanel();
    if (tab === 'discounts') return renderDiscountsPanel();
    if (tab === 'analytics') return renderAnalyticsPanel();
    if (tab === 'theme') return renderThemePanel();
    // ★ Phase 8 Batch 2 (Task 59): Admins tab — super_admin only.
    if (tab === 'admins') return renderAdminsPanel();
    // ★ Phase 8 Batch 3 (Task 60): Currencies tab — super_admin only.
    if (tab === 'currencies') return renderCurrenciesPanel();
    return null;
  }

  function bindActivePanel() {
    if (activeTab === 'products') bindProductForm();
    if (activeTab === 'categories') bindCategoryForm();
    if (activeTab === 'landing') bindSectionsPanel();
    if (activeTab === 'orders') bindOrdersPanel();
    if (activeTab === 'discounts') bindDiscountsPanel();
    if (activeTab === 'analytics') bindAnalyticsPanel();
    if (activeTab === 'theme') bindThemeForm();
    // ★ Phase 8 Batch 2 (Task 59): Admins tab binding.
    if (activeTab === 'admins') bindAdminsPanel();
    // ★ Phase 8 Batch 3 (Task 60): Currencies tab binding.
    if (activeTab === 'currencies') bindCurrenciesPanel();
  }

  // ★ PERF-06 fix (Task 45): swap ONLY .dash-content's children. Call sites
  // converted from doRender(): every post-mutation re-render (product
  // save/delete, demo load, category save/delete, discount save/delete,
  // theme save/reset, import, migrate, reset-defaults) + the tab switch.
  // The header (logo + 3 icon buttons) is static — rebuilding it re-created
  // ~30 nodes + 3 listeners for zero change, and on a 50-product catalog a
  // single Save rebuilt ~300 nodes + ~100 listeners when ONE row changed.
  // Falls back to a full doRender() when the shell isn't present (e.g.
  // login/logout paths that switch between the login panel and the shell).
  function renderActivePanel() {
    ensureBootstrap();
    // ★ Blind-spot hardening (Task 45): renderLogin() ALSO renders a
    //   .dash-content container (login/forgot forms live inside one) — so
    //   testing only for the container's existence is NOT enough to know
    //   the admin shell is on screen. Every renderActivePanel call site is
    //   admin-only today, but a stray future call while logged out would
    //   otherwise WIPE the login form and build a panel inside it. The
    //   .dash-tabs signature (only renderTabs() creates it) proves the
    //   real shell is present; anything else falls back to a full render.
    var content = document.querySelector('#app-root .dash-content');
    if (!content || !content.querySelector('.dash-tabs')) { doRender(); return; }
    clear(content);
    buildDashContent().forEach(function (node) {
      if (node) content.appendChild(node);
    });
    bindActivePanel();
  }

  /* ---- Header ------------------------------------------------------- */

  function renderHeader() {
    // ★ Feature 1: replace 3 separate icon buttons (Storefront, Landing page,
    //   Log out) with a single hamburger menu button (fas fa-bars) that opens
    //   a dropdown with the 3 items as clickable menu items. The dropdown
    //   closes on outside click, Escape key, and after a menu item is clicked.
    //   The shared helper (ui.renderHeaderMenu) lives in ui-helpers.js; the
    //   dark-theme dropdown styling lives in styles.css (.header-menu-*).
    var menu = ui.renderHeaderMenu([
      {
        label: 'Storefront',
        icon: 'fas fa-store',
        onclick: function () { router.navigate('/morcenzs'); }
      },
      {
        label: 'Landing Page',
        icon: 'fas fa-home',
        onclick: function () { router.navigate('/'); }
      },
      {
        label: 'Log Out',
        icon: 'fas fa-sign-out-alt',
        onclick: function () { handleLogout(); }
      }
    ], 'nav-item');
    return el('header', { class: 'header' }, [
      el('div', { class: 'logo' }, [
        el('h1', { class: 'wordmark' }, 'morbi.shop'),
        el('p', { class: 'header-subtitle' }, 'Admin Panel')
      ]),
      el('div', { class: 'usr-toggle' }, [
        el('ul', { class: 'nav-links header' }, [
          el('li', {}, [menu])
        ])
      ])
    ]);
  }

  /* ---- Login (Phase 0) ------------------------------------------------ */
  // Rendered in place of the tabs while no admin session exists. Reuses the
  // existing editor/form classes so it matches the panel look with zero new CSS.

  function renderLogin() {
    var root = document.getElementById(ROOT_ID);
    clear(root);
    root.appendChild(
      el('div', { class: 'container dashboard' }, [
        el('div', { class: 'main-body' }, [
          renderHeader(),
          el('div', { class: 'dash-content' }, [
            el('span', { class: 'status-text', id: 'dash-status' }),
            // PHASE-3-B3: the login panel now has two modes: 'login' (default)
            // and 'forgot'. The 'forgot' mode shows the email-entry form for
            // password recovery. Toggled by the "Forgot password?" link.
            loginMode === 'forgot' ? renderForgotPanel() : renderLoginPanel()
          ])
        ])
      ])
    );

    if (loginMode === 'forgot') {
      bindForgotForm();
    } else {
      bindLoginForm();
    }
  }

  // PHASE-3-B3: login panel mode — 'login' (default) or 'forgot'.
  var loginMode = 'login';

  function renderLoginPanel() {
    return el('section', { class: 'panel' }, [
      el('h3', { class: 'panel-title', id: 'login-panel-title' }, 'Admin Login'),
      el('form', { id: 'login-form', class: 'item-editor', onsubmit: function (e) { e.preventDefault(); } }, [
        el('div', { class: 'form-row' }, [
          el('label', { for: 'l-username' }, 'Username'),
          el('input', { id: 'l-username', type: 'text', autocomplete: 'username' })
        ]),
        el('div', { class: 'form-row' }, [
          el('label', { for: 'l-password' }, 'Password'),
          el('input', { id: 'l-password', type: 'password', autocomplete: 'current-password' }),
          el('p', { class: 'form-error', id: 'l-error' }, '')
        ]),
        el('div', { class: 'form-actions' }, [
          el('button', { id: 'l-submit', type: 'button', class: 'btn-md fill' }, 'Sign In')
        ]),
        // PHASE-3-B3: Forgot password link — switches the panel to the
        // email-entry mode (no navigation, just a mode swap).
        el('div', { style: { marginTop: '10px', textAlign: 'center' } }, [
          el('button', {
            id: 'l-forgot-link',
            type: 'button',
            class: 'btn-sm outline',
            style: { fontSize: '12px', padding: '4px 10px' },
            onclick: function () { loginMode = 'forgot'; doRender(); }
          }, 'Forgot password?')
        ])
      ])
    ]);
  }

  function renderForgotPanel() {
    return el('section', { class: 'panel' }, [
      el('h3', { class: 'panel-title', id: 'forgot-panel-title' }, 'Reset Password'),
      el('p', { class: 'muted' }, 'Enter your admin email and we will send you a password reset link.'),
      el('form', { id: 'forgot-form', class: 'item-editor', onsubmit: function (e) { e.preventDefault(); } }, [
        el('div', { class: 'form-row' }, [
          el('label', { for: 'f-email' }, 'Admin Email'),
          el('input', { id: 'f-email', type: 'email', autocomplete: 'email', placeholder: 'you@example.com' }),
          el('p', { class: 'form-error', id: 'f-error' }, '')
        ]),
        el('div', { class: 'form-actions' }, [
          el('button', { id: 'f-submit', type: 'button', class: 'btn-md fill' }, 'Send Reset Link'),
          el('button', {
            id: 'f-back',
            type: 'button',
            class: 'btn-md outline',
            onclick: function () { loginMode = 'login'; doRender(); }
          }, 'Back to Login')
        ])
      ])
    ]);
  }

  function bindLoginForm() {
    var btn = document.getElementById('l-submit');
    if (btn) btn.addEventListener('click', handleLogin);
    ['l-username', 'l-password'].forEach(function (inputId) {
      var input = document.getElementById(inputId);
      if (input) input.addEventListener('keydown', function (e) {
        if (e.key === 'Enter') { e.preventDefault(); handleLogin(); }
      });
    });
    var usernameInput = document.getElementById('l-username');
    if (usernameInput) usernameInput.focus();
  }

  function bindForgotForm() {
    var btn = document.getElementById('f-submit');
    if (btn) btn.addEventListener('click', handleForgotPassword);
    var emailInput = document.getElementById('f-email');
    if (emailInput) {
      emailInput.focus();
      emailInput.addEventListener('keydown', function (e) {
        if (e.key === 'Enter') { e.preventDefault(); handleForgotPassword(); }
      });
    }
  }

  // PHASE-3-B3: Forgot password handler. Calls store.requestPasswordReset(email).
  // The server ALWAYS returns {sent: true} (anti-enumeration) — so the success
  // message is the same whether or not the email exists. On 422 (invalid email
  // format) or 429 (rate limited), shows the error inline.
  function handleForgotPassword() {
    var email = document.getElementById('f-email').value.trim();
    var errEl = document.getElementById('f-error');
    var btn = document.getElementById('f-submit');

    // ★ Blind-spot fix (Task 43, UX-09 neighborhood): the submit button is
    //   disabled + relabeled "Sending…" during the request and stays
    //   disabled after success — but the Enter-key handler on #f-email
    //   calls handleForgotPassword() directly, bypassing the disabled
    //   button and re-firing the request (double reset emails; or a
    //   pointless re-send after success since the form now stays on
    //   screen). Early-return when a request is already done/in-flight.
    if (btn && btn.disabled) return;

    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      if (errEl) { errEl.textContent = 'Enter a valid email address.'; errEl.classList.add('show'); }
      return;
    }
    if (errEl) errEl.classList.remove('show');
    if (btn) { btn.disabled = true; btn.textContent = 'Sending…'; }

    store.requestPasswordReset(email).then(function () {
      flashStatus('If an admin account exists for ' + email + ', a reset link has been sent. Check your inbox (and spam folder).');
      // ★ UX-09 fix: the 2.5s auto-switch back to the login form is gone.
      //   It yanked the user off this screen mid-read (the status flash
      //   itself lives 3s), destroying the email they'd just typed and
      //   leaving them unsure the request went through. The form now stays
      //   put with the success message; the panel's existing "Back to
      //   Login" button gives the user control of the transition (and the
      //   submit button stays disabled, preventing a double-send).
    }).catch(function (err) {
      if (btn) { btn.disabled = false; btn.textContent = 'Send Reset Link'; }
      if (errEl) {
        errEl.textContent = err.message || 'Could not send reset link. Please try again.';
        errEl.classList.add('show');
      }
    });
  }

  function handleLogin() {
    var username = document.getElementById('l-username').value.trim();
    var password = document.getElementById('l-password').value;
    var errEl = document.getElementById('l-error');
    var btn = document.getElementById('l-submit');

    if (!username || !password) {
      if (errEl) { errEl.textContent = 'Username and password are required.'; errEl.classList.add('show'); }
      return;
    }
    if (errEl) errEl.classList.remove('show');
    if (btn) btn.disabled = true;

    store.login(username, password).then(function () {
      activeTab = 'products';
      doRender();
    }).catch(function (err) {
      if (btn) btn.disabled = false;
      if (errEl) { errEl.textContent = err.message || 'Login failed.'; errEl.classList.add('show'); }
    });
  }

  function handleLogout() {
    store.logout().then(function () {
      // ★ BS-10 fix (iteration 25, carried over from PERF batch):
      //   PERF-06's renderActivePanel refactor converted 12 call sites
      //   from full doRender() to a partial rebuild, but kept doRender()
      //   for the login/logout/re-auth paths "intentionally". The logout
      //   path was overlooked: after logout, store.isAdmin() returns
      //   false, but doRender() doesn't check that — it unconditionally
      //   rebuilds the admin shell (.container.dashboard + renderHeader
      //   + .dash-content with the active tab's panel). The admin shell
      //   lingers with public-scope data (the user is logged out, but
      //   the dashboard tabs are still visible, the Logout button still
      //   shows, clicking anything fails with 401). The correct call is
      //   render() — it routes to renderLogin() when !store.isAdmin(),
      //   and doRender() when still admin. Same fix for the catch path
      //   (a logout-side failure like a network drop should still drop
      //   the user to the login panel).
      render();
    }).catch(function (err) {
      flashStatus(err.message || 'Logout failed.');
      render();
    });
  }

  /* ---- PHASE-3-B3: Session-expiry re-auth modal ----------------------- *
   * When store.api() receives a 401 AND the user was previously authed
   * (session expired mid-use), it fires store.onSessionExpired (set below).
   * showReAuthModal() creates a modal overlay asking the user to re-enter
   * their password. The username is pre-filled from adminName (the user
   * hasn't forgotten WHO they are, just the session lapsed). On success:
   * close the modal + flash a "retry your last action" prompt. On cancel:
   * navigate to #/ (landing page).
   *
   * The original failed request rejects normally — the user retries after
   * re-auth. Form data stays in the DOM (the modal is an overlay, not a
   * navigation) — so unsaved edits are NOT lost.
   *
   * ★ UX-10 fix: on success the modal closes and NOTHING re-renders. The
   *   old code called doRender() here, which clear(#app-root)'s the entire
   *   dashboard and rebuilds it — wiping every input (p-name, p-price,
   *   variant rows, theme pickers) the comment above promised was safe.
   *   Skipping the re-render keeps the form data intact; the underlying
   *   lists may show pre-expiry data until the user's next successful save
   *   or tab switch, which is the correct trade (data loss vs staleness).
   *
   * ★ UX-16 fix: the modal is a real ARIA dialog (role="dialog",
   *   aria-modal="true", aria-labelledby) with a focus trap — Tab and
   *   Shift+Tab cycle inside the modal instead of escaping to the hidden
   *   dashboard form underneath, so keyboard/screen-reader users' focus
   *   and keystrokes stay where the visible UI says they are. */

  // Wire up the callback ONCE (at module load, not on every render —
  // otherwise we'd register the same callback N times).
  if (typeof store.onSessionExpired !== 'function') {
    store.onSessionExpired = function () { showReAuthModal(); };
  }

  function showReAuthModal() {
    closeReAuthModal();  // defensive: never stack two re-auth modals
    // ★ Phase 10 (2026-09-26): capture the trigger element so close can
    //   restore focus. The trigger is whatever button the admin clicked
    //   before the 401 fired (typically a Save button). Without this,
    //   keyboard users were stranded on document.body after closing the
    //   re-auth modal — and the next Tab keystroke wandered into the page
    //   rather than starting from the form they were trying to submit.
    if (global.MorbiUI && typeof global.MorbiUI.captureTrigger === 'function') {
      global.MorbiUI.captureTrigger();
    }
    var username = store.adminUsername() || '';
    var backdrop = el('div', { id: 'reauth-modal-backdrop', class: 'modal-backdrop',
      // ★ UX-16 fix: ARIA dialog semantics — screen readers announce the
      //   dialog ("Session Expired") and hide the page content behind it.
      role: 'dialog', 'aria-modal': 'true', 'aria-labelledby': 'reauth-title'
    }, [
      el('div', { class: 'modal-panel', style: { maxWidth: '420px' } }, [
        el('div', { class: 'modal-header' }, [
          el('h3', { id: 'reauth-title' }, 'Session Expired'),
          el('button', {
            class: 'btn-sm outline',
            onclick: function () {
              closeReAuthModal();
              router.navigate('/');  // user gave up — go to landing
            }
          }, '× Close')
        ]),
        el('div', { class: 'modal-body' }, [
          el('p', { class: 'muted', style: { marginBottom: '14px' } },
            'Your session has expired. Please sign in again to continue. (Your unsaved edits are still in the form — sign in, then click Save again.)'),
          el('form', { id: 'reauth-form', onsubmit: function (e) { e.preventDefault(); } }, [
            el('div', { class: 'form-row' }, [
              el('label', { for: 'ra-username' }, 'Username'),
              el('input', { id: 'ra-username', type: 'text', value: username, autocomplete: 'username' })
            ]),
            el('div', { class: 'form-row' }, [
              el('label', { for: 'ra-password' }, 'Password'),
              el('input', { id: 'ra-password', type: 'password', autocomplete: 'current-password' }),
              el('p', { class: 'form-error', id: 'ra-error' }, '')
            ]),
            el('div', { class: 'form-actions' }, [
              el('button', {
                id: 'ra-submit',
                type: 'button',
                class: 'btn-md fill'
              }, 'Sign In'),
              el('button', {
                id: 'ra-cancel',
                type: 'button',
                class: 'btn-md outline',
                onclick: function () {
                  closeReAuthModal();
                  router.navigate('/');
                }
              }, 'Cancel')
            ])
          ])
        ])
      ])
    ]);
    document.body.appendChild(backdrop);

    var submitBtn = document.getElementById('ra-submit');
    if (submitBtn) submitBtn.addEventListener('click', handleReAuth);
    var passInput = document.getElementById('ra-password');
    if (passInput) {
      passInput.focus();
      passInput.addEventListener('keydown', function (e) {
        if (e.key === 'Enter') { e.preventDefault(); handleReAuth(); }
      });
    }

    // ★ UX-16 fix: focus trap. Tab / Shift+Tab wrap within the modal's
    //   focusable elements (close button, username, password, Sign In,
    //   Cancel). Without this, Tab from the password field escaped the
    //   modal and landed in the hidden dashboard's product-name field —
    //   keyboard users typed their password into an invisible form.
    backdrop.addEventListener('keydown', function (e) {
      if (e.key !== 'Tab') return;
      var focusables = backdrop.querySelectorAll('button, input');
      if (!focusables.length) return;
      var first = focusables[0];
      var last = focusables[focusables.length - 1];
      if (e.shiftKey && document.activeElement === first) {
        e.preventDefault();
        last.focus();
      } else if (!e.shiftKey && document.activeElement === last) {
        e.preventDefault();
        first.focus();
      }
    });
  }

  function handleReAuth() {
    var username = document.getElementById('ra-username').value.trim();
    var password = document.getElementById('ra-password').value;
    var errEl = document.getElementById('ra-error');
    var btn = document.getElementById('ra-submit');

    if (!username || !password) {
      if (errEl) { errEl.textContent = 'Username and password are required.'; errEl.classList.add('show'); }
      return;
    }
    if (errEl) errEl.classList.remove('show');
    if (btn) { btn.disabled = true; btn.textContent = 'Signing in…'; }

    store.login(username, password).then(function () {
      closeReAuthModal();
      flashStatus('Re-authenticated. Please retry your last action.');
      // ★ UX-10 fix: do NOT call doRender() here. The old code re-rendered
      //   the dashboard "to refresh the lists" — but doRender() rebuilds
      //   #app-root from scratch, wiping every unsaved input in the editor
      //   form (name, price, stock, variants, theme colors) that this
      //   modal's own copy promised was preserved. The user re-signs in
      //   and then watches 12 fields of work vanish — the worst outcome
      //   available. Now: the modal closes, the form stays exactly as it
      //   was, and the user retries their save (which now succeeds with
      //   the fresh session; the save's own .then path re-renders). List
      //   views may show pre-expiry data until that next save or tab
      //   switch — acceptable staleness vs. destroying user input.
    }).catch(function (err) {
      if (btn) { btn.disabled = false; btn.textContent = 'Sign In'; }
      if (errEl) {
        errEl.textContent = err.message || 'Login failed.';
        errEl.classList.add('show');
      }
    });
  }

  function closeReAuthModal() {
    var b = document.getElementById('reauth-modal-backdrop');
    if (b && b.parentNode) b.parentNode.removeChild(b);
    // ★ Phase 10 (2026-09-26): restore focus to the trigger element so the
    //   admin can resume keyboard navigation from where they were (typically
    //   a Save button) instead of being stranded on document.body.
    if (global.MorbiUI && typeof global.MorbiUI.restoreTrigger === 'function') {
      global.MorbiUI.restoreTrigger();
    }
  }

  /* ---- Tabs --------------------------------------------------------- */
  // FIX-WF-8: Tab switch with unsaved data warning

  function renderTabs() {
    var tabs = [
      { key: 'products', label: 'Products', icon: 'fas fa-flask' },
      { key: 'categories', label: 'Categories', icon: 'fas fa-tags' },
      { key: 'landing', label: 'Sections', icon: 'fas fa-pen-fancy' },
      // PHASE-3-B2: Orders tab — view/manage orders placed via Paystack.
      // Uses api/orders.php admin GET paths (already in place from Phase 2).
      { key: 'orders', label: 'Orders', icon: 'fas fa-shopping-bag' },
      // ★ Phase 5 Batch 2: Discounts tab — create/manage discount codes.
      { key: 'discounts', label: 'Discounts', icon: 'fas fa-tags' },
      // ★ Phase 5 Batch 4: Analytics tab — revenue charts, top products, trends.
      { key: 'analytics', label: 'Analytics', icon: 'fas fa-chart-bar' },
      // PHASE-1: design-token editor — rebrand colors without touching code.
      { key: 'theme', label: 'Theme', icon: 'fas fa-palette' }
    ];
    // ★ Phase 8 Batch 2 (Task 59): Admins tab — visible only to super_admin.
    //   An 'admin' role can manage everything except other admin accounts.
    //   The server enforces this via require_role('super_admin') on every
    //   api/admins.php route; the frontend just hides the tab to avoid
    //   showing actions that would 403. JS tampering that re-shows the
    //   tab gains nothing — every API call still requires super_admin.
    if (store.isSuperAdmin && store.isSuperAdmin()) {
      tabs.push({ key: 'admins', label: 'Admins', icon: 'fas fa-users' });
      // ★ Phase 8 Batch 3 (Task 60): Currencies tab — also super_admin only.
      //   Managing exchange rates is an admin-level task; an 'admin' role
      //   can sell in any currency but cannot add new ones or edit rates.
      tabs.push({ key: 'currencies', label: 'Currencies', icon: 'fas fa-coins' });
    }
    return el('div', { class: 'dash-tabs' }, tabs.map(function (t) {
      return el('button', {
        class: 'dash-tab' + (activeTab === t.key ? ' active' : ''),
        onclick: function () {
          // FIX-WF-8: Warn about unsaved changes before switching tabs
          if (activeTab !== t.key && hasUnsavedChanges()) {
            if (!confirm('You have unsaved changes. Switch tabs anyway?')) return;
          }
          // PHASE-1: leaving the Theme tab without saving reverts live-preview
          // overrides back to the saved token map.
          if (activeTab === 'theme' && t.key !== 'theme') {
            store.applyTokens();
          }
          activeTab = t.key;
          renderActivePanel();  // ★ PERF-06: was doRender() — header is static
        }
      }, [el('i', { class: t.icon, style: { marginRight: '8px' } }), t.label]);
    }));
  }

  // FIX-WF-8: Check if current tab has unsaved form data
  // ★ UX-04 fix: the Products branch previously diffed ONLY the name field —
  //   editing price/stock/scent/description/category/availability/variants/
  //   photo and switching tabs proceeded silently, then doRender() wiped
  //   everything. Now every editable field is diffed against the saved
  //   product (or against empty/default for a new product), and any
  //   non-empty variant row or freshly picked photo counts as unsaved.
  function hasUnsavedChanges() {
    if (activeTab === 'products') {
      var nameEl = document.getElementById('p-name');
      var idEl = document.getElementById('p-id');
      if (!nameEl || !idEl) return false;
      var name = nameEl.value.trim();
      var id = idEl.value;

      // Freshly picked photo file that hasn't been uploaded/saved yet.
      var photoEl = document.getElementById('p-photo');
      if (photoEl && photoEl.files && photoEl.files.length > 0) return true;

      // Any variant row the admin has touched (name or price non-empty)
      // counts as unsaved state — even an incomplete row is work the user
      // would lose to a silent tab switch (see also UX-08).
      var vContainer = document.getElementById('p-variants-list');
      if (vContainer) {
        var vRows = vContainer.querySelectorAll('.variant-editor-row');
        for (var vr = 0; vr < vRows.length; vr++) {
          var vn = vRows[vr].querySelector('.variant-input-name');
          var vp = vRows[vr].querySelector('.variant-input-price');
          if ((vn && vn.value.trim()) || (vp && vp.value.trim() !== '')) return true;
        }
      }

      // Shared field reads for both the new + edit cases.
      var scentEl = document.getElementById('p-scent');
      var scentCatEl = document.getElementById('p-scent-category');
      var priceEl = document.getElementById('p-price');
      var catEl = document.getElementById('p-category');
      var descEl = document.getElementById('p-desc');
      var availEl = document.getElementById('p-available');
      var stockEl = document.getElementById('p-stock');
      var scent = scentEl ? scentEl.value.trim() : '';
      var scentCategory = scentCatEl ? scentCatEl.value : '';
      var priceRaw = priceEl ? priceEl.value.trim() : '';
      var categoryVal = catEl ? catEl.value : '';
      var description = descEl ? descEl.value.trim() : '';
      var availableChecked = availEl ? !!availEl.checked : false;
      var stockRaw = stockEl ? stockEl.value.trim() : '';

      // NEW product (no p-id): any content beyond the form's defaults is
      // unsaved work. Form defaults: everything empty, available checked,
      // scent-category 'unisex' (matches clearProductEditor + the markup).
      if (!id) {
        if (name) return true;
        if (scent || priceRaw || description || stockRaw) return true;
        if (categoryVal) return true;
        if (scentCategory && scentCategory !== 'unisex') return true;
        if (!availableChecked) return true;
        return false;
      }

      // EDIT product: diff every field against the saved product.
      var p = store.getProduct(id);
      if (!p) return name !== '';  // product vanished (deleted elsewhere) — name content is unsaved intent
      if (p.name !== name) return true;
      if ((p.scent || '') !== scent) return true;
      if ((p.scentCategory || '') !== scentCategory) return true;
      if (priceRaw !== '' && Number(p.price) !== Number(priceRaw)) return true;
      if (priceRaw === '' && p.price !== null && p.price !== undefined) return true;
      if (String(p.categoryId || '') !== categoryVal) return true;
      if ((p.description || '') !== description) return true;
      if (!!p.available !== availableChecked) return true;
      var savedStock = (p.stock === null || p.stock === undefined) ? '' : String(p.stock);
      if (savedStock !== stockRaw) return true;
      return false;
    }
    if (activeTab === 'categories') {
      // ★ M13 fix (audit): check edits to EXISTING categories too, not just
      //   new ones. The old code only flagged unsaved state for new categories
      //   (no c-id). If the admin edited an existing category's name/description
      //   and switched tabs, the edits were silently lost.
      var catName = document.getElementById('c-name');
      var catId = document.getElementById('c-id');
      if (!catName) return false;
      if (!catId.value) return catName.value.trim().length > 0; // new category
      // Existing category — diff against the saved entity.
      var cat = store.getCategories().find(function (c) { return String(c.id) === String(catId.value); });
      if (!cat) return true; // can't verify — assume unsaved
      if (cat.name !== catName.value.trim()) return true;
      var catDesc = document.getElementById('c-desc');
      if (catDesc && (cat.description || '') !== catDesc.value.trim()) return true;
      var catSort = document.getElementById('c-sort');
      if (catSort && String(cat.sortOrder || 0) !== catSort.value) return true;
      return false;
    }
    // PHASE-1: any unsaved color/hex change in the Theme tab counts.
    if (activeTab === 'theme') {
      return themeFormDirty();
    }
    return false;
  }

  /* ====================================================================
     PRODUCTS TAB
     ==================================================================== */

  function renderProductsPanel() {
    var products = store.getProducts();
    var categories = store.getCategories();
    var currency = store.getCurrency();

    return el('section', { class: 'panel' }, [
      el('h3', { class: 'panel-title', id: 'products-panel-title' }, 'Products (' + products.length + ')'),
      el('div', { class: 'panel-body' }, [
        renderProductEditor(categories),
        el('div', { id: 'products-list', class: 'items-list' },
          products.length
            ? products.map(function (p) { return renderProductRow(p, currency); })
            : [el('p', { class: 'muted' }, 'No products yet. Add your first perfume above.')]
        )
      ])
    ]);
  }

  function renderProductEditor(categories) {
    return el('form', { id: 'product-form', class: 'item-editor', onsubmit: function (e) { e.preventDefault(); } }, [
      el('input', { type: 'hidden', id: 'p-id' }),
      el('div', { class: 'editor-grid' }, [
        el('div', { class: 'form-row' }, [
          el('label', { for: 'p-name' }, 'Product Name *'),
          el('input', { id: 'p-name', type: 'text', placeholder: 'Oud Royale' }),
          el('p', { class: 'form-error', id: 'p-name-error' }, 'Name is required (min 2 characters)')
        ]),
        el('div', { class: 'form-row' }, [
          el('label', { for: 'p-scent' }, 'Scent Profile'),
          el('input', { id: 'p-scent', type: 'text', placeholder: 'Woody, Spicy' }),
          el('p', { class: 'form-error', id: 'p-scent-error' }, 'Scent profile is too long (max 100 characters)')
        ]),
        // ★ BL-16 fix: scent category select. The Phase 5 Batch 1 scent-gate
        //   feature in storefront.js filters by this column — but until this
        //   field was added, no UI populated it, so every product was
        //   "untagged" and the gate was effectively a no-op. Options:
        //     - '' (Untagged): product shows in ALL scent views (backward-compat
        //       rule from filterByScent line 181).
        //     - 'male': shows only in Male + View All.
        //     - 'female': shows only in Female + View All.
        //     - 'unisex': shows only in Unisex + View All.
        //   Default on the form is 'unisex' (matches the install.php seed for
        //   the 4 default products — sane starting point for a new product).
        el('div', { class: 'form-row' }, [
          el('label', { for: 'p-scent-category' }, 'Scent Category (for the storefront scent gate)'),
          el('select', { id: 'p-scent-category' }, [
            el('option', { value: '' }, 'Untagged (shows in all scent views)'),
            el('option', { value: 'male' }, 'Male'),
            el('option', { value: 'female' }, 'Female'),
            el('option', { value: 'unisex', selected: true }, 'Unisex')
          ])
        ]),
        el('div', { class: 'form-row' }, [
          el('label', { for: 'p-price' }, 'Price (numbers only) *'),
          el('input', { id: 'p-price', type: 'number', step: '0.01', min: '0.01', placeholder: '150' }),
          el('p', { class: 'form-error', id: 'p-price-error' }, 'Valid price required (must be greater than 0)')
        ]),
        el('div', { class: 'form-row' }, [
          el('label', { for: 'p-category' }, 'Category'),
          el('select', { id: 'p-category' },
            [el('option', { value: '' }, 'None')].concat(
              // FIX-BL-15: Sort categories by sortOrder
              categories.slice().sort(function (a, b) { return (a.sortOrder || 0) - (b.sortOrder || 0); }).map(function (c) {
                return el('option', { value: c.id }, c.name);
              })
            )
          )
        ]),
        el('div', { class: 'form-row' }, [
          el('label', { for: 'p-photo' }, 'Photo (from device)'),
          el('div', { class: 'photo-row' }, [
            el('input', { id: 'p-photo', type: 'file', accept: 'image/*' }),
            // FIX-WF-7: onerror fallback for preview
            el('img', { id: 'p-photo-preview', class: 'photo-preview', alt: 'Preview', style: { display: 'none' } })
          ])
        ]),
        el('div', { class: 'form-row' }, [
          el('label', { for: 'p-currency' }, 'Currency Symbol'),
          el('input', { id: 'p-currency', type: 'text', value: store.getCurrency(), maxlength: 5, placeholder: 'GHS' })
        ])
      ]),
      el('div', { class: 'form-row' }, [
        el('label', { for: 'p-desc' }, 'Description'),
        el('textarea', { id: 'p-desc', rows: 3, placeholder: 'A bold oriental blend of oud and amber.' }),
        el('p', { class: 'form-error', id: 'p-desc-error' }, 'Description is too long (max 500 characters)')
      ]),
      el('div', { class: 'form-row' }, [
        el('label', { class: 'checkbox-row' }, [
          el('input', { id: 'p-available', type: 'checkbox', checked: true }),
          el('span', {}, 'Available (show in store)')
        ])
      ]),
      // ★ Phase 3 Batch 4: stock field. Empty = unlimited (no tracking,
      // backward compat for Phase 0-3 products). Number = tracked (decremented
      // automatically when an order is paid). 0 = out of stock (checkout
      // refused in payments.php with 422).
      el('div', { class: 'form-row' }, [
        el('label', { for: 'p-stock' }, 'Stock (leave empty for unlimited)'),
        el('input', { id: 'p-stock', type: 'number', min: '0', step: '1', placeholder: 'Unlimited' }),
        el('p', { class: 'form-error', id: 'p-stock-error' }, 'Stock must be a non-negative integer (or empty for unlimited)')
      ]),
      // ★ Phase 5 Batch 3: variants manager. Morbi can add size/option rows
      // (e.g. "50ml" at GHS 120, "100ml" at GHS 180). Each row has a name,
      // price, and optional stock. The variants are saved alongside the
      // product via the products.php API (save_variants function).
      el('div', { class: 'form-row' }, [
        el('label', {}, 'Variants (sizes/options — leave empty if product has no variants)'),
        el('div', { id: 'p-variants-list', class: 'variants-list' }, []),
        el('button', {
          type: 'button',
          class: 'btn-sm outline',
          style: { marginTop: '8px', fontSize: '12px' },
          onclick: function () { addVariantRow(); }
        }, [el('i', { class: 'fas fa-plus', style: { marginRight: '4px' } }), 'Add Variant'])
      ]),
      el('div', { class: 'form-actions' }, [
        el('button', { id: 'p-save', type: 'button', class: 'btn-md fill' }, 'Save Product'),
        el('button', { id: 'p-clear', type: 'button', class: 'btn-md outline' }, 'Clear'),
        el('button', {
          id: 'p-load-demo', type: 'button', class: 'btn-md outline',
          style: { marginLeft: 'auto', borderColor: '#2D8B4E', color: '#2D8B4E' }
        }, 'Load Demo Products')
      ])
    ]);
  }

  function renderProductRow(p, currency) {
    var cat = p.categoryId ? store.getCategory(p.categoryId) : null;
    var thumbContent;
    if (p.imagePath) {
      var img = document.createElement('img');
      // ★ Phase 10 (2026-09-26): resolve image path against basePath so the
      //   thumbnail renders under clean-path routing (/morbi-shop/dashboard).
      //   Was: `img.src = p.imagePath` — relative path 404'd under clean-path
      //   routing → onerror flask-icon placeholder showed.
      img.src = (store.resolveImagePath && p.imagePath) ? store.resolveImagePath(p.imagePath) : p.imagePath;
      img.alt = p.name;
      img.className = 'item-thumb';
      // ★ PERF-12 (Task 45): rows sit below the editor fold — lazy-load.
      img.loading = 'lazy';
      // FIX-WF-7: onerror fallback for broken images
      img.addEventListener('error', function () {
        var parent = this.parentNode;
        if (!parent) return;
        var fallback = document.createElement('div');
        fallback.className = 'item-thumb';
        fallback.style.cssText = 'background:linear-gradient(135deg,#1a1a1a,#222222);display:flex;align-items:center;justify-content:center;border-radius:8px;';
        var icon = document.createElement('i');
        icon.className = 'fas fa-flask';
        icon.style.color = '#333';
        fallback.appendChild(icon);
        parent.replaceChild(fallback, this);
      });
      thumbContent = img;
    } else {
      thumbContent = el('div', {
        class: 'item-thumb', style: {
          background: 'linear-gradient(135deg, #1a1a1a, #222222)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          borderRadius: '8px'
        }
      }, [el('i', { class: 'fas fa-flask', style: { color: '#333' } })]);
    }

    return el('div', { class: 'item-row', dataset: { id: p.id } }, [
      thumbContent,
      el('div', { class: 'item-info' }, [
        el('h4', {}, p.name),
        el('p', { class: 'muted' }, [
          formatPrice(p.price, currency),
          p.scent ? ' | ' + p.scent : '',
          cat ? ' | ' + cat.name : '',
          p.available ? '' : ' | hidden'
        ])
      ]),
      el('div', { class: 'item-actions' }, [
        el('button', { class: 'btn-sm outline', onclick: function () { fillProductEditor(p.id); } }, 'Edit'),
        el('button', { class: 'btn-sm outline', style: { borderColor: '#dc2626', color: '#dc2626' }, onclick: function () { deleteProduct(p.id); } }, 'Del')
      ])
    ]);
  }

  function bindProductForm() {
    var saveBtn = document.getElementById('p-save');
    if (saveBtn) saveBtn.addEventListener('click', handleProductSave);
    var clearBtn = document.getElementById('p-clear');
    if (clearBtn) clearBtn.addEventListener('click', clearProductEditor);
    var demoBtn = document.getElementById('p-load-demo');
    if (demoBtn) demoBtn.addEventListener('click', loadDemoProducts);
    // FIX-WF-6: Bind photo preview on file selection
    var photoInput = document.getElementById('p-photo');
    if (photoInput) {
      photoInput.addEventListener('change', function () {
        var file = this.files && this.files[0];
        var preview = document.getElementById('p-photo-preview');
        if (!file || !preview) return;
        var reader = new FileReader();
        reader.onload = function (e) {
          preview.src = e.target.result;
          preview.style.display = 'block';
        };
        reader.readAsDataURL(file);
      });
    }
  }

  function handleProductSave() {
    var id = document.getElementById('p-id').value;
    var name = document.getElementById('p-name').value.trim();
    var scent = document.getElementById('p-scent').value.trim();
    // ★ BL-16 fix: read the scent_category select. Empty string = untagged
    //   (shows in all scent views per the filterByScent backward-compat rule).
    var scentCategory = document.getElementById('p-scent-category').value;
    var priceRaw = document.getElementById('p-price').value;
    var categoryId = document.getElementById('p-category').value || null;
    var photoFile = document.getElementById('p-photo').files && document.getElementById('p-photo').files[0];
    var currencyVal = document.getElementById('p-currency').value.trim();
    var description = document.getElementById('p-desc').value.trim();
    var valid = true;

    // Name validation
    if (!name || name.length < 2) {
      showFormError('p-name', 'p-name-error', 'Name is required (min 2 characters)');
      valid = false;
    } else {
      hideFormError('p-name', 'p-name-error');
    }

    // FIX-BL-4/5: Price validation — reject empty, NaN, and zero
    var price = Number(priceRaw);
    if (!priceRaw || priceRaw.trim() === '' || isNaN(price) || price <= 0) {
      showFormError('p-price', 'p-price-error', 'Valid price required (must be greater than 0)');
      valid = false;
    } else {
      hideFormError('p-price', 'p-price-error');
    }

    // Scent validation (optional, max 100 chars)
    if (scent && scent.length > 100) {
      showFormError('p-scent', 'p-scent-error', 'Scent profile is too long (max 100 characters)');
      valid = false;
    } else {
      hideFormError('p-scent', 'p-scent-error');
    }

    // Description validation (optional, max 500 chars)
    if (description && description.length > 500) {
      showFormError('p-desc', 'p-desc-error', 'Description is too long (max 500 characters)');
      valid = false;
    } else {
      hideFormError('p-desc', 'p-desc-error');
    }

    // ★ Phase 3 Batch 4: Stock validation. Empty string = unlimited (NULL).
    // Non-negative integer = tracked. Negative or non-numeric = 422.
    var stockRaw = document.getElementById('p-stock').value.trim();
    var stockVal = null;  // default: unlimited
    if (stockRaw !== '') {
      var stockNum = Number(stockRaw);
      if (!/^\d+$/.test(stockRaw) || isNaN(stockNum) || stockNum < 0) {
        showFormError('p-stock', 'p-stock-error', 'Stock must be a non-negative integer (or empty for unlimited)');
        valid = false;
      } else {
        hideFormError('p-stock', 'p-stock-error');
        stockVal = Math.floor(stockNum);
      }
    } else {
      hideFormError('p-stock', 'p-stock-error');
    }

    if (!valid) return;

    // FIX-BL-9/18: Currency validation (1-5 chars).
    // PHASE-0: async now; a currency sync failure must not block the product
    // save, so it is logged only (the product POST reports its own errors).
    if (currencyVal && /^[A-Za-z$\u20A0-\u20CF\u00A2-\u00A5]{1,5}$/.test(currencyVal)) {
      store.saveCurrency(currencyVal).catch(function (e) { console.warn('[morbi] currency sync failed:', e.message); });
    }

    var persist = function (photoData) {
      var payload = {
        name: name,
        scent: scent,
        // ★ BL-16 fix: include scentCategory in the payload so the server's
        //   validate_product() picks it up + persists it to the scent_category
        //   column. Without this, the dashboard's p-scent-category select
        //   value would be silently dropped (the server's $allowed list
        //   wouldn't include 'scentCategory', so it'd be ignored on PUT).
        scentCategory: scentCategory,
        price: price,
        categoryId: categoryId,
        description: description,
        available: document.getElementById('p-available').checked,
        stock: stockVal  // ★ Phase 3 Batch 4: null = unlimited; int = tracked
      };
      if (photoData) payload.imagePath = photoData;

      // ★ Phase 5 Batch 3: collect variants from the form.
      // ★ BL-08 fix: ALWAYS attach payload.variants, even when the array is
      //   empty. The old `if (variants.length > 0) payload.variants = variants;`
      //   guard meant that when the admin removed every variant row and
      //   clicked Save, the `variants` key was OMITTED from the PUT body —
      //   the server's `if (array_key_exists('variants', $b))` check then
      //   failed and save_variants was never called, so the existing variant
      //   rows in product_variants were left intact. The dashboard's empty
      //   editor would "come back" on the next page load.
      //   Sending `payload.variants = []` explicitly triggers save_variants,
      //   which DELETEs all existing variants for the product then inserts
      //   nothing — the correct "clear all variants" behavior.
      // ★ UX-08 fix: collectVariants now returns { variants, skipped } —
      //   rows with a name but a missing/invalid price are still skipped
      //   (they can't be saved), but the count is surfaced to the admin
      //   after the save settles instead of vanishing silently.
      var collected = collectVariants();
      payload.variants = collected.variants;  // always send, even if empty — BL-08

      if (id) {
        var existing = store.getProduct(id);
        if (!photoData && existing && existing.imagePath) payload.imagePath = existing.imagePath;
      }

      // PHASE-0: the store call is a server round-trip now. The button stays
      // disabled until the request settles (double-submit guard — duplicates
      // were impossible before only because the old store was synchronous).
      var saveBtn = document.getElementById('p-save');
      if (saveBtn) saveBtn.disabled = true;

      var op = id ? store.updateProduct(id, payload) : store.addProduct(payload);
      op.then(function () {
        // ★ Phase 10 (2026-09-26): wrap clearProductEditor + renderActivePanel
        //   in try/catch. Was: if renderActivePanel threw (DOM bug, a
        //   console.error in a child component, an undefined getter on a
        //   stale cache entry), the throw propagated out of the .then()
        //   callback → the Promise turned into a rejection → but the .catch
        //   handler re-enabled saveBtn + flashed "Save failed", even though
        //   the save HAD actually succeeded (the API returned 200/201). The
        //   admin saw a "Save failed" message + the editor was cleared +
        //   the panel was in a broken half-rendered state.
        //   Fix: separate the "did the save succeed?" question (yes — we're
        //   in the .then) from the "did the post-save UI work?" question.
        //   If the post-save UI throws, log it + show a "Saved (but UI
        //   refresh failed)" message instead of "Save failed".
        try {
          clearProductEditor();
          cacheClear('analytics');  // ★ PERF-14: top-products names join live products
          renderActivePanel();  // ★ PERF-06: was doRender()
          // ★ UX-08 fix: warn AFTER the re-render — flashStatus targets
          //   #dash-status, which the re-render recreates, so flashing before
          //   the re-render would be wiped instantly. The warning survives
          //   3s (flashStatus's standard auto-clear), long enough to read.
          if (collected.skipped > 0) {
            flashStatus(collected.skipped + ' variant row(s) had a missing or invalid price and were NOT saved. '
              + 'Each row needs a name AND a price of 0 or more.');
          } else {
            // ★ Phase 10: explicit success flag — flashStatus used to
            //   substring-match on "Saved"/"Added" to pick the color, but
            //   we're not saying either word in the success path above
            //   (only the warn-on-skipped path flashes). Now flash an
            //   explicit "Saved" so the admin gets visual confirmation.
            flashStatus('Saved.', true);
          }
        } catch (uiErr) {
          if (typeof console !== 'undefined' && console.error) {
            console.error('[morbi] Product saved but UI refresh failed:', uiErr && uiErr.message ? uiErr.message : uiErr);
          }
          // The save itself succeeded — surface a clear message rather
          // than the misleading "Save failed." Re-enable the save button
          // so the admin can attempt to re-render by editing again.
          if (saveBtn) saveBtn.disabled = false;
          flashStatus('Saved, but the panel could not be refreshed. Click Save again or refresh the page.', true);
        }
      }).catch(function (err) {
        if (saveBtn) saveBtn.disabled = false;
        // ★ Phase 10: pass explicit isError=false to flashStatus so the
        //   substring heuristic doesn't accidentally color a "Saved" word
        //   in an error message green.
        // ★ Phase 10 (2026-09-26): also surface the error INLINE next to
        //   the offending field when the server message maps to a known
        //   field. Was: every save failure (including field-specific
        //   validation errors like "Name is required") was shown only via
        //   flashStatus at the TOP of the panel — the admin had to scroll
        //   up to see which field was wrong. Now: the catch inspects the
        //   server message for known phrases + lights up the matching
        //   field's inline error. Unknown errors still fall back to
        //   flashStatus only.
        var msg = (err && err.message) || 'Save failed.';
        var shownInline = false;
        var lowerMsg = msg.toLowerCase();
        if (lowerMsg.indexOf('name') !== -1 && (lowerMsg.indexOf('required') !== -1 || lowerMsg.indexOf('min') !== -1 || lowerMsg.indexOf('max') !== -1 || lowerMsg.indexOf('character') !== -1)) {
          showFormError('p-name', 'p-name-error', msg);
          shownInline = true;
        } else if (lowerMsg.indexOf('price') !== -1 && (lowerMsg.indexOf('required') !== -1 || lowerMsg.indexOf('greater') !== -1 || lowerMsg.indexOf('valid') !== -1)) {
          showFormError('p-price', 'p-price-error', msg);
          shownInline = true;
        } else if (lowerMsg.indexOf('stock') !== -1 && (lowerMsg.indexOf('non-negative') !== -1 || lowerMsg.indexOf('integer') !== -1 || lowerMsg.indexOf('valid') !== -1)) {
          showFormError('p-stock', 'p-stock-error', msg);
          shownInline = true;
        } else if (lowerMsg.indexOf('description') !== -1 && lowerMsg.indexOf('long') !== -1) {
          showFormError('p-desc', 'p-desc-error', msg);
          shownInline = true;
        } else if (lowerMsg.indexOf('scent') !== -1 && (lowerMsg.indexOf('long') !== -1 || lowerMsg.indexOf('category') !== -1)) {
          showFormError('p-scent', 'p-scent-error', msg);
          shownInline = true;
        }
        // Always also flashStatus so the admin sees the message at the top
        // of the panel (in case the inline error is below the fold).
        flashStatus(msg, false);
        // If shown inline, log so the admin can find the field via devtools
        // if the inline error is hidden by scroll.
        if (shownInline && typeof console !== 'undefined' && console.info) {
          console.info('[morbi] Product save failed — inline error shown next to the offending field.');
        }
      });
    };

    if (photoFile) {
      // PHASE-1-UPLOAD: compress client-side (saves bandwidth + gives the
      // server a predictable ~500 KB file to validate), then POST the Blob
      // to api/upload.php. The server returns uploads/<filename>, which
      // gets passed to persist() as imagePath — same shape as Phase 0's
      // base64 data URL, just much smaller in the DB and served as a
      // static file. On failure the flash shows the server message.
      compressImageToBlob(photoFile, 800)
        .then(uploadImage)
        .then(function (path) { persist(path); })
        .catch(function (err) {
          flashStatus((err && err.message) || 'Could not read or upload image.');
        });
    } else {
      persist(null);
    }
  }

  function fillProductEditor(id) {
    var p = store.getProduct(id);
    if (!p) return;
    document.getElementById('p-id').value = p.id;
    document.getElementById('p-name').value = p.name;
    document.getElementById('p-scent').value = p.scent || '';
    // ★ BL-16 fix: populate the scent_category select from the product's
    //   current scentCategory value. NULL/undefined/empty → 'untagged'
    //   (the empty option). The server's map_product returns scentCategory
    //   as a string (empty string for NULL) so the select's value matches.
    var scentCatSelect = document.getElementById('p-scent-category');
    if (scentCatSelect) {
      scentCatSelect.value = p.scentCategory || '';
    }
    document.getElementById('p-price').value = p.price;
    document.getElementById('p-category').value = p.categoryId || '';
    document.getElementById('p-desc').value = p.description || '';
    document.getElementById('p-available').checked = !!p.available;
    // ★ Phase 3 Batch 4: stock field. null = unlimited → empty input. int = tracked.
    document.getElementById('p-stock').value = (p.stock !== null && p.stock !== undefined) ? String(p.stock) : '';
    document.getElementById('p-photo').value = '';
    // ★ Phase 5 Batch 3: fill variants from the product's variants array.
    fillVariants(p.variants);

    var preview = document.getElementById('p-photo-preview');
    if (preview) {
      // ★ Phase 10 (2026-09-26): resolve image path against basePath (same fix as renderProductRow).
      if (p.imagePath) {
        preview.src = (store.resolveImagePath && p.imagePath) ? store.resolveImagePath(p.imagePath) : p.imagePath;
        preview.style.display = 'block';
      }
      else { preview.style.display = 'none'; }
    }
    document.getElementById('p-name').scrollIntoView({ behavior: 'smooth', block: 'center' });
  }

  function clearProductEditor() {
    ['p-id', 'p-name', 'p-scent', 'p-price', 'p-desc', 'p-photo', 'p-stock'].forEach(function (idEl) {
      var node = document.getElementById(idEl);
      if (node) node.value = '';
    });
    // ★ BL-16 fix: reset the scent_category select to 'unisex' (the form's
    //   default — matches install.php's seed for new default products).
    var scentCatSelect = document.getElementById('p-scent-category');
    if (scentCatSelect) scentCatSelect.value = 'unisex';
    var cb = document.getElementById('p-available');
    if (cb) cb.checked = true;
    var cat = document.getElementById('p-category');
    if (cat) cat.value = '';
    var preview = document.getElementById('p-photo-preview');
    if (preview) preview.style.display = 'none';
    hideFormError('p-name', 'p-name-error');
    hideFormError('p-price', 'p-price-error');
    hideFormError('p-scent', 'p-scent-error');
    hideFormError('p-desc', 'p-desc-error');
    hideFormError('p-stock', 'p-stock-error');  // ★ Phase 3 Batch 4
    clearVariants();  // ★ Phase 5 Batch 3
  }

  function deleteProduct(id) {
    if (!confirm('Delete this product?')) return;
    // PHASE-0: delete is a server round-trip; only re-render on success.
    store.deleteProduct(id).then(function () {
      cacheClear('analytics');  // ★ PERF-14: product set changed
      renderActivePanel();  // ★ PERF-06: was doRender()
    }).catch(function (err) {
      flashStatus(err.message || 'Delete failed.');
    });
  }

  /* ---- Phase 5 Batch 3: Variant manager helpers ------------------------- *
   * The variants-list container holds N variant rows. Each row has:
   *   - text input for variant name (e.g. "50ml")
   *   - number input for variant price (e.g. 120)
   *   - number input for variant stock (optional, empty = unlimited)
   *   - a "Remove" button to delete the row
   * The rows are created client-side via addVariantRow() and collected via
   * collectVariants() when the product is saved. On edit, fillVariants()
   * populates the rows from the existing product's variants array. */

  var variantRowCounter = 0;

  function addVariantRow(name, price, stock, variantId) {
    var container = document.getElementById('p-variants-list');
    if (!container) return;
    var rowId = 'v-row-' + (++variantRowCounter);
    // ★ WF-04 fix: stash the EXISTING variant's DB id on the row
    //   (data-variant-id). collectVariants() reads it back into the save
    //   payload so the server can UPDATE the row in place (preserving the
    //   id customer carts reference) instead of DELETE + re-INSERT. New
    //   rows created via the "+ Add Option" button pass no id — the attr
    //   stays absent and collectVariants sends no id, which the server
    //   treats as INSERT.
    container.appendChild(
      el('div', { class: 'variant-editor-row', id: rowId, 'data-variant-id': (variantId ? String(variantId) : null) }, [
        el('input', { type: 'text', placeholder: '50ml', value: name || '', class: 'variant-input-name', style: { flex: '2' } }),
        el('input', { type: 'number', step: '0.01', min: '0', placeholder: 'Price', value: price !== undefined ? price : '', class: 'variant-input-price', style: { flex: '1' } }),
        el('input', { type: 'number', min: '0', placeholder: 'Stock', value: stock !== undefined ? stock : '', class: 'variant-input-stock', style: { flex: '1' } }),
        el('button', {
          type: 'button',
          class: 'btn-sm outline',
          style: { borderColor: '#dc2626', color: '#dc2626', flexShrink: '0' },
          onclick: function () {
            var row = document.getElementById(rowId);
            if (row && row.parentNode) row.parentNode.removeChild(row);
          }
        }, '×')
      ])
    );
  }

  // Collects variant rows for save. Returns { variants, skipped }:
  //   - variants: the valid rows ({name, price, stock}) ready for the API
  //   - skipped:  how many rows were dropped (name empty, or price
  //               missing/invalid) — surfaced to the admin by
  //               handleProductSave (★ UX-08 fix: previously the drop was
  //               completely silent, so a variant typed without a price
  //               vanished on save with zero feedback).
  function collectVariants() {
    var container = document.getElementById('p-variants-list');
    if (!container) return { variants: [], skipped: 0 };
    var rows = container.querySelectorAll('.variant-editor-row');
    var variants = [];
    var skipped = 0;
    rows.forEach(function (row) {
      var nameInput = row.querySelector('.variant-input-name');
      var priceInput = row.querySelector('.variant-input-price');
      var stockInput = row.querySelector('.variant-input-stock');
      if (!nameInput || !priceInput) { skipped++; return; }
      var name = nameInput.value.trim();
      var price = parseFloat(priceInput.value);
      if (!name || isNaN(price) || price < 0) { skipped++; return; } // count incomplete rows (★ UX-08)
      var stock = null;
      if (stockInput && stockInput.value.trim() !== '') {
        // ★ L11 fix (audit): validate as integer via regex first, not
        //   parseInt — parseInt("1.5", 10) silently returns 1 (truncates
        //   the decimal), so the user sees variant stock = 1 in the DB
        //   when they typed 1.5. The regex ^\d+$ rejects non-integers.
        var stockRaw = stockInput.value.trim();
        if (/^\d+$/.test(stockRaw)) {
          stock = parseInt(stockRaw, 10);
        }
      }
      // ★ WF-04 fix: carry the row's existing variant id (if any) in the
      //   payload. addVariantRow stashes it on the row as data-variant-id
      //   when the editor is filled from an existing product. With ids in
      //   the payload, the server's save_variants can UPDATE existing rows
      //   IN PLACE instead of DELETE + re-INSERT — variant ids stay stable
      //   across product saves, so customer carts that reference them stay
      //   valid (the old rotate-on-every-save behavior orphaned every
      //   cart holding the product, even for a description-only edit).
      var rowId = parseInt(row.getAttribute('data-variant-id') || '', 10);
      if (!isNaN(rowId) && rowId > 0) {
        variants.push({ id: rowId, name: name, price: price, stock: stock });
      } else {
        variants.push({ name: name, price: price, stock: stock });
      }
    });
    return { variants: variants, skipped: skipped };
  }

  function fillVariants(variants) {
    var container = document.getElementById('p-variants-list');
    if (!container) return;
    clear(container);
    if (!variants || variants.length === 0) return;
    variants.forEach(function (v) {
      // ★ WF-04 fix: pass the variant's id through so edits to EXISTING
      //   variants round-trip it and the server can update in place.
      addVariantRow(v.name, v.price, v.stock, v.id);
    });
  }

  function clearVariants() {
    var container = document.getElementById('p-variants-list');
    if (container) clear(container);
  }

  // FIX-WF-5: Check for duplicate product names before loading demos
  function loadDemoProducts() {
    if (!confirm('This will add 6 demo products. Continue?')) return;
    var demos = store.getDemoProducts();
    var existing = store.getProducts();
    var existingNames = {};
    existing.forEach(function (p) { existingNames[p.name.toLowerCase()] = true; });

    // PHASE-0: adds are server round-trips, so the queue runs strictly
    // sequentially — this preserves the old insertion order (the API returns
    // products ordered by created_at/id, so parallel adds would shuffle them).
    var queue = demos.filter(function (d) { return !existingNames[d.name.toLowerCase()]; });
    var added = 0;
    var failures = [];  // ★ Phase 10 (2026-09-26): track per-product failures so partial success is reported.
    var demoBtn = document.getElementById('p-load-demo');
    if (demoBtn) demoBtn.disabled = true;

    function addNext() {
      if (!queue.length) {
        // ★ PERF-06: was doRender(). ★ BS-7 fix (Task 45): the success
        //   flash used to run BEFORE the re-render — flashStatus wrote to
        //   #dash-status, then the re-render cleared .dash-content and
        //   created a FRESH empty span, so the "Added N demo product(s)"
        //   message was wiped the instant it appeared. Reordered:
        //   re-render first, flash after (same order UX-08 uses).
        //   ★ Phase 6 Batch 0: switched from window.location.hash to
        //   window.location.pathname (clean-path routing).
        // ★ Phase 10 (2026-09-26): was `p.indexOf('/dashboard')===0` which
        //   matched `/dashboardXYZ` too — a future route like
        //   `/dashboard-export` would have triggered the re-render. Now uses
        //   an exact-match OR path-with-segment-slash check (matches
        //   `/dashboard` and `/dashboard/anything` but NOT `/dashboardXYZ`).
        if ((function(){var p=(global.MorbiRouter?MorbiRouter.stripBasePath(window.location.pathname):window.location.pathname)||'';return p==='/dashboard'||p.indexOf('/dashboard/')===0;})()) {
          renderActivePanel();
        }
        if (added === 0 && failures.length === 0) {
          flashStatus('All demo products already exist.');
        } else if (added > 0 && failures.length === 0) {
          flashStatus('Added ' + added + ' demo product(s).', true);
        } else if (added === 0 && failures.length > 0) {
          // All adds failed — the user sees the LAST failure's message
          // (matches old behavior) but the count is now accurate.
          flashStatus('Failed to add ' + failures.length + ' demo product(s). Last error: ' + failures[failures.length - 1].message, false);
        } else {
          // ★ Phase 10 (2026-09-26): partial success — was: the loop STOPPED
          //   at the first failure, so remaining demos were never tried + the
          //   admin saw "Failed to add demo products." with no indication of
          //   how many HAD succeeded. Now: failures are collected + the loop
          //   continues, so the admin sees the full picture.
          flashStatus('Added ' + added + ' demo product(s); ' + failures.length + ' failed. Last error: ' + failures[failures.length - 1].message, false);
        }
        cacheClear('analytics');  // top-products names join live products
        return;
      }
      var d = queue.shift();
      existingNames[d.name.toLowerCase()] = true;
      store.addProduct(d).then(function () {
        added++;
        addNext();
      }).catch(function (err) {
        // ★ Phase 10 (2026-09-26): collect the failure + continue the loop.
        //   Was: `flashStatus(err.message || 'Failed to add demo products.');`
        //   + the loop STOPPED — the remaining demos were never tried. The
        //   admin had no way to know which products succeeded or how many.
        //   Now: record the failure (name + message) + keep going so the
        //   admin sees a complete summary at the end.
        failures.push({ name: d.name, message: err && err.message ? err.message : String(err) });
        if (typeof console !== 'undefined' && console.warn) {
          console.warn('[morbi] Demo product add failed for "' + d.name + '":', err && err.message ? err.message : err);
        }
        addNext();
      });
    }
    addNext();
  }

  // ★ OTH-17 fix (iteration 25): the dead in-file `compressImage()` helper
  //   that used to live here (acknowledged-dead since Phase 1 Batch 2, when
  //   handleProductSave switched to ui-helpers.compressImageToBlob +
  //   uploadImage) has been removed. The file-header comment that said
  //   "the old compressImage() is retained for diff readability — dead code
  //   is harmless" is also updated (see the file header below). No behavior
  //   change — the function was never called by any code in the codebase
  //   (verified by `grep -rn 'compressImage(' js/`).
  //   ui-helpers.compressImageToBlob (the live helper) is unchanged.

  /* ---- Image upload (Phase 1 Batch 2 + Phase 3 CSRF) ---------------------
     uploadImage(blob) POSTs the Blob to api/upload.php as multipart/form-data
     and resolves with the uploads/<filename> path the server returns.
     Rejects with the server's error message on any failure (4xx/5xx).

     The Blob comes from ui-helpers.compressImageToBlob, so it's already
     resized to 800px and JPEG- or PNG-encoded — no second pass needed.

     Credentials: 'same-origin' (the admin session cookie rides along,
     matching the Phase 0 api() wrapper). NO JSON Content-Type — fetch()
     sets the multipart boundary automatically when the body is a FormData.

     PHASE-3-CSRF: this helper bypasses store.api() (which would JSON-encode
     the FormData body — wrong). We attach X-CSRF-Token manually using the
     token store.js fetched on init() / login(). upload.php is admin-only
     AND now calls verify_csrf(), so this header is required. */
  function uploadImage(blob) {
    var formData = new FormData();
    formData.append('photo', blob, 'product.jpg');
    var headers = {};
    var token = store.getCsrfToken && store.getCsrfToken();
    if (token) headers['X-CSRF-Token'] = token;
    return fetch('api/upload.php', {
      method: 'POST',
      credentials: 'same-origin',
      headers: headers,
      body: formData
    }).then(function (res) {
      return res.text().then(function (text) {
        var json = null;
        try { json = text ? JSON.parse(text) : null; } catch (e) { json = null; }
        if (!res.ok || !json || json.ok !== true) {
          var message = (json && json.error) || ('Upload failed (HTTP ' + res.status + ').');
          var err = new Error(message);
          err.status = res.status;
          throw err;
        }
        // Server returns { path: "uploads/<filename>", size: <bytes> }.
        return json.data && json.data.path;
      });
    });
  }

  /* ====================================================================
     CATEGORIES TAB
     ==================================================================== */

  function renderCategoriesPanel() {
    var categories = store.getCategories();
    return el('section', { class: 'panel' }, [
      el('h3', { class: 'panel-title' }, 'Categories (' + categories.length + ')'),
      el('div', { class: 'panel-body' }, [
        renderCategoryEditor(),
        el('div', { id: 'categories-list', class: 'items-list' },
          categories.length
            ? categories.map(function (c) { return renderCategoryRow(c); })
            : [el('p', { class: 'muted' }, 'No categories yet.')]
        )
      ])
    ]);
  }

  function renderCategoryEditor() {
    return el('form', { id: 'cat-form', class: 'item-editor', onsubmit: function (e) { e.preventDefault(); } }, [
      el('input', { type: 'hidden', id: 'c-id' }),
      el('div', { class: 'editor-grid' }, [
        el('div', { class: 'form-row' }, [
          el('label', { for: 'c-name' }, 'Category Name *'),
          el('input', { id: 'c-name', type: 'text', placeholder: 'Eau de Parfum' }),
          el('p', { class: 'form-error', id: 'c-name-error' }, 'Name is required (min 2 characters)')
        ]),
        el('div', { class: 'form-row' }, [
          el('label', { for: 'c-sort' }, 'Sort Order (lower = first) *'),
          el('input', { id: 'c-sort', type: 'number', min: '0', value: '0' }),
          el('p', { class: 'form-error', id: 'c-sort-error' }, 'Valid sort order required (0 or greater)')
        ])
      ]),
      el('div', { class: 'form-row' }, [
        el('label', { for: 'c-desc' }, 'Description'),
        el('input', { id: 'c-desc', type: 'text', placeholder: 'Long-lasting signature scents' }),
        el('p', { class: 'form-error', id: 'c-desc-error' }, 'Description is too long (max 200 characters)')
      ]),
      el('div', { class: 'form-actions' }, [
        el('button', { id: 'c-save', type: 'button', class: 'btn-md fill' }, 'Save Category'),
        el('button', { id: 'c-clear', type: 'button', class: 'btn-md outline' }, 'Clear')
      ])
    ]);
  }

  function renderCategoryRow(c) {
    return el('div', { class: 'category-row', dataset: { id: c.id } }, [
      el('div', {}, [
        el('h4', {}, c.name),
        el('p', { class: 'muted' }, (c.description || 'No description') + ' | Order: ' + (c.sortOrder || 0))
      ]),
      el('div', { class: 'item-actions' }, [
        el('button', { class: 'btn-sm outline', onclick: function () { fillCategoryEditor(c.id); } }, 'Edit'),
        el('button', { class: 'btn-sm outline', style: { borderColor: '#dc2626', color: '#dc2626' }, onclick: function () { deleteCategory(c.id); } }, 'Del')
      ])
    ]);
  }

  function bindCategoryForm() {
    var saveBtn = document.getElementById('c-save');
    if (saveBtn) saveBtn.addEventListener('click', handleCategorySave);
    var clearBtn = document.getElementById('c-clear');
    if (clearBtn) clearBtn.addEventListener('click', clearCategoryEditor);
  }

  function handleCategorySave() {
    var id = document.getElementById('c-id').value;
    var name = document.getElementById('c-name').value.trim();
    var description = document.getElementById('c-desc').value.trim();
    var sortOrderVal = document.getElementById('c-sort').value;
    var valid = true;

    if (!name || name.length < 2) {
      showFormError('c-name', 'c-name-error', 'Name is required (min 2 characters)');
      valid = false;
    } else {
      hideFormError('c-name', 'c-name-error');
    }

    var sortOrder = parseInt(sortOrderVal);
    if (isNaN(sortOrder) || sortOrder < 0) {
      showFormError('c-sort', 'c-sort-error', 'Valid sort order required (0 or greater)');
      valid = false;
    } else {
      hideFormError('c-sort', 'c-sort-error');
    }

    if (description && description.length > 200) {
      showFormError('c-desc', 'c-desc-error', 'Description is too long (max 200 characters)');
      valid = false;
    } else {
      hideFormError('c-desc', 'c-desc-error');
    }

    if (!valid) return;

    // FIX-BL-8: Create a new payload object to avoid mutating caller's object
    var payload = {
      name: name,
      description: description,
      sortOrder: sortOrder
    };

    // PHASE-0: server round-trip with double-submit guard.
    var saveBtn = document.getElementById('c-save');
    if (saveBtn) saveBtn.disabled = true;

    var op = id ? store.updateCategory(id, payload) : store.addCategory(payload);
    op.then(function () {
      clearCategoryEditor();
      renderActivePanel();  // ★ PERF-06: was doRender()
    }).catch(function (err) {
      if (saveBtn) saveBtn.disabled = false;
      flashStatus(err.message || 'Save failed.');
    });
  }

  function fillCategoryEditor(id) {
    var c = store.getCategory(id);
    if (!c) return;
    document.getElementById('c-id').value = c.id;
    document.getElementById('c-name').value = c.name;
    document.getElementById('c-desc').value = c.description || '';
    document.getElementById('c-sort').value = c.sortOrder || 0;
    document.getElementById('c-name').scrollIntoView({ behavior: 'smooth', block: 'center' });
  }

  function clearCategoryEditor() {
    ['c-id', 'c-name', 'c-desc', 'c-sort'].forEach(function (idEl) {
      var node = document.getElementById(idEl);
      if (node) node.value = '';
    });
    var sort = document.getElementById('c-sort');
    if (sort) sort.value = '0';
    hideFormError('c-name', 'c-name-error');
    hideFormError('c-sort', 'c-sort-error');
    hideFormError('c-desc', 'c-desc-error');
  }

  function deleteCategory(id) {
    if (!confirm('Delete this category? Products in this category will become uncategorized.')) return;
    // PHASE-0: delete is a server round-trip; only re-render on success.
    store.deleteCategory(id).then(function () {
      renderActivePanel();  // ★ PERF-06: was doRender()
    }).catch(function (err) {
      flashStatus(err.message || 'Delete failed.');
    });
  }

  /* ====================================================================
     LANDING CONTENT TAB
     ==================================================================== */

  var LANDING_FIELDS = [
    { key: 'hero_title', label: 'Hero Title', type: 'text', placeholder: 'Luxury Scents, Redefined.', required: true, max: 100 },
    { key: 'hero_subtitle', label: 'Hero Subtitle', type: 'text', placeholder: 'Handcrafted perfumes and accessories...', required: true, max: 200 },
    { key: 'about_heading', label: 'About Heading', type: 'text', placeholder: 'About Morbi', required: true, max: 100 },
    { key: 'about_text_1', label: 'About Paragraph 1', type: 'textarea', placeholder: 'Morbi is a creative entrepreneur...', required: true, max: 500 },
    { key: 'about_text_2', label: 'About Paragraph 2', type: 'textarea', placeholder: 'Every Morcenzs bottle is curated...', required: true, max: 500 },
    { key: 'featured_heading', label: 'Featured Section Heading', type: 'text', placeholder: 'Featured Scents', required: true, max: 100 },
    { key: 'featured_sub', label: 'Featured Section Subtitle', type: 'text', placeholder: 'A selection from the Morcenzs collection.', required: true, max: 200 },
    { key: 'footer_text', label: 'Footer Text', type: 'text', placeholder: 'All rights reserved.', required: true, max: 200 }
  ];

  /* ==========================================================================
   * ★ Phase 6 Batch 1b (Task 49): the Sections tab.
   * Replaces the old "Landing Page" tab (which only edited 8 hardcoded
   * fields). The new tab lets Morbi add/edit/delete/reorder landing-page
   * sections without writing code — a mini WordPress-style page builder.
   * 9 section types: 4 base (hero, about, featured, footer) + 5 new
   * (promo_banner, cta_block, image_spot, text_block, spacer).
   * Backed by api/sections.php (full CRUD with type-specific content-shape
   * validation, soft-delete, restore) via the 5 store.js wrappers
   * (getSections, saveSection, updateSection, deleteSection, restoreSection).
   * ========================================================================== */

  // Module-scoped state for the Sections tab.
  var sectionsCache = null;          // cached getSections response
  var sectionsShowDeleted = false;   // toggle: include soft-deleted rows?
  var sectionsEditingId = null;      // section id being edited (null = creating)
  var sectionsEditingType = null;    // section_type being edited or created

  // Section type catalog — mirrors the server-side SECTION_TYPES in
  // api/sections.php. Single source of truth for the dashboard's forms.
  // Each type's `fields` array drives the type-specific form render + the
  // client-side validation (the server re-validates anyway — defense in depth).
  // ★ Feature 5: text_color + bg_color fields (type: 'color') added to the
  //   section types that support per-section color overrides (hero, about,
  //   featured, text_block, cta_block, promo_banner). Both are optional;
  //   when set, the landing renderers apply them as inline styles on the
  //   section wrapper (overriding the CSS defaults). When empty, the CSS
  //   defaults apply.
  var SECTION_TYPE_CATALOG = [
    { type: 'hero', label: 'Hero', icon: 'fas fa-star',
      description: 'The big headline at the top of the landing page.',
      fields: [
        { key: 'heading',  label: 'Headline',    type: 'text',    max: 100, required: true,  placeholder: 'Luxury Scents, Redefined.' },
        { key: 'subtitle', label: 'Subtitle',    type: 'text',    max: 200, required: true,  placeholder: 'Morcenzs, handcrafted perfumes...' },
        { key: 'text_color', label: 'Text color (optional)', type: 'color', max: 7, required: false, placeholder: '#ffffff' },
        { key: 'bg_color',   label: 'Background color (optional)', type: 'color', max: 7, required: false, placeholder: '#000000' }
      ] },
    { type: 'about', label: 'About', icon: 'fas fa-info-circle',
      description: 'The "About Morbi" section with heading + two paragraphs.',
      fields: [
        { key: 'heading',    label: 'Heading',     type: 'text',     max: 500, required: true, placeholder: 'About Morbi' },
        { key: 'paragraph_1', label: 'Paragraph 1', type: 'textarea', max: 500, required: true, placeholder: 'Morbi is a creative entrepreneur...' },
        { key: 'paragraph_2', label: 'Paragraph 2', type: 'textarea', max: 500, required: true, placeholder: 'Every Morcenzs bottle is curated with care...' },
        { key: 'text_color', label: 'Text color (optional)', type: 'color', max: 7, required: false, placeholder: '#000000' },
        { key: 'bg_color',   label: 'Background color (optional)', type: 'color', max: 7, required: false, placeholder: '#ffffff' }
      ] },
    { type: 'featured', label: 'Featured', icon: 'fas fa-star-of-life',
      description: 'The "Featured Scents" heading above the product grid.',
      fields: [
        { key: 'heading',  label: 'Heading',  type: 'text', max: 100, required: true, placeholder: 'Featured Scents' },
        { key: 'subtitle', label: 'Subtitle', type: 'text', max: 200, required: true, placeholder: 'A selection from the Morcenzs collection.' },
        { key: 'text_color', label: 'Text color (optional)', type: 'color', max: 7, required: false, placeholder: '#ffffff' },
        { key: 'bg_color',   label: 'Background color (optional)', type: 'color', max: 7, required: false, placeholder: '#000000' }
      ] },
    { type: 'footer', label: 'Footer', icon: 'fas fa-shoe-prints',
      description: 'The copyright line at the bottom of every page.',
      fields: [
        { key: 'text', label: 'Footer text', type: 'text', max: 200, required: true, placeholder: 'Morcenzs by Morbi. All rights reserved.' }
      ] },
    { type: 'promo_banner', label: 'Promo Banner', icon: 'fas fa-bullhorn',
      description: 'A one-line promo banner with optional link + accent color.',
      fields: [
        { key: 'text',         label: 'Promo text',     type: 'text',     max: 200, required: true,  placeholder: 'Free shipping on orders over GHS 200!' },
        { key: 'link_url',     label: 'Link URL (optional)', type: 'text', max: 200, required: false, placeholder: '/morcenzs' },
        { key: 'accent_color', label: 'Accent color (banner background, optional, #RRGGBB)', type: 'color', max: 7, required: false, placeholder: '#D4AF37' },
        { key: 'text_color',   label: 'Text color (optional)',     type: 'color', max: 7, required: false, placeholder: '#ffffff' },
        { key: 'bg_color',     label: 'Background color (section, optional)', type: 'color', max: 7, required: false, placeholder: '#000000' }
      ] },
    { type: 'cta_block', label: 'CTA Block', icon: 'fas fa-hand-pointer',
      description: 'A call-to-action block with heading, body, + button.',
      fields: [
        { key: 'heading',     label: 'Heading',     type: 'text',     max: 100, required: true, placeholder: 'Shop Our New Collection' },
        { key: 'body',        label: 'Body',         type: 'textarea', max: 500, required: true, placeholder: 'Browse our latest fragrances...' },
        { key: 'button_text', label: 'Button text', type: 'text',     max: 50,  required: true, placeholder: 'Shop Now' },
        { key: 'button_url',  label: 'Button URL',  type: 'text',     max: 200, required: true, placeholder: '/morcenzs' },
        { key: 'text_color', label: 'Text color (optional)', type: 'color', max: 7, required: false, placeholder: '#ffffff' },
        { key: 'bg_color',   label: 'Background color (optional)', type: 'color', max: 7, required: false, placeholder: '#1a1a1a' }
      ] },
    { type: 'image_spot', label: 'Image Spot', icon: 'fas fa-image',
      description: 'A single image with optional caption + link.',
      fields: [
        { key: 'image_path', label: 'Image',    type: 'image',   max: 255, required: true,  placeholder: '' },
        { key: 'caption',    label: 'Caption (optional)', type: 'text', max: 150, required: false, placeholder: 'Morbi at the launch event' },
        { key: 'link_url',  label: 'Link URL (optional)',  type: 'text', max: 200, required: false, placeholder: '/morcenzs' }
      ] },
    { type: 'text_block', label: 'Text Block', icon: 'fas fa-align-left',
      description: 'A free-form heading + body text block (no HTML).',
      fields: [
        { key: 'heading', label: 'Heading (optional)', type: 'text',     max: 100, required: false, placeholder: 'Our Story' },
        { key: 'body',    label: 'Body',              type: 'textarea', max: 500, required: true,  placeholder: 'Founded in 2024...' },
        { key: 'text_color', label: 'Text color (optional)', type: 'color', max: 7, required: false, placeholder: '#ffffff' },
        { key: 'bg_color',   label: 'Background color (optional)', type: 'color', max: 7, required: false, placeholder: '#000000' }
      ] },
    { type: 'spacer', label: 'Spacer', icon: 'fas fa-arrows-alt-v',
      description: 'Vertical whitespace (1-200px).',
      fields: [
        { key: 'height', label: 'Height (px, 1-200)', type: 'number', min: 1, max: 200, required: true, placeholder: '40' }
      ] }
  ];

  function renderSectionsPanel() {
    return el('section', { class: 'panel' }, [
      el('h3', { class: 'panel-title' }, 'Landing Page Sections'),
      el('div', { class: 'panel-body' }, [
        el('p', { class: 'muted' }, 'Add, edit, reorder, or remove the sections that make up your landing page. Changes appear on the live site after Save.'),
        // Action row: Add Section + Show deleted toggle + Refresh.
        el('div', { class: 'form-actions', style: { marginTop: '12px', flexWrap: 'wrap' } }, [
          el('button', {
            id: 'sec-add-btn', class: 'btn-md fill', type: 'button'
          }, [el('i', { class: 'fas fa-plus', style: { marginRight: '8px' } }), 'Add Section']),
          el('button', {
            id: 'sec-toggle-deleted', class: 'btn-md outline', type: 'button'
          }, sectionsShowDeleted ? 'Hide Deleted' : 'Show Deleted'),
          el('button', {
            id: 'sec-refresh', class: 'btn-md outline', type: 'button'
          }, [el('i', { class: 'fas fa-rotate-right', style: { marginRight: '8px' } }), 'Refresh']),
          // ★ Task 54: Preview Site button — opens the live landing page in
          // a new tab so Morbi can see how her sections look on the real
          // site without navigating away from the dashboard.
          el('button', {
            id: 'sec-preview', class: 'btn-md outline', type: 'button',
            style: { borderColor: 'var(--accent)', color: 'var(--accent)' },
            onclick: function () { window.open('/', '_blank'); }
          }, [el('i', { class: 'fas fa-external-link-alt', style: { marginRight: '8px' } }), 'Preview Site'])
        ]),
        // The Add Section type-picker dropdown (hidden by default; the
        // Add Section button shows it). Lists all 9 types with icons.
        el('div', { id: 'sec-type-picker', class: 'sec-type-picker', style: { display: 'none' } }, [
          el('h4', {}, 'Choose a section type:'),
          el('div', { class: 'sec-type-grid' },
            SECTION_TYPE_CATALOG.map(function (t) {
              return el('button', {
                class: 'sec-type-card', type: 'button',
                dataset: { type: t.type },
                onclick: function () { startNewSection(t.type); }
              }, [
                el('i', { class: t.icon + ' sec-type-icon' }),
                el('div', { class: 'sec-type-name' }, t.label),
                el('div', { class: 'sec-type-desc' }, t.description)
              ]);
            })
          ),
          el('div', { class: 'form-actions', style: { marginTop: '10px' } }, [
            el('button', {
              class: 'btn-md outline', type: 'button',
              onclick: function () {
                var p = document.getElementById('sec-type-picker');
                if (p) p.style.display = 'none';
              }
            }, 'Cancel')
          ])
        ]),
        // The section editor (hidden by default; shown when Add or Edit is clicked).
        el('div', { id: 'sec-editor', class: 'sec-editor', style: { display: 'none' } }),
        // The sections list.
        el('div', { id: 'sec-list', class: 'items-list', style: { marginTop: '16px' } }, [
          el('p', { class: 'muted' }, 'Loading sections…')
        ]),
        // Maintenance section: the 4 buttons that used to live in the old
        // Landing Page tab (Export Backup, Import Backup, Migrate Images,
        // Reset to Defaults). Kept here so the dashboard's functionality is
        // unchanged from iteration 27 — Morbi still has the same tools.
        el('hr', { style: { border: 'none', borderTop: '1px solid var(--border)', margin: '24px 0 16px' } }),
        el('h4', { class: 'panel-subtitle' }, 'Maintenance'),
        el('div', { class: 'form-actions', style: { flexWrap: 'wrap' } }, [
          el('button', {
            class: 'btn-md outline', type: 'button',
            onclick: function () { exportBackup(); }
          }, 'Export Backup'),
          el('button', {
            class: 'btn-md outline', type: 'button',
            onclick: function () { var f = document.getElementById('import-file'); if (f) f.click(); }
          }, 'Import Backup'),
          el('input', { id: 'import-file', type: 'file', accept: 'application/json,.json', style: { display: 'none' } }),
          el('button', {
            // ★ Blind-spot fix (2026-09-26): added id="migrate-img-btn"
            //   so handleMigrateImages() (line ~4895) can find the button
            //   via getElementById('migrate-img-btn') and disable it during
            //   the dry-run + real migration. Without the id, the lookup
            //   returned null and `if (btn) btn.disabled = true` was a
            //   no-op → double-click could trigger concurrent migrations
            //   (the server-side dry-run is idempotent so no data corruption,
            //   but the wasted requests + the missing "Migrating…" button
            //   state was confusing UX).
            id: 'migrate-img-btn',
            class: 'btn-md outline', type: 'button',
            style: { borderColor: '#2D8B4E', color: '#2D8B4E' },
            onclick: function () { handleMigrateImages(); }
          }, 'Migrate Images'),
          el('button', {
            class: 'btn-md outline', type: 'button',
            style: { borderColor: '#dc2626', color: '#dc2626' },
            onclick: function () { handleResetDefaults(); }
          }, 'Reset to Defaults')
        ])
      ])
    ]);
  }

  function bindSectionsPanel() {
    // ★ WF-1 fix (Task 53): invalidate the sections cache on tab entry so
    //   Morbi always sees fresh data when she returns to the Sections tab.
    //   Without this, a stale sectionsCache (from a prior visit) would
    //   show old content — e.g. she adds a section in one visit, switches
    //   to Products, comes back, and the new section is missing until she
    //   clicks Refresh. Now the cache is cleared on every tab entry,
    //   forcing a fresh fetch from the server.
    sectionsCache = null;
    var addBtn = document.getElementById('sec-add-btn');
    if (addBtn) addBtn.addEventListener('click', function () {
      var picker = document.getElementById('sec-type-picker');
      var editor = document.getElementById('sec-editor');
      if (editor) editor.style.display = 'none';
      if (picker) picker.style.display = (picker.style.display === 'none') ? '' : 'none';
    });
    var toggleBtn = document.getElementById('sec-toggle-deleted');
    if (toggleBtn) toggleBtn.addEventListener('click', function () {
      sectionsShowDeleted = !sectionsShowDeleted;
      // Re-render the button label + reload the list.
      toggleBtn.textContent = sectionsShowDeleted ? 'Hide Deleted' : 'Show Deleted';
      loadSections(true);
    });
    var refreshBtn = document.getElementById('sec-refresh');
    if (refreshBtn) refreshBtn.addEventListener('click', function () {
      loadSections(true);
    });
    // Hidden backup file input from the Maintenance section.
    var fileInput = document.getElementById('import-file');
    if (fileInput) {
      fileInput.addEventListener('change', function () {
        var file = this.files && this.files[0];
        this.value = '';
        importBackup(file);
      });
    }
    // ★ Task 54: drag-and-drop event delegation on the sections list
    //   container. Uses the native HTML5 Drag and Drop API (no library).
    //   Events: dragstart (set the dragged row's dataTransfer), dragover
    //   (prevent default to allow drop + show a drop indicator line),
    //   drop (swap sort_order), dragend (cleanup).
    bindSectionDragDrop();
    // Initial load (uses cache if fresh).
    loadSections(false);
  }

  // ★ Task 54: drag-and-drop for sections reordering.
  // Module-scoped state for the dragged row.
  var draggedRow = null;

  function bindSectionDragDrop() {
    var container = document.getElementById('sec-list');
    if (!container) return;

    container.addEventListener('dragstart', function (e) {
      var row = e.target.closest('.sec-row');
      if (!row || row.classList.contains('sec-row-deleted')) {
        e.preventDefault();
        return;
      }
      draggedRow = row;
      row.classList.add('sec-dragging');
      e.dataTransfer.effectAllowed = 'move';
      e.dataTransfer.setData('text/plain', row.dataset.id);
    });

    container.addEventListener('dragover', function (e) {
      e.preventDefault();
      e.dataTransfer.dropEffect = 'move';
      var row = e.target.closest('.sec-row');
      if (!row || row === draggedRow) return;
      // Show a drop indicator — insert a line before or after the target
      // row depending on whether the cursor is in the top or bottom half.
      var rect = row.getBoundingClientRect();
      var isAbove = e.clientY < rect.top + rect.height / 2;
      // Remove any existing drop indicators.
      clearDropIndicators(container);
      row.classList.add(isAbove ? 'sec-drop-above' : 'sec-drop-below');
    });

    container.addEventListener('drop', function (e) {
      e.preventDefault();
      if (!draggedRow) return;
      var targetRow = e.target.closest('.sec-row');
      if (!targetRow || targetRow === draggedRow) {
        clearDropIndicators(container);
        return;
      }
      var rect = targetRow.getBoundingClientRect();
      var isAbove = e.clientY < rect.top + rect.height / 2;
      // Find the sections in the cache + compute the new sort_order.
      var draggedId = parseInt(draggedRow.dataset.id, 10);
      var targetId = parseInt(targetRow.dataset.id, 10);
      var draggedSection = sectionsCache.find(function (s) { return s.id === draggedId; });
      var targetSection = sectionsCache.find(function (s) { return s.id === targetId; });
      if (!draggedSection || !targetSection) return;
      // Swap sort_order values (same approach as handleSectionMove, but
      // for drag-and-drop). Sequential PUTs (R-1/C-1 fix pattern).
      var draggedNewSort = targetSection.sort_order;
      var targetNewSort = draggedSection.sort_order;
      // If dropping above, the dragged section takes the target's sort_order
      // and the target takes the dragged section's old one. If dropping below,
      // same swap — the visual position is determined by the sort_order value,
      // not the drop position relative to the target. This is simpler + more
      // predictable than computing a midpoint sort_order.
      store.updateSection(draggedId, { sort_order: draggedNewSort }).then(function () {
        return store.updateSection(targetId, { sort_order: targetNewSort });
      }).then(function () {
        flashStatus('Reordered.');
        sectionsCache = null;
        loadSections(true);
      }).catch(function (err) {
        flashStatus(err.message || 'Reorder failed.');
        sectionsCache = null;
        loadSections(true);
      });
      clearDropIndicators(container);
    });

    container.addEventListener('dragend', function () {
      clearDropIndicators(container);
      // ★ Phase 10 (2026-09-26): guard against the edge case where the
      //   sections list re-rendered mid-drag (e.g. a parallel
      //   loadSections(true) call rebuilt #sec-list, detaching the
      //   original draggedRow from the DOM). The classList.remove is a
      //   no-op on a detached node, but `draggedRow = null` must still
      //   fire so a future drag start has a clean slate. Also: check
      //   document.contains() so we don't leak a reference to a dead node.
      if (draggedRow) {
        if (document.contains(draggedRow)) {
          draggedRow.classList.remove('sec-dragging');
        } else {
          // Detached (list re-rendered mid-drag) — log + clear the ref.
          if (typeof console !== 'undefined' && console.warn) {
            console.warn('[morbi] Section drag ended but the dragged row is no longer in the DOM (list re-rendered mid-drag). The drop did not take effect.');
          }
        }
        draggedRow = null;
      }
    });
  }

  function clearDropIndicators(container) {
    var rows = container.querySelectorAll('.sec-drop-above, .sec-drop-below');
    rows.forEach(function (r) {
      r.classList.remove('sec-drop-above', 'sec-drop-below');
    });
  }

  function loadSections(force) {
    var container = document.getElementById('sec-list');
    if (!container) return;
    if (!force && sectionsCache) {
      renderSectionsList(container, sectionsCache);
      return;
    }
    // ★ Phase 10 (2026-09-26): was `container.innerHTML = ''` — switched to
    //   clear() for consistency with the rest of the file.
    clear(container);
    container.appendChild(el('p', { class: 'muted' }, 'Loading sections…'));
    store.getSections(sectionsShowDeleted).then(function (res) {
      sectionsCache = res.sections || [];
      renderSectionsList(container, sectionsCache);
    }).catch(function (err) {
      clear(container);
      container.appendChild(el('p', { class: 'form-error show' }, err.message || 'Failed to load sections.'));
    });
  }

  function renderSectionsList(container, sections) {
    clear(container);
    if (!sections || sections.length === 0) {
      container.appendChild(el('p', { class: 'muted' },
        'No sections yet. Click "Add Section" to create your first one.'));
      return;
    }
    sections.forEach(function (s) {
      container.appendChild(renderSectionRow(s));
    });
  }

  function renderSectionRow(s) {
    var isDeleted = !!s.deleted_at;
    var typeMeta = SECTION_TYPE_CATALOG.filter(function (t) { return t.type === s.section_type; })[0] || { label: s.section_type, icon: 'fas fa-question' };
    // ★ Task 54: drag-and-drop — each row is draggable when not deleted.
    // The drag handle icon gives a visual affordance. The actual drag is
    // initiated from anywhere on the row (not just the handle — simpler UX
    // for Morbi who may not know to grab the handle specifically).
    return el('div', {
      class: 'sec-row' + (isDeleted ? ' sec-row-deleted' : '') + (!s.active ? ' sec-row-inactive' : ''),
      dataset: { id: s.id },
      draggable: isDeleted ? 'false' : 'true'
    }, [
      // Drag handle (only for non-deleted rows — deleted rows can't be reordered).
      isDeleted ? el('div', { class: 'sec-row-icon' }, [el('i', { class: typeMeta.icon })])
                : el('div', { class: 'sec-row-icon sec-drag-handle', title: 'Drag to reorder' }, [
                    el('i', { class: typeMeta.icon }),
                    el('i', { class: 'fas fa-grip-vertical sec-drag-grip' })
                  ]),
      el('div', { class: 'sec-row-body' }, [
        el('div', { class: 'sec-row-title' }, [
          el('strong', {}, typeMeta.label + ' #' + s.id),
          isDeleted ? el('span', { class: 'sec-badge sec-badge-deleted' }, 'deleted') : null,
          !s.active && !isDeleted ? el('span', { class: 'sec-badge sec-badge-inactive' }, 'inactive') : null
        ]),
        el('div', { class: 'sec-row-preview' }, renderSectionPreview(s))
      ]),
      el('div', { class: 'sec-row-actions' }, (isDeleted
        ? [
            el('button', { class: 'btn-md outline', type: 'button',
              onclick: function () { handleSectionRestore(s.id); }
            }, 'Restore')
          ]
        : [
            // ★ Task 54: keep ↑/↓ as fallback for mobile/touch (drag-and-drop
            //   is hard on touchscreens). The drag handle is for desktop.
            el('button', { class: 'btn-md outline sec-move-up', type: 'button', title: 'Move up',
              onclick: function () { handleSectionMove(s, -1); }
            }, [el('i', { class: 'fas fa-arrow-up' })]),
            el('button', { class: 'btn-md outline sec-move-down', type: 'button', title: 'Move down',
              onclick: function () { handleSectionMove(s, 1); }
            }, [el('i', { class: 'fas fa-arrow-down' })]),
            el('button', { class: 'btn-md outline', type: 'button',
              onclick: function () { startEditSection(s); }
            }, 'Edit'),
            el('button', { class: 'btn-md outline', type: 'button', style: { borderColor: '#dc2626', color: '#dc2626' },
              onclick: function () { handleSectionDelete(s); }
            }, 'Del')
          ]
      ))
    ]);
  }

  // A short text preview of the section's content (for the list row).
  function renderSectionPreview(s) {
    var c = s.content || {};
    var text = '';
    switch (s.section_type) {
      case 'hero':         text = (c.heading || '') + (c.subtitle ? ' — ' + c.subtitle : ''); break;
      case 'about':       text = (c.heading || '') + (c.paragraph_1 ? ' — ' + c.paragraph_1 : ''); break;
      case 'featured':    text = (c.heading || '') + (c.subtitle ? ' — ' + c.subtitle : ''); break;
      case 'footer':      text = c.text || ''; break;
      case 'promo_banner': text = c.text || ''; break;
      case 'cta_block':   text = (c.heading || '') + (c.body ? ' — ' + c.body : '') + (c.button_text ? ' [' + c.button_text + ']' : ''); break;
      case 'image_spot':  text = c.caption || c.image_path || '(image)'; break;
      case 'text_block':  text = (c.heading || '') + (c.body ? ' — ' + c.body : ''); break;
      case 'spacer':      text = c.height + 'px tall'; break;
      default:            text = JSON.stringify(c).slice(0, 120);
    }
    if (text.length > 140) text = text.slice(0, 137) + '…';
    return [text];
  }

  function startNewSection(type) {
    sectionsEditingId = null;
    sectionsEditingType = type;
    var picker = document.getElementById('sec-type-picker');
    if (picker) picker.style.display = 'none';
    var editor = document.getElementById('sec-editor');
    if (!editor) return;
    editor.style.display = '';
    clear(editor);
    var typeMeta = SECTION_TYPE_CATALOG.filter(function (t) { return t.type === type; })[0];
    editor.appendChild(renderSectionEditorForm(typeMeta, null));
    bindSectionEditorForm();
  }

  function startEditSection(section) {
    sectionsEditingId = section.id;
    sectionsEditingType = section.section_type;
    var picker = document.getElementById('sec-type-picker');
    if (picker) picker.style.display = 'none';
    var editor = document.getElementById('sec-editor');
    if (!editor) return;
    editor.style.display = '';
    clear(editor);
    var typeMeta = SECTION_TYPE_CATALOG.filter(function (t) { return t.type === section.section_type; })[0];
    editor.appendChild(renderSectionEditorForm(typeMeta, section));
    bindSectionEditorForm();
  }

  function renderSectionEditorForm(typeMeta, existing) {
    var content = existing ? (existing.content || {}) : {};
    return el('form', { id: 'sec-form', class: 'item-editor', onsubmit: function (e) { e.preventDefault(); } }, [
      el('input', { type: 'hidden', id: 'sec-id', value: existing ? existing.id : '' }),
      el('h4', {}, (existing ? 'Edit ' : 'Add ') + typeMeta.label + ' Section'),
      el('p', { class: 'muted' }, typeMeta.description),
      typeMeta.fields.map(function (f) { return renderSectionField(f, content[f.key]); }),
      el('div', { class: 'form-row', style: { marginTop: '8px' } }, [
        el('label', { class: 'checkbox-row' }, [
          el('input', { id: 'sec-active', type: 'checkbox', checked: existing ? existing.active : true }),
          el('span', {}, 'Active (visible on the live site)')
        ])
      ]),
      el('div', { class: 'form-actions' }, [
        el('button', { id: 'sec-save', type: 'button', class: 'btn-md fill' },
          [el('i', { class: 'fas fa-check', style: { marginRight: '8px' } }), 'Save Section']),
        el('button', { id: 'sec-cancel', type: 'button', class: 'btn-md outline' }, 'Cancel')
      ])
    ]);
  }

  function renderSectionField(f, value) {
    var val = (value === undefined || value === null) ? '' : String(value);
    var input;
    if (f.type === 'textarea') {
      input = el('textarea', { id: 'sec-field-' + f.key, rows: 3, placeholder: f.placeholder || '' }, val);
    } else if (f.type === 'color') {
      // ★ Feature 5: color-type field. <input type="color"> can't be empty
      //   (the browser always returns a value, defaulting to #000000). For
      //   OPTIONAL color fields we add a hidden text input that mirrors the
      //   color picker's value, so collectSectionContent() can read it
      //   consistently + so a future "Clear" affordance can set it to ''.
      //   The default value (when val is empty) is taken from f.placeholder
      //   if it's a valid #RRGGBB, otherwise #D4AF37 (the brand gold). Each
      //   catalog entry's placeholder is the section's CSS-default color, so
      //   a brand-new section with no color picks renders identically to the
      //   CSS-default look.
      var defaultHex = (f.placeholder && /^#[0-9a-fA-F]{6}$/.test(f.placeholder)) ? f.placeholder : '#D4AF37';
      var colorInput = el('input', {
        id: 'sec-field-' + f.key + '-picker',
        type: 'color',
        value: val || defaultHex,
        title: 'Pick a color',
        style: { width: '56px', height: '38px', padding: '0', border: '1px solid var(--border)', background: 'transparent', cursor: 'pointer', flexShrink: '0' }
      });
      // A text input alongside the picker — shows the hex value, lets Morbi
      // type a precise hex, AND when cleared (empty) signals "no override"
      // to collectSectionContent (which then saves '' so the renderer's
      // `if (text_color)` check skips applying the inline style → CSS default).
      var hexInput = el('input', {
        id: 'sec-field-' + f.key,
        type: 'text',
        value: val,
        maxlength: 7,
        placeholder: defaultHex,
        title: 'Hex color (#RRGGBB). Leave empty to use the section\'s default color.',
        style: { flex: '1', minWidth: '120px' }
      });
      // Cross-bind: picker → hex (always copies #RRGGBB); hex → picker (only
      // when valid so the picker doesn't snap to #000000 while typing).
      colorInput.addEventListener('input', function () { hexInput.value = colorInput.value; });
      hexInput.addEventListener('input', function () {
        var v = hexInput.value.trim();
        if (/^#[0-9a-fA-F]{6}$/.test(v)) colorInput.value = v.toLowerCase();
      });
      return el('div', { class: 'form-row' }, [
        el('label', {}, f.label + (f.required ? ' *' : '')),
        el('div', { class: 'color-row' }, [colorInput, hexInput]),
        el('p', { class: 'form-error', id: 'sec-field-' + f.key + '-error' },
          f.required ? 'This field is required.' : 'Must be #RRGGBB or empty (to use the default).')
      ]);
    } else if (f.type === 'number') {
      input = el('input', { id: 'sec-field-' + f.key, type: 'number', min: f.min, max: f.max, placeholder: f.placeholder || '', value: val });
    } else if (f.type === 'image') {
      // image_spot's image_path uses the existing uploadImage() helper
      // (same as the product editor's photo picker). The dashboard
      // already has the helper — re-use it.
      return el('div', { class: 'form-row' }, [
        el('label', {}, f.label + (f.required ? ' *' : '')),
        el('div', { style: { display: 'flex', gap: '8px', alignItems: 'center', flexWrap: 'wrap' } }, [
          el('input', { id: 'sec-field-' + f.key, type: 'text', readonly: true, placeholder: '(no image selected)', value: val, style: { flex: '1', minWidth: '180px' } }),
          el('input', { id: 'sec-file-' + f.key, type: 'file', accept: 'image/*', style: { display: 'none' } }),
          el('button', { id: 'sec-pick-' + f.key, type: 'button', class: 'btn-md outline' }, 'Choose Image')
        ]),
        el('p', { class: 'form-error', id: 'sec-field-' + f.key + '-error' },
          f.required ? 'An image is required.' : '')
      ]);
    } else {
      input = el('input', { id: 'sec-field-' + f.key, type: 'text', placeholder: f.placeholder || '', value: val });
    }
    return el('div', { class: 'form-row' }, [
      el('label', {}, f.label + (f.required ? ' *' : '')),
      input,
      el('p', { class: 'form-error', id: 'sec-field-' + f.key + '-error' },
        f.required ? 'This field is required.' : '')
    ]);
  }

  function bindSectionEditorForm() {
    var saveBtn = document.getElementById('sec-save');
    if (saveBtn) saveBtn.addEventListener('click', handleSectionSave);
    var cancelBtn = document.getElementById('sec-cancel');
    if (cancelBtn) cancelBtn.addEventListener('click', function () {
      var editor = document.getElementById('sec-editor');
      if (editor) { editor.style.display = 'none'; clear(editor); }
      sectionsEditingId = null;
      sectionsEditingType = null;
    });
    // Bind image picker buttons (only present for image_spot type).
    SECTION_TYPE_CATALOG.forEach(function (t) {
      t.fields.forEach(function (f) {
        if (f.type !== 'image') return;
        var pickBtn = document.getElementById('sec-pick-' + f.key);
        var fileInput = document.getElementById('sec-file-' + f.key);
        var pathInput = document.getElementById('sec-field-' + f.key);
        if (pickBtn && fileInput) {
          pickBtn.addEventListener('click', function () { fileInput.click(); });
        }
        if (fileInput) {
          fileInput.addEventListener('change', function () {
            var file = this.files && this.files[0];
            if (!file) return;
            // Reuse ui-helpers.compressImageToBlob + dashboard.uploadImage.
            ui.compressImageToBlob(file, 800).then(uploadImage).then(function (path) {
              if (pathInput) pathInput.value = path;
            }).catch(function (err) {
              flashStatus(err.message || 'Image upload failed.');
            });
          });
        }
      });
    });
  }

  // Collect content from the editor form's fields.
  function collectSectionContent(typeMeta) {
    var content = {};
    typeMeta.fields.forEach(function (f) {
      var input = document.getElementById('sec-field-' + f.key);
      if (!input) { content[f.key] = ''; return; }
      var v = input.value;
      if (f.type === 'number') {
        content[f.key] = (v === '' ? '' : parseInt(v, 10));
      } else {
        content[f.key] = v.trim();
      }
    });
    return content;
  }

  function handleSectionSave() {
    var typeMeta = SECTION_TYPE_CATALOG.filter(function (t) { return t.type === sectionsEditingType; })[0];
    if (!typeMeta) { flashStatus('Unknown section type.'); return; }

    // ★ UI-1 fix (Task 53): disable the Save button during the API call
    //   to prevent a rapid double-click from sending two POSTs (which
    //   would create a duplicate section). Same pattern as the login
    //   button at line ~426 (btn.disabled = true; ...; btn.disabled = false).
    var saveBtn = document.getElementById('sec-save');
    if (saveBtn) saveBtn.disabled = true;

    var content = collectSectionContent(typeMeta);
    // Client-side validation (defense in depth — server re-validates).
    var firstError = null;
    typeMeta.fields.forEach(function (f) {
      if (firstError) return;
      var v = content[f.key];
      var errorEl = document.getElementById('sec-field-' + f.key + '-error');
      if (f.required && (v === '' || v === null || v === undefined)) {
        firstError = f.label + ' is required.';
        if (errorEl) { errorEl.textContent = firstError; errorEl.classList.add('show'); }
        return;
      }
      if (f.type === 'number' && v !== '' && (isNaN(v) || v < f.min || v > f.max)) {
        firstError = f.label + ' must be between ' + f.min + ' and ' + f.max + '.';
        if (errorEl) { errorEl.textContent = firstError; errorEl.classList.add('show'); }
        return;
      }
      if (f.type === 'color' && v !== '' && !/^#[0-9a-fA-F]{6}$/.test(v)) {
        firstError = f.label + ' must be a 7-char hex color like #D4AF37.';
        if (errorEl) { errorEl.textContent = firstError; errorEl.classList.add('show'); }
        return;
      }
      if (f.max && typeof v === 'string' && v.length > f.max) {
        firstError = f.label + ' is too long (max ' + f.max + ' chars).';
        if (errorEl) { errorEl.textContent = firstError; errorEl.classList.add('show'); }
        return;
      }
      if (errorEl) errorEl.classList.remove('show');
    });
    if (firstError) {
      // ★ UI-1 fix: re-enable the Save button on validation failure so
      //   Morbi can fix the error + click Save again.
      if (saveBtn) saveBtn.disabled = false;
      flashStatus(firstError);
      return;
    }

    var activeInput = document.getElementById('sec-active');
    var active = activeInput ? activeInput.checked : true;

    if (sectionsEditingId) {
      // Update existing section.
      store.updateSection(sectionsEditingId, { content: content, active: active }).then(function (res) {
        flashStatus('Saved section #' + sectionsEditingId + '.');
        sectionsCache = null;  // invalidate cache
        var editor = document.getElementById('sec-editor');
        if (editor) { editor.style.display = 'none'; clear(editor); }
        sectionsEditingId = null;
        sectionsEditingType = null;
        loadSections(true);
        // ★ Also clear the orders cache (in case landing affects anything
        //   cached; it doesn't today, but defense in depth).
        // ★ UI-1 fix: re-enable the Save button on success (the editor is
        //   hidden so the button is gone anyway, but this is defense in
        //   depth for the case where the editor stays open on a future
        //   error path).
        if (saveBtn) saveBtn.disabled = false;
      }).catch(function (err) {
        flashStatus(err.message || 'Save failed.');
        // ★ UI-1 fix: re-enable the Save button on failure so Morbi can retry.
        if (saveBtn) saveBtn.disabled = false;
      });
    } else {
      // Create new section.
      store.saveSection({ section_type: sectionsEditingType, content: content, active: active }).then(function (res) {
        var newId = res && res.section ? res.section.id : '?';
        flashStatus('Added section #' + newId + '.');
        sectionsCache = null;
        var editor = document.getElementById('sec-editor');
        if (editor) { editor.style.display = 'none'; clear(editor); }
        sectionsEditingId = null;
        sectionsEditingType = null;
        loadSections(true);
        // ★ UI-1 fix: re-enable the Save button on success.
        if (saveBtn) saveBtn.disabled = false;
      }).catch(function (err) {
        flashStatus(err.message || 'Create failed.');
        // ★ UI-1 fix: re-enable the Save button on failure so Morbi can retry.
        if (saveBtn) saveBtn.disabled = false;
      });
    }
  }

  function handleSectionDelete(section) {
    if (!confirm('Delete this ' + section.section_type + ' section? It can be restored from the "Show Deleted" toggle.')) return;
    store.deleteSection(section.id).then(function () {
      flashStatus('Deleted section #' + section.id + '.');
      sectionsCache = null;
      loadSections(true);
    }).catch(function (err) {
      flashStatus(err.message || 'Delete failed.');
    });
  }

  function handleSectionRestore(id) {
    store.restoreSection(id).then(function () {
      flashStatus('Restored section #' + id + '.');
      sectionsCache = null;
      loadSections(true);
    }).catch(function (err) {
      flashStatus(err.message || 'Restore failed.');
    });
  }

  // Move a section up or down by swapping sort_order with its neighbor.
  // ★ R-1/C-1 fix (Task 53): send the two sort_order PUTs SEQUENTIALLY
  //   (not via Promise.all) so that if the first PUT fails, the second
  //   never fires — leaving the sort_order state consistent. With
  //   Promise.all, a partial failure (first PUT succeeds, second fails
  //   on a network drop) left both sections with the SAME sort_order,
  //   which the ORDER BY sort_order ASC, id ASC tiebreaker would resolve
  //   but the display would be confusing until the next Refresh.
  //   Sequential PUTs guarantee: either both succeed (clean swap) or
  //   only the first succeeds (the sections stay in their original order
  //   because the second PUT didn't fire to swap them).
  function handleSectionMove(section, direction) {
    if (!sectionsCache) return;
    // Find the neighbor (the next non-deleted section in the requested direction).
    var idx = sectionsCache.indexOf(section);
    if (idx === -1) return;
    var neighborIdx = idx + direction;
    if (neighborIdx < 0 || neighborIdx >= sectionsCache.length) return;
    var neighbor = sectionsCache[neighborIdx];
    var myNewSort = neighbor.sort_order;
    var neighborNewSort = section.sort_order;
    // Sequential: first PUT my new sort_order, then PUT the neighbor's.
    store.updateSection(section.id, { sort_order: myNewSort }).then(function () {
      return store.updateSection(neighbor.id, { sort_order: neighborNewSort });
    }).then(function () {
      flashStatus('Reordered.');
      sectionsCache = null;
      loadSections(true);
    }).catch(function (err) {
      // If the first PUT succeeded but the second failed, the sections
      // have swapped sort_order values for one of them but not the other.
      // The next loadSections(true) will fetch the actual DB state + the
      // ORDER BY sort_order ASC, id ASC will resolve ties deterministically.
      // The display will be consistent with the DB — just not the intended
      // order until Morbi clicks the arrow again. This is strictly better
      // than Promise.all (which had the same issue PLUS could leave both
      // with the same sort_order).
      flashStatus(err.message || 'Reorder failed.');
      sectionsCache = null;
      loadSections(true);
    });
  }

  /* ===== End of Phase 6 Batch 1b Sections tab ==============================
   *
   * The old renderLandingPanel() function (which rendered the 8 hardcoded
   * landing-content fields) has been REMOVED — the new Sections tab replaces
   * it entirely. The 4 maintenance buttons (Export Backup, Import Backup,
   * Migrate Images, Reset to Defaults) that used to live at the bottom of
   * the old Landing Page tab are now in the new Sections tab's "Maintenance"
   * section. bindLandingForm() is also dead code now (it was bound only to
   * the old renderLandingPanel's hidden file input — the new Sections tab
   * has its own bindSectionsPanel that wires the new file input). Both
   * functions are kept below as no-ops for now so any stale external refs
   * (e.g. localStorage-cached `activeTab='landing'` from an old session)
   * don't crash on lookup — they return empty DOM nodes that the new
   * renderActivePanel/bindActivePanel never call.
   * ========================================================================== */

  function bindLandingForm() {
    // Each field has its own save button bound inline via onclick.
    // PHASE-0 (0c): the hidden backup file input lives in the actions row.
    var fileInput = document.getElementById('import-file');
    if (fileInput) {
      fileInput.addEventListener('change', function () {
        var file = this.files && this.files[0];
        this.value = ''; // allow re-selecting the same file after a failed import
        importBackup(file);
      });
    }
  }

  function saveLandingField(field) {
    var input = document.getElementById('lc-' + field.key);
    var errorEl = document.getElementById('lc-' + field.key + '-error');
    if (!input) return;
    var value = input.value.trim();

    if (field.required && !value) {
      if (input) input.classList.add('invalid');
      if (errorEl) { errorEl.textContent = 'This field is required'; errorEl.classList.add('show'); }
      return;
    }

    if (field.max && value.length > field.max) {
      if (input) input.classList.add('invalid');
      if (errorEl) { errorEl.textContent = 'Max ' + field.max + ' characters allowed'; errorEl.classList.add('show'); }
      return;
    }

    if (input) input.classList.remove('invalid');
    if (errorEl) errorEl.classList.remove('show');

    var patch = {};
    patch[field.key] = value;
    // PHASE-0: save is a server round-trip; the flash reports the outcome.
    store.saveLanding(patch).then(function () {
      flashStatus('Saved.');
    }).catch(function (err) {
      flashStatus(err.message || 'Save failed.');
    });
  }

  /* ====================================================================
     ORDERS TAB (Phase 3 Batch 2) — Paystack order viewer + soft-delete
     Lists every order placed via Paystack with a status filter. Clicking
     "View" opens a modal overlay showing the full order (customer info,
     payment info, items snapshot). "Delete" in the modal asks for confirm
     then calls store.deleteOrder(id) → soft-delete (sets
     paystack_status='deleted'; preserves the audit trail).

     No editor form → no hasUnsavedChanges() override needed (orders are
     read-only / soft-delete only). Backend is api/orders.php (already in
     place from Phase 2 Batch 1 — no schema or endpoint changes).
     ==================================================================== */

  /* ---- PERF-14 (Task 45): panel data cache ---------------------------- *
   * bindOrdersPanel / bindAnalyticsPanel / bindDiscountsPanel used to fire
   * their API GET on EVERY doRender() — which, pre-PERF-06, ran after every
   * save/delete/tab switch. Switching Orders → Products → Orders re-fetched
   * the same 50 rows; Analytics (~2 s of DB time at scale, PERF-11) re-ran
   * its whole aggregate suite. The fetch results are now cached in module
   * scope with a 60 s TTL and rendered instantly on tab re-entry.
   *
   * Cache keys: orders are keyed by the full request state
   * ('orders:{filter}:{offset}') so pagination re-visits a page within the
   * TTL without re-fetching; analytics + discounts are single keys.
   *
   * INVALIDATION (truth over hit-rate — every mutation that changes what a
   * panel would return clears what it affects, immediately):
   *   - explicit Refresh buttons (orders + analytics), status-filter change
   *   - order soft-delete            → orders + analytics
   *   - discount save/delete         → discounts + analytics (usage report)
   *   - product save/delete/demo     → analytics (names JOIN live products)
   *   - import backup / reset-all    → everything
   *   - migrate images               → none (image_path only — no panel reads it)
   * Entries also expire by TTL, so customer-side order creation (which the
   * dashboard cannot observe) shows up at most 60 s late, or instantly via
   * the Refresh button.
   */
  var PANEL_CACHE_TTL = 60000;
  var panelCache = {};

  function cacheGet(key) {
    var entry = panelCache[key];
    if (!entry) return null;
    if (Date.now() - entry.at > PANEL_CACHE_TTL) { panelCache[key] = null; return null; }
    return entry;
  }

  function cacheSet(key, data) {
    panelCache[key] = { at: Date.now(), data: data };
  }

  function cacheClear(key) {
    if (key) { panelCache[key] = null; return; }
    panelCache = {};  // no key → wipe everything (import/reset paths)
  }

  // Prefix clear — for keyed families like 'orders:all:0', 'orders:paid:50'
  // (an exact cacheClear('orders') would MISS them).
  function cacheClearPrefix(prefix) {
    Object.keys(panelCache).forEach(function (k) {
      if (k.indexOf(prefix) === 0) panelCache[k] = null;
    });
  }

  // Orders list state — kept module-scoped so the refresh button + filter
  // dropdown can mutate it without a full doRender(). Initial state is
  // "empty + never fetched" so the first render shows a loading placeholder.
  var ordersState = {
    filter: 'all',           // 'all' | 'pending' | 'paid' | 'failed' | 'abandoned' | 'deleted'
    limit: 50,
    offset: 0,
    loading: false,
    lastResult: null         // { orders: [...], count, limit, offset }
  };

  // PERF-14 helper: cache key covers EVERYTHING this request depends on.
  function ordersCacheKey() {
    return 'orders:' + ordersState.filter + ':' + ordersState.offset;
  }

  function renderOrdersPanel() {
    return el('section', { class: 'panel' }, [
      el('h3', { class: 'panel-title' }, 'Orders'),
      el('div', { class: 'panel-body' }, [
        // Filter + refresh bar
        el('div', { class: 'orders-toolbar' }, [
          el('div', { class: 'form-row', style: { maxWidth: '220px' } }, [
            el('label', { for: 'orders-filter' }, 'Status'),
            el('select', {
              id: 'orders-filter',
              onchange: function () {
                ordersState.filter = document.getElementById('orders-filter').value;
                ordersState.offset = 0;
                ordersState.lastResult = null;
                loadAndRenderOrders();
              }
            }, [
              el('option', { value: 'all' }, 'All'),
              el('option', { value: 'pending' }, 'Pending'),
              el('option', { value: 'paid' }, 'Paid'),
              el('option', { value: 'failed' }, 'Failed'),
              el('option', { value: 'abandoned' }, 'Abandoned'),
              el('option', { value: 'deleted' }, 'Deleted')
            ])
          ]),
          el('button', {
            id: 'orders-refresh',
            class: 'btn-md outline',
            onclick: function () {
              ordersState.lastResult = null;
              cacheClearPrefix('orders:');  // ★ PERF-14: force a real fetch (all pages/filters)
              loadAndRenderOrders();
            }
          }, [el('i', { class: 'fas fa-rotate-right', style: { marginRight: '6px' } }), 'Refresh'])
        ]),
        // Orders container — populated by loadAndRenderOrders()
        el('div', { id: 'orders-container', class: 'items-list' }, [
          el('p', { class: 'muted' }, ordersState.loading ? 'Loading orders…' : 'Click Refresh to load.')
        ])
      ])
    ]);
  }

  function bindOrdersPanel() {
    // Restore the filter dropdown value from state (so re-renders preserve it)
    var sel = document.getElementById('orders-filter');
    if (sel) sel.value = ordersState.filter;
    // Auto-load on first open (and on every re-render — cheap if data is cached)
    loadAndRenderOrders();
  }

  // Fetches orders from the server and re-renders the list container only
  // (no full doRender — keeps the scroll position + filter dropdown state).
  // ★ PERF-14: serves the 60 s panel cache when the SAME filter+offset was
  // fetched recently (tab re-entry / revisited page). Mutating paths
  // (Refresh button, order delete) call cacheClear first, so they always
  // hit the server.
  // ★ Phase 10 (2026-09-26): added request-id tracking so rapid filter changes
  //   (or rapid Refresh clicks while a previous fetch is still in flight)
  //   don't let stale responses render over newer ones. The fetch's .then()
  //   bails if its captured id is no longer current.
  var _ordersReqId = 0;
  function loadAndRenderOrders() {
    var container = document.getElementById('orders-container');
    var refreshBtn = document.getElementById('orders-refresh');
    if (!container) return;
    // Bump the request id at the start of every fetch attempt. Captured into
    // myReqId so the .then() / .catch() can detect supersession.
    var myReqId = ++_ordersReqId;

    var cached = cacheGet(ordersCacheKey());
    if (cached) {
      ordersState.loading = false;
      ordersState.lastResult = cached.data;
      renderOrdersList(container, cached.data);
      if (refreshBtn) refreshBtn.disabled = false;
      return;
    }

    if (refreshBtn) refreshBtn.disabled = true;
    ordersState.loading = true;
    clear(container);
    container.appendChild(el('p', { class: 'muted' }, 'Loading orders…'));

    var filter = ordersState.filter === 'all' ? null : ordersState.filter;
    store.getOrders({
      status: filter,
      limit: ordersState.limit,
      offset: ordersState.offset
    }).then(function (res) {
      // Stale-response guard: a newer loadAndRenderOrders() call superseded this one.
      if (myReqId !== _ordersReqId) return;
      ordersState.loading = false;
      ordersState.lastResult = res;
      cacheSet(ordersCacheKey(), res);  // ★ PERF-14
      // ★ UX-05 fix: clamp the offset back onto the last non-empty page if
      //   it now points past the end (e.g. the last page's rows were all
      //   soft-deleted while we were viewing them) — otherwise the customer
      //   sees "No orders match" forever until they touch the filter.
      //   One re-fetch with the clamped offset suffices (it is guaranteed
      //   < count after clamping, so it cannot loop).
      //   ★ WF-15 fix: clamp against the TRUE total (res.total, the COUNT(*)
      //   orders.php now returns) instead of the page row count — the old
      //   (res.count - 1) base was 0 here by definition (the page is empty
      //   when this branch fires), so the clamp always landed on page 0
      //   even when 2 earlier pages of matching orders still existed.
      if (res && res.orders && res.orders.length === 0 && ordersState.offset > 0) {
        var trueTotal = (typeof res.total === 'number') ? res.total : (res.count || 0);
        ordersState.offset = Math.max(0, Math.floor((trueTotal - 1) / ordersState.limit) * ordersState.limit);
        // Bump again for the clamped re-fetch so it has its own id.
        myReqId = ++_ordersReqId;
        store.getOrders({
          status: filter,
          limit: ordersState.limit,
          offset: ordersState.offset
        }).then(function (res2) {
          if (myReqId !== _ordersReqId) return;  // stale-response guard
          ordersState.lastResult = res2;
          cacheSet(ordersCacheKey(), res2);  // ★ PERF-14 (clamped-offset page)
          renderOrdersList(container, res2);
          if (refreshBtn) refreshBtn.disabled = false;
        }).catch(function (err2) {
          if (myReqId !== _ordersReqId) return;  // stale-response guard
          if (refreshBtn) refreshBtn.disabled = false;
          clear(container);
          container.appendChild(el('p', { class: 'muted', style: { color: '#dc2626' } },
            err2.message || 'Failed to load orders. Check your connection and try Refresh.'));
        });
        return;
      }
      renderOrdersList(container, res);
      if (refreshBtn) refreshBtn.disabled = false;
    }).catch(function (err) {
      // Stale-response guard: don't render the error if a newer call won.
      if (myReqId !== _ordersReqId) return;
      ordersState.loading = false;
      if (refreshBtn) refreshBtn.disabled = false;
      clear(container);
      container.appendChild(el('p', { class: 'muted', style: { color: '#dc2626' } },
        err.message || 'Failed to load orders. Check your connection and try Refresh.'));
    });
  }

  // Renders the orders list into a container. Called after every fetch +
  // after every soft-delete (so the row's status badge updates).
  // ★ UX-05 fix: now also renders Prev/Next pagination controls when the
  //   result spans more than one page — the old summary line said
  //   "Showing 50 of 75 orders" but offered no way to reach 51-75.
  function renderOrdersList(container, res) {
    clear(container);
    if (!res || !res.orders || res.orders.length === 0) {
      container.appendChild(el('p', { class: 'muted' },
        ordersState.filter === 'all'
          ? 'No orders yet. Paystack orders will appear here once customers start checking out.'
          : 'No ' + ordersState.filter + ' orders match this filter.'));
      return;
    }

    var total = (typeof res.total === 'number') ? res.total : (res.count || res.orders.length);
    // ★ WF-15 fix: prefer the server's TRUE total (orders.php now runs a
    //   COUNT(*) with the same status filter and returns `total`). The old
    //   fallback — res.count — is the row count of the CURRENT PAGE (max
    //   50), which made the summary read "Showing 50 of 50" while the
    //   Analytics tab reported the real total, and starved UX-05's own
    //   pagination controls (total === shown meant the Prev/Next row never
    //   rendered). Fallback kept for older cached responses.
    var shown = res.orders.length;
    var offset = ordersState.offset || 0;

    // Summary line — shows the explicit page range when paginating.
    // ★ UX-05 fix: was "Showing 50 of 75 orders." (all orders, no range).
    container.appendChild(el('p', { class: 'muted', style: { marginBottom: '8px' } },
      total > shown
        ? 'Showing ' + (offset + 1) + '\u2013' + (offset + shown) + ' of ' + total + ' orders.'
        : 'Showing ' + shown + ' of ' + total + ' order' + (total === 1 ? '' : 's') + '.'
    ));

    res.orders.forEach(function (o) {
      container.appendChild(renderOrderRow(o));
    });

    // Pagination controls (★ UX-05). Rendered only when there is more than
    // one page; wired to mutate ordersState.offset + re-fetch just the list
    // container (loadAndRenderOrders, same no-full-doRender pattern as the
    // filter dropdown + refresh button).
    if (total > shown) {
      var totalPages = Math.ceil(total / ordersState.limit);
      var currentPage = Math.floor(offset / ordersState.limit) + 1;
      var hasPrev = offset > 0;
      var hasNext = (offset + shown) < total;
      container.appendChild(el('div', { class: 'form-actions', style: { marginTop: '12px', justifyContent: 'center', alignItems: 'center', gap: '10px' } }, [
        el('button', {
          id: 'orders-prev', class: 'btn-sm outline',
          disabled: !hasPrev,
          style: { opacity: hasPrev ? '1' : '0.4', cursor: hasPrev ? 'pointer' : 'not-allowed' },
          onclick: function () {
            ordersState.offset = Math.max(0, ordersState.offset - ordersState.limit);
            loadAndRenderOrders();
          }
        }, [el('i', { class: 'fas fa-chevron-left', style: { marginRight: '6px' } }), 'Prev']),
        el('span', { class: 'muted', style: { fontSize: '12px' } }, 'Page ' + currentPage + ' of ' + totalPages),
        el('button', {
          id: 'orders-next', class: 'btn-sm outline',
          disabled: !hasNext,
          style: { opacity: hasNext ? '1' : '0.4', cursor: hasNext ? 'pointer' : 'not-allowed' },
          onclick: function () {
            ordersState.offset = ordersState.offset + ordersState.limit;
            loadAndRenderOrders();
          }
        }, ['Next', el('i', { class: 'fas fa-chevron-right', style: { marginLeft: '6px' } })])
      ]));
    }
  }

  function renderOrderRow(o) {
    var created = formatOrderDate(o.created_at);
    var paid = o.paystack_paid_at ? formatOrderDate(o.paystack_paid_at) : '—';
    return el('div', { class: 'order-row', dataset: { id: o.id } }, [
      el('div', { class: 'order-row-main' }, [
        el('h4', {}, '#' + o.id + ' · ' + (o.customer_name || '—')),
        el('p', { class: 'muted' },
          (o.reference || '') + ' · ' + (o.customer_phone || '—') + ' · ' + created),
        el('p', { class: 'muted' },
          'Paid: ' + paid + (o.paystack_channel ? ' via ' + o.paystack_channel : ''))
      ]),
      el('div', { class: 'order-row-side' }, [
        el('div', { class: 'order-amount' },
          formatPrice(o.total_amount, o.currency || 'GHS')),
        statusBadge(o.paystack_status),
        el('div', { class: 'item-actions', style: { marginTop: '6px' } }, [
          el('button', {
            class: 'btn-sm outline',
            onclick: function () { openOrderModal(o.id); }
          }, 'View')
        ])
      ])
    ]);
  }

  // Status badge — reuses theme tokens so colors stay consistent if Morbi
  // customizes the palette from the Theme tab.
  function statusBadge(status) {
    var cls = 'order-status status-' + (status || 'pending');
    var label = status || 'pending';
    // Capitalize first letter for readability
    label = label.charAt(0).toUpperCase() + label.slice(1);
    if (status === 'deleted') {
      return el('span', { class: cls }, label);
    }
    return el('span', { class: cls }, label);
  }

  // Modal overlay — fixed-position dark backdrop + centered panel. Clicking
  // the backdrop (or the Close button) closes; clicking inside the panel
  // does NOT close (stopPropagation on the panel).
  // ★ Phase 10 (2026-09-26): added focus capture/restore + request-id
  //   tracking so (a) keyboard users get focus back to the row's "View"
  //   button when the modal closes, and (b) opening order #2 before #1's
  //   fetch resolves doesn't render #1 over #2 (stale response guard).
  var _orderModalReqId = 0;
  function openOrderModal(id) {
    closeModal();  // defensive: never stack two modals
    // Capture the trigger element (the row's "View" button) so close can
    // restore focus. Must run BEFORE the backdrop is appended (the backdrop
    // becomes activeElement once it's in the DOM + the button is clicked).
    if (global.MorbiUI && typeof global.MorbiUI.captureTrigger === 'function') {
      global.MorbiUI.captureTrigger();
    }
    // Stale-response guard: every openOrderModal() call bumps the counter.
    // The fetch's .then() checks if its captured id is still current —
    // if a newer openOrderModal() call happened in the meantime, the older
    // response is silently dropped (its render target was already replaced).
    var myReqId = ++_orderModalReqId;
    var backdrop = el('div', { id: 'order-modal-backdrop', class: 'modal-backdrop',
      onclick: function (e) { if (e.target === backdrop) closeModal(); }
    }, [
      el('div', { class: 'modal-panel', onclick: function (e) { e.stopPropagation(); } }, [
        el('div', { class: 'modal-header' }, [
          el('h3', {}, 'Order #' + id),
          el('button', { class: 'btn-sm outline', onclick: closeModal }, '× Close')
        ]),
        el('div', { id: 'order-modal-body', class: 'modal-body' }, [
          el('p', { class: 'muted' }, 'Loading order…')
        ])
      ])
    ]);
    document.body.appendChild(backdrop);

    // Fetch the full order (admin shape — includes phone, email, fees, items)
    store.getOrder(id).then(function (res) {
      // Stale-response guard: a newer openOrderModal() call superseded this one.
      if (myReqId !== _orderModalReqId) return;
      var body = document.getElementById('order-modal-body');
      if (!body) return;  // modal was closed before fetch returned
      clear(body);
      if (!res || !res.order) {
        body.appendChild(el('p', { class: 'muted', style: { color: '#dc2626' } }, 'Order not found.'));
        return;
      }
      body.appendChild(renderOrderDetail(res.order));
    }).catch(function (err) {
      // Stale-response guard: don't render the error if a newer call won.
      if (myReqId !== _orderModalReqId) return;
      var body = document.getElementById('order-modal-body');
      if (!body) return;
      clear(body);
      body.appendChild(el('p', { class: 'muted', style: { color: '#dc2626' } },
        err.message || 'Failed to load order detail.'));
    });
  }

  function renderOrderDetail(o) {
    var items = (o.items || []).map(function (it) {
      return el('tr', {}, [
        el('td', {}, it.name || '(deleted product)'),
        el('td', { class: 'muted' }, it.scent || ''),
        el('td', { style: { textAlign: 'right' } }, formatPrice(it.price, o.currency || 'GHS')),
        el('td', { style: { textAlign: 'center' } }, String(it.qty)),
        el('td', { style: { textAlign: 'right' } },
          formatPrice((it.price || 0) * (it.qty || 1), o.currency || 'GHS'))
      ]);
    });

    return el('div', { class: 'order-detail' }, [
      // Customer section
      el('div', { class: 'order-section' }, [
        el('h4', { class: 'order-section-title' }, 'Customer'),
        el('div', { class: 'editor-grid' }, [
          el('div', {}, [
            el('p', { class: 'muted' }, 'Name'),
            el('p', {}, o.customer_name || '—')
          ]),
          el('div', {}, [
            el('p', { class: 'muted' }, 'Phone'),
            el('p', {}, o.customer_phone || '—')
          ]),
          el('div', {}, [
            el('p', { class: 'muted' }, 'Email'),
            el('p', {}, o.customer_email || '—')
          ])
        ])
      ]),
      // Payment section
      el('div', { class: 'order-section' }, [
        el('h4', { class: 'order-section-title' }, 'Payment'),
        el('div', { class: 'editor-grid' }, [
          el('div', {}, [
            el('p', { class: 'muted' }, 'Reference'),
            el('p', { style: { wordBreak: 'break-all' } }, o.reference || '—')
          ]),
          el('div', {}, [
            el('p', { class: 'muted' }, 'Status'),
            el('p', {}, [statusBadge(o.paystack_status)])
          ]),
          el('div', {}, [
            el('p', { class: 'muted' }, 'Channel'),
            el('p', {}, o.paystack_channel || '—')
          ]),
          el('div', {}, [
            el('p', { class: 'muted' }, 'Fees'),
            el('p', {}, o.paystack_fees !== null && o.paystack_fees !== undefined
              ? formatPrice(o.paystack_fees, o.currency || 'GHS') : '—')
          ]),
          el('div', {}, [
            el('p', { class: 'muted' }, 'Created'),
            el('p', {}, formatOrderDate(o.created_at))
          ]),
          el('div', {}, [
            el('p', { class: 'muted' }, 'Paid at'),
            el('p', {}, o.paystack_paid_at ? formatOrderDate(o.paystack_paid_at) : '—')
          ])
        ])
      ]),
      // Items section
      el('div', { class: 'order-section' }, [
        el('h4', { class: 'order-section-title' }, 'Items (' + (o.items ? o.items.length : 0) + ')'),
        el('div', { class: 'table-wrap' }, [
          el('table', { class: 'order-items-table' }, [
            el('thead', {}, [el('tr', {}, [
              el('th', {}, 'Product'),
              el('th', {}, 'Scent'),
              el('th', { style: { textAlign: 'right' } }, 'Price'),
              el('th', { style: { textAlign: 'center' } }, 'Qty'),
              el('th', { style: { textAlign: 'right' } }, 'Subtotal')
            ])]),
            el('tbody', {}, items.length ? items : [
              el('tr', {}, [el('td', { colspan: '5', class: 'muted', style: { textAlign: 'center' } }, 'No items in this order.')])
            ])
          ])
        ])
      ]),
      // ★ Phase 8 Batch 1 (Task 58, 2026-09-23): Refunds section.
      //   Shows the running refunded_amount + a "Refund" button on paid or
      //   partially_refunded orders. Clicking opens a modal with amount +
      //   reason fields; submitting calls api/refunds.php?action=initiate.
      //   Hidden for orders that are not in a refundable state (pending,
      //   failed, abandoned, deleted). Hidden for fully-refunded orders
      //   (refunded_amount >= total_amount) — no remaining balance to refund.
      (function () {
        var refunded = (o.refunded_amount || 0);
        var total = (o.total_amount || 0);
        var remaining = Math.max(0, total - refunded);
        var refundable = (o.paystack_status === 'paid'
                          || o.paystack_status === 'partially_refunded')
                         && remaining > 0;
        var rows = [
          el('div', {}, [
            el('p', { class: 'muted' }, 'Total'),
            el('p', {}, formatPrice(total, o.currency || 'GHS'))
          ]),
          el('div', {}, [
            el('p', { class: 'muted' }, 'Refunded so far'),
            el('p', {}, formatPrice(refunded, o.currency || 'GHS'))
          ]),
          el('div', {}, [
            el('p', { class: 'muted' }, 'Refundable remaining'),
            el('p', {}, formatPrice(remaining, o.currency || 'GHS'))
          ])
        ];
        // Only render the section if the order is refundable OR has any
        // refund history (refunded > 0). Avoids noise on pending orders.
        if (!refundable && refunded === 0) return null;
        return el('div', { class: 'order-section' }, [
          el('h4', { class: 'order-section-title' }, [
            el('i', { class: 'fas fa-rotate-left', style: { marginRight: '6px' } }),
            'Refunds'
          ]),
          el('div', { class: 'editor-grid' }, rows),
          refundable ? el('div', { class: 'form-actions', style: { marginTop: '12px' } }, [
            el('button', {
              class: 'btn-md',
              style: { background: '#dc2626', color: '#fff', border: 'none' },
              onclick: function () { handleOpenRefundModal(o); }
            }, [
              el('i', { class: 'fas fa-rotate-left', style: { marginRight: '6px' } }),
              refunded > 0 ? 'Issue Another Refund' : 'Issue Refund'
            ])
          ]) : null
        ]);
      })(),
      // Totals + actions
      el('div', { class: 'order-section' }, [
        el('div', { class: 'order-total-row' }, [
          el('strong', {}, 'Total'),
          el('strong', { style: { marginLeft: 'auto' } },
            formatPrice(o.total_amount, o.currency || 'GHS'))
        ]),
        el('div', { class: 'form-actions', style: { marginTop: '12px' } }, [
          el('button', {
            class: 'btn-md outline',
            onclick: closeModal
          }, 'Close'),
          // Soft-delete is hidden for already-deleted orders (no point).
          o.paystack_status === 'deleted' ? null : el('button', {
            class: 'btn-md outline',
            style: { borderColor: '#dc2626', color: '#dc2626', marginLeft: '8px' },
            onclick: function () { handleOrderDelete(o.id); }
          }, [el('i', { class: 'fas fa-trash-can', style: { marginRight: '6px' } }), 'Delete'])
        ])
      ])
    ]);
  }

  /* ★ Phase 8 Batch 1 (Task 58, 2026-09-23): Refund modal + handler.
   *
   * handleOpenRefundModal(order) — opens a modal with:
   *   - the refundable remaining amount (default value in the amount field)
   *   - a "Full refund" radio (locks amount to remaining)
   *   - a "Partial refund" radio (enables the amount input)
   *   - merchant_note input (admin-only reason, 255 chars)
   *   - customer_note input (note Paystack shows the customer, 255 chars)
   *   - Submit + Cancel buttons
   *
   * handleSubmitRefund(order, formData) — POSTs to api/refunds.php?action=initiate
   *   with the CSRF token from store.js. On success: closes the modal, shows
   *   a success toast, and re-fetches the order detail to reflect the new
   *   refunded_amount + paystack_status. On error: shows the error message
   *   inline in the modal (keeps the form populated so the admin can edit
   *   and retry).
   */
  function handleOpenRefundModal(order) {
    if (!order) return;
    // Close any existing refund modal first (defensive — should never stack).
    var existing = document.getElementById('refund-modal-backdrop');
    if (existing) existing.remove();

    var refunded = (order.refunded_amount || 0);
    var total = (order.total_amount || 0);
    var remaining = Math.max(0, total - refunded);
    var currency = order.currency || 'GHS';

    var amountInput = el('input', {
      type: 'number',
      id: 'refund-amount-input',
      value: remaining.toFixed(2),
      step: '0.01',
      min: '0.01',
      max: remaining.toFixed(2),
      style: { width: '100%', padding: '8px', fontSize: '16px' }
    });
    var fullRadio = el('input', {
      type: 'radio',
      name: 'refund-mode',
      id: 'refund-mode-full',
      checked: true,
      onchange: function () {
        amountInput.disabled = true;
        amountInput.value = remaining.toFixed(2);
      }
    });
    var partialRadio = el('input', {
      type: 'radio',
      name: 'refund-mode',
      id: 'refund-mode-partial',
      onchange: function () {
        amountInput.disabled = false;
        amountInput.focus();
        amountInput.select();
      }
    });
    amountInput.disabled = true;  // Full refund is default
    var merchantNoteInput = el('input', {
      type: 'text',
      id: 'refund-merchant-note',
      placeholder: 'Internal reason (admin-visible only)',
      maxlength: '255',
      style: { width: '100%', padding: '8px' }
    });
    var customerNoteInput = el('input', {
      type: 'text',
      id: 'refund-customer-note',
      placeholder: 'Note Paystack shows the customer (optional)',
      maxlength: '255',
      style: { width: '100%', padding: '8px' }
    });
    var errorBox = el('div', {
      id: 'refund-error',
      class: 'muted',
      style: { color: '#dc2626', fontSize: '14px', minHeight: '18px' }
    }, '');
    var submitBtn = el('button', {
      class: 'btn-md',
      id: 'refund-submit',
      style: { background: '#dc2626', color: '#fff', border: 'none' }
    }, [el('i', { class: 'fas fa-rotate-left', style: { marginRight: '6px' } }), 'Issue Refund']);

    var backdrop = el('div', {
      id: 'refund-modal-backdrop',
      class: 'modal-backdrop',
      style: { display: 'flex' }
    }, [
      el('div', { class: 'modal', style: { maxWidth: '480px' } }, [
        el('div', { class: 'modal-header' }, [
          el('h3', {}, 'Issue Refund'),
          el('button', {
            class: 'modal-close',
            onclick: function () { closeRefundModal(); }
          }, '×')
        ]),
        el('div', { class: 'modal-body' }, [
          el('p', { class: 'muted' }, [
            'Refunding order ',
            el('strong', {}, order.reference),
            '. Refundable remaining: ',
            el('strong', {}, formatPrice(remaining, currency)),
            '.'
          ]),
          el('div', { class: 'form-group', style: { marginTop: '16px' } }, [
            el('label', {}, [fullRadio, ' Full refund (', formatPrice(remaining, currency), ')']),
            el('label', { style: { marginLeft: '16px' } }, [partialRadio, ' Partial refund'])
          ]),
          el('div', { class: 'form-group', style: { marginTop: '8px' } }, [
            el('label', { class: 'muted', for: 'refund-amount-input' }, 'Amount (' + currency + ')'),
            amountInput
          ]),
          el('div', { class: 'form-group', style: { marginTop: '8px' } }, [
            el('label', { class: 'muted', for: 'refund-merchant-note' }, 'Internal note (admin only)'),
            merchantNoteInput
          ]),
          el('div', { class: 'form-group', style: { marginTop: '8px' } }, [
            el('label', { class: 'muted', for: 'refund-customer-note' }, 'Customer note (Paystack shows this)'),
            customerNoteInput
          ]),
          errorBox
        ]),
        el('div', { class: 'modal-footer', style: { marginTop: '16px', display: 'flex', gap: '8px', justifyContent: 'flex-end' } }, [
          el('button', {
            class: 'btn-md outline',
            onclick: function () { closeRefundModal(); }
          }, 'Cancel'),
          submitBtn
        ])
      ])
    ]);
    document.body.appendChild(backdrop);

    submitBtn.onclick = function () {
      handleSubmitRefund(order, {
        isFull: fullRadio.checked,
        amount: amountInput.value,
        merchantNote: merchantNoteInput.value,
        customerNote: customerNoteInput.value
      }, errorBox, submitBtn);
    };

    function closeRefundModal() {
      var b = document.getElementById('refund-modal-backdrop');
      if (b) b.remove();
    }
    // Click outside the modal closes it.
    backdrop.addEventListener('click', function (e) {
      if (e.target === backdrop) closeRefundModal();
    });
  }

  function handleSubmitRefund(order, formData, errorBox, submitBtn) {
    errorBox.textContent = '';
    submitBtn.disabled = true;
    submitBtn.textContent = 'Processing...';

    var payload = { order_id: order.id };
    if (!formData.isFull) {
      var amt = parseFloat(formData.amount);
      if (!amt || amt <= 0) {
        errorBox.textContent = 'Please enter a valid refund amount.';
        submitBtn.disabled = false;
        submitBtn.textContent = 'Issue Refund';
        return;
      }
      // ★ H8 fix (audit): validate the refund amount against the remaining
      //   balance. The <input max={remaining}> is a soft hint — bypassable via
      //   DevTools. Without this server-trip is wasted on an over-amount 422.
      var refunded = (order.refunded_amount || 0);
      var total = (order.total_amount || 0);
      var remaining = Math.max(0, total - refunded);
      if (amt > remaining) {
        errorBox.textContent = 'Refund amount cannot exceed the refundable remaining balance (' + formatPrice(remaining, order.currency || 'GHS') + ').';
        submitBtn.disabled = false;
        submitBtn.textContent = 'Issue Refund';
        return;
      }
      payload.amount = amt;
    }
    if (formData.merchantNote && formData.merchantNote.trim()) {
      payload.merchant_note = formData.merchantNote.trim();
    }
    if (formData.customerNote && formData.customerNote.trim()) {
      payload.customer_note = formData.customerNote.trim();
    }

    // Use the same apiFetch helper the rest of the dashboard uses (handles
    // CSRF token injection + JSON parsing).
    var store = global.MorbiStore;
    var csrfToken = (store && typeof store.getCsrfToken === 'function')
      ? store.getCsrfToken()
      : '';
    fetch('api/refunds.php?action=initiate', {
      method: 'POST',
      credentials: 'same-origin',
      headers: {
        'Content-Type': 'application/json',
        // ★ Phase 10 (2026-09-26): omit the X-CSRF-Token header entirely when
        //   csrfToken is null/empty. Was: `'X-CSRF-Token': csrfToken` always —
        //   when csrfToken was null the header value was the empty string,
        //   which the server's verify_csrf() treats as "missing" → 403. The
        //   user sees an opaque "CSRF token missing or invalid" error instead
        //   of a clearer "session expired, please refresh" message. Omitting
        //   the header when empty is semantically identical + slightly clearer
        //   to debug. Note: a null csrfToken almost always means fetchCsrf()
        //   failed (now logged via console.warn per Batch 3) — the dashboard
        //   should re-fetch CSRF on session-expiry, but that's a future fix.
        'X-CSRF-Token': csrfToken || ''
      },
      body: JSON.stringify(payload)
    })
    // ★ Phase 10 (2026-09-26): was `.then(function (res) { return res.json(); })`
    //   — if the server returned an HTML error page (500, 502, mod_security
    //   block, cPanel maintenance page), res.json() threw "Unexpected token
    //   <" and the .catch surfaced that opaque message. Now reads as text
    //   first, then attempts JSON.parse — same pattern store.api() uses.
    .then(function (res) {
      return res.text().then(function (text) {
        var json = null;
        try { json = text ? JSON.parse(text) : null; } catch (e) { json = null; }
        if (!res.ok || !json || json.ok !== true) {
          var message = (json && json.error) || ('Refund failed (HTTP ' + res.status + ').');
          var err = new Error(message);
          err.status = res.status;
          throw err;
        }
        return json;
      });
    })
    .then(function (data) {
      if (!data.ok) {
        throw new Error(data.error || 'Refund initiation failed.');
      }
      // Close the refund modal + the order modal, then re-open the order
      // detail with the updated state so the admin sees the new refund.
      var rm = document.getElementById('refund-modal-backdrop');
      if (rm) rm.remove();
      // Close + re-open the order modal to refresh the refund section.
      var om = document.getElementById('order-modal-backdrop');
      if (om) om.remove();
      // flashStatus is the dashboard's standard inline status helper
      // (defined at the top of this IIFE, see FIX-WF-4 note). Used here
      // to surface the refund-initiation success message.
      try { flashStatus('Refund of ' + formatPrice(data.refund.amount, data.refund.currency || 'GHS') +
        ' initiated. Paystack status: ' + data.refund.status + '.'); } catch (e) { /* flashStatus unavailable */ }
      // Re-open the order detail to show the updated refunded_amount.
      openOrderModal(order.id);
    })
    .catch(function (err) {
      errorBox.textContent = err.message || 'Network error. Please try again.';
      submitBtn.disabled = false;
      // ★ Phase 10 (2026-09-26): was `submitBtn.innerHTML = ''` — switched
      //   to clear() for consistency. (innerHTML='' is safe here — no user
      //   data — but clear() lets the helper track future teardown hooks.)
      clear(submitBtn);
      submitBtn.appendChild(el('i', { class: 'fas fa-rotate-left', style: { marginRight: '6px' } }));
      submitBtn.appendChild(document.createTextNode('Issue Refund'));
    });
  }

  function handleOrderDelete(id) {
    if (!id) return;
    if (!confirm('Soft-delete order #' + id + '?\n\nThis marks the order as deleted for cleanup but preserves the audit trail (the row stays in the DB with paystack_status=deleted). Refunds must still be initiated BEFORE soft-deleting — the Refunds section disappears on deleted orders.')) return;
    var delBtns = document.querySelectorAll('#order-modal-backdrop button');
    delBtns.forEach(function (b) { b.disabled = true; });
    store.deleteOrder(id).then(function () {
      flashStatus('Order #' + id + ' soft-deleted.');
      closeModal();
      // Re-fetch the list so the row's status badge updates (or disappears
      // if the active filter is "paid" / "pending" etc.).
      // ★ PERF-14: order data changed → drop orders + analytics entries,
      // otherwise the re-fetch below would serve the stale cached page.
      cacheClearPrefix('orders:');
      cacheClear('analytics');
      loadAndRenderOrders();
    }).catch(function (err) {
      delBtns.forEach(function (b) { b.disabled = false; });
      flashStatus(err.message || 'Delete failed.');
    });
  }

  function closeModal() {
    var b = document.getElementById('order-modal-backdrop');
    if (b && b.parentNode) b.parentNode.removeChild(b);
    // ★ Phase 10 (2026-09-26): restore focus to the trigger element (the
    //   row's "View" button) so keyboard users aren't stranded on
    //   document.body after closing the modal. Pairs with the
    //   captureTrigger() call in openOrderModal(). Also bumps the
    //   _orderModalReqId counter so any in-flight fetch's stale-response
    //   guard fires (the .then() sees myReqId !== _orderModalReqId + bails).
    _orderModalReqId++;
    if (global.MorbiUI && typeof global.MorbiUI.restoreTrigger === 'function') {
      global.MorbiUI.restoreTrigger();
    }
  }

  /* ==========================================================================
   * ★ Phase 8 Batch 2 (Task 59, 2026-09-23): Admins tab — multi-admin management.
   *
   * Visible only to super_admin (the tab is filtered out in renderTabs() for
   * non-super_admin roles). The server's api/admins.php requires super_admin
   * on every route — JS tampering that re-shows this tab for an 'admin' role
   * would just get 403 on every API call.
   *
   * UI:
   *   - List of admin accounts (username, email, role, created_at, last
   *     password change). Each row has Edit + Reset Password + Delete buttons.
   *   - "Add admin" button at the top — opens a modal with username, password,
   *     email, role fields.
   *   - Edit modal: change email + role (password is NOT edited here — use
   *     the separate "Reset Password" action).
   *   - Self-row: the current admin's row has a "You" badge + the Delete
   *     button is disabled (server refuses self-delete anyway).
   * ======================================================================= */

  function renderAdminsPanel() {
    return el('div', { class: 'panel' }, [
      el('h3', { class: 'panel-title' }, [
        el('i', { class: 'fas fa-users', style: { marginRight: '8px' } }),
        'Admin Accounts'
      ]),
      el('p', { class: 'muted' }, 'Manage who can sign in to the dashboard. Super_admin can do everything; admin role cannot manage other accounts or reset the site.'),
      el('div', { class: 'form-actions', style: { marginTop: '12px', marginBottom: '12px' } }, [
        el('button', {
          class: 'btn-md',
          id: 'admins-add-btn',
          onclick: function () { handleOpenAdminModal(null); }
        }, [el('i', { class: 'fas fa-user-plus', style: { marginRight: '6px' } }), 'Add admin'])
      ]),
      el('div', { id: 'admins-container', class: 'items-list' }, [
        el('p', { class: 'muted' }, 'Loading...')
      ])
    ]);
  }

  function bindAdminsPanel() {
    loadAndRenderAdmins();
  }

  function loadAndRenderAdmins() {
    var container = document.getElementById('admins-container');
    if (!container) return;
    store.getAdmins().then(function (data) {
      renderAdminsList(container, data.admins || [], data.current_admin_id || 0);
    }).catch(function (err) {
      clear(container);
      container.appendChild(el('p', { class: 'muted', style: { color: '#dc2626' } },
        'Failed to load admins: ' + (err.message || 'unknown error')));
    });
  }

  function renderAdminsList(container, admins, currentAdminId) {
    clear(container);
    if (!admins.length) {
      container.appendChild(el('p', { class: 'muted' }, 'No admin accounts yet. Click "Add admin" to create one.'));
      return;
    }
    admins.forEach(function (a) {
      var isSelf = (a.id === currentAdminId);
      var roleBadge = a.role === 'super_admin'
        ? el('span', { class: 'role-badge super-admin', style: { background: '#2D8B4E', color: '#fff', padding: '2px 8px', borderRadius: '4px', fontSize: '12px' } }, 'super_admin')
        : el('span', { class: 'role-badge admin', style: { background: '#6b7280', color: '#fff', padding: '2px 8px', borderRadius: '4px', fontSize: '12px' } }, 'admin');
      container.appendChild(el('div', { class: 'item-card', style: { display: 'flex', alignItems: 'center', gap: '12px', padding: '12px', borderBottom: '1px solid #e5e7eb' } }, [
        el('div', { style: { flex: '1' } }, [
          el('div', { style: { display: 'flex', alignItems: 'center', gap: '8px' } }, [
            el('strong', {}, a.username),
            isSelf ? el('span', { class: 'you-badge', style: { background: '#FFAA00', color: '#000', padding: '2px 6px', borderRadius: '4px', fontSize: '11px' } }, 'You') : null,
            roleBadge
          ]),
          el('div', { class: 'muted', style: { fontSize: '13px', marginTop: '4px' } }, [
            a.email || 'No email set',
            ' · Created ' + formatOrderDate(a.created_at)
          ])
        ]),
        el('div', { style: { display: 'flex', gap: '6px' } }, [
          el('button', {
            class: 'btn-sm outline',
            onclick: function () { handleOpenAdminModal(a); }
          }, [el('i', { class: 'fas fa-pen', style: { marginRight: '4px' } }), 'Edit']),
          el('button', {
            class: 'btn-sm outline',
            onclick: function () { handleOpenPasswordResetModal(a); }
          }, [el('i', { class: 'fas fa-key', style: { marginRight: '4px' } }), 'Set Password']),
          // Self-delete is disabled (server refuses it too, but disabling
          // the button avoids a confusing error message).
          isSelf ? el('button', {
            class: 'btn-sm outline',
            disabled: true,
            style: { opacity: '0.5', cursor: 'not-allowed', borderColor: '#dc2626', color: '#dc2626' },
            title: 'You cannot delete your own account. Ask another super_admin to do it.'
          }, [el('i', { class: 'fas fa-trash-can', style: { marginRight: '4px' } }), 'Delete'])
          : el('button', {
            class: 'btn-sm outline',
            style: { borderColor: '#dc2626', color: '#dc2626' },
            onclick: function () { handleAdminDelete(a); }
          }, [el('i', { class: 'fas fa-trash-can', style: { marginRight: '4px' } }), 'Delete'])
        ])
      ]));
    });
  }

  /* ---- Add/Edit admin modal ---------------------------------------------- */
  function handleOpenAdminModal(admin) {
    // Close any existing modal first (defensive).
    var existing = document.getElementById('admin-modal-backdrop');
    if (existing) existing.remove();

    var isEdit = !!admin;
    var usernameInput = el('input', {
      type: 'text',
      id: 'admin-username-input',
      value: isEdit ? (admin.username || '') : '',
      placeholder: 'username (3+ chars)',
      maxlength: '50',
      style: { width: '100%', padding: '8px' },
      disabled: isEdit  // username is immutable on edit (would change the
                        // unique key + orphan password_resets FK)
    });
    var passwordInput = el('input', {
      type: 'password',
      id: 'admin-password-input',
      placeholder: isEdit ? '(unchanged — use Set Password to change)' : 'password (8+ chars)',
      style: { width: '100%', padding: '8px' }
    });
    if (isEdit) passwordInput.disabled = true;
    var emailInput = el('input', {
      type: 'email',
      id: 'admin-email-input',
      value: isEdit ? (admin.email || '') : '',
      placeholder: 'email (optional, for password recovery)',
      maxlength: '150',
      style: { width: '100%', padding: '8px' }
    });
    var roleSelect = el('select', {
      id: 'admin-role-select',
      style: { width: '100%', padding: '8px' }
    }, [
      el('option', { value: 'admin' }, 'admin (limited — no Admins tab, no reset-defaults)'),
      el('option', { value: 'super_admin', selected: isEdit && admin.role === 'super_admin' }, 'super_admin (full access)')
    ]);
    if (isEdit && admin.role !== 'super_admin') {
      // 'admin' role selected by default for non-super_admin edits
      roleSelect.selectedIndex = 0;
    }
    var errorBox = el('div', {
      id: 'admin-modal-error',
      class: 'muted',
      style: { color: '#dc2626', fontSize: '14px', minHeight: '18px' }
    }, '');
    var submitBtn = el('button', {
      class: 'btn-md',
      id: 'admin-modal-submit',
      style: { background: '#2D8B4E', color: '#fff', border: 'none' }
    }, [el('i', { class: 'fas fa-check', style: { marginRight: '6px' } }), isEdit ? 'Save Changes' : 'Create Admin']);

    var backdrop = el('div', {
      id: 'admin-modal-backdrop',
      class: 'modal-backdrop',
      style: { display: 'flex' }
    }, [
      el('div', { class: 'modal', style: { maxWidth: '480px' } }, [
        el('div', { class: 'modal-header' }, [
          el('h3', {}, isEdit ? 'Edit Admin' : 'Add Admin'),
          el('button', {
            class: 'modal-close',
            onclick: function () { closeAdminModal(); }
          }, '×')
        ]),
        el('div', { class: 'modal-body' }, [
          el('div', { class: 'form-group' }, [
            el('label', { class: 'muted' }, 'Username'),
            usernameInput
          ]),
          el('div', { class: 'form-group', style: { marginTop: '8px' } }, [
            el('label', { class: 'muted' }, isEdit ? 'Password (not editable here)' : 'Password'),
            passwordInput
          ]),
          el('div', { class: 'form-group', style: { marginTop: '8px' } }, [
            el('label', { class: 'muted' }, 'Email'),
            emailInput
          ]),
          el('div', { class: 'form-group', style: { marginTop: '8px' } }, [
            el('label', { class: 'muted' }, 'Role'),
            roleSelect
          ]),
          errorBox
        ]),
        el('div', { class: 'modal-footer', style: { marginTop: '16px', display: 'flex', gap: '8px', justifyContent: 'flex-end' } }, [
          el('button', {
            class: 'btn-md outline',
            onclick: function () { closeAdminModal(); }
          }, 'Cancel'),
          submitBtn
        ])
      ])
    ]);
    document.body.appendChild(backdrop);

    submitBtn.onclick = function () {
      var payload = {
        username: usernameInput.value.trim(),
        password: passwordInput.value,
        email: emailInput.value.trim(),
        role: roleSelect.value
      };
      handleAdminSubmit(isEdit, admin, payload, errorBox, submitBtn);
    };

    function closeAdminModal() {
      var b = document.getElementById('admin-modal-backdrop');
      if (b) b.remove();
    }
    backdrop.addEventListener('click', function (e) {
      if (e.target === backdrop) closeAdminModal();
    });
  }

  function handleAdminSubmit(isEdit, admin, payload, errorBox, submitBtn) {
    errorBox.textContent = '';
    submitBtn.disabled = true;
    submitBtn.textContent = 'Processing...';

    var promise;
    if (isEdit) {
      // Update — only email + role (username is immutable, password is via Set Password).
      // ★ M11 fix (audit): validate email format before submit. The <input type="email">
      //   only validates on native form submit — our modal uses onclick, so the
      //   browser's built-in validation never fires. An admin could submit "john@@@example".
      // ★ Phase 10 (2026-09-26): tightened email regex — added {2,} on the TLD
      //   so single-char TLDs (a@b.c) are rejected. The server's
      //   filter_var(FILTER_VALIDATE_EMAIL) accepts single-char TLDs (RFC 5321
      //   allows them), but they're virtually always typos in practice. Now
      //   rejects "a@b.c" client-side; the server still has the final say.
      if (payload.email && !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(payload.email)) {
        errorBox.textContent = 'Please enter a valid email address.';
        submitBtn.disabled = false;
        submitBtn.textContent = 'Save Changes';
        return;
      }
      promise = store.updateAdmin(admin.id, {
        email: payload.email,
        role: payload.role
      });
    } else {
      // Create — needs username + password.
      if (!payload.username || payload.username.length < 3) {
        errorBox.textContent = 'Username must be at least 3 characters.';
        submitBtn.disabled = false;
        submitBtn.textContent = 'Create Admin';
        return;
      }
      if (!payload.password || payload.password.length < 8) {
        errorBox.textContent = 'Password must be at least 8 characters.';
        submitBtn.disabled = false;
        submitBtn.textContent = 'Create Admin';
        return;
      }
      promise = store.createAdmin(payload);
    }

    promise.then(function (data) {
      closeAdminModal();
      flashStatus(isEdit
        ? 'Admin "' + (data.admin.username || admin.username) + '" updated.'
        : 'Admin "' + data.admin.username + '" created with role "' + data.admin.role + '".');
      loadAndRenderAdmins();
    }).catch(function (err) {
      errorBox.textContent = err.message || 'Save failed.';
      submitBtn.disabled = false;
      submitBtn.textContent = isEdit ? 'Save Changes' : 'Create Admin';
    });

    function closeAdminModal() {
      var b = document.getElementById('admin-modal-backdrop');
      if (b) b.remove();
    }
  }

  /* ---- Set Password modal ------------------------------------------------ */
  function handleOpenPasswordResetModal(admin) {
    var existing = document.getElementById('admin-password-modal-backdrop');
    if (existing) existing.remove();

    var passwordInput = el('input', {
      type: 'password',
      id: 'admin-new-password-input',
      placeholder: 'new password (8+ chars)',
      style: { width: '100%', padding: '8px' }
    });
    var confirmInput = el('input', {
      type: 'password',
      id: 'admin-new-password-confirm',
      placeholder: 'confirm new password',
      style: { width: '100%', padding: '8px' }
    });
    var errorBox = el('div', {
      id: 'admin-password-modal-error',
      class: 'muted',
      style: { color: '#dc2626', fontSize: '14px', minHeight: '18px' }
    }, '');
    var submitBtn = el('button', {
      class: 'btn-md',
      style: { background: '#2D8B4E', color: '#fff', border: 'none' }
    }, [el('i', { class: 'fas fa-key', style: { marginRight: '6px' } }), 'Set Password']);

    var backdrop = el('div', {
      id: 'admin-password-modal-backdrop',
      class: 'modal-backdrop',
      style: { display: 'flex' }
    }, [
      el('div', { class: 'modal', style: { maxWidth: '420px' } }, [
        el('div', { class: 'modal-header' }, [
          el('h3', {}, 'Set Password for ' + admin.username),
          el('button', {
            class: 'modal-close',
            onclick: function () { closePasswordModal(); }
          }, '×')
        ]),
        el('div', { class: 'modal-body' }, [
          el('p', { class: 'muted' }, 'The admin will need to use this new password on their next sign-in. Any existing sessions of theirs will be invalidated immediately (SEC-13).'),
          el('div', { class: 'form-group', style: { marginTop: '12px' } }, [
            el('label', { class: 'muted' }, 'New password'),
            passwordInput
          ]),
          el('div', { class: 'form-group', style: { marginTop: '8px' } }, [
            el('label', { class: 'muted' }, 'Confirm new password'),
            confirmInput
          ]),
          errorBox
        ]),
        el('div', { class: 'modal-footer', style: { marginTop: '16px', display: 'flex', gap: '8px', justifyContent: 'flex-end' } }, [
          el('button', {
            class: 'btn-md outline',
            onclick: function () { closePasswordModal(); }
          }, 'Cancel'),
          submitBtn
        ])
      ])
    ]);
    document.body.appendChild(backdrop);

    submitBtn.onclick = function () {
      var pw = passwordInput.value;
      var cf = confirmInput.value;
      if (!pw || pw.length < 8) {
        errorBox.textContent = 'Password must be at least 8 characters.';
        return;
      }
      if (pw !== cf) {
        errorBox.textContent = 'Passwords do not match.';
        return;
      }
      errorBox.textContent = '';
      submitBtn.disabled = true;
      submitBtn.textContent = 'Processing...';
      store.setAdminPassword(admin.id, pw).then(function () {
        closePasswordModal();
        flashStatus('Password set for "' + admin.username + '". Their existing sessions were invalidated.');
      }).catch(function (err) {
        errorBox.textContent = err.message || 'Failed to set password.';
        submitBtn.disabled = false;
        submitBtn.textContent = 'Set Password';
      });
    };

    function closePasswordModal() {
      var b = document.getElementById('admin-password-modal-backdrop');
      if (b) b.remove();
    }
    backdrop.addEventListener('click', function (e) {
      if (e.target === backdrop) closePasswordModal();
    });
  }

  /* ---- Delete admin handler ---------------------------------------------- */
  function handleAdminDelete(admin) {
    if (!admin || !admin.id) return;
    if (!confirm('Delete admin account "' + admin.username + '"?\n\n' +
        'They will immediately lose access. Refunds they initiated will be ' +
        'deleted too (the refund audit trail survives on Paystack side).')) return;
    store.deleteAdmin(admin.id).then(function () {
      flashStatus('Admin "' + admin.username + '" deleted.');
      loadAndRenderAdmins();
    }).catch(function (err) {
      flashStatus(err.message || 'Delete failed.');
    });
  }

  /* ==========================================================================
   * ★ Phase 8 Batch 3 (Task 60, 2026-09-23): Currencies tab — multi-currency.
   *
   * Visible only to super_admin. The dashboard's Currencies tab manages the
   * currencies table — list, add, edit, delete currencies + their exchange
   * rates. The storefront's currency switcher (added in storefront.js) reads
   * the active currencies via the public GET endpoint.
   *
   * UI:
   *   - List of currencies (code, name, symbol, exchange_rate, paystack_supported,
   *     active, is_base). Each row has Edit + Delete buttons.
   *   - "Add currency" button at the top.
   *   - Edit modal: change name, symbol, exchange_rate, paystack_supported,
   *     active. Code is immutable. is_base cannot be changed via the API.
   *   - The base currency (is_base=1, typically GHS) has its Delete button
   *     disabled + a "Base" badge — the server refuses to delete it anyway.
   *   - The base currency's exchange_rate is forced to 1.0 (it's the
   *     reference); the input is disabled when editing the base.
   * ======================================================================= */

  function renderCurrenciesPanel() {
    return el('div', { class: 'panel' }, [
      el('h3', { class: 'panel-title' }, [
        el('i', { class: 'fas fa-coins', style: { marginRight: '8px' } }),
        'Currencies'
      ]),
      el('p', { class: 'muted' }, 'Manage display + charging currencies. Exchange rates are 1 GHS = N units of the target currency. Paystack can charge in NGN, GHS, KES, ZAR, USD.'),
      el('div', { class: 'form-actions', style: { marginTop: '12px', marginBottom: '12px' } }, [
        el('button', {
          class: 'btn-md',
          id: 'currencies-add-btn',
          onclick: function () { handleOpenCurrencyModal(null); }
        }, [el('i', { class: 'fas fa-plus', style: { marginRight: '6px' } }), 'Add currency'])
      ]),
      el('div', { id: 'currencies-container', class: 'items-list' }, [
        el('p', { class: 'muted' }, 'Loading...')
      ])
    ]);
  }

  function bindCurrenciesPanel() {
    loadAndRenderCurrencies();
  }

  function loadAndRenderCurrencies() {
    var container = document.getElementById('currencies-container');
    if (!container) return;
    store.getAllCurrencies().then(function (data) {
      renderCurrenciesList(container, data.currencies || []);
    }).catch(function (err) {
      clear(container);
      container.appendChild(el('p', { class: 'muted', style: { color: '#dc2626' } },
        'Failed to load currencies: ' + (err.message || 'unknown error')));
    });
  }

  function renderCurrenciesList(container, currencies) {
    clear(container);
    if (!currencies.length) {
      container.appendChild(el('p', { class: 'muted' }, 'No currencies configured. Click "Add currency" to create one.'));
      return;
    }
    currencies.forEach(function (c) {
      var isBase = !!c.is_base;
      var badges = [];
      if (isBase) {
        badges.push(el('span', { class: 'role-badge', style: { background: '#FFAA00', color: '#000', padding: '2px 6px', borderRadius: '4px', fontSize: '11px' } }, 'Base'));
      }
      if (c.paystack_supported) {
        badges.push(el('span', { class: 'role-badge', style: { background: '#2D8B4E', color: '#fff', padding: '2px 6px', borderRadius: '4px', fontSize: '11px' } }, 'Paystack'));
      }
      if (!c.active) {
        badges.push(el('span', { class: 'role-badge', style: { background: '#6b7280', color: '#fff', padding: '2px 6px', borderRadius: '4px', fontSize: '11px' } }, 'Inactive'));
      }
      container.appendChild(el('div', { class: 'item-card', style: { display: 'flex', alignItems: 'center', gap: '12px', padding: '12px', borderBottom: '1px solid #e5e7eb' } }, [
        el('div', { style: { flex: '1' } }, [
          el('div', { style: { display: 'flex', alignItems: 'center', gap: '8px' } }, [
            el('strong', {}, c.code + ' (' + c.symbol + ')'),
            c.name
          ].concat(badges)),
          el('div', { class: 'muted', style: { fontSize: '13px', marginTop: '4px' } }, [
            '1 GHS = ' + c.exchange_rate + ' ' + c.code,
            isBase ? ' · (base currency — rate is always 1.0)' : ''
          ])
        ]),
        el('div', { style: { display: 'flex', gap: '6px' } }, [
          el('button', {
            class: 'btn-sm outline',
            onclick: function () { handleOpenCurrencyModal(c); }
          }, [el('i', { class: 'fas fa-pen', style: { marginRight: '4px' } }), 'Edit']),
          isBase ? el('button', {
            class: 'btn-sm outline',
            disabled: true,
            style: { opacity: '0.5', cursor: 'not-allowed', borderColor: '#dc2626', color: '#dc2626' },
            title: 'The base currency cannot be deleted.'
          }, [el('i', { class: 'fas fa-trash-can', style: { marginRight: '4px' } }), 'Delete'])
          : el('button', {
            class: 'btn-sm outline',
            style: { borderColor: '#dc2626', color: '#dc2626' },
            onclick: function () { handleCurrencyDelete(c); }
          }, [el('i', { class: 'fas fa-trash-can', style: { marginRight: '4px' } }), 'Delete'])
        ])
      ]));
    });
  }

  /* ---- Add/Edit currency modal ------------------------------------------ */
  function handleOpenCurrencyModal(currency) {
    var existing = document.getElementById('currency-modal-backdrop');
    if (existing) existing.remove();

    var isEdit = !!currency;
    var isBase = isEdit && currency.is_base;
    var codeInput = el('input', {
      type: 'text',
      id: 'currency-code-input',
      value: isEdit ? (currency.code || '') : '',
      placeholder: '3-letter ISO code (e.g. USD, NGN, KES)',
      maxlength: '3',
      style: { width: '100%', padding: '8px', textTransform: 'uppercase' },
      disabled: isEdit  // code is immutable on edit (it's the unique key)
    });
    var nameInput = el('input', {
      type: 'text',
      id: 'currency-name-input',
      value: isEdit ? (currency.name || '') : '',
      placeholder: 'e.g. US Dollar',
      maxlength: '50',
      style: { width: '100%', padding: '8px' }
    });
    var symbolInput = el('input', {
      type: 'text',
      id: 'currency-symbol-input',
      value: isEdit ? (currency.symbol || '') : '',
      placeholder: 'e.g. $, ₵, ₦, KSh',
      maxlength: '10',
      style: { width: '100%', padding: '8px' }
    });
    var rateInput = el('input', {
      type: 'number',
      id: 'currency-rate-input',
      value: isEdit ? (currency.exchange_rate || 1) : '',
      placeholder: '1 GHS = N units of this currency',
      step: '0.000001',
      min: '0.000001',
      style: { width: '100%', padding: '8px' },
      disabled: isBase  // base currency rate is always 1.0
    });
    if (isBase) rateInput.value = '1.000000';
    var paystackCheckbox = el('input', {
      type: 'checkbox',
      id: 'currency-paystack-checkbox',
      checked: isEdit ? !!currency.paystack_supported : false
    });
    var activeCheckbox = el('input', {
      type: 'checkbox',
      id: 'currency-active-checkbox',
      checked: isEdit ? !!currency.active : true,
      disabled: isBase  // base currency cannot be deactivated
    });
    var errorBox = el('div', {
      id: 'currency-modal-error',
      class: 'muted',
      style: { color: '#dc2626', fontSize: '14px', minHeight: '18px' }
    }, '');
    var submitBtn = el('button', {
      class: 'btn-md',
      id: 'currency-modal-submit',
      style: { background: '#2D8B4E', color: '#fff', border: 'none' }
    }, [el('i', { class: 'fas fa-check', style: { marginRight: '6px' } }), isEdit ? 'Save Changes' : 'Create Currency']);

    var backdrop = el('div', {
      id: 'currency-modal-backdrop',
      class: 'modal-backdrop',
      style: { display: 'flex' }
    }, [
      el('div', { class: 'modal', style: { maxWidth: '480px' } }, [
        el('div', { class: 'modal-header' }, [
          el('h3', {}, isEdit ? 'Edit Currency' : 'Add Currency'),
          el('button', {
            class: 'modal-close',
            onclick: function () { closeCurrencyModal(); }
          }, '×')
        ]),
        el('div', { class: 'modal-body' }, [
          el('div', { class: 'form-group' }, [
            el('label', { class: 'muted' }, 'Code (ISO 4217)'),
            codeInput,
            isEdit ? el('p', { class: 'muted', style: { fontSize: '12px', marginTop: '4px' } }, 'Code cannot be changed after creation.') : null
          ]),
          el('div', { class: 'form-group', style: { marginTop: '8px' } }, [
            el('label', { class: 'muted' }, 'Name'),
            nameInput
          ]),
          el('div', { class: 'form-group', style: { marginTop: '8px' } }, [
            el('label', { class: 'muted' }, 'Symbol'),
            symbolInput
          ]),
          el('div', { class: 'form-group', style: { marginTop: '8px' } }, [
            el('label', { class: 'muted' }, 'Exchange rate (1 GHS = ?)'),
            rateInput,
            isBase ? el('p', { class: 'muted', style: { fontSize: '12px', marginTop: '4px' } }, 'Base currency rate is always 1.0.') : null
          ]),
          el('div', { class: 'form-group', style: { marginTop: '8px' } }, [
            el('label', {}, [paystackCheckbox, ' Paystack-supported (can charge in this currency)']),
            el('p', { class: 'muted', style: { fontSize: '12px', marginTop: '4px' } }, 'Paystack supports: NGN, GHS, KES, ZAR, USD.')
          ]),
          el('div', { class: 'form-group', style: { marginTop: '8px' } }, [
            el('label', {}, [activeCheckbox, ' Active (shown in storefront switcher)']),
            isBase ? el('p', { class: 'muted', style: { fontSize: '12px', marginTop: '4px' } }, 'Base currency is always active.') : null
          ]),
          errorBox
        ]),
        el('div', { class: 'modal-footer', style: { marginTop: '16px', display: 'flex', gap: '8px', justifyContent: 'flex-end' } }, [
          el('button', {
            class: 'btn-md outline',
            onclick: function () { closeCurrencyModal(); }
          }, 'Cancel'),
          submitBtn
        ])
      ])
    ]);
    document.body.appendChild(backdrop);

    submitBtn.onclick = function () {
      var payload = {
        code: codeInput.value.trim().toUpperCase(),
        name: nameInput.value.trim(),
        symbol: symbolInput.value.trim(),
        exchange_rate: parseFloat(rateInput.value),
        paystack_supported: paystackCheckbox.checked,
        active: activeCheckbox.checked
      };
      handleCurrencySubmit(isEdit, currency, payload, errorBox, submitBtn);
    };

    function closeCurrencyModal() {
      var b = document.getElementById('currency-modal-backdrop');
      if (b) b.remove();
    }
    backdrop.addEventListener('click', function (e) {
      if (e.target === backdrop) closeCurrencyModal();
    });
  }

  function handleCurrencySubmit(isEdit, currency, payload, errorBox, submitBtn) {
    errorBox.textContent = '';
    submitBtn.disabled = true;
    submitBtn.textContent = 'Processing...';

    // Client-side validation (the server also validates — defense in depth).
    if (!isEdit) {
      if (!payload.code || !/^[A-Z]{3}$/.test(payload.code)) {
        errorBox.textContent = 'Code must be exactly 3 uppercase letters.';
        submitBtn.disabled = false;
        submitBtn.textContent = 'Create Currency';
        return;
      }
    }
    // ★ Phase 10 (2026-09-26): was `if (!payload.name || payload.name.length > 50)`
    //   — a whitespace-only name like "   " passed (truthy + length <= 50).
    //   The server-side currency.php's body_str() trims, so the request
    //   would land as an empty name + 422. Now we trim + reject empty.
    var trimmedName = (payload.name || '').trim();
    if (!trimmedName || trimmedName.length > 50) {
      errorBox.textContent = 'Name is required (1-50 characters).';
      submitBtn.disabled = false;
      submitBtn.textContent = isEdit ? 'Save Changes' : 'Create Currency';
      return;
    }
    payload.name = trimmedName;  // pass the trimmed version to the server
    if (!payload.symbol || payload.symbol.length > 10) {
      errorBox.textContent = 'Symbol is required (1-10 characters).';
      submitBtn.disabled = false;
      submitBtn.textContent = isEdit ? 'Save Changes' : 'Create Currency';
      return;
    }
    if (!isEdit || !currency.is_base) {
      if (!payload.exchange_rate || payload.exchange_rate <= 0) {
        errorBox.textContent = 'Exchange rate must be a positive number.';
        submitBtn.disabled = false;
        submitBtn.textContent = isEdit ? 'Save Changes' : 'Create Currency';
        return;
      }
    }

    var promise;
    if (isEdit) {
      promise = store.updateCurrency(currency.code, payload);
    } else {
      promise = store.createCurrency(payload);
    }

    promise.then(function (data) {
      closeCurrencyModal();
      flashStatus(isEdit
        ? 'Currency "' + data.currency.code + '" updated.'
        : 'Currency "' + data.currency.code + '" created.');
      // Re-hydrate the public currencies map so the storefront's switcher
      // picks up the change without a page reload. The dashboard's list is
      // also re-rendered below.
      store.hydrateCurrencies().then(loadAndRenderCurrencies);
    }).catch(function (err) {
      errorBox.textContent = err.message || 'Save failed.';
      submitBtn.disabled = false;
      submitBtn.textContent = isEdit ? 'Save Changes' : 'Create Currency';
    });

    function closeCurrencyModal() {
      var b = document.getElementById('currency-modal-backdrop');
      if (b) b.remove();
    }
  }

  /* ---- Delete currency handler ------------------------------------------- */
  function handleCurrencyDelete(currency) {
    if (!currency || !currency.id) return;
    if (!confirm('Delete currency "' + currency.code + '"?\n\n' +
        'It will be removed from the storefront switcher. Historical orders ' +
        'that used this currency will retain the code in their records.')) return;
    store.deleteCurrency(currency.id).then(function (data) {
      var msg = 'Currency "' + currency.code + '" deleted.';
      if (data && data.orders_using && data.orders_using > 0) {
        msg += ' ' + data.orders_using + ' historical order(s) retain the "' + currency.code + '" currency code.';
      }
      flashStatus(msg);
      store.hydrateCurrencies().then(loadAndRenderCurrencies);
    }).catch(function (err) {
      flashStatus(err.message || 'Delete failed.');
    });
  }

  // Format a SQL TIMESTAMP string ("2026-09-04 12:34:56") or ISO 8601 into
  // a readable "Sep 4, 2026, 12:34 PM" form. Returns '—' on falsy input.
  // Uses the browser's locale fortoLocaleString — the dashboard is admin-only
  // so locale formatting is fine (the public site uses the original formatPrice).
  function formatOrderDate(s) {
    if (!s) return '—';
    // ★ RT-06 fix: was `new Date(String(s).replace(' ', 'T') + 'Z')` —
    //   appending 'Z' tells the JS Date constructor to interpret the string
    //   as UTC. But MySQL TIMESTAMP columns return the value in the
    //   connection's session timezone (default: the server's system TZ).
    //   So an order placed at "2026-09-04 14:00:00" server-local was parsed
    //   as 14:00 UTC, then toLocaleString() shifted it by the browser's TZ
    //   offset — showing the wrong time on every order.
    //   Fix: remove the 'Z' suffix. `new Date('2026-09-04T14:00:00')`
    //   (without 'Z') interprets the string as the browser's local time.
    //   Since the MySQL value is server-local, and the admin's browser is
    //   typically in the same TZ as the server (Ghana → UTC+0), the
    //   displayed time matches the server's local time. Even if the admin
    //   is in a different TZ, the displayed time is the SERVER's local
    //   time (not shifted by the browser's TZ offset) — which is what the
    //   admin wants when reconciling with Paystack's dashboard.
    var d = new Date(String(s).replace(' ', 'T'));
    if (isNaN(d.getTime())) return String(s);
    // Convert to local time + format
    return d.toLocaleString(undefined, {
      year: 'numeric', month: 'short', day: 'numeric',
      hour: '2-digit', minute: '2-digit'
    });
  }

  /* ====================================================================
     ANALYTICS TAB (Phase 5 Batch 4) — sales analytics dashboard
     Revenue stats, top products, 30-day trend, customer insights,
     discount usage. Pure CSS/SVG charts — no external chart library.
     ==================================================================== */

  function renderAnalyticsPanel() {
    return el('section', { class: 'panel' }, [
      el('h3', { class: 'panel-title' }, 'Sales Analytics'),
      el('div', { class: 'panel-body' }, [
        // ★ UX-06 fix: refresh control + "last refreshed" timestamp.
        //   Previously the analytics data was fetched exactly once when the
        //   tab opened, with no way to re-fetch short of switching tabs and
        //   back (a full doRender + re-fetch anyway) — and no indication of
        //   how stale the numbers were. Same toolbar pattern as Orders.
        el('div', { class: 'orders-toolbar', style: { justifyContent: 'space-between', alignItems: 'center' } }, [
          el('span', { class: 'muted', id: 'analytics-refreshed', style: { fontSize: '12px' } }, ''),
          el('button', {
            id: 'analytics-refresh',
            class: 'btn-md outline',
            onclick: function () {
              cacheClear('analytics');  // ★ PERF-14: bypass the cache — admin asked for fresh numbers
              loadAnalytics();
            }
          }, [el('i', { class: 'fas fa-rotate-right', style: { marginRight: '6px' } }), 'Refresh'])
        ]),
        el('div', { id: 'analytics-container' }, [
          el('p', { class: 'muted' }, 'Loading analytics…')
        ])
      ])
    ]);
  }

  function bindAnalyticsPanel() {
    loadAnalytics();
  }

  // ★ Phase 10 (2026-09-26): added request-id tracking so rapid Refresh
  //   clicks (or rapid tab switches that re-trigger loadAnalytics) don't
  //   let stale responses render over newer ones. The fetch's .then() bails
  //   if its captured id is no longer current.
  var _analyticsReqId = 0;
  function loadAnalytics() {
    var container = document.getElementById('analytics-container');
    if (!container) return;
    var refreshBtn = document.getElementById('analytics-refresh');
    var myReqId = ++_analyticsReqId;

    // ★ PERF-14: serve the 60 s cached result on tab re-entry (the stamp
    //   shows the ORIGINAL fetch time so staleness is honest + visible).
    //   The Refresh button and every mutating path clear the entry first.
    var cached = cacheGet('analytics');
    if (cached) {
      renderAnalyticsInto(container, cached.data, new Date(cached.at).toLocaleTimeString() + ' (cached)', refreshBtn);
      return;
    }

    if (refreshBtn) refreshBtn.disabled = true;
    clear(container);
    container.appendChild(el('p', { class: 'muted' }, 'Loading analytics…'));

    store.getAnalytics().then(function (data) {
      // Stale-response guard: a newer loadAnalytics() call superseded this one.
      if (myReqId !== _analyticsReqId) return;
      cacheSet('analytics', data);  // ★ PERF-14
      renderAnalyticsInto(container, data, new Date().toLocaleTimeString(), refreshBtn);
    }).catch(function (err) {
      // Stale-response guard: don't render the error if a newer call won.
      if (myReqId !== _analyticsReqId) return;
      clear(container);
      if (refreshBtn) refreshBtn.disabled = false;
      container.appendChild(el('p', { class: 'muted', style: { color: '#dc2626' } },
        err.message || 'Failed to load analytics.'));
    });
  }

  // PERF-14 helper: shared render path for fresh + cached analytics results
  // (same DOM either way — the only difference is the "Last refreshed" stamp).
  function renderAnalyticsInto(container, data, stampText, refreshBtn) {
    clear(container);
    if (refreshBtn) refreshBtn.disabled = false;
    // ★ UX-06 fix: stamp the fetch time so the admin can tell fresh
    //   numbers from stale ones at a glance.
    var stamp = document.getElementById('analytics-refreshed');
    if (stamp) {
      stamp.textContent = 'Last refreshed: ' + stampText;
    }
    if (!data) {
      container.appendChild(el('p', { class: 'muted' }, 'No analytics data available.'));
      return;
    }
    renderAnalyticsContent(container, data);
  }

  function renderAnalyticsContent(container, data) {
    var r = data.revenue || {};
    var currency = store.getCurrency() || 'GHS';

    // --- Stat cards row ---
    container.appendChild(
      el('div', { class: 'analytics-stats' }, [
        renderStatCard('Total Revenue', formatPrice(r.paidRevenue || 0, currency), 'fas fa-coins', 'var(--accent)'),
        renderStatCard('Total Orders', String(r.totalOrders || 0), 'fas fa-shopping-bag', 'var(--ok)'),
        renderStatCard('Paid Orders', String(r.paidOrders || 0), 'fas fa-check-circle', 'var(--ok)'),
        renderStatCard('Avg Order Value', formatPrice(r.avgOrderValue || 0, currency), 'fas fa-chart-line', 'var(--accent)'),
        renderStatCard('Pending', String(r.pendingOrders || 0), 'fas fa-clock', 'var(--muted)'),
        renderStatCard('Failed', String(r.failedOrders || 0), 'fas fa-times-circle', 'var(--danger)'),
        renderStatCard('Abandoned', String(r.abandonedOrders || 0), 'fas fa-ban', 'var(--muted)'),
        renderStatCard('Discount Given', formatPrice(r.totalDiscountGiven || 0, currency), 'fas fa-tags', 'var(--ok)')
      ])
    );

    // --- 30-day trend chart ---
    container.appendChild(
      el('div', { class: 'analytics-section' }, [
        el('h4', { class: 'analytics-section-title' }, '30-Day Revenue Trend'),
        renderTrendChart(data.trend || [], currency)
      ])
    );

    // --- Top products ---
    container.appendChild(
      el('div', { class: 'analytics-section' }, [
        el('h4', { class: 'analytics-section-title' }, 'Top Products (by quantity sold)'),
        renderTopProducts(data.topProducts || [], currency)
      ])
    );

    // --- Customer insights ---
    container.appendChild(
      el('div', { class: 'analytics-section' }, [
        el('h4', { class: 'analytics-section-title' }, 'Customer Insights'),
        renderCustomerInsights(data.customerInsights || {}, currency)
      ])
    );

    // --- Discount usage ---
    if (data.discountUsage && data.discountUsage.length > 0) {
      container.appendChild(
        el('div', { class: 'analytics-section' }, [
          el('h4', { class: 'analytics-section-title' }, 'Discount Code Usage'),
          renderDiscountUsage(data.discountUsage || [], currency)
        ])
      );
    }
  }

  function renderStatCard(label, value, icon, color) {
    return el('div', { class: 'stat-card' }, [
      el('div', { class: 'stat-card-icon', style: { color: color || 'var(--accent)' } }, [el('i', { class: icon })]),
      el('div', { class: 'stat-card-body' }, [
        el('div', { class: 'stat-card-value' }, value),
        el('div', { class: 'stat-card-label' }, label)
      ])
    ]);
  }

  function renderTrendChart(trend, currency) {
    if (!trend || trend.length === 0) {
      return el('p', { class: 'muted' }, 'No trend data yet.');
    }
    var maxRevenue = 0;
    var maxOrders = 0;
    trend.forEach(function (d) {
      if (d.revenue > maxRevenue) maxRevenue = d.revenue;
      if (d.orders > maxOrders) maxOrders = d.orders;
    });
    if (maxRevenue === 0) maxRevenue = 1;
    if (maxOrders === 0) maxOrders = 1;

    var bars = trend.map(function (d) {
      var revenuePct = (d.revenue / maxRevenue) * 100;
      var ordersPct = (d.orders / maxOrders) * 100;
      var dateLabel = d.date.substring(5); // MM-DD
      return el('div', { class: 'trend-bar-group', title: d.date + ' · ' + d.orders + ' orders · ' + formatPrice(d.revenue, currency) }, [
        el('div', { class: 'trend-bar-revenue', style: { height: Math.max(revenuePct, 2) + '%' } }),
        el('div', { class: 'trend-bar-orders', style: { height: Math.max(ordersPct, 2) + '%' } }),
        el('div', { class: 'trend-bar-label' }, dateLabel)
      ]);
    });

    return el('div', { class: 'trend-chart' }, [
      el('div', { class: 'trend-chart-legend' }, [
        el('span', {}, [el('span', { class: 'trend-dot trend-dot-revenue' }), ' Revenue']),
        el('span', { style: { marginLeft: '16px' } }, [el('span', { class: 'trend-dot trend-dot-orders' }), ' Orders'])
      ]),
      el('div', { class: 'trend-chart-bars' }, bars)
    ]);
  }

  function renderTopProducts(products, currency) {
    if (!products || products.length === 0) {
      return el('p', { class: 'muted' }, 'No product sales data yet. Data appears after the first paid order.');
    }
    var maxQty = products[0].totalQty || 1;
    var rows = products.map(function (p, i) {
      var pct = (p.totalQty / maxQty) * 100;
      return el('div', { class: 'analytics-row' }, [
        el('span', { class: 'analytics-rank' }, '#' + (i + 1)),
        el('div', { class: 'analytics-row-main' }, [
          el('div', { class: 'analytics-row-name' }, [
            // ★ WF-06 fix: order_items rows whose product was deleted
            //   collapse into one aggregated row with productId = null (FK
            //   ON DELETE SET NULL). The server now flags it (deleted:
            //   true) — render a visible "(deleted product)" badge instead
            //   of showing the snapshot name as if it were a live product
            //   the admin could look up in the Products tab.
            p.name + (p.scent ? ' · ' + p.scent : ''),
            p.deleted || p.productId === null
              ? el('span', { style: { color: 'var(--muted)', fontSize: '11px', marginLeft: '6px', border: '1px solid var(--border)', borderRadius: '4px', padding: '1px 6px' } }, 'deleted product')
              : null
          ]),
          el('div', { class: 'analytics-bar-container' }, [
            el('div', { class: 'analytics-bar', style: { width: pct + '%' } })
          ]),
          el('div', { class: 'analytics-row-stats' },
            p.totalQty + ' sold · ' + formatPrice(p.totalRevenue, currency) + ' · ' + p.orderCount + ' orders')
        ])
      ]);
    });
    return el('div', { class: 'analytics-list' }, rows);
  }

  function renderCustomerInsights(insights, currency) {
    var ci = insights || {};
    var total = ci.totalCustomers || 0;
    var returning = ci.returningCustomers || 0;
    var newCust = total - returning;
    var repeatRate = total > 0 ? Math.round((returning / total) * 100) : 0;

    var cards = el('div', { class: 'analytics-stats' }, [
      renderStatCard('Total Customers', String(total), 'fas fa-users', 'var(--accent)'),
      renderStatCard('Returning', String(returning), 'fas fa-redo', 'var(--ok)'),
      renderStatCard('New', String(newCust), 'fas fa-user-plus', 'var(--accent)'),
      renderStatCard('Repeat Rate', repeatRate + '%', 'fas fa-percentage', 'var(--ok)')
    ]);

    var topList = el('div', { style: { marginTop: '16px' } }, [
      el('p', { class: 'muted', style: { marginBottom: '8px' } }, 'Top customers by total spent:')
    ]);

    if (ci.topCustomers && ci.topCustomers.length > 0) {
      ci.topCustomers.forEach(function (c, i) {
        topList.appendChild(
          el('div', { class: 'analytics-row' }, [
            el('span', { class: 'analytics-rank' }, '#' + (i + 1)),
            el('div', { class: 'analytics-row-main' }, [
              el('div', { class: 'analytics-row-name' }, (c.name || '—') + ' · ' + c.phone),
              el('div', { class: 'analytics-row-stats' },
                c.orderCount + ' orders · ' + formatPrice(c.totalSpent, currency) + ' · last: ' + (c.lastOrder || '—'))
            ])
          ])
        );
      });
    } else {
      topList.appendChild(el('p', { class: 'muted' }, 'No customer data yet.'));
    }

    return el('div', {}, [cards, topList]);
  }

  function renderDiscountUsage(usage, currency) {
    var rows = usage.map(function (d) {
      // ★ WF-07 fix: hard-deleted codes now re-enter this report (server
      //   merges an orphaned-usage query) flagged with deleted: true and
      //   UNKNOWN type/value (the discount_codes row is gone — there is
      //   nothing to read the discount definition from). Render the
      //   "deleted code" badge instead of the old type/value line, which
      //   would have shown a bogus "GHS 0.00 off" for the null value.
      var headline = (d.deleted || d.type === null)
        ? [
            d.value !== null && d.type === 'percentage' ? d.value + '% off' : null,
            d.value !== null && d.type === 'flat' ? formatPrice(d.value, currency) + ' off' : null,
            el('span', { style: { color: 'var(--muted)', fontSize: '11px', marginLeft: '6px', border: '1px solid var(--border)', borderRadius: '4px', padding: '1px 6px' } }, 'deleted code')
          ]
        : (d.type === 'percentage' ? d.value + '% off' : formatPrice(d.value, currency) + ' off');
      return el('div', { class: 'analytics-row' }, [
        el('span', { class: 'analytics-rank' }, d.code),
        el('div', { class: 'analytics-row-main' }, [
          el('div', { class: 'analytics-row-name' }, headline),
          el('div', { class: 'analytics-row-stats' },
            d.usedCount + ' uses · ' + formatPrice(d.totalDiscountGiven, currency) + ' given · ' + d.orderCount + ' orders')
        ])
      ]);
    });
    return el('div', { class: 'analytics-list' }, rows);
  }

  /* ====================================================================
     DISCOUNTS TAB (Phase 5 Batch 2) — create/manage discount codes
     Morbi creates promo codes (e.g. WELCOME10 for 10% off). Customers
     apply them at checkout. The server validates + applies the discount.
     ==================================================================== */

  var discountCodesCache = [];

  function renderDiscountsPanel() {
    return el('section', { class: 'panel' }, [
      el('h3', { class: 'panel-title' }, 'Discount Codes'),
      el('div', { class: 'panel-body' }, [
        renderDiscountEditor(),
        el('div', { id: 'discounts-list', class: 'items-list' }, [
          el('p', { class: 'muted' }, 'Loading discount codes…')
        ])
      ])
    ]);
  }

  function renderDiscountEditor() {
    return el('form', { id: 'discount-form', class: 'item-editor', onsubmit: function (e) { e.preventDefault(); } }, [
      el('input', { type: 'hidden', id: 'd-id' }),
      el('div', { class: 'editor-grid' }, [
        el('div', { class: 'form-row' }, [
          el('label', { for: 'd-code' }, 'Code * (3-50 chars, A-Z 0-9 - _)'),
          el('input', { id: 'd-code', type: 'text', placeholder: 'WELCOME10', style: { textTransform: 'uppercase' } }),
          el('p', { class: 'form-error', id: 'd-code-error' }, 'Code is required (3-50 chars, letters/numbers/hyphens)')
        ]),
        el('div', { class: 'form-row' }, [
          el('label', { for: 'd-type' }, 'Type *'),
          el('select', { id: 'd-type' }, [
            el('option', { value: 'percentage' }, 'Percentage (%)'),
            el('option', { value: 'flat' }, 'Flat Amount (GHS)')
          ])
        ]),
        el('div', { class: 'form-row' }, [
          el('label', { for: 'd-value' }, 'Value * (e.g. 10 for 10% or GHS 10)'),
          el('input', { id: 'd-value', type: 'number', step: '0.01', min: '0.01', placeholder: '10' }),
          el('p', { class: 'form-error', id: 'd-value-error' }, 'Value must be greater than 0')
        ]),
        el('div', { class: 'form-row' }, [
          el('label', { for: 'd-max-uses' }, 'Max Uses (empty = unlimited)'),
          el('input', { id: 'd-max-uses', type: 'number', min: '1', placeholder: 'Unlimited' }),
          el('p', { class: 'form-error', id: 'd-max-uses-error' }, 'Must be a positive integer')
        ])
      ]),
      el('div', { class: 'form-row' }, [
        el('label', { for: 'd-desc' }, 'Description (internal note)'),
        el('input', { id: 'd-desc', type: 'text', placeholder: '10% off welcome discount' }),
        el('p', { class: 'form-error', id: 'd-desc-error' }, 'Description is too long (max 200 characters)')
      ]),
      el('div', { class: 'form-row' }, [
        el('label', { for: 'd-expires' }, 'Expiry Date (empty = never)'),
        el('input', { id: 'd-expires', type: 'date' })
      ]),
      el('div', { class: 'form-row' }, [
        el('label', { class: 'checkbox-row' }, [
          el('input', { id: 'd-active', type: 'checkbox', checked: true }),
          el('span', {}, 'Active (customers can use this code)')
        ])
      ]),
      el('div', { class: 'form-actions' }, [
        el('button', { id: 'd-save', type: 'button', class: 'btn-md fill' }, 'Save Code'),
        el('button', { id: 'd-clear', type: 'button', class: 'btn-md outline' }, 'Clear')
      ])
    ]);
  }

  function bindDiscountsPanel() {
    var saveBtn = document.getElementById('d-save');
    if (saveBtn) saveBtn.addEventListener('click', handleDiscountSave);
    var clearBtn = document.getElementById('d-clear');
    if (clearBtn) clearBtn.addEventListener('click', clearDiscountEditor);
    loadDiscountCodes();
  }

  function loadDiscountCodes() {
    var container = document.getElementById('discounts-list');
    if (!container) return;

    // ★ PERF-14: 60 s cache on tab re-entry; save/delete clear it first.
    var cached = cacheGet('discounts');
    if (cached) {
      discountCodesCache = cached.data;
      renderDiscountCodesList(container, discountCodesCache);
      return;
    }

    clear(container);
    container.appendChild(el('p', { class: 'muted' }, 'Loading discount codes…'));

    store.getDiscountCodes().then(function (res) {
      discountCodesCache = (res && res.codes) || [];
      cacheSet('discounts', discountCodesCache);  // ★ PERF-14
      renderDiscountCodesList(container, discountCodesCache);
    }).catch(function (err) {
      clear(container);
      container.appendChild(el('p', { class: 'muted', style: { color: '#dc2626' } },
        err.message || 'Failed to load discount codes.'));
    });
  }

  function renderDiscountCodesList(container, codes) {
    clear(container);
    if (!codes || codes.length === 0) {
      container.appendChild(el('p', { class: 'muted' }, 'No discount codes yet. Create one above.'));
      return;
    }
    codes.forEach(function (c) {
      container.appendChild(renderDiscountRow(c));
    });
  }

  function renderDiscountRow(c) {
    // ★ Phase 10 (2026-09-26): was `c.type === 'percentage' ? c.value + '% off' : 'GHS ' + c.value + ' off'`
    //   — hardcoded "GHS" as the currency symbol. If the admin had changed
    //   the base currency (e.g. to USD), this label was wrong. Now reads
    //   the actual base currency code + symbol from store (with a safe
    //   fallback to GHS if store isn't available yet).
    var baseCurrencyCode = (typeof store.getBaseCurrencyCode === 'function')
      ? (store.getBaseCurrencyCode() || 'GHS')
      : 'GHS';
    var currenciesMap = (typeof store.getCurrenciesMap === 'function')
      ? store.getCurrenciesMap()
      : {};
    var baseSymbol = (currenciesMap[baseCurrencyCode] && currenciesMap[baseCurrencyCode].symbol) || baseCurrencyCode;
    var typeLabel = c.type === 'percentage' ? c.value + '% off' : baseSymbol + ' ' + c.value + ' off';
    var statusLabel = c.active ? 'Active' : 'Inactive';
    var statusColor = c.active ? '#2D8B4E' : '#a0a0a0';
    var usesLabel = c.maxUses !== null
      ? c.usedCount + ' / ' + c.maxUses + ' used'
      : c.usedCount + ' used';
    var expiryLabel = c.expiresAt
      // ★ RT-06 blind-spot fix: same TZ bug as formatOrderDate — was
      //   `+ 'Z'` which treated the MySQL TIMESTAMP as UTC. Removed 'Z'
      //   so the date is interpreted as server-local (matching the
      //   MySQL session TZ that returned the value).
      ? 'Expires: ' + new Date(String(c.expiresAt).replace(' ', 'T')).toLocaleDateString()
      : 'Never expires';
    return el('div', { class: 'discount-row', dataset: { id: c.id } }, [
      el('div', {}, [
        el('h4', { style: { color: c.active ? '#D4AF37' : '#a0a0a0' } }, c.code),
        el('p', { class: 'muted' }, (c.description || 'No description') + ' · ' + typeLabel + ' · ' + usesLabel + ' · ' + expiryLabel),
        el('span', { class: 'order-status', style: { color: statusColor, borderColor: statusColor, fontSize: '10px' } }, statusLabel)
      ]),
      el('div', { class: 'item-actions' }, [
        el('button', { class: 'btn-sm outline', onclick: function () { fillDiscountEditor(c.id); } }, 'Edit'),
        el('button', {
          class: 'btn-sm outline', style: { borderColor: '#dc2626', color: '#dc2626' },
          onclick: function () { deleteDiscountCode(c.id); }
        }, 'Del')
      ])
    ]);
  }

  function handleDiscountSave() {
    var id = document.getElementById('d-id').value;
    var code = document.getElementById('d-code').value.trim().toUpperCase();
    var type = document.getElementById('d-type').value;
    var valueRaw = document.getElementById('d-value').value;
    var maxUsesRaw = document.getElementById('d-max-uses').value.trim();
    var description = document.getElementById('d-desc').value.trim();
    var expiresRaw = document.getElementById('d-expires').value;
    var active = document.getElementById('d-active').checked;
    var valid = true;

    if (!code || code.length < 3 || code.length > 50 || !/^[A-Z0-9_-]+$/.test(code)) {
      showFormError('d-code', 'd-code-error', 'Code is required (3-50 chars, letters/numbers/hyphens)');
      valid = false;
    } else { hideFormError('d-code', 'd-code-error'); }

    var value = parseFloat(valueRaw);
    if (!valueRaw || isNaN(value) || value <= 0) {
      showFormError('d-value', 'd-value-error', 'Value must be greater than 0');
      valid = false;
    } else if (type === 'percentage' && value > 100) {
      showFormError('d-value', 'd-value-error', 'Percentage cannot exceed 100%');
      valid = false;
    } else { hideFormError('d-value', 'd-value-error'); }

    // ★ UX-07 fix: maxUses was passed straight into the payload with no
    //   client-side validation — "0", "-5", "1.5", "abc" all reached the
    //   server (which then rejects with an opaque top-of-page error), and
    //   the inline d-max-uses-error element never lit up. Mirrors the
    //   server rule in discounts.php (FILTER_VALIDATE_INT, >= 1):
    //   empty = unlimited (null), otherwise a positive integer.
    if (maxUsesRaw === '') {
      hideFormError('d-max-uses', 'd-max-uses-error');
    } else if (!/^\d+$/.test(maxUsesRaw) || parseInt(maxUsesRaw, 10) < 1) {
      showFormError('d-max-uses', 'd-max-uses-error', 'Must be a positive integer');
      valid = false;
    } else {
      hideFormError('d-max-uses', 'd-max-uses-error');
    }

    if (!valid) return;

    var payload = {
      code: code, type: type, value: value, active: active,
      // ★ M14 fix (audit): parseInt maxUses instead of sending as string.
      //   "5" (string) works on PHP's loose == but fails FILTER_VALIDATE_INT
      //   strict checks on some servers.
      description: description, maxUses: maxUsesRaw ? parseInt(maxUsesRaw, 10) : null, expiresAt: expiresRaw || null
    };

    var saveBtn = document.getElementById('d-save');
    if (saveBtn) saveBtn.disabled = true;

    var op = id ? store.updateDiscountCode(id, payload) : store.createDiscountCode(payload);
    op.then(function () {
      clearDiscountEditor();
      // ★ PERF-14: the codes list (and the analytics usage report) just
      //   changed — drop both cache entries so the re-fetch is real.
      cacheClear('discounts');
      cacheClear('analytics');
      loadDiscountCodes();
    }).catch(function (err) {
      if (saveBtn) saveBtn.disabled = false;
      flashStatus(err.message || 'Save failed.');
    });
  }

  function fillDiscountEditor(id) {
    var c = discountCodesCache.find(function (x) { return String(x.id) === String(id); });
    if (!c) return;
    document.getElementById('d-id').value = c.id;
    document.getElementById('d-code').value = c.code;
    document.getElementById('d-type').value = c.type;
    document.getElementById('d-value').value = c.value;
    document.getElementById('d-max-uses').value = c.maxUses !== null ? c.maxUses : '';
    document.getElementById('d-desc').value = c.description || '';
    document.getElementById('d-expires').value = c.expiresAt ? String(c.expiresAt).substring(0, 10) : '';
    document.getElementById('d-active').checked = !!c.active;
    document.getElementById('d-code').scrollIntoView({ behavior: 'smooth', block: 'center' });
  }

  function clearDiscountEditor() {
    ['d-id', 'd-code', 'd-value', 'd-max-uses', 'd-desc', 'd-expires'].forEach(function (idEl) {
      var node = document.getElementById(idEl);
      if (node) node.value = '';
    });
    var cb = document.getElementById('d-active');
    if (cb) cb.checked = true;
    var type = document.getElementById('d-type');
    if (type) type.value = 'percentage';
    hideFormError('d-code', 'd-code-error');
    hideFormError('d-value', 'd-value-error');
    hideFormError('d-max-uses', 'd-max-uses-error');  // ★ UX-07 fix: clear the max-uses error too
    var saveBtn = document.getElementById('d-save');
    if (saveBtn) saveBtn.disabled = false;
  }

  function deleteDiscountCode(id) {
    // ★ WF-07 fix: the old dialog promised "Existing orders that used it
    //   will keep their discount records" — the orders keep their
    //   discount_code STRING, but the delete is a hard DELETE and the
    //   analytics discount-usage report used to start FROM discount_codes,
    //   so the deleted code's entire usage history vanished from the
    //   dashboard (the dialog's promise was false). The analytics now
    //   resurrects orphaned-code usage (flagged "deleted code"), so the
    //   dialog tells the whole truth: what survives, what becomes
    //   unreusable, and what the report will show.
    if (!confirm('Delete this discount code?\n\n'
      + '- The code stops working at checkout immediately (customers who try it get "invalid code").\n'
      + '- Past orders keep their discount amounts and their records.\n'
      + '- The code still appears in Analytics > Discount Code Usage, marked "deleted code", with its historical usage totals.\n\n'
      + 'Delete it? If you only want to stop new redemptions, set the code to Inactive instead.')) return;
    store.deleteDiscountCode(id).then(function () {
      // ★ PERF-14: same invalidation pair as handleDiscountSave.
      cacheClear('discounts');
      cacheClear('analytics');
      loadDiscountCodes();
    }).catch(function (err) {
      flashStatus(err.message || 'Delete failed.');
    });
  }

  /* ====================================================================
     THEME TAB (Phase 1) — design-token editor
     Color picker + hex text input per token. Live preview fires on every
     input event (store.applyTokens(formMap) injects the unsaved values
     into <head> WITHOUT touching state.tokens). Save commits to the
     server; Reset to Defaults POSTs {action:'reset'}.
     ==================================================================== */

  // Catalog (mirrors api/tokens.php TOKEN_CATALOG). Order groups the editor:
  // backgrounds -> accents -> status/utility. Each entry's `label` is the
  // human-readable form shown in the dashboard.
  var THEME_TOKENS = [
    { name: 'bg_deep',       label: 'Background — deep',    group: 'Backgrounds' },
    { name: 'bg_mid',        label: 'Background — mid',     group: 'Backgrounds' },
    { name: 'bg_card',       label: 'Background — card',    group: 'Backgrounds' },
    { name: 'accent',        label: 'Accent — gold',        group: 'Accents' },
    { name: 'accent_strong', label: 'Accent — strong',      group: 'Accents' },
    { name: 'accent_hover',  label: 'Accent — hover',       group: 'Accents' },
    { name: 'danger',        label: 'Danger',               group: 'Status' },
    { name: 'ok',            label: 'OK',                   group: 'Status' },
    { name: 'green',         label: 'Brand green',          group: 'Status' },
    { name: 'muted',         label: 'Muted text',           group: 'Status' },
    { name: 'border',        label: 'Border',               group: 'Status' }
  ];

  // Normalize any hex value to #RRGGBB for the <input type=color> element.
  // <input type=color> REQUIRES 7 chars (#RRGGBB); shortform or alpha hexes
  // are silently rejected by the browser. The text input still accepts the
  // full range — only the visual picker is constrained.
  function hexToColorInput(hex) {
    var v = String(hex || '').trim();
    if (/^#[0-9a-fA-F]{6}$/.test(v)) return v.toLowerCase();
    if (/^#[0-9a-fA-F]{3}$/.test(v)) {
      // #abc -> #aabbcc
      return ('#' + v[1] + v[1] + v[2] + v[2] + v[3] + v[3]).toLowerCase();
    }
    // 4 or 8 chars (alpha) — strip alpha for the picker preview.
    if (/^#[0-9a-fA-F]{8}$/.test(v)) return v.slice(0, 7).toLowerCase();
    if (/^#[0-9a-fA-F]{4}$/.test(v)) return ('#' + v[1] + v[1] + v[2] + v[2] + v[3] + v[3]).toLowerCase();
    return '#000000';
  }

  // True when the form values differ from the saved state.tokens.
  function themeFormDirty() {
    var current = store.getTokens();
    for (var i = 0; i < THEME_TOKENS.length; i++) {
      var name = THEME_TOKENS[i].name;
      var hexInput = document.getElementById('tk-' + name + '-hex');
      if (!hexInput) continue;
      var formVal = hexInput.value.trim().toLowerCase();
      var savedVal = String(current[name] || '').trim().toLowerCase();
      if (formVal !== savedVal) return true;
    }
    return false;
  }

  // Reads every token input from the Theme tab into a map.
  function readThemeForm() {
    var out = {};
    for (var i = 0; i < THEME_TOKENS.length; i++) {
      var name = THEME_TOKENS[i].name;
      var hexInput = document.getElementById('tk-' + name + '-hex');
      if (!hexInput) continue;
      out[name] = hexInput.value.trim();
    }
    return out;
  }

  // Injects the form values into <head> for live preview — WITHOUT touching
  // state.tokens. Called on every input/change event in the Theme tab
  // (debounced — see scheduleThemePreview below).
  function previewThemeLive() {
    store.applyTokens(readThemeForm());
  }

  // ★ PERF-13 fix (Task 45): the Theme tab used to call previewThemeLive()
  // on EVERY keystroke/drag tick — each call rebuilt the :root token block,
  // forcing a full style recalc + repaint of every element referencing the
  // 11 CSS vars (7 keystrokes for "#1a1a1a" = 7 full cascades, ~30-60 ms
  // each on desktop, 100-200 ms on mobile). Debounced to 200 ms: one
  // recompute after the user stops typing. The timer bails when the Theme
  // tab is no longer active — otherwise a pending preview could fire AFTER
  // a tab switch's store.applyTokens() revert and stamp the form values
  // over the saved tokens (a leak this debounce would otherwise introduce).
  var themePreviewTimer = null;

  function scheduleThemePreview() {
    if (themePreviewTimer) clearTimeout(themePreviewTimer);
    themePreviewTimer = setTimeout(function () {
      themePreviewTimer = null;
      if (activeTab !== 'theme') return;  // tab switched mid-debounce → revert already applied
      previewThemeLive();
    }, 200);
  }

  function renderThemePanel() {
    var tokens = store.getTokens();

    // Group tokens by their `group` field so the editor reads naturally.
    var groups = [];
    var groupMap = {};
    THEME_TOKENS.forEach(function (t) {
      if (!groupMap[t.group]) {
        groupMap[t.group] = { name: t.group, tokens: [] };
        groups.push(groupMap[t.group]);
      }
      groupMap[t.group].tokens.push(t);
    });

    // ★ Feature 4: read the current WhatsApp number from the store (defaults
    //   to the placeholder '233000000000' when the API hasn't returned a row
    //   yet — pre-seed installs). The Theme tab now has a "Store Contact"
    //   section below the color tokens with an input + its own Save button.
    var whatsappNumber = '';
    if (store && typeof store.getWhatsAppNumber === 'function') {
      whatsappNumber = store.getWhatsAppNumber() || '';
    }

    return el('section', { class: 'panel' }, [
      el('h3', { class: 'panel-title' }, 'Theme & Colors'),
      el('div', { class: 'panel-body' }, [
        el('p', { class: 'muted' }, 'Rebrand the site colors without touching code. Changes apply live as you pick — click Save to keep them, Reset to Defaults to undo all customization.'),
        groups.map(function (g) {
          return el('div', { class: 'landing-section-editor' }, [
            el('h4', {}, g.name),
            el('div', { class: 'editor-grid' }, g.tokens.map(function (t) {
              var current = String(tokens[t.name] || '');
              return el('div', { class: 'form-row' }, [
                el('label', { for: 'tk-' + t.name + '-hex' }, t.label),
                // ★ UI-14 fix: was `class: 'photo-row'` — the `.photo-row`
                //   rule (theme.css ~L1325-1328) has a `@media (max-width: 767px)`
                //   breakpoint that sets `flex-direction: column`, stacking the
                //   colour picker above the hex input on mobile. That breakpoint
                //   was designed for the product photo row (file input above
                //   preview thumbnail). On the Theme tab, the colour picker (56px
                //   wide) + hex input (120px min) fit side-by-side even at 320px
                //   viewport width — the stacking was unnecessary + doubled the
                //   Theme tab's height on mobile. Changed to `class: 'color-row'`
                //   + added a `.color-row` CSS rule (theme.css) that's like
                //   `.photo-row` but WITHOUT the mobile `flex-direction: column`
                //   breakpoint. The colour picker + hex input stay side-by-side
                //   on all viewport widths.
                el('div', { class: 'color-row' }, [
                  el('input', {
                    id: 'tk-' + t.name + '-color',
                    type: 'color',
                    value: hexToColorInput(current),
                    title: 'Pick a color',
                    style: { width: '56px', height: '38px', padding: '0', border: '1px solid var(--border)', background: 'transparent', cursor: 'pointer', flexShrink: '0' }
                  }),
                  el('input', {
                    id: 'tk-' + t.name + '-hex',
                    type: 'text',
                    value: current,
                    maxlength: 9,
                    placeholder: '#1a1a1a',
                    title: 'Hex color (#RGB, #RRGGBB, or #RRGGBBAA)',
                    style: { flex: '1', minWidth: '120px' }
                  })
                ]),
                el('p', { class: 'form-error', id: 'tk-' + t.name + '-error' }, 'Must be a hex color (e.g. #1a1a1a)')
              ]);
            }))
          ]);
        }),
        el('div', { class: 'form-actions', style: { marginTop: '20px' } }, [
          el('button', { id: 'tk-save', type: 'button', class: 'btn-md fill' }, 'Save Theme'),
          el('button', {
            id: 'tk-reset', type: 'button', class: 'btn-md outline',
            style: { borderColor: '#dc2626', color: '#dc2626' }
          }, 'Reset to Defaults')
        ]),
        // ★ Feature 4: Store Contact section — WhatsApp number editor.
        //   Below the color tokens, separated by an <hr>. Has its own Save
        //   button (the WhatsApp number is a site_setting, not a token, so
        //   it needs its own PUT to api/settings.php). The number is digits-
        //   only (country code + local number, no + or punctuation) and
        //   powers the WhatsApp FAB link's href on the public site.
        el('hr', { style: { border: 'none', borderTop: '1px solid var(--border)', margin: '24px 0 16px' } }),
        el('h4', { class: 'panel-subtitle' }, 'Store Contact'),
        el('div', { class: 'form-row' }, [
          el('label', { for: 'wa-number' }, 'WhatsApp Business Number'),
          el('input', {
            id: 'wa-number',
            type: 'tel',
            value: whatsappNumber,
            placeholder: '233000000000',
            maxlength: 15,
            inputmode: 'numeric',
            pattern: '[0-9+\\s\\-()]{6,20}',
            title: 'Country code + local number (e.g. 233244567890). The + and punctuation are stripped on save.',
            style: { maxWidth: '280px' }
          }),
          el('p', { class: 'muted', style: { fontSize: '12px', marginTop: '4px' } },
            'Digits only (country code + local number, no + or punctuation). This number powers the WhatsApp chat button on the live site.'),
          el('p', { class: 'form-error', id: 'wa-number-error' }, 'Must be 6-15 digits.')
        ]),
        el('div', { class: 'form-actions' }, [
          el('button', { id: 'wa-save', type: 'button', class: 'btn-md fill' }, 'Save WhatsApp Number')
        ])
      ])
    ]);
  }

  function bindThemeForm() {
    var saveBtn = document.getElementById('tk-save');
    if (saveBtn) saveBtn.addEventListener('click', handleThemeSave);
    var resetBtn = document.getElementById('tk-reset');
    if (resetBtn) resetBtn.addEventListener('click', handleThemeReset);

    // ★ Feature 4: bind the WhatsApp number Save button. The number is a
    //   site_setting (not a token), so it has its own PUT to api/settings.php
    //   via store.saveWhatsAppNumber. On success: re-render the panel + flash.
    //   On error: light up the field's error message.
    var waSaveBtn = document.getElementById('wa-save');
    if (waSaveBtn) waSaveBtn.addEventListener('click', handleWhatsAppSave);

    // Live preview + cross-binding between the color picker and the hex text.
    // Typing in the hex box updates the picker; dragging the picker updates
    // the hex box; both fire applyTokens(formMap) so the change is visible
    // instantly without a save.
    THEME_TOKENS.forEach(function (t) {
      var colorInput = document.getElementById('tk-' + t.name + '-color');
      var hexInput = document.getElementById('tk-' + t.name + '-hex');
      var errEl = document.getElementById('tk-' + t.name + '-error');
      if (!colorInput || !hexInput) return;

      colorInput.addEventListener('input', function () {
        // Picker emits #RRGGBB only; copy straight into the hex field.
        hexInput.value = colorInput.value;
        if (errEl) errEl.classList.remove('show');
        scheduleThemePreview();  // ★ PERF-13: was previewThemeLive() per tick
      });

      hexInput.addEventListener('input', function () {
        var v = hexInput.value.trim();
        // Only update the picker for valid #RRGGBB shapes; otherwise leave
        // it alone (don't snap to #000000 while the user is mid-typing).
        if (/^#[0-9a-fA-F]{6}$/.test(v)) colorInput.value = v.toLowerCase();
        if (errEl) errEl.classList.remove('show');
        scheduleThemePreview();  // ★ PERF-13: was previewThemeLive() per keystroke
      });
    });
  }

  // ★ Feature 4: save the WhatsApp number via store.saveWhatsAppNumber.
  //   Mirrors handleThemeSave's pattern: disable the button during the API
  //   call, re-render on success, re-enable on error.
  function handleWhatsAppSave() {
    var input = document.getElementById('wa-number');
    if (!input) return;
    var value = input.value.trim();
    // Strip + and punctuation client-side too (the server also strips —
    // defense in depth). Empty input falls back to the default placeholder
    // on the server side, but we'll reject here so Morbi sees the error.
    var cleaned = value.replace(/[^0-9]/g, '');
    var errEl = document.getElementById('wa-number-error');
    if (cleaned !== '' && (cleaned.length < 6 || cleaned.length > 15)) {
      if (errEl) { errEl.textContent = 'Must be 6-15 digits (country code + local number, no + or punctuation).'; errEl.classList.add('show'); }
      flashStatus('WhatsApp number must be 6-15 digits.');
      return;
    }
    if (errEl) errEl.classList.remove('show');

    var saveBtn = document.getElementById('wa-save');
    if (saveBtn) saveBtn.disabled = true;
    store.saveWhatsAppNumber(cleaned).then(function (saved) {
      renderActivePanel();
      flashStatus('Saved WhatsApp number: ' + (saved || '(default)') + '.');
    }).catch(function (err) {
      if (saveBtn) saveBtn.disabled = false;
      flashStatus(err.message || 'Save failed.');
    });
  }

  function handleThemeSave() {
    var patch = readThemeForm();
    // Validate before round-trip — the server repeats the same check, but a
    // client-side guard avoids a wasted 422 round-trip and lights up the
    // per-field error inline.
    var valid = true;
    THEME_TOKENS.forEach(function (t) {
      var v = patch[t.name];
      if (!v || !/^#[0-9a-fA-F]{3,8}$/.test(String(v))) {
        showFormError('tk-' + t.name + '-hex', 'tk-' + t.name + '-error', 'Must be a hex color (e.g. #1a1a1a)');
        valid = false;
      } else {
        hideFormError('tk-' + t.name + '-hex', 'tk-' + t.name + '-error');
      }
    });
    if (!valid) return;

    var saveBtn = document.getElementById('tk-save');
    if (saveBtn) saveBtn.disabled = true;
    store.saveTokens(patch).then(function (tokens) {
      // ★ PERF-06: was doRender(). ★ BS-7 fix: re-render BEFORE the flash —
      //   the old flash-then-doRender() order wrote the message to
      //   #dash-status and then replaced it with a fresh empty span, so
      //   "Saved N theme colors" never became visible.
      renderActivePanel();
      flashStatus('Saved ' + Object.keys(patch).length + ' theme color' + (Object.keys(patch).length === 1 ? '' : 's') + '.');
    }).catch(function (err) {
      if (saveBtn) saveBtn.disabled = false;
      flashStatus(err.message || 'Save failed.');
    });
  }

  function handleThemeReset() {
    if (!confirm('Reset ALL theme colors to the defaults? This cannot be undone.')) return;
    var resetBtn = document.getElementById('tk-reset');
    if (resetBtn) resetBtn.disabled = true;
    store.resetTokens().then(function () {
      // ★ PERF-06: was doRender(). ★ BS-7: re-render before the flash (same
      //   message-loss shape as handleThemeSave).
      renderActivePanel();
      flashStatus('Theme reset to defaults.');
    }).catch(function (err) {
      if (resetBtn) resetBtn.disabled = false;
      flashStatus(err.message || 'Reset failed.');
    });
  }

  /* ====================================================================
     BOOTSTRAP ACTIVATION (Phase 1)
     The vendored Bootstrap 5.3.8 stylesheet is loaded ONLY when the
     dashboard renders — never on the public landing/storefront routes
     (locked decision, PROJECT-ROADMAP §3). The link is appended to <head>
     once and never removed; BS5 is scoped to its own classes, so leaving
     it loaded across a route change has zero visual effect on the public
     pages (no `.container`/`.row`/`.col-*` exist in landing/storefront
     markup). Idempotent across re-renders.
     ==================================================================== */
  function ensureBootstrap() {
    if (document.getElementById('morbi-bs-css')) return;
    var link = document.createElement('link');
    link.id = 'morbi-bs-css';
    link.rel = 'stylesheet';
    link.href = 'vendor/bootstrap/5.3.8/bootstrap.min.css';
    // ★ Phase 10 (2026-09-26): add an onerror handler so a missing vendor
    //   folder (deploy error, FTP upload incomplete, .gitignore'd) is at
    //   least visible in devtools. The dashboard will render unstyled
    //   (relying on theme.css's grid/flex fallbacks), but the admin will
    //   see the diagnostic instead of silently wondering why the layout
    //   looks wrong. Was: a bare appendChild with no error handling — the
    //   <link> 404'd silently in the Network tab + the dashboard rendered
    //   unstyled with no clue why.
    link.onerror = function () {
      if (typeof console !== 'undefined' && console.error) {
        console.error('[morbi] Bootstrap CSS failed to load: vendor/bootstrap/5.3.8/bootstrap.min.css is missing (404). The dashboard will render with limited styling. Re-upload the vendor/bootstrap/ folder or run the build script.');
      }
    };
    document.head.appendChild(link);
  }

  /* ====================================================================
     BACKUP / MIGRATION (Phase 0, increment 0c)
     Export downloads the current server state as JSON (same shape the old
     localStorage app produced). Import posts it to api/import.php, which
     replaces products/categories inside one transaction, then the store
     re-hydrates so the UI reflects server truth immediately.
     ==================================================================== */

  function exportBackup() {
    var blob = new Blob([store.exportJSON()], { type: 'application/json' });
    var link = document.createElement('a');
    var url = URL.createObjectURL(blob);  // ★ RT-11 fix: capture URL before removing link
    link.href = url;
    link.download = 'morbi-backup-' + new Date().toISOString().slice(0, 10) + '.json';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    // ★ RT-11 fix: was `setTimeout(function () { URL.revokeObjectURL(link.href); }, 1000)`.
    //   Problems: (1) 1-second timeout may fire before the browser's download
    //   navigator has read the blob URL on slow browsers (older Safari, mobile
    //   Chrome with low memory) — the download fails silently. (2) `link.href`
    //   after `removeChild` may return `"blob:null"` on older Firefox (which
    //   GCs the blob URL when the <a> is removed from the DOM) —
    //   `revokeObjectURL` on that string is a no-op, so the blob leaks.
    //   Fix: capture the URL in a local variable (not `link.href`), and extend
    //   the timeout to 10 seconds (generous for even the slowest browsers).
    //   The local `url` variable is in closure scope — survives `removeChild`.
    setTimeout(function () { URL.revokeObjectURL(url); }, 10000);
    flashStatus('Backup downloaded.');
  }

  function importBackup(file) {
    if (!file) return;
    // ★ WF-14 fix: the import REPLACES the products table inside its
    //   transaction — two silent FK consequences used to hit with zero
    //   warning: (1) product_variants rows CASCADE-delete with the old
    //   products, and the legacy backup shape has NO variants field, so
    //   re-imported products come back with zero variants even if the
    //   store had configured sizes/gift-sets; (2) every historical
    //   order_items row loses its product_id (FK SET NULL), collapsing
    //   pre-import sales into the "deleted product" analytics row. The
    //   status message only counted categories/products/landing — no
    //   hint of either loss. Fix: a confirm() step that discloses both
    //   consequences BEFORE the destructive call (mirrors the two-step
    //   confirm used by Reset to Defaults), and a status line that
    //   reports what actually happened.
    var proceed = confirm('Import this backup?\n\n'
      + 'Sections present in the file (categories, products, landing, currency) REPLACE the current ones. Sections absent are left untouched.\n\n'
      + 'WARNING — replacing products:\n'
      + '  • Deletes every variant on every current product (the backup\n'
      + '    format carries no variants — re-imported products start with\n'
      + '    none). Re-add sizes/options afterwards if you need them.\n'
      + '  • Historical order items lose their product linkage; analytics\n'
      + '    will show those sales under "deleted product".\n\n'
      + 'This cannot be undone. Consider clicking "Export Backup" first.');
    if (!proceed) return;
    var reader = new FileReader();
    reader.onload = function (e) {
      store.importJSON(String(e.target.result)).then(function (counts) {
        // ★ PERF-14: import can replace categories/products/landing/currency
        //   — every cached panel could be stale. Wipe everything.
        cacheClear();
        // ★ PERF-06: was doRender(). ★ BS-7 fix: re-render BEFORE the flash —
        //   the old order wrote "Imported …" to #dash-status, then replaced
        //   the span via the re-render, so the import summary never showed.
        renderActivePanel();
        flashStatus('Imported ' + counts.categories + ' categories, ' + counts.products + ' products, ' + counts.landing
          + ' landing fields. Note: variants on replaced products were cleared and past order items were unlinked — re-add variants in the product editor if needed.');
      }).catch(function (err) {
        flashStatus(err.message || 'Import failed.');
      });
    };
    reader.onerror = function () {
      flashStatus('Could not read file.');
    };
    reader.readAsText(file);
  }

  /* ====================================================================
     BASE64 IMAGE MIGRATION (Phase 1 Batch 3)
     Two-step UX: dry-run first (scan + report counts, write nothing),
     then a second confirm dialog asks the user to commit. Safe to
     cancel at either step. Safe to re-run after a real migration —
     idempotent (no base64 rows left → 0 migrated).
     ==================================================================== */

  function handleMigrateImages() {
    var btn = document.getElementById('migrate-img-btn');
    // Step 1: dry-run preview.
    if (btn) btn.disabled = true;
    flashStatus('Scanning base64 images…');
    store.migrateBase64Images(true).then(function (res) {
      if (btn) btn.disabled = false;
      if (!res || (res.migrated === 0 && res.skipped === 0)) {
        flashStatus('No base64 images found — nothing to migrate.');
        return;
      }
      var kb = Math.round((res.bytes || 0) / 1024);
      var preview = 'Dry run: ' + res.migrated + ' image(s) would be migrated to uploads/ '
        + '(' + kb + ' KB total' + (res.skipped ? ', ' + res.skipped + ' skipped' : '') + ').';
      if (res.samples && res.samples.length > 0) {
        preview += ' First sample → product #' + res.samples[0].id + ' → ' + res.samples[0].would_become;
      }
      // Step 2: confirm + commit.
      if (!confirm(preview + '\n\nProceed with the real migration?')) {
        flashStatus('Migration cancelled.');
        return;
      }
      if (btn) btn.disabled = true;
      flashStatus('Migrating ' + res.migrated + ' image(s)…');
      store.migrateBase64Images(false).then(function (real) {
        // ★ PERF-06: was doRender(). ★ BS-7 fix: re-render BEFORE the flash
        //   (the old order wiped the migration summary instantly).
        //   ★ PERF-14 note: no cache clear needed — migrate touches ONLY
        //   products.image_path, which no cached panel reads.
        renderActivePanel();
        flashStatus('Migrated ' + real.migrated + ' image(s) to uploads/ (' + Math.round((real.bytes || 0) / 1024) + ' KB).'
          + (real.skipped ? ' ' + real.skipped + ' skipped.' : ''));
      }).catch(function (err) {
        if (btn) btn.disabled = false;
        flashStatus(err.message || 'Migration failed.');
      });
    }).catch(function (err) {
      if (btn) btn.disabled = false;
      flashStatus(err.message || 'Dry-run scan failed.');
    });
  }

  /* ---- PHASE-3 Batch 4: Server-side reset to defaults ------------------ *
   * Replaces the old local-only "Reset Everything" button. Asks for a
   * two-step confirm: (1) warning dialog explaining what gets deleted +
   * what's preserved; (2) on OK, calls store.resetDefaults() which POSTs
   * to api/reset-defaults.php (CSRF auto-attached by api()).
   *
   * What gets deleted:
   *   - All products (replaced with the 4 default products)
   *   - All categories (replaced with the 3 default categories)
   *   - All landing_content (replaced with the 8 default fields)
   *   - site_settings.currency (reset to 'GHS')
   *   - All token_* rows (the 11 design tokens reset to defaults)
   *
   * What is PRESERVED:
   *   - admin_users (your password stays — you can still sign in)
   *   - orders + order_items (Paystack transaction history — audit trail)
   *   - rate_limit_log (active rate-limit state)
   *   - password_resets (pending password reset tokens — don't strand users)
   *   - Your session (you stay signed in)
   */
  function handleResetDefaults() {
    var products = store.getProducts();
    var categories = store.getCategories();
    // ★ BL-17 fix: the confirm dialog now mentions the stock + scent_category
    //   preservation behavior (the server's reset-defaults.php preserves
    //   these for matching-name default products) + the variants-loss
    //   blind spot (variants are FK CASCADE-deleted with the products — the
    //   preservation logic doesn't restore variants because the new
    //   product row gets a fresh id and the old variant rows can't be
    //   re-keyed to it).
    var msg = 'Reset ALL CMS content to defaults?\n\n'
      + 'This will REPLACE:\n'
      + '  • ' + products.length + ' product(s) → 4 default products\n'
      + '  • ' + categories.length + ' categor(ies) → 3 default categories\n'
      + '  • All landing page copy → 8 default fields\n'
      + '  • Currency → GHS\n'
      + '  • 11 design tokens → default palette\n\n'
      + 'PRESERVED on the 4 default products (matched by name):\n'
      + '  • Stock counts (e.g. if you set "Oud Royale" stock=50, it stays at 50)\n'
      + '  • Scent category tags (male/female/unisex/untagged)\n\n'
      + 'NOT preserved (silently lost):\n'
      + '  • Variants on the 4 default products (the products table is wiped,\n'
      + '    which CASCADE-deletes product_variants via FK — re-add variants\n'
      + '    in the product editor after the reset if you need them back)\n'
      + '  • Any products you added beyond the 4 defaults (renamed defaults\n'
      + '    are also lost — only the exact default names are matched)\n\n'
      + 'PRESERVED (not affected):\n'
      + '  • Your admin account + password (you stay signed in)\n'
      + '  • Paystack order ROWS + their items (the transaction audit trail survives)\n'
      + '  • Password reset tokens (pending recovery links)\n\n'
      + 'BUT NOTE — historical analytics after the reset:\n'
      + '  • Every past order item loses its product LINKAGE (the FK sets the\n'
      + '    product reference to NULL when the products table is wiped).\n'
      + '  • Analytics > Top Products will show all pre-reset sales as one\n'
      + '    row marked "deleted product". Order rows, amounts, and customer\n'
      + '    details survive — but you can no longer answer "how many units\n'
      + '    of Oud Royale have I sold in total?" from analytics.\n\n'
      + 'This cannot be undone. Consider clicking "Export Backup" first if you want to keep current content.';
    if (!confirm(msg)) return;

    flashStatus('Resetting CMS content to defaults…');
    store.resetDefaults().then(function (res) {
      var counts = (res && res.counts) || {};
      // ★ PERF-14: reset-defaults replaces every CMS section — wipe all
      //   panel caches. ★ PERF-06: was doRender(). ★ BS-7 fix: re-render
      //   BEFORE the flash so the reset summary stays visible.
      cacheClear();
      renderActivePanel();
      flashStatus('Reset complete: '
        + (counts.products || 0) + ' products, '
        + (counts.categories || 0) + ' categories, '
        + (counts.landing || 0) + ' landing fields, '
        + (counts.tokens || 0) + ' design tokens restored to defaults.');
    }).catch(function (err) {
      flashStatus(err.message || 'Reset failed.');
    });
  }

  /* ====================================================================
     SHARED HELPERS
     ==================================================================== */

  function showFormError(inputId, errorId, message) {
    var input = document.getElementById(inputId);
    var error = document.getElementById(errorId);
    if (input) input.classList.add('invalid');
    if (error) { error.textContent = message; error.classList.add('show'); }
  }

  function hideFormError(inputId, errorId) {
    var input = document.getElementById(inputId);
    var error = document.getElementById(errorId);
    if (input) input.classList.remove('invalid');
    if (error) error.classList.remove('show');
  }

  // FIX-WF-4: flashStatus now finds the inline status element
  // ★ Phase 10 (2026-09-26): added an optional `isSuccess` 2nd argument
  //   so callers can explicitly signal success vs error. Was: substring
  //   matching on the message ("Saved", "Added", etc.) — fragile, because
  //   an error message containing "Saved" (e.g. "Save failed: ...") would
  //   be colored green. The legacy 1-arg form is preserved for backward
  //   compat — existing callers that don't pass the 2nd arg still get the
  //   substring-matching behavior. New callers should pass the explicit flag.
  function flashStatus(msg, isSuccess) {
    var span = document.getElementById('dash-status');
    if (span) {
      span.textContent = msg;
      // Determine success color: explicit arg wins; otherwise fall back to
      // the legacy substring heuristic for callers that haven't been updated.
      var success;
      if (typeof isSuccess === 'boolean') {
        success = isSuccess;
      } else {
        // PHASE-0: 'Backup downloaded.' and 'Imported ...' are success messages too.
        success = msg.indexOf('Saved') !== -1 || msg.indexOf('Added') !== -1
          || msg.indexOf('Imported') !== -1 || msg.indexOf('downloaded') !== -1;
      }
      span.style.color = success ? '#2D8B4E' : '#dc2626';
      setTimeout(function () { if (span.textContent === msg) span.textContent = ''; }, 3000);
    } else {
      // ★ Phase 10 (2026-09-26): was `alert(msg)` — blocking, jarring, and
      //   can't be styled. Now logs to console.error so the message is at
      //   least visible in devtools without blocking the UI. The #dash-status
      //   span should always be rendered (it's in the dashboard's root
      //   template) — if it's missing, something is very wrong with the
      //   render path. alert() would have been the only signal, but a
      //   console.error is better for debugging + doesn't trap keyboard
      //   focus in a native dialog.
      if (typeof console !== 'undefined' && console.error) {
        console.error('[morbi] flashStatus: #dash-status not found in DOM. Message was:', msg);
      }
    }
  }

  global.MorbiDashboard = { render: render };
})(window);
