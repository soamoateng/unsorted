/**
 * router.js — Clean-path (history.pushState) routing with a hash-router
 * backward-compat shim. Scroll-to-top on navigation is preserved.
 *
 * Phase 6 Batch 0 change: switched from hash-based routing
 * (`morbi-shop/#/dashboard`) to HTML5 history routing (`morbi-shop/dashboard`).
 * The site is now reachable at clean paths. Old bookmarks/links with `#/...`
 * in the hash are auto-redirected to the clean path on first load (via
 * `history.replaceState` — same-origin, no server round-trip) so external
 * links keep working indefinitely.
 *
 * Backward-compat note: the .htaccess `mod_rewrite` SPA-fallback rule
 * serves index.html for any request that's not a real file/dir, so deep
 * links like `morbi-shop/dashboard` work on browser refresh + on shared
 * links. Without mod_rewrite (rare — XAMPP without the rewrite_module
 * uncommented), the fallback is to the project root URL, which the router
 * then resolves to the landing page (the `default_` handler).
 *
 * Public API (unchanged surface):
 *   register(pattern, handler)   — pattern is now `/foo` or `/foo/:id`
 *                                  (was: `#/foo` or `#/foo/:id`)
 *   default(handler)             — fall-through handler for unknown paths
 *   navigate(path)               — path is now `/foo` (was: `#/foo`)
 *   start()                      — wires popstate + initial dispatch
 *
 * Changelog retained from prior versions:
 *   - FIX-RT-1: safeDecode() guards decodeURIComponent against URIError on
 *     malformed segments (e.g. a pasted URL like "/morcenzs%zz"). The
 *     exception is caught and the raw segment is used so one bad URL can
 *     never break routing.
 *   - Phase 2 (Bicycle): query-string support. Paystack redirects back to
 *     `/payment-callback?reference=morbi-123-abc&status=success`. The
 *     router strips the query from each segment before matching the
 *     route pattern, and passes the parsed query object as `params.query`
 *     to the handler. Routes without `?` get `query: {}` (unchanged).
 *   - Phase 6 Batch 0: clean-path routing. The match() function is
 *     unchanged; the dispatch() and navigate() functions now read
 *     `window.location.pathname` instead of `window.location.hash`. A
 *     one-time hash-to-path redirect handles old bookmarks.
 *   - ★ Phase 6 Batch 0 fix-up (Task 57, 2026-09-23): base-path-aware
 *     routing. The original Phase 6 Batch 0 rewrite assumed web-root
 *     hosting (`http://localhost/`), but the project is deployed at a
 *     subdirectory (`http://localhost/morbi-shop/`). Two symptoms:
 *       (a) navigate('/morcenzs') called pushState({}, '', '/morcenzs')
 *           which is an ABSOLUTE path → the URL bar showed
 *           `http://localhost/morcenzs` (the `/morbi-shop/` prefix was
 *           DROPPED). On refresh, Apache 404'd. Manual URL typing
 *           produced the double-slash `morbi-shop//morcenzs` because
 *           Apache's mod_dir auto-appends a trailing slash on directory
 *           requests (DirectorySlash directive — see
 *           https://httpd.apache.org/docs/2.4/mod/mod_dir.html#directoryslash)
 *           and the user/browser appended `/morcenzs` without removing
 *           the trailing slash.
 *       (b) On a direct visit to `http://localhost/morbi-shop/morcenzs`,
 *           dispatch() read location.pathname = "/morbi-shop/morcenzs",
 *           match() split it into ['morbi-shop', 'morcenzs'] (2 segments),
 *           and no registered 1-segment route matched → default handler
 *           fired → MorbiLanding.render() (the landing page, NOT the
 *           storefront). dashboard.js (lines 1304, 1326) and
 *           payment-callback.js (line 272) masked this with
 *           `pathname.indexOf('dashboard') !== -1` substring checks.
 *     Fix: auto-detect the base path from this script's own <script src>
 *     (URL resolves against the document base; pathname is e.g.
 *     `/morbi-shop/js/router.js`, strip the `/js/router.js` suffix to
 *     get `/morbi-shop/`). All dispatch()/navigate()/migrateHashBookmark()
 *     calls now strip (on read) or prepend (on write) the base path.
 *     Web-root hosting (basePath='/') is a no-op. Moving the deployable
 *     root to any other subdirectory works without code change.
 */
(function (global) {
  'use strict';

  var routes = [];
  var defaultHandler = null;

  // ★ Phase 6 Batch 0 fix-up (Task 57): capture this script's <script>
  // tag NOW (during synchronous execution) so we can read its src for
  // base-path detection. `document.currentScript` is only valid during
  // the script's initial execution — by the time any async callback
  // runs, it's null. Capturing here makes it available to detectBasePath()
  // whenever it's called. The typeof guard keeps the file parseable in
  // non-browser environments (Node tests) where `document` is undefined.
  var thisScript = (typeof document !== 'undefined' && document.currentScript) || null;

  // ★ Phase 6 Batch 0 fix-up (Task 57): detect the base path of the
  // deployable web root from this script's <script src> attribute.
  // Strategy:
  //   1. Use thisScript (captured at module load — see above).
  //   2. Fallback: scan all <script> tags for one whose src ends with
  //      /js/router.js (covers very old browsers without currentScript).
  //   3. Fallback: return '/' (web-root hosting — original behavior).
  // The script's URL pathname is e.g. `/morbi-shop/js/router.js` (when
  // deployed at subdirectory) or `/js/router.js` (web root). Stripping
  // the `/js/router.js` suffix yields `/morbi-shop/` or `/`.
  // Normalization: always leading-slash + always trailing-slash, so
  // stripBasePath/prependBasePath can use simple string ops.
  function detectBasePath() {
    var src = thisScript && thisScript.src;
    if (!src && typeof document !== 'undefined') {
      var scripts = document.getElementsByTagName('script');
      for (var i = scripts.length - 1; i >= 0; i--) {
        var s = scripts[i].src || '';
        // Match `/js/router.js` at end of pathname (with optional ?query or #hash).
        if (/\/js\/router\.js(?:[?#].*)?$/.test(s)) {
          src = s;
          break;
        }
      }
    }
    if (!src) return '/';
    try {
      // URL constructor resolves relative URLs against the document base.
      // In modern browsers this is `new URL(src, global.location.href)`.
      var u = new URL(src, global.location.href);
      var p = u.pathname;
      // Strip the `/js/router.js` suffix (and any trailing query/hash).
      p = p.replace(/\/js\/router\.js(?:[?#].*)?$/, '/');
      // Normalize: leading slash (URL guarantees this, but be defensive).
      if (p.charAt(0) !== '/') p = '/' + p;
      // Normalize: trailing slash (so prependBasePath can do `basePath.replace(/\/$/, '') + path`).
      if (p.length > 1 && p.charAt(p.length - 1) !== '/') p = p + '/';
      return p;
    } catch (e) {
      // Very old browsers without URL constructor → assume web root.
      return '/';
    }
  }

  // Detected ONCE at module load. Cached for the lifetime of the page.
  // Exposed on MorbiRouter.basePath for cross-file access (e.g. app.js's
  // WhatsApp FAB visibility toggle needs to strip the base path from
  // window.location.pathname before comparing to known route paths).
  var basePath = detectBasePath();

  // Strip the base path prefix from a path. Used by dispatch() before
  // passing the path to match(). E.g.:
  //   basePath = '/morbi-shop/', path = '/morbi-shop/morcenzs' → '/morcenzs'
  //   basePath = '/morbi-shop/', path = '/morbi-shop'         → '/'
  //   basePath = '/morbi-shop/', path = '/morbi-shop/'        → '/'
  //   basePath = '/',          path = '/morcenzs'             → '/morcenzs'  (no-op)
  //   basePath = '/morbi-shop/', path = '/other/path'         → '/other/path' (no match — don't touch)
  function stripBasePath(p) {
    if (basePath === '/' || basePath === '') return p;
    var baseNoSlash = basePath.replace(/\/$/, ''); // '/morbi-shop'
    // Exact match on the base path without trailing slash → normalize to '/'.
    if (p === baseNoSlash) return '/';
    // Prefix match: strip everything up to and including the trailing slash
    // of basePath, keeping the leading slash of the rest.
    if (p.indexOf(basePath) === 0) {
      // p.slice(basePath.length - 1) = slice from index of basePath's trailing slash
      // E.g. basePath='/morbi-shop/' (length 12), p='/morbi-shop/morcenzs' (length 20)
      // → p.slice(11) = '/morcenzs' ✓
      return p.slice(basePath.length - 1);
    }
    return p;
  }

  // Prepend the base path to a path. Used by navigate() and
  // migrateHashBookmark() before calling pushState/replaceState. E.g.:
  //   basePath = '/morbi-shop/', path = '/morcenzs'           → '/morbi-shop/morcenzs'
  //   basePath = '/morbi-shop/', path = '/'                    → '/morbi-shop/'
  //   basePath = '/morbi-shop/', path = '/payment-callback?reference=XYZ'
  //                                                            → '/morbi-shop/payment-callback?reference=XYZ'
  //   basePath = '/',          path = '/morcenzs'              → '/morcenzs' (no-op)
  function prependBasePath(p) {
    if (basePath === '/' || basePath === '') return p;
    // Defensive: p must start with '/' (the project's navigate() contract
    // requires it — every call site passes '/foo' or '/').
    if (p.charAt(0) !== '/') p = '/' + p;
    // basePath ends with '/'; strip it, then concat with p.
    return basePath.replace(/\/$/, '') + p;
  }

  function register(pattern, handler) {
    routes.push({ pattern: pattern, handler: handler });
  }

  // FIX-RT-1: decodeURIComponent throws URIError on malformed input ("%/zz").
  // Fall back to the raw segment so one bad URL can never break routing.
  function safeDecode(segment) {
    try {
      return decodeURIComponent(segment);
    } catch (e) {
      return segment;
    }
  }

  function match(path) {
    // Strip the leading slash. Patterns are now `/foo` or `/foo/:id`,
    // so routeSegs/parts both lose the leading slash before comparison.
    var stripped = path.replace(/^\//, '');
    // Phase 2: split the path from the query string. Paystack redirects
    // back to `/payment-callback?reference=...&status=...` — we need to
    // match the route by path alone, then pass the parsed query to the
    // handler via params.query. Routes without `?` get query: {} (unchanged).
    var queryStr = '';
    var qMark = stripped.indexOf('?');
    if (qMark !== -1) {
      queryStr = stripped.slice(qMark + 1);
      stripped = stripped.slice(0, qMark);
    }
    var parts = stripped.split('/').filter(Boolean);
    var query = parseQuery(queryStr);
    for (var i = 0; i < routes.length; i++) {
      var route = routes[i];
      var routeSegs = route.pattern.replace(/^\//, '').split('/').filter(Boolean);
      if (routeSegs.length !== parts.length) continue;
      var params = { query: query };
      var ok = true;
      for (var j = 0; j < routeSegs.length; j++) {
        var seg = routeSegs[j];
        var actual = parts[j];
        if (seg.indexOf(':') === 0) {
          params[seg.slice(1)] = safeDecode(actual);
        } else if (seg !== actual) {
          ok = false;
          break;
        }
      }
      if (ok) return { handler: route.handler, params: params };
    }
    return null;
  }

  // Phase 2: minimal query-string parser. Handles `?a=1&b=2&c=` → {a:'1', b:'2', c:''}.
  // Does NOT handle arrays (`?a=1&a=2`) — last value wins, matching PHP's $_GET.
  function parseQuery(qs) {
    var out = {};
    if (!qs) return out;
    var pairs = qs.split('&');
    for (var i = 0; i < pairs.length; i++) {
      var pair = pairs[i];
      if (!pair) continue;
      var eq = pair.indexOf('=');
      var k, v;
      if (eq === -1) { k = pair; v = ''; }
      else           { k = pair.slice(0, eq); v = pair.slice(eq + 1); }
      try { k = decodeURIComponent(k.replace(/\+/g, ' ')); }
      catch (e) { /* keep raw */ }
      try { v = decodeURIComponent(v.replace(/\+/g, ' ')); }
      catch (e) { /* keep raw */ }
      out[k] = v;
    }
    return out;
  }

  // ★ Phase 6 Batch 0: detect an old-style `#/...` hash in the URL and
  // rewrite it to a clean path. This runs ONCE on start(). The replaceState
  // (not pushState) means the old bookmark URL is replaced in the history
  // stack — the user's back button goes to whatever was before the bookmark,
  // not back to the dead `#/...` URL.
  function migrateHashBookmark() {
    var hash = global.location.hash;
    if (!hash || hash.indexOf('#/') !== 0) return;
    // Old shape: `#/dashboard`, `#/payment-callback?reference=XYZ`, etc.
    // New shape: `/dashboard`, `/payment-callback?reference=XYZ` — but
    // ★ Phase 6 Batch 0 fix-up (Task 57): prepend the base path so the
    // rewritten URL keeps the subdirectory prefix. Without this, an old
    // bookmark like `http://localhost/morbi-shop/#/dashboard` would be
    // rewritten to `http://localhost/dashboard` (the `/morbi-shop/`
    // prefix would be DROPPED), breaking refresh + back button.
    var newPath = hash.slice(1); // strip the `#`
    if (newPath.indexOf('/') !== 0) newPath = '/' + newPath;
    newPath = prependBasePath(newPath);
    // Replace the URL — no history entry, no scroll jump.
    if (global.history && global.history.replaceState) {
      global.history.replaceState({}, '', newPath);
    }
  }

  function navigate(path) {
    // ★ Phase 6 Batch 0 fix-up (Task 57): prepend the base path to the
    // requested path before comparing to the current URL or calling
    // pushState. Without this, navigate('/morcenzs') called
    // pushState({}, '', '/morcenzs') which is an ABSOLUTE path → the
    // URL bar showed `http://localhost/morcenzs` (the `/morbi-shop/`
    // prefix was DROPPED). Now it shows `http://localhost/morbi-shop/morcenzs`.
    var fullUrl = prependBasePath(path);
    // ★ Phase 6 Batch 0: same-path check now compares location.pathname +
    // location.search against the requested path. If they match, dispatch
    // without pushing a new history entry (matches the old behavior where
    // setting `location.hash` to its current value was a no-op + dispatch).
    var current = global.location.pathname + global.location.search;
    if (current === fullUrl) {
      dispatch();
    } else if (global.history && global.history.pushState) {
      global.history.pushState({}, '', fullUrl);
      dispatch();
    } else {
      // Fallback (very old browsers without history API): fall back to
      // setting the hash. The router still works on hash routing in that
      // case because migrateHashBookmark() runs on start() and on every
      // load. This is essentially never hit on any browser from the last
      // decade but keeps the router from crashing outright.
      // NOTE: hash fallback uses the ORIGINAL path (without base prefix)
      // because hash routing doesn't go through Apache — the browser
      // resolves `#/foo` against the current document URL, which already
      // includes the base path.
      global.location.hash = '#' + path;
    }
  }

  function dispatch() {
    // FIX-UX-2: scroll to top on route change
    try { global.scrollTo(0, 0); } catch (e) { /* ignore */ }
    // ★ Phase 6 Batch 0: read from location.pathname + location.search
    // instead of location.hash. The path always starts with '/' (the
    // browser guarantees this); an empty path becomes '/'.
    var rawPath = global.location.pathname || '/';
    // ★ Phase 6 Batch 0 fix-up (Task 57): strip the base path before
    // matching so route patterns like `/morcenzs` work whether the app
    // is deployed at web root or at a subdirectory. Without this, a
    // direct visit to `/morbi-shop/morcenzs` would split into 2 segments
    // ('morbi-shop', 'morcenzs') and no 1-segment route would match →
    // default handler would fire → wrong page rendered.
    var path = stripBasePath(rawPath);
    // ★ Phase 6 Batch 0 fix-up (Task 57): include location.search so
    // match() can parse query params. WITHOUT THIS, Phase 2's
    // payment-callback route never receives params.query.reference — a
    // regression introduced when Phase 6 Batch 0 switched dispatch()
    // from `location.hash` (which included `?reference=XYZ`) to
    // `location.pathname` (which doesn't — the browser splits pathname
    // and search). payment-callback.js's `params.query.reference` was
    // always undefined → customers always saw "No payment reference
    // found in the URL" after every Paystack redirect-back. Verified by
    // tracing the data flow: dispatch() → match(path) → query parsing
    // only fires if `path` contains '?'. Original hash routing passed
    // the whole hash (#/payment-callback?reference=XYZ → strips '#')
    // to match(), so '?' was present. Clean-path routing passes only
    // pathname (no '?'), so query parsing was a no-op. Fix: concat
    // search onto the path before calling match().
    var matchPath = path + (global.location.search || '');
    var matched = match(matchPath);
    if (matched) {
      matched.handler(matched.params);
    } else if (defaultHandler) {
      defaultHandler({ path: path });
    } else {
      console.warn('[morbi] No route matched', path);
    }
    // ★ Phase 6 Batch 0: emit a custom event so non-router listeners
    // (e.g. app.js's WhatsApp FAB visibility toggle) can react to
    // internal navigate() calls. pushState does NOT fire popstate, so
    // without this, a listener on popstate alone would miss internal
    // navigation. The event name is namespaced to avoid collision.
    // ★ Phase 6 Batch 0 fix-up (Task 57): the event's `path` field is
    // the STRIPPED path WITHOUT search (the logical route, e.g.
    // `/morcenzs`), not the raw URL pathname (which would be
    // `/morbi-shop/morcenzs` in subdirectory deployments) and not the
    // match-path (which would include `?reference=XYZ`). Listeners can
    // compare against route patterns directly without knowing the base
    // path or query string. Listeners that need the query can read
    // window.location.search directly.
    try {
      var ev = new global.CustomEvent('morbi:route', { detail: { path: path } });
      global.dispatchEvent(ev);
    } catch (e) { /* very old browsers — listener can fall back to polling */ }
  }

  function start() {
    // ★ Phase 6 Batch 0: backward-compat shim. If the URL has a `#/...`
    // hash (old bookmark), rewrite it to a clean path BEFORE the first
    // dispatch — so old links keep working + the router sees a clean path
    // from the very first route match.
    migrateHashBookmark();
    // popstate fires on back/forward button clicks. (pushState does NOT
    // fire popstate — that's why navigate() calls dispatch() manually.)
    global.addEventListener('popstate', dispatch);
    dispatch();
  }

  function default_(handler) {
    defaultHandler = handler;
  }

  global.MorbiRouter = {
    register: register,
    default: default_,
    navigate: navigate,
    start: start,
    // ★ Phase 6 Batch 0 fix-up (Task 57): expose the detected base path
    // and the strip helper so cross-file consumers (currently app.js's
    // WhatsApp FAB visibility toggle) can normalize window.location
    // pathname against known route paths without duplicating the
    // detection logic. Read-only — do NOT reassign from outside.
    basePath: basePath,
    stripBasePath: stripBasePath,
    // ★ Phase 10 (2026-09-26): expose prependBasePath so storefront.js +
    //   landing.js can resolve relative asset paths (images/male/male-01.jpeg)
    //   against the app's base URL. Without this, clean-path routing
    //   (/morbi-shop/morcenzs) causes the browser to resolve relative
    //   image paths against /morbi-shop/morcenzs/ instead of /morbi-shop/,
    //   404ing every product image → the onerror flask-icon placeholder
    //   shows instead of the real perfume photo.
    prependBasePath: prependBasePath
  };

  // Phase 1 Batch 3 (R1): backward-compat alias. Same shallow-pointer
  // pattern as ui-helpers.js — keeps external code referencing the old
  // `ChowMenuRouter` name working. Internal callers now use `MorbiRouter`.
  global.ChowMenuRouter = global.MorbiRouter;
})(window);
