/**
 * reset-password.js — Phase 3 (Motorcycle) Batch 3 password recovery UI.
 *
 * Handles the #/reset-password?token=<64hex> route (the link emailed to the
 * admin by api/forgot-password.php). Shows a form with the new password +
 * confirm-password fields, calls store.resetPassword(token, password), and
 * on success redirects to #/dashboard so the admin can sign in with the
 * new password.
 *
 * Token comes from the URL query string (router.js parses it into params.query).
 * If no token is present (or the format is wrong — not 64 hex chars), the
 * page shows a friendly error instead of the form.
 *
 * No session/CSRF needed — the token itself is the auth (256 bits of entropy,
 * single-use, time-limited per the server-side password_resets table).
 */
(function (global) {
  'use strict';

  var ui = global.MorbiUI;
  var el = ui.el, clear = ui.clear;
  var store = global.MorbiStore;
  var router = global.MorbiRouter;

  var ROOT_ID = 'app-root';

  // ★ Phase 10 (2026-09-26): module-scoped timer for the post-success auto-
  //   redirect to /dashboard. Was: a bare `setTimeout(function () { router.navigate('/dashboard'); }, 3000)`
  //   with no handle — if the user clicked "Continue to Sign In" before the
  //   3s elapsed, OR navigated to a different route (e.g. clicked "Back to
  //   Login" then went home), the timer fired anyway and yanked them to
  //   /dashboard. Now: the timer handle is captured here + cleared in two
  //   places — (a) at the top of render() so a re-render cancels the pending
  //   redirect, and (b) inside the "Continue to Sign In" click handler so
  //   manual navigation cancels the auto-redirect.
  var rpRedirectTimer = null;

  function render(params) {
    var root = document.getElementById(ROOT_ID);
    // Cancel any pending auto-redirect from a previous successful reset
    // (e.g. user pressed Back to return to the reset-password page).
    if (rpRedirectTimer) { clearTimeout(rpRedirectTimer); rpRedirectTimer = null; }
    clear(root);

    var query = (params && params.query) || {};
    var token = (query.token || '').trim();

    root.appendChild(
      el('div', { class: 'container dashboard' }, [
        el('div', { class: 'main-body' }, [
          el('div', { class: 'dash-content' }, [
            el('span', { class: 'status-text', id: 'reset-status' }),
            el('section', { class: 'panel' }, [
              el('h3', { class: 'panel-title' }, 'Reset Password'),
              el('div', { class: 'panel-body' }, [
                !isValidToken(token)
                  ? renderInvalidToken()
                  : renderResetForm(token)
              ])
            ])
          ])
        ])
      ])
    );

    if (isValidToken(token)) {
      var submitBtn = document.getElementById('rp-submit');
      if (submitBtn) submitBtn.addEventListener('click', function () { handleSubmit(token); });
      var passInput = document.getElementById('rp-password');
      if (passInput) passInput.focus();
      ['rp-password', 'rp-confirm'].forEach(function (inputId) {
        var node = document.getElementById(inputId);
        if (node) node.addEventListener('keydown', function (e) {
          // ★ Phase 10 (2026-09-26): was a bare `if (e.key === 'Enter') { ... handleSubmit(token); }`.
          //   The handler fired even when the submit button was already
          //   disabled (in-flight request). Pressing Enter during the reset
          //   request would re-fire handleSubmit, which would re-read the
          //   (now-disabled) inputs + call store.resetPassword again — double
          //   submit. Fix: bail out if the submit button is disabled OR if
          //   the inputs themselves are disabled (post-success state).
          if (e.key === 'Enter') {
            e.preventDefault();
            var btn = document.getElementById('rp-submit');
            if (btn && btn.disabled) return;
            if (node.disabled) return;
            handleSubmit(token);
          }
        });
      });
    }
  }

  function isValidToken(token) {
    return typeof token === 'string' && /^[0-9a-f]{64}$/.test(token);
  }

  function renderInvalidToken() {
    return el('div', {}, [
      el('p', { class: 'muted', style: { color: '#dc2626' } },
        'Invalid or missing reset token. The link may have expired or been truncated.'),
      el('p', { class: 'muted' },
        'Request a new password reset link from the admin login page, or contact your site administrator.'),
      el('div', { class: 'form-actions', style: { marginTop: '12px' } }, [
        el('button', {
          class: 'btn-md fill',
          onclick: function () { router.navigate('/dashboard'); }
        }, 'Back to Login')
      ])
    ]);
  }

  function renderResetForm(token) {
    return el('form', { id: 'reset-form', class: 'item-editor', onsubmit: function (e) { e.preventDefault(); } }, [
      el('p', { class: 'muted' }, 'Choose a new password for your morbi.shop admin account.'),
      el('div', { class: 'form-row' }, [
        el('label', { for: 'rp-password' }, 'New Password * (min 8 characters)'),
        el('input', { id: 'rp-password', type: 'password', autocomplete: 'new-password', minlength: '8', required: true }),
        el('p', { class: 'form-error', id: 'rp-password-error' }, 'Password must be at least 8 characters')
      ]),
      el('div', { class: 'form-row' }, [
        el('label', { for: 'rp-confirm' }, 'Confirm Password *'),
        el('input', { id: 'rp-confirm', type: 'password', autocomplete: 'new-password', minlength: '8', required: true }),
        el('p', { class: 'form-error', id: 'rp-confirm-error' }, 'Passwords do not match')
      ]),
      el('div', { class: 'form-actions' }, [
        el('button', { id: 'rp-submit', type: 'button', class: 'btn-md fill' }, 'Reset Password')
      ])
    ]);
  }

  function handleSubmit(token) {
    var password = document.getElementById('rp-password').value;
    var confirm = document.getElementById('rp-confirm').value;
    var btn = document.getElementById('rp-submit');
    var valid = true;

    // ★ Phase 10 (2026-09-26): defense-in-depth against double-submit. The
    //   Enter-key + click handlers above already bail if the button is
    //   disabled, but a fast double-click before the .disabled=true line
    //   fires (line ~135 below) could still slip through. Bail here too.
    if (btn && btn.disabled) return;

    if (!password || password.length < 8) {
      showError('rp-password', 'rp-password-error', 'Password must be at least 8 characters');
      valid = false;
    } else {
      hideError('rp-password', 'rp-password-error');
    }

    if (password !== confirm) {
      showError('rp-confirm', 'rp-confirm-error', 'Passwords do not match');
      valid = false;
    } else {
      hideError('rp-confirm', 'rp-confirm-error');
    }

    if (!valid) return;

    if (btn) btn.disabled = true;
    if (btn) btn.textContent = 'Resetting…';

    store.resetPassword(token, password).then(function () {
      flashStatus('Password reset successfully. You can now sign in.', true);
      // ★ UX-18 fix: the 1.5s auto-redirect was shorter than the time it
      //   takes to read "Password reset successfully. You can now sign
      //   in." — users were yanked to the login screen wondering whether
      //   the reset had actually worked. Now:
      //     - the auto-redirect fires at 3s (double the old window), and
      //     - a "Continue to Sign In" button appears immediately, so the
      //       user controls the transition instead of racing a timer.
      //     (The token is single-use and consumed server-side, so leaving
      //     the form on screen is safe — a re-submit would just fail with
      //     "invalid or expired". The submit button stays disabled.)
      var actions = document.querySelector('#reset-form .form-actions');
      if (actions && !document.getElementById('rp-continue')) {
        var continueBtn = el('button', {
          id: 'rp-continue',
          type: 'button',
          class: 'btn-md outline',
          style: { marginLeft: '8px' },
          onclick: function () {
            // ★ Phase 10 (2026-09-26): cancel the 3s auto-redirect timer so
            //   the manual navigation doesn't get a duplicate navigate() call
            //   3s later (router.navigate is idempotent on same-path, but
            //   if the user navigated to a DIFFERENT route in the meantime,
            //   the timer would yank them back to /dashboard).
            if (rpRedirectTimer) { clearTimeout(rpRedirectTimer); rpRedirectTimer = null; }
            router.navigate('/dashboard');
          }
        }, 'Continue to Sign In');
        actions.appendChild(continueBtn);
      }
      // ★ Blind-spot fix (Task 43, UX-18 neighborhood): disable the password
      //   fields once the reset has succeeded. The form stays on screen now
      //   (3s window + Continue button), and its Enter-key handlers are
      //   still bound — pressing Enter in either field re-fired
      //   handleSubmit with the already-consumed token, replacing the
      //   success flash with a confusing "invalid or expired" error.
      //   Disabled inputs neither fire keydown nor accept edits.
      ['rp-password', 'rp-confirm'].forEach(function (inputId) {
        var node = document.getElementById(inputId);
        if (node) node.disabled = true;
      });
      // ★ Phase 10 (2026-09-26): capture the timer handle so it can be
      //   cancelled if the user clicks "Continue to Sign In" before the 3s
      //   elapses, OR if render() is called again (e.g. via Back button).
      rpRedirectTimer = setTimeout(function () {
        rpRedirectTimer = null;
        router.navigate('/dashboard');
      }, 3000);
    }).catch(function (err) {
      if (btn) { btn.disabled = false; btn.textContent = 'Reset Password'; }
      flashStatus(err.message || 'Reset failed. The link may be invalid or expired.', false);
      // ★ WF-13 fix: a WELL-FORMED token that has expired (1-hour TTL) or
      //   already been used renders the normal form, and every submit
      //   422s forever — the old flow showed the error flash for 5s and
      //   left the user staring at a form that can never succeed, with no
      //   in-page pointer to the recovery path (dashboard → "Forgot
      //   password?" → re-enter email → wait for a new link). Fix: when
      //   the server rejects the TOKEN itself (422 "Invalid or expired
      //   reset token."), convert the form into the same guided dead-end
      //   renderInvalidToken() already uses for malformed tokens: disable
      //   the fields (also prevents Enter-key re-submits with a consumed
      //   token — same defense as the Task 43 BS-3 fix) and surface
      //   "Request a New Link" / "Back to Login" actions. Validation
      //   errors (short password, mismatch — also 422 but different
      //   messages) deliberately keep the plain flash so the user can
      //   correct the fields.
      if (err && err.status === 422 && /invalid or expired/i.test(String(err.message || ''))) {
        showTokenRecovery();
      }
    });
  }

  // ★ WF-13 fix: guided recovery from the expired/consumed-token state.
  //   Disables the two password inputs + the submit button, explains WHY
  //   the reset can't proceed, and offers the two exits (request a new
  //   link from the login page — where the "Forgot password?" flow lives —
  //   or just go back to sign in). Idempotent: guard prevents duplicate
  //   blocks if the server is somehow hit twice.
  function showTokenRecovery() {
    if (document.getElementById('rp-recovery')) return;
    ['rp-password', 'rp-confirm'].forEach(function (inputId) {
      var node = document.getElementById(inputId);
      if (node) node.disabled = true;
    });
    var btn = document.getElementById('rp-submit');
    if (btn) { btn.disabled = true; btn.textContent = 'Link Expired'; }
    var form = document.getElementById('reset-form');
    if (!form) return;
    form.appendChild(
      el('div', { id: 'rp-recovery', style: { marginTop: '14px' } }, [
        el('p', { class: 'muted' },
          'This reset link is invalid, expired (links last 1 hour), or has already been used. '
          + 'The fields above have been disabled because they can no longer be submitted.'),
        el('div', { class: 'form-actions', style: { marginTop: '12px' } }, [
          el('button', {
            type: 'button',
            class: 'btn-md fill',
            onclick: function () { router.navigate('/dashboard'); }
          }, 'Request a New Link'),
          el('button', {
            type: 'button',
            class: 'btn-md outline',
            style: { marginLeft: '8px' },
            onclick: function () { router.navigate('/dashboard'); }
          }, 'Back to Login')
        ])
      ])
    );
  }

  function showError(inputId, errorId, msg) {
    var input = document.getElementById(inputId);
    var error = document.getElementById(errorId);
    if (input) input.style.borderColor = '#dc2626';
    if (error) { error.textContent = msg; error.style.display = 'block'; }
  }

  function hideError(inputId, errorId) {
    var input = document.getElementById(inputId);
    var error = document.getElementById(errorId);
    if (input) input.style.borderColor = '';
    if (error) { error.style.display = 'none'; }
  }

  function flashStatus(msg, isSuccess) {
    var span = document.getElementById('reset-status');
    if (span) {
      span.textContent = msg;
      span.style.color = isSuccess ? '#2D8B4E' : '#dc2626';
      // Auto-clear after 5 seconds (longer than the 3s in dashboard.js
      // because the reset-password page is simpler — no other UI competing).
      setTimeout(function () { if (span.textContent === msg) span.textContent = ''; }, 5000);
    } else {
      alert(msg);
    }
  }

  global.MorbiResetPassword = { render: render };
})(window);
