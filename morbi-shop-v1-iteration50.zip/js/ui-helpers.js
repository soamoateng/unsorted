/**
 * ui-helpers.js — Shared DOM & formatting kernel for morbi.shop.
 *
 * Single Responsibility: dependency-light DOM creation + pure formatting helpers.
 * Load order contract: this file MUST load before store.js (index.html enforces it)
 * because store.js delegates slugify() to it — one slug implementation total (DRY).
 *
 * Changelog (this refactor):
 *   - Removed pointless try/catch in formatPrice (property access cannot throw there).
 *   - Removed dead export formatDate() — verified zero callers across all 7 files.
 *   - Kept FIX-BL-10 `html` prop guard (defensive, costs one line, no caller today).
 *
 * Phase 1 Batch 2 (Scooter) addition:
 *   - compressImageToBlob(file, maxDim): canvas-based resize + JPEG/PNG
 *     compression that returns a Blob ready for FormData upload. Used by
 *     dashboard.js handleProductSave to send a real file to api/upload.php
 *     instead of a base64 data URL (the Phase 0 approach). PNG is preserved
 *     for transparency (same rule as the original Phase 0 compressImage that
 *     used to live in dashboard.js — removed by the OTH-17 fix in iteration 25
 *     as dead code; this helper is the live replacement and the transparency
 *     rule is preserved here).
 */
(function (global) {
  'use strict';

  /**
   * Create a DOM element.
   * @param {string} tag
   * @param {Object} [props] class|className, dataset, style(object), on* listeners,
   *                         html (text-only, sanitized per FIX-BL-10); booleans become
   *                         empty attributes; everything else goes to setAttribute.
   * @param {Array|Node|string|number} [children]
   * @returns {HTMLElement}
   */
  function el(tag, props, children) {
    const node = document.createElement(tag);
    if (props) {
      Object.keys(props).forEach(function (key) {
        const value = props[key];
        if (value == null) return;
        if (key === 'class' || key === 'className') {
          node.className = value;
        } else if (key === 'dataset') {
          Object.keys(value).forEach(function (dk) {
            node.dataset[dk] = value[dk];
          });
        } else if (key === 'style' && typeof value === 'object') {
          Object.assign(node.style, value);
        } else if (key.startsWith('on') && typeof value === 'function') {
          node.addEventListener(key.slice(2).toLowerCase(), value);
        } else if (key === 'html') {
          // FIX-BL-10: "html" prop is intentionally text-only — never innerHTML.
          node.textContent = String(value);
        } else if (value === true) {
          node.setAttribute(key, '');
        } else if (value === false) {
          // ignore
        } else {
          node.setAttribute(key, value);
        }
      });
    }
    appendChildren(node, children);
    return node;
  }

  function appendChildren(node, children) {
    if (children == null) return;
    if (!Array.isArray(children)) {
      children = [children];
    }
    children.forEach(function (child) {
      if (child == null || child === false) return;
      if (typeof child === 'string' || typeof child === 'number') {
        node.appendChild(document.createTextNode(String(child)));
      } else if (child instanceof Node) {
        node.appendChild(child);
      } else {
        node.appendChild(el(child.tag || 'div', child.props, child.children));
      }
    });
  }

  /** Empty a node. */
  function clear(node) {
    while (node.firstChild) node.removeChild(node.firstChild);
    return node;
  }

  /**
   * Format a price using the vendor's currency code/symbol.
   * FIX-BL-1: reads global.MorbiStore (was the undefined global.ChowMenuStore).
   * FIX-BL-11: round to 2 decimals to avoid floating-point artifacts.
   * Output contract (unchanged): integers drop ".00" ("GHS120"),
   * fractional values keep 2 dp ("GHS150.50").
   */
  function formatPrice(amount, currency) {
    var fallback = (global.MorbiStore && global.MorbiStore.DEFAULT_CURRENCY) || 'GHS';
    var sym = currency || fallback;
    // ★ Phase 10 (2026-09-26): handle null/undefined amount distinctly from
    //   a 0 amount. Was: `Number(amount) || 0` — both null AND 0 became "GHS0",
    //   which is misleading for null (a missing price should show "—" not
    //   "GHS0"). Now: null/undefined → "—" (em dash, the universal "no value"
    //   symbol in dashboards); 0 → "0" (preserves the original behavior for
    //   legitimate zero-amount items like free samples).
    //   Also: NaN (a real risk from corrupted server data) → "—" too.
    if (amount === null || amount === undefined) return '—';
    var num = Number(amount);
    if (!isFinite(num)) return '—';  // NaN or Infinity → "—"
    var rounded = Math.round(num * 100) / 100;
    return sym + rounded.toFixed(2).replace(/\.00$/, '');
  }

  /** Convert a File to a base64 data URL. */
  function fileToDataURL(file) {
    return new Promise(function (resolve, reject) {
      var reader = new FileReader();
      reader.onload = function () { resolve(reader.result); };
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  }

  /**
   * Resize + compress an image File in-browser, returning a Blob ready for
   * FormData upload. Mirrors the rules of dashboard's old in-file
   * compressImage() (max 800px on the long edge; PNG preserved for
   * transparency, everything else JPEG at q=0.85) — that helper was removed
   * by the OTH-17 fix in iteration 25 as dead code; this Blob-emitting version
   * is the live replacement. Saves a ~33% base64 inflation on the wire and
   * lets the server read the bytes directly from $_FILES.
   *
   * @param {File} file the user-selected image
   * @param {number} maxDim longest edge in px (defaults to 800)
   * @returns {Promise<Blob>} resized image as a Blob
   */
  function compressImageToBlob(file, maxDim) {
    maxDim = maxDim || 800;
    return fileToDataURL(file).then(function (dataUrl) {
      return new Promise(function (resolve, reject) {
        var img = new Image();
        // ★ Phase 10 (2026-09-26): add a 30s timeout so a corrupted image
        //   that never fires onload/onerror (rare browser bug, broken data
        //   URL, suspended tab) doesn't leave the Promise pending forever.
        //   The dashboard's handleProductSave is blocked waiting on this
        //   Promise — a hung compress means the save button stays disabled
        //   + the admin has no idea why. Now: 30s timeout rejects with a
        //   clear message + the dashboard's catch surfaces it.
        var timedOut = false;
        var timeoutId = setTimeout(function () {
          timedOut = true;
          reject(new Error('Image load timed out after 30s. The file may be corrupted or the browser tab was suspended.'));
        }, 30000);
        img.onload = function () {
          if (timedOut) return;  // timeout already fired
          clearTimeout(timeoutId);
          var w = img.width, h = img.height;
          if (w > h && w > maxDim) { h = Math.round(h * maxDim / w); w = maxDim; }
          else if (h > maxDim)     { w = Math.round(w * maxDim / h); h = maxDim; }
          // If the source is already smaller than maxDim, keep its dimensions
          // (just re-encode through the canvas to apply quality + format rules).
          var canvas = document.createElement('canvas');
          canvas.width = w; canvas.height = h;
          canvas.getContext('2d').drawImage(img, 0, 0, w, h);
          // PNG → keep PNG (preserve transparency); everything else → JPEG q=0.85.
          var isPng = (file.type === 'image/png') || (dataUrl.indexOf('image/png') !== -1);
          var type = isPng ? 'image/png' : 'image/jpeg';
          var quality = isPng ? undefined : 0.85;
          if (canvas.toBlob) {
            // Modern browsers (every browser since ~2017) support toBlob.
            canvas.toBlob(function (blob) {
              if (blob) resolve(blob);
              else reject(new Error('Image compression failed (toBlob returned null).'));
            }, type, quality);
          } else {
            // Fallback for very old browsers — re-encode via toDataURL then
            // convert to Blob via fetch(). Same byte output, just slower.
            var fallbackUrl = canvas.toDataURL(type, quality || 0.92);
            fetch(fallbackUrl).then(function (r) { return r.blob(); }).then(resolve, reject);
          }
        };
        img.onerror = function () {
          if (timedOut) return;  // timeout already fired
          clearTimeout(timeoutId);
          reject(new Error('Image load failed'));
        };
        img.src = dataUrl;
      });
    });
  }

  /** Generate a URL-safe slug from any text. Single source of truth (store.js delegates here).
   *  ★ Phase 10 (2026-09-26): added Unicode normalization via String.prototype.normalize('NFD')
   *    + strip combining marks. Was: bare [^a-z0-9\s-] which dropped accented chars entirely
   *    ("Café" → "caf", "Ürünler" → "rnler"). Now: NFD decomposes "é" → "e" + combining acute
   *    accent, then the [^a-z0-9\s-] strip removes the combining mark, leaving "cafe". This
   *    matches the behavior of most slug libraries (slugify, friendly-url, etc.). Browsers
   *    that don't support String.prototype.normalize (IE, very old Safari) fall back to the
   *    old behavior (drop accented chars) — same as before, no regression.
   *  ★ KISS guard: did NOT add a full transliteration table (à→a, ñ→n, etc.) — NFD handles
   *    the common Latin-script cases. Non-Latin scripts (CJK, Arabic, Cyrillic) are still
   *    stripped entirely, which matches the original behavior. */
  function slugify(text) {
    var s = String(text || '')
      .toLowerCase()
      .trim();
    // ★ Phase 10: NFD normalization + strip combining marks (accents).
    if (typeof s.normalize === 'function') {
      s = s.normalize('NFD');
    }
    return s
      .replace(/[^a-z0-9\s-]/g, '')  // strips combining marks + remaining non-ASCII
      .replace(/\s+/g, '-')
      .replace(/-+/g, '-')
      .replace(/^-|-$/g, '');
  }

  /* ==========================================================================
   * ★ Hamburger menu helper (Feature 1, header dropdown).
   *   Reusable dropdown menu — a hamburger button (fas fa-bars) that toggles
   *   an absolutely-positioned list of clickable menu items. The dropdown:
   *     - Closes on outside click
   *     - Closes on Escape key
   *     - Closes after clicking a menu item
   *   The caller passes an array of { label, onclick, icon? } items; the
   *   helper returns a wrapper <div> (position:relative) containing the
   *   button + the dropdown. The button uses the supplied `buttonClass` so
   *   each header can match its existing button styling (nav-item, btn-sm,
   *   btn-md outline, etc.).
   *
   *   The dark theme colors (background #1a1a1a, border #333, text #e0e0e0,
   *   hover #2a2a2a) live in the .header-menu-dropdown + .header-menu-item
   *   CSS rules in styles.css so the look is consistent across all three
   *   headers (dashboard, landing, storefront).
   * ========================================================================== */
  function renderHeaderMenu(items, buttonClass) {
    var wrapper = document.createElement('div');
    wrapper.className = 'header-menu-wrapper';

    var dropdown = el('div', { class: 'header-menu-dropdown', role: 'menu' });

    var btn = el('button', {
      class: buttonClass || 'btn-sm outline',
      type: 'button',
      title: 'Open menu',
      'aria-label': 'Open menu',
      'aria-haspopup': 'true',
      'aria-expanded': 'false',
      onclick: function (e) {
        e.stopPropagation();
        if (dropdown.classList.contains('open')) {
          closeMenu();
        } else {
          openMenu();
        }
      }
    }, [el('i', { class: 'fas fa-bars', 'aria-hidden': 'true' })]);

    function openMenu() {
      dropdown.classList.add('open');
      btn.setAttribute('aria-expanded', 'true');
      // Defer attaching the outside-click + escape listeners so the click
      // that opened the menu doesn't immediately close it (the same event
      // would otherwise bubble to document and trigger outsideHandler).
      setTimeout(function () {
        document.addEventListener('click', outsideHandler);
        document.addEventListener('keydown', escapeHandler);
      }, 0);
    }
    function closeMenu() {
      dropdown.classList.remove('open');
      btn.setAttribute('aria-expanded', 'false');
      document.removeEventListener('click', outsideHandler);
      document.removeEventListener('keydown', escapeHandler);
    }
    function outsideHandler(ev) {
      // If the wrapper was detached (route changed mid-open), self-clean.
      if (!document.contains(wrapper)) {
        document.removeEventListener('click', outsideHandler);
        document.removeEventListener('keydown', escapeHandler);
        return;
      }
      if (!wrapper.contains(ev.target)) closeMenu();
    }
    function escapeHandler(ev) {
      // ★ Phase 10 (2026-09-26): self-clean if the wrapper was detached
      //   (route changed mid-open). The outsideHandler already had this
      //   guard, but escapeHandler did NOT — if the user opened the menu
      //   and then navigated away WITHOUT clicking outside, the wrapper was
      //   detached but the Escape listener stayed attached to document
      //   forever (memory leak + the listener fired on every Escape press
      //   for the rest of the page session).
      if (!document.contains(wrapper)) {
        document.removeEventListener('keydown', escapeHandler);
        document.removeEventListener('click', outsideHandler);
        return;
      }
      if (ev.key === 'Escape' || ev.keyCode === 27) closeMenu();
    }

    (items || []).forEach(function (item) {
      var kids = [];
      if (item.icon) {
        kids.push(el('i', { class: item.icon, style: { marginRight: '8px', width: '14px', textAlign: 'center' }, 'aria-hidden': 'true' }));
      }
      kids.push(document.createTextNode(String(item.label)));
      var menuItem = el('button', {
        type: 'button',
        class: 'header-menu-item',
        role: 'menuitem',
        onclick: function (e) {
          e.stopPropagation();
          closeMenu();
          if (typeof item.onclick === 'function') {
            // ★ Phase 10 (2026-09-26): was a fully silent try/catch. Now logs
            //   the error so a buggy menu-item callback (e.g. router.navigate
            //   on a detached DOM, a reference to an undefined store method)
            //   is visible in devtools instead of the menu closing with no
            //   action and no diagnostic.
            try { item.onclick(); }
            catch (err) {
              if (typeof console !== 'undefined' && console.warn) {
                console.warn('[morbi] Menu item callback threw:', err && err.message ? err.message : err);
              }
            }
          }
        }
      }, kids);
      dropdown.appendChild(menuItem);
    });

    wrapper.appendChild(btn);
    wrapper.appendChild(dropdown);
    return wrapper;
  }

  /* ──────────────────────────────────────────────────────────────────────
   * ★ Phase 10 (2026-09-26): Modal focus management helpers.
   *
   * Two helpers that solve the same accessibility blind-spot across every
   * modal in the app (checkout, order detail, refund, re-auth, currency,
   * admin, password): none of them restored focus to the trigger element
   * on close, leaving keyboard + screen-reader users stranded on
   * document.body after closing any modal.
   *
   *   captureTrigger()  — call BEFORE opening a modal. Snapshots
   *                       document.activeElement so it can be restored
   *                       later. Returns an opaque handle.
   *   restoreTrigger() — call when the modal closes. Re-focuses the
   *                       snapshotted element (if it's still in the DOM).
   *
   * Design:
   *   - Stack-based so nested modals work (open A → open B → close B →
   *     focus back to A's trigger; close A → focus back to A's trigger).
   *   - Defensive: a detached node (removed during the modal's lifetime)
   *     is silently skipped — no throw, no console error.
   *   - The handle is a tiny object so callers can pass null/undefined
   *     without branching (restoreTrigger(null) is a no-op).
   * ──────────────────────────────────────────────────────────────────── */
  var focusStack = [];
  function captureTrigger() {
    var t = (typeof document !== 'undefined' && document.activeElement
             && document.activeElement !== document.body)
      ? document.activeElement : null;
    focusStack.push(t);
    return t;  // returned for callers that want to inspect/log
  }
  function restoreTrigger() {
    var t = focusStack.pop();
    if (t && document.contains(t)) {
      try {
        t.focus({ preventScroll: true });
      } catch (e) {
        // Older browsers don't support options on focus() — fall back to bare focus().
        try { t.focus(); } catch (e2) { /* detached node — give up */ }
      }
    }
  }

  global.MorbiUI = {
    el: el,
    clear: clear,
    formatPrice: formatPrice,
    fileToDataURL: fileToDataURL,
    compressImageToBlob: compressImageToBlob,
    slugify: slugify,
    renderHeaderMenu: renderHeaderMenu,
    // ★ Phase 10: focus management for modals
    captureTrigger: captureTrigger,
    restoreTrigger: restoreTrigger
  };

  // Phase 1 Batch 3 (R1): backward-compat alias. The original code shipped
  // with `ChowMenuUI` (a leftover from a previous project template). All
  // internal callers now use `MorbiUI`; this alias keeps any external
  // script or future snippet that still references the old name working.
  // It is a SHALLOW pointer to the same object — additions to MorbiUI
  // automatically appear on ChowMenuUI too.
  global.ChowMenuUI = global.MorbiUI;
})(window);
