<?php
/**
 * _bootstrap.php — shared kernel for every API endpoint (Single Responsibility:
 * error/output hygiene, session, JSON helpers, PDO handle, auth guard,
 * rate limiting, CSRF).
 *
 * Every endpoint starts with:  require __DIR__ . '/_bootstrap.php';
 *
 * Phase 0 note: CSRF tokens are deliberately deferred to Phase 3 per the
 * approved plan. Baseline protection comes from SameSite=Lax cookies, which
 * modern browsers enforce — cross-site POSTs cannot ride the session cookie.
 * ★ OTH-24 fix (iteration 25): the project's canonical PHP version
 *   statement is "PHP 7.3+ syntax-compatible; 8.1+ recommended for
 *   production; 8.3 target." The same wording is used in INSTALL-XAMPP.md,
 *   LOCAL-TESTING.md, DEPLOY-CPANEL.md, README.md, and PROJECT-ROADMAP.md
 *   so a reader diffing these docs against each other doesn't see
 *   contradictions. The hard minimum (7.3+) is the syntax the code
 *   targets (no arrow functions, no named args, no readonly props);
 *   8.1+ is recommended because it's the lowest XAMPP bundle we'd ship
 *   today and gets union types + enums for free if a future patch uses
 *   them; 8.3 is the active development target (current XAMPP at time
 *   of writing).
 *
 * Phase 3 (Motorcycle) additions:
 *   - rate_limit_check($bucket, $max, $window): DB-backed counter with inline
 *     GC. Returns void on allow, calls json_err() with 429 + Retry-After on
 *     exceed. Used by payments.php (public) and login.php (admin auth).
 *   - csrf_token(): lazily generates + returns $_SESSION['csrf_token'].
 *   - verify_csrf(): timing-safe (hash_equals) check of the X-CSRF-Token
 *     header. Called from every admin write endpoint (POST/PUT/DELETE).
 *   - client_ip(): REMOTE_ADDR only (no X-Forwarded-For — trusted-proxy
 *     handling behind Cloudflare/etc is a Phase 6 candidate, NOT Phase 4;
 *     Phase 4 is delivered and did not add it. See OTH-15 fix note below).
 */

// --- Output hygiene: notices must never corrupt JSON responses -------------
error_reporting(E_ALL);
ini_set('display_errors', '0');
ini_set('log_errors', '1');

// ★ SQLITE TIMEZONE FIX (2026-09-26): force PHP to UTC so all date()/strtotime()
//   calls produce timestamps that match SQLite's CURRENT_TIMESTAMP / datetime('now')
//   (both return UTC). Was: PHP used php.ini's timezone (often America/New_York
//   or Europe/London on cPanel) while SQLite is always UTC → the expiry check
//   in payments.php (`expires_at <= datetime('now')`), the rate-limit window in
//   _bootstrap::rate_limit_check (`created_at >= ?` with PHP-computed cutoff),
//   and the session-invalidation check in require_admin (`password_changed_at`
//   vs `$_SESSION['iat']`) were ALL off by the TZ offset on non-UTC hosts.
//   Fix: set PHP to UTC globally. This is a single-line fix that resolves
//   M1 + M2 + M3 from the SQLite scan. analytics.php already did this
//   locally (line 38) — now it's global.
date_default_timezone_set('UTC');

// Hide PHP version in the 'X-Powered-By' header (belt-and-braces — the
// root .htaccess also unsets it via mod_headers, but this covers hosts where
// mod_headers isn't available + the API responses specifically).
header_remove('X-Powered-By');

// --- Phase 4: load .env file (optional) --------------------------------------
// If a .env file exists at the project root, parse it and putenv() each line.
// This lets cPanel users (who often can't set real environment variables)
// configure secrets without editing _config.php. If no .env exists, this is
// a no-op — _config.php falls back to getenv() (which returns false for
// unset vars) and then to the hardcoded dev defaults.
//
// _env.php is a kernel file (blocked from direct web access by api/.htaccess
// via the leading-underscore FilesMatch rule — same convention as _config.php).
require_once __DIR__ . '/_env.php';

// --- Config: the ONLY file that ever requires _config.php is this kernel ----
// Endpoints require _bootstrap.php and nothing else (single-require contract).
require_once __DIR__ . '/_config.php';

// --- Uniform JSON responses -------------------------------------------------
function json_out(array $payload, int $status = 200): void {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($payload);
    exit;
}
function json_ok($data, int $status = 200): void {
    json_out(['ok' => true, 'data' => $data], $status);
}
function json_err(string $message, int $status = 400): void {
    json_out(['ok' => false, 'error' => $message], $status);
}

// --- Shared data contracts (single source of truth for all endpoints) -------
// Landing field -> max length. Mirrors the old LANDING_FIELDS in dashboard.js.
const LANDING_ALLOWED = [
    'hero_title'       => 100,
    'hero_subtitle'    => 200,
    'about_heading'    => 100,
    'about_text_1'     => 500,
    'about_text_2'     => 500,
    'featured_heading' => 100,
    'featured_sub'     => 200,
    'footer_text'      => 200,
];

const DEFAULT_CURRENCY = 'GHS';
const CURRENCY_KEY     = 'currency';
// Same rule as the old saveCurrency(): 1-5 chars, letters/currency symbols.
const CURRENCY_PATTERN = '/^[A-Za-z$\x{20A0}-\x{20CF}\x{00A2}-\x{00A5}]{1,5}$/u';

// Mirrors the JS slugify in ui-helpers.js (single behavior contract).
function slugify_server(string $text): string {
    $t = mb_strtolower(trim($text));
    $t = preg_replace('/[^a-z0-9\s-]/', '', $t);
    $t = preg_replace('/\s+/', '-', $t);
    $t = preg_replace('/-+/', '-', $t);
    return trim($t, '-');
}

// --- Session (httpOnly + SameSite=Lax; 'secure' auto-enabled on HTTPS) ------
// Phase 4: the 'secure' flag is now conditionally set based on whether the
// current request came in over HTTPS. This means:
//   - Local dev (HTTP): 'secure' = false → cookie is sent → session works
//   - Production (HTTPS): 'secure' = true → cookie is NOT sent over HTTP →
//     MITM can't sniff it.
// We detect HTTPS by checking $_SERVER['HTTPS'] (Apache) or the server port.
// ★ SEC-09 fix: was also checking X-Forwarded-Proto header — the OR
//   semantics meant the header was trusted on ANY port, not just 443. On
//   a host without a TLS-terminating proxy (XAMPP, misconfigured cPanel),
//   an attacker could send X-Forwarded-Proto: https over plain HTTP → the
//   session cookie was set with Secure=true over an HTTP response → modern
//   browsers rejected it → the admin couldn't log in (DoS).
//   Fix: drop the X-Forwarded-Proto check entirely. ★ OTH-15 fix (iteration 25):
//   the original audit recommendation was "drop the header check until Phase 4
//   adds trusted-proxy support" — but Phase 4 is delivered and did NOT add
//   trusted-proxy support (the SEC-09 fix IS the long-term answer; the X-Forwarded-*
//   headers are simply not trusted on cPanel shared hosting where there's no
//   known TLS-terminating proxy in front). If a trusted-proxy mechanism is
//   ever needed (e.g. behind Cloudflare), add an explicit TRUSTED_PROXIES
//   config that matches REMOTE_ADDR before
//   trusting the header.
$isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
    || (($_SERVER['SERVER_PORT'] ?? '') == 443);

session_set_cookie_params([
    'httponly' => true,
    'samesite' => 'Lax',
    'secure'   => $isHttps,  // ★ Phase 4: auto-enabled on HTTPS
]);
session_start();

// --- PDO (single lazy handle, real prepared statements) ----------------------
// ★ Iteration 48 (2026-09-25): switched from MySQL to SQLite. The DB is a
//   single file at DB_PATH (storage/morbi.sqlite). The pre-seeded file ships
//   inside the zip — no CREATE DATABASE, no DB user, no password. WAL mode
//   is enabled on every connection for concurrent-read + serialized-write
//   semantics (good enough for a single-store, low-traffic site + Paystack
//   webhook retries).
function db(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        // Ensure the storage/ directory exists. SQLite can't create the
        // file if the parent directory doesn't exist. mkdir is idempotent
        // (suppressed warnings) — if it's already there, no-op.
        $storageDir = dirname(DB_PATH);
        if (!is_dir($storageDir)) {
            @mkdir($storageDir, 0755, true);
        }
        if (!is_dir($storageDir) || !is_writable($storageDir)) {
            json_err('storage/ directory is missing or not writable. '
                . 'Check folder permissions and retry. Expected at: ' . $storageDir, 500);
        }
        // If the SQLite file doesn't exist, the pre-seeded file from the
        // zip didn't make it onto the server (or was deleted). Run the
        // installer as a safety net to rebuild it from scratch.
        // ★ RENAMED (2026-09-26): install.php → install.php. The safety-net
        //   require now checks file_exists first — if the user has deleted
        //   install.php after the initial install (as recommended for
        //   security), the safety-net returns a clear error instead of a
        //   fatal "require failed to open stream" error.
        if (!file_exists(DB_PATH)) {
            $installerPath = __DIR__ . '/install.php';
            if (file_exists($installerPath)) {
                require $installerPath;
                // install.php exits with json_ok/json_err (safety-net mode),
                // so we never get here.
                exit;
            }
            // install.php was deleted (post-install cleanup). Can't auto-rebuild.
            json_err(
                'Database file is missing (storage/morbi.sqlite not found) and '
                . 'api/install.php has been removed. Please re-upload the '
                . 'morbi.sqlite file from the original zip, or restore '
                . 'install.php to trigger a fresh install.',
                500
            );
        }
        $dsn = 'sqlite:' . DB_PATH;
        try {
            $pdo = new PDO($dsn, null, null, [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ]);
            // WAL mode = concurrent reads + serialized writes. Best for
            // web workloads. The setting persists in the DB file header
            // (pragma journal_mode is durable), but we re-apply it on
            // every connection to be safe across upgrades.
            $pdo->exec('PRAGMA journal_mode = WAL');
            // Foreign keys are OFF by default in SQLite — turn them ON
            // so the ON DELETE CASCADE constraints in the schema work.
            $pdo->exec('PRAGMA foreign_keys = ON');
            // Synchronous=NORMAL is the recommended setting for WAL —
            // fsyncs only at checkpoint, not every commit. Trade-off:
            // a power loss could lose the last few transactions (rare +
            // acceptable for an e-commerce site where Paystack webhooks
            // retry). FULL is safer but slower.
            $pdo->exec('PRAGMA synchronous = NORMAL');
            // 5-second busy timeout — if a write lock is held by another
            // request, wait up to 5s before returning SQLITE_BUSY.
            $pdo->exec('PRAGMA busy_timeout = 5000');
        } catch (PDOException $e) {
            json_err('Database connection failed: ' . $e->getMessage()
                . ' (DB path: ' . DB_PATH . ')', 500);
        }
    }
    return $pdo;
}

// --- Request body (JSON-only API) --------------------------------------------
function json_body(): array {
    $raw = file_get_contents('php://input');
    // ★ SEC-10 fix: enforce a hard 1 MB body-size cap BEFORE json_decode.
    //   Was: no cap — file_get_contents('php://input') reads the entire
    //   body into memory. PHP's post_max_size applies only to form-encoded
    //   bodies, NOT to php://input for Content-Type: application/json.
    //   An attacker could POST a 2 GB JSON body to exhaust PHP-FPM worker
    //   memory (OOM kill) → DoS. Fix: reject bodies > 1 MB with 413
    //   (Request Entity Too Large). 1 MB is generous for all legitimate
    //   API calls (the largest is import.php with a full backup JSON —
    //   typically < 100 KB for this store's size).
    if (strlen($raw) > 1048576) {
        json_err('Request body too large (max 1 MB).', 413);
    }
    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
}

// --- Auth guard ----------------------------------------------------------------
function is_admin(): bool {
    return !empty($_SESSION['admin_id']);
}

function require_admin(): void {
    if (!is_admin()) {
        json_err('Authentication required.', 401);
    }
    // ★ SEC-13 fix: check if the admin's password was changed AFTER this
    //   session was created. If so, the session is stale (the password was
    //   reset by someone else, or by this admin from another device) —
    //   force re-login by destroying the session + returning 401.
    //   The check uses the session's 'iat' (set at login time) compared
    //   to admin_users.password_changed_at (set at password reset time).
    //   If password_changed_at is NULL (pre-SEC-13 installs), the check
    //   is skipped (backward compat — the column is added by install.php
    //   idempotent ALTER for existing installs).
    if (!empty($_SESSION['admin_id']) && !empty($_SESSION['iat'])) {
        $stmt = db()->prepare('SELECT password_changed_at FROM admin_users WHERE id = ? LIMIT 1');
        $stmt->execute([$_SESSION['admin_id']]);
        $row = $stmt->fetch();
        if ($row && $row['password_changed_at'] !== null) {
            $pwChangedTs = strtotime((string)$row['password_changed_at']);
            $sessionIat = (int)$_SESSION['iat'];
            if ($pwChangedTs !== false && $pwChangedTs > $sessionIat) {
                // Password was changed after this session started → invalidate.
                $_SESSION = [];
                session_destroy();
                json_err('Session expired. Please log in again.', 401);
            }
        }
    }
    // ★ H5 fix (audit): when the DB row is missing (admin was deleted),
    //   destroy the session + return 401. The old code fell back to
    //   'super_admin' — escalating a deleted admin to full access.
    if (!isset($_SESSION['admin_role']) && !empty($_SESSION['admin_id'])) {
        $roleStmt = db()->prepare('SELECT role FROM admin_users WHERE id = ? LIMIT 1');
        $roleStmt->execute([$_SESSION['admin_id']]);
        $roleRow = $roleStmt->fetch();
        if (!$roleRow) {
            // Admin row doesn't exist — the session is stale (the admin was
            // deleted by another super_admin). Destroy + 401 instead of
            // escalating to super_admin.
            $_SESSION = [];
            session_destroy();
            json_err('Session invalid. Please log in again.', 401);
        }
        $_SESSION['admin_role'] = $roleRow['role'] ?? 'admin';
    }
}

/**
 * ★ Phase 8 Batch 2 (Task 59, 2026-09-23): role-based access control.
 *
 * Returns the current admin's role from the session. The role is loaded
 * lazily by require_admin() (see above) — so callers MUST call
 * require_admin() FIRST, then current_admin_role(). Calling this without
 * require_admin() returns 'super_admin' as a safe default (matches the
 * column default + the seeded admin), but that's a coding error — the
 * caller should always require_admin() first.
 *
 * @return string 'super_admin' | 'admin'
 */
function current_admin_role(): string {
    return $_SESSION['admin_role'] ?? 'super_admin';
}

/**
 * ★ Phase 8 Batch 2 (Task 59): gate an endpoint on a specific role.
 *
 * Usage:
 *   require_admin();              // authenticates the admin (401 if not logged in)
 *   require_role('super_admin');  // 403 if the admin's role is not super_admin
 *
 * The role check is exact-match (no hierarchy) — 'admin' is NOT a subset
 * of 'super_admin'. If a hierarchy is needed later, swap this for a
 * permission-based check (e.g., require_permission('manage_admins')).
 *
 * Returns void on success; calls json_err(403) on failure (which exits).
 *
 * @param string $role  the required role ('super_admin' or 'admin')
 */
function require_role(string $role): void {
    $current = current_admin_role();
    if ($current !== $role) {
        // Log the denial for audit — the admin's id + role + the required role.
        // Surface a generic 403 to the client (don't leak the role hierarchy).
        error_log('[morbi] 403: admin_id=' . ($_SESSION['admin_id'] ?? 0) .
            ' role=' . $current . ' required=' . $role);
        json_err('Permission denied. Your admin role does not allow this action.', 403);
    }
}

/**
 * ★ Phase 8 Batch 2 (Task 59): check if the current admin has a given role.
 * Returns true/false without exiting. Useful for conditional UI rendering
 * (e.g., the dashboard's Admins tab is only rendered if has_role('super_admin')).
 *
 * @param string $role  'super_admin' or 'admin'
 * @return bool
 */
function has_role(string $role): bool {
    return current_admin_role() === $role;
}

// --- Small shared validators (deliberately tiny; per-endpoint rules stay local)
function body_str(array $body, string $key, int $maxLen): ?string {
    if (!array_key_exists($key, $body)) return null;
    $v = is_scalar($body[$key]) ? trim((string)$body[$key]) : '';
    return ($v === '' ) ? '' : mb_substr($v, 0, $maxLen);
}

function to_bool($value, bool $default): bool {
    if (is_bool($value)) return $value;
    if (is_int($value) || is_float($value)) return $value !== 0;
    if (is_string($value)) {
        $t = strtolower(trim($value));
        if (in_array($t, ['1', 'true', 'on', 'yes'], true)) return true;
        if (in_array($t, ['0', 'false', 'off', 'no', ''], true)) return false;
    }
    return $default;
}

// ── Phase 3 (Motorcycle) — rate limiting ───────────────────────────────────
// DB-backed counter with inline GC. One row per attempt; the (bucket, created_at)
// index covers both the COUNT and DELETE WHERE clauses. No Redis/APCu dependency
// (cPanel shared hosting constraint).
//
// Buckets are arbitrary strings — callers compose them like "payments_init:1.2.3.4"
// or "login:morbi". The bucket is the unit of rate-limiting: anything sharing
// the same string shares the same counter. A single IP can be in multiple
// buckets simultaneously (e.g. login:1.2.3.4 AND login:morbi).
//
// On exceed: 429 Too Many Requests + Retry-After header (seconds remaining).
// json_err() exits, so callers don't need to check the return value.

function client_ip(): string {
    // Direct REMOTE_ADDR only. ★ OTH-15 fix (iteration 25): the comment
    //   used to say "Phase 4 may add trusted-proxy handling (X-Forwarded-For
    //   behind Cloudflare/nginx) — but only behind a known proxy." Phase 4
    //   is delivered and did NOT add trusted-proxy handling — the SEC-09 fix
    //   explicitly DROPPED the X-Forwarded-Proto check (an attacker could
    //   spoof it over plain HTTP to force the session cookie's Secure flag).
    //   The same risk applies to X-Forwarded-For: trusting the header by
    //   default would let any client spoof their IP and bypass per-IP rate
    //   limits. If a trusted-proxy mechanism is ever needed (e.g. behind
    //   Cloudflare), add an explicit TRUSTED_PROXIES config that matches
    //   REMOTE_ADDR before trusting the header. This is a Phase 6 (Super Car)
    //   candidate, NOT a pending Phase 4 deliverable.
    return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
}

function rate_limit_check(string $bucket, int $max, int $window_secs): void {
    $pdo = db();
    $cutoff = date('Y-m-d H:i:s', time() - $window_secs);

    // Inline GC: delete expired rows for THIS bucket only. Cheaper than a global
    // sweep and keeps the per-bucket check fast.
    // ★ PERF-10 fix (Task 45): the per-bucket delete alone left ABANDONED
    //   buckets (login:olduser, payments_init:1.2.3.4 from a customer who
    //   never returned, …) in the table FOREVER — the table grew unbounded
    //   (~240k rows for a 1,000-customer store over 2 years) and eventually
    //   slowed THIS endpoint's own COUNT(*) query on every login + checkout.
    //   No cleanup cron exists (and none can ship inside a PHP zip), so the
    //   sweep now runs opportunistically: ~1% of rate-limited requests also
    //   run a global DELETE of rows older than 24 h. Retention of one day is
    //   far longer than any window actually used (login/payments windows are
    //   minutes), so live counters are unaffected; on a busy site 1% of
    //   requests keeps the table at ~one day of rows, and on a quiet site the
    //   table is small anyway — the cost self-scales with traffic. Runs inside
    //   the same try/catch: a missing table (pre-Phase-3 install) still falls
    //   through to the allow-path below, unchanged.
    try {
        $del = $pdo->prepare('DELETE FROM rate_limit_log WHERE bucket = ? AND created_at < ?');
        $del->execute([$bucket, $cutoff]);

        if (random_int(1, 100) === 1) {
            $gc = $pdo->prepare('DELETE FROM rate_limit_log WHERE created_at < ?');
            $gc->execute([date('Y-m-d H:i:s', time() - 86400)]);
        }

        $stmt = $pdo->prepare('SELECT COUNT(*) FROM rate_limit_log WHERE bucket = ? AND created_at >= ?');
        $stmt->execute([$bucket, $cutoff]);
        $count = (int)$stmt->fetchColumn();
    } catch (PDOException $e) {
        // If the table doesn't exist yet (Phase 2 → Phase 3 upgrade where the
        // user hasn't run install.php), let the request through rather than
        // breaking the site. The CREATE TABLE is part of install.php + schema.sql.
        return;
    }

    if ($count >= $max) {
        // 429 + Retry-After hint (rounded up to whole seconds, min 1).
        $retry = max(1, $window_secs);
        header('Retry-After: ' . $retry);
        json_err('Too many attempts. Please try again in ' . ceil($window_secs / 60) . ' minute(s).', 429);
    }

    // Record this attempt. We do this AFTER the limit check so a blocked
    // request still counts (prevents an attacker from racing the check).
    try {
        $ins = $pdo->prepare('INSERT INTO rate_limit_log (bucket) VALUES (?)');
        $ins->execute([$bucket]);
    } catch (PDOException $e) {
        // Insert failures shouldn't break the request — they're a defensive
        // measure, not a correctness one. Log silently and continue.
    }
}

// ── Phase 3 (Motorcycle) — CSRF tokens ─────────────────────────────────────
// Per-session tokens, 32 random bytes hex. Stored in $_SESSION['csrf_token'];
// lazily generated on first read; rotated automatically when login.php calls
// session_regenerate_id(true) — because regenerate creates a new empty session
// array, csrf_token() will mint a fresh value on the next call.
//
// Frontend: store.js fetches the token from api/csrf.php on init() AND on
// login() (because the login response triggers a regenerate, invalidating the
// pre-login token). The api() helper auto-attaches X-CSRF-Token on every
// non-GET request. dashboard.js's uploadImage() (multipart, bypasses api())
// attaches the header manually via store.getCsrfToken().
//
// Exempt endpoints:
//   - payments.php: public, no session, defended by rate limiting + Paystack HMAC
//   - login.php:    pre-auth, by definition no session yet
//   - webhook.php:  Paystack HMAC-SHA512 is the auth, not the session
//   - install.php:  one-time installer, no session

function csrf_token(): string {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verify_csrf(): void {
    $sent = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
    $expected = $_SESSION['csrf_token'] ?? '';
    if ($sent === '' || $expected === '' || !hash_equals($expected, $sent)) {
        json_err('CSRF token missing or invalid. Please refresh the page and try again.', 403);
    }
}

// ── Phase 4: Security headers (PHP fallback) ──────────────────────────────
// The root .htaccess sets these via mod_headers (preferred — applies to ALL
// responses including static assets). This PHP fallback covers:
//   - Hosts where mod_headers isn't available (rare on cPanel, but possible)
//   - API responses specifically (belt-and-braces — if mod_headers IS
//     available, these header() calls are no-ops because Apache already set
//     them; if mod_headers is NOT available, these ensure API JSON responses
//     still get the headers).
//
// Note: static assets (CSS/JS/images) won't get these headers if mod_headers
// isn't available — that's a server-config issue the user must fix. The
// headers here protect the API (the highest-risk surface).
//
// HSTS (Strict-Transport-Security) is only sent over HTTPS — over HTTP it's
// ignored by browsers AND sending it would be a no-op anyway.
function set_security_headers(): void {
    // CSP — same policy as .htaccess. 'unsafe-inline' in style-src is needed
    // for the dynamic <style id="morbi-tokens"> block injected by app.js.
    header("Content-Security-Policy: default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; font-src 'self'; connect-src 'self'; frame-ancestors 'none'; object-src 'none'; base-uri 'self'; form-action 'self'");
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: DENY');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('Permissions-Policy: camera=(), microphone=(), geolocation=(), payment=()');
    header('X-XSS-Protection: 0');
    // HSTS only over HTTPS (sending it over HTTP is a no-op + some browsers warn).
    if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') {
        header('Strict-Transport-Security: max-age=31536000; includeSubDomains; preload');
    }
}

// Call immediately so every API response gets the headers. Endpoints that
// call json_ok/json_err exit() before these would be set IF we called them
// later — so we call them here, at the end of _bootstrap.php, before the
// endpoint handler runs. (header() before any output is the PHP rule;
// json_encode happens in the handlers, so we're safe.)
set_security_headers();
