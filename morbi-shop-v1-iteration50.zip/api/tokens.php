<?php
/**
 * tokens.php — design-token CMS endpoint (Phase 1, "Scooter").
 *
 * The black/gold theme used to be hardcoded in css/theme.css :root.
 * Phase 1 moves those CSS custom properties into site_settings so the
 * client can rebrand (colors) from the dashboard without touching code.
 *
 * Tokens are stored as one site_settings row per token, with the key
 * prefix `token_` (e.g. `token_bg_deep` -> CSS var `--bg-deep`).
 * Hardcoded values in theme.css stay as fallbacks: if the API is down
 * or a row is missing, theme.css :root still applies.
 *
 *   GET  public          -> { tokens: { bg_deep: "#000000", ... }, defaults: {...} }
 *   PUT  admin           -> body { tokens: { bg_deep: "#0a0a0a", ... } }
 *                          validates every value as a hex color (#RGB / #RRGGBB / #RRGGBBAA),
 *                          upserts each row. Unknown keys are rejected (422).
 *   POST admin {reset:1} -> clears every token_* row so theme.css defaults reapply.
 *
 * Token catalog (single source of truth — keep in sync with js/store.js
 * DEFAULT_TOKENS and css/theme.css :root):
 *   bg_deep, bg_mid, bg_card, accent, accent_strong, accent_hover,
 *   danger, muted, ok, border, green
 */

require __DIR__ . '/_bootstrap.php';

switch ($_SERVER['REQUEST_METHOD']) {
    case 'GET':  handle_get();  break;
    case 'PUT':  require_admin(); verify_csrf(); handle_put();  break;
    case 'POST': require_admin(); verify_csrf(); handle_post(); break;
    default:     json_err('Method not allowed.', 405);
}

/* ---- Catalog & defaults ---------------------------------------------------- */

// Keyed by token name (snake_case) -> [css_var, default_hex].
// Order is preserved for the dashboard editor (background tones first, accent
// greens/reds last). Mirrors the :root block order in theme.css.
const TOKEN_CATALOG = [
    'bg_deep'        => '#000000',
    'bg_mid'         => '#111111',
    'bg_card'        => '#1a1a1a',
    'accent'         => '#D4AF37',
    'accent_strong'  => '#C8A951',
    'accent_hover'   => '#E5C654',
    'danger'         => '#dc2626',
    'muted'          => '#a0a0a0',
    'ok'             => '#2D8B4E',
    'border'         => '#333333',
    'green'          => '#2D8B4E',
];

const TOKEN_KEY_PREFIX = 'token_';
// #RGB, #RGBA, #RRGGBB, #RRGGBBAA — covers every hex shape browsers parse
// for custom properties. Hex-only (no rgb()/hsl()) keeps the contract tight
// and avoids CSS injection vectors.
const TOKEN_HEX_RE = '/^#[0-9a-fA-F]{3,8}$/';

function token_setting_key(string $name): string {
    return TOKEN_KEY_PREFIX . $name;
}

function is_known_token(string $name): bool {
    return array_key_exists($name, TOKEN_CATALOG);
}

/* ---- GET ------------------------------------------------------------------- */
function handle_get(): void {
    // Pull every token_* row in one shot (one round-trip, no N+1).
    $stmt = db()->prepare(
        'SELECT setting_key, setting_value FROM site_settings WHERE setting_key LIKE ?'
    );
    $stmt->execute([TOKEN_KEY_PREFIX . '%']);
    $rows = $stmt->fetchAll();

    $stored = [];
    foreach ($rows as $r) {
        $name = substr($r['setting_key'], strlen(TOKEN_KEY_PREFIX));
        if (!is_known_token($name)) continue; // ignore orphan rows from older schema
        $stored[$name] = $r['setting_value'];
    }

    // Merge: stored value wins, otherwise fall back to the catalog default.
    $tokens = [];
    foreach (TOKEN_CATALOG as $name => $default) {
        $tokens[$name] = array_key_exists($name, $stored) ? $stored[$name] : $default;
    }

    json_ok([
        'tokens'    => $tokens,
        'defaults'  => TOKEN_CATALOG,
    ]);
}

/* ---- PUT (update individual tokens; patch-style) --------------------------- */
function handle_put(): void {
    $b = json_body();
    if (!array_key_exists('tokens', $b) || !is_array($b['tokens'])) {
        json_err('Body must be { tokens: { ... } }.', 422);
    }

    $patch = $b['tokens'];
    if (count($patch) === 0) json_err('No tokens provided.', 422);

    // Validate the whole patch first; never partially commit (atomic UX:
    // the dashboard flashes either "saved" or "X is not a valid hex color").
    $clean = [];
    foreach ($patch as $name => $value) {
        $name = (string)$name;
        if (!is_known_token($name)) {
            json_err('Unknown token: ' . $name, 422);
        }
        $hex = trim((string)$value);
        if (!preg_match(TOKEN_HEX_RE, $hex)) {
            json_err('Token ' . $name . ' must be a hex color (e.g. #1a1a1a).', 422);
        }
        $clean[$name] = $hex;
    }

    $stmt = db()->prepare(
        'INSERT INTO site_settings (setting_key, setting_value) VALUES (?, ?)
         ON CONFLICT(setting_key) DO UPDATE SET setting_value = excluded.setting_value'
    );
    foreach ($clean as $name => $hex) {
        $stmt->execute([token_setting_key($name), $hex]);
    }

    // Return the full merged set so the dashboard can refresh its form
    // without an extra round-trip.
    $tokens = [];
    foreach (TOKEN_CATALOG as $name => $default) {
        $tokens[$name] = array_key_exists($name, $clean) ? $clean[$name] : $default;
    }
    // Include any previously-stored tokens that weren't in this patch.
    $stmt = db()->prepare('SELECT setting_key, setting_value FROM site_settings WHERE setting_key LIKE ?');
    $stmt->execute([TOKEN_KEY_PREFIX . '%']);
    foreach ($stmt->fetchAll() as $r) {
        $name = substr($r['setting_key'], strlen(TOKEN_KEY_PREFIX));
        if (!is_known_token($name)) continue;
        if (!array_key_exists($name, $tokens)) $tokens[$name] = $r['setting_value'];
    }

    json_ok(['tokens' => $tokens, 'saved' => array_keys($clean)]);
}

/* ---- POST (reset to catalog defaults) -------------------------------------- */
function handle_post(): void {
    $b = json_body();
    $action = (string)($b['action'] ?? '');
    if ($action !== 'reset') {
        json_err('Unknown POST action. Use { action: "reset" } to restore defaults.', 422);
    }

    $stmt = db()->prepare('DELETE FROM site_settings WHERE setting_key LIKE ?');
    $stmt->execute([TOKEN_KEY_PREFIX . '%']);

    json_ok(['tokens' => TOKEN_CATALOG, 'reset' => true]);
}
