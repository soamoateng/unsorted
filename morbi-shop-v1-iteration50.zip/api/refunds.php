<?php
/**
 * refunds.php — ★ Phase 8 Batch 1 (Task 58, 2026-09-23) refund management.
 *
 * Server-side refund initiation against Paystack — replaces the previous
 * "do it manually on the Paystack dashboard" workflow for Morbi.
 *
 * Routes (all admin-only, CSRF-protected on writes):
 *   POST   ?action=initiate              -> initiate a full or partial refund
 *                                          body: { order_id, amount?, merchant_note?,
 *                                                  customer_note? }
 *                                          calls Paystack POST /refund, inserts a
 *                                          row in `refunds`, updates orders.refunded_amount
 *                                          + orders.paystack_status.
 *   GET    ?order_id=N                    -> list all refunds for an order (admin only)
 *   GET    ?id=N                          -> single refund detail (admin only)
 *   POST   ?action=refresh&id=N           -> re-fetch status from Paystack for a
 *                                            pending refund (admin only, CSRF)
 *
 * Refund semantics (verified live 2026-09-23 against
 * https://paystack.com/docs/refunds):
 *   - Full refund: omit `amount` from the body → Paystack refunds the full
 *     transaction amount.
 *   - Partial refund: include `amount` in MAJOR unit (decimal GHS). The
 *     server multiplies by 100 (subunit) before calling Paystack.
 *   - Multiple partial refunds are supported: each one is a separate ledger
 *     entry on Paystack's side, and a separate row in our `refunds` table.
 *   - Paystack's refund status starts as 'pending' and transitions to
 *     'processed' or 'failed' async. The refund.processed / refund.failed
 *     webhook events update the local row (see webhook.php).
 *
 * Amount validation:
 *   - For partial refunds, the requested amount + existing refunded_amount
 *     must not exceed total_amount. We check this BEFORE calling Paystack
 *     to avoid the "refund created, then we discover it over-refunds" race.
 *   - We use bccomp() for the decimal comparison (DECIMAL(10,2) arithmetic
 *     is exact in MySQL, but PHP's float math can drift on edge amounts
 *     like 0.1 + 0.2 = 0.30000000000000004).
 *
 * Order status transitions:
 *   - Before refund: paystack_status = 'paid'
 *   - After partial refund: paystack_status = 'partially_refunded'
 *   - After full refund (refunded_amount == total_amount): paystack_status = 'refunded'
 *   - Status is recomputed from the SUM of refund rows WHERE status IN
 *     ('pending','processing','processed') — 'failed' refunds don't count.
 *
 * Rate limiting: 5 refund initiations per minute per admin (separate from
 * the per-IP rate limit on orders.php verify). Refunds are an admin-only
 * operation so the bucket is per-admin, not per-IP.
 */

require __DIR__ . '/_bootstrap.php';
require_once __DIR__ . '/_paystack.php';
// ★ Phase 9 Batch 2 (Task 62): load _notifications.php for the
//   notify_customer_refund_processed() call after a refund succeeds.
require_once __DIR__ . '/_notifications.php';

switch ($_SERVER['REQUEST_METHOD']) {
    case 'GET':  require_admin(); handle_get();   break;
    case 'POST': require_admin(); verify_csrf(); handle_post(); break;
    default:     json_err('Method not allowed.', 405);
}

/* ---- GET router ---------------------------------------------------------- */
function handle_get(): void {
    $action = (string)($_GET['action'] ?? '');
    $orderId = (int)($_GET['order_id'] ?? 0);
    $id      = (int)($_GET['id'] ?? 0);

    // GET ?order_id=N → list refunds for an order.
    if ($orderId > 0) {
        handle_list_for_order($orderId);
        return;
    }

    // GET ?id=N → single refund detail.
    if ($id > 0) {
        handle_detail($id);
        return;
    }

    json_err('Provide order_id or id parameter.', 422);
}

/* ---- GET: list refunds for an order -------------------------------------- */
function handle_list_for_order(int $orderId): void {
    // Verify the order exists (404 if not).
    $order = fetch_order_by_id($orderId);
    if (!$order) json_err('Order not found.', 404);

    $stmt = db()->prepare(
        'SELECT r.*, u.username AS initiated_by_username
         FROM refunds r
         LEFT JOIN admin_users u ON u.id = r.initiated_by
         WHERE r.order_id = ?
         ORDER BY r.initiated_at DESC, r.id DESC'
    );
    $stmt->execute([$orderId]);
    $rows = $stmt->fetchAll();

    $refunds = array_map('map_refund', $rows);

    json_ok([
        'order_id'        => $orderId,
        'order_reference' => $order['reference'],
        'total_amount'    => (float)$order['total_amount'],
        'refunded_amount' => (float)($order['refunded_amount'] ?? 0),
        'refunds'         => $refunds,
        'count'           => count($refunds),
    ]);
}

/* ---- GET: single refund detail ------------------------------------------- */
function handle_detail(int $id): void {
    $stmt = db()->prepare(
        'SELECT r.*, u.username AS initiated_by_username, o.reference AS order_reference
         FROM refunds r
         LEFT JOIN admin_users u ON u.id = r.initiated_by
         LEFT JOIN orders o ON o.id = r.order_id
         WHERE r.id = ?
         LIMIT 1'
    );
    $stmt->execute([$id]);
    $row = $stmt->fetch();
    if (!$row) json_err('Refund not found.', 404);

    json_ok(['refund' => map_refund($row)]);
}

/* ---- POST router --------------------------------------------------------- */
function handle_post(): void {
    $action = (string)($_GET['action'] ?? '');
    if ($action === 'initiate') {
        handle_initiate();
        return;
    }
    if ($action === 'refresh') {
        handle_refresh();
        return;
    }
    json_err('Unknown action. Supported: initiate, refresh.', 422);
}

/* ---- POST: ?action=initiate ---------------------------------------------- */
function handle_initiate(): void {
    // Rate limit: 5 refund initiations per minute per admin.
    // Refunds are sensitive — an admin should not be able to bulk-refund
    // via the API. The bucket is per-admin (not per-IP) because refunds
    // are an admin-only action.
    $adminId = (int)($_SESSION['admin_id'] ?? 0);
    rate_limit_check('refund_initiate:admin:' . $adminId, 5, 60);

    $body = json_body();

    $orderId = (int)($body['order_id'] ?? 0);
    if ($orderId <= 0) json_err('order_id is required.', 422);

    // Fetch the order. Refuse if it doesn't exist OR is not in a refundable
    // state. Refundable: paystack_status = 'paid' (Paystack only allows
    // refunds on successful transactions). 'pending'/'failed'/'abandoned'/
    // 'deleted' orders cannot be refunded.
    $order = fetch_order_by_id($orderId);
    if (!$order) json_err('Order not found.', 404);
    if ($order['paystack_status'] !== 'paid'
        && $order['paystack_status'] !== 'partially_refunded'
        && $order['paystack_status'] !== 'refunded') {
        json_err(
            'Order is not in a refundable state (current status: ' .
            $order['paystack_status'] . '). Only paid / partially_refunded orders can be refunded.',
            422
        );
    }

    // ★ H2 fix (audit): optimistic locking to prevent concurrent refund
    //   initiations from both reading the same refunded_amount and over-refunding.
    //   The old code did a read-then-validate-then-Paystack-call pattern with
    //   no transaction — two admins simultaneously refunding the same order both
    //   read $alreadyRefund=0, both pass the bccomp check, both call Paystack.
    //   ★ SQLITE NOTE (2026-09-26) m6: was "use SELECT ... FOR UPDATE" —
    //   SQLite does NOT support FOR UPDATE (it's a MySQL/PostgreSQL clause).
    //   SQLite uses database-level write locks (one writer at a time via
    //   BEGIN IMMEDIATE). The pattern here is optimistic locking: read →
    //   validate → release lock → call Paystack (slow, outside the txn) →
    //   re-acquire lock → re-validate → commit. A concurrent refund that
    //   commits during the Paystack call changes $alreadyRefund; the re-
    //   validation catches the drift + refuses with a clear error.
    $pdo = db();
    $pdo->beginTransaction();
    try {
        $lockStmt = $pdo->prepare('SELECT * FROM orders WHERE id = ?');
        $lockStmt->execute([$orderId]);
        $order = $lockStmt->fetch();
        if (!$order) {
            $pdo->rollBack();
            json_err('Order not found.', 404);
        }

        $totalAmount   = (float)$order['total_amount'];
        $alreadyRefund = (float)($order['refunded_amount'] ?? 0);
        $remaining     = $totalAmount - $alreadyRefund;
        if ($remaining <= 0) {
            $pdo->rollBack();
            json_err('Order is already fully refunded. No remaining amount to refund.', 422);
        }

        // Parse amount. NULL or omitted → full refund of remaining balance.
        // Provided → partial refund. Validate that it doesn't exceed remaining.
        $amountInput = $body['amount'] ?? null;
        $isFullRefund = ($amountInput === null || $amountInput === '' || $amountInput === 0);
        if ($isFullRefund) {
            $refundAmount = $remaining;  // refund whatever's left
        } else {
            $refundAmount = (float)(string)$amountInput;
            if ($refundAmount <= 0) {
                $pdo->rollBack();
                json_err('Refund amount must be a positive number.', 422);
            }
            if (bccomp((string)$refundAmount, (string)$remaining, 2) === 1) {
                $pdo->rollBack();
                json_err(
                    'Refund amount (' . number_format($refundAmount, 2, '.', '') .
                    ') exceeds the refundable remaining balance (' .
                    number_format($remaining, 2, '.', '') . ').',
                    422
                );
            }
        }

        $merchantNote = body_str($body, 'merchant_note', 255);
        $customerNote = body_str($body, 'customer_note', 255);

        // Convert to subunit for Paystack. GHS uses pesewas (×100).
        $amountSubunit = (int)round($refundAmount * 100);

        $isOriginalFullRefund = $isFullRefund && $alreadyRefund == 0;
        $paystackAmount = $isOriginalFullRefund ? null : $amountSubunit;

        // ★ NEW-4 fix (audit): the original H2 fix called paystack_refund()
        //   INSIDE the DB transaction (holding the FOR UPDATE lock for up to
        //   30s during the Paystack API timeout). Now: we release the
        //   transaction before calling Paystack, then re-lock + re-validate
        //   when inserting the refund row. This is optimistic locking —
        //   we trust the Paystack call won't take long, but if a concurrent
        //   refund DID slip through, the re-validation catches it.
        $pdo->commit();  // release the FOR UPDATE lock — Paystack call is slow
        } catch (Throwable $e) {
            $pdo->rollBack();
            error_log('[morbi] Refund lock/validation failed: ' . $e->getMessage());
            json_err('Could not process refund. Check the server error log for details.', 500);
        }

        // Paystack call — OUTSIDE the DB transaction (no lock held during the
        // 30s API timeout). If Paystack fails, we haven't touched the DB.
        // ★ SQLITE FIX (2026-09-26) n3: initialize $paystackRefundId BEFORE
        //   the Paystack call so the catch handler below can reference it
        //   without an "Undefined variable" Warning on PHP 8.
        $paystackRefundId = null;
        $resp = paystack_refund(
            $order['reference'],
            $paystackAmount,
            $merchantNote,
            $customerNote
        );
        if (!$resp['ok']) {
            // ★ NEW-4 fix: no transaction is active at this point — just return error.
            json_err('Paystack declined the refund: ' . $resp['error'], 502);
        }

        $paystackRefundId = $resp['data']['refund_id'] ?? null;
        $paystackStatus   = $resp['data']['status'] ?? 'pending';

        // ★ SQLITE FIX (2026-09-26) M6: paystack_refund_id column is now
        //   NOT NULL (via migration). If Paystack's response omitted
        //   refund_id (rare — network blip, partial response, Paystack bug),
        //   the INSERT below would fail with a NOT NULL constraint violation.
        //   Refuse the refund at this point with a clear error — the admin
        //   should contact Paystack support to reconcile (the refund was
        //   created on Paystack's side but we can't record it locally
        //   without an ID). This is better than a 500 + a half-recorded state.
        if ($paystackRefundId === null || $paystackRefundId === '') {
            error_log('[morbi] Refund created on Paystack but no refund_id returned. '
                . 'Order: ' . $orderId . ', reference: ' . $order['reference']
                . '. Admin must reconcile manually via Paystack dashboard.');
            json_err(
                'Paystack created the refund but did not return a refund ID. '
                . 'The refund was initiated on Paystack — please check the Paystack dashboard '
                . 'and reconcile manually. Order reference: ' . $order['reference'],
                502
            );
        }

        // Re-acquire the lock + re-validate remaining balance (optimistic locking).
        // A concurrent refund may have changed $alreadyRefund while we were
        // calling Paystack. If so, the new refund might over-refund — re-check.
        $pdo->beginTransaction();
        try {
            $relockStmt = $pdo->prepare('SELECT refunded_amount, total_amount FROM orders WHERE id = ?');
            $relockStmt->execute([$orderId]);
            $relockedOrder = $relockStmt->fetch();
            if (!$relockedOrder) {
                $pdo->rollBack();
                json_err('Order not found (may have been deleted during refund).', 404);
            }
            $newAlreadyRefund = (float)($relockedOrder['refunded_amount'] ?? 0);
            $newTotalAmount = (float)$relockedOrder['total_amount'];
            $newRemaining = $newTotalAmount - $newAlreadyRefund;
            // ★ SQLITE FIX (2026-09-26) m4: was `if ($refundAmount > $newRemaining + 0.001)`
            //   — bare float comparison with 0.001 tolerance. Inconsistent with the
            //   pre-Paystack check at line ~213 which uses bccomp() with scale=2.
            //   Now uses bccomp for exactness (matches the file's own philosophy
            //   documented in the H2-fix comment block at lines 174-181).
            if (bccomp((string)$refundAmount, (string)$newRemaining, 2) === 1) {
                $pdo->rollBack();
                json_err(
                    'Refund amount (' . number_format($refundAmount, 2, '.', '') .
                    ') now exceeds the remaining balance (' .
                    number_format($newRemaining, 2, '.', '') . ') — a concurrent refund may have been processed. ' .
                    'The Paystack refund was created (id: ' . $paystackRefundId . ') — please reconcile manually.',
                    422
                );
            }
        $stmt = $pdo->prepare(
            // ★ Migration 2026-09-26: added `initiated_at` column to the INSERT
            //   (column was added by the schema migration but the INSERT didn't
            //   populate it → every new refund row had initiated_at=NULL, which
            //   broke the `ORDER BY r.initiated_at DESC` semantic). Now set
            //   to CURRENT_TIMESTAMP at insert time — matches the `created_at`
            //   default but is explicit so the audit trail is clear.
            'INSERT INTO refunds
               (order_id, paystack_refund_id, amount, currency, status,
                merchant_note, customer_note, initiated_by, initiated_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)'
        );
        $stmt->execute([
            $orderId,
            $paystackRefundId,
            $refundAmount,
            $order['currency'],
            $paystackStatus,
            $merchantNote,
            $customerNote,
            $adminId,
        ]);
        $refundId = (int)$pdo->lastInsertId();

        // Recompute orders.refunded_amount + paystack_status from the sum of
        // all non-failed refunds. This is the source of truth — even if a
        // previous refund's status changes via the webhook, this stays
        // correct on the next initiate.
        recompute_order_refund_state($orderId);

        $pdo->commit();
    } catch (Throwable $e) {
        $pdo->rollBack();
        error_log('[morbi] Refund insert failed after Paystack refund ' .
            $paystackRefundId . ' was created. Admin must reconcile manually. ' .
            'Error: ' . $e->getMessage());
        json_err(
            'Refund was created on Paystack (id: ' . $paystackRefundId . ') but the local ' .
            'database insert failed. Please reconcile manually via the Paystack dashboard ' .
            'and contact support.',
            500
        );
    }

    // Fetch the inserted row + the updated order for the response.
    $refund = fetch_refund_by_id($refundId);
    $updatedOrder = fetch_order_by_id($orderId);

    // ★ Phase 9 Batch 2 (Task 62): notify the customer that a refund was
    //   processed. Fire-and-forget — the refund was already created on
    //   Paystack + logged locally; an email failure doesn't roll it back.
    //   The notification is idempotent (UNIQUE KEY on type+order_id+refund_id)
    //   so the admin's "Refresh status" button (api/refunds.php?action=refresh)
    //   doesn't double-send.
    try {
        notify_customer_refund_processed($orderId, $refundId);
    } catch (Throwable $e) {
        error_log('[morbi] notify_customer_refund_processed threw for order ' .
            $orderId . ' refund ' . $refundId . ': ' . $e->getMessage());
    }

    json_ok([
        'refund' => map_refund($refund),
        'order'  => [
            'id'               => (int)$updatedOrder['id'],
            'reference'        => $updatedOrder['reference'],
            'paystack_status'  => $updatedOrder['paystack_status'],
            'total_amount'     => (float)$updatedOrder['total_amount'],
            'refunded_amount'  => (float)$updatedOrder['refunded_amount'],
        ],
    ]);
}

/* ---- POST: ?action=refresh&id=N ------------------------------------------- */
/* Re-fetches the refund status from Paystack. Useful when the webhook was
 * missed/delayed and the admin wants the latest status without waiting.
 * Calls Paystack GET /refund/{id} and updates the local row. */
function handle_refresh(): void {
    $id = (int)($_GET['id'] ?? 0);
    if ($id <= 0) json_err('id parameter is required for refresh.', 422);

    $refund = fetch_refund_by_id($id);
    if (!$refund) json_err('Refund not found.', 404);
    if (!$refund['paystack_refund_id']) {
        json_err('Refund has no Paystack ID — cannot refresh.', 422);
    }

    $resp = paystack_refund_status((int)$refund['paystack_refund_id']);
    if (!$resp['ok']) {
        json_err('Paystack did not return refund status: ' . $resp['error'], 502);
    }

    $newStatus    = $resp['data']['status'] ?? $refund['status'];
    $settledAt    = $resp['data']['settled_at'] ?? null;

    $pdo = db();
    $pdo->beginTransaction();
    try {
        $stmt = $pdo->prepare(
            'UPDATE refunds SET status = ?, settled_at = ? WHERE id = ?'
        );
        $stmt->execute([$newStatus, $settledAt, $id]);

        // If status changed to processed or failed, the order's
        // refunded_amount + paystack_status may need recompute.
        recompute_order_refund_state((int)$refund['order_id']);

        $pdo->commit();
    } catch (Throwable $e) {
        $pdo->rollBack();
        error_log('[morbi] Refund refresh failed: ' . $e->getMessage());
        json_err('Failed to update local refund row: ' . $e->getMessage(), 500);
    }

    $updated = fetch_refund_by_id($id);
    json_ok(['refund' => map_refund($updated)]);
}

/* ---- Helpers -------------------------------------------------------------- */
function fetch_order_by_id(int $id): ?array {
    $stmt = db()->prepare('SELECT * FROM orders WHERE id = ? LIMIT 1');
    $stmt->execute([$id]);
    $row = $stmt->fetch();
    return $row ?: null;
}

function fetch_refund_by_id(int $id): ?array {
    $stmt = db()->prepare(
        'SELECT r.*, u.username AS initiated_by_username, o.reference AS order_reference
         FROM refunds r
         LEFT JOIN admin_users u ON u.id = r.initiated_by
         LEFT JOIN orders o ON o.id = r.order_id
         WHERE r.id = ?
         LIMIT 1'
    );
    $stmt->execute([$id]);
    $row = $stmt->fetch();
    return $row ?: null;
}

/**
 * Recompute orders.refunded_amount + orders.paystack_status from the sum
 * of all non-failed refunds for the order. Called after every refund
 * insert AND after every webhook refund status update.
 *
 * Rules:
 *   - refunded_amount = SUM(amount) WHERE status IN ('pending','processing','processed')
 *     (failed refunds don't count toward the refunded total)
 *   - if refunded_amount >= total_amount → paystack_status = 'refunded'
 *   - if refunded_amount > 0 AND < total_amount → 'partially_refunded'
 *   - if refunded_amount == 0 (all refunds failed) → restore 'paid'
 *     (the order is no longer refunded at all)
 */
function recompute_order_refund_state(int $orderId): void {
    $pdo = db();

    $sumStmt = $pdo->prepare(
        "SELECT COALESCE(SUM(amount), 0) AS total
         FROM refunds
         WHERE order_id = ? AND status IN ('pending', 'processing', 'processed')"
    );
    $sumStmt->execute([$orderId]);
    $refundedAmount = (float)$sumStmt->fetchColumn();

    $orderStmt = $pdo->prepare('SELECT total_amount, paystack_status FROM orders WHERE id = ? LIMIT 1');
    $orderStmt->execute([$orderId]);
    $order = $orderStmt->fetch();
    if (!$order) return;

    $totalAmount = (float)$order['total_amount'];

    // Determine the new paystack_status. Preserve non-refund-related statuses
    // ('deleted' is never touched here; 'pending'/'failed'/'abandoned' orders
    // should never have refunds anyway because the initiate path blocks them).
    if (bccomp((string)$refundedAmount, (string)$totalAmount, 2) >= 0) {
        $newStatus = 'refunded';
    } elseif ($refundedAmount > 0) {
        $newStatus = 'partially_refunded';
    } else {
        // All refunds failed or none exist → restore 'paid' (the original
        // successful status before any refund was attempted).
        $newStatus = 'paid';
    }

    // ★ C3 fix (audit): guard against overwriting 'deleted' paystack_status.
    $updStmt = $pdo->prepare(
        "UPDATE orders SET refunded_amount = ?, paystack_status = ? WHERE id = ? AND paystack_status NOT IN ('deleted')"
    );
    $updStmt->execute([$refundedAmount, $newStatus, $orderId]);
}

/** Map a refund row to the JSON shape returned by every endpoint. */
function map_refund(array $r): array {
    return [
        'id'                    => (int)$r['id'],
        'order_id'              => (int)$r['order_id'],
        'order_reference'       => $r['order_reference'] ?? null,
        'paystack_refund_id'    => $r['paystack_refund_id'] !== null ? (int)$r['paystack_refund_id'] : null,
        'amount'                => (float)$r['amount'],
        'currency'              => $r['currency'],
        'status'                => $r['status'],
        'merchant_note'         => $r['merchant_note'],
        'customer_note'         => $r['customer_note'],
        'initiated_by'          => (int)$r['initiated_by'],
        'initiated_by_username' => $r['initiated_by_username'] ?? null,
        'initiated_at'          => $r['initiated_at'],
        'settled_at'            => $r['settled_at'],
    ];
}
