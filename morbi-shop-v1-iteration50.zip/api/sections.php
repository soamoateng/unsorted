<?php
/**
 * sections.php — Phase 6 Batch 1a: Landing Page Builder — sections CRUD.
 *
 *   GET    public                 -> { sections: [...] }
 *          (active + non-deleted, in sort_order)
 *   GET    admin  ?include_deleted=1
 *                                  -> { sections: [...], deleted_count: N }
 *          (active + non-deleted, OR all including deleted if include_deleted=1)
 *   POST   admin, JSON body        -> created section (201)
 *          { section_type, content, sort_order?, active? }
 *   PUT    admin, JSON body        -> updated section
 *          { id, content?, active?, sort_order? }  (patch-style — only
 *          the keys present are updated)
 *   DELETE admin  ?id=N            -> soft-delete (sets deleted_at = NOW())
 *   POST   admin  ?action=restore&id=N
 *                                  -> restore a soft-deleted section
 *
 * ── Section types + content shape (validated server-side — no free-form ──
 *    HTML ever, XSS-safe):
 *
 *   hero         { heading: str(100), subtitle: str(200) }
 *   about        { heading: str(100), paragraph_1: str(500), paragraph_2: str(500) }
 *   featured     { heading: str(100), subtitle: str(200) }
 *   footer       { text: str(200) }
 *   promo_banner { text: str(200), link_url?: str(200), accent_color?: str(7) }
 *   cta_block    { heading: str(100), body: str(500),
 *                  button_text: str(50), button_url: str(200) }
 *   image_spot   { image_path: str(255), caption?: str(150), link_url?: str(200) }
 *   text_block   { heading?: str(100), body: str(500) }
 *   spacer       { height: int 1..200 }
 *
 * The 4 base types (hero, about, featured, footer) are migrated from the
 * existing landing_content key-value rows by install.php (idempotent —
 * only runs if landing_sections is empty AND landing_content has the old
 * 8 keys). The 5 new types (promo_banner, cta_block, image_spot, text_block,
 * spacer) are addable by Morbi from the dashboard's new Sections tab
 * (Batch 1b).
 *
 * ── Security:
 *   * GET public path returns only active + non-deleted sections. Does NOT
 *     leak deleted_at, created_at, updated_at (those are admin-only fields).
 *   * All admin paths require the existing X-CSRF-Token header (verify_csrf
 *     from _bootstrap.php — same as every other admin write endpoint).
 *   * Content is validated per type before INSERT/UPDATE. Invalid shape → 422.
 *   * No free-form HTML is accepted anywhere — XSS-safe by construction.
 *   * Soft-delete preserves the audit trail (Morbi can restore from the
 *     dashboard's "show deleted" toggle). The DELETE endpoint sets
 *     `deleted_at = NOW()` and `active = 0`; it does NOT actually remove
 *     the row. The restore endpoint clears both.
 *   * Reorder via PUT with `sort_order` patch — the dashboard will use
 *     ↑/↓ buttons that send a new sort_order; the server accepts any
 *     positive integer and the dashboard's render sorts by sort_order ASC.
 *     No "shift others" logic server-side (the dashboard's UI is the only
 *     reorder caller and it manages the full list ordering).
 *
 * ── Backward compat:
 *   api/landing.php's GET path still returns the 8 key-value pairs the
 *   existing storefront expects, now rebuilt from the 4 base sections
 *   (hero, about, featured, footer). So the storefront renders byte-
 *   identically until the Batch 1c storefront rewrite. If a base section
 *   is missing (admin deleted it), the shim falls back to the value in
 *   landing_content (the old key-value table is preserved). If both are
 *   missing, falls back to the install-time defaults.
 */

require __DIR__ . '/_bootstrap.php';

switch ($_SERVER['REQUEST_METHOD']) {
    case 'GET':    handle_get();                                   break;
    case 'POST':   require_admin(); verify_csrf(); handle_post();   break;
    case 'PUT':    require_admin(); verify_csrf(); handle_put();    break;
    case 'DELETE': require_admin(); verify_csrf(); handle_delete(); break;
    default:       json_err('Method not allowed.', 405);
}

/* ── Section type catalog (single source of truth) ──────────────────────
 * The shape is enforced by validate_section_content() below. The catalog
 * is also referenced (via comments) in install.php's migration block +
 * will be referenced in the dashboard's Sections tab in Batch 1b.
 * ★ Feature 5: text_color + bg_color added to hero/about/featured/text_block/
 *   cta_block/promo_banner as optional_color_7 fields. Both are optional;
 *   when set, the landing renderers apply them as inline styles on the
 *   section wrapper (overriding the CSS defaults). When empty, the CSS
 *   defaults apply. */
const SECTION_TYPES = [
    'hero'         => ['heading' => 'required_str_100', 'subtitle' => 'required_str_200', 'text_color' => 'optional_color_7', 'bg_color' => 'optional_color_7'],
    'about'        => ['heading' => 'required_str_100', 'paragraph_1' => 'required_str_500', 'paragraph_2' => 'required_str_500', 'text_color' => 'optional_color_7', 'bg_color' => 'optional_color_7'],
    'featured'     => ['heading' => 'required_str_100', 'subtitle' => 'required_str_200', 'text_color' => 'optional_color_7', 'bg_color' => 'optional_color_7'],
    'footer'       => ['text'    => 'required_str_200'],
    'promo_banner' => ['text' => 'required_str_200', 'link_url' => 'optional_str_200', 'accent_color' => 'optional_color_7', 'text_color' => 'optional_color_7', 'bg_color' => 'optional_color_7'],
    'cta_block'    => ['heading' => 'required_str_100', 'body' => 'required_str_500', 'button_text' => 'required_str_50', 'button_url' => 'required_str_200', 'text_color' => 'optional_color_7', 'bg_color' => 'optional_color_7'],
    'image_spot'   => ['image_path' => 'required_str_255', 'caption' => 'optional_str_150', 'link_url' => 'optional_str_200'],
    'text_block'   => ['heading' => 'optional_str_100', 'body' => 'required_str_500', 'text_color' => 'optional_color_7', 'bg_color' => 'optional_color_7'],
    'spacer'       => ['height' => 'required_int_1_200'],
];

/* ── GET ------------------------------------------------------------------ */
function handle_get(): void {
    $includeDeleted = is_admin() && isset($_GET['include_deleted']) && $_GET['include_deleted'] === '1';

    // Public path: active + non-deleted. Admin path: same, OR all
    // (including deleted) if include_deleted=1.
    $sql = 'SELECT id, section_type, sort_order, content, active, deleted_at, created_at, updated_at
            FROM landing_sections';
    if (!$includeDeleted) {
        $sql .= ' WHERE active = 1 AND deleted_at IS NULL';
    }
    $sql .= ' ORDER BY sort_order ASC, id ASC';

    $rows = db()->query($sql)->fetchAll();
    $sections = array_map('map_section', $rows);

    $out = ['sections' => $sections];
    if ($includeDeleted) {
        $deletedCount = (int) db()->query('SELECT COUNT(*) FROM landing_sections WHERE deleted_at IS NOT NULL')->fetchColumn();
        $out['deleted_count'] = $deletedCount;
    }
    json_ok($out);
}

/* ── POST (create OR restore, routed by ?action= query param) ─────────── */
function handle_post(): void {
    // ?action=restore&id=N → restore a soft-deleted section. This runs
    // BEFORE the create handler so a body-less POST to ?action=restore
    // doesn't get treated as a "create with no section_type" 422.
    $action = (string)($_GET['action'] ?? '');
    if ($action === 'restore') {
        handle_post_restore();
        return;
    }
    // Default: create a new section.
    $b = json_body();
    $type = (string)($b['section_type'] ?? '');
    if (!isset(SECTION_TYPES[$type])) {
        json_err('Unknown section type. Valid types: ' . implode(', ', array_keys(SECTION_TYPES)) . '.', 422);
    }

    $content = $b['content'] ?? null;
    $validated = validate_section_content($type, $content);
    if ($validated['error'] !== null) {
        json_err($validated['error'], 422);
    }

    // sort_order: optional. Default = max+1 so the new section appears at
    // the end of the list (the dashboard's "Add Section" UI pattern).
    $sortOrder = isset($b['sort_order']) ? filter_var($b['sort_order'], FILTER_VALIDATE_INT) : null;
    if ($sortOrder === false || $sortOrder < 0) {
        // Compute max+1 server-side so the new section lands at the end
        // even if the dashboard didn't send a sort_order.
        $max = (int) db()->query('SELECT COALESCE(MAX(sort_order), -1) FROM landing_sections WHERE deleted_at IS NULL')->fetchColumn();
        $sortOrder = $max + 1;
    }
    // Cap sort_order at 9999 — defensive against runaway values; the
    // dashboard's ↑/↓ buttons never produce values this high.
    $sortOrder = min($sortOrder, 9999);

    // active: optional, default 1 (visible). The dashboard can toggle
    // this via PUT; on create it's almost always 1.
    $active = to_bool($b['active'] ?? true, true) ? 1 : 0;

    $stmt = db()->prepare(
        'INSERT INTO landing_sections (section_type, sort_order, content, active)
         VALUES (?, ?, ?, ?)'
    );
    $stmt->execute([
        $type,
        $sortOrder,
        json_encode($validated['content'], JSON_UNESCAPED_UNICODE),
        $active,
    ]);
    $newId = (int) db()->lastInsertId();

    // Fetch + return the created section (so the dashboard can render it
    // immediately without a separate GET).
    $row = fetch_section($newId);
    json_ok(['section' => map_section($row)], 201);
}

/* ── POST ?action=restore (restore a soft-deleted section) ────────────── */
function handle_post_restore(): void {
    $id = (int)($_GET['id'] ?? 0);
    if ($id <= 0) {
        json_err('Section id is required for restore.', 422);
    }
    $existing = fetch_section($id);
    if (!$existing) {
        json_err('Section not found.', 404);
    }
    // Idempotent: if already active, return success without re-stamping.
    if ($existing['deleted_at'] === null) {
        json_ok(['restored' => $id, 'already_active' => true]);
    }
    $stmt = db()->prepare('UPDATE landing_sections SET deleted_at = NULL, active = 1 WHERE id = ?');
    $stmt->execute([$id]);
    $row = fetch_section($id);
    json_ok(['restored' => $id, 'section' => map_section($row)]);
}

/* ── PUT (update — patch-style) ----------------------------------------- */
function handle_put(): void {
    $b = json_body();
    $id = (int)($b['id'] ?? 0);
    if ($id <= 0) {
        json_err('Section id is required.', 422);
    }
    $existing = fetch_section($id);
    if (!$existing) {
        json_err('Section not found.', 404);
    }
    // Refuse to update a soft-deleted section — the dashboard must restore
    // it first (so the audit trail stays clean: a deleted section's
    // content is frozen until restore).
    if ($existing['deleted_at'] !== null) {
        json_err('Section is deleted. Restore it first before editing.', 422);
    }

    // Patch-style: only the keys present in the body are updated.
    // section_type is NOT patchable — the type determines the content
    // shape, so changing the type would invalidate existing content.
    // (The dashboard's UI hides the type field on edit; to "change type"
    // Morbi deletes + creates a new section.)
    $sets = [];
    $params = [];
    $newContent = null;

    if (array_key_exists('content', $b)) {
        $validated = validate_section_content($existing['section_type'], $b['content']);
        if ($validated['error'] !== null) {
            json_err($validated['error'], 422);
        }
        $newContent = $validated['content'];
        $sets[] = 'content = ?';
        $params[] = json_encode($newContent, JSON_UNESCAPED_UNICODE);
    }
    if (array_key_exists('active', $b)) {
        $sets[] = 'active = ?';
        $params[] = to_bool($b['active'], true) ? 1 : 0;
    }
    if (array_key_exists('sort_order', $b)) {
        $so = filter_var($b['sort_order'], FILTER_VALIDATE_INT);
        if ($so === false || $so < 0) {
            json_err('sort_order must be a non-negative integer.', 422);
        }
        $sets[] = 'sort_order = ?';
        $params[] = min($so, 9999);
    }

    if (!$sets) {
        json_err('No valid fields to update (content, active, or sort_order).', 422);
    }

    $params[] = $id;
    $stmt = db()->prepare('UPDATE landing_sections SET ' . implode(', ', $sets) . ' WHERE id = ?');
    $stmt->execute($params);

    // Fetch + return the updated section.
    $row = fetch_section($id);
    json_ok(['section' => map_section($row)]);
}

/* ── DELETE (soft-delete) ----------------------------------------------- */
function handle_delete(): void {
    $id = (int)($_GET['id'] ?? 0);
    if ($id <= 0) {
        json_err('Section id is required.', 422);
    }
    $existing = fetch_section($id);
    if (!$existing) {
        json_err('Section not found.', 404);
    }
    // Idempotent: if already deleted, return success without re-stamping.
    if ($existing['deleted_at'] !== null) {
        json_ok(['deleted' => $id, 'already_deleted' => true]);
    }
    $stmt = db()->prepare('UPDATE landing_sections SET deleted_at = CURRENT_TIMESTAMP, active = 0 WHERE id = ?');
    $stmt->execute([$id]);
    json_ok(['deleted' => $id]);
}

/* ── Helpers ------------------------------------------------------------- */
function fetch_section(int $id): ?array {
    $stmt = db()->prepare('SELECT * FROM landing_sections WHERE id = ? LIMIT 1');
    $stmt->execute([$id]);
    $row = $stmt->fetch();
    return $row ?: null;
}

function map_section(array $r): array {
    // Decode content JSON. Older MySQL versions or pre-existing rows might
    // have content stored as a string (rare — install.php + sections.php
    // always use json_encode). Defend with json_decode + a string fallback.
    $content = json_decode((string)$r['content'], true);
    if (!is_array($content)) {
        $content = [];
    }
    return [
        'id'           => (int)$r['id'],
        'section_type' => $r['section_type'],
        'sort_order'   => (int)$r['sort_order'],
        'content'      => $content,
        'active'       => (bool)(int)$r['active'],
        // admin-only fields — included in the response shape so the
        // dashboard can show "deleted" badges + last-edited timestamps.
        // Public callers (no admin session) ignore these fields; the
        // public GET path doesn't return deleted rows anyway.
        'deleted_at'   => $r['deleted_at'],
        'created_at'   => $r['created_at'],
        'updated_at'   => $r['updated_at'],
    ];
}

/**
 * Validate a section's content against the type's expected shape.
 * Returns ['content' => validated_array, 'error' => string|null].
 * The content array is normalized: optional fields that weren't provided
 * are set to '' (so the dashboard's "patch-style" PUT doesn't accidentally
 * drop fields). Required fields that were missing → 422 error.
 */
function validate_section_content(string $type, $content): array {
    if (!is_array($content)) {
        return ['content' => null, 'error' => 'content must be a JSON object.'];
    }
    $shape = SECTION_TYPES[$type] ?? null;
    if ($shape === null) {
        return ['content' => null, 'error' => 'Unknown section type: ' . $type];
    }
    $out = [];
    foreach ($shape as $field => $rule) {
        $isOptional = (strpos($rule, 'optional_') === 0);
        $value = $content[$field] ?? null;

        if (!$isOptional && ($value === null || (is_string($value) && trim($value) === ''))) {
            return ['content' => null, 'error' => "Field '$field' is required for section type '$type'."];
        }

        if ($isOptional && $value === null) {
            $out[$field] = '';
            continue;
        }

        // Apply per-rule validation.
        $ruleCheck = check_rule($rule, $value);
        if ($ruleCheck['error'] !== null) {
            return ['content' => null, 'error' => "Field '$field': " . $ruleCheck['error']];
        }
        $out[$field] = $ruleCheck['value'];
    }
    return ['content' => $out, 'error' => null];
}

/**
 * Check a single field against its rule. Returns ['value' => normalized,
 * 'error' => string|null]. The rule string is one of:
 *   required_str_NNN  — required string, max NNN chars (after trim)
 *   optional_str_NNN  — optional string, max NNN chars
 *   optional_color_7  — optional hex color (#RRGGBB), exactly 7 chars
 *   required_int_LO_HI — required integer in [LO, HI] inclusive
 */
function check_rule(string $rule, $value): array {
    $isOptional = (strpos($rule, 'optional_') === 0);
    $trimmed = is_string($value) ? trim($value) : $value;

    if ($isOptional && ($value === '' || $value === null)) {
        return ['value' => '', 'error' => null];
    }

    if (preg_match('/^(?:required|optional)_str_(\d+)$/', $rule, $m)) {
        $maxLen = (int)$m[1];
        if (!is_string($value)) {
            return ['value' => null, 'error' => 'must be a string.'];
        }
        $v = trim($value);
        if (mb_strlen($v) > $maxLen) {
            return ['value' => null, 'error' => "max {$maxLen} characters allowed (got " . mb_strlen($v) . ")."];
        }
        return ['value' => $v, 'error' => null];
    }

    if ($rule === 'optional_color_7') {
        if (!is_string($value)) {
            return ['value' => null, 'error' => 'must be a string.'];
        }
        $v = trim($value);
        if ($v === '') {
            return ['value' => '', 'error' => null];
        }
        if (!preg_match('/^#[0-9a-fA-F]{6}$/', $v)) {
            return ['value' => null, 'error' => 'must be a 7-char hex color like #D4AF37.'];
        }
        return ['value' => $v, 'error' => null];
    }

    if (preg_match('/^required_int_(\d+)_(\d+)$/', $rule, $m)) {
        $lo = (int)$m[1];
        $hi = (int)$m[2];
        $iv = filter_var($value, FILTER_VALIDATE_INT);
        if ($iv === false) {
            return ['value' => null, 'error' => 'must be an integer.'];
        }
        if ($iv < $lo || $iv > $hi) {
            return ['value' => null, 'error' => "must be between {$lo} and {$hi}."];
        }
        return ['value' => $iv, 'error' => null];
    }

    return ['value' => null, 'error' => "unknown rule: $rule"];
}
