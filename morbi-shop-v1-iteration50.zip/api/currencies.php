<?php
/**
 * currencies.php — ★ Phase 8 Batch 3 (Task 60, 2026-09-23) multi-currency.
 *
 * CRUD endpoint for the currencies table. Public reads (the storefront
 * currency switcher); super_admin writes (managing exchange rates is an
 * admin-level task — an 'admin' role can sell in any currency but cannot
 * add new ones or edit rates).
 *
 * Routes:
 *   GET    (public)               -> list ACTIVE currencies for the storefront switcher
 *   GET    ?all=1    (admin)      -> list ALL currencies (including inactive)
 *   GET    ?code=XXX (public)     -> single currency detail
 *   POST              (super_admin, CSRF) -> create a new currency
 *   PUT               (super_admin, CSRF) -> update an existing currency's
 *                                            rate/symbol/name/active/paystack_supported
 *   DELETE ?id=N      (super_admin, CSRF) -> delete a currency
 *
 * Special guards:
 *   - The base currency (is_base=1, typically GHS) cannot be deleted or
 *     deactivated. The storefront needs at least one currency to display
 *     prices. The base currency's exchange_rate is always 1.0 and cannot
 *     be changed (it's the reference for all other rates).
 *   - is_base can only be set at CREATE time (and only on a fresh table
 *     with no base currency yet). Once set, is_base cannot be transferred
 *     via the API — that would require re-pricing every product, which is
 *     a manual migration. Use the reset-defaults flow + DB edit if you
 *     really need to change the base currency.
 *
 * Verified live 2026-09-23: Paystack supports these currency codes for
 * /transaction/initialize's `currency` parameter: NGN, GHS, KES, ZAR, USD.
 * The dashboard's "Add currency" form should offer these as suggestions
 * (the admin can add any ISO 4217 code, but only these 5 will actually
 * charge via Paystack).
 */

require __DIR__ . '/_bootstrap.php';

switch ($_SERVER['REQUEST_METHOD']) {
    case 'GET':  handle_get();   break;
    case 'POST': require_admin(); verify_csrf(); handle_create(); break;
    case 'PUT':  require_admin(); verify_csrf(); handle_update();  break;
    case 'DELETE': require_admin(); verify_csrf(); handle_delete(); break;
    default:     json_err('Method not allowed.', 405);
}

/* ---- GET router ---------------------------------------------------------- */
function handle_get(): void {
    $all  = (string)($_GET['all'] ?? '');
    $code = (string)($_GET['code'] ?? '');

    if ($code !== '') {
        handle_detail_by_code(strtoupper($code));
        return;
    }

    if ($all === '1') {
        // Admin-only — returns inactive currencies too.
        require_admin();
        handle_list_all();
        return;
    }

    // Default: public list of ACTIVE currencies only (for the storefront switcher).
    handle_list_active();
}

/* ---- GET: list active currencies (public) ------------------------------- */
function handle_list_active(): void {
    $stmt = db()->prepare(
        'SELECT id, code, name, symbol, exchange_rate, paystack_supported, is_base
         FROM currencies
         WHERE active = 1
         ORDER BY is_base DESC, code ASC'
    );
    $stmt->execute();
    $rows = $stmt->fetchAll();

    $currencies = array_map('map_currency_public', $rows);

    json_ok([
        'currencies' => $currencies,
        'count'      => count($currencies),
        // The base currency code is included so the frontend can compute
        // conversions correctly (exchange_rate is "1 base = X this").
        'base'       => get_base_currency_code(),
    ]);
}

/* ---- GET: list all currencies (admin) ----------------------------------- */
function handle_list_all(): void {
    $stmt = db()->prepare(
        'SELECT id, code, name, symbol, exchange_rate, paystack_supported, active, is_base, created_at, updated_at
         FROM currencies
         ORDER BY is_base DESC, code ASC'
    );
    $stmt->execute();
    $rows = $stmt->fetchAll();

    $currencies = array_map('map_currency_admin', $rows);

    json_ok([
        'currencies' => $currencies,
        'count'      => count($currencies),
        'base'       => get_base_currency_code(),
    ]);
}

/* ---- GET: single currency by code (public) ------------------------------ */
function handle_detail_by_code(string $code): void {
    $stmt = db()->prepare(
        'SELECT id, code, name, symbol, exchange_rate, paystack_supported, is_base
         FROM currencies
         WHERE code = ? AND active = 1
         LIMIT 1'
    );
    $stmt->execute([$code]);
    $row = $stmt->fetch();
    if (!$row) json_err('Currency not found.', 404);

    json_ok(['currency' => map_currency_public($row)]);
}

/* ---- POST: create (super_admin only) ------------------------------------ */
function handle_create(): void {
    require_role('super_admin');

    $body     = json_body();
    $code     = strtoupper(trim((string)($body['code'] ?? '')));
    $name     = trim((string)($body['name'] ?? ''));
    $symbol   = trim((string)($body['symbol'] ?? ''));
    $rate     = (float)($body['exchange_rate'] ?? 0);
    $paystack = !empty($body['paystack_supported']) ? 1 : 0;
    $active   = isset($body['active']) ? (!empty($body['active']) ? 1 : 0) : 1;

    // Validation
    if (!preg_match('/^[A-Z]{3}$/', $code)) {
        json_err('Currency code must be exactly 3 uppercase letters (ISO 4217).', 422);
    }
    if ($name === '' || mb_strlen($name) > 50) {
        json_err('Currency name is required (1-50 characters).', 422);
    }
    if ($symbol === '' || mb_strlen($symbol) > 10) {
        json_err('Currency symbol is required (1-10 characters).', 422);
    }
    if ($rate <= 0) {
        json_err('Exchange rate must be a positive number (1 base = N this currency).', 422);
    }

    // Check for duplicate code
    $stmt = db()->prepare('SELECT id FROM currencies WHERE code = ? LIMIT 1');
    $stmt->execute([$code]);
    if ($stmt->fetch()) {
        json_err('Currency code "' . $code . '" already exists.', 409);
    }

    // is_base can only be set if there is no base currency yet (fresh table
    // edge case — the seed already creates GHS as base, so this is rare).
    $isBase = !empty($body['is_base']) ? 1 : 0;
    if ($isBase) {
        $existingBase = db()->query("SELECT COUNT(*) FROM currencies WHERE is_base = 1")->fetchColumn();
        if ((int)$existingBase > 0) {
            json_err('A base currency already exists. Cannot create another.', 422);
        }
        // The base currency's exchange_rate MUST be 1.0 (it's the reference).
        $rate = 1.0;
    }

    $stmt = db()->prepare(
        'INSERT INTO currencies (code, name, symbol, exchange_rate, paystack_supported, active, is_base)
         VALUES (?, ?, ?, ?, ?, ?, ?)'
    );
    $stmt->execute([$code, $name, $symbol, $rate, $paystack, $active, $isBase]);
    $newId = (int)db()->lastInsertId();

    $new = fetch_currency_by_id($newId);
    json_ok(['currency' => map_currency_admin($new)], 201);
}

/* ---- PUT: update (super_admin only) ------------------------------------- */
function handle_update(): void {
    require_role('super_admin');

    $body = json_body();
    $code = strtoupper(trim((string)($body['code'] ?? '')));
    if ($code === '') {
        json_err('Currency code is required in the body.', 422);
    }

    $currency = fetch_currency_by_code($code);
    if (!$currency) json_err('Currency not found.', 404);

    $isBase = ((int)$currency['is_base'] === 1);

    // Build the SET clause from provided fields (patch-style).
    $sets = [];
    $params = [];

    if (array_key_exists('name', $body)) {
        $name = trim((string)$body['name']);
        if ($name === '' || mb_strlen($name) > 50) {
            json_err('Currency name must be 1-50 characters.', 422);
        }
        $sets[] = 'name = ?';
        $params[] = $name;
    }
    if (array_key_exists('symbol', $body)) {
        $symbol = trim((string)$body['symbol']);
        if ($symbol === '' || mb_strlen($symbol) > 10) {
            json_err('Currency symbol must be 1-10 characters.', 422);
        }
        $sets[] = 'symbol = ?';
        $params[] = $symbol;
    }
    if (array_key_exists('exchange_rate', $body)) {
        $rate = (float)$body['exchange_rate'];
        if ($isBase) {
            // The base currency's rate is ALWAYS 1.0 — it's the reference.
            // Ignore the provided value (don't error — let the dashboard
            // submit the same value back without special-casing).
            $rate = 1.0;
        } else {
            if ($rate <= 0) {
                json_err('Exchange rate must be a positive number.', 422);
            }
        }
        $sets[] = 'exchange_rate = ?';
        $params[] = $rate;
    }
    if (array_key_exists('paystack_supported', $body)) {
        $sets[] = 'paystack_supported = ?';
        $params[] = !empty($body['paystack_supported']) ? 1 : 0;
    }
    if (array_key_exists('active', $body)) {
        $active = !empty($body['active']) ? 1 : 0;
        // The base currency cannot be deactivated.
        if ($isBase && $active === 0) {
            json_err('The base currency cannot be deactivated. The storefront always needs at least one active currency.', 422);
        }
        $sets[] = 'active = ?';
        $params[] = $active;
    }
    // is_base is NOT editable via PUT — see the file header comment.

    if (empty($sets)) {
        json_err('No fields to update. Provide name, symbol, exchange_rate, paystack_supported, or active.', 422);
    }

    $params[] = $code;
    $stmt = db()->prepare('UPDATE currencies SET ' . implode(', ', $sets) . ' WHERE code = ?');
    $stmt->execute($params);

    $updated = fetch_currency_by_code($code);
    json_ok(['currency' => map_currency_admin($updated)]);
}

/* ---- DELETE: delete (super_admin only) ---------------------------------- */
function handle_delete(): void {
    require_role('super_admin');

    $id = (int)($_GET['id'] ?? 0);
    if ($id <= 0) json_err('id parameter is required for delete.', 422);

    $currency = fetch_currency_by_id($id);
    if (!$currency) json_err('Currency not found.', 404);

    // The base currency cannot be deleted.
    if ((int)$currency['is_base'] === 1) {
        json_err('The base currency cannot be deleted. The storefront always needs a base currency for price conversion.', 422);
    }

    // Soft check: warn if the currency has been used in orders (existing
    // orders with this currency code). We DON'T refuse the delete — the
    // historical order rows keep their currency column value even if the
    // currencies table row is gone. But we surface a count so the admin
    // knows the scope of the impact.
    $orderCount = 0;
    try {
        $stmt = db()->prepare('SELECT COUNT(*) FROM orders WHERE currency = ?');
        $stmt->execute([$currency['code']]);
        $orderCount = (int)$stmt->fetchColumn();
    } catch (Throwable $e) {
        // orders.currency column may not exist on very old installs — ignore.
    }

    $stmt = db()->prepare('DELETE FROM currencies WHERE id = ?');
    $stmt->execute([$id]);

    json_ok([
        'deleted'       => $id,
        'code'          => $currency['code'],
        'orders_using'  => $orderCount,
        'note'          => $orderCount > 0
            ? $orderCount . ' historical order(s) retain the "' . $currency['code'] . '" currency code in their records.'
            : null,
    ]);
}

/* ---- Helpers -------------------------------------------------------------- */
function fetch_currency_by_id(int $id): ?array {
    $stmt = db()->prepare(
        'SELECT id, code, name, symbol, exchange_rate, paystack_supported, active, is_base, created_at, updated_at
         FROM currencies WHERE id = ? LIMIT 1'
    );
    $stmt->execute([$id]);
    $row = $stmt->fetch();
    return $row ?: null;
}

function fetch_currency_by_code(string $code): ?array {
    $stmt = db()->prepare(
        'SELECT id, code, name, symbol, exchange_rate, paystack_supported, active, is_base, created_at, updated_at
         FROM currencies WHERE code = ? LIMIT 1'
    );
    $stmt->execute([$code]);
    $row = $stmt->fetch();
    return $row ?: null;
}

function get_base_currency_code(): string {
    $stmt = db()->prepare('SELECT code FROM currencies WHERE is_base = 1 LIMIT 1');
    $stmt->execute();
    $row = $stmt->fetch();
    return $row ? $row['code'] : 'GHS';
}

/** Public shape — no created_at/updated_at (not needed by the storefront). */
function map_currency_public(array $r): array {
    return [
        'id'                 => (int)$r['id'],
        'code'               => $r['code'],
        'name'               => $r['name'],
        'symbol'             => $r['symbol'],
        'exchange_rate'      => (float)$r['exchange_rate'],
        'paystack_supported' => (int)$r['paystack_supported'] === 1,
        'is_base'            => (int)$r['is_base'] === 1,
    ];
}

/** Admin shape — includes active flag + timestamps. */
function map_currency_admin(array $r): array {
    return [
        'id'                 => (int)$r['id'],
        'code'               => $r['code'],
        'name'               => $r['name'],
        'symbol'             => $r['symbol'],
        'exchange_rate'      => (float)$r['exchange_rate'],
        'paystack_supported' => (int)$r['paystack_supported'] === 1,
        'active'             => (int)$r['active'] === 1,
        'is_base'            => (int)$r['is_base'] === 1,
        'created_at'         => $r['created_at'] ?? null,
        'updated_at'         => $r['updated_at'] ?? null,
    ];
}
