<?php
/**
 * stock-alerts.php — ★ Phase 9 Batch 3 (Task 63, 2026-09-23) restock alerts.
 *
 *   POST  public {product_id, variant_id?, email}  -> {signed_up: true}
 *        Customer signup for an out-of-stock product/variant. When the
 *        admin restocks (api/products.php PUT changing stock from 0 to N>0),
 *        notify_stock_back() in _notifications.php emails every unnotified
 *        signup for that product/variant + marks notified_at.
 *
 *   GET   admin ?product_id=N  -> {alerts: [...], count}  (list signups for a product)
 *   GET   admin ?all=1          -> {alerts: [...], count}  (list ALL signups, newest first)
 *   DELETE admin ?id=N          -> {deleted: id}  (delete a single signup)
 *   DELETE admin ?product_id=N  -> {deleted_count: N}  (bulk delete all signups for a product)
 *
 * Security:
 *   * POST is public (no admin session) — customers don't have accounts.
 *     Anti-enumeration: always returns 200 {signed_up: true} even if the
 *     email is already on the list (INSERT IGNORE + rowCount detects
 *     duplicates silently). The customer can't tell whether they were the
 *     1st or 5th signup for the same product — same privacy stance as the
 *     forgot-password endpoint (deliberate).
 *   * Rate-limited 10/hour per IP — generous for a single customer signing
 *     up for multiple out-of-stock products, tight enough to prevent email
 *     list scraping (an attacker signing up garbage@domain.com for every
 *     product to enumerate the catalog's stock state).
 *   * Email validation: filter_var(FILTER_VALIDATE_EMAIL). Invalid emails
 *     get 422 (syntax error, not anti-enumeration — the customer typed
 *     something malformed + needs to fix it).
 *   * GET + DELETE are admin-only + CSRF-protected.
 *
 * Idempotency:
 *   The UNIQUE KEY uq_alerts_dedup (product_id, variant_id, customer_email)
 *   prevents duplicate signups. POST uses INSERT IGNORE + rowCount:
 *     - rowCount > 0: new signup inserted (returns 200 {signed_up: true, new: true})
 *     - rowCount = 0: duplicate (returns 200 {signed_up: true, new: false})
 *   The customer sees the same success message either way; the `new` field
 *   is for the frontend's UX (show "You're on the list!" vs "You're already
 *   on the list — we'll email you when it's back.").
 */

require __DIR__ . '/_bootstrap.php';

switch ($_SERVER['REQUEST_METHOD']) {
    case 'GET':    require_admin(); handle_get();    break;
    case 'POST':   handle_signup();                   break;
    case 'DELETE': require_admin(); verify_csrf(); handle_delete(); break;
    default:       json_err('Method not allowed.', 405);
}

/* ---- POST: customer signup (public) ------------------------------------- */
function handle_signup(): void {
    $body = json_body();

    $productId = (int)($body['product_id'] ?? 0);
    if ($productId <= 0) {
        json_err('product_id is required.', 422);
    }
    $variantId = isset($body['variant_id']) ? (int)$body['variant_id'] : 0;
    if ($variantId < 0) $variantId = 0;
    $email = trim((string)($body['email'] ?? ''));
    if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || mb_strlen($email) > 150) {
        json_err('A valid email address is required.', 422);
    }

    // Verify the product exists + is available (a hidden product shouldn't
    // accept restock signups — the customer got a stale link).
    $prodStmt = db()->prepare('SELECT id, stock FROM products WHERE id = ? LIMIT 1');
    $prodStmt->execute([$productId]);
    $product = $prodStmt->fetch();
    if (!$product) {
        json_err('Product not found.', 404);
    }
    // ★ L4 fix (audit): verify the product is actually out of stock before
    //   accepting a signup. The old code accepted signups for in-stock products
    //   too — the customer would never receive a restock email (the trigger
    //   requires going from 0/NULL → N>0). Wastes DB rows + confuses the customer.
    if ($product['stock'] !== null && (int)$product['stock'] > 0) {
        json_err('This product is already in stock — no restock alert needed.', 422);
    }

    // If a variant_id is provided, verify it belongs to the product.
    if ($variantId > 0) {
        $varStmt = db()->prepare('SELECT id FROM product_variants WHERE id = ? AND product_id = ? LIMIT 1');
        $varStmt->execute([$variantId, $productId]);
        if (!$varStmt->fetch()) {
            json_err('Invalid variant for this product.', 422);
        }
    }

    // Rate limit: 10 signups per hour per IP. Generous for a customer
    // signing up for multiple out-of-stock products, tight enough to
    // prevent email-list scraping.
    rate_limit_check('stock_alert_signup:' . client_ip(), 10, 3600);

    // INSERT OR IGNORE — the UNIQUE constraint catches duplicates.
    // rowCount() > 0 means a new row was inserted; = 0 means duplicate.
    $stmt = db()->prepare(
        'INSERT OR IGNORE INTO stock_alerts (product_id, variant_id, customer_email)
         VALUES (?, ?, ?)'
    );
    $stmt->execute([
        $productId,
        $variantId > 0 ? $variantId : null,
        $email,
    ]);
    $isNew = $stmt->rowCount() > 0;

    // Anti-enumeration: always return 200 + signed_up: true. The `new`
    // field lets the frontend show a slightly different message for
    // already-on-the-list customers, but the HTTP status is the same
    // so an attacker can't distinguish "new signup" from "duplicate".
    json_ok([
        'signed_up' => true,
        'new'       => $isNew,
        // Echo back the product_id so the frontend can confirm the right
        // signup form was submitted (defensive against double-submits).
        'product_id' => $productId,
        'variant_id' => $variantId > 0 ? $variantId : null,
    ]);
}

/* ---- GET: list signups (admin) ------------------------------------------- */
function handle_get(): void {
    $productId = (int)($_GET['product_id'] ?? 0);
    $all       = (string)($_GET['all'] ?? '');

    if ($all === '1') {
        // List all signups, newest first. Useful for the dashboard's
        // "Stock Alerts" view (future) — shows every customer waiting
        // across every product.
        $stmt = db()->prepare(
            'SELECT sa.id, sa.product_id, sa.variant_id, sa.customer_email,
                    sa.created_at, sa.notified_at,
                    p.name AS product_name,
                    pv.name AS variant_name
             FROM stock_alerts sa
             LEFT JOIN products p ON p.id = sa.product_id
             LEFT JOIN product_variants pv ON pv.id = sa.variant_id
             ORDER BY sa.created_at DESC, sa.id DESC'
        );
        $stmt->execute();
    } elseif ($productId > 0) {
        // List signups for a specific product.
        $stmt = db()->prepare(
            'SELECT sa.id, sa.product_id, sa.variant_id, sa.customer_email,
                    sa.created_at, sa.notified_at,
                    p.name AS product_name,
                    pv.name AS variant_name
             FROM stock_alerts sa
             LEFT JOIN products p ON p.id = sa.product_id
             LEFT JOIN product_variants pv ON pv.id = sa.variant_id
             WHERE sa.product_id = ?
             ORDER BY sa.created_at DESC, sa.id DESC'
        );
        $stmt->execute([$productId]);
    } else {
        json_err('Provide ?product_id=N or ?all=1 parameter.', 422);
    }

    $rows = $stmt->fetchAll();
    $alerts = array_map(function ($r) {
        return [
            'id'              => (int)$r['id'],
            'product_id'      => (int)$r['product_id'],
            'product_name'    => (string)($r['product_name'] ?? ''),
            'variant_id'      => $r['variant_id'] !== null ? (int)$r['variant_id'] : null,
            'variant_name'    => $r['variant_name'] !== null ? (string)$r['variant_name'] : null,
            'customer_email'  => (string)$r['customer_email'],
            'created_at'      => (string)$r['created_at'],
            'notified_at'     => $r['notified_at'] !== null ? (string)$r['notified_at'] : null,
        ];
    }, $rows);

    json_ok(['alerts' => $alerts, 'count' => count($alerts)]);
}

/* ---- DELETE: remove signup(s) (admin) ----------------------------------- */
function handle_delete(): void {
    $id        = (int)($_GET['id'] ?? 0);
    $productId = (int)($_GET['product_id'] ?? 0);

    if ($id > 0) {
        // Single-signup delete.
        $stmt = db()->prepare('DELETE FROM stock_alerts WHERE id = ?');
        $stmt->execute([$id]);
        if ($stmt->rowCount() === 0) {
            json_err('Stock alert signup not found.', 404);
        }
        json_ok(['deleted' => $id]);
    }

    if ($productId > 0) {
        // Bulk delete all signups for a product (e.g., the admin is
        // discontinuing the product + wants to clean up the waitlist).
        $stmt = db()->prepare('DELETE FROM stock_alerts WHERE product_id = ?');
        $stmt->execute([$productId]);
        $count = $stmt->rowCount();
        json_ok(['deleted_count' => $count, 'product_id' => $productId]);
    }

    json_err('Provide ?id=N (single) or ?product_id=N (bulk) parameter.', 422);
}
