<?php
/**
 * payments.php — Phase 2 (Bicycle) order creation + Paystack init.
 *
 *   POST  public { name, phone, email?, items: [{id, qty}, ...] }
 *         -> { reference, authorization_url, amount }
 *
 * Flow:
 *   1. Validate customer fields (name min 2, phone matches Ghana MoMo regex,
 *      email if provided must be a valid email).
 *   2. Validate cart: at least 1 item; every product id exists and is available;
 *      qty 1..99 (matches storefront MAX_QTY).
 *   3. Compute the total from the DATABASE product prices — NEVER trust the
 *      client total. Snapshots the product name/scent/price/image_path into
 *      order_items so the historical record is preserved.
 *   4. Create the orders row (status='pending') + order_items rows in ONE
 *      transaction. The reference is generated server-side and passed to
 *      Paystack.
 *   5. Call Paystack /transaction/initialize via _paystack.php.
 *   6. On success: return { reference, authorization_url, amount } so the
 *      client can redirect.
 *      On failure: mark the order status='failed', return 502 with the
 *      Paystack error message. The customer can retry — a new order row
 *      is created each time (the failed one stays in the DB for audit).
 *
 * Security:
 *   * No auth guard — this is the public checkout. Phase 3 adds DB-backed
 *     rate limiting (per-IP bucket, 5 attempts / 5 min — see _bootstrap::
 *     rate_limit_check()). The check is placed AFTER the cheap input
 *     validation (cart shape, customer fields) and BEFORE the DB read +
 *     Paystack init, so a malicious actor spamming invalid payloads gets
 *     422s without ticking the rate-limit counter — but the moment they
 *     send a payload valid enough to trigger a Paystack round-trip, the
 *     counter starts.
 *   * The Paystack secret key never appears in the response (it lives in
 *     _config.php and is used only by _paystack.php).
 *   * Cart total is computed server-side from DB prices — a tampered cart
 *     that claims GHS 1 for a GHS 180 product will be corrected to GHS 180
 *     before the order is created.
 *   * ★ Phase 3 Batch 4: stock check. Products with stock !== NULL
 *     (inventory tracked) are checked for availability — if stock < qty,
 *     the order is refused with 422. NULL stock = unlimited (backward
 *     compat for Phase 0-3 installs). Stock is decremented only when the
 *     order transitions to 'paid' (in webhook.php + orders.php verify),
 *     NOT at order creation (because a 'pending' order hasn't been paid yet).
 */

require __DIR__ . '/_bootstrap.php';
require_once __DIR__ . '/_paystack.php';
// ★ Phase 9 Batch 2 (Task 62): load _notifications.php for the
//   notify_admin_new_order() call after Paystack init succeeds.
require_once __DIR__ . '/_notifications.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_err('POST only.', 405);
}

$b = json_body();
if (!$b) json_err('Empty or malformed JSON body.', 422);

/* ---- 1. Validate customer fields ------------------------------------------- */
$name = trim((string)($b['name'] ?? ''));
if (mb_strlen($name) < 2 || mb_strlen($name) > 100) {
    json_err('Full name is required (2–100 characters).', 422);
}

$phone = trim((string)($b['phone'] ?? ''));
// Same regex as storefront.js validateCheckout + PROJECT-ROADMAP §1.
if (!preg_match('/^(\+?233|0)[2-9]\d{8}$/', $phone)) {
    json_err('Enter a valid Ghana phone number (e.g. 233XXXXXXXXX).', 422);
}

$email = '';
if (!empty($b['email'])) {
    $email = trim((string)$b['email']);
    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || mb_strlen($email) > 150) {
        json_err('Enter a valid email address.', 422);
    }
}
// Paystack REQUIRES an email field on /transaction/initialize. For MoMo-only
// orders where the customer didn't provide one, we pass a synthetic address
// — the customer never sees it, and it doesn't affect the MoMo flow. This
// is the documented Paystack pattern for MoMo-heavy merchants.
$paystackEmail = $email !== '' ? $email : preg_replace('/[^0-9+]/', '', $phone) . '@morbi.shop';

/* ---- 2. Validate cart ----------------------------------------------------- */
$items = $b['items'] ?? null;
if (!is_array($items) || count($items) === 0) {
    json_err('Cart is empty.', 422);
}

/* ---- 2b. Rate limiting (Phase 3) ----------------------------------------- *
 * Placed AFTER cheap input validation (cart shape, customer fields) but
 * BEFORE the DB read + Paystack init. A spam-init script sending 1000
 * garbage payloads/sec gets 422s without ticking the counter — but the
 * moment it sends a payload valid enough to trigger a Paystack round-trip,
 * the counter starts. After 5 in 5 min: 429 + Retry-After.
 *
 * Bucket key includes the IP only (no customer info — the customer is not
 * authenticated, so we can't tie them to anything more durable than the
 * source IP). A determined attacker rotating IPs still gets one Paystack
 * round-trip per IP before being throttled — Paystack itself rate-limits
 * at their end too. */
rate_limit_check('payments_init:' . client_ip(), RATE_LIMIT_PAYMENTS_MAX, RATE_LIMIT_PAYMENTS_WINDOW);

// Pull every product id from the DB so we validate availability + compute
// the total from the SOURCE OF TRUTH (DB prices), not from the client body.
$ids = [];
foreach ($items as $it) {
    if (!is_array($it) || !isset($it['id'])) continue;
    $ids[] = (int)$it['id'];
}
$ids = array_unique($ids);
if (count($ids) === 0) json_err('Cart has no valid product ids.', 422);

$placeholders = implode(',', array_fill(0, count($ids), '?'));
// ★ PERF-02 note (Task 45): this stays SELECT * deliberately.
//   1. The row count is bounded by the CART (a handful of products), not the
//      catalog — the audit's payload concern targets the LIST endpoint
//      (products.php), which was converted to an explicit column list there.
//   2. RT-09's upgrade-drift contract depends on SELECT *: on a schema that
//      predates the stock/scent_category columns, an explicit column list
//      would throw SQLSTATE 42S22 and kill checkout entirely, while SELECT *
//      simply omits the column and the `$p['stock'] ?? null` guards below
//      treat it as unlimited (the documented Phase-2-upgrade behavior).
$stmt = db()->prepare("SELECT * FROM products WHERE id IN ($placeholders)");
$stmt->execute(array_map('intval', $ids));
$productsById = [];
foreach ($stmt->fetchAll() as $row) {
    $productsById[(int)$row['id']] = $row;
}

// Build the normalized item list (only available products; qty clamped 1..99).
// ★ Phase 3 Batch 4: if a product has stock !== NULL (inventory tracked),
// reject the order if stock < qty. This prevents overselling. NULL stock =
// unlimited (no tracking) — backward compat for Phase 0-3 installs.
// ★ Phase 5 Batch 3: if a variantId is provided, look up the variant in
// product_variants and use the VARIANT price (from DB, never client) + the
// variant name in the snapshot. If no variantId, use the product price (backward compat).
// ★ H3 fix (audit): aggregate qty per product_id BEFORE the stock check.
//   A cart with [{id:1,qty:8},{id:1,qty:7}] for stock=10 passed both
//   individual checks (8<10, 7<10) but the total 15 exceeded stock.
$cleanItems = [];
$totalGhs = 0.0;
// ★ H3 fix (audit): aggregate qty per (product_id, variant_id) BEFORE the stock check.
//   A cart with [{id:1,qty:8},{id:1,qty:7}] for stock=10 passed both
//   individual checks (8<10, 7<10) but the total 15 exceeded stock.
// ★ NEW-2 fix (audit): the original H3 fix used only product_id as the key,
//   which broke variant-level stock: if product 1 has variant A (stock=3)
//   and variant B (stock=3), and the cart has [{id:1,variantId:A,qty:3},
//   {id:1,variantId:B,qty:3}], the aggregate (6) was checked against
//   variant A's stock (3) → falsely rejected. Now: key by product_id:variant_id.
$aggQtyByKey = [];  // "pid:vid" → total qty
foreach ($items as $it) {
    if (!is_array($it) || !isset($it['id'])) continue;
    $pid = (int)$it['id'];
    if (!isset($productsById[$pid])) continue;
    $p = $productsById[$pid];
    if ((int)$p['available'] !== 1) continue;            // skip hidden products
    $qty = (int)($it['qty'] ?? 1);
    if ($qty < 1) $qty = 1;
    if ($qty > 99) $qty = 99;                              // storefront MAX_QTY

    // ★ H3 fix: track the aggregate qty per (product_id, variant_id)
    // ★ NEW-2 fix: use composite key "pid:vid" so variant stock checks
    //   use variant-level aggregate, not product-level.
    $variantId = isset($it['variantId']) ? (int)$it['variantId'] : 0;
    $aggKey = $pid . ':' . $variantId;
    if (!isset($aggQtyByKey[$aggKey])) $aggQtyByKey[$aggKey] = 0;
    $aggQtyByKey[$aggKey] += $qty;

    // ★ Phase 5 Batch 3: variant lookup.
    $variantId = isset($it['variantId']) ? (int)$it['variantId'] : 0;
    $variantName = '';
    $itemPrice = (float)$p['price'];
    // ★ BL-14 fix: $stockToCheck is initialized to the PRODUCT's stock.
    //   The previous code overwrote this with $variant['stock']
    //   unconditionally when a variant was selected — including when
    //   $variant['stock'] was NULL (the "unlimited" convention). That
    //   silently made the variant unlimited even if the parent product
    //   had stock=5 (the comment said "variant-level stock overrides
    //   product-level", but the practical effect was that any variant
    //   created without an explicit stock value bypassed the parent's
    //   inventory cap entirely).
    //
    //   Fix: only override $stockToCheck when the variant has an explicit
    //   non-NULL stock. If variant.stock IS NULL, fall back to the
    //   product's stock (which may itself be NULL = unlimited). This
    //   matches the audit's recommendation: variant.stock ?? product.stock
    //   (NULL variant falls back to product, NULL product means unlimited).
    //
    //   Blind-spot fix (parallel): the decrement loop in webhook.php +
    //   orders.php must mirror this — when variant.stock IS NULL and the
    //   check fell back to product.stock, the decrement must ALSO fall
    //   back to decrementing product.stock (otherwise product.stock is
    //   checked-but-never-decremented → over time multiple orders all
    //   see "5 in stock" even after 5 sales). See the BL-14 BLIND-SPOT
    //   comments in webhook.php + orders.php's decrement loops.
    // ★ RT-09 fix: use null-coalescing (`??`) instead of bare `$p['stock']`
    //   to suppress the PHP 8 "Undefined array key" Warning on pre-Phase-3
    //   installs where the `stock` column doesn't exist yet (the admin
    //   upgraded the codebase from Phase 2 to Phase 3+ WITHOUT re-running
    //   api/install.php). On such installs, `SELECT * FROM products` doesn't
    //   include `stock` — `$p['stock']` is an undefined key. The `??`
    //   operator returns `null` without a Warning, the `if ($stockToCheck
    //   !== null)` check skips → checkout proceeds (treats the product as
    //   unlimited — correct for pre-Phase-3 installs).
    $stockToCheck = $p['stock'] ?? null;

    if ($variantId > 0) {
        // ★ RT-09 fix: wrap the variant lookup in a try/catch. If the
        //   `product_variants` table doesn't exist (pre-Phase-5 installs
        //   where the admin upgraded from Phase 2/3/4 to Phase 5+ WITHOUT
        //   re-running api/install.php), `execute()` throws
        //   `PDOException: SQLSTATE[42S02]: Table doesn't exist`. Without
        //   this catch, the exception propagates to the top-level switch
        //   (no try/catch) → PHP's default exception handler prints an HTML
        //   stack trace → the JSON response is corrupted → the customer sees
        //   "Payment init failed (HTTP 500)" and can't checkout.
        //   Fix: catch PDOException + return 422 "Invalid variant" (same
        //   response as a non-existent variant — the customer can retry
        //   without a variantId, or the admin re-runs install.php to create
        //   the table).
        try {
            // ★ Migration 2026-09-26: was `SELECT id, name, price, stock, available
            //   FROM product_variants` — the actual schema has `price_delta` (legacy)
            //   plus the new `price` column added by this migration. `available` and
            //   `sort_order` were also added by this migration. The code reads
            //   `$variant['price']` and `$variant['available']` so both must be present.
            $vStmt = db()->prepare(
                'SELECT id, name, price, stock, available
                 FROM product_variants
                 WHERE id = ? AND product_id = ?
                 LIMIT 1'
            );
            $vStmt->execute([$variantId, $pid]);
            $variant = $vStmt->fetch();
        } catch (PDOException $e) {
            json_err('Invalid variant for product "' . $p['name'] . '".', 422);
        }
        if (!$variant) {
            json_err('Invalid variant for product "' . $p['name'] . '".', 422);
        }
        if ((int)$variant['available'] !== 1) {
            json_err('Variant "' . $variant['name'] . '" is not available.', 422);
        }
        $variantName = (string)$variant['name'];
        $itemPrice = (float)$variant['price'];
        // ★ BL-14 fix: only override $stockToCheck when the variant has an
        //   EXPLICIT non-NULL stock. NULL variant falls back to the parent
        //   product's stock (already in $stockToCheck from line above).
        if ($variant['stock'] !== null) {
            $stockToCheck = $variant['stock'];
        }
    }

    // ★ Phase 3 Batch 4: stock check (now uses variant stock if applicable).
    // ★ H3 fix (audit): check the AGGREGATE qty against stock.
    // ★ NEW-2 fix: use the (pid:vid) key, not just pid — variant stock
    //   should be checked against the variant-level aggregate.
    if ($stockToCheck !== null) {
        $availableStock = (int)$stockToCheck;
        $checkKey = $pid . ':' . $variantId;
        $totalQty = $aggQtyByKey[$checkKey] ?? $qty;
        if ($availableStock <= 0) {
            json_err('"' . $p['name'] . ($variantName ? ' (' . $variantName . ')' : '') . '" is out of stock.', 422);
        }
        if ($availableStock < $totalQty) {
            json_err('Only ' . $availableStock . ' of "' . $p['name'] . ($variantName ? ' (' . $variantName . ')' : '') . '" are in stock (you requested ' . $totalQty . ').', 422);
        }
    }
    $cleanItems[] = [
        'product_id' => $pid,
        'variant_id' => $variantId > 0 ? $variantId : null,  // ★ BL-01 fix: persist variant_id so the decrement loop can drain variant stock
        'name'       => $p['name'],
        'scent'      => (string)($p['scent'] ?? ''),
        'price'      => $itemPrice,
        'qty'        => $qty,
        'image_path' => (string)($p['image_path'] ?? ''),
        'variant'    => $variantName,
    ];
    $totalGhs += $itemPrice * $qty;
}

if (count($cleanItems) === 0) {
    json_err('Cart has no available products.', 422);
}

// Paystack minimum transaction in Ghana is GHS 1.00 (100 kobo). Below that
// Paystack rejects the init. We surface a friendly error here.
if ($totalGhs < 1.0) {
    json_err('Order total is below the Paystack minimum (GHS 1.00).', 422);
}

// Round to 2 dp.
$totalGhs = round($totalGhs, 2);

/* ---- 2c. Apply discount code (Phase 5 Batch 2) ------------------------- *
 * If the customer provided a discountCode, validate it + apply the discount.
 * The code is validated AGAINST THE DB (never trust the client's claim about
 * what discount applies — the client only says WHICH code, the server says
 * HOW MUCH). The discount is computed from the SERVER-COMPUTED totalGhs
 * (from DB prices), not from any client-sent total.
 *
 * After discount: if the total drops below GHS 1.00 (Paystack minimum), we
 * refuse with 422. If the discount exceeds the total (e.g. flat GHS 50 on a
 * GHS 30 order), we clamp the total to 0 — but Paystack doesn't accept 0, so
 * we also refuse with 422 in that case. */
$discountCode = strtoupper(trim((string)($b['discountCode'] ?? '')));
$discountAmount = 0.0;

if ($discountCode !== '') {
    // ★ Migration 2026-09-26: was `SELECT id, code, type, value, ... FROM discount_codes`
    //   but the actual schema columns are `discount_type` and `discount_value`
    //   (NOT `type` / `value`). The old query was throwing
    //   `SQLITE_ERROR: no such column: type` on every checkout with a
    //   discount code. Aliased to the PHP-expected names so the rest of
    //   the function (`$dc['type']`, `$dc['value']`) keeps working unchanged.
    $dcStmt = db()->prepare(
        'SELECT id, code, discount_type AS type, discount_value AS value, active, max_uses, used_count, expires_at
         FROM discount_codes
         WHERE code = ?
         LIMIT 1'
    );
    $dcStmt->execute([$discountCode]);
    $dc = $dcStmt->fetch();

    if (!$dc) {
        json_err('Invalid discount code.', 422);
    }
    if ((int)$dc['active'] !== 1) {
        json_err('This discount code is no longer active.', 422);
    }
    if ($dc['expires_at'] !== null) {
        // ★ M5 fix (audit): drop PHP-side expiry check (time() is UTC, MySQL
        //   NOW() is DB session timezone — they disagree around boundaries).
        //   The atomic MySQL check in the BL-10 reservation UPDATE below
        //   uses NOW() which is the correct single source of truth.
        // ★ NEW-5 fix (audit): the original M5 fix removed the specific
        //   "This discount code has expired" message entirely, leaving only
        //   the generic "usage limit (or was just deactivated/expired)" from
        //   the atomic UPDATE. Now: check expiry using a UTC query
        //   (single source of truth) so we can show the specific message.
        // ★ Migration 2026-09-26: was `expires_at <= UTC_TIMESTAMP()` —
        //   UTC_TIMESTAMP() is MySQL-only. SQLite's equivalent is
        //   `datetime('now')` which returns the current UTC time as
        //   'YYYY-MM-DD HH:MM:SS' (same format as CURRENT_TIMESTAMP).
        //   Both `expires_at` and `datetime('now')` are TEXT in SQLite,
        //   and the lexical comparison `<=` works correctly for ISO-8601
        //   timestamps (same as MySQL's DATETIME comparison).
        $expCheck = db()->prepare('SELECT expires_at <= datetime(\'now\') AS expired FROM discount_codes WHERE id = ? LIMIT 1');
        $expCheck->execute([$dc['id']]);
        $expRow = $expCheck->fetch();
        if ($expRow && (int)$expRow['expired'] === 1) {
            json_err('This discount code has expired.', 422);
        }
    }
    if ($dc['max_uses'] !== null && (int)$dc['used_count'] >= (int)$dc['max_uses']) {
        json_err('This discount code has reached its usage limit.', 422);
    }

    // Compute the discount amount from the SERVER-COMPUTED total.
    // ★ L1 fix (audit): validate discount type explicitly. The old code treated
    //   any non-'percentage' type as 'flat' — a typo like 'perentage' would
    //   silently apply a flat-amount discount equal to the percentage value.
    if (!in_array($dc['type'], ['percentage', 'flat'], true)) {
        json_err('Internal error: invalid discount type "' . $dc['type'] . '".', 500);
    }
    if ($dc['type'] === 'percentage') {
        $discountAmount = round($totalGhs * ((float)$dc['value'] / 100), 2);
    } else { // flat
        $discountAmount = round((float)$dc['value'], 2);
    }

    // Clamp: don't let the discount exceed the total.
    if ($discountAmount > $totalGhs) {
        $discountAmount = $totalGhs;
    }

    $totalGhs = round($totalGhs - $discountAmount, 2);
    $discountCode = $dc['code']; // the canonical uppercase version from DB
}

// Paystack minimum transaction in Ghana is GHS 1.00 (100 kobo). Below that
// Paystack rejects the init. We surface a friendly error here.
if ($totalGhs < 1.0) {
    json_err('Order total after discount is below the Paystack minimum (GHS 1.00).', 422);
}

// ★ L2 fix (audit): removed dead code — $amountKobo was computed but never
//   used (the actual Paystack call uses $amountSubunit below).

/* ---- 2d. Multi-currency (Phase 8 Batch 3, Task 60) ---------------------- *
 * ★ Verified live 2026-09-23 against paystack.com/docs + mctaba.com (Jul 2026):
 *   Paystack's /transaction/initialize accepts `currency` parameter with
 *   values: NGN, GHS, KES, ZAR, USD. For Ghanaian merchants, GHS is the
 *   default settlement currency; USD settlement requires a separate USD
 *   account in the Paystack dashboard (per support.paystack.com Sep 15 2026).
 *
 * Multi-currency flow:
 *   1. The customer's selected currency is sent in the body as `currency`
 *      (a 3-letter ISO 4217 code). If omitted, defaults to GHS (backward
 *      compat — existing callers see no behavior change).
 *   2. We look up the currency in the `currencies` table. If it doesn't
 *      exist, is inactive, OR is not paystack_supported: fall back to GHS
 *      with a notice in the response. The customer sees their selected
 *      currency on the storefront (display) but is charged in GHS.
 *   3. If the currency IS paystack_supported: convert the GHS total to
 *      that currency using the exchange_rate (1 GHS = rate units of the
 *      target currency). The amount is in SUBUNIT (pesewas for GHS, cents
 *      for USD, kobo for NGN, etc.) — Paystack's contract for all
 *      currencies is "amount in smallest currency unit × 100". So
 *      USD 10.00 → amount=1000, currency=USD.
 *   4. The order row's `currency` column is set to the CHARGING currency
 *      (what Paystack actually charges), NOT the display currency. This
 *      keeps the order record accurate — the receipt from Paystack will
 *      show the charged currency + amount, matching our DB row.
 *   5. Paystack's amount validation: the minimum chargeable is roughly
 *      GHS 1.00 equivalent. We check the converted amount against
 *      Paystack's minimum (100 subunit = 1.00 major) — if below, refuse.
 *
 * Security: the conversion rate is read from the DB (admin-controlled),
 * never from the client. The customer cannot tamper with the exchange
 * rate to get a discount. The admin updates rates via the Currencies tab. */

$displayCurrency = strtoupper(trim((string)($b['currency'] ?? '')));
$chargedCurrency = 'GHS';  // default fallback
$chargedAmount   = $totalGhs;  // in MAJOR unit (e.g. GHS 100.00, USD 12.50)
$currencyNotice  = null;  // optional message to surface to the customer

if ($displayCurrency !== '' && $displayCurrency !== 'GHS') {
    // Look up the requested currency.
    $currStmt = db()->prepare(
        'SELECT code, exchange_rate, paystack_supported, active
         FROM currencies
         WHERE code = ?
         LIMIT 1'
    );
    $currStmt->execute([$displayCurrency]);
    $curr = $currStmt->fetch();

    if (!$curr) {
        // Unknown currency code — fall back to GHS with a notice.
        $currencyNotice = 'Currency "' . $displayCurrency . '" is not configured. Charged in GHS instead.';
    } elseif ((int)$curr['active'] !== 1) {
        // Inactive currency — admin deactivated it. Fall back to GHS.
        $currencyNotice = 'Currency "' . $displayCurrency . '" is no longer available. Charged in GHS instead.';
    } elseif ((int)$curr['paystack_supported'] !== 1) {
        // Active for display but not chargeable via Paystack. Fall back to GHS.
        $currencyNotice = 'Paystack cannot charge in "' . $displayCurrency . '". Charged in GHS instead.';
    } else {
        // Paystack-supported + active: charge in this currency.
        $rate = (float)$curr['exchange_rate'];
        $chargedAmount = round($totalGhs * $rate, 2);
        $chargedCurrency = $displayCurrency;
    }
}

// Convert to subunit (×100). Paystack's amount field is always the smallest
// currency unit × 100, regardless of the currency (e.g. USD 10.00 → 1000,
// GHS 100.00 → 10000, NGN 5000.00 → 500000). This is documented at
// https://paystack.com/docs/payments/accept-payments#amount
$amountSubunit = (int)round($chargedAmount * 100);

// Paystack minimum: 100 subunit = 1.00 major unit. Refuse if below.
if ($amountSubunit < 100) {
    json_err('Order total after currency conversion is below the Paystack minimum (1.00 ' . $chargedCurrency . ').', 422);
}

/* ---- 3. Read currency from site_settings --------------------------------- */
// ★ Phase 8 Batch 3 (Task 60): the site_settings currency is the BASE currency
// (the one product prices are stored in). For Morcenzs this is always 'GHS'.
// The CHARGING currency (what Paystack charges) was computed in section 2d
// above from the customer's selected display currency. The order row's
// `currency` column stores the CHARGING currency (matches the Paystack
// receipt); `total_amount` stores the CHARGING amount (in major unit, e.g.
// 12.50 USD or 100.00 GHS).
//
// The original guard ("Store currency must be GHS") is retained as a
// sanity check on the BASE currency — if the admin somehow set the base
// currency to something other than GHS, the product prices in the DB are
// meaningless for conversion. Refuse loudly instead of charging wrong amounts.
$currency = DEFAULT_CURRENCY;
$stmt = db()->prepare('SELECT setting_value FROM site_settings WHERE setting_key = ? LIMIT 1');
$stmt->execute([CURRENCY_KEY]);
$cRow = $stmt->fetch();
if ($cRow) $currency = $cRow['setting_value'];
if ($currency !== PAYSTACK_CURRENCY) {
    json_err('Store base currency must be GHS for Paystack payments. Current: ' . $currency, 422);
}

/* ---- 4. Create the order + items (transactional) -------------------------- */
// ★ Phase 8 Batch 3: total_amount + currency in the order row are now the
// CHARGING values (what Paystack will charge), not the GHS base. The
// order_items table still snapshots the GHS product prices (the source of
// truth for inventory valuation + analytics), so historical orders always
// know both: what was charged AND what it was worth in base currency.
$reference = generate_order_reference();
$pdo = db();
$pdo->beginTransaction();
try {
    $stmt = $pdo->prepare(
        'INSERT INTO orders (reference, customer_name, customer_phone, customer_email, total_amount, currency, paystack_status, discount_code, discount_amount)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'
    );
    $stmt->execute([
        $reference, $name, $phone, ($email ?: null),
        $chargedAmount, $chargedCurrency, 'pending',
        $discountCode !== '' ? $discountCode : null,
        // ★ H6 fix (audit): store discount in the CHARGING currency, not GHS.
        //   The old code stored $discountAmount (computed from $totalGhs = GHS
        //   base) alongside $chargedAmount (USD/NGN/etc). A GHS 10 discount on
        //   a USD order was stored as if it were USD 10. Now: convert the
        //   discount to the charging currency using the same rate.
        ($discountAmount > 0 && $chargedCurrency !== $currency)
            ? round($discountAmount * ($chargedAmount / max($totalGhs, 0.01)), 2)
            : ($discountAmount > 0 ? $discountAmount : null),
    ]);
    $orderId = (int)$pdo->lastInsertId();

    $stmt = $pdo->prepare(
        // ★ Migration 2026-09-26: was
        //   `INSERT INTO order_items (order_id, product_id, variant_id, name, scent, price, qty, image_path)`
        //   but the actual schema columns are `product_name`, `variant_name`,
        //   `unit_price`, `quantity`. There is NO `scent` column — the
        //   snapshot's `scent` value (which the cleanItems array carries)
        //   is now folded into the variant_name field if present, otherwise
        //   into product_name. The previous INSERT was throwing
        //   `SQLITE_ERROR: table order_items has no column named name` on
        //   every checkout → entire transaction rolled back → no order
        //   could ever be created.
        'INSERT INTO order_items (order_id, product_id, variant_id, product_name, variant_name, unit_price, quantity, image_path)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
    );
    foreach ($cleanItems as $it) {
        // image_path can be a long base64 data URL for legacy rows — cap at 255
        // chars to fit the column. Newer uploads/ paths are already short.
        $imgPath = $it['image_path'];
        if (strlen($imgPath) > 255) $imgPath = '';  // legacy base64 — drop snapshot
        $snapshotName = $it['name'];
        $snapshotVariant = !empty($it['variant']) ? $it['variant'] : null;  // ★ BL-01: keep variant_name separate
        $stmt->execute([
            $orderId,
            $it['product_id'],
            $it['variant_id'],   // ★ BL-01 fix: persist variant_id so webhook/orders decrement loop can drain variant stock
            $snapshotName,
            $snapshotVariant,
            $it['price'],
            $it['qty'],
            $imgPath,
        ]);
    }

    // ★ BL-10 fix (= SEC-03 fix): atomic reservation on discount_codes.
    //   The pre-transaction validation (lines 216-256) read the row +
    //   checked max_uses — but that was a read-then-validate-then-write
    //   pattern spread across two endpoints (payments.php reads,
    //   webhook.php writes). Between the check here and the increment in
    //   webhook.php (on the paid transition), `used_count` did NOT
    //   reflect the in-flight orders that had already consumed the code.
    //   Ten concurrent checkouts with code `WELCOME10` (max_uses=1) all
    //   read used_count=0, all passed, all created order rows with
    //   discount_code='WELCOME10' — if even two paid, the code was
    //   used twice against max_uses=1.
    //
    //   SEC-03 re-verify (Task 37): the audit's SEC-03 recommended
    //   "atomically UPDATE discount_codes SET used_count = used_count + 1
    //   WHERE code = ? AND (max_uses IS NULL OR used_count < max_uses) and
    //   refuse the order if rowCount() === 0". This is EXACTLY what the
    //   BL-10 fix (Task 28) implemented — the atomic conditional UPDATE
    //   below matches the audit's recommendation. SEC-03 is RESOLVED.
    //
    //   Fix: at the moment of order creation, atomically increment
    //   used_count ONLY if there's still capacity. The conditional UPDATE
    //   is serialized by InnoDB's row-level locking — the second concurrent
    //   request blocks until the first commits, then sees the incremented
    //   used_count and the WHERE clause fails → rowCount=0 → we roll back
    //   the order INSERT + return 422.
    //
    //   Semantic change: used_count now reflects RESERVATIONS (pending +
    //   paid orders), not just paid orders. The decrement-on-abandoned/
    //   failed path in webhook.php + orders.php releases the reservation
    //   when the order doesn't pay. The increment-on-paid path is REMOVED
    //   from webhook.php + orders.php (the increment now happens here at
    //   creation). See the parallel edits in webhook.php + orders.php.
    //
    //   Legacy-order note: orders created BEFORE this fix (existing rows
    //   with paystack_status='pending' and discount_code set) had their
    //   used_count NOT incremented at creation. Under the new code, they
    //   also won't be incremented on the paid transition (because that
    //   path is removed). So those legacy pending orders will not
    //   contribute to used_count even when they eventually pay. This
    //   affects a small window of orders at the moment of deploy —
    //   acceptable for a surgical fix.
    if ($discountCode !== '') {
        $reserve = $pdo->prepare(
            'UPDATE discount_codes
             SET used_count = used_count + 1
             WHERE code = ?
               AND active = 1
               AND (expires_at IS NULL OR expires_at > CURRENT_TIMESTAMP)
               AND (max_uses IS NULL OR used_count < max_uses)'
        );
        $reserve->execute([$discountCode]);
        if ($reserve->rowCount() === 0) {
            // The pre-transaction validation passed, but a concurrent
            // checkout took the last slot between then and now. Roll back
            // the order INSERT + return 422 — the customer can retry.
            $pdo->rollBack();
            json_err('This discount code has reached its usage limit (or was just deactivated/expired). Please try again.', 422);
        }
    }

    $pdo->commit();
} catch (Exception $e) {
    $pdo->rollBack();
    error_log('[morbi] Order creation failed: ' . $e->getMessage()); json_err('Could not create order. Check the server error log for details.', 500);
}

/* ---- 5. Call Paystack /transaction/initialize ---------------------------- */
// ★ Phase 8 Batch 3 (Task 60): pass the CHARGING amount + currency to Paystack.
//   paystack_initialize() now takes a 6th parameter for the currency (defaults
//   to PAYSTACK_CURRENCY='GHS' for backward compat). The amount is in subunit
//   (×100) regardless of the currency — Paystack's contract per
//   https://paystack.com/docs/payments/accept-payments#amount.
$init = paystack_initialize($reference, $amountSubunit, $paystackEmail, $phone, [
    'order_id'   => $orderId,
    'item_count' => count($cleanItems),
    'total_items' => array_sum(array_column($cleanItems, 'qty')),
], $chargedCurrency);

if (!$init['ok']) {
    // Paystack init failed. Mark the order as failed so the dashboard shows it;
    // the customer can retry (a new order row will be created).
    $upd = db()->prepare('UPDATE orders SET paystack_status = ? WHERE id = ?');
    $upd->execute(['failed', $orderId]);

    // ★ BL-10 BLIND-SPOT fix: release the discount-code reservation we
    //   incremented at order creation (line 355-372). The webhook will
    //   NOT fire for this order (Paystack never received the init
    //   request successfully), so the decrement-on-failed path in
    //   webhook.php + orders.php never runs. Without this release, the
    //   `used_count` would be permanently inflated by one for every
    //   customer who hit a Paystack init failure (network blip, secret
    //   key rotation, rate limit, etc.) — the code would slowly drain
    //   its max_uses capacity on orders that never even reached Paystack.
    //   The decrement is conditional on the order having a
    //   `discount_code` (no-op for orders without a code) and uses
    //   `MAX(used_count - 1, 0)` to defend against any future
    //   edge case where used_count is already 0 (e.g. a manual DB
    //   edit).
    //   ★ SQLITE FIX (2026-09-26): GREATEST() → MAX() (SQLite scalar form).
    if ($discountCode !== '') {
        $release = db()->prepare(
            'UPDATE discount_codes
             SET used_count = MAX(used_count - 1, 0)
             WHERE code = ?'
        );
        $release->execute([$discountCode]);
    }

    json_err('Paystack initialization failed: ' . $init['error'], 502);
}

/* ---- 6. Return the auth URL + reference ---------------------------------- */
// ★ Phase 8 Batch 3 (Task 60): response now includes BOTH the GHS base
//   total (what the order was worth in the store's base currency — for the
//   frontend's reference) AND the charging values (what Paystack will
//   actually charge, in the charged currency). The `currency_notice` field
//   is non-null when the customer's selected display currency could not be
//   charged (fell back to GHS) — the storefront surfaces this to the customer.

// ★ Phase 9 Batch 2 (Task 62): notify the admin that a new order was created.
//   Fire-and-forget — the customer's checkout isn't blocked by an email
//   failure. The notification is logged to notification_log (idempotent —
//   if the same order_id is processed twice, the second insert is a no-op
//   via the UNIQUE KEY uq_notif_dedup).
try {
    notify_admin_new_order($orderId);
} catch (Throwable $e) {
    // Defensive: don't let a notification failure break the checkout response.
    // The order was created + Paystack init succeeded — the customer needs
    // the authorization_url to proceed.
    error_log('[morbi] notify_admin_new_order threw for order ' . $orderId . ': ' . $e->getMessage());
}

json_ok([
    'reference'         => $reference,
    'authorization_url' => $init['data']['authorization_url'],
    'amount'            => $chargedAmount,             // ★ Phase 8 Batch 3: charging amount (major unit)
    'currency'          => $chargedCurrency,           // ★ Phase 8 Batch 3: charging currency
    'base_amount'       => $totalGhs,                   // ★ Phase 8 Batch 3: GHS-equivalent for reference
    'base_currency'     => $currency,                   // ★ Phase 8 Batch 3: base currency (GHS)
    'currency_notice'   => $currencyNotice,             // ★ Phase 8 Batch 3: null or fallback message
    'order_id'          => $orderId,
    'discount_code'     => $discountCode !== '' ? $discountCode : null,
    'discount_amount'   => $discountAmount > 0 ? $discountAmount : null,
]);
