<?php
/**
 * settings.php — site settings (Phase 0: currency only; ★ Phase 9 Batch 2:
 * notify_* email-notification settings).
 *
 * GET public               -> { currency: "GHS", notify: { admin_email, from_name, from_email } }
 * PUT  admin {currency}    -> validates with the SAME rule as the old saveCurrency().
 * PUT  admin {notify: {admin_email, from_name, from_email}}  -> ★ Phase 9 Batch 2:
 *                            updates the notification settings. admin_email must be
 *                            a valid email (or empty to disable notifications).
 *                            from_email must be a valid email (or empty to fall back
 *                            to SMTP_FROM). from_name is 1-100 chars.
 *
 * Public GET exposes the notify_* fields so the frontend can show "notifications
 * are disabled" warnings. The notify_admin_email is returned as-is (it's the
 * admin's address, not PII — the storefront doesn't display it).
 */

require __DIR__ . '/_bootstrap.php';

// CURRENCY_KEY / DEFAULT_CURRENCY / CURRENCY_PATTERN live in _bootstrap.php —
// shared with import.php so both enforce the identical validation rule.

// ★ Phase 9 Batch 2 (Task 62): notification setting keys.
const NOTIFY_ADMIN_EMAIL_KEY = 'notify_admin_email';
const NOTIFY_FROM_NAME_KEY   = 'notify_from_name';
const NOTIFY_FROM_EMAIL_KEY  = 'notify_from_email';

// ★ Feature 4: WhatsApp business number key (default '233000000000').
//   Stored in site_settings so the admin can edit it from the dashboard
//   Theme tab; returned by GET so the frontend (app.js) can update the
//   #whatsapp-fab link's href at boot.
const WHATSAPP_NUMBER_KEY = 'whatsapp_number';
const WHATSAPP_NUMBER_DEFAULT = '233000000000';
// 6-15 digits — country code + local number, no +, spaces, dashes, or
// parentheses. Matches the format wa.me/<number> expects.
const WHATSAPP_NUMBER_PATTERN = '/^[0-9]{6,15}$/';

switch ($_SERVER['REQUEST_METHOD']) {
    case 'GET': handle_get();  break;
    case 'PUT': require_admin(); verify_csrf(); handle_put(); break;
    default:    json_err('Method not allowed.', 405);
}

/* ---- GET ------------------------------------------------------------------ */
function handle_get(): void {
    $stmt = db()->prepare('SELECT setting_value FROM site_settings WHERE setting_key = ? LIMIT 1');
    $stmt->execute([CURRENCY_KEY]);
    $row = $stmt->fetch();
    $currency = $row ? $row['setting_value'] : DEFAULT_CURRENCY;

    // ★ Phase 9 Batch 2 (Task 62): also return the notify_* settings so the
    //   frontend (dashboard Theme tab or a future Settings tab) can show
    //   the current values + warn if notifications are disabled.
    $notifyKeys = [NOTIFY_ADMIN_EMAIL_KEY, NOTIFY_FROM_NAME_KEY, NOTIFY_FROM_EMAIL_KEY];
    $inPlaceholders = implode(',', array_fill(0, count($notifyKeys), '?'));
    $notifyStmt = db()->prepare(
        "SELECT setting_key, setting_value FROM site_settings WHERE setting_key IN ($inPlaceholders)"
    );
    $notifyStmt->execute($notifyKeys);
    $notifyRows = $notifyStmt->fetchAll();
    $notifyMap = [];
    foreach ($notifyRows as $r) {
        $notifyMap[$r['setting_key']] = (string)$r['setting_value'];
    }

    // ★ Feature 4: also return the WhatsApp number so the frontend (app.js)
    //   can update the #whatsapp-fab link's href at boot. Falls back to the
    //   default placeholder on pre-seed installs (no row yet).
    $waStmt = db()->prepare('SELECT setting_value FROM site_settings WHERE setting_key = ? LIMIT 1');
    $waStmt->execute([WHATSAPP_NUMBER_KEY]);
    $waRow = $waStmt->fetch();
    $whatsappNumber = $waRow ? (string)$waRow['setting_value'] : WHATSAPP_NUMBER_DEFAULT;

    json_ok([
        'currency' => $currency,
        'notify'   => [
            'admin_email' => $notifyMap[NOTIFY_ADMIN_EMAIL_KEY] ?? '',
            'from_name'   => $notifyMap[NOTIFY_FROM_NAME_KEY] ?? 'morbi.shop',
            'from_email'  => ($notifyMap[NOTIFY_FROM_EMAIL_KEY] ?? '') ?: (defined('SMTP_FROM') ? SMTP_FROM : ''),
        ],
        // ★ Feature 4: WhatsApp business number (digits only, country code +
        //   local number, no +). Returned to the frontend so the FAB link
        //   can be configured without editing index.html.
        'whatsapp_number' => $whatsappNumber,
    ]);
}

/* ---- PUT ------------------------------------------------------------------ */
function handle_put(): void {
    $b = json_body();

    // Currency update (existing Phase 0 behavior — preserved).
    if (array_key_exists('currency', $b)) {
        $currency = trim((string)$b['currency']);
        if ($currency === '' || !preg_match(CURRENCY_PATTERN, $currency)) {
            json_err('Invalid currency symbol/code (1-5 letters or currency symbols).', 422);
        }
        $stmt = db()->prepare(
            'INSERT INTO site_settings (setting_key, setting_value) VALUES (?, ?)
             ON CONFLICT(setting_key) DO UPDATE SET setting_value = excluded.setting_value'
        );
        $stmt->execute([CURRENCY_KEY, $currency]);
    }

    // ★ Phase 9 Batch 2 (Task 62): notification settings update.
    if (array_key_exists('notify', $b) && is_array($b['notify'])) {
        $n = $b['notify'];

        // admin_email: must be a valid email OR empty (to disable notifications).
        if (array_key_exists('admin_email', $n)) {
            $adminEmail = trim((string)$n['admin_email']);
            if ($adminEmail !== '' && !filter_var($adminEmail, FILTER_VALIDATE_EMAIL)) {
                json_err('notify.admin_email must be a valid email address or empty (to disable).', 422);
            }
            _upsert_setting(NOTIFY_ADMIN_EMAIL_KEY, $adminEmail);
        }

        // from_name: 1-100 chars (or default 'morbi.shop').
        if (array_key_exists('from_name', $n)) {
            $fromName = trim((string)$n['from_name']);
            if ($fromName !== '' && mb_strlen($fromName) > 100) {
                json_err('notify.from_name must be 1-100 characters.', 422);
            }
            if ($fromName === '') $fromName = 'morbi.shop';
            _upsert_setting(NOTIFY_FROM_NAME_KEY, $fromName);
        }

        // from_email: must be a valid email OR empty (falls back to SMTP_FROM).
        if (array_key_exists('from_email', $n)) {
            $fromEmail = trim((string)$n['from_email']);
            if ($fromEmail !== '' && !filter_var($fromEmail, FILTER_VALIDATE_EMAIL)) {
                json_err('notify.from_email must be a valid email address or empty (to use SMTP_FROM).', 422);
            }
            _upsert_setting(NOTIFY_FROM_EMAIL_KEY, $fromEmail);
        }
    }

    // ★ Feature 4: WhatsApp number update. Accepts a digits-only string
    //   (6-15 chars, country code + local number, no + or punctuation).
    //   Empty string falls back to the default placeholder so the FAB link
    //   is never broken.
    if (array_key_exists('whatsapp_number', $b)) {
        $waNumber = trim((string)$b['whatsapp_number']);
        // Strip common punctuation a customer might paste with the number
        //   (+, spaces, dashes, parentheses) before validating.
        $waNumber = preg_replace('/[^0-9]/', '', $waNumber);
        if ($waNumber !== '' && !preg_match(WHATSAPP_NUMBER_PATTERN, $waNumber)) {
            json_err('whatsapp_number must be 6-15 digits (country code + local number, no + or punctuation).', 422);
        }
        if ($waNumber === '') {
            $waNumber = WHATSAPP_NUMBER_DEFAULT;
        }
        _upsert_setting(WHATSAPP_NUMBER_KEY, $waNumber);
    }

    // Re-read the current state for the response (so the caller sees the
    // merged result of their PUT).
    $stmt = db()->prepare('SELECT setting_value FROM site_settings WHERE setting_key = ? LIMIT 1');
    $stmt->execute([CURRENCY_KEY]);
    $row = $stmt->fetch();
    $currency = $row ? $row['setting_value'] : DEFAULT_CURRENCY;

    $notifyKeys = [NOTIFY_ADMIN_EMAIL_KEY, NOTIFY_FROM_NAME_KEY, NOTIFY_FROM_EMAIL_KEY];
    $inPlaceholders = implode(',', array_fill(0, count($notifyKeys), '?'));
    $notifyStmt = db()->prepare(
        "SELECT setting_key, setting_value FROM site_settings WHERE setting_key IN ($inPlaceholders)"
    );
    $notifyStmt->execute($notifyKeys);
    $notifyRows = $notifyStmt->fetchAll();
    $notifyMap = [];
    foreach ($notifyRows as $r) {
        $notifyMap[$r['setting_key']] = (string)$r['setting_value'];
    }

    // ★ Feature 4: re-read the WhatsApp number for the response.
    $waStmt = db()->prepare('SELECT setting_value FROM site_settings WHERE setting_key = ? LIMIT 1');
    $waStmt->execute([WHATSAPP_NUMBER_KEY]);
    $waRow = $waStmt->fetch();
    $whatsappNumber = $waRow ? (string)$waRow['setting_value'] : WHATSAPP_NUMBER_DEFAULT;

    json_ok([
        'currency' => $currency,
        'notify'   => [
            'admin_email' => $notifyMap[NOTIFY_ADMIN_EMAIL_KEY] ?? '',
            'from_name'   => $notifyMap[NOTIFY_FROM_NAME_KEY] ?? 'morbi.shop',
            'from_email'  => ($notifyMap[NOTIFY_FROM_EMAIL_KEY] ?? '') ?: (defined('SMTP_FROM') ? SMTP_FROM : ''),
        ],
        'whatsapp_number' => $whatsappNumber,
    ]);
}

/** Helper: INSERT ... ON CONFLICT UPDATE (SQLite UPSERT) for site_settings. */
function _upsert_setting(string $key, string $value): void {
    $stmt = db()->prepare(
        'INSERT INTO site_settings (setting_key, setting_value) VALUES (?, ?)
         ON CONFLICT(setting_key) DO UPDATE SET setting_value = excluded.setting_value'
    );
    $stmt->execute([$key, $value]);
}
