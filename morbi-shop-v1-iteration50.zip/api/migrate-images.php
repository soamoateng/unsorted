<?php
/**
 * migrate-images.php — bulk-migrate legacy base64 product images to uploads/.
 *
 * Phase 1 Batch 2 moved NEW uploads to real files under uploads/, but legacy
 * product rows whose image_path is a `data:image/...;base64,...` string
 * were left untouched (read-compat — <img src> accepts both shapes).
 *
 * This endpoint scans every products.image_path that matches the base64
 * pattern, decodes the data URL, writes the bytes to uploads/<safe-name>,
 * and UPDATEs the row's image_path to the new uploads/<name> path. Idempotent
 * — re-running on an already-migrated DB is a no-op (no base64 rows left).
 *
 *   POST  admin, optional body { dryRun: true }
 *         -> { migrated: N, skipped: N, bytes: B, dryRun: bool, samples: [...] }
 *
 * Security:
 *   * Admin-only (require_admin guard).
 *   * MIME sniffed from the base64-decoded bytes via finfo (NOT from the
 *     data: URL prefix, which can lie). Same security stance as upload.php.
 *   * Allowed MIME: image/jpeg, image/png, image/webp, image/gif (the
 *     same ALLOWED_MIME map from _config.php).
 *   * Filename = {timestamp}-{12 hex random}.{ext} — server-generated,
 *     zero user input, no path traversal.
 *   * One DB transaction per row: image_path is updated only AFTER the
 *     file write succeeds. A failed write leaves the row's base64 intact
 *     so the legacy image still renders (no data loss on partial failure).
 *   * dryRun=true: scans + reports what WOULD be migrated, writes nothing.
 *
 * Why a dedicated endpoint (not folded into upload.php):
 *   * Different shape (no $_FILES; reads from DB) → different code path.
 *   * Different auth UX (one-button bulk action vs. per-product upload).
 *   * Different failure semantics (per-row partial success is OK; for
 *     upload.php a single failure aborts the whole request).
 */

require __DIR__ . '/_bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_err('POST only.', 405);
}
require_admin();
verify_csrf();

$b = json_body();
$dryRun = to_bool($b['dryRun'] ?? false, false);

/* ---- Make sure uploads/ exists (mirrors upload.php's bootstrap) --------- */
if (!is_dir(UPLOAD_DIR)) {
    @mkdir(UPLOAD_DIR, 0755, true);
}
if (!$dryRun && (!is_dir(UPLOAD_DIR) || !is_writable(UPLOAD_DIR))) {
    json_err('Server error: uploads/ directory is missing or not writable. Check folder permissions and retry.', 500);
}

/* ---- Scan every product whose image_path is a base64 data URL ----------- */
// Regex mirrors the one in products.php validate_product — same MIME list,
// same character class. Anchored with ^...$ so partial matches don't slip in.
$base64Pattern = '#^data:image/(png|jpe?g|webp|gif);base64,([A-Za-z0-9+/=\s]+)$#';

$stmt = db()->prepare('SELECT id, image_path FROM products WHERE image_path LIKE ?');
$stmt->execute(['data:image/%']);
$rows = $stmt->fetchAll();

$migrated = 0;
$skipped  = 0;
$bytes    = 0;
$samples  = [];

foreach ($rows as $row) {
    $img = (string)$row['image_path'];
    if (!preg_match($base64Pattern, $img, $m)) {
        // Not a clean base64 image URL — skip without failing. The row will
        // still render via <img src> (data URL or whatever it is).
        $skipped++;
        continue;
    }

    $mimeFromUrl = $m[1];
    $b64 = $m[2];
    $decoded = base64_decode($b64, true);   // strict mode: reject non-base64 chars
    if ($decoded === false || strlen($decoded) === 0) {
        $skipped++;
        continue;
    }

    // SNIFF the actual MIME from the decoded bytes (defensive — the data:
    // URL prefix can lie). Same finfo path as upload.php.
    $actualMime = false;
    if (function_exists('finfo_open')) {
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        if ($finfo !== false) {
            $actualMime = finfo_buffer($finfo, $decoded);
            finfo_close($finfo);
        }
    }
    if ($actualMime === false || !array_key_exists($actualMime, ALLOWED_MIME)) {
        $skipped++;
        continue;
    }
    $extension = ALLOWED_MIME[$actualMime];

    // Generate the safe filename (same shape as upload.php — see that file
    // for the rationale: 12 hex chars of random_bytes + timestamp prefix).
    $filename = sprintf('%d-%s.%s', time(), bin2hex(random_bytes(6)), $extension);
    $fullPath = rtrim(UPLOAD_DIR, '/') . '/' . $filename;
    $relPath  = UPLOAD_URL . '/' . $filename;

    if ($dryRun) {
        $migrated++;
        $bytes += strlen($decoded);
        if (count($samples) < 5) {
            $samples[] = ['id' => (int)$row['id'], 'would_become' => $relPath, 'bytes' => strlen($decoded)];
        }
        continue;
    }

    // Write the decoded bytes to uploads/. Use file_put_contents (not
    // move_uploaded_file — that helper only accepts real $_FILES POSTs).
    // ★ OTH-18 fix (iteration 25): the previous line was
    //   `$written = file_put_contents($serializedData = $fullPath, $decoded);`
    //   The inline assignment `$serializedData = $fullPath` was a leftover
    //   debugging scaffold — `$serializedData` was never read anywhere else
    //   in the file (verified by grep). Simplified to the bare call.
    $written = file_put_contents($fullPath, $decoded);
    if ($written === false || $written !== strlen($decoded)) {
        // Partial write — clean up and skip this row (legacy base64 stays).
        @unlink($fullPath);
        $skipped++;
        continue;
    }

    // File written. Now UPDATE the row's image_path inside a transaction
    // so a DB failure doesn't leave an orphan file (well — the orphan stays
    // in uploads/, but at least the DB stays consistent with itself; the
    // next migrate run will simply find no base64 row for that id and skip).
    $pdo = db();
    $pdo->beginTransaction();
    try {
        $upd = $pdo->prepare('UPDATE products SET image_path = ? WHERE id = ?');
        $upd->execute([$relPath, (int)$row['id']]);
        $pdo->commit();
    } catch (Exception $e) {
        $pdo->rollBack();
        @unlink($fullPath);   // tidy up the just-written file
        $skipped++;
        continue;
    }

    $migrated++;
    $bytes += $written;
    if (count($samples) < 5) {
        $samples[] = ['id' => (int)$row['id'], 'path' => $relPath, 'bytes' => $written];
    }
}

json_ok([
    'migrated' => $migrated,
    'skipped'  => $skipped,
    'bytes'    => $bytes,
    'dryRun'   => $dryRun,
    'samples'  => $samples,
    'note'     => $dryRun
        ? 'Dry run — nothing was written. Re-POST without dryRun to migrate.'
        : ($migrated . ' image(s) migrated to uploads/. Legacy base64 rows now point to file paths.'),
]);
