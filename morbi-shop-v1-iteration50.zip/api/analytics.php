<?php
/**
 * analytics.php — Phase 5 (Sport Car) Batch 4 sales analytics.
 *
 *   GET  admin  → { revenue, orders, topProducts, recentTrend, customerInsights, discountUsage }
 *
 * Returns aggregated data for the dashboard Analytics tab:
 *   - revenue: total revenue, total orders, average order value, revenue by status
 *   - topProducts: top 10 products by quantity sold + revenue
 *   - recentTrend: last 30 days order count + revenue (for sparkline charts)
 *   - customerInsights: total customers, returning customers, top 5 by order count
 *   - discountUsage: total discount given, top 5 codes by usage
 *
 * Security: admin-only (require_admin). CSRF not needed (GET request).
 */

require __DIR__ . '/_bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    json_err('GET only.', 405);
}
require_admin();

// ★ RT-07 fix: synchronize PHP + MySQL timezones for the trend chart.
//   The SQL uses CURDATE()/DATE() (MySQL session TZ) + the PHP fill-in loop
//   uses date()/strtotime() (PHP date.timezone). On hosts where PHP ≠ MySQL
//   TZ (common on cPanel: PHP=UTC, MySQL=system TZ), an order placed at
//   "2026-09-04 23:30:00" in MySQL's local TZ lands in MySQL's "2026-09-04"
//   bucket, but PHP's strtotime("-1 days") (relative to PHP's "today" which
//   is one TZ off) generates "2026-09-05" — the lookup fails, the chart
//   shows 0 orders for the day that actually had the order.
//   Fix: set BOTH PHP + MySQL to UTC at the top of this script. UTC is the
//   safest choice because MySQL TIMESTAMP columns are stored in UTC
//   internally (the value returned to PDO is the UTC value converted to the
//   session TZ — setting the session TZ to UTC returns the raw UTC value).
//   This only affects this script's queries (the PDO singleton is per-request).
//   Other scripts (payments.php, orders.php, webhook.php) are unaffected.
@date_default_timezone_set('UTC');
// ★ SQLite: no time_zone session variable (it's a MySQL concept). Skip.
//   SQLite stores timestamps as TEXT in UTC by default (PHP's date('Y-m-d H:i:s')
//   produces UTC if date_default_timezone_set('UTC') is in effect). All
//   timestamp comparisons just work because both PHP + SQLite use UTC.

// ★ SEC-14 fix: log this analytics access for audit purposes. Records who
//   accessed the analytics endpoint + when.
// ★ SQLITE FIX (2026-09-26) n5: was `CREATE TABLE IF NOT EXISTS` inline on
//   every analytics request — 3 wasted SQL round-trips per request. The
//   table is now created by install.php (alongside the other 19 tables).
//   The inline CREATE is kept as a SAFETY NET (suppressed with @) for the
//   case where an operator upgraded the codebase but didn't re-run
//   install.php. Once install.php is run (or the pre-seeded morbi.sqlite
//   ships with the table), the inline CREATE is a no-op (IF NOT EXISTS).
@db()->exec("CREATE TABLE IF NOT EXISTS analytics_access_log (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  admin_id   INTEGER NOT NULL,
  ip_address TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
)");
@db()->exec("CREATE INDEX IF NOT EXISTS idx_analytics_access_admin ON analytics_access_log(admin_id)");
@db()->exec("CREATE INDEX IF NOT EXISTS idx_analytics_access_created ON analytics_access_log(created_at)");
$logStmt = db()->prepare('INSERT INTO analytics_access_log (admin_id, ip_address) VALUES (?, ?)');
$logStmt->execute([$_SESSION['admin_id'] ?? 0, $_SERVER['REMOTE_ADDR'] ?? null]);

// ★ RT-14 fix: wrap ALL analytics queries in a single try/catch. If any
//   underlying table is missing or has drifted schema (e.g. an upgrade
//   skipped install.php's ALTER TABLE for discount_code/variant_id/
//   scent_category; or discount_codes/product_variants table doesn't
//   exist), the PDOException propagates as a fatal error with HTML stack
//   trace. The dashboard's loadAnalytics() does JSON.parse(text) on the
//   HTML body, throws, catches, and shows "Failed to load analytics."
//   The admin has no way to know what specifically failed.
//   Fix: catch PDOException → return a clean JSON 500 with the specific
//   error message (tells the admin which query failed + suggests
//   re-running install.php).
try {

/* ---- Revenue summary ----------------------------------------------------
 * ★ BL-03 fix: avg_order_value now scopes AVG() to paid orders only
 *   (was AVG over ALL non-deleted orders → inflated by pending/failed/
 *   abandoned carts). The dashboard's "Avg Order Value" stat card reads
 *   this field directly (dashboard.js renderStatCard line 1759).
 * ★ BL-04 fix: total_discount_given now scopes SUM() to paid orders only
 *   (was SUM over ALL non-deleted orders → discounts on never-paid orders
 *   inflated the "Discount Given" card). discount_amount is written at
 *   order creation (payments.php ~line 292), not at payment time, so a
 *   customer who applies WELCOME10 then abandons produces a row with
 *   discount_amount = 20.00 — that row must not contribute to the
 *   "Discount Given" metric. The dashboard reads this field at line 1763.
 * ★ BL-18 fix: the paid CASE WHEN now uses `paystack_paid_at IS NOT NULL`
 *   instead of `paystack_status = 'paid'`, AND the outer WHERE now
 *   includes `OR paystack_paid_at IS NOT NULL`. This means soft-deleted
 *   PAID orders (status='deleted' but paystack_paid_at IS NOT NULL — i.e.
 *   the order was paid, then the admin soft-deleted it for cleanup) STILL
 *   CONTRIBUTE to paid_orders, paid_revenue, avg_order_value, and
 *   total_discount_given. Previously, soft-deleting a paid order
 *   retroactively removed its revenue from the dashboard — the audit
 *   calls this "mutable by deletion" (a paid order from last month that's
 *   soft-deleted today causes last month's revenue number to drop).
 *   The principle: deleted = "hidden from the active Orders tab list but
 *   still counted historically in analytics".
 *
 *   Active-only metrics (`total_orders` COUNT(*), `total_revenue`
 *   SUM(total_amount), `pending_orders` / `failed_orders` /
 *   `abandoned_orders` CASE WHEN counts) ALSO include deleted-was-paid
 *   orders under the new outer WHERE. This is a deliberate semantic
 *   change per the audit: `total_orders` is now "all orders I've ever
 *   received except pending/failed/abandoned carts that were
 *   soft-deleted for cleanup". A soft-deleted-was-paid order is still
 *   counted in `total_orders` (it was a real order). A soft-deleted-was-
 *   abandoned order is NOT counted (it was never a real order — just a
 *   cart that was abandoned then cleaned up).
 *
 *   The `pending_orders` / `failed_orders` / `abandoned_orders` CASE
 *   WHEN checks use `paystack_status = 'X'` — a deleted-was-paid order
 *   has status='deleted', so it doesn't match any of these (correct —
 *   it was paid, not pending/failed/abandoned). A deleted-was-abandoned
 *   order also has status='deleted' (was 'abandoned' before the admin
 *   soft-deleted it) — it's NOT counted in `abandoned_orders` because
 *   we don't track previous status. Acceptable per the audit (the
 *   audit's concern is PAID orders, not abandoned).
 *
 *   The dashboard deliberately shows BOTH "Total Orders" (r.totalOrders)
 *   and "Paid Orders" (r.paidOrders) so the admin can see the cart-
 *   abandonment rate at a glance. */
$revStmt = db()->query(
    "SELECT
        COUNT(*) as total_orders,
        COALESCE(SUM(total_amount), 0) as total_revenue,
        COALESCE(AVG(CASE WHEN paystack_paid_at IS NOT NULL THEN total_amount ELSE NULL END), 0) as avg_order_value,
        COALESCE(SUM(CASE WHEN paystack_paid_at IS NOT NULL THEN discount_amount ELSE 0 END), 0) as total_discount_given,
        -- ★ SQLITE FIX (2026-09-26): wrapped all 5 SUMs in COALESCE(..., 0)
        --   for consistency with the 3 above. When the orders table is empty,
        --   SUM(CASE...) returns NULL (not 0). PHP's (int)null cast gives 0
        --   (functionally correct), but a future maintainer using ===
        --   comparison would break. COALESCE makes the contract explicit.
        COALESCE(SUM(CASE WHEN paystack_paid_at IS NOT NULL THEN 1 ELSE 0 END), 0) as paid_orders,
        COALESCE(SUM(CASE WHEN paystack_paid_at IS NOT NULL THEN total_amount ELSE 0 END), 0) as paid_revenue,
        COALESCE(SUM(CASE WHEN paystack_status = 'pending' THEN 1 ELSE 0 END), 0) as pending_orders,
        COALESCE(SUM(CASE WHEN paystack_status = 'failed' THEN 1 ELSE 0 END), 0) as failed_orders,
        COALESCE(SUM(CASE WHEN paystack_status = 'abandoned' THEN 1 ELSE 0 END), 0) as abandoned_orders
     FROM orders
     WHERE paystack_status != 'deleted' OR paystack_paid_at IS NOT NULL"
);
$rev = $revStmt->fetch();
/* ★ PERF-11 review (Task 45): the audit asked for every `paystack_status
 * != 'deleted'` to be rewritten as a seekable IN (...) list. That rewrite is
 * deliberately NOT applied here, for two provable reasons:
 *   1. SEMANTICS — BL-18 (Task 30) deliberately shaped this predicate as
 *      `status != 'deleted' OR paid_at IS NOT NULL` so soft-deleted PAID
 *      orders stay in the historical metrics. An IN ('pending','paid',
 *      'failed','abandoned') rewrite would DROP those rows again — a
 *      functional regression of a fixed bug.
 *   2. PLAN — this query is a whole-table aggregate (COUNT/SUM over ~all
 *      rows, no narrow filter): the optimal plan is a full scan regardless
 *      of predicate form, so no index can help it. The audit's index
 *      lever that DOES apply is orders.discount_code: added as
 *      idx_orders_discount_code by install.php (PERF-11 block) — it turns
 *      the discount-usage JOIN + the WF-07 orphaned-code NOT EXISTS from
 *      O(codes × orders) into index lookups.
 * The 30-day trend query already seeks idx_orders_created on its WHERE
 * (created_at >= DATE_SUB(...)) and groups a bounded ≤30-day subset, so the
 * DATE(o.created_at) GROUP BY filesort there is over at most a month of
 * rows — the generated-column rewrite the audit sketched would add schema
 * risk (MariaDB/generated-column version differences on shared hosting) for
 * a negligible gain. */

/* ---- Top products by quantity sold --------------------------------------
 * ★ BL-05 fix: GROUP BY oi.product_id only (was oi.product_id, oi.name).
 *   The old grouping treated each variant as a separate product because
 *   payments.php builds order_items.name as `product.name + ' (' +
 *   variant.name + ')'` — so "Oud Royale (50ml)" and "Oud Royale (100ml)"
 *   were two distinct groups. The dashboard's "Top Products" list was
 *   actually a "Top Product-Variant Combinations" list.
 *
 * Fix: GROUP BY oi.product_id only, and pull the live product name via
 *   LEFT JOIN products (no variant suffix). COALESCE(MAX(p.name),
 *   MAX(oi.name)) falls back to the snapshot name when the product was
 *   deleted (oi.product_id IS NULL after FK ON DELETE SET NULL). MAX()
 *   wrapping is for MySQL 5.7+ strict-mode compliance (ONLY_FULL_GROUP_BY
 *   rejects bare non-aggregated non-grouped columns — MAX() makes it
 *   aggregated). Same shape for scent.
 *
 * Response contract preserved: dashboard.js renderTopProducts reads
 *   p.productId, p.name, p.scent, p.totalQty, p.totalRevenue, p.orderCount
 *   (lines 1849-1860) — same fields, same keys, just-better values. */
$topStmt = db()->query(
    // ★ Migration 2026-09-26: was `oi.name`, `oi.scent`, `oi.qty`, `oi.price`
    //   but order_items schema columns are `product_name`, `variant_name`,
    //   `unit_price`, `quantity` (no `scent` column at all — scent lives
    //   on the `products` table, fetched via the LEFT JOIN). The old query
    //   threw `SQLITE_ERROR: no such column: oi.name` on every analytics
    //   load → dashboard's Top Products widget 500'd.
    "SELECT
        oi.product_id,
        COALESCE(MAX(p.name), MAX(oi.product_name)) as name,
        COALESCE(MAX(p.scent), MAX(oi.variant_name)) as scent,
        SUM(oi.quantity) as total_qty,
        SUM(oi.quantity * oi.unit_price) as total_revenue,
        COUNT(DISTINCT o.id) as order_count
     FROM order_items oi
     JOIN orders o ON o.id = oi.order_id
     LEFT JOIN products p ON p.id = oi.product_id
     WHERE o.paystack_paid_at IS NOT NULL
     GROUP BY oi.product_id
     ORDER BY total_qty DESC
     LIMIT 10"
);
$topProducts = $topStmt->fetchAll();

/* ---- 30-day trend (order count + revenue per day) ----------------------
 * ★ BLIND-SPOT fix (BL-06 parallel): the trend's `order_count` was
 *   inflated the same way BL-06's customer counts were — `COUNT(*)` over
 *   ALL non-deleted orders (pending + paid + failed + abandoned). The
 *   `revenue` column already correctly filtered to paid inside the SUM
 *   CASE, so the dashboard's trend bars showed an inconsistent pair:
 *   "5 orders · GHS 1,500" where 4 of the 5 orders were abandoned and
 *   only 1 actually paid GHS 1,500.
 *
 * Fix: change `AND o.paystack_status != 'deleted'` → `AND o.paystack_status
 *   = 'paid'` so order_count matches revenue (both paid-only). The
 *   dashboard's trend tooltip (dashboard.js renderTrendChart line 1829:
 *   d.date + ' · ' + d.orders + ' orders · ' + formatPrice(d.revenue))
 *   now reads consistently. The 30-day window is preserved (created_at
 *   predicate unchanged) — only the status filter is tightened.
 * ★ BL-18 fix: change `= 'paid'` → `paystack_paid_at IS NOT NULL` so
 *   soft-deleted PAID orders (status='deleted' but paid_at IS NOT NULL)
 *   still contribute to the trend. A paid order from 5 days ago that
 *   the admin soft-deletes today should NOT retroactively drop from
 *   last week's trend bar — it was a real paid order on that day.
 *   The `revenue` SUM CASE also uses `paystack_paid_at IS NOT NULL` for
 *   consistency. */
$trendStmt = db()->query(
    "SELECT
        DATE(o.created_at) as date,
        COUNT(*) as order_count,
        COALESCE(SUM(CASE WHEN o.paystack_paid_at IS NOT NULL THEN o.total_amount ELSE 0 END), 0) as revenue
     FROM orders o
     WHERE o.created_at >= date('now', '-29 days')
       AND o.paystack_paid_at IS NOT NULL
     GROUP BY DATE(o.created_at)
     ORDER BY date ASC"
);
$trendRows = $trendStmt->fetchAll();

// Fill in missing days (days with no orders → 0 count, 0 revenue).
$trend = [];
for ($i = 29; $i >= 0; $i--) {
    $date = date('Y-m-d', strtotime("-$i days"));
    $found = null;
    foreach ($trendRows as $row) {
        if ($row['date'] === $date) { $found = $row; break; }
    }
    $trend[] = [
        'date'   => $date,
        'orders' => $found ? (int)$found['order_count'] : 0,
        'revenue' => $found ? (float)$found['revenue'] : 0.0,
    ];
}

/* ---- Customer insights --------------------------------------------------
 * ★ BL-06 fix: totalCustomers + returningCustomers now filter to
 *   paid orders (was `!= 'deleted'`). A phone number that placed two
 *   abandoned orders and zero paid orders was counted as a "returning
 *   customer" — the dashboard's "Returning" / "Repeat Rate" stat cards
 *   were inflated by cart-abandonment, not by actual repeat purchases.
 *   Same root cause as the audit's BL-06 entry.
 * ★ BLIND-SPOT fix (parallel to BL-06): the topCustomers query below had
 *   the SAME `!= 'deleted'` predicate. The `total_spent` SUM already
 *   filtered to paid inside CASE WHEN, but `order_count` was `COUNT(*)`
 *   over all non-deleted orders — so a customer with 2 abandoned + 1
 *   paid showed "3 orders · GHS X" (inflated count). Aligning the WHERE
 *   to paid-only makes order_count and total_spent consistent.
 *   first_order / last_order now also reflect only paid orders (correct
 *   — the admin wants to see when the customer first PAID, not when
 *   they first abandoned).
 * ★ BL-12 fix: customer_name + customer_email were bare (non-aggregated,
 *   non-grouped) columns on a `GROUP BY customer_phone` query. On MySQL
 *   with `ONLY_FULL_GROUP_BY` (default since 5.7.5), this throws
 *   `ERROR 1140: In aggregated query without GROUP BY, expression #N of
 *   SELECT list is not in GROUP BY clause and contains nonaggregated
 *   column`. On permissive installs, MySQL returned an arbitrary
 *   name/email from the grouped rows — possibly an outdated name from
 *   an old order, or a typo from an abandoned cart. Wrapping both in
 *   MAX() makes the query deterministic + strict-mode compliant (the
 *   MAX of a set of identical-or-mostly-identical strings is the most
 *   recently-seen value; for a phone-number-grouped set, all rows have
 *   the same name/email in practice — but MAX() is still the correct
 *   aggregate shape so the SQL parser is happy).
 * ★ BL-18 fix: all three customer queries (topCustomers, totalCustomers,
 *   returningCustomers) now use `paystack_paid_at IS NOT NULL` instead
 *   of `paystack_status = 'paid'` so soft-deleted PAID orders still
 *   count. If a customer placed 2 paid orders + the admin soft-deletes
 *   one for cleanup, the customer should still be counted as a
 *   "returning customer" (they paid twice historically). The `total_spent`
 *   inside the SUM CASE also uses `paystack_paid_at IS NOT NULL` so the
 *   soft-deleted paid order's revenue still contributes to the
 *   customer's total_spent. */
$custStmt = db()->query(
    "SELECT
        customer_phone,
        MAX(customer_name) as customer_name,
        MAX(customer_email) as customer_email,
        COUNT(*) as order_count,
        SUM(CASE WHEN paystack_paid_at IS NOT NULL THEN total_amount ELSE 0 END) as total_spent,
        MIN(created_at) as first_order,
        MAX(created_at) as last_order
     FROM orders
     WHERE paystack_paid_at IS NOT NULL
     GROUP BY customer_phone
     ORDER BY total_spent DESC
     LIMIT 10"
);
$topCustomers = $custStmt->fetchAll();

$totalCustomers = db()->query(
    "SELECT COUNT(DISTINCT customer_phone) FROM orders WHERE paystack_paid_at IS NOT NULL"
)->fetchColumn();

$returningCustomers = db()->query(
    "SELECT COUNT(*) FROM (
        SELECT customer_phone FROM orders
        WHERE paystack_paid_at IS NOT NULL
        GROUP BY customer_phone
        HAVING COUNT(*) > 1
    ) t"
)->fetchColumn();

/* ---- Discount usage -----------------------------------------------------
 * ★ BL-18 fix: the LEFT JOIN's ON clause now uses `o.paystack_paid_at IS
 *   NOT NULL` instead of `o.paystack_status = 'paid'` so soft-deleted PAID
 *   orders still contribute to the discount code's `total_discount_given`
 *   + `order_count`. A soft-deleted paid order that used WELCOME10 should
 *   still show in the "Discount Code Usage" section (the code WAS used,
 *   the discount WAS given — the admin just soft-deleted the order for
 *   cleanup, the historical fact of the discount usage doesn't change). */
$discStmt = db()->query(
    // ★ Migration 2026-09-26: was `dc.type, dc.value` but schema columns
    //   are `discount_type`, `discount_value`. Aliased so the rest of the
    //   function (which reads `$d['type']`, `$d['value']`) keeps working.
    "SELECT
        dc.code, dc.discount_type AS type, dc.discount_value AS value, dc.used_count,
        COALESCE(SUM(o.discount_amount), 0) as total_discount_given,
        COUNT(o.id) as order_count
     FROM discount_codes dc
     LEFT JOIN orders o ON o.discount_code = dc.code AND o.paystack_paid_at IS NOT NULL
     GROUP BY dc.id, dc.code, dc.discount_type, dc.discount_value, dc.used_count
     ORDER BY dc.used_count DESC
     LIMIT 5"
);
$discountUsage = $discStmt->fetchAll();

/* ★ WF-07 fix: hard-deleting a discount code (discounts.php handle_delete
 *   runs DELETE FROM discount_codes) used to erase that code from this
 *   report entirely — the query above starts from discount_codes and LEFT
 *   JOINs orders, so a deleted code has no row to join FROM and its paid
 *   orders (which still carry orders.discount_code = 'WELCOME10') silently
 *   dropped out of the analytics. The dashboard's delete dialog even
 *   promised the history survives.
 *
 * Fix: a second query collects the ORPHANED usage — orders whose
 * discount_code no longer matches any discount_codes row (and is not
 * NULL/empty). Each orphaned code becomes its own row with the SAME
 * response keys (code/type/value/usedCount/totalDiscountGiven/orderCount),
 * but with type/value unknown (the row is gone — the snapshot in
 * order_items doesn't carry the code metadata) and `deleted: true` so the
 * dashboard can badge it. Merged into discountUsage, re-sorted by
 * usedCount DESC, capped to the same LIMIT 5. */
$orphanStmt = db()->query(
    "SELECT
        o.discount_code as code,
        COUNT(o.id) as order_count,
        COALESCE(SUM(o.discount_amount), 0) as total_discount_given
     FROM orders o
     WHERE o.discount_code IS NOT NULL AND o.discount_code != ''
       AND o.paystack_paid_at IS NOT NULL
       AND NOT EXISTS (SELECT 1 FROM discount_codes dc WHERE dc.code = o.discount_code)
     GROUP BY o.discount_code
     ORDER BY order_count DESC
     LIMIT 5"
);
foreach ($orphanStmt->fetchAll() as $o) {
    $discountUsage[] = [
        'code'                 => $o['code'],
        'type'                 => null,
        'value'                => null,
        'used_count'           => (int)$o['order_count'],  // best available proxy: paid orders that used it
        'total_discount_given' => (float)$o['total_discount_given'],
        'order_count'          => (int)$o['order_count'],
        'deleted'              => true,
    ];
}
usort($discountUsage, function ($a, $b) {
    // ★ SQLITE NOTE (2026-09-26) m7: this `<=>` is PHP's spaceship operator
    //   (PHP 7.0+), NOT MySQL's `<=>` SQL NULL-safe equality operator. The
    //   _notifications.php migration replaced the SQL `<=>` with SQLite's
    //   `IS`. Don't confuse the two — this one sorts descending by used_count.
    return $b['used_count'] <=> $a['used_count'];
});
$discountUsage = array_slice($discountUsage, 0, 5);

} catch (\PDOException $e) {
    // ★ RT-14 fix: catch any PDOException from the analytics queries.
    //   Return a clean JSON 500 with the specific error message + a
    //   suggestion to re-run install.php (the most common cause is a
    //   missing table/column from an upgrade that skipped install.php).
    // ★ BS-5 fix (Task 44, WF batch blind-spot): the previous batch's edit
    //   left a DANGLING string fragment on the line after the json_err()
    //   call — a bare `'. Please re-run ...', 500);` statement that is a
    //   PHP PARSE ERROR (a script can't start a statement with a string
    //   literal followed by a comma). The whole file failed to compile,
    //   so EVERY analytics request fatals with an unstyled HTTP 500 HTML
    //   page and the dashboard's Analytics tab never loads. Proof:
    //   the fragment was the tail of the pre-RT-14 message that the
    //   batch's search-and-replace mangled. Removing the orphan line
    //   restores the intended single json_err() call.
    error_log('[morbi] Analytics query failed: ' . $e->getMessage());
    json_err('Analytics query failed. Please re-run api/install.php to ensure all tables and columns exist.', 500);
}

/* ---- Build response ----------------------------------------------------- */
json_ok([
    'revenue' => [
        'totalOrders'      => (int)$rev['total_orders'],
        'totalRevenue'      => (float)$rev['total_revenue'],
        'avgOrderValue'     => (float)$rev['avg_order_value'],
        'totalDiscountGiven' => (float)$rev['total_discount_given'],
        'paidOrders'        => (int)$rev['paid_orders'],
        'paidRevenue'       => (float)$rev['paid_revenue'],
        'pendingOrders'     => (int)$rev['pending_orders'],
        'failedOrders'      => (int)$rev['failed_orders'],
        'abandonedOrders'   => (int)$rev['abandoned_orders'],
    ],
    'topProducts' => array_map(function ($p) {
        return [
            'productId'   => $p['product_id'] !== null ? (int)$p['product_id'] : null,
            'name'        => $p['name'],
            'scent'       => $p['scent'],
            'totalQty'    => (int)$p['total_qty'],
            'totalRevenue' => (float)$p['total_revenue'],
            'orderCount'  => (int)$p['order_count'],
            // ★ WF-06 fix: mark the aggregated row whose product_id is NULL
            //   (the product(s) behind these order_items were deleted — the
            //   FK ON DELETE SET NULL preserved the snapshot rows but severed
            //   the linkage). BL-05's COALESCE already falls back to the
            //   snapshot name; without this flag the dashboard rendered the
            //   orphan row exactly like a live product with no way to tell
            //   it apart. The dashboard renders a "(deleted product)" badge
            //   for deleted:true rows.
            'deleted'     => $p['product_id'] === null,
        ];
    }, $topProducts),
    'trend' => $trend,
    'customerInsights' => [
        'totalCustomers'    => (int)$totalCustomers,
        'returningCustomers' => (int)$returningCustomers,
        'topCustomers'      => array_map(function ($c) {
            // ★ SEC-14 fix: mask PII — phone and email are masked so a
            //   compromised admin session can't exfiltrate raw customer
            //   contact details. Phone: last 4 digits visible
            //   (+233***1234). Email: first char + domain visible
            //   (j***@example.com). Name is left unmasked (the admin
            //   needs to see it for customer service).
            $phone = (string)$c['customer_phone'];
            $maskedPhone = strlen($phone) > 4
                ? substr($phone, 0, -4) . '***' . substr($phone, -4)
                : '***';
            $email = (string)$c['customer_email'];
            $atPos = strpos($email, '@');
            $maskedEmail = $atPos !== false && $atPos > 0
                ? substr($email, 0, 1) . '***' . substr($email, $atPos)
                : '***';
            return [
                'phone'      => $maskedPhone,
                'name'       => $c['customer_name'],
                'email'      => $maskedEmail,
                'orderCount' => (int)$c['order_count'],
                'totalSpent' => (float)$c['total_spent'],
                'firstOrder' => $c['first_order'],
                'lastOrder'  => $c['last_order'],
            ];
        }, $topCustomers),
    ],
    'discountUsage' => array_map(function ($d) {
        return [
            'code'               => $d['code'],
            // ★ WF-07 fix: type/value are NULL for deleted-code rows (the
            //   discount_codes row is gone — there is nothing to read them
            //   from). Cast carefully: (float)null would silently become
            //   0.0 and the dashboard would render "GHS 0.00 off"; keep the
            //   nulls so the dashboard can render the "(deleted code)"
            //   badge instead of a bogus amount.
            'type'               => $d['type'] !== null ? (string)$d['type'] : null,
            'value'              => $d['value'] !== null ? (float)$d['value'] : null,
            'usedCount'          => (int)$d['used_count'],
            'totalDiscountGiven' => (float)$d['total_discount_given'],
            'orderCount'         => (int)$d['order_count'],
            // ★ WF-07 fix: true for orphaned (hard-deleted) code rows.
            'deleted'            => !empty($d['deleted']),
        ];
    }, $discountUsage),
]);
