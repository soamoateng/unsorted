<?php
/**
 * webhook.php — Phase 2 (Bicycle) Paystack webhook receiver.
 *
 *   POST  public (Paystack fires this; no session auth — security comes
 *         from the HMAC-SHA512 signature instead)
 *         -> 200 on success, 400/403 on signature mismatch
 *
 * What it does:
 *   1. Read the RAW request body (BEFORE any JSON parse — the HMAC is
 *      computed against the exact bytes Paystack sent).
 *   2. Read the `x-paystack-signature` header.
 *   3. Compute hash_hmac('sha512', $rawBody, PAYSTACK_SECRET_KEY) and
 *      compare via hash_equals() (timing-safe).
 *   4. If signature matches: parse the JSON, find the event type + reference,
 *      call paystack_verify($reference) to confirm the transaction status
 *      directly with Paystack (defense in depth — the webhook could be
 *      replayed; only Paystack's verify endpoint is authoritative).
 *   5. UPDATE the order row with the verified status. Idempotent — verifying
 *      an already-paid order is a no-op.
 *
 * Why no session_start(): this endpoint is hit by Paystack, not by the user's
 * browser. Starting a session would create a useless cookie file on every
 * webhook call. _bootstrap.php's session_set_cookie_params + session_start
 * is bypassed by NOT requiring _bootstrap.php directly — instead we require
 * _config.php (for the secret key) + _paystack.php (for the verify helper)
 * and a hand-rolled PDO + JSON helper. This keeps the webhook fast and
 * isolates it from session-related cookie issues.
 *
 * (If we ever need rate limiting or CSRF on this endpoint, that lives here.)
 */

// Don't load _bootstrap.php — we don't want session_start() on a webhook.
// Load _config.php directly for the constants, then define the minimal
// helpers we need (db() + json_out() + json_err() — same shapes as _bootstrap).
//
// ★ RT-01 fix: _bootstrap.php normally runs these output-hygiene directives:
//     error_reporting(E_ALL);
//     ini_set('display_errors', '0');
//     ini_set('log_errors', '1');
//     header_remove('X-Powered-By');
//   Because webhook.php deliberately skips _bootstrap.php (to avoid
//   session_start()), it also skips these directives. On hosts with
//   `display_errors=On` (XAMPP default, many cPanel configs), any PHP
//   Notice/Warning emitted during webhook processing (RT-16's Undefined
//   array key, an undefined variable, a date() timezone warning, a
//   finfo warning) is printed to stdout BEFORE _wh_json_out() echoes
//   the JSON body. The response body becomes:
//     <b>Notice</b>: ... in webhook.php on line N\n{"ok":true,...}
//   Paystack then fails to parse the JSON + retries the webhook
//   indefinitely — orders stay stuck in `pending` forever.
//
//   Fix: replicate the same output-hygiene directives here, BEFORE
//   require_once _config.php (so that any notice/warning emitted during
//   config loading is also suppressed from stdout). Errors are still
//   LOGGED (log_errors=1) — they just don't corrupt the JSON response.
error_reporting(E_ALL);
ini_set('display_errors', '0');
ini_set('log_errors', '1');
header_remove('X-Powered-By');

// ★ SEC-15 fix: webhook.php bypasses _bootstrap.php (to avoid session_start),
//   so it also bypasses set_security_headers(). The JSON responses lacked
//   Content-Security-Policy, X-Frame-Options, X-Content-Type-Options,
//   Referrer-Policy, Permissions-Policy, and HSTS. On hosts where
//   mod_headers is unavailable, webhook responses had no security headers.
//   Fix: replicate the essential security headers inline. The full
//   set_security_headers() function in _bootstrap.php includes HSTS
//   (only over HTTPS) — we skip HSTS here because the webhook is hit by
//   Paystack's servers (not browsers), and HSTS is a browser-only header.
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('Referrer-Policy: no-referrer');
header('Permissions-Policy: camera=(), microphone=(), geolocation=(), payment=()');
header("Content-Security-Policy: default-src 'none'; frame-ancestors 'none'");

// ★ WF-11 fix: load the .env parser BEFORE _config.php. The webhook
//   deliberately bypasses _bootstrap.php (no session_start()), which is
//   where _env.php is normally loaded from. Consequence: on any deployment
//   that configures secrets via a .env file (the documented cPanel path in
//   docs/DEPLOY-CPANEL.md), getenv('MORBI_PAYSTACK_SECRET_KEY') returned
//   false here and _config.php fell back to the hardcoded placeholder —
//   the placeholder check below then 500'd EVERY webhook call ("Paystack
//   secret key not configured"), so no order ever transitioned to paid via
//   the webhook even though the customer's payment succeeded (the callback
//   page's verify path DOES boot via _bootstrap.php and worked — masking
//   the breakage until the admin noticed orders stuck in `pending`).
//   _env.php is side-effect-free when no .env exists (early return) and
//   only calls putenv()/$_ENV/$_SERVER — no session, no output, safe in
//   the webhook context.
require_once __DIR__ . '/_env.php';
require_once __DIR__ . '/_config.php';
require_once __DIR__ . '/_paystack.php';
// ★ Phase 9 Batch 2 (Task 62): load _notifications.php for the
//   notify_customer_order_paid() call on the paid transition. _notifications.php
//   itself requires _mailer.php + _config.php (already loaded above).
require_once __DIR__ . '/_notifications.php';

// Minimal JSON helper (mirrors _bootstrap.php's shape but no session).
function _wh_json_out(array $payload, int $status = 200): void {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($payload);
    exit;
}

// Minimal PDO helper (same shape as _bootstrap::db()).
// ★ C2 fix (audit): _notifications.php calls db(), not _wh_db(). Without
//   this alias, notify_customer_order_paid() throws "Call to undefined
//   function db()" — the try/catch(Throwable) in the webhook swallows it,
//   so customer order-confirmation emails silently never send.
// ★ Migration 2026-09-26: was a MySQL DSN ('mysql:host=' . DB_HOST . ...)
//   but the DB is SQLite. The webhook deliberately bypasses _bootstrap.php
//   (no session_start), so it never benefited from the SQLite DSN fix in
//   _bootstrap::db(). Every Paystack webhook delivery failed to open the
//   DB → returned 500 → orders stuck in 'pending' forever even though
//   the customer paid. Now mirrors _bootstrap::db() exactly: SQLite DSN
//   + WAL mode + foreign keys + synchronous=NORMAL + busy_timeout.
function db(): PDO { return _wh_db(); }
function _wh_db(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        if (!file_exists(DB_PATH)) {
            // _bootstrap::db() would normally rebuild the file via
            // install.php, but webhook.php skips _bootstrap. For the
            // webhook, the most likely path here is a misconfigured
            // deploy (DB file deleted). Surface a 500 so the operator
            // notices; Paystack will retry the webhook.
            _wh_json_out(['ok' => false, 'error' => 'Database file not found.'], 500);
        }
        $dsn = 'sqlite:' . DB_PATH;
        try {
            $pdo = new PDO($dsn, null, null, [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ]);
            // Match _bootstrap::db() pragmas — WAL + FK + sync + busy_timeout.
            $pdo->exec('PRAGMA journal_mode = WAL');
            $pdo->exec('PRAGMA foreign_keys = ON');
            $pdo->exec('PRAGMA synchronous = NORMAL');
            $pdo->exec('PRAGMA busy_timeout = 5000');
        } catch (PDOException $e) {
            _wh_json_out(['ok' => false, 'error' => 'Database connection failed.'], 500);
        }
    }
    return $pdo;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    _wh_json_out(['ok' => false, 'error' => 'POST only.'], 405);
}

/* ---- 1. Read the RAW request body (before any parse) --------------------- */
$rawBody = file_get_contents('php://input');
if ($rawBody === false || $rawBody === '') {
    _wh_json_out(['ok' => false, 'error' => 'Empty body.'], 400);
}

/* ---- 2. Read the Paystack signature header ------------------------------- */
$sig = $_SERVER['HTTP_X_PAYSTACK_SIGNATURE'] ?? '';
if ($sig === '') {
    _wh_json_out(['ok' => false, 'error' => 'Missing x-paystack-signature header.'], 403);
}

/* ---- 3. Verify the HMAC-SHA512 signature ---------------------------------- */
// Defensive: refuse to operate if the secret key is still the placeholder.
if (!defined('PAYSTACK_SECRET_KEY') || strpos(PAYSTACK_SECRET_KEY, 'REPLACE') !== false) {
    _wh_json_out(['ok' => false, 'error' => 'Paystack secret key not configured.'], 500);
}

if (!hash_equals(hash_hmac('sha512', $rawBody, PAYSTACK_SECRET_KEY), $sig)) {
    // Don't reveal whether the body was parseable — just 403.
    _wh_json_out(['ok' => false, 'error' => 'Invalid signature.'], 403);
}

/* ---- 4. Parse the JSON + find the event ----------------------------------- */
$event = json_decode($rawBody, true);
if (!is_array($event) || empty($event['event'])) {
    _wh_json_out(['ok' => false, 'error' => 'Malformed event payload.'], 422);
}

$eventType = (string)$event['event'];

// ★ Phase 8 Batch 1 (Task 58, 2026-09-23): handle refund.* events BEFORE the
// charge-event logic. Refund events have a different shape (no order
// 'reference' at the top of data — they have data.transaction.reference +
// data.id, the Paystack refund id). Branching here keeps the rest of the
// webhook's charge-success flow untouched.
//
// Refund events Paystack fires (verified live 2026-09-23 against
// https://paystack.com/docs/refunds):
//   refund.created    → refund was created (we typically already have this
//                       row from the initiate API call; idempotent update)
//   refund.processed  → funds returned to customer's payment method
//   refund.failed     → Paystack could not process the refund (e.g.,
//                       insufficient merchant balance, expired card)
//   refund.pending    → interim status (we treat as no-op; the .processed
//                       or .failed event will follow)
//
// The local refunds table is updated by Paystack refund ID (not by order
// reference) because partial refunds share an order reference. The
// refunded_amount + paystack_status on the orders row are recomputed from
// the SUM of all non-failed refunds — same logic as api/refunds.php's
// recompute_order_refund_state(). Inlined here because webhook.php
// deliberately avoids _bootstrap.php (no session_start) and therefore
// cannot require refunds.php.
if (strpos($eventType, 'refund.') === 0) {
    handle_refund_event($event);
    return; // handle_refund_event calls _wh_json_out internally
}

// We only care about charge success + failure. Paystack fires many event
// types (transfer.success, refund.processed, etc.) but for Phase 2 (direct
// charge to merchant) only charge.* matters.
// ★ RT-16 fix: was `$reference = $event['data']['reference'] ?? '';` —
//   the `??` operator handles the null RESULT (returns ''), but the
//   WARNING is still emitted BEFORE `??` can intervene. On PHP 8, accessing
//   `['reference']` on `null` (when `$event['data']` is null, e.g. a
//   Paystack payload like `{"event":"charge.success","data":null}`)
//   emits: "Warning: Trying to access array offset on value of type null".
//   On PHP 7, it's a Notice. With the RT-01 fix (display_errors=0), the
//   Warning doesn't appear in the output — but it's still emitted to the
//   error log, AND on hosts where the RT-01 fix hasn't been deployed yet,
//   it corrupts the JSON. Fix: coalesce `$event['data']` to an empty array
//   FIRST, then access `['reference']`. `($event['data'] ?? [])` returns
//   `[]` if data is null — then `[]['reference']` returns null (no Warning
//   — accessing a non-existent key on a real array returns null silently
//   on PHP 7+), then `?? ''` returns ''.
$reference = ($event['data'] ?? [])['reference'] ?? '';
if ($reference === '') {
    // Not a charge event we know how to handle. Acknowledge so Paystack
    // doesn't keep retrying — but log nothing (we have no logger).
    _wh_json_out(['ok' => true, 'ignored' => true, 'event' => $eventType]);
}

/* ---- 5. Look up the order by reference ----------------------------------- */
// ★ Phase 8 Batch 3 (Task 60): SELECT now includes currency + total_amount so
//   the SEC-12 amount check below can compare in the CORRECT currency (the
//   order may have been charged in USD/NGN/KES/ZAR, not just GHS). The
//   Paystack verify response's `currency` field is also checked for parity.
$stmt = _wh_db()->prepare('SELECT id, paystack_status, total_amount, currency FROM orders WHERE reference = ? LIMIT 1');
$stmt->execute([$reference]);
$order = $stmt->fetch();
if (!$order) {
    // Unknown reference — could be a test from Paystack's dashboard, or a
    // legitimate order we deleted. Acknowledge so Paystack stops retrying.
    _wh_json_out(['ok' => true, 'ignored' => true, 'reason' => 'unknown_reference']);
}

// Idempotency: if the order is already terminal (paid OR deleted), no need
// to verify again. Paystack may fire the webhook multiple times for the same
// transaction.
// ★ BL-15 BLIND-SPOT fix (parallel to the orders.php verify_and_return fix):
//   the original guard only short-circuited on 'paid'. If the admin had
//   soft-deleted an order (status='deleted') and Paystack retried the
//   webhook (within the 5min/30min/2h/12h retry window per the comment
//   below at line 134), the function would proceed to paystack_verify,
//   potentially un-deleting the order. The audit notes this is less
//   critical than the customer-facing verify-on-demand path (Paystack
//   retries are time-limited; the customer's verify-on-demand is callable
//   indefinitely), but the fix is defense in depth — same shape, same
//   guard. The webhook acknowledges with `idempotent: true` so Paystack
//   stops retrying.
// ★ H1 fix (audit): idempotency check must also short-circuit on post-refund
//   states (partially_refunded, refunded). Without this, a replayed
//   charge.success webhook overwrites the refund state back to 'paid' AND
//   sends a duplicate "your order is paid" email for an already-refunded order.
if (in_array($order['paystack_status'], ['paid', 'deleted', 'partially_refunded', 'refunded'], true)) {
    _wh_json_out(['ok' => true, 'idempotent' => true, 'reference' => $reference]);
}

/* ---- 6. Call paystack_verify to confirm the status (defense in depth) ----- */
// The webhook payload contains the status, but Paystack's docs explicitly
// recommend re-verifying via the API to guard against webhook tampering
// (even though we already checked the HMAC, a leaked secret key would let
// an attacker forge events — verify puts the final authority with Paystack).
$verify = paystack_verify($reference);
if (!$verify['ok']) {
    // Paystack API failed (network, rate limit, etc.). Don't update the order
    // — leave it as pending. Paystack will retry the webhook in 5min, 30min,
    // 2h, 12h intervals; the next attempt may succeed.
    _wh_json_out(['ok' => false, 'error' => 'Verify call failed: ' . $verify['error']], 502);
}

$data = $verify['data'];
$status = $data['status'];        // 'success' | 'failed' | 'abandoned' | 'ongoing'

// ★ SEC-12 fix: verify the charged amount matches the order total. Was: no
//   amount check — if Paystack charged a different amount under the same
//   reference (Paystack-side bug, compromised account, or a future
//   server-side regression), the order would be marked 'paid' for GHS 1
//   even though the cart total was GHS 1000. Paystack's reference is bound
//   to the amount at /transaction/initialize, so this is not directly
//   exploitable today — but the defense-in-depth check is missing.
//   Fix: compare (int)$data['amount_kobo'] to
//   (int)round((float)$order['total_amount'] * 100). If they differ, the
//   order is NOT marked 'paid' — it stays 'pending' + the webhook returns
//   402 (Payment Required) so Paystack retries. The error is logged
//   server-side (SEC-08: no $e->getMessage() in the response).
//   Only check on 'success' status — failed/abandoned orders don't have a
//   meaningful amount to compare.
if ($status === 'success') {
    // ★ C1 fix (audit): paystack_verify() normalizes 'amount' to 'amount_kobo'.
    //   The old code read $data['amount'] which is undefined after normalization
    //   → always 0 → amount-mismatch check ALWAYS fired 402 → orders stuck
    //   in 'pending' forever. This was the #1 Critical bug.
    $chargedKobo = (int)($data['amount_kobo'] ?? 0);
    $expectedKobo = (int)round((float)$order['total_amount'] * 100);
    // ★ Phase 8 Batch 3 (Task 60): also verify the currency matches.
    //   Was: assumed GHS. Now: order can be charged in any Paystack-supported
    //   currency. If the verify response's currency doesn't match the order's
    //   currency, log + 402 (same as amount mismatch — defense in depth).
    $chargedCurrency  = (string)($data['currency'] ?? '');
    $expectedCurrency = (string)($order['currency'] ?? PAYSTACK_CURRENCY);
    $currencyMismatch = ($chargedCurrency !== '' && $chargedCurrency !== $expectedCurrency);
    if ($chargedKobo !== $expectedKobo || $currencyMismatch) {
        error_log('[morbi] Amount/currency mismatch for reference ' . $reference .
            ': charged=' . $chargedKobo . ' ' . $chargedCurrency .
            ', expected=' . $expectedKobo . ' ' . $expectedCurrency);
        _wh_json_out(['ok' => false, 'error' => 'Amount or currency mismatch. The charged amount/currency does not match the order record.'], 402);
    }
}

// Map Paystack's verify status to our DB status vocabulary.
$dbStatus = 'pending';
if ($status === 'success')      $dbStatus = 'paid';
elseif ($status === 'failed')   $dbStatus = 'failed';
elseif ($status === 'abandoned') $dbStatus = 'abandoned';
elseif ($status === 'ongoing') {
    // Don't update — customer is still on the Paystack page.
    _wh_json_out(['ok' => true, 'ignored' => true, 'reason' => 'ongoing']);
}

/* ---- 7. UPDATE the order row ---------------------------------------------- */
$paidAt = $data['paid_at'] ?? null;
$channel = $data['channel'] ?? null;
$fees = $data['fees_kobo'] !== null ? round((int)$data['fees_kobo'] / 100, 2) : null;

// Use a transaction so the row is updated consistently. The webhook may
// fire twice (Paystack retries); the second UPDATE is a no-op.
$pdo = _wh_db();
$pdo->beginTransaction();
try {
    $upd = $pdo->prepare(
        'UPDATE orders
         SET paystack_status = ?, paystack_channel = ?, paystack_fees = ?, paystack_paid_at = ?
         WHERE id = ? AND paystack_status != ?'
    );
    // The WHERE clause is the idempotency guard: only update if the new
    // status differs from the current one. (For 'paid' transitions we
    // always update — but the early-return above already handled the
    // already-paid case.)
    $upd->execute([$dbStatus, $channel, $fees, $paidAt, $order['id'], $dbStatus]);

    // ★ Race-condition fix: gate ALL side-effects on whether the UPDATE
    // actually matched a row. If a concurrent webhook/callback already
    // updated the status, this UPDATE matches 0 rows — so we skip the
    // stock decrement + discount count increment. This prevents
    // double-decrement / double-increment when webhook + callback race.
    $transitioned = ($upd->rowCount() > 0);

    // ★ Phase 3 Batch 4: decrement stock for each order_item, ONLY when
    // genuinely transitioning to 'paid' (not on a replayed webhook).
    // ★ BL-01 fix: if order_items.variant_id IS NOT NULL, decrement
    // product_variants.stock for that variant (variant-level inventory).
    // Otherwise decrement products.stock for the parent product (the
    // original Phase 3 Batch 4 behaviour — backward compat for orders
    // placed before variant_id was persisted, and for products without
    // variants). The MAX(stock - ?, 0) clamp prevents negative stock
    // if a race or a stock-edit-during-checkout caused the count to dip
    // below the ordered qty (defensive — the payments.php init-time check
    // should have already refused the order in that case).
    // ★ BL-14 BLIND-SPOT fix: the BL-14 fix in payments.php changed the
    //   stock CHECK so that a NULL variant.stock falls back to the parent
    //   product's stock. The decrement loop MUST mirror this — when
    //   variant_id IS NOT NULL but the variant's stock IS NULL (the
    //   "unlimited" convention), the check ran against product.stock, so
    //   the decrement must ALSO drain product.stock (otherwise
    //   product.stock is checked-but-never-decremented → over time
    //   multiple orders all see "5 in stock" even after 5 sales). We
    //   LEFT JOIN product_variants to fetch variant_stock alongside
    //   variant_id, then branch: variant.stock NOT NULL → drain variant;
    //   variant.stock IS NULL → drain parent product (fallback). When
    //   variant_id IS NULL (no variant), drain the parent product as
    //   before.
    if ($dbStatus === 'paid' && $transitioned) {
        // ★ Migration 2026-09-26: was `oi.qty` — order_items schema column
        //   is `quantity`, not `qty`. This SELECT was throwing
        //   `SQLITE_ERROR: no such column: oi.qty` inside the webhook's
        //   post-update transaction → rollback → order stayed 'pending'
        //   even though the customer paid.
        $itemsStmt = $pdo->prepare(
            'SELECT oi.product_id, oi.variant_id, oi.quantity AS qty, pv.stock AS variant_stock
             FROM order_items oi
             LEFT JOIN product_variants pv ON pv.id = oi.variant_id
             WHERE oi.order_id = ? AND (oi.product_id IS NOT NULL OR oi.variant_id IS NOT NULL)'
        );
        $itemsStmt->execute([$order['id']]);
        $decProduct = $pdo->prepare(
            // ★ SQLITE FIX (2026-09-26): GREATEST() does NOT exist in SQLite
            //   (it's a MySQL/PostgreSQL function). Was throwing
            //   "no such function: GREATEST" inside the webhook's paid-order
            //   transaction → rollback → order stayed 'pending' forever.
            //   SQLite's scalar MAX(a, b) is the correct equivalent (when
            //   called with 2+ args, MAX returns the largest — same as
            //   GREATEST). Verified at runtime against SQLite 3.53.1.
            'UPDATE products SET stock = MAX(stock - ?, 0)
             WHERE id = ? AND stock IS NOT NULL'
        );
        $decVariant = $pdo->prepare(
            'UPDATE product_variants SET stock = MAX(stock - ?, 0)
             WHERE id = ? AND stock IS NOT NULL'
        );
        foreach ($itemsStmt->fetchAll() as $it) {
            // ★ BL-14 BLIND-SPOT: variant.stock NOT NULL → drain variant;
            //   variant.stock IS NULL → drain parent product (fallback,
            //   mirrors the check in payments.php). The previous code
            //   branched purely on variant_id presence, which left
            //   product.stock unchecked-against-but-never-decremented when
            //   the variant had NULL stock.
            $vid = $it['variant_id'] !== null ? (int)$it['variant_id'] : 0;
            $variantStock = $it['variant_stock'] ?? null;
            if ($vid > 0 && $variantStock !== null) {
                // Variant tracks its own stock → drain variant.
                $decVariant->execute([(int)$it['qty'], $vid]);
            } else if ($it['product_id'] !== null) {
                // Either no variant, OR variant has NULL stock (unlimited)
                // → drain the parent product (fallback per BL-14 fix).
                $decProduct->execute([(int)$it['qty'], (int)$it['product_id']]);
            }
        }
    }

    // ★ BL-10 fix: release the discount-code reservation when the order
    //   transitions to a non-paid terminal state (failed / abandoned). The
    //   reservation was incremented atomically at order creation in
    //   payments.php (line ~355-372). If the customer never pays, the
    //   reservation must be released so the code's `used_count` doesn't
    //   slowly drain on abandoned carts. The increment-on-paid path that
    //   used to live here is REMOVED — used_count is now incremented at
    //   creation (reservation), not at payment confirmation.
    //   Defense in depth: MAX(used_count - 1, 0) prevents negative
    //   used_count if a concurrent webhook already decremented (race).
    //   The decrement is conditional on the order actually having a
    //   discount_code (no-op for orders without a code).
    //   ★ SQLITE FIX (2026-09-26): GREATEST() → MAX() (SQLite scalar form).
    if (in_array($dbStatus, ['failed', 'abandoned'], true) && $transitioned) {
        $dcStmt = $pdo->prepare('SELECT discount_code FROM orders WHERE id = ? LIMIT 1');
        $dcStmt->execute([$order['id']]);
        $dcRow = $dcStmt->fetch();
        if ($dcRow && !empty($dcRow['discount_code'])) {
            $rel = $pdo->prepare(
                'UPDATE discount_codes
                 SET used_count = MAX(used_count - 1, 0)
                 WHERE code = ?'
            );
            $rel->execute([$dcRow['discount_code']]);
        }
    }

    $pdo->commit();
} catch (Exception $e) {
    $pdo->rollBack();
    error_log('[morbi] Webhook DB update failed: ' . $e->getMessage()); _wh_json_out(['ok' => false, 'error' => 'DB update failed. Check the server error log for details.'], 500);
}

// ★ Phase 9 Batch 2 (Task 62): send the customer order-paid notification
//   AFTER the transaction commits + only if the order genuinely transitioned
//   to 'paid' this request ($transitioned=true). On a replayed webhook
//   (already-paid order, BL-15 short-circuit), $transitioned=false → no
//   notification attempt (also: notification_log's UNIQUE KEY would catch
//   a duplicate insert even if we did try).
//
//   The notification is fire-and-forget — failures are logged to
//   notification_log (status='failed') but don't affect the webhook's 200
//   response to Paystack. The order is already marked paid; the email is
//   a courtesy, not a payment-gating step.
if ($dbStatus === 'paid' && !empty($transitioned)) {
    try {
        notify_customer_order_paid((int)$order['id']);
    } catch (Throwable $e) {
        // Defensive: _notifications.php catches its own errors, but a
        // catastrophic failure (DB down mid-notification) shouldn't break
        // the webhook. Log + continue to the 200 response.
        error_log('[morbi] notify_customer_order_paid threw for order ' . $order['id'] . ': ' . $e->getMessage());
    }
}

_wh_json_out([
    'ok'        => true,
    'reference' => $reference,
    'status'    => $dbStatus,
    'updated'   => $upd->rowCount() > 0,
]);

/* ──────────────────────────────────────────────────────────────────────────
 * ★ Phase 8 Batch 1 (Task 58, 2026-09-23): refund.* event handler.
 *
 * Updates the local refunds table when Paystack sends a refund status
 * change event. Called from the main flow ABOVE when the event type starts
 * with "refund.". Returns via _wh_json_out (no fall-through).
 *
 * Event shape (verified live against Paystack docs + mctaba.com July 2026):
 *   {
 *     "event": "refund.processed" | "refund.failed" | "refund.created" | "refund.pending",
 *     "data": {
 *       "id": 12345,                           ← Paystack refund ID
 *       "amount": 5000,                         ← subunit
 *       "currency": "GHS",
 *       "status": "processed" | "failed" | "pending" | "processing",
 *       "transaction": { "reference": "morbi-..." },
 *       "merchant_note": "...",
 *       "customer_note": "...",
 *       "createdAt": "2026-09-23T...",
 *       "settledAt": "2026-09-23T..." or null
 *     }
 *   }
 *
 * Idempotency: if the refund row's status already matches the event's
 * status, the UPDATE matches 0 rows — the order's refunded_amount is
 * NOT recomputed (no change). Otherwise, update the refund row, then
 * recompute the order's refunded_amount + paystack_status from the SUM
 * of non-failed refunds.
 * ────────────────────────────────────────────────────────────────────────── */
function handle_refund_event(array $event): void {
    $data = $event['data'] ?? [];
    if (!is_array($data)) {
        _wh_json_out(['ok' => false, 'error' => 'Malformed refund event data.'], 422);
    }

    $paystackRefundId = isset($data['id']) ? (int)$data['id'] : 0;
    if ($paystackRefundId <= 0) {
        // No refund id — can't match to a local row. Acknowledge so Paystack
        // doesn't keep retrying.
        _wh_json_out(['ok' => true, 'ignored' => true, 'reason' => 'no_refund_id']);
    }

    $newStatus = $data['status'] ?? 'pending';
    $settledAt = $data['settledAt'] ?? ($data['settled_at'] ?? null);

    // Map Paystack's refund.* event to the local refunds.status column.
    // The webhook's $newStatus from data.status is authoritative — Paystack
    // sets it to match the event type (refund.processed → status='processed').
    $validStatuses = ['pending', 'processing', 'processed', 'failed'];
    if (!in_array($newStatus, $validStatuses, true)) {
        // Unknown status — log + ignore (don't update with garbage).
        error_log('[morbi] Webhook: unknown refund status "' . $newStatus .
            '" for Paystack refund id ' . $paystackRefundId);
        _wh_json_out(['ok' => true, 'ignored' => true, 'reason' => 'unknown_status']);
    }

    $pdo = _wh_db();

    // Look up the local refund row by Paystack refund ID.
    $stmt = $pdo->prepare(
        'SELECT id, order_id, status FROM refunds WHERE paystack_refund_id = ? LIMIT 1'
    );
    $stmt->execute([$paystackRefundId]);
    $refund = $stmt->fetch();

    if (!$refund) {
        // Refund exists on Paystack but not in our local table. This can
        // happen if the refund was initiated directly on the Paystack
        // dashboard (not via our api/refunds.php). Acknowledge so Paystack
        // stops retrying, but don't insert a row — we have no initiated_by
        // admin to credit, and we don't know the original amount in major
        // unit (Paystack's payload has it in subunit; converting requires
        // knowing the currency's subunit factor, which for GHS is 100 but
        // could differ for USD/EUR). The order's refunded_amount won't
        // reflect this refund — admin must manually reconcile.
        error_log('[morbi] Webhook: refund ' . $paystackRefundId .
            ' not found in local table (likely initiated on Paystack dashboard).');
        _wh_json_out(['ok' => true, 'ignored' => true, 'reason' => 'no_local_refund_row']);
    }

    // Idempotency: if the status hasn't changed, no-op.
    if ($refund['status'] === $newStatus) {
        _wh_json_out(['ok' => true, 'idempotent' => true, 'refund_id' => (int)$refund['id']]);
    }

    // Update the refund row + recompute the order's refund state in a
    // transaction. The recompute reads the SUM of all non-failed refunds
    // for the order, so the order's refunded_amount + paystack_status stay
    // correct even if a previous refund's status changed too.
    $pdo->beginTransaction();
    try {
        $upd = $pdo->prepare(
            'UPDATE refunds SET status = ?, settled_at = ? WHERE id = ? AND status != ?'
        );
        $upd->execute([$newStatus, $settledAt, $refund['id'], $newStatus]);

        _wh_recompute_order_refund_state((int)$refund['order_id']);

        $pdo->commit();
    } catch (Exception $e) {
        $pdo->rollBack();
        error_log('[morbi] Webhook: refund update failed for refund ' .
            $paystackRefundId . ': ' . $e->getMessage());
        _wh_json_out(['ok' => false, 'error' => 'Refund update failed.'], 500);
    }

    _wh_json_out([
        'ok'        => true,
        'refund_id' => (int)$refund['id'],
        'status'    => $newStatus,
        'updated'   => $upd->rowCount() > 0,
    ]);
}

/**
 * Recompute orders.refunded_amount + orders.paystack_status from the SUM
 * of non-failed refunds. Mirrors api/refunds.php's
 * recompute_order_refund_state() — duplicated here because webhook.php
 * cannot require refunds.php (no session_start, no _bootstrap.php).
 *
 * Logic:
 *   - refunded_amount = SUM(amount) WHERE status IN ('pending','processing','processed')
 *   - if refunded_amount >= total_amount → 'refunded'
 *   - if 0 < refunded_amount < total_amount → 'partially_refunded'
 *   - if refunded_amount == 0 (all refunds failed) → restore 'paid'
 */
function _wh_recompute_order_refund_state(int $orderId): void {
    $pdo = _wh_db();

    $sumStmt = $pdo->prepare(
        "SELECT COALESCE(SUM(amount), 0) AS total
         FROM refunds
         WHERE order_id = ? AND status IN ('pending', 'processing', 'processed')"
    );
    $sumStmt->execute([$orderId]);
    $refundedAmount = (float)$sumStmt->fetchColumn();

    $orderStmt = $pdo->prepare('SELECT total_amount FROM orders WHERE id = ? LIMIT 1');
    $orderStmt->execute([$orderId]);
    $totalAmount = (float)$orderStmt->fetchColumn();

    if (bccomp((string)$refundedAmount, (string)$totalAmount, 2) >= 0) {
        $newStatus = 'refunded';
    } elseif ($refundedAmount > 0) {
        $newStatus = 'partially_refunded';
    } else {
        $newStatus = 'paid';
    }

    // ★ C3 fix (audit): guard against overwriting 'deleted' paystack_status.
    //   A refund webhook on a soft-deleted order would un-delete it by
    //   setting paystack_status to 'refunded'/'partially_refunded'/'paid'.
    //   The WHERE clause now skips deleted orders entirely.
    $updStmt = $pdo->prepare(
        "UPDATE orders SET refunded_amount = ?, paystack_status = ? WHERE id = ? AND paystack_status NOT IN ('deleted')"
    );
    $updStmt->execute([$refundedAmount, $newStatus, $orderId]);
}
