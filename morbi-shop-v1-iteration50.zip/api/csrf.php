<?php
/**
 * csrf.php — Phase 3 (Motorcycle) CSRF token getter.
 *
 *   GET  public  -> { token: "..." }
 *
 * Returns the per-session CSRF token. The frontend (js/store.js) fetches
 * this on init() and on login() (because login.php calls session_regenerate_id,
 * which mints a new token). The token is then attached as X-CSRF-Token on
 * every state-changing request (POST/PUT/DELETE) by the api() helper.
 *
 * Public endpoint (no auth guard): the CSRF token is needed BEFORE the user
 * signs in — login.php itself is exempt (pre-auth, no session), but every
 * subsequent admin write needs the token, and the dashboard's first action
 * after login might be a write. So we hand out the token to anyone who asks.
 * The token is not a secret — its security comes from being unguessable +
 * bound to the session cookie. SameSite=Lax means a cross-site request can't
 * ride the session cookie, so an attacker can't fetch a token for the victim's
 * session.
 *
 * Token rotation:
 *   - Lazy generation: first call mints $_SESSION['csrf_token'].
 *   - Login: session_regenerate_id(true) creates a fresh session, so the next
 *     csrf.php call mints a new token (the old one is gone with the old session).
 *   - Logout: session_destroy() — the next csrf.php call (after a new
 *     session_start in _bootstrap.php) mints yet another new token.
 */

require __DIR__ . '/_bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    json_err('GET only.', 405);
}

json_ok(['token' => csrf_token()]);
