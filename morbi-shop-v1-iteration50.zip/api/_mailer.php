<?php
/**
 * _mailer.php — server-side SMTP helper (Phase 3, "Motorcycle", Batch 3).
 *
 * Single Responsibility: wrap PHPMailer so forgot-password.php doesn't
 * duplicate SMTP boilerplate. PHPMailer is placed MANUALLY in
 * vendor/phpmailer/ (no composer — cPanel shared hosting constraint).
 *
 * Blocked from direct web access by api/.htaccess (the leading underscore
 * matches the `^_` FilesMatch rule — same convention as _config.php and
 * _paystack.php).
 *
 * One operation:
 *   send_mail($to, $subject, $html_body, $text_body)
 *     Sends a MIME multipart email via SMTP using the credentials in
 *     _config.php. Returns ['ok' => bool, 'error' => string?].
 *
 * On PHPMailer-not-installed: returns ok=false with a clear message pointing
 * to docs/SMTP-SETUP.md. Better to fail loudly than silently fail to send.
 *
 * On SMTP credentials placeholder: returns ok=false with a clear message
 * pointing to api/_config.php.
 *
 * Why PHPMailer over PHP's mail():
 *   * mail() on cPanel shared hosting goes through the host's sendmail,
 *     which has no TLS, no auth, and gets flagged as spam by Gmail/Outlook.
 *   * PHPMailer supports SMTP AUTH + STARTTLS + proper MIME multipart.
 *   * PHPMailer is the de-facto standard — maintained, security-audited,
 *     used by WordPress, Drupal, Magento.
 *
 * Installation (see docs/SMTP-SETUP.md for the full walkthrough):
 *   1. Download PHPMailer 6.x from https://github.com/PHPMailer/PHPMailer
 *   2. Copy these 3 files to vendor/phpmailer/:
 *        PHPMailer.php
 *        SMTP.php
 *        Exception.php
 *   3. Edit api/_config.php → set SMTP_HOST/USER/PASS/FROM.
 *   4. Test by calling POST api/forgot-password.php with a valid admin email.
 */

require_once __DIR__ . '/_config.php';

// Reuse the JSON helpers from _bootstrap.php — but _mailer.php is included
// from endpoint files that already require _bootstrap.php, so the helpers
// are available. (Same pattern as _paystack.php.)

/**
 * Send a MIME multipart email via PHPMailer + SMTP.
 *
 * @param string $to         recipient email address
 * @param string $subject    email subject line
 * @param string $html_body  HTML body (UTF-8)
 * @param string $text_body  plain-text fallback body (UTF-8)
 * @return array ['ok' => bool, 'error' => string?]
 */
function send_mail(string $to, string $subject, string $html_body, string $text_body): array {
    // ★ SEC-16 fix: was checking only `SMTP_PASS` for 'REPLACE'. Now checks
    //   that ALL SMTP config values are non-empty. With the SEC-16 fix,
    //   SMTP_HOST/USER/PASS/FROM all default to '' — so an unconfigured
    //   install fails fast here instead of hanging on a DNS lookup for
    //   `smtp.morbi.shop` (which may not exist). The error message points
    //   to docs/SMTP-SETUP.md so the admin knows exactly what to do.
    if (!defined('SMTP_HOST') || SMTP_HOST === '' ||
        !defined('SMTP_USER') || SMTP_USER === '' ||
        !defined('SMTP_PASS') || SMTP_PASS === '' ||
        !defined('SMTP_FROM') || SMTP_FROM === '') {
        error_log('[morbi] SMTP not configured. Set MORBI_SMTP_HOST, MORBI_SMTP_USER, MORBI_SMTP_PASS, MORBI_SMTP_FROM in .env. See docs/SMTP-SETUP.md.');
        return ['ok' => false, 'error' => 'SMTP is not configured. See docs/SMTP-SETUP.md.'];
    }

    // Locate PHPMailer. The three required files live in vendor/phpmailer/.
    $phpmailerPath = __DIR__ . '/../vendor/phpmailer/PHPMailer.php';
    $smtpPath      = __DIR__ . '/../vendor/phpmailer/SMTP.php';
    $exceptionPath = __DIR__ . '/../vendor/phpmailer/Exception.php';

    if (!file_exists($phpmailerPath) || !file_exists($smtpPath) || !file_exists($exceptionPath)) {
        return ['ok' => false, 'error' => 'PHPMailer is not installed. See docs/SMTP-SETUP.md — copy PHPMailer.php + SMTP.php + Exception.php to vendor/phpmailer/.'];
    }

    // ★ RT-10 fix: was bare `require_once` + `new PHPMailer()` with no
    //   try/catch. If the PHPMailer file is deleted, renamed, or chmod'd
    //   unreadable between the `file_exists()` check (above) and the
    //   `require_once` call (below) — e.g. an admin running `composer
    //   update` mid-request, a backup tool cycling the directory, an FTP
    //   upload in progress — `require_once` emits a PHP Warning "file does
    //   not exist" (suppressed by display_errors=0, but the file doesn't
    //   load), and then `$mailer = new \PHPMailer\PHPMailer\PHPMailer(true)`
    //   throws `Error: Class not found`. Because `send_mail()` is called
    //   from `forgot-password.php` inside a normal (non-try) context, the
    //   Error propagates as a fatal error — the JSON response is HTML; the
    //   user sees a blank page or a 500.
    //   Fix: wrap the `require_once` calls + the class instantiation in a
    //   try/catch that catches `\Throwable` (catches both `Exception` and
    //   `Error` on PHP 7+). On failure, return a clean JSON error.
    try {
        require_once $phpmailerPath;
        require_once $smtpPath;
        require_once $exceptionPath;

        // PHPMailer 6.x uses namespaces; reference via the global namespace.
        $mailer = new \PHPMailer\PHPMailer\PHPMailer(true); // true = throw exceptions on error
    } catch (\Throwable $e) {
        return ['ok' => false, 'error' => 'PHPMailer could not be loaded: ' . $e->getMessage() . '. Check that vendor/phpmailer/PHPMailer.php, SMTP.php, and Exception.php exist and are readable.'];
    }

    try {
        // Server settings — TLS on port 587 (recommended); SSL on 465.
        $mailer->isSMTP();
        $mailer->Host       = SMTP_HOST;
        $mailer->Port       = (int)SMTP_PORT;
        $mailer->SMTPAuth   = true;
        $mailer->Username   = SMTP_USER;
        $mailer->Password   = SMTP_PASS;
        // Port 587 = STARTTLS (upgrades after connect); 465 = implicit SSL.
        $mailer->SMTPSecure = ((int)SMTP_PORT === 465)
            ? \PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_SMTPS
            : \PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
        // Disable verbose debug output. ★ OTH-15 fix (iteration 25): the
        //   comment used to say "Phase 4 may add a log file." Phase 4 is
        //   delivered and did NOT add a mailer log file — the existing
        //   `error_log('[morbi] ...')` calls in this file (the SMTP-failure
        //   paths below) ARE the mailer log; the PHP error log captures SMTP
        //   failures on the host's standard log surface (e.g. cPanel's
        //   `/usr/local/apache/logs/error_log`). A dedicated mailer log file
        //   is a Phase 6 (Super Car) candidate, not a pending Phase 4 deliverable.
        $mailer->SMTPDebug = 0;
        // Timeout: 10s connect, 15s read — generous for slow shared hosting.
        $mailer->Timeout = 15;

        // Recipients
        $mailer->setFrom(SMTP_FROM, SMTP_FROM_NAME);
        $mailer->addAddress($to);
        $mailer->addReplyTo(SMTP_FROM, SMTP_FROM_NAME);

        // Content — MIME multipart (HTML + plain-text fallback).
        $mailer->isHTML(true);
        $mailer->CharSet = 'UTF-8';
        $mailer->Subject = $subject;
        $mailer->Body    = $html_body;
        $mailer->AltBody = $text_body;

        $mailer->send();
        return ['ok' => true];
    } catch (\PHPMailer\PHPMailer\Exception $e) {
        // PHPMailer throws on SMTP errors (auth failure, connection refused, etc.)
        // The exception message includes the SMTP server's response — useful for
        // debugging but NEVER surface to the public (may leak SMTP internals).
        return ['ok' => false, 'error' => 'SMTP error: ' . $mailer->ErrorInfo];
    } catch (\Exception $e) {
        error_log('[morbi] Mailer error: ' . $e->getMessage()); return ['ok' => false, 'error' => 'Email could not be sent.'];
    }
}
