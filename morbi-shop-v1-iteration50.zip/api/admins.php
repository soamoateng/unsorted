<?php
/**
 * admins.php — ★ Phase 8 Batch 2 (Task 59, 2026-09-23) multi-admin management.
 *
 * CRUD endpoints for admin accounts. All routes are super_admin-only — an
 * 'admin' role cannot list, create, edit, or delete other admins (and
 * cannot promote/demote itself). This is the only tab in the dashboard
 * that's role-gated; everything else (products, orders, refunds, discounts,
 * analytics, theme) is accessible to both roles.
 *
 * Routes (all require admin session + super_admin role + CSRF on writes):
 *   GET    ?all=1                  -> list all admins (excluding password_hash)
 *   GET    ?id=N                    -> single admin detail (excluding password_hash)
 *   POST   ?action=create           -> create a new admin account
 *                                      body: { username, password, email?, role? }
 *                                      role defaults to 'admin' if not provided
 *   POST   ?action=update&id=N      -> update an existing admin's email + role
 *                                      body: { email?, role? }
 *                                      (password is NOT changed here — use ?action=set_password)
 *   POST   ?action=set_password&id=N -> change an admin's password
 *                                      body: { password }
 *                                      Updates password_changed_at to invalidate
 *                                      existing sessions on that admin (SEC-13).
 *   POST   ?action=delete&id=N      -> delete an admin account
 *                                      Refuses to delete the last super_admin
 *                                      (would lock Morbi out of the dashboard).
 *                                      Refuses to delete yourself (use a
 *                                      different admin session for that).
 *
 * Security considerations:
 *   - password_hash is NEVER returned in any response — only the boolean
 *     'has_password' is exposed (always true for current installs, but
 *     defensive for future OAuth-only accounts if added).
 *   - The 'role' field on update is validated against the allowlist
 *     ['super_admin', 'admin']. Unknown values are rejected with 422.
 *   - Deleting yourself is refused with 422 — an admin cannot lock
 *     themselves out by deleting their own account. They must use a
 *     different super_admin session to delete theirs.
 *   - Deleting the last super_admin is refused with 422 — would lock
 *     Morbi out of the Admins tab + reset-defaults permanently.
 *   - Passwords are hashed with password_hash() using PASSWORD_DEFAULT
 *     (currently bcrypt with cost 10). The hash is never logged.
 *
 * Rate limiting:
 *   - The login endpoint (api/login.php) has its own rate limit — that
 *     applies when the new admin first signs in. The create/update/delete
 *     endpoints here are super_admin-only, so they get a lighter rate limit
 *     (10/min per admin — generous because the UI doesn't bulk-action).
 */

require __DIR__ . '/_bootstrap.php';

// All routes here require admin session + super_admin role.
// require_admin() is called per-route below for clarity (some routes also
// need verify_csrf()). require_role('super_admin') is called once at the
// top because ALL routes in this file require it.
require_admin();
require_role('super_admin');

switch ($_SERVER['REQUEST_METHOD']) {
    case 'GET':  handle_get();   break;
    case 'POST': verify_csrf(); handle_post(); break;
    default:     json_err('Method not allowed.', 405);
}

/* ---- GET router ---------------------------------------------------------- */
function handle_get(): void {
    $all = (string)($_GET['all'] ?? '');
    $id  = (int)($_GET['id'] ?? 0);

    if ($all === '1') {
        handle_list_all();
        return;
    }
    if ($id > 0) {
        handle_detail($id);
        return;
    }
    json_err('Provide ?all=1 or ?id=N parameter.', 422);
}

/* ---- GET: list all admins ----------------------------------------------- */
function handle_list_all(): void {
    $stmt = db()->prepare(
        'SELECT id, username, email, role, created_at, updated_at, password_changed_at
         FROM admin_users
         ORDER BY id ASC'
    );
    $stmt->execute();
    $rows = $stmt->fetchAll();

    $admins = array_map(function ($r) {
        return map_admin($r);
    }, $rows);

    json_ok([
        'admins' => $admins,
        'count'  => count($admins),
        // Include the current admin's id + role so the frontend can:
        //   1. Disable the "Delete" button on the current admin's row.
        //   2. Show a "You" badge on the current admin's row.
        //   3. Confirm the current admin is super_admin before showing the tab
        //      (defense in depth — the API already enforces it, but the UI
        //      shouldn't show actions that would 403).
        'current_admin_id'   => (int)($_SESSION['admin_id'] ?? 0),
        'current_admin_role' => current_admin_role(),
    ]);
}

/* ---- GET: single admin detail ------------------------------------------- */
function handle_detail(int $id): void {
    $admin = fetch_admin_by_id($id);
    if (!$admin) json_err('Admin not found.', 404);

    json_ok(['admin' => map_admin($admin)]);
}

/* ---- POST router -------------------------------------------------------- */
function handle_post(): void {
    $action = (string)($_GET['action'] ?? '');
    switch ($action) {
        case 'create':       handle_create();      break;
        case 'update':       handle_update();      break;
        case 'set_password': handle_set_password(); break;
        case 'delete':       handle_delete();      break;
        default:
            json_err('Unknown action. Supported: create, update, set_password, delete.', 422);
    }
}

/* ---- POST: ?action=create ----------------------------------------------- */
function handle_create(): void {
    // Rate limit: 10 admin creates per minute per super_admin.
    $adminId = (int)($_SESSION['admin_id'] ?? 0);
    rate_limit_check('admin_create:admin:' . $adminId, 10, 60);

    $body = json_body();

    $username = body_str($body, 'username', 50);
    $password = (string)($body['password'] ?? '');
    $email    = body_str($body, 'email', 150);
    $role     = body_str($body, 'role', 30);

    // Validation
    // ★ M3 fix (audit): mb_strlen instead of strlen — a 2-char multibyte
    //   username like "áb" has strlen=3 (bytes) but mb_strlen=2 (chars),
    //   bypassing the "min 3 characters" rule.
    if ($username === '' || mb_strlen($username) < 3) {
        json_err('Username is required and must be at least 3 characters.', 422);
    }
    if (strlen($password) < 8) {
        json_err('Password must be at least 8 characters.', 422);
    }
    // Email is optional, but if provided must be valid + unique.
    if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        json_err('Email is not a valid address.', 422);
    }
    // Role defaults to 'admin' (the limited role) for new accounts — the
    // super_admin creating the account must explicitly opt-in to creating
    // another super_admin.
    if ($role === '') $role = 'admin';
    if (!in_array($role, ['super_admin', 'admin'], true)) {
        json_err('Role must be "super_admin" or "admin".', 422);
    }

    // Check username uniqueness
    $stmt = db()->prepare('SELECT id FROM admin_users WHERE username = ? LIMIT 1');
    $stmt->execute([$username]);
    if ($stmt->fetch()) {
        json_err('Username is already taken.', 409);
    }

    // Check email uniqueness (if provided)
    if ($email !== '') {
        $stmt = db()->prepare('SELECT id FROM admin_users WHERE email = ? LIMIT 1');
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            json_err('Email is already in use by another admin.', 409);
        }
    }

    $hash = password_hash($password, PASSWORD_DEFAULT);
    if ($hash === false) {
        error_log('[morbi] password_hash() failed for new admin ' . $username);
        json_err('Could not hash the password. Please try again.', 500);
    }

    $stmt = db()->prepare(
        'INSERT INTO admin_users (username, password_hash, email, role)
         VALUES (?, ?, ?, ?)'
    );
    $stmt->execute([$username, $hash, ($email !== '' ? $email : null), $role]);
    $newId = (int)db()->lastInsertId();

    $newAdmin = fetch_admin_by_id($newId);
    json_ok(['admin' => map_admin($newAdmin)], 201);
}

/* ---- POST: ?action=update ----------------------------------------------- */
function handle_update(): void {
    $id = (int)($_GET['id'] ?? 0);
    if ($id <= 0) json_err('id parameter is required for update.', 422);

    $admin = fetch_admin_by_id($id);
    if (!$admin) json_err('Admin not found.', 404);

    $body  = json_body();
    $email = body_str($body, 'email', 150);
    $role  = body_str($body, 'role', 30);

    // Validate role if provided
    if ($role !== '' && !in_array($role, ['super_admin', 'admin'], true)) {
        json_err('Role must be "super_admin" or "admin".', 422);
    }
    // Validate email if provided
    if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        json_err('Email is not a valid address.', 422);
    }

    // Check email uniqueness (excluding the current admin's row)
    if ($email !== '') {
        $stmt = db()->prepare('SELECT id FROM admin_users WHERE email = ? AND id != ? LIMIT 1');
        $stmt->execute([$email, $id]);
        if ($stmt->fetch()) {
            json_err('Email is already in use by another admin.', 409);
        }
    }

    // ★ Self-demotion guard: a super_admin cannot demote themselves if they
    //   are the LAST super_admin. This prevents accidentally locking Morbi
    //   out of the Admins tab + reset-defaults. They must promote another
    //   admin to super_admin FIRST, then demote themselves.
    // ★ M2 fix (audit): wrap the last-super_admin check + UPDATE + H4 invalidation
    //   ALL in one transaction so the check + UPDATE are atomic.
    // ★ NEW-3 fix (audit): the original M2 fix committed BEFORE the UPDATE —
    //   the check was released too early, creating a new TOCTOU gap.
    //   Now: the entire check + UPDATE + invalidation is inside one transaction.
    // ★ SQLITE NOTE (2026-09-26) m6: was "FOR UPDATE lock" — SQLite does NOT
    //   support FOR UPDATE (MySQL/PostgreSQL clause). SQLite uses database-
    //   level write locks (one writer at a time). The BEGIN TRANSACTION
    //   acquires a write lock on first write; the COUNT(*) + UPDATE inside
    //   the same transaction are serialized correctly — a concurrent request
    //   blocks on the first write until this transaction commits.
    // ★ SQLITE FIX (2026-09-26) n4: was `if ($needsLock) { beginTransaction() }`
    //   — the UPDATE at line ~300 ran OUTSIDE a transaction when $needsLock
    //   was false (no role change to admin). Now: ALWAYS wrap the UPDATE in
    //   a transaction so concurrent edits to the same admin are serialized.
    $needsLock = ($role === 'admin'
        && $admin['role'] === 'super_admin'
        && (int)$admin['id'] === (int)($_SESSION['admin_id'] ?? 0));

    // Build the UPDATE — only set fields that were provided (patch-style).
    $sets = [];
    $params = [];
    if ($email !== '') {
        $sets[] = 'email = ?';
        $params[] = $email;
    } elseif (array_key_exists('email', $body) && $body['email'] === null) {
        $sets[] = 'email = NULL';
    }
    if ($role !== '') {
        $sets[] = 'role = ?';
        $params[] = $role;
    }
    if (empty($sets)) {
        json_err('No fields to update. Provide email and/or role.', 422);
    }
    $params[] = $id;

    $pdo = db();
    // ★ n4 fix: ALWAYS begin a transaction (was: only when $needsLock).
    $pdo->beginTransaction();
    try {
        if ($needsLock) {
            $countStmt = $pdo->prepare("SELECT COUNT(*) FROM admin_users WHERE role = 'super_admin'");
            $countStmt->execute();
            $superCount = (int)$countStmt->fetchColumn();
            if ($superCount <= 1) {
                $pdo->rollBack();
                json_err(
                    'Cannot demote yourself — you are the last super_admin. ' .
                    'Promote another admin to super_admin first, then demote yourself.',
                    422
                );
            }
        }

        $stmt = $pdo->prepare('UPDATE admin_users SET ' . implode(', ', $sets) . ' WHERE id = ?');
        $stmt->execute($params);

        // ★ H4 fix (audit): when the role changes, set password_changed_at = CURRENT_TIMESTAMP
        if ($role !== '' && $role !== $admin['role']) {
            $invalidateStmt = $pdo->prepare('UPDATE admin_users SET password_changed_at = CURRENT_TIMESTAMP WHERE id = ?');
            $invalidateStmt->execute([$id]);
        }

        $pdo->commit();
    } catch (Exception $e) {
        $pdo->rollBack();
        error_log('[morbi] Admin update failed: ' . $e->getMessage());
        json_err('Could not update admin. Check the server error log for details.', 500);
    }

    // If the admin updated THEMSELVES, refresh the session's role so the
    // dashboard's tab visibility updates immediately.
    if ($id === (int)($_SESSION['admin_id'] ?? 0) && $role !== '') {
        $_SESSION['admin_role'] = $role;
        // ★ H4 fix: also refresh iat so SEC-13 doesn't immediately invalidate us
        // (we just authenticated via the existing session + CSRF token).
        $_SESSION['iat'] = time();
    }

    $updated = fetch_admin_by_id($id);
    json_ok(['admin' => map_admin($updated)]);
}

/* ---- POST: ?action=set_password ----------------------------------------- */
function handle_set_password(): void {
    $id = (int)($_GET['id'] ?? 0);
    if ($id <= 0) json_err('id parameter is required for set_password.', 422);

    $admin = fetch_admin_by_id($id);
    if (!$admin) json_err('Admin not found.', 404);

    $body = json_body();
    $password = (string)($body['password'] ?? '');
    if (strlen($password) < 8) {
        json_err('Password must be at least 8 characters.', 422);
    }

    $hash = password_hash($password, PASSWORD_DEFAULT);
    if ($hash === false) {
        error_log('[morbi] password_hash() failed for admin id ' . $id);
        json_err('Could not hash the password. Please try again.', 500);
    }

    // Update the password + password_changed_at (triggers SEC-13 session
    // invalidation for any existing sessions of THIS admin — they'll be
    // forced to re-login on their next API call).
    $stmt = db()->prepare(
        "UPDATE admin_users
         SET password_hash = ?, password_changed_at = CURRENT_TIMESTAMP
         WHERE id = ?"
    );
    $stmt->execute([$hash, $id]);

    // If the admin changed THEIR OWN password via this endpoint, refresh
    // the session's iat so the SEC-13 check doesn't immediately invalidate
    // them (they just authenticated via the existing session + CSRF token,
    // so the password change was authorized).
    if ($id === (int)($_SESSION['admin_id'] ?? 0)) {
        $_SESSION['iat'] = time();
    }

    json_ok(['id' => $id, 'password_changed' => true]);
}

/* ---- POST: ?action=delete ----------------------------------------------- */
function handle_delete(): void {
    $id = (int)($_GET['id'] ?? 0);
    if ($id <= 0) json_err('id parameter is required for delete.', 422);

    $admin = fetch_admin_by_id($id);
    if (!$admin) json_err('Admin not found.', 404);

    // ★ Self-delete guard: an admin cannot delete themselves. They would
    //   immediately lose their session and could not log back in if no
    //   other admin existed (or if they were the only super_admin).
    //   Use a different admin session to delete yours.
    if ($id === (int)($_SESSION['admin_id'] ?? 0)) {
        json_err('You cannot delete your own admin account. Ask another super_admin to do it.', 422);
    }

    // ★ Last-super_admin guard: refuse to delete the last super_admin.
    // ★ M2 fix (audit): wrap the last-super_admin check + DELETE in one transaction.
    // ★ NEW-3 fix (audit): the original M2 fix committed BEFORE the DELETE —
    //   the lock was released too early, creating a new TOCTOU gap.
    //   Now: the entire check + DELETE is inside one transaction.
    if ($admin['role'] === 'super_admin') {
        $pdo = db();
        $pdo->beginTransaction();
        try {
            $lockStmt = $pdo->prepare("SELECT COUNT(*) FROM admin_users WHERE role = 'super_admin'");
            $lockStmt->execute();
            $superCount = (int)$lockStmt->fetchColumn();
            if ($superCount <= 1) {
                $pdo->rollBack();
                json_err(
                    'Cannot delete the last super_admin account. ' .
                    'Promote another admin to super_admin first, then delete this one.',
                    422
                );
            }
            // DELETE runs inside the same transaction — lock is still held.
            $delStmt = $pdo->prepare('DELETE FROM admin_users WHERE id = ?');
            $delStmt->execute([$id]);
            $pdo->commit();
        } catch (Exception $e) {
            $pdo->rollBack();
            throw $e;
        }
    } else {
        // Non-super_admin delete — no lock needed.
        $stmt = db()->prepare('DELETE FROM admin_users WHERE id = ?');
        $stmt->execute([$id]);
    }

    // The password_resets table has FK ON DELETE CASCADE — reset tokens
    // for this admin are auto-cleaned. The refunds table also has FK ON
    // DELETE CASCADE — refund records are deleted, which would orphan the
    // audit trail. To preserve the refund audit trail, we could change the
    // FK to ON DELETE SET NULL, but that's a schema migration we'll skip
    // for now — the refund's paystack_refund_id + the Paystack dashboard
    // remain as the audit trail if the admin row is gone.
    json_ok(['deleted' => $id]);
}

/* ---- Helpers -------------------------------------------------------------- */
function fetch_admin_by_id(int $id): ?array {
    $stmt = db()->prepare(
        'SELECT id, username, email, role, created_at, updated_at, password_changed_at
         FROM admin_users
         WHERE id = ?
         LIMIT 1'
    );
    $stmt->execute([$id]);
    $row = $stmt->fetch();
    return $row ?: null;
}

/**
 * Map an admin row to the JSON shape. NEVER includes password_hash —
 * that field is intentionally not selected in fetch_admin_by_id() and not
 * present in the response. The frontend only needs to know whether a
 * password is set (always true for current installs) — exposed as
 * 'has_password' for forward-compat with future OAuth-only accounts.
 */
function map_admin(array $r): array {
    return [
        'id'                   => (int)$r['id'],
        'username'             => $r['username'],
        'email'                => $r['email'],
        'role'                 => $r['role'],
        'has_password'         => true,  // always true for current installs
        'created_at'           => $r['created_at'],
        'updated_at'           => $r['updated_at'],
        'password_changed_at'  => $r['password_changed_at'],
    ];
}
