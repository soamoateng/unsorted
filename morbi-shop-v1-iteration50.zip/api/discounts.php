<?php
/**
 * discounts.php — Phase 5 (Sport Car) Batch 2 discount code management.
 *
 *   GET  public  ?code=XYZ          → validates code, returns {valid, type, value}
 *   GET  admin                     → list all discount codes
 *   POST admin                     → create a new code
 *   PUT  admin  {id, ...patch}      → update a code
 *   DELETE admin  ?id=N             → delete a code
 *
 * The public GET ?code=XYZ validates: code exists, active=1, not expired,
 * used_count < max_uses (if set). Returns the type + value so the frontend
 * can compute the discount amount. Does NOT reveal used_count or max_uses
 * (don't leak usage data to the public).
 *
 * The admin paths return the full row (including used_count, max_uses,
 * expires_at, active status) so the dashboard can show management UI.
 */

require __DIR__ . '/_bootstrap.php';

switch ($_SERVER['REQUEST_METHOD']) {
    case 'GET':    handle_get();    break;
    case 'POST':   require_admin(); verify_csrf(); handle_create();   break;
    case 'PUT':    require_admin(); verify_csrf(); handle_update();   break;
    case 'DELETE': require_admin(); verify_csrf(); handle_delete();   break;
    default:       json_err('Method not allowed.', 405);
}

/* ---- GET router ---------------------------------------------------------- */
function handle_get(): void {
    $code = trim((string)($_GET['code'] ?? ''));

    // Public path: validate a single code.
    if ($code !== '') {
        validate_code_public($code);
        return;
    }

    // Admin path: list all codes.
    require_admin();
    handle_admin_list();
}

/* ---- Public: validate code ---------------------------------------------- */
/* ★ SEC-07 fix: three changes to the public validate endpoint:
 *   1. Rate-limit: was no rate limit — an attacker could brute-force
 *      codes (WELCOME10, SUMMER2024, BLACKFRIDAY) in minutes. Now:
 *      10 requests/hour/IP — enough for a legitimate customer to try
 *      a few codes, not enough for brute-force.
 *   2. Strip type + value from the response: was `{valid:true, code,
 *      type, value}` — disclosed the discount type (percentage/flat)
 *      and the discount amount. This is enough to plan fraud (combined
 *      with SEC-03) or to misuse a code the merchant intended for a
 *      private campaign. Now: `{valid:true, code}` — the code is
 *      needed so the client knows which code was validated, but the
 *      type + value are NOT returned. The server computes the discount
 *      at checkout (payments.php line ~242-255) — the client doesn't
 *      need to know the type/value.
 *   3. Unify error messages: was distinct messages for "Invalid
 *      discount code" (not found), "no longer active", "expired",
 *      "reached its usage limit" — each leaks the code's state,
 *      enabling targeted enumeration. Now: all return the same
 *      "Invalid discount code." — the attacker can't distinguish
 *      between not-found, inactive, expired, or used-up.
 */
function validate_code_public(string $code): void {
    // ★ SEC-07: rate-limit the public validate path (10/hour/IP).
    rate_limit_check('discounts_validate:' . client_ip(), 10, 3600);

    // Normalize to uppercase for case-insensitive matching.
    $code = strtoupper($code);
    if (strlen($code) < 3 || strlen($code) > 50) {
        // ★ SEC-07: unified error message (was: "Invalid code format.")
        json_err('Invalid discount code.', 422);
    }

    // ★ Migration 2026-09-26: schema columns are `discount_type` and
    //   `discount_value`, NOT `type` / `value`. Aliased here so the rest
    //   of the function (`$row['type']`, etc.) keeps working unchanged.
    $stmt = db()->prepare(
        'SELECT id, code, discount_type AS type, discount_value AS value, active, max_uses, used_count, expires_at
         FROM discount_codes
         WHERE code = ?
         LIMIT 1'
    );
    $stmt->execute([$code]);
    $row = $stmt->fetch();

    if (!$row) {
        // ★ SEC-07: unified error (was: "Invalid discount code.")
        json_err('Invalid discount code.', 422);
    }
    if ((int)$row['active'] !== 1) {
        // ★ SEC-07: unified error (was: "This discount code is no longer active.")
        json_err('Invalid discount code.', 422);
    }
    // Check expiry.
    if ($row['expires_at'] !== null) {
        $expires = strtotime((string)$row['expires_at']);
        if ($expires !== false && $expires < time()) {
            // ★ SEC-07: unified error (was: "This discount code has expired.")
            json_err('Invalid discount code.', 422);
        }
    }
    // Check max_uses.
    if ($row['max_uses'] !== null) {
        if ((int)$row['used_count'] >= (int)$row['max_uses']) {
            // ★ SEC-07: unified error (was: "This discount code has reached its usage limit.")
            json_err('Invalid discount code.', 422);
        }
    }

    // ★ SEC-07: return only {valid, code} — type + value are NOT returned.
    // The server computes the discount at checkout (payments.php). The
    // frontend's computeDiscount() returns 0 (no type/value to compute
    // from) — the checkout summary shows "Discount applied" without the
    // amount. The actual discounted total is shown on Paystack's page.
    json_ok([
        'valid' => true,
        'code'  => $row['code'],
    ]);
}

/* ---- Admin: list -------------------------------------------------------- */
function handle_admin_list(): void {
    $rows = db()->query('SELECT * FROM discount_codes ORDER BY created_at DESC, id DESC')->fetchAll();
    json_ok(['codes' => array_map('map_code', $rows)]);
}

/* ---- Admin: create ------------------------------------------------------ */
function handle_create(): void {
    $b = json_body();

    $code = strtoupper(trim((string)($b['code'] ?? '')));
    if (strlen($code) < 3 || strlen($code) > 50 || !preg_match('/^[A-Z0-9_-]+$/', $code)) {
        json_err('Code must be 3-50 characters (letters, numbers, hyphens, underscores).', 422);
    }

    $type = (string)($b['type'] ?? 'percentage');
    if (!in_array($type, ['percentage', 'flat'], true)) {
        json_err('Type must be "percentage" or "flat".', 422);
    }

    $value = filter_var($b['value'] ?? null, FILTER_VALIDATE_FLOAT);
    if ($value === false || $value <= 0) {
        json_err('Value must be greater than 0.', 422);
    }
    if ($type === 'percentage' && $value > 100) {
        json_err('Percentage discount cannot exceed 100%.', 422);
    }

    $description = trim((string)($b['description'] ?? ''));
    if (mb_strlen($description) > 200) {
        json_err('Description is too long (max 200 characters).', 422);
    }

    $maxUses = null;
    if (isset($b['maxUses']) && $b['maxUses'] !== null && $b['maxUses'] !== '') {
        $maxUses = filter_var($b['maxUses'], FILTER_VALIDATE_INT);
        if ($maxUses === false || $maxUses < 1) {
            json_err('Max uses must be a positive integer (or empty for unlimited).', 422);
        }
    }

    $expiresAt = null;
    if (!empty($b['expiresAt'])) {
        $expiresAt = trim((string)$b['expiresAt']);
        // Accept 'YYYY-MM-DD' or 'YYYY-MM-DD HH:MM:SS' — append time if date-only.
        if (strlen($expiresAt) === 10) $expiresAt .= ' 23:59:59';
        $parsed = strtotime($expiresAt);
        if ($parsed === false) {
            json_err('Invalid expiry date format. Use YYYY-MM-DD.', 422);
        }
        $expiresAt = date('Y-m-d H:i:s', $parsed);
    }

    // Check for duplicate code.
    $check = db()->prepare('SELECT id FROM discount_codes WHERE code = ? LIMIT 1');
    $check->execute([$code]);
    if ($check->fetch()) {
        json_err('A code with this name already exists.', 422);
    }

    $active = to_bool($b['active'] ?? true, true);

    // ★ Migration 2026-09-26: schema columns are `discount_type` and
    //   `discount_value`, NOT `type` / `value`.
    $stmt = db()->prepare(
        'INSERT INTO discount_codes (code, description, discount_type, discount_value, active, max_uses, expires_at)
         VALUES (?, ?, ?, ?, ?, ?, ?)'
    );
    $stmt->execute([$code, $description ?: null, $type, round($value, 2), $active ? 1 : 0, $maxUses, $expiresAt]);

    $row = fetch_code((int)db()->lastInsertId());
    json_ok(map_code($row), 201);
}

/* ---- Admin: update ------------------------------------------------------ */
function handle_update(): void {
    $b = json_body();
    $id = (int)($b['id'] ?? 0);
    if ($id <= 0) json_err('Discount code id is required.', 422);
    // ★ BL-07 blind-spot guard: fetch the existing row BEFORE the patch loop
    //   so we can apply the patch on top of the current values and check the
    //   cross-field rule (type=percentage ⇒ value ≤ 100) AFTER the patch is
    //   built. Without this fetch, the patch loop only sees the fields the
    //   admin sent — flipping type from flat to percentage without re-sending
    //   value would let a stored value=200 silently become "200% off".
    $existing = fetch_code($id);
    if (!$existing) json_err('Discount code not found.', 404);

    $allowed = ['code', 'description', 'type', 'value', 'active', 'maxUses', 'expiresAt'];
    $sets = [];
    $params = [];

    // Track the FINAL type + value (post-patch) so we can cross-check.
    // Initialized to the existing row's current values — the patch only
    // overrides what the admin actually sent.
    // ★ Migration 2026-09-26: schema columns are `discount_type` and
    //   `discount_value`. fetch_code() does `SELECT *` so the row has the
    //   real column names — read them with the real names.
    $finalType  = (string)$existing['discount_type'];
    $finalValue = (float)$existing['discount_value'];

    foreach ($allowed as $key) {
        if (!array_key_exists($key, $b)) continue;

        if ($key === 'code') {
            $code = strtoupper(trim((string)$b['code']));
            if (strlen($code) < 3 || strlen($code) > 50 || !preg_match('/^[A-Z0-9_-]+$/', $code)) {
                json_err('Code must be 3-50 characters (letters, numbers, hyphens, underscores).', 422);
            }
            $sets[] = 'code = ?';
            $params[] = $code;
        } elseif ($key === 'type') {
            $type = (string)$b['type'];
            if (!in_array($type, ['percentage', 'flat'], true)) {
                json_err('Type must be "percentage" or "flat".', 422);
            }
            // ★ Migration 2026-09-26: schema column is `discount_type`.
            $sets[] = 'discount_type = ?';
            $params[] = $type;
            $finalType = $type;  // ★ BL-07: track for cross-field check
        } elseif ($key === 'value') {
            $value = filter_var($b['value'], FILTER_VALIDATE_FLOAT);
            if ($value === false || $value <= 0) {
                json_err('Value must be greater than 0.', 422);
            }
            // ★ Migration 2026-09-26: schema column is `discount_value`.
            $sets[] = 'discount_value = ?';
            $params[] = round($value, 2);
            $finalValue = round($value, 2);  // ★ BL-07: track for cross-field check
        } elseif ($key === 'description') {
            $desc = trim((string)$b['description']);
            $sets[] = 'description = ?';
            $params[] = $desc ?: null;
        } elseif ($key === 'active') {
            $sets[] = 'active = ?';
            $params[] = to_bool($b['active'], true) ? 1 : 0;
        } elseif ($key === 'maxUses') {
            $mu = null;
            if ($b['maxUses'] !== null && $b['maxUses'] !== '') {
                $mu = filter_var($b['maxUses'], FILTER_VALIDATE_INT);
                if ($mu === false || $mu < 1) {
                    json_err('Max uses must be a positive integer (or empty for unlimited).', 422);
                }
            }
            $sets[] = 'max_uses = ?';
            $params[] = $mu;
        } elseif ($key === 'expiresAt') {
            $ea = null;
            if (!empty($b['expiresAt'])) {
                $ea = trim((string)$b['expiresAt']);
                if (strlen($ea) === 10) $ea .= ' 23:59:59';
                $parsed = strtotime($ea);
                if ($parsed === false) {
                    json_err('Invalid expiry date format. Use YYYY-MM-DD.', 422);
                }
                $ea = date('Y-m-d H:i:s', $parsed);
            }
            $sets[] = 'expires_at = ?';
            $params[] = $ea;
        }
    }

    // ★ BL-07 fix: post-loop cross-field validation. The create handler
    //   checks `if ($type === 'percentage' && $value > 100)` at line 115-117;
    //   the update handler had no equivalent check. Without it, the admin
    //   could:
    //     - PATCH {value: 200} on a percentage-type code → stored as 200% off
    //     - PATCH {type: 'percentage'} on a flat-200 code → stored as 200% off
    //       (the admin didn't re-send value, so the existing 200 stayed)
    //   The fix computes the FINAL (post-patch) type + value by starting from
    //   the existing row's current values (fetched above) and overriding
    //   only the fields the admin sent. Then the cross-field rule is checked
    //   against the FINAL pair. This mirrors the create handler's behaviour
    //   exactly.
    //
    //   Note: payments.php (line 248-251) clamps the resulting discount to
    //   the order total, so a 200%-off code can't produce a negative charge
    //   at checkout — but the dashboard's discount editor would happily
    //   store the bad value, and validate_code_public (line 76-80) would
    //   return {valid: true, type: 'percentage', value: 200} to any customer
    //   who tries the code, which the storefront's computeDiscount would
    //   use to display a nonsensical "Discount: -GHS 200" on a GHS 100 cart
    //   (before the clamp kicks in). This fix refuses the bad value at the
    //   source.
    if ($finalType === 'percentage' && $finalValue > 100) {
        json_err('Percentage discount cannot exceed 100%.', 422);
    }

    if (!$sets) json_err('No valid fields to update.', 422);

    $params[] = $id;
    $stmt = db()->prepare('UPDATE discount_codes SET ' . implode(', ', $sets) . ' WHERE id = ?');
    $stmt->execute($params);

    json_ok(map_code(fetch_code($id)));
}

/* ---- Admin: delete ------------------------------------------------------ */
function handle_delete(): void {
    $id = (int)($_GET['id'] ?? 0);
    if ($id <= 0) json_err('Discount code id is required.', 422);

    $stmt = db()->prepare('DELETE FROM discount_codes WHERE id = ?');
    $stmt->execute([$id]);
    if ($stmt->rowCount() === 0) json_err('Discount code not found.', 404);

    json_ok(['deleted' => $id]);
}

/* ---- Helpers ------------------------------------------------------------ */
function fetch_code(int $id): ?array {
    $stmt = db()->prepare('SELECT * FROM discount_codes WHERE id = ? LIMIT 1');
    $stmt->execute([$id]);
    $row = $stmt->fetch();
    return $row ?: null;
}

// ★ Migration 2026-09-26: schema columns are `discount_type` and
//   `discount_value`. fetch_code() does `SELECT *` so the row has the
//   real column names — read them with the real names + alias to the
//   JS-expected names in the response.
function map_code(array $r): array {
    return [
        'id'          => (int)$r['id'],
        'code'        => $r['code'],
        'description' => (string)($r['description'] ?? ''),
        'type'        => (string)($r['discount_type'] ?? 'percentage'),
        'value'       => (float)($r['discount_value'] ?? 0),
        'active'      => (bool)$r['active'],
        'maxUses'     => ($r['max_uses'] !== null) ? (int)$r['max_uses'] : null,
        'usedCount'   => (int)$r['used_count'],
        'expiresAt'   => $r['expires_at'],
        'createdAt'   => $r['created_at'],
    ];
}
