<?php
/**
 * search.php — ★ Phase 9 Batch 1 (Task 61, 2026-09-23) product search.
 *
 *   GET  public  -> {products:[...], count, total, query, filters}
 *
 * Parameters (all optional, all combine with AND logic):
 *   q           string  search keyword. < 3 chars → LIKE fallback
 *                       (InnoDB FULLTEXT default min token size is 3).
 *                       Empty → no keyword filter (returns available
 *                       products filtered by other params only).
 *   category    int     category_id filter. 0 = all categories.
 *   min_price   float   minimum price in GHS (base currency). Inclusive.
 *   max_price   float   maximum price in GHS. Inclusive.
 *   scent       string  scent_category filter: 'male' | 'female' | 'unisex'
 *                       (matches the Phase 5 Batch 1 scent-gate values).
 *   limit       int     max results. Range [1, 50]. Default 20.
 *   offset      int     pagination offset. Default 0.
 *
 * Returns the same product shape as products.php (public GET) so the
 * storefront can reuse its render logic. Only `available=1` products
 * are returned (matches the public storefront's behavior).
 *
 * Rate-limited 30/min per IP — storefront search is high-frequency (every
 * keystroke with 300ms debounce), so a generous limit. Abusers get 429 +
 * Retry-After. The rate limit is checked AFTER cheap input validation so
 * obviously-malformed requests get 422 without ticking the counter.
 *
 * Verified live 2026-09-23 against MySQL docs (dev.mysql.com): FULLTEXT
 * with BOOLEAN MODE supports +/- operators, partial-word matching, etc.
 * We strip +- prefixes from user input to avoid surprising behavior
 * (e.g., a customer typing "+oud -floral" — the operators are advanced
 * and would silently exclude legitimate matches if a customer didn't
 * know the syntax). The raw query is searched as-is in BOOLEAN MODE
 * (the engine handles stemming/stop-words).
 *
 * Security: this endpoint never returns products where available=0
 * (hidden products are admin-only via products.php?all=1). Stock levels
 * are returned (the storefront shows "Out of stock" badges), but no PII
 * or admin-only fields (created_at, updated_at, etc.) are exposed.
 */

require __DIR__ . '/_bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    json_err('GET only.', 405);
}

// ---- Parse + validate inputs ------------------------------------------------
$q         = trim((string)($_GET['q'] ?? ''));
$categoryId = (int)($_GET['category'] ?? 0);
$minPrice  = isset($_GET['min_price']) ? (float)$_GET['min_price'] : null;
$maxPrice  = isset($_GET['max_price']) ? (float)$_GET['max_price'] : null;
$scent     = (string)($_GET['scent'] ?? '');
// ★ RT-13-style floor: clamp limit to [1, 50] so a malformed ?limit=-5 or
//   ?limit=999999 doesn't break the SQL or return the whole catalog.
$limit     = max(1, min((int)($_GET['limit'] ?? 20), 50));
$offset    = max((int)($_GET['offset'] ?? 0), 0);

if ($scent !== '' && !in_array($scent, ['male', 'female', 'unisex'], true)) {
    json_err('scent must be "male", "female", or "unisex".', 422);
}
if ($minPrice !== null && $minPrice < 0) {
    json_err('min_price cannot be negative.', 422);
}
if ($maxPrice !== null && $maxPrice < 0) {
    json_err('max_price cannot be negative.', 422);
}
if ($minPrice !== null && $maxPrice !== null && $minPrice > $maxPrice) {
    json_err('min_price cannot be greater than max_price.', 422);
}

// ---- Rate limit (after cheap validation, before DB read) ------------------
// 30 searches / 60 seconds per IP. Generous because the storefront debounces
// at 300ms — a customer typing "oud royale" makes ~5 searches per keystroke-burst.
rate_limit_check('search:' . client_ip(), 30, 60);

// ---- Detect whether FTS5 virtual table exists ----------------------------
// If the install ran install.php after Phase 9 Batch 1 landed, the FTS5
// virtual table products_fts exists. SQLite detects this by querying
// sqlite_master (the built-in schema catalog) — there's no information_schema
// in SQLite like there is in MySQL. If the FTS table is missing (admin
// upgraded from Phase 8 to Phase 9 without re-running install.php, OR the
// PHP build doesn't have FTS5 compiled in), fall back to LIKE — search
// still works, just slower on large catalogs.
$fulltextAvailable = false;
try {
    $idxCheck = db()->prepare(
        "SELECT COUNT(*) FROM sqlite_master
         WHERE type='table' AND name='products_fts'"
    );
    $idxCheck->execute();
    $fulltextAvailable = ((int)$idxCheck->fetchColumn() > 0);
    // Verify FTS5 is functional by doing a trivial query — if FTS5 is not
    // compiled into PHP's SQLite, the table exists but MATCH() throws.
    if ($fulltextAvailable) {
        try {
            db()->query("SELECT COUNT(*) FROM products_fts WHERE products_fts MATCH 'a' LIMIT 0");
        } catch (Throwable $probeErr) {
            $fulltextAvailable = false;
        }
    }
} catch (Throwable $e) {
    // sqlite_master query failed (very rare). Fall back to LIKE.
    $fulltextAvailable = false;
}

// ---- Build the query -------------------------------------------------------
// Strategy:
//   1. Always start with `WHERE available = 1` (public storefront contract).
//   2. If $q is non-empty AND >= 3 chars AND $fulltextAvailable: use
//      products_fts MATCH (SQLite FTS5 syntax).
//   3. If $q is non-empty AND (< 3 chars OR no FULLTEXT): use
//      (name LIKE ? OR scent LIKE ? OR description LIKE ?) with %q%.
//   4. If $q is empty: skip the keyword filter entirely (filters-only search).
//   5. Apply category, price range, scent_category as additional AND conditions.
$where  = ['available = 1'];
$params = [];
$useFulltext = ($q !== '' && mb_strlen($q) >= 3 && $fulltextAvailable);
$useLike     = ($q !== '' && !$useFulltext);

if ($useFulltext) {
    // ★ SQLite FTS5: query the products_fts virtual table, join back to
    //   products for the rowid. The MATCH operator in FTS5 has different
    //   syntax from MySQL's MATCH...AGAINST — FTS5 uses 'OR'/'AND' keywords
    //   and bare words. We pass the user query wrapped in single quotes
    //   for FTS5 string-prefix matching. (FTS5 doesn't support BOOLEAN
    //   MODE the way MySQL does, but it supports its own query language.)
    //   For safety, we wrap each token in double quotes to treat it as a
    //   phrase — this avoids surprises with FTS5 operators (AND, OR, NOT).
    //   The user can't inject FTS5 syntax this way.
    $tokens = preg_split('/\s+/', $q);
    $quoted = array_map(function ($t) { return '"' . str_replace('"', '""', $t) . '"'; }, $tokens);
    $ftsQuery = implode(' ', $quoted);
    $where[] = 'id IN (SELECT rowid FROM products_fts WHERE products_fts MATCH ?)';
    $params[] = $ftsQuery;
} elseif ($useLike) {
    // ★ SQLITE FIX (2026-09-26) m5: escape LIKE wildcards (% and _) in the
    //   user query so a search for "50% off" doesn't match every row
    //   containing "50" (the % would be interpreted as a wildcard).
    //   Also escape the escape char itself (\). The ESCAPE '\' clause tells
    //   SQLite to treat \ as the escape character in this LIKE expression.
    //   (MySQL behaves identically — this is a cross-DB best practice.)
    $where[] = "(name LIKE ? ESCAPE '\\' OR scent LIKE ? ESCAPE '\\' OR description LIKE ? ESCAPE '\\')";
    $escaped = str_replace(['\\', '%', '_'], ['\\\\', '\\%', '\\_'], $q);
    $like = '%' . $escaped . '%';
    $params[] = $like;
    $params[] = $like;
    $params[] = $like;
}

if ($categoryId > 0) {
    $where[] = 'category_id = ?';
    $params[] = $categoryId;
}
if ($minPrice !== null) {
    $where[] = 'price >= ?';
    $params[] = $minPrice;
}
if ($maxPrice !== null) {
    $where[] = 'price <= ?';
    $params[] = $maxPrice;
}
if ($scent !== '') {
    // ★ Phase 5 Batch 1 backward compat: products with scent_category=NULL
    //   are treated as "untagged = show everywhere". So a filter for 'male'
    //   matches scent_category='male' OR scent_category IS NULL. Same rule
    //   the storefront's filterByScent() uses.
    $where[] = '(scent_category = ? OR scent_category IS NULL)';
    $params[] = $scent;
}

$whereSql = implode(' AND ', $where);

// ---- Run the search -------------------------------------------------------
$pdo = db();
$sql = "SELECT id, name, scent, scent_category, description, price,
               category_id, image_path, available, stock
        FROM products
        WHERE {$whereSql}
        ORDER BY";
$sql .= ' name ASC';
// SQLite FTS5 doesn't expose relevance ranking in a simple way that works
// across PHP SQLite builds, so we just sort by name ASC. The user gets the
// same product visibility they would have with relevance ranking, just in
// alphabetical order.
$sql .= ' LIMIT ' . $limit . ' OFFSET ' . $offset;

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll();

// ---- Total count (for pagination) ------------------------------------------
// Same WHERE clause, no LIMIT. Used by the frontend to show "20 of 47 results".
$countSql = "SELECT COUNT(*) FROM products WHERE {$whereSql}";
$countParams = $params;
$countStmt = $pdo->prepare($countSql);
$countStmt->execute($countParams);
$total = (int)$countStmt->fetchColumn();

// ---- Map to public shape (matches products.php) ---------------------------
$products = array_map(function ($r) {
    return [
        'id'             => (int)$r['id'],
        'name'           => $r['name'],
        'scent'          => (string)($r['scent'] ?? ''),
        'scent_category' => (string)($r['scent_category'] ?? ''),
        'description'    => (string)($r['description'] ?? ''),
        'price'          => (float)$r['price'],
        'categoryId'     => $r['category_id'] !== null ? (int)$r['category_id'] : null,
        'image_path'     => (string)($r['image_path'] ?? ''),
        'available'       => (int)$r['available'] === 1,
        'stock'          => $r['stock'] !== null ? (int)$r['stock'] : null,
    ];
}, $rows);

json_ok([
    'products' => $products,
    'count'    => count($products),
    'total'    => $total,
    'limit'    => $limit,
    'offset'   => $offset,
    'query'    => $q,
    'filters'  => [
        'category'  => $categoryId > 0 ? $categoryId : null,
        'min_price' => $minPrice,
        'max_price' => $maxPrice,
        'scent'     => $scent !== '' ? $scent : null,
    ],
    // Expose the search engine used (for debugging + the smoke test). The
    // storefront doesn't read this — it just renders the products array.
    'engine'   => $useFulltext ? 'fulltext' : ($useLike ? 'like' : 'none'),
]);
