<?php
/**
 * upload.php — product image upload endpoint (Phase 1, "Scooter", Batch 2).
 *
 * Replaces the Phase 0 base64-in-MEDIUMTEXT approach. The dashboard's photo
 * picker now POSTs the file here; this endpoint validates MIME + size from
 * the actual file bytes (NOT the client-provided Content-Type, which is
 * trivially spoofable), generates a safe filename, moves the file into
 * uploads/, and returns the web-root-relative path that gets stored in
 * products.image_path.
 *
 *   POST  admin, multipart/form-data, field name "photo"
 *         -> { path: "uploads/1709xxxxxx-a1b2c3d4e5f6.jpg" }
 *
 * Security:
 *   * Admin-only (require_admin guard — same as every other write endpoint).
 *   * MIME sniffed from file bytes via PHP's finfo extension (always ships
 *     with PHP 5.3+ on XAMPP and cPanel). Client-provided Content-Type
 *     and file extension are IGNORED.
 *   * Allowed MIME: image/jpeg, image/png, image/webp, image/gif.
 *   * Size hard cap: MAX_UPLOAD_BYTES (4 MB). Also enforced client-side
 *     in dashboard.js before the request fires (cheap UX win).
 *   * Filename = {timestamp}-{12 hex random}.{ext}. No user input in the
 *     filename — defense in depth against path traversal and collisions.
 *   * uploads/.htaccess blocks PHP execution inside the directory even
 *     if an attacker somehow drops a .php file there.
 *
 * Phase 0 base64 read-compat: legacy product rows whose image_path is a
 * `data:image/...;base64,...` string still render correctly — <img src>
 * accepts both URLs and data URLs. New uploads always use the uploads/
 * path. No DB migration needed.
 */

require __DIR__ . '/_bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_err('POST only.', 405);
}
require_admin();
verify_csrf();

/* ---- Validate the upload arrived ---------------------------------------- */
// PHP populates $_FILES only for multipart/form-data POSTs. The dashboard's
// uploadImage() helper uses FormData, so $_FILES['photo'] is expected.
if (!isset($_FILES['photo'])) {
    json_err('No file uploaded. Field name must be "photo".', 422);
}

$file = $_FILES['photo'];

// PHP upload error codes (UPLOAD_ERR_*). 4 = no file — different from a
// missing field, so the message tells the user which.
if ($file['error'] !== UPLOAD_ERR_OK) {
    json_err(upload_error_message($file['error']), 422);
}

// Size cap (defensive — MAX_UPLOAD_BYTES also enforced by Apache's
// LimitRequestBody on production, but the PHP guard fires first).
if ($file['size'] > MAX_UPLOAD_BYTES) {
    json_err('Image is too large. Max ' . (MAX_UPLOAD_BYTES / 1024 / 1024) . ' MB.', 422);
}

/* ---- Sniff the ACTUAL MIME from the file bytes -------------------------- */
// Client-provided $file['type'] is trivially spoofable. We re-detect via
// finfo (always available on PHP 5.3.0+ — universal on XAMPP and cPanel).
// Returns false on failure; treat as "not an image".
$actualMime = false;
if (function_exists('finfo_open')) {
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    if ($finfo !== false) {
        $actualMime = finfo_file($finfo, $file['tmp_name']);
        finfo_close($finfo);
    }
}
if ($actualMime === false || !array_key_exists($actualMime, ALLOWED_MIME)) {
    json_err('Unsupported image type. Allowed: JPEG, PNG, WebP, GIF.', 422);
}

$extension = ALLOWED_MIME[$actualMime];

/* ---- Generate a safe filename + path ------------------------------------ */
// 12 hex chars (48 bits) of random = 281 trillion possibilities. The
// timestamp prefix keeps the directory listing readable (and prevents
// collisions from concurrent uploads in the same second). Filename has
// zero user input — defense in depth against path traversal.
$filename = sprintf('%d-%s.%s', time(), bin2hex(random_bytes(6)), $extension);
$fullPath = rtrim(UPLOAD_DIR, '/') . '/' . $filename;
$relPath = UPLOAD_URL . '/' . $filename;

/* ---- Make sure uploads/ exists (idempotent) ---------------------------- */
// install.php does NOT create uploads/ — only storage/. So the first upload
// after install must self-create the directory. Permissions 0755 (rwxr-xr-x)
// match XAMPP's default and the cPanel writable-bit pattern.
if (!is_dir(UPLOAD_DIR)) {
    @mkdir(UPLOAD_DIR, 0755, true);
}
if (!is_dir(UPLOAD_DIR) || !is_writable(UPLOAD_DIR)) {
    json_err('Server error: uploads/ directory is missing or not writable. Check folder permissions and retry.', 500);
}

/* ---- Move the file from /tmp to uploads/ -------------------------------- */
// move_uploaded_file() refuses files that did not come from a real HTTP POST,
// which closes the local-file-injection vector. The check is implicit.
if (!move_uploaded_file($file['tmp_name'], $fullPath)) {
    json_err('Could not save the uploaded file. Check disk space and uploads/ permissions.', 500);
}

// Defensive: confirm the saved file is readable and not zero-length.
if (!is_file($fullPath) || filesize($fullPath) === 0) {
    @unlink($fullPath); // tidy up the partial file
    json_err('Saved file is empty or unreadable.', 500);
}

json_ok(['path' => $relPath, 'size' => (int)filesize($fullPath)]);

/* ---- helpers ------------------------------------------------------------ */
function upload_error_message(int $code): string {
    switch ($code) {
        case UPLOAD_ERR_INI_SIZE:   return 'Image exceeds the server upload limit (php.ini upload_max_filesize).';
        case UPLOAD_ERR_FORM_SIZE:  return 'Image exceeds the form MAX_FILE_SIZE directive.';
        case UPLOAD_ERR_PARTIAL:    return 'Image was only partially uploaded — try again.';
        case UPLOAD_ERR_NO_FILE:    return 'No file was selected.';
        case UPLOAD_ERR_NO_TMP_DIR: return 'Server error: missing temporary directory.';
        case UPLOAD_ERR_CANT_WRITE: return 'Server error: cannot write to disk.';
        case UPLOAD_ERR_EXTENSION:  return 'A PHP extension blocked the upload.';
        default:                    return 'Upload failed (code ' . $code . ').';
    }
}
