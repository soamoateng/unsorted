<?php
/**
 * forgot-password.php — Phase 3 (Motorcycle) Batch 3 password recovery initiator.
 *
 *   POST  public { email }  -> { sent: true }  (ALWAYS returns 200 — even if
 *                                                    email doesn't exist, to
 *                                                    prevent user enumeration)
 *
 * Flow:
 *   1. Validate email format (cheap — done BEFORE rate limiting so garbage
 *      payloads get 422 without ticking the counter, same pattern as
 *      payments.php).
 *   2. Rate limit: 3 attempts / hour per IP AND per email. Both buckets
 *      checked BEFORE the DB lookup so timing doesn't leak email existence.
 *   3. Look up admin_users by email. If not found: still return 200 (the
 *      response is identical to a successful send — no user enumeration).
 *   4. Generate a 32-byte random token (64 hex chars). Hash with SHA-256
 *      for storage (defense in depth: DB leak → hashes useless without
 *      the email link).
 *   5. INSERT into password_resets with expires_at = NOW() + TTL.
 *   6. Send the email via _mailer.php with a link to
 *      /reset-password?token=<64hex> (Phase 6 Batch 0: clean-path routing —
 *      no `#/` prefix).
 *   7. On mail failure: return 503 with a clear message (don't pretend the
 *      email was sent — the user needs to know to retry or contact support).
 *
 * Security:
 *   * No auth guard — public endpoint (pre-auth by definition).
 *   * CSRF exempt (pre-auth, same as login.php).
 *   * Rate-limited: 3 / hour per IP + 3 / hour per email.
 *   * No user enumeration: identical response shape + timing regardless of
 *     whether the email exists in admin_users.
 *   * Token is 256 bits of entropy (32 random bytes) — brute-forcing is
 *     computationally infeasible.
 *   * Token hash stored, not the token itself — DB leak doesn't compromise
 *     pending reset links.
 *   * Single-use: reset-password.php marks used_at on consumption + nukes
 *     all other tokens for that user.
 */

require __DIR__ . '/_bootstrap.php';
require_once __DIR__ . '/_mailer.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_err('POST only.', 405);
}

$b = json_body();
if (!$b) json_err('Empty or malformed JSON body.', 422);

/* ---- 1. Validate email format ------------------------------------------- */
$email = trim((string)($b['email'] ?? ''));
if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || mb_strlen($email) > 150) {
    json_err('Enter a valid email address.', 422);
}

/* ---- 2. Rate limiting (per-IP + per-email, both BEFORE DB lookup) ------- *
 * Same dual-bucket pattern as login.php — timing-safe against user
 * enumeration. Slugify the email for the bucket key so case/whitespace
 * differences don't reset the counter. */
$ip = client_ip();
$emailSlug = slugify_server($email);

rate_limit_check('forgotpw:' . $ip, PASSWORD_RESET_RATE_LIMIT_MAX, PASSWORD_RESET_RATE_LIMIT_WINDOW);
rate_limit_check('forgotpw:' . $emailSlug, PASSWORD_RESET_RATE_LIMIT_MAX, PASSWORD_RESET_RATE_LIMIT_WINDOW);

/* ---- 3. Look up admin user by email or username -------------------------- *
 * ★ BL-02 fix (= SEC-18 fix, applied in iteration 19 — Phase 5 audit):
 *   the original query was `WHERE username = ? OR username = ?` with
 *   `[$email, $email]` — the same column twice, the same binding twice.
 *   The intent was `WHERE username = ? OR email = ?`, but the `email`
 *   column on admin_users didn't exist yet (Phase 0 schema never added it).
 *
 *   The `email` column now exists (added to schema.sql + install.php fresh
 *   CREATE TABLE + idempotent ALTER for existing installs). The query is
 *   patched to actually bind the second placeholder against the `email`
 *   column. Recovery now works for:
 *   - Admins whose `username` column equals the typed email (the legacy
 *     "Morbi's username is her email" case).
 *   - Admins whose `email` column equals the typed email (the new path
 *     — works even when the username is "morbi" and the email is
 *     "morbi@example.com").
 *
 * The existing anti-enumeration stance is preserved: if neither branch
 *   matches, we still return 200 with the same body as a success would.
 * The existing `LIMIT 1` is preserved: at most one admin row matches
 *   (both username and email have UNIQUE constraints).
 *
 * NOTE: the user-supplied $email is the destination for the reset link
 *   (line 142: send_mail($email, ...)). This is correct because:
 *   - If matched by `email = ?`: the typed email IS the admin's email →
 *     correct destination.
 *   - If matched by `username = ?`: the admin's username happens to BE
 *     an email-shaped string the user just typed → correct destination
 *     (the user knows the address; they typed it).
 *
 * ★ OTH-13 fix (iteration 25 — this batch): the long stale TODO block that
 *   used to live here (referencing a "Phase 4 may add an `email` column"
 *   future deliverable) has been removed. Phase 4 is delivered; the email
 *   column is in place; the TODO is no longer pending. The historical
 *   context is preserved in the BL-02 fix note above.
 */
$stmt = db()->prepare('SELECT id, username, email FROM admin_users WHERE username = ? OR email = ? LIMIT 1');
$stmt->execute([$email, $email]);
$admin = $stmt->fetch();

if (!$admin) {
    // No user with this email — return the same 200 as a success would.
    // This is the anti-enumeration stance: an attacker can't tell "email
    // doesn't exist" from "email exists but SMTP failed" by the response.
    json_ok(['sent' => true]);
}

/* ---- 4-5. Generate token + INSERT ------------------------------------- */
// 32 random bytes = 256 bits of entropy. hex-encoded = 64 chars.
$plaintextToken = bin2hex(random_bytes(32));
$tokenHash = hash('sha256', $plaintextToken);
$expiresAt = date('Y-m-d H:i:s', time() + PASSWORD_RESET_TOKEN_TTL);

$pdo = db();
try {
    $stmt = $pdo->prepare(
        'INSERT INTO password_resets (admin_user_id, token_hash, expires_at, ip_address)
         VALUES (?, ?, ?, ?)'
    );
    $stmt->execute([
        (int)$admin['id'],
        $tokenHash,
        $expiresAt,
        $ip,
    ]);
} catch (Exception $e) {
    // INSERT failure (e.g. duplicate token_hash — astronomically unlikely with
    // 256 bits of entropy, but the UNIQUE constraint catches it). Don't leak
    // the error to the public; return 200 (same as no-user-found path).
    error_log('[morbi] password_resets INSERT failed: ' . $e->getMessage());
    json_ok(['sent' => true]);
}

/* ---- 6. Send the email ------------------------------------------------- */
// ★ Phase 6 Batch 0: clean-path routing — no more `#/` in the reset URL.
//   The old URL was `<base>/#/reset-password?token=<64hex>`. The new URL is
//   `<base>/reset-password?token=<64hex>`. The .htaccess SPA-fallback rule
//   serves index.html for the clean path; the router then matches the
//   /reset-password route. Old reset links (already-emailed ones with `#/`)
//   still work because the router's migrateHashBookmark() rewrites them to
//   clean paths on startup — so a reset link sent before this upgrade keeps
//   working indefinitely.
$resetUrl = rtrim(PASSWORD_RESET_URL_BASE, '/') . '/reset-password?token=' . $plaintextToken;

$subject = 'morbi.shop — Password Reset';
$htmlBody = '<!DOCTYPE html><html><body style="font-family: Arial, sans-serif; color: #222; max-width: 560px; margin: 0 auto;">'
    . '<h2 style="color: #D4AF37;">Password Reset Request</h2>'
    . '<p>Someone requested a password reset for your morbi.shop admin account.</p>'
    . '<p>Click the link below to choose a new password:</p>'
    . '<p><a href="' . htmlspecialchars($resetUrl, ENT_QUOTES, 'UTF-8') . '" '
    . 'style="display: inline-block; background: #D4AF37; color: #000; padding: 10px 20px; text-decoration: none; border-radius: 6px; font-weight: 700;">'
    . 'Reset Password</a></p>'
    . '<p style="color: #666; font-size: 13px;">Or copy this URL into your browser:</p>'
    . '<p style="word-break: break-all; background: #f5f5f5; padding: 8px; border-radius: 4px; font-size: 12px;">'
    . htmlspecialchars($resetUrl, ENT_QUOTES, 'UTF-8') . '</p>'
    . '<p style="color: #666; font-size: 13px;">This link expires in 1 hour.</p>'
    . '<p style="color: #666; font-size: 13px;">If you did not request this reset, you can safely ignore this email — your password will not change.</p>'
    . '<hr style="border: none; border-top: 1px solid #eee; margin: 20px 0;">'
    . '<p style="color: #999; font-size: 12px;">morbi.shop admin panel</p>'
    . '</body></html>';
$textBody = "Password Reset Request\n\n"
    . "Someone requested a password reset for your morbi.shop admin account.\n\n"
    . "Click the link below to choose a new password:\n"
    . $resetUrl . "\n\n"
    . "This link expires in 1 hour.\n\n"
    . "If you did not request this reset, you can safely ignore this email — your password will not change.\n\n"
    . "morbi.shop admin panel";

$mail = send_mail($email, $subject, $htmlBody, $textBody);
if (!$mail['ok']) {
    // SMTP failure — log internally (for the admin to debug via php_sanity or
    // server logs) but return 200 to the public (anti-enumeration: an attacker
    // can't distinguish "SMTP failed" from "user doesn't exist").
    error_log('[morbi] forgot-password email send failed for admin_id=' . $admin['id'] . ': ' . $mail['error']);
    // Don't expose the SMTP error to the public — it may leak SMTP internals.
    json_ok(['sent' => true]);
}

/* ---- 7. Return success ------------------------------------------------- */
json_ok(['sent' => true]);
