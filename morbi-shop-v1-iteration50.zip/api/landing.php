<?php
/**
 * landing.php — landing page copy (key/value CMS content).
 *
 * GET public                 -> { hero_title: "...", ... } (same 8 keys as before)
 * PUT   admin {key, value}   -> upserts ONE field (mirrors the old
 *                               "save each field individually" dashboard UX)
 *
 * ★ Phase 6 Batch 1a (Task 48): the GET path is now a BACKWARD-COMPAT SHIM.
 *   The 8 key-value pairs are rebuilt from the 4 base sections (hero, about,
 *   featured, footer) in the new landing_sections table. If a base section
 *   is missing (admin deleted it), the shim falls back to the value in the
 *   legacy landing_content table (preserved from Phase 0). If both are
 *   missing, falls back to the install-time defaults.
 *   This means the existing storefront (which calls landing.php GET on
 *   hydrate) keeps rendering byte-identically until the Batch 1c storefront
 *   rewrite — no client-side changes are required for this batch.
 *   The PUT path is UNCHANGED — the dashboard's current "Landing Page" tab
 *   still writes to the legacy landing_content table. Batch 1b will replace
 *   that tab with the new "Sections" tab which writes to landing_sections
 *   via api/sections.php instead; the landing_content table will then be
 *   read-only (kept for the shim's fallback path until a future cleanup).
 */

require __DIR__ . '/_bootstrap.php';

// LANDING_ALLOWED (field -> max length) lives in _bootstrap.php —
// shared with import.php so both enforce the identical contract.

switch ($_SERVER['REQUEST_METHOD']) {
    case 'GET': handle_get();  break;
    case 'PUT': require_admin(); verify_csrf(); handle_put(); break;
    default:    json_err('Method not allowed.', 405);
}

/* ---- GET ------------------------------------------------------------------
 * ★ Phase 6 Batch 1a: rebuild the 8 key-value pairs from the 4 base
 *   sections (hero, about, featured, footer) in landing_sections. If a
 *   base section is missing, fall back to the legacy landing_content
 *   table. If both are missing, fall back to the install-time defaults.
 *   The response shape is the SAME 8 keys Morbi's storefront has always
 *   expected: hero_title, hero_subtitle, about_heading, about_text_1,
 *   about_text_2, featured_heading, featured_sub, footer_text. */
function handle_get(): void {
    // 1) Read the legacy landing_content table (fallback values).
    $legacyRows = db()->query('SELECT section_key, content FROM landing_content')->fetchAll();
    $legacy = [];
    foreach ($legacyRows as $row) {
        $legacy[$row['section_key']] = $row['content'];
    }

    // 2) Install-time defaults (the same values install.php seeds).
    $defaults = [
        'hero_title'       => 'Luxury Scents, Redefined.',
        'hero_subtitle'    => 'Morcenzs, handcrafted perfumes and accessories for those who leave an impression.',
        'about_heading'    => 'About Morbi',
        'about_text_1'     => 'Morbi is a creative entrepreneur and the founder of Morcenzs, a homegrown fragrance brand born from a passion for self-expression through scent.',
        'about_text_2'     => 'Every Morcenzs bottle is curated with care, from bold, attention-grabbing signatures to subtle everyday essentials.',
        'featured_heading' => 'Featured Scents',
        'featured_sub'     => 'A selection from the Morcenzs collection. Visit the store for the full range.',
        'footer_text'      => 'Morcenzs by Morbi. All rights reserved.',
    ];

    // 3) Read the 4 base sections from landing_sections. Decode the JSON
    //    content per section type. Use the values as the primary source.
    $out = [];
    $baseSections = db()->query(
        "SELECT section_type, content FROM landing_sections
         WHERE section_type IN ('hero', 'about', 'featured', 'footer')
           AND active = 1 AND deleted_at IS NULL"
    )->fetchAll();
    foreach ($baseSections as $row) {
        $content = json_decode((string)$row['content'], true);
        if (!is_array($content)) continue;
        switch ($row['section_type']) {
            case 'hero':
                $out['hero_title']    = $content['heading']  ?? '';
                $out['hero_subtitle'] = $content['subtitle'] ?? '';
                break;
            case 'about':
                $out['about_heading'] = $content['heading']     ?? '';
                $out['about_text_1']  = $content['paragraph_1'] ?? '';
                $out['about_text_2']  = $content['paragraph_2'] ?? '';
                break;
            case 'featured':
                $out['featured_heading'] = $content['heading']  ?? '';
                $out['featured_sub']     = $content['subtitle'] ?? '';
                break;
            case 'footer':
                $out['footer_text'] = $content['text'] ?? '';
                break;
        }
    }

    // 4) For any key that's still empty/missing in $out, fall back to the
    //    legacy landing_content table, then to the install-time defaults.
    foreach ($defaults as $key => $defaultVal) {
        if (!isset($out[$key]) || $out[$key] === '') {
            $out[$key] = $legacy[$key] ?? $defaultVal;
        }
    }

    json_ok($out);
}

/* ---- PUT ------------------------------------------------------------------
 * UNCHANGED from Phase 0: the dashboard's existing "Landing Page" tab
 * still writes to the legacy landing_content table. Batch 1b will replace
 * the tab with the new "Sections" tab that writes to landing_sections via
 * api/sections.php; this PUT path will then be deprecated (but kept for
 * backward compat with any external script that calls it). */
function handle_put(): void {
    $b = json_body();
    $key = (string)($b['key'] ?? '');

    if (!array_key_exists($key, LANDING_ALLOWED)) {
        json_err('Unknown landing field.', 422);
    }
    $value = (string)($b['value'] ?? '');
    if (mb_strlen(trim($value)) === 0) {
        json_err('This field is required', 422);
    }
    if (mb_strlen($value) > LANDING_ALLOWED[$key]) {
        json_err('Max ' . LANDING_ALLOWED[$key] . ' characters allowed', 422);
    }

    $stmt = db()->prepare(
        'INSERT INTO landing_content (section_key, content) VALUES (?, ?)
         ON CONFLICT(section_key) DO UPDATE SET content = excluded.content'
    );
    $stmt->execute([$key, $value]);

    json_ok(['key' => $key, 'value' => $value]);
}
