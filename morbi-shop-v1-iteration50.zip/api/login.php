<?php
/**
 * login.php — POST {username, password} → admin session.
 * Failures are deliberately generic (no user enumeration) and slightly
 * delayed. Phase 3 adds DB-backed rate limiting (per-IP AND per-username
 * buckets, 5 attempts / 5 min each — see _bootstrap::rate_limit_check()).
 *
 * Both buckets are checked BEFORE the DB lookup so timing doesn't leak user
 * existence. On exceed: 429 + Retry-After. On success: session_regenerate_id
 * (which rotates the CSRF token — frontend re-fetches via api/csrf.php).
 */

require __DIR__ . '/_bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_err('POST only.', 405);
}

$body     = json_body();
$username = trim((string)($body['username'] ?? ''));
$password = (string)($body['password'] ?? '');

if ($username === '' || $password === '') {
    json_err('Username and password are required.', 422);
}

/* ---- Rate limiting (Phase 3) --------------------------------------------- *
 * Two buckets, both checked BEFORE the DB lookup so an attacker can't tell
 * "user doesn't exist" from "rate limit hit" by timing.
 *   login:{ip}       — 5 attempts / 5 min per IP  (one attacker, many users)
 *   login:{username} — 5 attempts / 5 min per user (many attackers, one user)
 *
 * The per-username bucket uses a slugified form so a stray space or case
 * difference doesn't reset the counter (username is case-sensitive in the DB
 * lookup, but the rate-limit bucket should not be). slugify_server is in
 * _bootstrap.php — same function the CMS uses for category slugs. */
$ip = client_ip();
$userSlug = slugify_server($username);

rate_limit_check('login:' . $ip, RATE_LIMIT_LOGIN_MAX, RATE_LIMIT_LOGIN_WINDOW);
// ★ M8 fix (audit): always rate-limit by username, even when slugify returns
//   empty (all special-char usernames like "!!!"). The old code skipped the
//   per-username bucket when $userSlug was empty — an attacker sending garbage
//   usernames bypassed the per-username protection entirely. Fix: use a hash
//   of the raw username as the bucket key when slugify returns empty.
if ($userSlug !== '') {
    rate_limit_check('login:' . $userSlug, RATE_LIMIT_LOGIN_MAX, RATE_LIMIT_LOGIN_WINDOW);
} else {
    rate_limit_check('login:hash:' . hash('sha256', strtolower($username)), RATE_LIMIT_LOGIN_MAX, RATE_LIMIT_LOGIN_WINDOW);
}

$stmt = db()->prepare('SELECT id, username, password_hash, role FROM admin_users WHERE username = ? LIMIT 1');
$stmt->execute([$username]);
$admin = $stmt->fetch();

if (!$admin || !password_verify($password, $admin['password_hash'])) {
    usleep(random_int(100000, 300000)); // blunt brute force & timing probes
    json_err('Invalid username or password.', 401);
}

session_regenerate_id(true); // prevent session fixation → also rotates CSRF token
$_SESSION['admin_id']       = (int)$admin['id'];
$_SESSION['admin_username'] = $admin['username'];
// ★ SEC-13 fix: record the session creation time. require_admin() compares
//   this against admin_users.password_changed_at — if the password was
//   changed after this session started, the session is invalidated (401).
$_SESSION['iat']            = time();
// ★ Phase 8 Batch 2 (Task 59): load the admin's role into the session so
//   require_role() / has_role() can read it without a DB hit on every request.
//   require_admin() also lazy-loads this if missing (covers sessions created
//   before this batch landed — backward compat for admins already logged in
//   when the upgrade is deployed).
$_SESSION['admin_role']     = $admin['role'] ?? 'super_admin';

json_ok([
    'username' => $admin['username'],
    // ★ Phase 8 Batch 2: expose the role to the frontend so the dashboard
    // can hide the Admins tab for non-super_admin admins. The frontend
    // treats this as informational only — every privileged action still
    // hits the API, which enforces the role check server-side.
    'role'     => $_SESSION['admin_role'],
]);

