<?php
/**
 * import.php — ONE-TIME migration endpoint: imports the JSON produced by the
 * OLD localStorage exportJSON() (the dashboard will gain an "Import backup"
 * button in the frontend increment).
 *
 * POST admin body (the exact old export shape):
 * {
 *   "currency": "GHS",
 *   "landing":  { "hero_title": "...", ... },
 *   "categories": [ { "id": "cat_1", "name": "...", "slug": "...", ... } ],
 *   "products":   [ { "id": "prod_1", "name": "...", "categoryId": "cat_1", ... } ]
 * }
 *
 * Semantics (documented, deliberate):
 *   * Sections PRESENT in the body REPLACE the matching table rows, inside
 *     one transaction (all-or-nothing).
 *   * Sections ABSENT are left untouched (close to the old merge behavior,
 *     predictable, no partial surprises).
 *   * Old string ids ("cat_1" -> new INT id) are remapped for products.
 *   * Products whose categoryId points at an unknown category become
 *     uncategorized (same as the old deleteCategory behavior).
 *   * Rows failing validation (name < 2 chars) are skipped, like FIX-BL-18.
 */

require __DIR__ . '/_bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_err('POST only.', 405);
}
require_admin();
verify_csrf();

$b = json_body();
if (!$b) json_err('Empty or malformed JSON body.', 422);

$pdo = db();
$pdo->beginTransaction();
try {
    $result = ['categories' => 0, 'products' => 0, 'landing' => 0, 'currency' => false];
    $catMap = []; // old string id -> new INT id

    /* ---- currency -------------------------------------------------------- */
    if (array_key_exists('currency', $b)) {
        $currency = trim((string)$b['currency']);
        if ($currency !== '' && preg_match(CURRENCY_PATTERN, $currency)) {
            $stmt = $pdo->prepare(
                'INSERT INTO site_settings (setting_key, setting_value) VALUES (?, ?)
                 ON CONFLICT(setting_key) DO UPDATE SET setting_value = excluded.setting_value'
            );
            $stmt->execute(['currency', $currency]);
            $result['currency'] = true;
        }
    }

    /* ---- categories (replace) -------------------------------------------- */
    if (isset($b['categories'])) {
        if (!is_array($b['categories'])) json_err('categories must be an array.', 422);
        $valid = [];
        foreach ($b['categories'] as $c) {
            if (!is_array($c)) continue;
            $name = isset($c['name']) ? trim((string)$c['name']) : '';
            if (mb_strlen($name) < 2) continue; // skip invalid rows, like the old importJSON
            $valid[] = $c;
        }
        $pdo->exec('DELETE FROM categories');
        // ★ RT-02 fix: was `DELETE FROM products` here (inside the categories
        //   block) — the comment claimed "FK children first (SET NULL would
        //   fire otherwise)". But the FK on products.category_id IS
        //   `ON DELETE SET NULL` — deleting categories already nulls
        //   products.category_id cleanly. The explicit DELETE FROM products
        //   was unnecessary AND destructive: if the backup contained
        //   categories but omitted products (a common case for partial
        //   exports), EVERY product in the database was deleted with no
        //   warning. The next block (`if (isset($b['products']))`) was
        //   skipped, so no products were re-inserted. The user's catalog
        //   was gone.
        //   Fix: removed the DELETE FROM products from this block. The
        //   products block below has its own `DELETE FROM products` — so
        //   if the backup includes products, they're fully replaced there.
        //   If the backup omits products, existing products survive (their
        //   category_id is nulled by the FK ON DELETE SET NULL when the
        //   old categories are deleted). This matches the documented
        //   semantics: "Sections ABSENT are left untouched".
        $stmt = $pdo->prepare('INSERT INTO categories (name, slug, description, sort_order) VALUES (?, ?, ?, ?)');
        foreach ($valid as $i => $c) {
            $name = trim((string)$c['name']);
            $slug = isset($c['slug']) && trim((string)$c['slug']) !== '' ? trim((string)$c['slug']) : slugify_server($name);
            $desc = isset($c['description']) ? mb_substr(trim((string)$c['description']), 0, 200) : '';
            $sort = isset($c['sortOrder']) ? (int)$c['sortOrder'] : $i;
            $stmt->execute([$name, $slug, $desc, $sort]);
            $oldId = isset($c['id']) ? (string)$c['id'] : ('#idx' . $i);
            $catMap[$oldId] = (int)$pdo->lastInsertId();
            $result['categories']++;
        }
    }

    /* ---- products (replace) ----------------------------------------------- */
    if (isset($b['products'])) {
        if (!is_array($b['products'])) json_err('products must be an array.', 422);
        $pdo->exec('DELETE FROM products');
        $stmt = $pdo->prepare(
            'INSERT INTO products (name, scent, description, price, category_id, image_path, available)
             VALUES (?, ?, ?, ?, ?, ?, ?)'
        );
        foreach ($b['products'] as $p) {
            if (!is_array($p)) continue;
            $name = isset($p['name']) ? trim((string)$p['name']) : '';
            if (mb_strlen($name) < 2) continue;
            $price = filter_var($p['price'] ?? null, FILTER_VALIDATE_FLOAT);
            if ($price === false || $price <= 0) continue;
            $scent = isset($p['scent']) ? mb_substr(trim((string)$p['scent']), 0, 100) : '';
            $desc  = isset($p['description']) ? mb_substr(trim((string)$p['description']), 0, 500) : '';
            $img   = isset($p['imagePath']) ? (string)$p['imagePath'] : '';
            if (strlen($img) > MAX_IMAGE_CHARS) $img = ''; // skip oversized legacy images rather than fail
            $newCatId = null;
            $oldCat = isset($p['categoryId']) ? (string)$p['categoryId'] : '';
            if ($oldCat !== '' && isset($catMap[$oldCat])) {
                $newCatId = $catMap[$oldCat];
            }
            $available = isset($p['available']) ? to_bool($p['available'], true) : true;
            $stmt->execute([$name, $scent, $desc, round($price, 2), $newCatId, $img, $available ? 1 : 0]);
            $result['products']++;
        }
    }

    /* ---- landing (upsert provided fields only) ----------------------------- */
    if (isset($b['landing'])) {
        if (!is_array($b['landing'])) json_err('landing must be an object.', 422);
        $stmt = $pdo->prepare(
            'INSERT INTO landing_content (section_key, content) VALUES (?, ?)
             ON CONFLICT(section_key) DO UPDATE SET content = excluded.content'
        );
        foreach ($b['landing'] as $key => $value) {
            if (!array_key_exists($key, LANDING_ALLOWED)) continue; // ignore unknown keys
            if (!is_scalar($value)) continue;
            $content = trim((string)$value);
            if ($content === '') continue;
            if (mb_strlen($content) > LANDING_ALLOWED[$key]) $content = mb_substr($content, 0, LANDING_ALLOWED[$key]);
            $stmt->execute([$key, $content]);
            $result['landing']++;
        }
    }

    $pdo->commit();
    json_ok($result);
} catch (Exception $e) {
    $pdo->rollBack();
    error_log('[morbi] Import failed: ' . $e->getMessage()); json_err('Import failed, nothing was changed. Check the server error log for details.', 500);
}
