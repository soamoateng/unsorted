<?php
/**
 * _paystack.php — server-side Paystack helper (Phase 2, "Bicycle").
 *
 * Single Responsibility: wrap Paystack's REST API so the calling endpoints
 * (payments.php, webhook.php, orders.php, refunds.php) don't duplicate
 * cURL boilerplate. The secret key lives in _config.php and is NEVER
 * exposed to the browser — this file is blocked from direct access by
 * api/.htaccess (the leading underscore matches the `^_` FilesMatch rule).
 *
 * Four operations:
 *   paystack_initialize($reference, $amount_kobo, $email, $phone, $metadata)
 *     POST /transaction/initialize — returns Paystack's authorization_url.
 *
 *   paystack_verify($reference)
 *     GET /transaction/verify/{reference} — returns the verification payload
 *     (status, channel, fees, paid_at, customer info). Used by BOTH the
 *     webhook receiver and the payment-callback endpoint for double-confirmation
 *     (Paystack recommends verifying via the API even when the webhook fires,
 *     because webhooks can be delayed or missed).
 *
 *   paystack_refund($reference, $amount_kobo?, $merchant_note?, $customer_note?)
 *     ★ Phase 8 Batch 1 (Task 58, 2026-09-23): POST /refund — initiates a
 *     full (amount omitted) or partial (amount in subunit) refund on a
 *     previously successful transaction. Returns Paystack's refund record
 *     including the refund id and the initial status (typically 'pending'
 *     — the actual settlement happens async; the refund.processed /
 *     refund.failed webhook events update the local row). Docs:
 *     https://paystack.com/docs/refunds
 *
 *   paystack_refund_status($refund_id)
 *     ★ Phase 8 Batch 1 (Task 58): GET /refund/{id} — fetch the current
 *     status of a refund from Paystack's API. Used by the admin detail
 *     view to refresh a stale local row.
 *
 * All functions return ['ok' => bool, 'data' => [...], 'error' => string?].
 * On HTTP failure or Paystack error, ok=false with a human-readable error.
 */

require_once __DIR__ . '/_config.php';

// Reuse the JSON helpers from _bootstrap.php — but _paystack.php is included
// from endpoint files that already require _bootstrap.php, so the helpers
// are available. (We don't require _bootstrap here to avoid double-session
// issues when this file is included from webhook.php which uses a different
// session stance.)

/**
 * Initialize a Paystack transaction.
 *
 * @param string $reference    our order reference (morbi-{ts}-{12hex})
 * @param int    $amount_kobo  amount in subunit (kobo/pesewas/cents). Paystack requires int.
 *                             For GHS: amount × 100. For USD: amount × 100 (cents). For NGN:
 *                             amount × 100 (kobo). All currencies use ×100 subunit per
 *                             https://paystack.com/docs/payments/accept-payments#amount
 * @param string $email        customer email (Paystack requires this field,
 *                             but it can be a synthetic value for MoMo-only
 *                             orders where the customer didn't provide one —
 *                             we pass "{phone}@morbi.shop" as a fallback).
 * @param string $phone        customer phone (passed in metadata for MoMo)
 * @param array  $metadata     extra data to attach (order_id, cart summary)
 * @param string $currency     ★ Phase 8 Batch 3 (Task 60): ISO 4217 currency code
 *                             (GHS, USD, NGN, KES, ZAR). Defaults to PAYSTACK_CURRENCY
 *                             ('GHS') for backward compat. Verified live 2026-09-23:
 *                             Paystack supports NGN, GHS, KES, ZAR, USD for charging.
 * @return array ['ok' => bool, 'data' => [...], 'error' => string?]
 */
function paystack_initialize($reference, $amount_kobo, $email, $phone, $metadata = [], $currency = null) {
    // ★ Phase 8 Batch 3: default to PAYSTACK_CURRENCY for backward compat.
    //   Existing callers that don't pass the 6th arg get 'GHS' — same behavior
    //   as before this batch. New callers pass the customer's selected charging
    //   currency (already validated against the currencies table + Paystack's
    //   supported list in payments.php).
    $currency = $currency ?: PAYSTACK_CURRENCY;

    $body = [
        'reference'       => $reference,
        'amount'           => (int)$amount_kobo,
        'email'           => $email,
        'currency'        => $currency,
        'callback_url'    => PAYSTACK_CALLBACK_URL,
        'metadata'        => array_merge([
            'phone'      => $phone,
            'order_ref'  => $reference,
            'source'     => 'morbi.shop',
        ], $metadata),
        // Mobile money is the dominant channel in Ghana. Paystack's hosted
        // checkout lets the customer pick; we don't restrict channels here
        // so card / bank / USSD all still work for users who prefer them.
        'channels'        => ['mobile_money', 'card', 'bank', 'ussd'],
    ];

    $resp = _paystack_request('POST', '/transaction/initialize', $body);
    if (!$resp['ok']) return $resp;

    // Paystack returns { status: true, data: { authorization_url, reference, access_token } }
    $data = $resp['data']['data'] ?? null;
    if (!$data || empty($data['authorization_url'])) {
        return ['ok' => false, 'error' => 'Paystack did not return an authorization URL.'];
    }
    return ['ok' => true, 'data' => $data];
}

/**
 * Verify a Paystack transaction by reference. Used by BOTH the webhook
 * receiver (after the signature check) and the payment-callback endpoint
 * (after the redirect). Idempotent — verifying an already-verified
 * transaction returns the same payload.
 *
 * @param string $reference
 * @return array ['ok' => bool, 'data' => [...], 'error' => string?]
 *   On success, data contains: { status: 'success'|'failed'|'abandoned'|...,
 *   channel, amount (kobo), fees, paid_at, customer: {email, phone?} }
 */
function paystack_verify($reference) {
    $resp = _paystack_request('GET', '/transaction/verify/' . urlencode($reference));
    if (!$resp['ok']) return $resp;

    $data = $resp['data']['data'] ?? null;
    if (!$data) {
        return ['ok' => false, 'error' => 'Paystack verify returned no data.'];
    }
    // Normalize the fields we care about so callers don't dig into nested arrays.
    $normalized = [
        'reference'      => $data['reference'] ?? $reference,
        'status'         => $data['status'] ?? 'unknown',          // 'success' | 'failed' | 'abandoned' | 'ongoing'
        'amount_kobo'    => (int)($data['amount'] ?? 0),
        'currency'       => $data['currency'] ?? PAYSTACK_CURRENCY,
        'channel'        => $data['channel'] ?? null,               // 'mobile_money' | 'card' | ...
        'fees_kobo'      => isset($data['fees']) ? (int)$data['fees'] : null,
        'paid_at'        => $data['paid_at'] ?? null,
        'customer_email' => $data['customer']['email'] ?? null,
        'customer_phone' => $data['customer']['phone'] ?? null,    // not always present
        'gateway_response' => $data['gateway_response'] ?? null,   // human-readable status message
    ];
    return ['ok' => true, 'data' => $normalized];
}

/**
 * Internal: send a Paystack API request via cURL. Returns the decoded JSON
 * body + HTTP status. Throws nothing — every error becomes a non-ok return.
 */
function _paystack_request($method, $path, $body = null) {
    // Defensive: refuse to operate if the secret key is still the placeholder.
    // Better to fail loudly than to send malformed auth headers to Paystack.
    if (!defined('PAYSTACK_SECRET_KEY') || strpos(PAYSTACK_SECRET_KEY, 'REPLACE') !== false) {
        return ['ok' => false, 'error' => 'Paystack secret key is not configured. Edit api/_config.php.'];
    }

    $url = rtrim(PAYSTACK_BASE_URL, '/') . $path;
    $ch = curl_init($url);

    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CUSTOMREQUEST  => $method,
        CURLOPT_HTTPHEADER     => [
            'Authorization: Bearer ' . PAYSTACK_SECRET_KEY,
            'Content-Type: application/json',
            'Cache-Control: no-cache',
        ],
        CURLOPT_TIMEOUT        => 30,   // Paystack is normally <1s; 30s is generous
        CURLOPT_CONNECTTIMEOUT => 10,
    ]);

    if ($body !== null) {
        $json = json_encode($body);
        if ($json === false) {
            return ['ok' => false, 'error' => 'Could not encode request body as JSON.'];
        }
        curl_setopt($ch, CURLOPT_POSTFIELDS, $json);
    }

    $raw = curl_exec($ch);
    $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlErr = curl_error($ch);
    curl_close($ch);

    if ($raw === false || $curlErr) {
        return ['ok' => false, 'error' => 'Network error talking to Paystack: ' . $curlErr];
    }

    $decoded = json_decode($raw, true);
    if (!is_array($decoded)) {
        return ['ok' => false, 'error' => 'Paystack returned non-JSON response (HTTP ' . $status . ').'];
    }

    // Paystack's envelope: { status: bool, message: string, data: {...} }
    // A 200 with status:false means Paystack understood the request but refused
    // it (e.g., duplicate reference, invalid amount). Surface the message.
    if ($status < 200 || $status >= 300) {
        $msg = $decoded['message'] ?? ('Paystack returned HTTP ' . $status);
        return ['ok' => false, 'error' => $msg, 'data' => $decoded];
    }
    if (empty($decoded['status'])) {
        $msg = $decoded['message'] ?? 'Paystack declined the request (no message).';
        return ['ok' => false, 'error' => $msg, 'data' => $decoded];
    }

    return ['ok' => true, 'data' => $decoded, 'status' => $status];
}

/**
 * Generate a unique order reference. Format: morbi-{timestamp}-{12hex}.
 * Same shape as the upload filename pattern in upload.php.
 */
function generate_order_reference(): string {
    return sprintf('%s-%d-%s', ORDER_REF_PREFIX, time(), bin2hex(random_bytes(6)));
}

/* ──────────────────────────────────────────────────────────────────────────
 * ★ Phase 8 Batch 1 (Task 58, 2026-09-23): Refund helpers.
 *
 * Verified live against Paystack docs (https://paystack.com/docs/refunds,
 * accessed 2026-09-23):
 *   - Endpoint: POST https://api.paystack.co/refund
 *   - Body: { transaction: <ref_or_id>, amount?: <subunit_int>,
 *            currency?: <code>, merchant_note?: <str>,
 *            customer_note?: <str> }
 *   - If `amount` is omitted → full refund. If provided → partial refund.
 *   - Each partial refund creates a separate ledger entry (Paystack docs,
 *     mctaba.com July 2026).
 *   - Response: { status: true, message: "Refund created",
 *                 data: { id, integration, domain, currency, amount,
 *                         channel, transaction, status: "pending"|...,
 *                         merchant_note, customer_note, created_at, ... } }
 *
 *   Status fetch endpoint: GET /refund/{id}
 *   - Returns the same shape with the latest status (processed/failed/...)
 *
 * All amounts in subunit (kobo/pesewas/cents) to match Paystack's contract.
 * The refunds table + orders.refunded_amount track amounts in MAJOR unit
 * (decimal GHS) because that's what the storefront + dashboard display.
 * Conversion is the caller's responsibility — see api/refunds.php.
 * ────────────────────────────────────────────────────────────────────────── */

/**
 * Initiate a refund on a Paystack transaction.
 *
 * @param string      $reference      the order's Paystack reference (morbi-{ts}-{12hex})
 * @param int|null    $amount_kobo    null = full refund; int = partial refund in subunit
 * @param string|null $merchant_note  internal reason (admin-visible only)
 * @param string|null $customer_note  note Paystack shows the customer
 * @return array ['ok' => bool, 'data' => [...], 'error' => string?]
 *   On success, data contains: { refund_id, status, amount_kobo,
 *   currency, transaction_reference, created_at }
 */
function paystack_refund(string $reference, ?int $amount_kobo = null, ?string $merchant_note = null, ?string $customer_note = null): array {
    $body = ['transaction' => $reference];
    // ★ M7 fix (audit): reject amount_kobo=0 explicitly. The old code used
    //   `> 0` which let 0 fall through to "no amount key" → Paystack treats
    //   missing amount as a FULL refund. A caller passing 0 (intended as
    //   a 0-value partial refund, which is invalid) would get a full refund.
    if ($amount_kobo !== null) {
        if ($amount_kobo <= 0) {
            return ['ok' => false, 'error' => 'amount_kobo must be a positive integer, or null for a full refund.'];
        }
        $body['amount'] = $amount_kobo;
    }
    if ($merchant_note !== null && $merchant_note !== '') {
        $body['merchant_note'] = $merchant_note;
    }
    if ($customer_note !== null && $customer_note !== '') {
        $body['customer_note'] = $customer_note;
    }

    $resp = _paystack_request('POST', '/refund', $body);
    if (!$resp['ok']) return $resp;

    $data = $resp['data']['data'] ?? null;
    if (!$data) {
        return ['ok' => false, 'error' => 'Paystack did not return refund data.'];
    }
    // Normalize so callers don't dig into nested arrays.
    $normalized = [
        'refund_id'              => isset($data['id']) ? (int)$data['id'] : null,
        'status'                 => $data['status'] ?? 'pending',  // 'pending' | 'processed' | 'failed' | 'processing'
        'amount_kobo'            => isset($data['amount']) ? (int)$data['amount'] : 0,
        'currency'               => $data['currency'] ?? PAYSTACK_CURRENCY,
        'transaction_reference' => $data['transaction']['reference'] ?? $reference,
        'merchant_note'          => $data['merchant_note'] ?? null,
        'customer_note'          => $data['customer_note'] ?? null,
        'created_at'             => $data['createdAt'] ?? ($data['created_at'] ?? null),
    ];
    return ['ok' => true, 'data' => $normalized];
}

/**
 * Fetch the current status of a refund from Paystack. Used to refresh
 * stale local rows in the refunds table (e.g., admin clicked "Refresh
 * status" or the webhook was missed/delayed).
 *
 * @param int $refund_id  Paystack's refund ID (the local refunds.paystack_refund_id)
 * @return array ['ok' => bool, 'data' => [...], 'error' => string?]
 */
function paystack_refund_status(int $refund_id): array {
    $resp = _paystack_request('GET', '/refund/' . urlencode((string)$refund_id));
    if (!$resp['ok']) return $resp;

    $data = $resp['data']['data'] ?? null;
    if (!$data) {
        return ['ok' => false, 'error' => 'Paystack did not return refund data.'];
    }
    $normalized = [
        'refund_id'              => isset($data['id']) ? (int)$data['id'] : null,
        'status'                 => $data['status'] ?? 'unknown',
        'amount_kobo'            => isset($data['amount']) ? (int)$data['amount'] : 0,
        'currency'               => $data['currency'] ?? PAYSTACK_CURRENCY,
        'transaction_reference'  => $data['transaction']['reference'] ?? null,
        'merchant_note'          => $data['merchant_note'] ?? null,
        'customer_note'          => $data['customer_note'] ?? null,
        'created_at'             => $data['createdAt'] ?? ($data['created_at'] ?? null),
        'settled_at'             => $data['settledAt'] ?? ($data['settled_at'] ?? null),
    ];
    return ['ok' => true, 'data' => $normalized];
}
