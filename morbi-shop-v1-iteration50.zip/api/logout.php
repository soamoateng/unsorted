<?php
/**
 * logout.php — POST → destroys the admin session.
 *
 * ★ SEC-04 fix: added verify_csrf(). Was: no CSRF check — the endpoint
 *   relied solely on the SameSite=Lax session cookie. SameSite=Lax is
 *   bypassable on same-site subdomains (e.g. blog.morbi.shop can
 *   cross-POST to morbi.shop), and any future relaxation of the cookie
 *   policy makes it trivially exploitable. A successful CSRF logout is a
 *   UX-level denial-of-service + a building block for session-fixation
 *   chains.
 *   Fix: call verify_csrf() after the POST check. The frontend's api()
 *   helper auto-attaches X-CSRF-Token on every non-GET request (including
 *   logout) — the server just needs to verify it. If the admin is logged
 *   in, the session has a csrf_token → the POST's X-CSRF-Token matches →
 *   verification passes → session is destroyed. If not logged in (no
 *   session csrf_token) → verify_csrf() returns 403 (correct — can't log
 *   out if not logged in). If it's a CSRF attack (cross-site POST without
 *   the token) → verify_csrf() returns 403 (correct — CSRF blocked).
 */

require __DIR__ . '/_bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_err('POST only.', 405);
}

// ★ SEC-04 fix: verify the CSRF token before destroying the session.
// The frontend's api() helper attaches X-CSRF-Token on every non-GET
// request — this call verifies it. Without this, a cross-site POST
// (e.g. <form action=".../logout.php" method="POST"> auto-submitted
// from blog.morbi.shop) could destroy the admin's session.
verify_csrf();

$_SESSION = [];

if (ini_get('session.use_cookies')) {
    $p = session_get_cookie_params();
    setcookie(session_name(), '', [
        'expires'  => time() - 42000,
        'path'     => $p['path'],
        'domain'   => $p['domain'],
        'secure'   => $p['secure'],
        'httponly' => $p['httponly'],
        'samesite' => 'Lax',
    ]);
}

session_destroy();

json_ok(['loggedOut' => true]);
