<?php
/**
 * reset-defaults.php — Phase 3 (Motorcycle) Batch 4 server-side reset.
 *
 *   POST  admin (CSRF-protected)  -> { reset: true, counts: {categories, products, landing, settings, tokens} }
 *
 * What it does:
 *   1. TRANSACTIONALLY wipes + re-seeds the CMS tables to their install-time
 *      defaults: products, categories, landing_content, site_settings
 *      (currency + the 11 design tokens). The defaults mirror exactly what
 *      install.php seeds on first run — same products, same categories,
 *      same landing copy, same currency, same 11 token_* rows.
 *   2. DOES NOT touch: admin_users (your password stays), orders,
 *      order_items, rate_limit_log, password_resets (audit trails + active
 *      sessions stay). This is a CONTENT reset, not a system reset.
 *   3. Returns counts of what was reset so the dashboard can flash a
 *      friendly summary.
 *
 * Why transactional: a partial reset (e.g. categories deleted but products
 * not) would leave the DB in an inconsistent state — products pointing at
 * category_ids that don't exist. The FK is ON DELETE SET NULL, so the
 * orphaned products would survive, but the dashboard would show "no
 * categories" until the re-seed finished. Wrapping in a transaction means
 * either everything resets or nothing does.
 *
 * Why no dry-run: the dashboard's confirm dialog shows the user the EXACT
 * counts of what will be deleted (queried client-side before the call) —
 * cheaper than a server-side dry-run, same safety. The server endpoint
 * just executes the reset.
 *
 * Security:
 *   * Admin-only (require_admin guard).
 *   * CSRF-protected (verify_csrf() — POST is non-GET, so X-CSRF-Token is
 *     required + verified).
 *   * Not rate-limited (admin-only + CSRF is enough; rate-limiting a
 *     destructive admin action would just frustrate the admin).
 */

require __DIR__ . '/_bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_err('POST only.', 405);
}
require_admin();
// ★ Phase 8 Batch 2 (Task 59): restrict the destructive site-reset to
// super_admin only. An 'admin' role can manage products/orders/discounts
// but cannot wipe the entire CMS back to install-time defaults. This is
// the only existing endpoint that needed a role gate — the rest of the
// CMS endpoints (products.php, categories.php, landing.php, sections.php,
// discounts.php, tokens.php, orders.php, refunds.php) remain accessible
// to both roles.
require_role('super_admin');
verify_csrf();

$pdo = db();
$pdo->beginTransaction();
$counts = ['categories' => 0, 'products' => 0, 'landing' => 0, 'settings' => 0, 'tokens' => 0];

try {
    /* 1. Wipe CMS tables (NOT admin_users, orders, order_items, rate_limit_log, password_resets) */
    // ★ BL-17 fix: BEFORE the DELETE, snapshot the existing products' stock +
    //   scent_category values (keyed by name). The re-seed below uses these
    //   preserved values when the default product's name matches an existing
    //   row — so the admin's stock-tracking + scent-tagging configuration
    //   on the 4 default products survives the reset. Without this, the
    //   re-seed hardcoded stock=NULL (unlimited) + scent_category=NULL,
    //   silently discarding any configuration the admin had set.
    //   Products whose names DON'T match a default product name are simply
    //   deleted (the admin renamed or replaced them — they're treated as
    //   non-default and not preserved).
    $preserve = [];  // name → ['stock' => int|null, 'scent_category' => string|null]
    $presStmt = db()->prepare('SELECT name, stock, scent_category FROM products');
    $presStmt->execute();
    foreach ($presStmt->fetchAll() as $row) {
        $preserve[$row['name']] = [
            'stock'          => $row['stock'] !== null ? (int)$row['stock'] : null,
            'scent_category' => $row['scent_category'] !== null ? (string)$row['scent_category'] : null,
        ];
    }

    $pdo->exec('DELETE FROM products');
    $pdo->exec('DELETE FROM categories');
    $pdo->exec('DELETE FROM landing_content');
    // site_settings: delete currency + token_* rows only (other settings, if any, are preserved)
    $pdo->exec("DELETE FROM site_settings WHERE setting_key = 'currency' OR setting_key LIKE 'token_%'");

    /* 2. Re-seed categories (same defaults as install.php) */
    $stmt = $pdo->prepare(
        'INSERT INTO categories (name, slug, description, sort_order) VALUES (?, ?, ?, ?)'
    );
    $defaultCats = [
        ['Eau de Parfum', 'Long-lasting signature scents'],
        ['Body Mist', 'Light, everyday freshness'],
        ['Accessories', 'Perfume accessories and gift sets'],
    ];
    foreach ($defaultCats as $i => $cat) {
        $stmt->execute([$cat[0], slugify_server($cat[0]), $cat[1], $i]);
    }
    $counts['categories'] = count($defaultCats);

    /* 3. Re-seed products (same defaults as install.php) — but PRESERVE stock
     *    + scent_category from any existing row with the same name (BL-17 fix
     *    + BL-16 blind-spot — the admin may have tagged the default products
     *    with male/female/unisex via the new dashboard editor; that tagging
     *    should survive a reset-to-defaults). New products (no name match in
     *    $preserve) get stock=NULL + scent_category='unisex' (matches the
     *    install.php seed for fresh installs). */
    $catIds = [];
    foreach ($pdo->query('SELECT id, name FROM categories')->fetchAll() as $row) {
        $catIds[$row['name']] = (int)$row['id'];
    }
    $stmt = $pdo->prepare(
        'INSERT INTO products (name, scent, scent_category, description, price, category_id, available, stock)
         VALUES (?, ?, ?, ?, ?, ?, 1, ?)'
    );
    $defaultProducts = [
        ['Oud Royale', 'Woody, Spicy', 'A bold oriental blend of oud, amber, and black pepper. For the unapologetic.', 180, 'Eau de Parfum'],
        ['Velvet Bloom', 'Floral, Sweet', 'Rose, jasmine, and vanilla. Soft power in a bottle.', 150, 'Eau de Parfum'],
        ['Citrus Pulse', 'Fresh, Citrus', 'Bergamot, lemon zest, and green tea. Your morning ritual.', 120, 'Eau de Parfum'],
        ['Ocean Breeze Mist', 'Aquatic, Light', 'Sea salt, cucumber, and white musk. Fresh all day.', 65, 'Body Mist'],
    ];
    foreach ($defaultProducts as $p) {
        // Look up preserved values for this product name; fall back to
        // stock=NULL + scent_category='unisex' (the install.php defaults).
        $preserved = $preserve[$p[0]] ?? ['stock' => null, 'scent_category' => 'unisex'];
        $stmt->execute([
            $p[0],                          // name
            $p[1],                          // scent
            $preserved['scent_category'],   // scent_category (preserved OR 'unisex')
            $p[2],                          // description
            $p[3],                          // price
            $catIds[$p[4]],                 // category_id
            $preserved['stock'],            // stock (preserved OR NULL = unlimited)
        ]);
    }
    $counts['products'] = count($defaultProducts);

    /* 4. Re-seed landing_content (same defaults as install.php) */
    $stmt = $pdo->prepare('INSERT INTO landing_content (section_key, content) VALUES (?, ?)');
    $defaultLanding = [
        'hero_title'      => 'Luxury Scents, Redefined.',
        'hero_subtitle'   => 'Morcenzs, handcrafted perfumes and accessories for those who leave an impression.',
        'about_heading'   => 'About Morbi',
        'about_text_1'    => 'Morbi is a creative entrepreneur and the founder of Morcenzs, a homegrown fragrance brand born from a passion for self-expression through scent.',
        'about_text_2'    => 'Every Morcenzs bottle is curated with care, from bold, attention-grabbing signatures to subtle everyday essentials.',
        'featured_heading' => 'Featured Scents',
        'featured_sub'    => 'A selection from the Morcenzs collection. Visit the store for the full range.',
        'footer_text'     => 'Morcenzs by Morbi. All rights reserved.',
    ];
    foreach ($defaultLanding as $key => $content) {
        $stmt->execute([$key, $content]);
    }
    $counts['landing'] = count($defaultLanding);

    /* 5. Re-seed site_settings.currency */
    $stmt = $pdo->prepare('INSERT INTO site_settings (setting_key, setting_value) VALUES (?, ?)');
    $stmt->execute(['currency', 'GHS']);
    $counts['settings'] = 1;

    /* 6. Re-seed the 11 design tokens (same defaults as install.php + tokens.php TOKEN_CATALOG) */
    $defaultTokens = [
        'bg_deep'       => '#000000',
        'bg_mid'        => '#111111',
        'bg_card'       => '#1a1a1a',
        'accent'        => '#D4AF37',
        'accent_strong' => '#C8A951',
        'accent_hover'  => '#E5C654',
        'danger'        => '#dc2626',
        'muted'         => '#b8b8b8',  /* ★ UI-11 fix: lighter grey for WCAG AA on small text */
        'ok'            => '#2D8B4E',
        'border'        => '#333333',
        'green'         => '#2D8B4E',
    ];
    foreach ($defaultTokens as $name => $hex) {
        $stmt->execute(['token_' . $name, $hex]);
    }
    $counts['tokens'] = count($defaultTokens);

    $pdo->commit();
} catch (Exception $e) {
    $pdo->rollBack();
    error_log('[morbi] Reset failed: ' . $e->getMessage()); json_err('Reset failed. Check the server error log for details.', 500);
}

json_ok([
    'reset'  => true,
    'counts' => $counts,
    'note'   => 'CMS content reset to defaults. Admin account, orders, and audit trails were preserved.',
]);
