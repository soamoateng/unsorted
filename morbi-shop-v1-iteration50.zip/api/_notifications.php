<?php
/**
 * _notifications.php — ★ Phase 9 Batch 2 (Task 62, 2026-09-23) email
 * notification helper.
 *
 * Single Responsibility: send transactional email notifications on key
 * order/refund events, with idempotency so the webhook's retry loop
 * (Paystack retries at 5min/30min/2h/12h) doesn't double-send the same
 * order-confirmation email.
 *
 * Three notification types:
 *   notify_admin_new_order($order_id)
 *     Fires when a NEW order is CREATED (status='pending') — i.e., the
 *     customer clicked "Pay" and we created the order row + called
 *     Paystack /transaction/initialize. Tells Morbi "a new order came in,
 *     the customer is on the Paystack page." Called from api/payments.php
 *     AFTER the Paystack init succeeds.
 *
 *   notify_customer_order_paid($order_id)
 *     Fires when an order transitions to 'paid' (via the webhook's
 *     charge.success handler). Sends the customer a receipt-style email
 *     with the order summary + charged amount (in the charged currency).
 *     Skipped if orders.customer_email is NULL (MoMo-only orders where
 *     the customer didn't provide an email — they get Paystack's generic
 *     receipt instead).
 *
 *   notify_customer_refund_processed($order_id, $refund_id)
 *     Fires when a refund is initiated via api/refunds.php?action=initiate.
 *     Sends the customer a "refund of X has been initiated" email. The
 *     refund.processed webhook event updates the refund's status, but we
 *     don't send a second email at that point — one notification per
 *     refund action is enough.
 *
 * Idempotency:
 *   Each notification inserts a row in `notification_log` with a UNIQUE KEY
 *   on (type, order_id, refund_id). If the insert fails with a duplicate-key
 *   error (SQLSTATE 23000), the notification was already sent — we skip
 *   silently. This handles the webhook retry loop: the 2nd/3rd/4th retry of
 *   a charge.success webhook finds the order already 'paid' (BL-15 idempotency
 *   guard in webhook.php short-circuits) AND finds the notification_log row
 *   already present — both no-ops.
 *
 * Recipients:
 *   - Admin notifications go to site_settings.notify_admin_email (the admin
 *     sets this in the dashboard). If empty, the notification is logged as
 *     'skipped' — defense in depth against sending to a wrong address.
 *   - Customer notifications go to orders.customer_email. If NULL (MoMo-only),
 *     logged as 'skipped' — Paystack's own receipt covers the customer.
 *
 * From: address:
 *   Uses site_settings.notify_from_email (defaults to SMTP_FROM). The From:
 *   name uses site_settings.notify_from_name (defaults to 'morbi.shop').
 *
 * Failure handling:
 *   On SMTP failure: the notification_log row is updated with status='failed'
 *   + error_message. The webhook returns 200 to Paystack (the order was
 *   already marked 'paid' — the customer isn't penalized for an email
 *   failure). The admin can see the failure in notification_log + retry
 *   manually if needed (future dashboard feature).
 *
 * Blocked from direct web access by api/.htaccess (leading underscore).
 */

require_once __DIR__ . '/_config.php';
require_once __DIR__ . '/_mailer.php';

/* ---- Helpers -------------------------------------------------------------- */

/**
 * Read a single site_settings value by key. Returns null if not set.
 * Used for the notify_* settings (set in the dashboard, not in _config.php).
 */
function _notif_setting(string $key): ?string {
    static $cache = [];
    if (array_key_exists($key, $cache)) return $cache[$key];
    try {
        $stmt = db()->prepare('SELECT setting_value FROM site_settings WHERE setting_key = ? LIMIT 1');
        $stmt->execute([$key]);
        $row = $stmt->fetch();
        $val = $row ? (string)$row['setting_value'] : null;
        $cache[$key] = $val;
        return $val;
    } catch (Throwable $e) {
        return null;
    }
}

/**
 * Insert a notification_log row. Returns true on insert (new), false on
 * duplicate-key (already sent — idempotency hit). Throws on other errors.
 *
 * The UNIQUE KEY uq_notif_dedup (type, order_id, refund_id) is the
 * idempotency guard. We use INSERT IGNORE + check rowCount to detect the
 * duplicate (cleaner than catching SQLSTATE 23000 — works on all MySQL
 * forks + doesn't pollute the error log).
 */
// ★ L3 fix (audit): refund_id is now NOT NULL DEFAULT 0 in the DB schema.
//   The function signature matches: int (not ?int) so callers can't pass null.
// ★ SQLITE FIX (2026-09-26) M4: order_id column is now NOT NULL DEFAULT 0
//   (via migration). COALESCE the PHP-side null to 0 so the INSERT never
//   violates the constraint. All 6 call sites pass non-null today, but this
//   defends against a future caller that passes null.
function _notif_log_insert(string $type, ?string $recipient, ?int $orderId, int $refundId): bool {
    $stmt = db()->prepare(
        'INSERT OR IGNORE INTO notification_log (type, recipient, order_id, refund_id, status)
         VALUES (?, ?, ?, ?, ?)'
    );
    // Insert with status='sent' optimistically — updated to 'failed' or
    // 'skipped' below if the send fails or is skipped.
    // ★ M4: COALESCE null orderId → 0 (matches the column's DEFAULT 0).
    $stmt->execute([$type, $recipient, $orderId ?? 0, $refundId, 'sent']);
    return $stmt->rowCount() > 0;  // true = new row inserted, false = duplicate ignored
}

/**
 * Update the status of the most-recent notification_log row for a given
 * (type, order_id, refund_id). Used to mark 'failed' or 'skipped' after
 * the initial insert.
 */
// ★ Migration 2026-09-26: was `order_id <=> ?` — the `<=>` NULL-safe
//   equality operator is MySQL-only. SQLite throws
//   `SQLITE_ERROR: near "<=>": syntax error`. SQLite's equivalent is
//   `IS` (e.g. `order_id IS ?`) which handles NULL=NULL correctly.
//   ★ Migration 2026-09-26 (M8 fix): changed `refund_id = ?` to `refund_id IS ?`
//   for consistency with order_id. Defends against a future caller passing
//   null (the function signature allows ?int). `IS` is NULL-safe in SQLite.
//   ★ Migration 2026-09-26 (M4 fix): order_id column is now NOT NULL DEFAULT 0
//   (via migration). The COALESCE in _notif_log_insert ensures NULL never
//   lands in the column even if a caller passes null.
//   ★ Migration 2026-09-26 (part 2): was `UPDATE ... ORDER BY id DESC LIMIT 1`
//   — SQLite does NOT support ORDER BY + LIMIT on UPDATE statements (only
//   MySQL does). Fix: select the id first via a subquery, then UPDATE by id.
function _notif_log_update_status(string $type, ?int $orderId, ?int $refundId, string $status, ?string $errorMessage): void {
    $stmt = db()->prepare(
        'UPDATE notification_log
         SET status = ?, error_message = ?
         WHERE id = (
            SELECT id FROM notification_log
            WHERE type = ? AND order_id IS ? AND refund_id IS ?
            ORDER BY id DESC LIMIT 1
         )'
    );
    $stmt->execute([$status, $errorMessage, $type, $orderId, $refundId]);
}

/**
 * Fetch an order row + its items for the notification email body.
 * Returns null if the order doesn't exist.
 */
// ★ Migration 2026-09-26: was `SELECT name, scent, price, qty FROM order_items`
//   but the actual schema columns are `product_name`, `variant_name`,
//   `unit_price`, `quantity`. (There is NO `scent` column — scent is on the
//   `products` table, not `order_items`.) The old query was throwing
//   `SQLITE_ERROR: no such column: name` and the email body had no items.
//   Now selects the correct columns and aliases them to the PHP-expected
//   names so the email-formatting helpers (`_notif_format_items_html` +
//   the `array_map` calls below) keep working unchanged.
function _notif_fetch_order(int $orderId): ?array {
    $stmt = db()->prepare('SELECT * FROM orders WHERE id = ? LIMIT 1');
    $stmt->execute([$orderId]);
    $order = $stmt->fetch();
    if (!$order) return null;
    $itemsStmt = db()->prepare(
        'SELECT product_name AS name, variant_name AS scent, unit_price AS price, quantity AS qty
         FROM order_items WHERE order_id = ? ORDER BY id ASC'
    );
    $itemsStmt->execute([$orderId]);
    $order['items'] = $itemsStmt->fetchAll();
    return $order;
}

/**
 * Format the order items as an HTML table for the email body.
 */
function _notif_format_items_html(array $items): string {
    if (empty($items)) return '<p><em>No items in this order.</em></p>';
    $rows = '';
    foreach ($items as $it) {
        $name = htmlspecialchars((string)$it['name'], ENT_QUOTES, 'UTF-8');
        $scent = htmlspecialchars((string)($it['scent'] ?? ''), ENT_QUOTES, 'UTF-8');
        $price = htmlspecialchars((string)$it['price'], ENT_QUOTES, 'UTF-8');
        $qty = (int)$it['qty'];
        $subtotal = number_format((float)$it['price'] * $qty, 2, '.', '');
        $rows .= "<tr><td>{$name}" . ($scent ? " ({$scent})" : '') . "</td>"
               . "<td style=\"text-align:right;\">{$price}</td>"
               . "<td style=\"text-align:center;\">{$qty}</td>"
               . "<td style=\"text-align:right;\">{$subtotal}</td></tr>";
    }
    return "<table style=\"border-collapse:collapse;width:100%;font-size:14px;\">"
         . "<thead><tr style=\"border-bottom:1px solid #ddd;\">"
         . "<th style=\"text-align:left;padding:4px;\">Product</th>"
         . "<th style=\"text-align:right;padding:4px;\">Price</th>"
         . "<th style=\"text-align:center;padding:4px;\">Qty</th>"
         . "<th style=\"text-align:right;padding:4px;\">Subtotal</th>"
         . "</tr></thead><tbody>{$rows}</tbody></table>";
}

/* ---- Public notification functions --------------------------------------- */

/**
 * Notify the admin that a new order was created. Called from api/payments.php
 * AFTER the Paystack init succeeds (the order is 'pending', the customer is
 * on the Paystack page).
 *
 * @param int $orderId  the orders.id of the new order
 * @return array ['ok' => bool, 'skipped' => bool, 'error' => string?]
 */
function notify_admin_new_order(int $orderId): array {
    $order = _notif_fetch_order($orderId);
    if (!$order) return ['ok' => false, 'error' => 'Order not found.'];

    $adminEmail = _notif_setting('notify_admin_email');
    if (!$adminEmail) {
        // Log as 'skipped' so the admin can see in notification_log that
        // notifications are NOT being sent + knows to set notify_admin_email.
        _notif_log_insert('admin_new_order', null, $orderId, 0);
        _notif_log_update_status('admin_new_order', $orderId, 0, 'skipped',
            'notify_admin_email is not configured. Set it in the dashboard.');
        return ['ok' => false, 'skipped' => true, 'error' => 'notify_admin_email not configured.'];
    }

    // Idempotency check — if already sent, skip.
    if (!_notif_log_insert('admin_new_order', $adminEmail, $orderId, 0)) {
        return ['ok' => true, 'skipped' => true, 'error' => 'Already sent (idempotency).'];
    }

    $total = number_format((float)$order['total_amount'], 2, '.', '');
    $currency = htmlspecialchars((string)$order['currency'], ENT_QUOTES, 'UTF-8');
    $name = htmlspecialchars((string)$order['customer_name'], ENT_QUOTES, 'UTF-8');
    $phone = htmlspecialchars((string)$order['customer_phone'], ENT_QUOTES, 'UTF-8');
    $ref = htmlspecialchars((string)$order['reference'], ENT_QUOTES, 'UTF-8');
    $itemsHtml = _notif_format_items_html($order['items']);

    $subject = "New order #{$orderId} — {$currency}{$total}";
    $html = "<h2>New order received</h2>"
          . "<p><strong>Order #{$orderId}</strong> (ref: {$ref})</p>"
          . "<p><strong>Customer:</strong> {$name}<br>"
          . "<strong>Phone:</strong> {$phone}</p>"
          . "<p><strong>Total:</strong> {$currency} {$total} <em>(status: pending — customer is on Paystack page)</em></p>"
          . $itemsHtml
          . "<p style=\"margin-top:16px;color:#666;font-size:12px;\">Sent from morbi.shop — Phase 9 Batch 2 notifications.</p>";
    $text = "New order #{$orderId} (ref: {$ref})\n"
          . "Customer: {$name}\n"
          . "Phone: {$phone}\n"
          . "Total: {$currency} {$total} (status: pending)\n\n"
          . "Items:\n" . implode("\n", array_map(function ($it) {
              return "- {$it['name']}" . ($it['scent'] ? " ({$it['scent']})" : '') . " x {$it['qty']} @ {$it['price']}";
          }, $order['items']));

    $result = send_mail($adminEmail, $subject, $html, $text);
    if (!$result['ok']) {
        _notif_log_update_status('admin_new_order', $orderId, 0, 'failed', $result['error']);
        error_log('[morbi] admin_new_order notification failed for order ' . $orderId . ': ' . $result['error']);
    }
    return $result;
}

/**
 * Notify the customer that their order was paid. Called from api/webhook.php
 * on charge.success transition (order goes from 'pending' → 'paid').
 *
 * @param int $orderId  the orders.id of the paid order
 * @return array ['ok' => bool, 'skipped' => bool, 'error' => string?]
 */
function notify_customer_order_paid(int $orderId): array {
    $order = _notif_fetch_order($orderId);
    if (!$order) return ['ok' => false, 'error' => 'Order not found.'];

    $customerEmail = (string)($order['customer_email'] ?? '');
    if ($customerEmail === '' || !filter_var($customerEmail, FILTER_VALIDATE_EMAIL)) {
        // MoMo-only order with no email — Paystack's own receipt covers the
        // customer. Log as 'skipped'.
        _notif_log_insert('customer_order_paid', null, $orderId, 0);
        _notif_log_update_status('customer_order_paid', $orderId, 0, 'skipped',
            'No customer email on order (MoMo-only).');
        return ['ok' => false, 'skipped' => true, 'error' => 'No customer email on order.'];
    }

    // Idempotency check — if already sent, skip.
    if (!_notif_log_insert('customer_order_paid', $customerEmail, $orderId, 0)) {
        return ['ok' => true, 'skipped' => true, 'error' => 'Already sent (idempotency).'];
    }

    $total = number_format((float)$order['total_amount'], 2, '.', '');
    $currency = htmlspecialchars((string)$order['currency'], ENT_QUOTES, 'UTF-8');
    $name = htmlspecialchars((string)$order['customer_name'], ENT_QUOTES, 'UTF-8');
    $ref = htmlspecialchars((string)$order['reference'], ENT_QUOTES, 'UTF-8');
    $itemsHtml = _notif_format_items_html($order['items']);

    $subject = "Your morbi.shop order #{$orderId} is confirmed";
    $html = "<h2>Thank you for your order, {$name}!</h2>"
          . "<p>Your payment was received and your order is now confirmed.</p>"
          . "<p><strong>Order #{$orderId}</strong> (ref: {$ref})</p>"
          . "<p><strong>Total charged:</strong> {$currency} {$total}</p>"
          . $itemsHtml
          . "<p style=\"margin-top:16px;\">We'll be in touch if there are any updates. Thank you for shopping with morbi.shop!</p>"
          . "<p style=\"color:#666;font-size:12px;\">morbi.shop — Luxury Scents, Redefined.</p>";
    $text = "Thank you for your order, {$name}!\n\n"
          . "Your payment was received and your order is now confirmed.\n"
          . "Order #{$orderId} (ref: {$ref})\n"
          . "Total charged: {$currency} {$total}\n\n"
          . "Items:\n" . implode("\n", array_map(function ($it) {
              return "- {$it['name']}" . ($it['scent'] ? " ({$it['scent']})" : '') . " x {$it['qty']} @ {$it['price']}";
          }, $order['items']))
          . "\n\nWe'll be in touch if there are any updates. Thank you for shopping with morbi.shop!";

    $result = send_mail($customerEmail, $subject, $html, $text);
    if (!$result['ok']) {
        _notif_log_update_status('customer_order_paid', $orderId, 0, 'failed', $result['error']);
        error_log('[morbi] customer_order_paid notification failed for order ' . $orderId . ': ' . $result['error']);
    }
    return $result;
}

/**
 * Notify the customer that a refund was processed on their order. Called
 * from api/refunds.php after the refund insert + Paystack refund API call
 * succeed.
 *
 * @param int $orderId   the orders.id of the refunded order
 * @param int $refundId  the refunds.id of the new refund row
 * @return array ['ok' => bool, 'skipped' => bool, 'error' => string?]
 */
function notify_customer_refund_processed(int $orderId, int $refundId): array {
    $order = _notif_fetch_order($orderId);
    if (!$order) return ['ok' => false, 'error' => 'Order not found.'];

    $customerEmail = (string)($order['customer_email'] ?? '');
    if ($customerEmail === '' || !filter_var($customerEmail, FILTER_VALIDATE_EMAIL)) {
        _notif_log_insert('customer_refund_processed', null, $orderId, $refundId);
        _notif_log_update_status('customer_refund_processed', $orderId, $refundId, 'skipped',
            'No customer email on order (MoMo-only).');
        return ['ok' => false, 'skipped' => true, 'error' => 'No customer email on order.'];
    }

    // Idempotency check — uses (type, order_id, refund_id) so partial refunds
    // on the same order each get their own notification (refund_id differs).
    if (!_notif_log_insert('customer_refund_processed', $customerEmail, $orderId, $refundId)) {
        return ['ok' => true, 'skipped' => true, 'error' => 'Already sent (idempotency).'];
    }

    // Fetch the refund row for the amount.
    $refundStmt = db()->prepare('SELECT amount, currency, status FROM refunds WHERE id = ? LIMIT 1');
    $refundStmt->execute([$refundId]);
    $refund = $refundStmt->fetch();
    if (!$refund) {
        _notif_log_update_status('customer_refund_processed', $orderId, $refundId, 'failed', 'Refund row not found.');
        return ['ok' => false, 'error' => 'Refund row not found.'];
    }

    $refundAmount = number_format((float)$refund['amount'], 2, '.', '');
    $refundCurrency = htmlspecialchars((string)$refund['currency'], ENT_QUOTES, 'UTF-8');
    $refundStatus = htmlspecialchars((string)$refund['status'], ENT_QUOTES, 'UTF-8');
    $name = htmlspecialchars((string)$order['customer_name'], ENT_QUOTES, 'UTF-8');
    $ref = htmlspecialchars((string)$order['reference'], ENT_QUOTES, 'UTF-8');

    $subject = "Refund processed for your morbi.shop order #{$orderId}";
    $html = "<h2>Refund notification</h2>"
          . "<p>Hello {$name},</p>"
          . "<p>A refund of <strong>{$refundCurrency} {$refundAmount}</strong> has been initiated for your order <strong>#{$orderId}</strong> (ref: {$ref}).</p>"
          . "<p>Refund status: <em>{$refundStatus}</em></p>"
          . "<p>The refund will appear on your original payment method within 5-10 business days (Paystack's processing time).</p>"
          . "<p>If you have any questions, please reply to this email.</p>"
          . "<p style=\"color:#666;font-size:12px;\">morbi.shop — Luxury Scents, Redefined.</p>";
    $text = "Refund notification\n\n"
          . "Hello {$name},\n\n"
          . "A refund of {$refundCurrency} {$refundAmount} has been initiated for your order #{$orderId} (ref: {$ref}).\n"
          . "Refund status: {$refundStatus}\n\n"
          . "The refund will appear on your original payment method within 5-10 business days (Paystack's processing time).\n\n"
          . "If you have any questions, please reply to this email.\n\n"
          . "morbi.shop — Luxury Scents, Redefined.";

    $result = send_mail($customerEmail, $subject, $html, $text);
    if (!$result['ok']) {
        _notif_log_update_status('customer_refund_processed', $orderId, $refundId, 'failed', $result['error']);
        error_log('[morbi] customer_refund_processed notification failed for order ' . $orderId . ' refund ' . $refundId . ': ' . $result['error']);
    }
    return $result;
}

/**
 * ★ Phase 9 Batch 3 (Task 63): notify all customers who signed up for
 * restock alerts on a product/variant that it's back in stock. Called from
 * api/products.php PUT when the admin changes stock from 0 (or NULL) to N>0.
 *
 * Sends one email per signup (not a single BCC — the customers don't know
 * each other, so a BCC would leak signup-count info to anyone who inspects
 * the email headers). Uses send_mail()'s existing fire-and-forget pattern
 * (failures are logged but don't break the restock flow).
 *
 * After sending, marks each signup row's notified_at = CURRENT_TIMESTAMP.
 * The row is kept (not deleted) so the admin can see the audit trail +
 * signup counts in the dashboard's stock-alerts view.
 *
 * @param int      $productId  the products.id that was restocked
 * @param int|null $variantId  the product_variants.id (NULL = parent product, no variant context)
 * @return array ['ok' => bool, 'notified' => int, 'failed' => int]
 */
function notify_stock_back(int $productId, ?int $variantId = null): array {
    // Fetch unnotified signups for this product/variant.
    // ★ Migration 2026-09-26: was `variant_id <=> ?` — the `<=>` MySQL
    //   operator doesn't exist in SQLite. Replaced with `IS` which is
    //   SQLite's NULL-safe equality. Handles the variant_id IS NULL case
    //   (parent product without variants) correctly — `NULL IS NULL` = 1.
    $stmt = db()->prepare(
        'SELECT id, customer_email FROM stock_alerts
         WHERE product_id = ? AND variant_id IS ? AND notified_at IS NULL'
    );
    $stmt->execute([$productId, $variantId]);
    $signups = $stmt->fetchAll();

    if (empty($signups)) {
        return ['ok' => true, 'notified' => 0, 'failed' => 0];
    }

    // Fetch the product name for the email body. If the product was deleted
    // between signup + restock (impossible because the FK is ON DELETE
    // CASCADE — the signup row would be gone too), defensive null check.
    $prodStmt = db()->prepare('SELECT name FROM products WHERE id = ? LIMIT 1');
    $prodStmt->execute([$productId]);
    $product = $prodStmt->fetch();
    $productName = $product ? (string)$product['name'] : "Product #{$productId}";

    // Fetch the variant name (if applicable).
    $variantName = null;
    if ($variantId !== null) {
        $varStmt = db()->prepare('SELECT name FROM product_variants WHERE id = ? LIMIT 1');
        $varStmt->execute([$variantId]);
        $varRow = $varStmt->fetch();
        $variantName = $varRow ? (string)$varRow['name'] : null;
    }

    $notified = 0;
    $failed = 0;

    foreach ($signups as $signup) {
        $email = (string)$signup['customer_email'];
        $signupId = (int)$signup['id'];

        $displayName = htmlspecialchars($productName, ENT_QUOTES, 'UTF-8');
        $displayVariant = $variantName ? htmlspecialchars($variantName, ENT_QUOTES, 'UTF-8') : null;

        $subject = "Back in stock: {$productName}" . ($variantName ? " ({$variantName})" : '');
        $html = "<h2>Good news — it's back in stock!</h2>"
              . "<p>The item you signed up for is now available:</p>"
              . "<p><strong>{$displayName}" . ($displayVariant ? " ({$displayVariant})" : '') . "</strong></p>"
              . "<p>Head over to <a href=\"https://morbi.shop/morcenzs\">morbi.shop</a> to grab yours before it goes again.</p>"
              . "<p style=\"color:#666;font-size:12px;\">You received this email because you signed up for a restock alert on morbi.shop. "
              . "Reply to this email if you didn't sign up — we'll remove your address from our list.</p>";
        $text = "Good news — it's back in stock!\n\n"
              . "The item you signed up for is now available:\n"
              . "{$productName}" . ($variantName ? " ({$variantName})" : '') . "\n\n"
              . "Head over to https://morbi.shop/morcenzs to grab yours before it goes again.\n\n"
              . "You received this email because you signed up for a restock alert on morbi.shop. "
              . "Reply to this email if you didn't sign up — we'll remove your address from our list.";

        $result = send_mail($email, $subject, $html, $text);
        if ($result['ok']) {
            // Mark as notified (audit trail — the row stays).
            $upd = db()->prepare('UPDATE stock_alerts SET notified_at = CURRENT_TIMESTAMP WHERE id = ?');
            $upd->execute([$signupId]);
            $notified++;
        } else {
            // Log the failure but continue to the next signup — one bad email
            // shouldn't block the others.
            error_log('[morbi] stock_alert notify failed for signup ' . $signupId .
                ' (product ' . $productId . ', variant ' . ($variantId ?? 'null') . '): ' . $result['error']);
            $failed++;
        }
    }

    return ['ok' => $failed === 0, 'notified' => $notified, 'failed' => $failed];
}
