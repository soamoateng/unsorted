<?php
/**
 * install.php — morbi.shop SQLite schema + seed installer.
 *
 * ★ RENAMED from _install.php (2026-09-26): the underscore prefix blocked
 *   web access via the api/.htaccess `^_` FilesMatch rule. The user wants
 *   to trigger the install by visiting morbi-shop/api/install.php in the
 *   browser, then manually delete install.php after. This file is now
 *   web-accessible (no underscore) — that's intentional + by design.
 *
 * DUAL-MODE operation:
 *   1. Browser visit (direct access): outputs a user-friendly HTML page
 *      showing the install result (success/error + what was seeded +
 *      warning to delete install.php).
 *   2. Safety-net require (from _bootstrap.php's db() when morbi.sqlite
 *      is missing): outputs JSON (so the API request that triggered the
 *      safety-net gets a clean JSON response instead of HTML-in-JSON).
 *
 *   Detection: if the script was required from another PHP file (via
 *   require/include), $_SERVER['SCRIPT_NAME'] points to the PARENT script
 *   (e.g. /api/products.php), not install.php. If visited directly,
 *   SCRIPT_NAME is /api/install.php.
 *
 * SECURITY:
 *   - This file is web-accessible (no underscore prefix). Anyone can visit it.
 *   - CREATE TABLE IF NOT EXISTS is idempotent — visiting on an already-
 *     installed site is a no-op (safe).
 *   - Seeding only runs on empty tables — existing data is never overwritten.
 *   - DELETE THIS FILE after install for defense in depth.
 *
 * WHAT THIS FILE DOES:
 *   1. Creates storage/morbi.sqlite (idempotent — skipped if file exists)
 *   2. Creates ALL tables with CREATE TABLE IF NOT EXISTS
 *   3. Seeds the empty tables with the default admin user, 4 categories,
 *      12 perfume products, the landing sections, currencies, design tokens
 *   4. Seeds the admin account ONLY if MORBI_ADMIN_PASS is set to a real
 *      password (NOT the default placeholder 'ChangeMe-Now!2026')
 */

// ★ DUAL-MODE: detect whether this file was visited directly (browser) or
//   required from _bootstrap.php (safety-net). The safety-net case needs
//   JSON output (so the API request gets a clean response); the browser
//   case needs HTML (so the user sees a readable page).
$__directAccess = (basename($_SERVER['SCRIPT_NAME'] ?? '') === 'install.php');

// For the safety-net case, we need _bootstrap.php's config constants
// (DB_PATH, ADMIN_USER, etc.) + the json_ok/json_err helpers.
// For the browser case, we load _config.php directly for the constants
// + define our own output helpers.
if (!$__directAccess) {
    // Safety-net: _bootstrap.php already loaded us (or is about to).
    // It provides db(), json_ok(), json_err(), and all constants.
    // We just need _config.php for DB_PATH etc.
    require_once __DIR__ . '/_config.php';
    // Define JSON helpers if not already defined (they're in _bootstrap.php
    // which may or may not have been loaded depending on the call path).
    if (!function_exists('json_ok')) {
        function json_ok($data, int $status = 200): void {
            http_response_code($status);
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode(['ok' => true, 'data' => $data]);
            exit;
        }
    }
    if (!function_exists('json_err')) {
        function json_err(string $message, int $status = 400): void {
            http_response_code($status);
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode(['ok' => false, 'error' => $message]);
            exit;
        }
    }
} else {
    // Browser visit: load _config.php for constants only (no session_start).
    require_once __DIR__ . '/_env.php';
    require_once __DIR__ . '/_config.php';
    // Set PHP timezone to UTC (matches _bootstrap.php's fix for SQLite TZ consistency).
    date_default_timezone_set('UTC');
    // Output hygiene: suppress notices from corrupting the HTML page.
    error_reporting(E_ALL);
    ini_set('display_errors', '0');
    ini_set('log_errors', '1');
    header_remove('X-Powered-By');
}

// Ensure the storage/ directory exists.
$storageDir = dirname(DB_PATH);
if (!is_dir($storageDir)) { @mkdir($storageDir, 0755, true); }
if (!is_dir($storageDir) || !is_writable($storageDir)) {
    $msg = 'storage/ directory is missing or not writable. Fix folder permissions and retry. Expected at: ' . $storageDir;
    if ($__directAccess) {
        __install_html_error($msg);
    } else {
        json_err($msg, 500);
    }
}

// Open the SQLite file directly. SQLite creates the file if it doesn't exist.
try {
    $pdo = new PDO('sqlite:' . DB_PATH, null, null, [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ]);
    $pdo->exec('PRAGMA journal_mode = WAL');
    $pdo->exec('PRAGMA foreign_keys = ON');
    $pdo->exec('PRAGMA synchronous = NORMAL');
    // ★ SQLITE FIX (2026-09-26) m3: add busy_timeout (was missing — if a
    //   Paystack webhook fired while install.php was running, install would
    //   get SQLITE_BUSY immediately with the default 0ms timeout).
    $pdo->exec('PRAGMA busy_timeout = 5000');
} catch (PDOException $e) {
    $msg = 'Cannot open SQLite database: ' . $e->getMessage() . ' (path: ' . DB_PATH . ')';
    if ($__directAccess) {
        __install_html_error($msg);
    } else {
        json_err($msg, 500);
    }
}

/* ════════════════════════════════════════════════════════════════════════
 * SCHEMA — SQLite syntax. Idempotent (CREATE TABLE IF NOT EXISTS).
 * ════════════════════════════════════════════════════════════════════════ */

/* Table: admin_users — admins who can log in to /dashboard. */
$pdo->exec("CREATE TABLE IF NOT EXISTS admin_users (
  id                INTEGER PRIMARY KEY AUTOINCREMENT,
  username          TEXT NOT NULL,
  password_hash     TEXT NOT NULL,
  email             TEXT,
  role              TEXT NOT NULL DEFAULT 'super_admin',
  password_changed_at TEXT,
  created_at        TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at        TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE (username),
  UNIQUE (email)
)");
$pdo->exec("CREATE INDEX IF NOT EXISTS idx_admin_role ON admin_users(role)");

/* Table: categories — product groupings (e.g. 'Perfumes'). */
$pdo->exec("CREATE TABLE IF NOT EXISTS categories (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  name        TEXT NOT NULL,
  slug        TEXT NOT NULL,
  description TEXT,
  sort_order  INTEGER NOT NULL DEFAULT 0,
  created_at  TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at  TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE (slug)
)");
$pdo->exec("CREATE INDEX IF NOT EXISTS idx_categories_slug ON categories(slug)");
$pdo->exec("CREATE INDEX IF NOT EXISTS idx_categories_sort ON categories(sort_order)");

/* Table: products — the storefront items. */
$pdo->exec("CREATE TABLE IF NOT EXISTS products (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  name            TEXT NOT NULL,
  scent           TEXT,
  scent_category  TEXT,
  description     TEXT,
  price           REAL NOT NULL,
  category_id     INTEGER,
  image_path      TEXT,
  available       INTEGER NOT NULL DEFAULT 1,
  stock           INTEGER,
  created_at      TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at      TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL
)");
$pdo->exec("CREATE INDEX IF NOT EXISTS idx_products_category ON products(category_id)");
$pdo->exec("CREATE INDEX IF NOT EXISTS idx_products_available ON products(available)");
$pdo->exec("CREATE INDEX IF NOT EXISTS idx_products_stock ON products(stock)");
$pdo->exec("CREATE INDEX IF NOT EXISTS idx_products_scent_category ON products(scent_category)");

/* Table: product_variants — size/colour options for a product.
 * ★ Migration 2026-09-26: added price / available / sort_order columns
 *   (were missing from iteration 48's schema — every product LIST + variant
 *   checkout was throwing "no such column: price"). */
$pdo->exec("CREATE TABLE IF NOT EXISTS product_variants (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  product_id      INTEGER NOT NULL,
  name            TEXT NOT NULL,
  sku             TEXT,
  price_delta     REAL NOT NULL DEFAULT 0,
  price           REAL NOT NULL DEFAULT 0,
  stock           INTEGER,
  available       INTEGER NOT NULL DEFAULT 1,
  sort_order      INTEGER NOT NULL DEFAULT 0,
  created_at      TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at      TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
)");
$pdo->exec("CREATE INDEX IF NOT EXISTS idx_variants_product ON product_variants(product_id)");

/* Table: orders — customer orders.
 * ★ Migration 2026-09-26: added paystack_channel + paystack_fees columns
 *   (were missing — webhook UPDATE was throwing "no such column"). */
$pdo->exec("CREATE TABLE IF NOT EXISTS orders (
  id                INTEGER PRIMARY KEY AUTOINCREMENT,
  reference         TEXT NOT NULL,
  customer_name     TEXT NOT NULL,
  customer_email    TEXT,
  customer_phone    TEXT,
  delivery_address  TEXT,
  city              TEXT,
  region            TEXT,
  items_json        TEXT NOT NULL,
  total_amount      REAL NOT NULL,
  currency          TEXT NOT NULL DEFAULT 'GHS',
  paystack_ref      TEXT,
  paystack_status   TEXT NOT NULL DEFAULT 'pending',
  paystack_paid_at  TEXT,
  paystack_response TEXT,
  paystack_channel  TEXT,
  paystack_fees     REAL,
  discount_code     TEXT,
  discount_amount   REAL NOT NULL DEFAULT 0,
  refunded_amount   REAL NOT NULL DEFAULT 0,
  notes             TEXT,
  created_at        TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at        TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE (reference)
)");
$pdo->exec("CREATE INDEX IF NOT EXISTS idx_orders_created ON orders(created_at)");
$pdo->exec("CREATE INDEX IF NOT EXISTS idx_orders_paystack_ref ON orders(paystack_ref)");
$pdo->exec("CREATE INDEX IF NOT EXISTS idx_orders_paystack_status ON orders(paystack_status)");
$pdo->exec("CREATE INDEX IF NOT EXISTS idx_orders_discount_code ON orders(discount_code)");

/* Table: order_items — denormalized line items (snapshot at order time). */
$pdo->exec("CREATE TABLE IF NOT EXISTS order_items (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  order_id        INTEGER NOT NULL,
  product_id      INTEGER,
  variant_id      INTEGER,
  product_name    TEXT NOT NULL,
  variant_name    TEXT,
  unit_price      REAL NOT NULL,
  quantity        INTEGER NOT NULL,
  image_path      TEXT,
  created_at      TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
  FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE SET NULL,
  FOREIGN KEY (variant_id) REFERENCES product_variants(id) ON DELETE SET NULL
)");
$pdo->exec("CREATE INDEX IF NOT EXISTS idx_order_items_order ON order_items(order_id)");
$pdo->exec("CREATE INDEX IF NOT EXISTS idx_order_items_product ON order_items(product_id)");

/* Table: rate_limit_log — Phase 3 rate limiting (DB-backed counter). */
$pdo->exec("CREATE TABLE IF NOT EXISTS rate_limit_log (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  bucket      TEXT NOT NULL,
  created_at  TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
)");
$pdo->exec("CREATE INDEX IF NOT EXISTS idx_rate_limit_bucket ON rate_limit_log(bucket, created_at)");

/* Table: password_resets — token-based admin password recovery. */
$pdo->exec("CREATE TABLE IF NOT EXISTS password_resets (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  admin_user_id   INTEGER NOT NULL,
  token_hash      TEXT NOT NULL,
  expires_at      TEXT NOT NULL,
  ip_address      TEXT,
  used_at         TEXT,
  created_at      TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE (token_hash),
  FOREIGN KEY (admin_user_id) REFERENCES admin_users(id) ON DELETE CASCADE
)");
$pdo->exec("CREATE INDEX IF NOT EXISTS idx_password_resets_admin ON password_resets(admin_user_id)");
$pdo->exec("CREATE INDEX IF NOT EXISTS idx_password_resets_token ON password_resets(token_hash)");

/* Table: landing_content — legacy 8-key key-value store. */
$pdo->exec("CREATE TABLE IF NOT EXISTS landing_content (
  section_key TEXT NOT NULL PRIMARY KEY,
  content     TEXT NOT NULL,
  updated_at  TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
)");

/* Table: landing_sections — ordered section blocks. */
$pdo->exec("CREATE TABLE IF NOT EXISTS landing_sections (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  section_type  TEXT NOT NULL,
  sort_order    INTEGER NOT NULL DEFAULT 0,
  content       TEXT NOT NULL DEFAULT '{}',
  active        INTEGER NOT NULL DEFAULT 1,
  created_at    TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at    TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at    TEXT
)");
$pdo->exec("CREATE INDEX IF NOT EXISTS idx_sections_sort ON landing_sections(sort_order, active)");
$pdo->exec("CREATE INDEX IF NOT EXISTS idx_sections_active ON landing_sections(active)");

/* Table: site_settings — key-value store for currency, design tokens, etc. */
$pdo->exec("CREATE TABLE IF NOT EXISTS site_settings (
  setting_key    TEXT NOT NULL PRIMARY KEY,
  setting_value  TEXT
)");

/* Table: discount_codes — Phase 5 discount codes. */
$pdo->exec("CREATE TABLE IF NOT EXISTS discount_codes (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  code          TEXT NOT NULL,
  description   TEXT,
  discount_type TEXT NOT NULL DEFAULT 'percentage',
  discount_value REAL NOT NULL DEFAULT 0,
  min_order_amount REAL NOT NULL DEFAULT 0,
  max_uses       INTEGER,
  used_count     INTEGER NOT NULL DEFAULT 0,
  active         INTEGER NOT NULL DEFAULT 1,
  expires_at     TEXT,
  created_at     TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at     TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE (code)
)");
$pdo->exec("CREATE INDEX IF NOT EXISTS idx_discounts_active ON discount_codes(active, expires_at)");

/* Table: currencies — Phase 8 Batch 3 multi-currency. */
$pdo->exec("CREATE TABLE IF NOT EXISTS currencies (
  id                  INTEGER PRIMARY KEY AUTOINCREMENT,
  code                TEXT NOT NULL,
  name                TEXT NOT NULL,
  symbol              TEXT NOT NULL,
  exchange_rate       REAL NOT NULL DEFAULT 1.0,
  paystack_supported  INTEGER NOT NULL DEFAULT 0,
  active              INTEGER NOT NULL DEFAULT 1,
  is_base             INTEGER NOT NULL DEFAULT 0,
  created_at          TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at          TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE (code)
)");
$pdo->exec("CREATE INDEX IF NOT EXISTS idx_currencies_active ON currencies(active)");

/* Table: refunds — Phase 8 Batch 1 Paystack refunds.
 * ★ Migration 2026-09-26: added merchant_note / customer_note / settled_at /
 *   initiated_at columns (were missing from iteration 48).
 * ★ SQLITE FIX (2026-09-26) M6: paystack_refund_id is now NOT NULL (was
 *   nullable — the webhook's WHERE paystack_refund_id = ? lookup never
 *   matched NULL rows). Refunds without a Paystack ID are now rejected at
 *   INSERT time in refunds.php with a clear error message. */
$pdo->exec("CREATE TABLE IF NOT EXISTS refunds (
  id                  INTEGER PRIMARY KEY AUTOINCREMENT,
  order_id            INTEGER NOT NULL,
  paystack_refund_id  TEXT NOT NULL DEFAULT '',
  amount              REAL NOT NULL,
  currency            TEXT NOT NULL DEFAULT 'GHS',
  reason              TEXT,
  merchant_note       TEXT,
  customer_note       TEXT,
  status              TEXT NOT NULL DEFAULT 'pending',
  initiated_by        INTEGER NOT NULL,
  initiated_at        TEXT,
  settled_at          TEXT,
  created_at          TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at          TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
  FOREIGN KEY (initiated_by) REFERENCES admin_users(id) ON DELETE CASCADE
)");
$pdo->exec("CREATE INDEX IF NOT EXISTS idx_refunds_order ON refunds(order_id)");
$pdo->exec("CREATE INDEX IF NOT EXISTS idx_refunds_status ON refunds(status)");

/* Table: notification_log — Phase 9 Batch 2 email idempotency.
 * ★ SQLITE FIX (2026-09-26) M4: order_id is now NOT NULL DEFAULT 0 (was
 *   nullable — SQLite treats NULL as distinct in UNIQUE constraints, so
 *   the (type, order_id, refund_id) dedup failed when order_id was NULL).
 *   The _notif_log_insert function COALESCEs null to 0 defensively. */
$pdo->exec("CREATE TABLE IF NOT EXISTS notification_log (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  type          TEXT NOT NULL,
  recipient     TEXT,
  order_id      INTEGER NOT NULL DEFAULT 0,
  refund_id     INTEGER NOT NULL DEFAULT 0,
  status        TEXT NOT NULL DEFAULT 'sent',
  error_message TEXT,
  sent_at       TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE (type, order_id, refund_id)
)");
$pdo->exec("CREATE INDEX IF NOT EXISTS idx_notif_type ON notification_log(type)");
$pdo->exec("CREATE INDEX IF NOT EXISTS idx_notif_order ON notification_log(order_id)");

/* Table: stock_alerts — Phase 9 Batch 3 restock notifications. */
$pdo->exec("CREATE TABLE IF NOT EXISTS stock_alerts (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  product_id      INTEGER NOT NULL,
  variant_id      INTEGER,
  customer_email  TEXT NOT NULL,
  created_at      TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  notified_at     TEXT,
  UNIQUE (product_id, variant_id, customer_email),
  FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
  FOREIGN KEY (variant_id) REFERENCES product_variants(id) ON DELETE CASCADE
)");
$pdo->exec("CREATE INDEX IF NOT EXISTS idx_alerts_product ON stock_alerts(product_id)");
$pdo->exec("CREATE INDEX IF NOT EXISTS idx_alerts_notified ON stock_alerts(notified_at)");
// ★ SQLITE FIX (2026-09-26) M5: partial unique index for variant_id IS NULL.
//   SQLite treats NULL as distinct in UNIQUE constraints, so duplicate
//   (product_id, NULL, email) rows could be inserted. This partial index
//   catches the NULL case the table-level UNIQUE misses.
$pdo->exec("CREATE UNIQUE INDEX IF NOT EXISTS uq_stock_alerts_no_variant
  ON stock_alerts(product_id, customer_email)
  WHERE variant_id IS NULL");

/* Table: analytics_access_log — audit log for analytics endpoint access.
 * ★ SQLITE FIX (2026-09-26) n5: was created inline in analytics.php on
 *   every request (3 wasted SQL round-trips). Now created here alongside
 *   the other tables. analytics.php keeps a suppressed inline CREATE as
 *   a safety net for upgrades that didn't re-run install.php. */
$pdo->exec("CREATE TABLE IF NOT EXISTS analytics_access_log (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  admin_id   INTEGER NOT NULL,
  ip_address TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
)");
$pdo->exec("CREATE INDEX IF NOT EXISTS idx_analytics_access_admin ON analytics_access_log(admin_id)");
$pdo->exec("CREATE INDEX IF NOT EXISTS idx_analytics_access_created ON analytics_access_log(created_at)");

/* FTS5 virtual table for product search. */
try {
    $pdo->exec("CREATE VIRTUAL TABLE IF NOT EXISTS products_fts USING fts5(
    name, scent, description, content='products', content_rowid='id'
  )");
    $pdo->exec("CREATE TRIGGER IF NOT EXISTS products_ai AFTER INSERT ON products BEGIN
    INSERT INTO products_fts(rowid, name, scent, description)
    VALUES (new.id, new.name, new.scent, new.description);
  END");
    $pdo->exec("CREATE TRIGGER IF NOT EXISTS products_ad AFTER DELETE ON products BEGIN
    INSERT INTO products_fts(products_fts, rowid, name, scent, description)
    VALUES ('delete', old.id, old.name, old.scent, old.description);
  END");
    $pdo->exec("CREATE TRIGGER IF NOT EXISTS products_au AFTER UPDATE ON products BEGIN
    INSERT INTO products_fts(products_fts, rowid, name, scent, description)
    VALUES ('delete', old.id, old.name, old.scent, old.description);
    INSERT INTO products_fts(rowid, name, scent, description)
    VALUES (new.id, new.name, new.scent, new.description);
  END");
} catch (PDOException $e) {
    error_log('[morbi] FTS5 setup failed: ' . $e->getMessage() . ' — search.php will fall back to LIKE.');
}

/* ════════════════════════════════════════════════════════════════════════
 * SEEDING — idempotent. Only seeds tables that are empty (COUNT(*) = 0).
 * ════════════════════════════════════════════════════════════════════════ */

$seeded = [];

/* 1) Admin user. */
if ((int)$pdo->query('SELECT COUNT(*) FROM admin_users')->fetchColumn() === 0) {
    $adminPass = getenv('MORBI_ADMIN_PASS') ?: ADMIN_PASS;
    if ($adminPass === '' || $adminPass === 'ChangeMe-Now!2026') {
        $adminPass = 'ChangeMe-Now!2026';
        error_log('[morbi] SEC-01: admin password not set via MORBI_ADMIN_PASS. '
            . 'Seeding with the default placeholder. CHANGE IMMEDIATELY on first login.');
    }
    $stmt = $pdo->prepare(
        'INSERT INTO admin_users (username, password_hash, email, role) VALUES (?, ?, ?, ?)'
    );
    $hash = password_hash($adminPass, PASSWORD_DEFAULT);
    $email = ADMIN_EMAIL !== '' ? ADMIN_EMAIL : null;
    $stmt->execute([ADMIN_USER, $hash, $email, 'super_admin']);
    $seeded[] = 'admin_user';
}

/* 2) Categories — 4 default categories. */
if ((int)$pdo->query('SELECT COUNT(*) FROM categories')->fetchColumn() === 0) {
    $stmt = $pdo->prepare(
        'INSERT INTO categories (name, slug, description, sort_order) VALUES (?, ?, ?, ?)'
    );
    $cats = [
        ['Perfumes', 'perfumes', 'Luxury fragrances', 1],
        ['Bath & Body', 'bath-body', 'Bath and body products', 2],
        ['Home Scents', 'home-scents', 'Candles and diffusers', 3],
        ['Accessories', 'accessories', 'Perfume accessories', 4],
    ];
    foreach ($cats as $c) {
        $stmt->execute($c);
    }
    $seeded[] = 'categories';
}

/* 3) Products — 12 perfume products with REAL image_path values. */
if ((int)$pdo->query('SELECT COUNT(*) FROM products')->fetchColumn() === 0) {
    $catIds = [];
    foreach ($pdo->query('SELECT id, name FROM categories')->fetchAll() as $row) {
        $catIds[$row['name']] = (int)$row['id'];
    }
    $stmt = $pdo->prepare(
        'INSERT INTO products (name, scent, scent_category, description, price, category_id, image_path, available, stock) VALUES (?, ?, ?, ?, ?, ?, ?, 1, ?)'
    );
    $products = [
        // ── MALE (14 products — one per image in images/male/) ──
        ['Oud Royale',       'Oud, Amber, Sandalwood',         'male',   'A bold oriental blend of oud, amber, and sandalwood for the discerning gentleman.', 180, 'Perfumes', 'images/male/male-01.jpeg',    10],
        ['Noir Élégance',    'Black Pepper, Bergamot, Vetiver', 'male',   'A sophisticated evening fragrance with spicy black pepper and a clean vetiver base.', 195, 'Perfumes', 'images/male/male-02.jpeg',     8],
        ['Sapphire Smoke',   'Smoke, Leather, Bergamot',       'male',   'Smoky leather with a bright bergamot opening — mysterious and refined.',              170, 'Perfumes', 'images/male/male-03.jpeg',    11],
        ['Golden Hour',      'Amber, Sandalwood, Citrus',       'male',   'Warm amber and sandalwood kissed with citrus — a golden sunset in a bottle.',         160, 'Perfumes', 'images/male/male-04.jpeg',     9],
        ['Midnight Leather', 'Leather, Tobacco, Cedar',        'male',   'Smoky leather and tobacco with a cedar drydown — confident and commanding.',         200, 'Perfumes', 'images/male/male-05.jpeg',     5],
        ['Amber Noir',       'Amber, Vanilla, Musk',           'male',   'Sweet amber and vanilla wrapped in soft musk — a sensual evening scent.',              155, 'Perfumes', 'images/male/male-06.jpeg',    12],
        ['Steel & Sage',     'Sage, Metal, Cedarwood',         'male',   'Cool sage and metallic notes over cedarwood — modern and sharp.',                      175, 'Perfumes', 'images/male/male-07.jpeg',     6],
        ['Velvet Night',     'Bergamot, Black Cardamom, Oud',  'male',   'Spicy black cardamom meets deep oud — an intoxicating night scent.',                  210, 'Perfumes', 'images/male/male-08.jpeg',     4],
        ['Sahara Spice',     'Saffron, Cardamom, Oud',         'male',   'Warm saffron and cardamom over an oud base — inspired by cool desert nights.',        165, 'Perfumes', 'images/male/male-09.jpeg',     8],
        ['Imperial Oud',     'Oud, Rose, Saffron',             'male',   'Regal oud with rose and saffron — a statement of power and elegance.',                220, 'Perfumes', 'images/male/male-10.jpeg',     3],
        ['Leather Icon',     'Leather, Patchouli, Smoke',      'male',   'Iconic leather and patchouli with smoky undertones for a timeless finish.',             190, 'Perfumes', 'images/male/male-11.jpeg',     7],
        ['Bronze Emperor',   'Citrus, Amber, Woods',           'male',   'Bright citrus over warm amber and woods — confident and commanding.',                  185, 'Perfumes', 'images/male/male-12.jpeg',    10],
        ['Cedar Storm',      'Cedar, Vetiver, Bergamot',       'male',   'Fresh bergamot opening into a woody cedar and vetiver heart.',                        145, 'Perfumes', 'images/male/male-13.png',      0],
        ['Phantom Noir',     'Smoke, Vanilla, Dark Musk',      'male',   'A ghost of smoke with dark vanilla and musk — seductive and mysterious.',              205, 'Perfumes', 'images/male/male-14.png',      6],

        // ── FEMALE (18 products — one per image in images/female/) ──
        ['Jasmine Dream',    'Jasmine, Neroli, White Amber',   'female', 'Soft jasmine and neroli on a white amber base — luminous and airy.',                   130, 'Perfumes', 'images/female/female-01.jpeg', 15],
        ['Rose Petal',       'Bulgarian Rose, Peony, Musk',    'female', 'Fresh Bulgarian rose with peony and musk — a romantic bouquet.',                       140, 'Perfumes', 'images/female/female-02.jpeg', 12],
        ['Velvet Orchid',    'Orchid, Jasmine, Vanilla',       'female', 'A luxurious floral of orchid and jasmine with creamy vanilla undertones.',             150, 'Perfumes', 'images/female/female-03.jpeg', 10],
        ['Blush Garden',     'Peony, Rose, Lychee',            'female', 'A fresh garden of peony, rose, and lychee — youthful and bright.',                    125, 'Perfumes', 'images/female/female-04.jpeg', 14],
        ['Sunset Bloom',      'Mandarin, Ylang-Ylang, Sandalwood', 'female', 'Warm mandarin and ylang-ylang on sandalwood — a tropical sunset.',                135, 'Perfumes', 'images/female/female-05.jpeg',  9],
        ['Vanilla Noir',     'Vanilla, Tonka, Dark Chocolate', 'female', 'A gourmand vanilla with tonka and dark chocolate — rich and indulgent.',               145, 'Perfumes', 'images/female/female-06.jpeg',  0],
        ['Floral Muse',      'Peony, Lily, Cashmere Musk',     'female', 'Tender peony and lily on a cashmere musk base — soft and elegant.',                    125, 'Perfumes', 'images/female/female-07.jpeg',  9],
        ['Gardenia Whisper', 'Gardenia, Tuberose, White Musk', 'female', 'Creamy gardenia and tuberose with white musk — a soft floral embrace.',               155, 'Perfumes', 'images/female/female-08.jpeg',  7],
        ['Pink Aurora',      'Pink Pepper, Rose, Patchouli',   'female', 'Spicy pink pepper with rose and patchouli — bold and modern.',                       160, 'Perfumes', 'images/female/female-09.jpeg',  8],
        ['Rose Imperial',    'Damask Rose, Patchouli, Musk',    'female', 'Regal damask rose with earthy patchouli depth and a musky drydown.',                   175, 'Perfumes', 'images/female/female-10.jpeg',  6],
        ['Lily Cascade',     'Lily, Freesia, Musk',            'female', 'Cascading lily and freesia on a musk base — fresh and delicate.',                     120, 'Perfumes', 'images/female/female-11.jpeg', 18],
        ['Cherry Blossom',   'Cherry Blossom, Jasmine, Musk',  'female', 'Delicate cherry blossom with jasmine and musk — a springtime dream.',                130, 'Perfumes', 'images/female/female-12.jpeg', 13],
        ['Magnolia Royale',  'Magnolia, Peony, Amber',         'female', 'Lush magnolia with peony and amber — opulent and grand.',                              165, 'Perfumes', 'images/female/female-13.jpeg',  5],
        ['Moonlight Jasmine', 'Jasmine, Sambac, Vanilla',      'female', 'Night-blooming jasmine sambac with vanilla — intoxicating and warm.',                 150, 'Perfumes', 'images/female/female-14.jpeg', 11],
        ['Citrus Bloom',     'Bergamot, Lemon, Neroli',        'female', 'Bright bergamot and lemon with neroli — a crisp, sunlit opening.',                    110, 'Perfumes', 'images/female/female-15.jpeg', 20],
        ['Crystal Peony',    'Peony, Bergamot, Cedar',         'female', 'Sparkling peony with bergamot and cedar — clean and radiant.',                        140, 'Perfumes', 'images/female/female-16.png',   8],
        ['Satin Rose',       'Rose, Damask, Pink Pepper',      'female', 'Silky damask rose with pink pepper — smooth and sophisticated.',                       170, 'Perfumes', 'images/female/female-17.png',   4],
        ['Empress Bloom',    'Tuberose, Orange Blossom, Musk',  'female', 'Regal tuberose and orange blossom with musk — fit for an empress.',                   195, 'Perfumes', 'images/female/female-18.png',   3],
    ];
    foreach ($products as $p) {
        $stmt->execute([$p[0], $p[1], $p[2], $p[3], $p[4], $catIds[$p[5]], $p[6], $p[7]]);
    }
    $seeded[] = 'products';
}

/* 4) Landing content — the 8 legacy key-value rows. */
if ((int)$pdo->query('SELECT COUNT(*) FROM landing_content')->fetchColumn() === 0) {
    $stmt = $pdo->prepare('INSERT INTO landing_content (section_key, content) VALUES (?, ?)');
    $landing = [
        'hero_title'       => 'A scent full of desire',
        'hero_subtitle'    => 'Discover fragrances made to leave an impression. Find the fragrance that speaks for you. Shop long-lasting scents ranging from crisp florals to rich woody undertones, perfectly suited for any occasion. Delivered conveniently to Accra, Kumasi, and nationwide.',
        'about_heading'    => 'Founder & Curator-in-Chief',
        'about_text_1'     => 'Scent is the most powerful form of self-expression. At Morcenzs, we bring world-class, authentic luxury fragrances directly to perfume lovers across Ghana.',
        'about_text_2'     => 'Every bottle in our collection is carefully sourced for its longevity and craftsmanship, ensuring you always leave a memorable mark—wherever you go, whatever the occasion.',
        'featured_heading' => 'Featured Scents',
        'featured_sub'     => 'A selection from the Morcenzs collection.',
        'footer_text'      => 'Morcenzs by Morbi. All rights reserved.',
    ];
    foreach ($landing as $k => $v) {
        $stmt->execute([$k, $v]);
    }
    $seeded[] = 'landing_content';
}

/* 5) Landing sections — ordered section blocks. */
if ((int)$pdo->query('SELECT COUNT(*) FROM landing_sections')->fetchColumn() === 0) {
    $stmt = $pdo->prepare(
        'INSERT INTO landing_sections (section_type, sort_order, content, active) VALUES (?, ?, ?, 1)'
    );
    $stmt->execute(['hero', 1, json_encode([
        'heading'  => 'A scent full of desire',
        'subtitle' => 'Discover fragrances made to leave an impression. Find the fragrance that speaks for you. Shop long-lasting scents ranging from crisp florals to rich woody undertones, perfectly suited for any occasion.',
    ], JSON_UNESCAPED_UNICODE)]);
    $stmt->execute(['about', 2, json_encode([
        'heading'    => 'Founder & Curator-in-Chief',
        'paragraph_1' => 'Scent is the most powerful form of self-expression. At Morcenzs, we bring world-class, authentic luxury fragrances directly to perfume lovers across Ghana.',
        'paragraph_2' => 'Every bottle in our collection is carefully sourced for its longevity and craftsmanship, ensuring you always leave a memorable mark—wherever you go, whatever the occasion.',
    ], JSON_UNESCAPED_UNICODE)]);
    $stmt->execute(['featured', 3, json_encode([
        'heading'  => 'Featured Scents',
        'subtitle' => 'A selection from the Morcenzs collection.',
    ], JSON_UNESCAPED_UNICODE)]);
    $stmt->execute(['footer', 4, json_encode([
        'text' => 'Morcenzs by Morbi. All rights reserved.',
    ], JSON_UNESCAPED_UNICODE)]);
    $seeded[] = 'landing_sections';
}

/* 6) Site settings — currency + design tokens + notification + whatsapp. */
if ((int)$pdo->query('SELECT COUNT(*) FROM site_settings')->fetchColumn() === 0) {
    $stmt = $pdo->prepare('INSERT INTO site_settings (setting_key, setting_value) VALUES (?, ?)');
    $stmt->execute(['currency', 'GHS']);
    $stmt->execute(['notify_admin_email', '']);
    $stmt->execute(['notify_from_name', 'morbi.shop']);
    $stmt->execute(['notify_from_email', defined('SMTP_FROM') ? SMTP_FROM : '']);
    $stmt->execute(['whatsapp_number', '233000000000']);
    $tokens = [
        'bg_deep'       => '#000000',
        'bg_mid'        => '#111111',
        'bg_card'       => '#1a1a1a',
        'accent'        => '#D4AF37',
        'accent_strong' => '#C8A951',
        'accent_hover'  => '#E5C654',
        'danger'        => '#dc2626',
        'muted'         => '#b8b8b8',
        'ok'            => '#2D8B4E',
        'border'        => '#333333',
        'green'         => '#2D8B4E',
    ];
    foreach ($tokens as $name => $hex) {
        $stmt->execute(['token_' . $name, $hex]);
    }
    $seeded[] = 'site_settings';
}

/* 7) Currencies — GHS base + USD. */
if ((int)$pdo->query('SELECT COUNT(*) FROM currencies')->fetchColumn() === 0) {
    $stmt = $pdo->prepare(
        'INSERT INTO currencies (code, name, symbol, exchange_rate, paystack_supported, active, is_base) VALUES (?, ?, ?, ?, ?, ?, ?)'
    );
    $stmt->execute(['GHS', 'Ghanaian Cedi', '₵', 1.000000, 1, 1, 1]);
    $stmt->execute(['USD', 'US Dollar',     '$', 0.083300, 1, 1, 0]);
    $seeded[] = 'currencies';
}

/* ── Output ───────────────────────────────────────────────────────────── */

if ($__directAccess) {
    // Browser visit — output a user-friendly HTML page.
    __install_html_success($seeded);
} else {
    // Safety-net (required from _bootstrap.php) — output JSON.
    json_ok([
        'seeded'   => $seeded,
        'db_path'  => DB_PATH,
        'note'     => 'SQLite DB rebuilt from scratch. The site is ready. '
                    . 'DELETE api/install.php on the server for defense in depth.',
    ]);
}


/* ════════════════════════════════════════════════════════════════════════
 * HTML output helpers (only used for direct browser access).
 * ════════════════════════════════════════════════════════════════════════ */
function __install_html_success(array $seeded): void {
    $seededList = empty($seeded)
        ? '<li style="color:#666;">All tables already had data — no seeding was needed. The existing data was preserved.</li>'
        : implode('', array_map(function ($s) {
            return '<li>' . htmlspecialchars($s, ENT_QUOTES, 'UTF-8') . '</li>';
        }, $seeded));
    $adminUser = htmlspecialchars(ADMIN_USER, ENT_QUOTES, 'UTF-8');
    header('Content-Type: text/html; charset=utf-8');
    echo '<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>morbi.shop — Installation Complete</title>
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; background: #0a0a0a; color: #e0e0e0; margin: 0; padding: 40px 20px; line-height: 1.6; }
    .container { max-width: 600px; margin: 0 auto; background: #1a1a1a; border-radius: 12px; padding: 32px; border: 1px solid #333; }
    h1 { color: #D4AF37; margin: 0 0 8px; font-size: 24px; }
    .subtitle { color: #888; margin: 0 0 24px; font-size: 14px; }
    .section { margin: 20px 0; padding: 16px; background: #0d0d0d; border-radius: 8px; border: 1px solid #222; }
    .section h2 { margin: 0 0 8px; font-size: 16px; color: #fff; }
    .section ul { margin: 8px 0 0; padding-left: 20px; font-size: 14px; color: #aaa; }
    .warning { background: #2a1a0a; border: 1px solid #D4AF37; padding: 16px; border-radius: 8px; margin: 20px 0; }
    .warning strong { color: #D4AF37; }
    .credentials { font-family: monospace; background: #000; padding: 12px; border-radius: 6px; font-size: 14px; }
    .credentials span { color: #D4AF37; }
    a.btn { display: inline-block; margin-top: 20px; padding: 12px 24px; background: #D4AF37; color: #000; text-decoration: none; border-radius: 6px; font-weight: 600; }
    a.btn:hover { background: #E5C654; }
    .check { color: #2D8B4E; font-weight: bold; }
  </style>
</head>
<body>
  <div class="container">
    <h1><span class="check">&#10003;</span> Installation Complete</h1>
    <p class="subtitle">morbi.shop SQLite database has been created and seeded.</p>

    <div class="section">
      <h2>What was seeded</h2>
      <ul>' . $seededList . '</ul>
    </div>

    <div class="section">
      <h2>Admin login credentials</h2>
      <div class="credentials">
        Username: <span>' . $adminUser . '</span><br>
        Password: <span>ChangeMe-Now!2026</span>
      </div>
      <p style="margin: 12px 0 0; font-size: 13px; color: #dc2626;">
        <strong>IMPORTANT:</strong> Change this password immediately after your first login
        via the dashboard &rarr; Admins tab.
      </p>
    </div>

    <div class="warning">
      <strong>&#9888; Security: Delete this file</strong><br>
      Delete <code>api/install.php</code> from your server now. Leaving it
      accessible allows anyone to trigger a reinstall (though existing data
      is never overwritten — CREATE TABLE IF NOT EXISTS + seeding only runs
      on empty tables).
    </div>

    <a href="../" class="btn">Visit the shop &rarr;</a>
    <a href="../#dashboard" class="btn" style="background:#333;color:#fff;margin-left:8px;">Go to Dashboard</a>
  </div>
</body>
</html>';
    exit;
}

function __install_html_error(string $message): void {
    header('Content-Type: text/html; charset=utf-8');
    http_response_code(500);
    echo '<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>morbi.shop — Installation Error</title>
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; background: #0a0a0a; color: #e0e0e0; margin: 0; padding: 40px 20px; line-height: 1.6; }
    .container { max-width: 600px; margin: 0 auto; background: #1a1a1a; border-radius: 12px; padding: 32px; border: 1px solid #dc2626; }
    h1 { color: #dc2626; margin: 0 0 8px; font-size: 24px; }
    .error { background: #1a0a0a; border: 1px solid #dc2626; padding: 16px; border-radius: 8px; font-family: monospace; font-size: 14px; color: #ff6b6b; margin: 20px 0; word-break: break-word; }
  </style>
</head>
<body>
  <div class="container">
    <h1>&#10007; Installation Failed</h1>
    <p>The installer encountered an error:</p>
    <div class="error">' . htmlspecialchars($message, ENT_QUOTES, 'UTF-8') . '</div>
    <p>Check that:</p>
    <ul>
      <li>The <code>storage/</code> directory exists and is writable (chmod 755).</li>
      <li>PHP has the PDO_SQLITE extension enabled.</li>
      <li>You are running PHP 7.3+ (8.1+ recommended).</li>
    </ul>
  </div>
</body>
</html>';
    exit;
}
