<?php
/**
 * _config.php — morbi.shop configuration (private, outputs nothing).
 *
 * Direct browser access is blocked by api/.htaccess. This file only defines
 * constants; it is required by _bootstrap.php (which is required by every
 * endpoint), never routed to.
 *
 * ── Phase 4 (Car) — environment variable support ─────────────────────────
 * Every secret now reads from getenv() first, falling back to the hardcoded
 * dev default. This means:
 *   - Local dev (no .env, no env vars): hardcoded dev values apply → site works
 *   - Production via .env file: api/_env.php loads .env → getenv() returns
 *     the real values → hardcoded fallbacks are never used
 *   - Production via real env vars (Docker, cPanel "Environment Variables"):
 *     getenv() returns the real values directly → hardcoded fallbacks unused
 *
 * The hardcoded values MUST NOT be real secrets in version control. They're
 * either placeholders (REPLACE_WITH_...) or dev-safe defaults (empty string,
 * ChangeMe-Now!2026, etc.). Real secrets live in .env (gitignored) or env vars.
 *
 * ── SQLite (Phase 48, 2026-09-25) ──────────────────────────────────────────
 *   The DB is now SQLite. The whole database lives in a single file at
 *   storage/morbi.sqlite. No CREATE DATABASE, no DB user, no password.
 *   The pre-seeded file ships inside the zip — uploading the zip is the
 *   ONLY setup step. There is NO install step.
 *
 *   On a fresh upload: morbi.sqlite already has the schema, the 12 seed
 *   perfumes (with correct image_path values), the admin user, the
 *   landing sections, currencies, and design tokens. The site works on
 *   first request.
 *
 *   The api/install.php file is retained ONLY as a safety net: if the
 *   sqlite file is missing OR has zero tables (rare — operator deleted
 *   it), install.php rebuilds it from scratch. Otherwise it is a no-op.
 *
 *   Backups: copy storage/morbi.sqlite. That's it. One file.
 *
 *   Concurrency: SQLite in WAL mode (set in _bootstrap.php) handles
 *   concurrent reads + serializes writes. For a single-store, low-traffic
 *   perfume shop this is more than enough. Paystack webhook retries are
 *   serialized cleanly (50ms write lock is invisible at this scale).
 */

// Path to the SQLite database file. Lives under storage/ which is
// created on demand by _bootstrap.php. The path is absolute so PHP CLI
// invocations (cron jobs, etc.) resolve it regardless of CWD.
define('DB_PATH', dirname(__DIR__) . '/storage/morbi.sqlite');

// Legacy alias — some endpoints may still reference DB_NAME in error
// messages or comments. Keep it as the basename of DB_PATH so existing
// error strings ("Database 'X' not found") still read sensibly.
define('DB_NAME', basename(DB_PATH));

// DB_HOST/DB_USER/DB_PASS are kept as empty strings for backward
// compatibility with any code that still references them — they have
// no effect under SQLite but removing them would break require'd files.
define('DB_HOST', '127.0.0.1');
define('DB_USER', '');
define('DB_PASS', '');

define('ADMIN_USER', getenv('MORBI_ADMIN_USER') ?: 'morbi');     // seeded ONCE by install.php
define('ADMIN_PASS', getenv('MORBI_ADMIN_PASS') ?: 'ChangeMe-Now!2026');  // ⚠ change before running install.php
// ★ BL-02 fix: admin recovery email. Empty string default = not set;
// install.php seeds the admin's email column with ADMIN_EMAIL if it's a
// valid email, else falls back to ADMIN_USER if it's email-shaped, else
// NULL. The forgot-password.php query is `WHERE username = ? OR email =
// ?` so recovery works if EITHER the username column equals the typed
// email OR the email column equals the typed email.
define('ADMIN_EMAIL', getenv('MORBI_ADMIN_EMAIL') ?: '');

define('INSTALL_LOCK', __DIR__ . '/../storage/installed.lock');

// Phase 0 hard cap for image data URLs (mirrors the old localStorage reality;
// real file uploads with size checks arrive in Phase 1).
define('MAX_IMAGE_CHARS', 5000000);

// ── Phase 1 Batch 2 — image uploads to filesystem ─────────────────────────
// Products used to store images as base64 data URLs inside a MEDIUMTEXT
// column. Phase 1 Batch 2 moves uploads to real files under /uploads and
// keeps the base64 path as a READ-compat fallback for legacy rows. The
// api/products.php imagePath validator (Phase 0) already accepts both
// `data:image/...;base64,...` and `uploads/<name>` shapes — no schema change.
//
// Paths are absolute filesystem paths (used by PHP's move_uploaded_file)
// OR web-root-relative URL paths (used in <img src=...>). The two are
// kept in sync: UPLOAD_DIR is the absolute fs path; UPLOAD_URL is what
// gets stored in `products.image_path`.
//
// MAX_UPLOAD_BYTES is the hard cap on a single uploaded file. 4 MB
// comfortably fits a 1024x1024 photo at JPEG q=85 (the canvas-based
// compressImage() in dashboard.js resizes to 800px before upload, so
// real-world uploads land well under 500 KB).
//
// ALLOWED_MIME: only images. PHP's finfo extension is required (ships with
// PHP since 5.3.0 — universal on XAMPP and cPanel). We check the ACTUAL
// MIME from the file bytes (not the client-provided Content-Type, which
// is trivially spoofable) and map MIME -> extension for the saved filename.
define('UPLOAD_DIR', __DIR__ . '/../uploads');
define('UPLOAD_URL', 'uploads');              // web-root-relative, no trailing slash
define('MAX_UPLOAD_BYTES', 4 * 1024 * 1024);  // 4 MB hard cap
define('ALLOWED_MIME', [
    'image/jpeg' => 'jpg',
    'image/png'  => 'png',
    'image/webp' => 'webp',
    'image/gif'  => 'gif',
]);

// ── Phase 2 (Bicycle) — Paystack payments ──────────────────────────────────
// The Paystack secret key MUST NEVER appear in any frontend asset. It is
// used ONLY by api/_paystack.php (the server-side cURL wrapper) and lives
// in this file because _config.php is the single place where environment-
// specific credentials go.
//
// Test keys start with `sk_test_` and `pk_test_`; live keys start with
// `sk_live_` and `pk_live_`. To go live: replace the test keys with the
// live ones, run a single test transaction, then verify the live webhook
// fires correctly. (Paystack's dashboard → Settings → API Keys & Webhooks.)
//
// PAYSTACK_CALLBACK_URL is the URL Paystack redirects the customer back to
// after they complete (or abandon) the payment on Paystack's hosted page.
// It must be a PUBLIC URL (not localhost) for Paystack to allow it in
// production. For local dev, Paystack allows any URL in test mode.
// ★ Phase 6 Batch 0: clean-path routing — no more `#/` in the URL. The
//   old hash-based default was `http://localhost/morbi-shop/#/payment-callback`.
//   The new clean-path default is `http://localhost/morbi-shop/payment-callback`.
//   Old bookmarks/links with `#/...` still work because the router's
//   migrateHashBookmark() rewrites them to clean paths on startup.
//
// PAYSTACK_WEBHOOK_URL is the URL Paystack POSTs the async event to. MUST
// be HTTPS in production (Paystack enforces this). For local dev, use a
// tunnel like ngrok or paystack-cli's webhook proxy.
define('PAYSTACK_SECRET_KEY', getenv('MORBI_PAYSTACK_SECRET_KEY') ?: 'sk_test_REPLACE_WITH_YOUR_TEST_KEY');
define('PAYSTACK_BASE_URL', 'https://api.paystack.co');
define('PAYSTACK_CALLBACK_URL', getenv('MORBI_PAYSTACK_CALLBACK_URL') ?: 'http://localhost/morbi-shop/payment-callback');
define('PAYSTACK_WEBHOOK_URL', getenv('MORBI_PAYSTACK_WEBHOOK_URL') ?: 'https://yourdomain.com/api/webhook.php');

// Currency code Paystack expects for Ghana is 'GHS'. The storefront's
// currency setting (Morcenzs uses 'GHS') is read from site_settings at
// payment time; if it's not 'GHS', Paystack will reject the init — so we
// validate server-side and refuse to init if the currency is anything else.
define('PAYSTACK_CURRENCY', 'GHS');

// Order reference prefix. Format: morbi-{timestamp}-{12hex}. The timestamp
// makes references sortable in the DB; the random suffix prevents collisions
// from concurrent orders in the same second.
define('ORDER_REF_PREFIX', 'morbi');

// ── Phase 3 (Motorcycle) — rate limiting + CSRF ───────────────────────────────
// Buckets + windows for the DB-backed rate limiter in _bootstrap.php.
// Tuned to be gentle for legitimate users and hard for spammers/brute-forcers.
//
// RATE_LIMIT_PAYMENTS_MAX/WINDOW — public checkout endpoint. 5 attempts / 5
// min per IP. A spam-init script would have to rotate IPs every 5 attempts
// to keep going — and even then, every successful attempt creates a Paystack
// round-trip (which itself rate-limits at the Paystack side). A legit user
// will rarely trip this (typical checkout is 1-2 attempts; failures only
// happen on validation errors, which return 422 BEFORE the rate-limit
// counter ticks — see payments.php for the call placement).
//
// RATE_LIMIT_LOGIN_MAX/WINDOW — admin login endpoint. 5 attempts / 5 min per
// IP AND per username (both buckets enforced — see login.php). The
// per-username bucket defends against a distributed attacker targeting one
// account from many IPs; the per-IP bucket defends against a single
// attacker trying many usernames from one IP.
//
// ★ OTH-14 fix (iteration 25 — this batch): the long docstring that used to
//   describe a planned `RATE_LIMIT_LOGIN_LOCKOUT_EXTRA` constant (additional
//   escalating lockout applied AFTER a per-username bucket was exhausted)
//   has been removed. The constant was never defined; the escalating-
//   lockout behavior was never implemented; `_bootstrap::rate_limit_check()`
//   does a straight COUNT-based cutoff with no extra lockout. The stale
//   comment was misleading future maintainers (a planned-but-never-built
//   feature described as if shipped). The simpler "5/5min per IP + per
//   username" model is the actual behavior; this is the only contract.
//   If an escalating-lockout is needed in the future, define a new
//   constant explicitly + implement the behavior in `rate_limit_check()` —
//   don't re-add the stale docstring.
define('RATE_LIMIT_PAYMENTS_MAX',    5);
define('RATE_LIMIT_PAYMENTS_WINDOW', 5 * 60);   // 5 minutes
define('RATE_LIMIT_LOGIN_MAX',       5);
define('RATE_LIMIT_LOGIN_WINDOW',    5 * 60);   // 5 minutes

// ── Phase 3 (Motorcycle) Batch 3 — SMTP + password recovery ────────────────
// SMTP credentials for sending password-reset emails via PHPMailer. The
// client uses their own domain's SMTP (e.g. smtp.morbi.shop) — NOT a shared
// host's sendmail, which is unreliable on cPanel shared hosting and gets
// flagged as spam by Gmail/Outlook.
//
// PHPMailer is placed MANUALLY in vendor/phpmailer/ (no composer — cPanel
// shared hosting constraint per the approved roadmap). See docs/SMTP-SETUP.md
// for the 3-file installation walkthrough.
//
// If SMTP_HOST is still the placeholder, forgot-password.php returns 503
// with a clear message directing to docs/SMTP-SETUP.md — better to fail
// loudly than silently send emails that never arrive.
//
// PASSWORD_RESET_TOKEN_TTL: how long a reset link stays valid. 1 hour is
// the OWASP-recommended default — long enough for the user to check their
// inbox, short enough that a leaked link expires before an attacker can
// use it.
//
// PASSWORD_RESET_RATE_LIMIT_MAX/WINDOW: per-IP AND per-email rate limit
// for forgot-password.php. 3 / hour is tight enough to stop enumeration
// attacks (an attacker can only test 3 emails per hour per IP) but loose
// enough for a forgetful admin to retry after a typo.
// ★ SEC-16 fix: was `smtp.morbi.shop` / `noreply@morbi.shop` / `REPLACE_WITH_SMTP_PASSWORD`.
//   The defaults pretended to be real — a half-configured install would hang
//   trying to reach `smtp.morbi.shop` (which may not exist) rather than
//   failing locally. The placeholder password also revealed the expected
//   format to anyone reading the source.
//   Fix: default SMTP_HOST to empty string. _mailer.php now refuses to send
//   if SMTP_HOST is empty, with a clear log line pointing to docs/SMTP-SETUP.md.
//   SMTP_USER/FROM also default to empty — _mailer.php refuses if any are empty.
define('SMTP_HOST', getenv('MORBI_SMTP_HOST') ?: '');
define('SMTP_PORT', (int)(getenv('MORBI_SMTP_PORT') ?: 587));  // 587 = TLS (recommended); 465 = SSL
define('SMTP_USER', getenv('MORBI_SMTP_USER') ?: '');
define('SMTP_PASS', getenv('MORBI_SMTP_PASS') ?: '');
define('SMTP_FROM', getenv('MORBI_SMTP_FROM') ?: '');
define('SMTP_FROM_NAME', getenv('MORBI_SMTP_FROM_NAME') ?: 'morbi.shop Admin');

define('PASSWORD_RESET_TOKEN_TTL', 60 * 60);  // 1 hour (seconds)
define('PASSWORD_RESET_RATE_LIMIT_MAX',    3);
define('PASSWORD_RESET_RATE_LIMIT_WINDOW', 60 * 60);  // 1 hour

// The base URL for the reset link. The frontend clean-path route is
// /reset-password?token=<64hex> (Phase 6 Batch 0: clean-path routing —
// no `#/` prefix). For local dev, http://localhost/morbi-shop/
// is fine. For production, use the full HTTPS URL (Paystack + browsers
// require HTTPS for password-reset flows — Phase 4 enforces HTTPS site-wide
// via the root .htaccess + HSTS header).
// ★ Phase 6 Batch 0: the reset URL is built as `<base>/reset-password?token=...`
//   (was `<base>/#/reset-password?token=...`).
define('PASSWORD_RESET_URL_BASE', getenv('MORBI_PASSWORD_RESET_URL_BASE') ?: 'http://localhost/morbi-shop/');
