<?php
/**
 * products.php — public GET (available only) + admin CRUD.
 *
 * GET    ?all=1 (admin only)   -> { products: [...] }
 * POST   admin, full payload    -> created product (201)
 * PUT    admin, {id, ...patch}  -> updated product
 * DELETE admin, {id} or ?id=    -> { deleted: id }
 *
 * JSON field names mirror the original JS shapes (categoryId, imagePath,
 * available) so the frontend markup and logic stay byte-identical.
 */

require __DIR__ . '/_bootstrap.php';
// ★ Phase 9 Batch 3 (Task 63): load _notifications.php for the
// notify_stock_back() call when the admin restocks (stock 0/NULL → N>0).
require_once __DIR__ . '/_notifications.php';

switch ($_SERVER['REQUEST_METHOD']) {
    case 'GET':    handle_get();        break;
    case 'POST':   require_admin(); verify_csrf(); handle_create();   break;
    case 'PUT':    require_admin(); verify_csrf(); handle_update();   break;
    case 'DELETE': require_admin(); verify_csrf(); handle_delete();   break;
    default:       json_err('Method not allowed.', 405);
}

/* ---- GET ------------------------------------------------------------------
 * ★ PERF-02 fix (Task 45): SELECT * is replaced with the explicit column
 *   list map_product() actually reads. The old SELECT * pulled every column
 *   (including created_at/updated_at and, on drifted legacy schemas, whatever
 *   else exists) into PHP memory + the JSON encoder for zero benefit. The
 *   response JSON is byte-identical (map_product never read the extra keys).
 *   NOTE: image_path is deliberately KEPT in the list — the storefront renders
 *   <img src="{imagePath}"> directly, so dropping it would blank every card.
 *   The 12 MB-payload worst case from the audit (legacy base64 MEDIUMTEXT
 *   rows) can only shrink by running the existing Migrate Images tool
 *   (dashboard > Landing > Migrate Images) — see PERF-02 in performance_bugs.md.
 *   An upgrade-drift fallback re-runs the query with SELECT * when the
 *   explicit list fails (pre-Phase-3/5 schemas without stock/scent_category —
 *   the RT-09 "files upgraded without re-running install" scenario). On such
 *   schemas map_product's ?? guards produce the exact same output as before
 *   this fix.
 *
 * ★ PERF-03 fix (Task 45): optional pagination via ?limit= and ?offset=.
 *   Default behavior is UNCHANGED (no params → full catalog) because both
 *   existing consumers (storefront hydrate + dashboard hydrate) render the
 *   entire catalog client-side with client-side category/scent filtering —
 *   capping the server response would break them. New/future clients (mobile
 *   app, paged storefront) can opt in: ?limit=24&offset=0 caps each request
 *   at 200 rows and additionally returns { total, limit, offset } so callers
 *   can render page controls (same contract shape orders.php uses since WF-15).
 *
 * ★ PERF-01 fix (Task 45): the per-product fetch_variants() round-trip inside
 *   map_product() is replaced by ONE batched IN (...) query for the whole
 *   result set (fetch_variants_batch). 1 + N queries → 2 queries.
 */
function handle_get(): void {
    $all = is_admin() && isset($_GET['all']);
    $where = $all ? '' : ' WHERE available = 1';
    $order = ' ORDER BY created_at ASC, id ASC';

    // PERF-03: optional pagination (ints — interpolated safely after cast).
    $limit  = isset($_GET['limit'])  ? (int)$_GET['limit']  : 0;
    $offset = isset($_GET['offset']) ? max(0, (int)$_GET['offset']) : 0;
    $paged  = $limit > 0;
    if ($paged) { $limit = min($limit, 200); }  // hard per-request cap

    $cols = 'id, name, scent, scent_category, description, price, category_id, image_path, available, stock';
    try {
        $sql = 'SELECT ' . $cols . ' FROM products' . $where . $order
             . ($paged ? ' LIMIT ' . $limit . ' OFFSET ' . $offset : '');
        $rows = db()->query($sql)->fetchAll();
    } catch (PDOException $e) {
        // PERF-02 upgrade-drift fallback (see block comment above): a schema
        // missing stock/scent_category can't serve the explicit column list.
        // SELECT * + map_product's guards reproduce the pre-PERF-02 behavior.
        $sql = 'SELECT * FROM products' . $where . $order
             . ($paged ? ' LIMIT ' . $limit . ' OFFSET ' . $offset : '');
        $rows = db()->query($sql)->fetchAll();
    }

    // PERF-01: one batched variant fetch for the whole page (empty page →
    // skip the query entirely).
    $ids = [];
    foreach ($rows as $r) { $ids[] = (int)$r['id']; }
    $variantsByProduct = fetch_variants_batch($ids);

    $payload = ['products' => array_map(
        function ($r) use ($variantsByProduct) {
            return map_product($r, $variantsByProduct);
        },
        $rows
    )];
    if ($paged) {
        // Same truth-total contract orders.php has returned since WF-15:
        // COUNT(*) over the SAME visibility scope as the page query.
        $countSql = 'SELECT COUNT(*) FROM products' . $where;
        $payload['total']  = (int)db()->query($countSql)->fetchColumn();
        $payload['limit']  = $limit;
        $payload['offset'] = $offset;
    }
    json_ok($payload);
}

/* ---- POST ------------------------------------------------------------------ */
function handle_create(): void {
    $b = json_body();
    // Create requires the two non-nullable essentials (mirrors the old form
    // validation: name min 2 chars, price > 0).
    if (!array_key_exists('name', $b))  json_err('Name is required (min 2 characters, max 150).', 422);
    if (!array_key_exists('price', $b)) json_err('Valid price required (must be greater than 0).', 422);

    $v = validate_product($b);
    if ($v['error'] !== null) json_err($v['error'], 422);

    // ★ BL-11 fix (parallel blind spot to the audit's handle_update case):
    //   handle_create had the SAME atomicity issue — the product INSERT was
    //   committed first, then save_variants ran in a SEPARATE transaction.
    //   If save_variants threw, the product row was orphaned with no variants.
    //   The audit only flagged handle_update, but handle_create has the
    //   identical shape. Now both wrap product write + save_variants in a
    //   single outer transaction (save_variants no longer opens its own —
    //   see the helper's docstring for the rationale).
    // ★ RT-08 fix (re-verify): the audit's RT-08 said "the callers do NOT
    //   wrap the call in a try/catch" — but the BL-11 fix (Task 28) DID wrap
    //   both callers in a try/catch that catches Exception + returns json_err
    //   500. An uncaught PDOException from save_variants now produces a clean
    //   JSON error response (not an HTML stack trace). The save_variants
    //   function itself no longer opens its own transaction — it propagates
    //   exceptions to the caller's try/catch.
    // ★ OTH-19 verification (iteration 25 — this batch): re-confirmed by
    //   `grep -n 'save_variants' api/products.php` that BOTH callers
    //   (handle_create's save_variants call + handle_update's
    //   save_variants call, both visible in this file) wrap save_variants
    //   in `try { ... } catch (Exception $e) { $pdo->rollBack();
    //   json_err('Could not ...', 500); }`. An uncaught PDOException
    //   from save_variants now produces a clean JSON error response
    //   (not an HTML stack trace). The misleading comment in save_variants's
    //   own docstring (that said "let the caller's try/catch handle the
    //   HTTP response") was already updated by BL-11 to the accurate
    //   "the caller catches and returns 500" wording. The OTH-19 audit
    //   entry is therefore already closed by BL-11 + RT-08 re-verify;
    //   this note is the iteration-25 confirmation.
    $pdo = db();
    $pdo->beginTransaction();
    try {
        $stmt = $pdo->prepare(
            'INSERT INTO products (name, scent, scent_category, description, price, category_id, image_path, available, stock)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'
        );
        $stmt->execute([
            $v['name'], $v['scent'], $v['scent_category'], $v['description'], $v['price'],
            // ★ Blind-spot fix (audit): default 'available' to 1 (visible) when
            //   not provided. The old code: $v['available'] ? 1 : 0 — but
            //   validate_product leaves $out['available']=null when the field
            //   is absent, and null is falsey → 0 (hidden). A create request
            //   like {"name":"X","price":10} silently created a HIDDEN product.
            $v['category_id'], $v['image_path'], ($v['available'] === null ? 1 : ($v['available'] ? 1 : 0)),
            $v['stock'],
        ]);
        $newId = (int)$pdo->lastInsertId();

        // ★ Phase 5 Batch 3: save variants if provided.
        if (isset($b['variants']) && is_array($b['variants'])) {
            save_variants($pdo, $newId, $b['variants']);
        }

        $pdo->commit();
    } catch (Exception $e) {
        $pdo->rollBack();
        error_log('[morbi] Product creation failed: ' . $e->getMessage()); json_err('Could not create product. Check the server error log for details.', 500);
    }

    $row = fetch_product($newId);
    json_ok(map_product($row), 201);
}

/* ---- PUT ------------------------------------------------------------------ */
function handle_update(): void {
    $b = json_body();
    $id = (int)($b['id'] ?? 0);
    if ($id <= 0) json_err('Product id is required.', 422);
    if (!fetch_product($id)) json_err('Product not found.', 404);

    // Patch-style: only the keys present in the body are updated (mirrors the
    // old updateProduct(id, patch) semantics).
    // ★ BL-16 fix: 'scentCategory' added to the $allowed list so the dashboard's
    //   p-scent-category select can patch the column via PUT.
    $allowed = ['name', 'scent', 'scentCategory', 'description', 'price', 'categoryId', 'imagePath', 'available', 'stock'];
    $sets = [];
    $params = [];
    $v = null;

    foreach ($allowed as $key) {
        if (!array_key_exists($key, $b)) continue;
        if ($v === null) { $v = validate_product($b); if ($v['error'] !== null) json_err($v['error'], 422); }
        $colMap = ['name' => 'name', 'scent' => 'scent', 'scentCategory' => 'scent_category', 'description' => 'description',
                   'price' => 'price', 'categoryId' => 'category_id',
                   'imagePath' => 'image_path', 'available' => 'available', 'stock' => 'stock'];
        $sets[] = $colMap[$key] . ' = ?';
        $value = $v[$key === 'categoryId' ? 'category_id' : ($key === 'imagePath' ? 'image_path' : ($key === 'scentCategory' ? 'scent_category' : $key))];
        // available is a bool in $v but a TINYINT column: bind as int (a bare
        // PHP false can be sent as '' by PDO with native prepares).
        $params[] = ($key === 'available') ? (int)$value : $value;
    }

    // ★ BL-13 fix: the `if (!$sets) json_err` guard was placed BEFORE the
    // variant-handling block, so a PUT body of `{"id":N,"variants":[…]}`
    // (variant-only patch) was rejected with 422 "No valid fields to update"
    // and the variant data was silently discarded. The guard now also checks
    // whether a `variants` key is present — if so, the request is valid even
    // with no other field updates (the variant save runs and the product row
    // is untouched). Without this fix, any future "quick edit variants" UI
    // (modal, CLI tool, mobile app) would be broken.
    if (!$sets && !array_key_exists('variants', $b)) json_err('No valid fields to update.', 422);

    // ★ Phase 9 Batch 3 (Task 63): capture the OLD stock BEFORE the UPDATE
    //   so we can detect the restock transition (0 or NULL → N>0) and fire
    //   notify_stock_back() after the commit. We read the product row once
    //   here; the UPDATE below mutates the row but $oldStock is already in
    //   memory by then. Only fetches if the request is patching 'stock'
    //   (avoids a wasted query for name-only edits).
    $oldStock = null;
    $isStockPatch = array_key_exists('stock', $b);
    if ($isStockPatch) {
        $oldStmt = db()->prepare('SELECT stock FROM products WHERE id = ? LIMIT 1');
        $oldStmt->execute([$id]);
        $oldRow = $oldStmt->fetch();
        $oldStock = $oldRow ? ($oldRow['stock'] !== null ? (int)$oldRow['stock'] : null) : null;
    }

    // ★ BL-11 fix: wrap the product UPDATE + save_variants in a SINGLE outer
    //   transaction so a save_variants failure rolls back the product UPDATE
    //   too. Previously the UPDATE was committed first, then save_variants ran
    //   in a SEPARATE transaction (which rolled back its own writes on
    //   failure), leaving the product row with the admin's new name/price but
    //   the OLD variants → confused state.
    // ★ BL-13 unblock: when the request is variant-only ($sets is empty but
    //   `variants` is present), the UPDATE is skipped — the transaction only
    //   contains save_variants. The `$sets` guard above already ensured we
    //   don't reach here with both empty.
    $pdo = db();
    $pdo->beginTransaction();
    try {
        if ($sets) {
            $params[] = $id;
            $stmt = $pdo->prepare('UPDATE products SET ' . implode(', ', $sets) . ' WHERE id = ?');
            $stmt->execute($params);
        }

        // ★ Phase 5 Batch 3: save variants if provided (replaces all existing).
        if (array_key_exists('variants', $b) && is_array($b['variants'])) {
            save_variants($pdo, $id, $b['variants']);
        }

        $pdo->commit();
    } catch (Exception $e) {
        $pdo->rollBack();
        error_log('[morbi] Product update failed: ' . $e->getMessage()); json_err('Could not update product. Check the server error log for details.', 500);
    }

    // ★ Phase 9 Batch 3 (Task 63): if the admin restocked the product
    //   (stock went from 0 or NULL → N>0), fire notify_stock_back() to email
    //   every customer who signed up for a restock alert on this product.
    //   Fire-and-forget (try/catch) — an email failure shouldn't break the
    //   product update response. The notification is idempotent (signups
    //   marked notified_at are skipped on subsequent calls).
    //
    //   Variant restock: the BL-14 fix means variant stock overrides product
    //   stock. When the admin patches a variant's stock (via the variants[]
    //   array), the parent product's stock isn't touched. Variant-level
    //   restock notifications are a future enhancement — for now, only
    //   parent-product restock triggers notify_stock_back(). This covers the
    //   common case (Morcenzs has few variants).
    if ($isStockPatch && $oldStock !== $v['stock']) {
        $newStock = $v['stock'];
        $wasOutOfStock = ($oldStock === null || $oldStock === 0);
        $isNowInStock = ($newStock !== null && $newStock > 0);
        if ($wasOutOfStock && $isNowInStock) {
            try {
                notify_stock_back($id, null);
            } catch (Throwable $e) {
                error_log('[morbi] notify_stock_back threw for product ' . $id . ': ' . $e->getMessage());
            }
        }
    }

    json_ok(map_product(fetch_product($id)));
}

/* ---- DELETE ------------------------------------------------------------------ */
function handle_delete(): void {
    $b = json_body();
    $id = (int)($b['id'] ?? ($_GET['id'] ?? 0));
    if ($id <= 0) json_err('Product id is required.', 422);

    $stmt = db()->prepare('DELETE FROM products WHERE id = ?');
    $stmt->execute([$id]);
    if ($stmt->rowCount() === 0) json_err('Product not found.', 404);

    json_ok(['deleted' => $id]);
}

/* ---- Helpers ------------------------------------------------------------------ */
function fetch_product(int $id): ?array {
    $stmt = db()->prepare('SELECT * FROM products WHERE id = ? LIMIT 1');
    $stmt->execute([$id]);
    $row = $stmt->fetch();
    return $row ?: null;
}

/** Validates the fields present in $b. Returns validated values or a 422 error. */
function validate_product(array $b): array {
    $out = [
        'name' => null, 'scent' => null, 'scent_category' => null, 'description' => null, 'price' => null,
        'category_id' => null, 'image_path' => null, 'available' => null,
        'stock' => null, 'error' => null,
    ];

    if (array_key_exists('name', $b)) {
        $name = trim((string)$b['name']);
        $len = mb_strlen($name);
        if ($len < 2 || $len > 150) { $out['error'] = 'Name is required (min 2 characters, max 150).'; return $out; }
        $out['name'] = $name;
    }

    if (array_key_exists('scent', $b)) {
        $scent = trim((string)$b['scent']);
        if (mb_strlen($scent) > 100) { $out['error'] = 'Scent profile is too long (max 100 characters).'; return $out; }
        $out['scent'] = $scent;
    }

    // ★ BL-16 fix: validate scent_category. NULL/empty string = untagged
    //   (shows in ALL views per the backward-compat rule in storefront.js's
    //   filterByScent). Must be one of 'male', 'female', 'unisex' if set —
    //   any other value is a 422 (defensive — the dashboard's select only
    //   offers these three plus the empty "Untagged" option, but a CLI tool
    //   or mobile app could send anything).
    if (array_key_exists('scentCategory', $b)) {
        $rawCat = $b['scentCategory'];
        if ($rawCat === null || $rawCat === '') {
            $out['scent_category'] = null;
        } else {
            $sc = strtolower(trim((string)$rawCat));
            if (!in_array($sc, ['male', 'female', 'unisex'], true)) {
                $out['error'] = 'Scent category must be "male", "female", "unisex", or empty (untagged).';
                return $out;
            }
            $out['scent_category'] = $sc;
        }
    }

    if (array_key_exists('description', $b)) {
        $desc = trim((string)$b['description']);
        if (mb_strlen($desc) > 500) { $out['error'] = 'Description is too long (max 500 characters).'; return $out; }
        $out['description'] = $desc;
    }

    if (array_key_exists('price', $b)) {
        $price = filter_var($b['price'], FILTER_VALIDATE_FLOAT);
        if ($price === false || $price <= 0) { $out['error'] = 'Valid price required (must be greater than 0).'; return $out; }
        $out['price'] = round($price, 2);
    }

    if (array_key_exists('categoryId', $b)) {
        $raw = $b['categoryId'];
        if ($raw === null || $raw === '' || $raw === 0) {
            $out['category_id'] = null;
        } else {
            $cid = (int)$raw;
            $stmt = db()->prepare('SELECT COUNT(*) FROM categories WHERE id = ?');
            $stmt->execute([$cid]);
            if ((int)$stmt->fetchColumn() === 0) { $out['error'] = 'Selected category does not exist.'; return $out; }
            $out['category_id'] = $cid;
        }
    }

    if (array_key_exists('imagePath', $b)) {
        $img = (string)$b['imagePath'];
        if (strlen($img) > MAX_IMAGE_CHARS) { $out['error'] = 'Image is too large.'; return $out; }
        // Data URL or relative path only — never let raw markup into this field.
        // ★ SEC-11 fix: was `uploads/[A-Za-z0-9._/-]+` which allowed `/` and `..`
        //   → path-traversal sequences like `uploads/../../api/_config.php` passed
        //   validation. The storefront would render `<img src="uploads/../../api/_config.php">`
        //   → browser resolves to `/api/_config.php` (same-origin reference). While
        //   api/.htaccess blocks `^_` files, the path could reference any same-origin
        //   URL. Fix: tighten to `uploads/[A-Za-z0-9._-]+` (no `/`) — uploads are
        //   flat (server-generated filenames like `{ts}-{12hex}.jpg`). Also reject
        //   `..` explicitly (defense in depth — the `-` in the character class
        //   is at the end so it's a literal, not a range).
        if ($img !== '' && !preg_match('#^(data:image/(png|jpe?g|webp|gif);base64,[A-Za-z0-9+/=\s]+|uploads/[A-Za-z0-9._-]+)$#', $img)) {
            $out['error'] = 'Image must be a base64 data URL or an uploads/ path.'; return $out;
        }
        $out['image_path'] = $img;
    }

    if (array_key_exists('available', $b)) {
        $out['available'] = to_bool($b['available'], true);
    }

    // ★ Phase 3 Batch 4: stock validation.
    // NULL or absent  → unlimited (no tracking) — backward compat for Phase 0-3 clients
    // empty string '' → unlimited (frontend "clear" button sends "")
    // non-negative int → tracked (0 = out of stock, N = available)
    // negative int    → 422 (defensive — frontend clamps to 0, but server doesn't trust)
    if (array_key_exists('stock', $b)) {
        $raw = $b['stock'];
        if ($raw === null || $raw === '') {
            $out['stock'] = null;
        } else {
            $stock = filter_var($raw, FILTER_VALIDATE_INT);
            if ($stock === false || $stock < 0) {
                $out['error'] = 'Stock must be a non-negative integer (or empty for unlimited).'; return $out;
            }
            $out['stock'] = $stock;
        }
    }

    return $out;
}

/** DB row → JSON shape the frontend already understands.
 * ★ PERF-01 (Task 45): optional second parameter — the batched variant map
 * from fetch_variants_batch(). NULL (the default) keeps the legacy per-row
 * fetch_variants() behavior for single-product callers. */
function map_product(array $r, ?array $variantsByProduct = null): array {
    return [
        'id'            => (int)$r['id'],
        'name'          => $r['name'],
        'scent'         => (string)($r['scent'] ?? ''),
        // ★ BL-16 fix: expose scent_category in the response so the storefront's
        //   filterByScent() can filter by it + the dashboard's product editor
        //   can populate the p-scent-category select on edit. NULL = untagged
        //   (shows in ALL views per the backward-compat rule in filterByScent).
        'scentCategory' => (string)($r['scent_category'] ?? ''),
        'description'   => (string)($r['description'] ?? ''),
        'price'         => (float)$r['price'],
        'categoryId'    => ($r['category_id'] !== null) ? (int)$r['category_id'] : null,
        'imagePath'     => (string)($r['image_path'] ?? ''),
        'available'     => (bool)$r['available'],
        // ★ PERF-02 hardening (Task 45): the bare $r['stock'] access warned
        //   (PHP 8 "Undefined array key") on upgrade-drifted schemas where the
        //   fallback SELECT * path returns no stock column — same scenario as
        //   payments.php's RT-09 guard. The ?? null form is behavior-identical
        //   on every schema that has the column.
        'stock'         => (($r['stock'] ?? null) !== null) ? (int)$r['stock'] : null,  // ★ Phase 3 Batch 4 + PERF-02
        // ★ PERF-01 fix (Task 45): $variantsByProduct (the batched map from
        //   fetch_variants_batch) is passed by handle_get so the LIST path no
        //   longer runs one query PER PRODUCT (the N+1). When the map is not
        //   supplied (single-product responses from handle_create/handle_update),
        //   the original per-row fetch_variants() runs — 1 row = 1 query, no waste.
        'variants'      => ($variantsByProduct !== null)
            ? ($variantsByProduct[(int)$r['id']] ?? [])
            : fetch_variants((int)$r['id']),  // ★ Phase 5 Batch 3
    ];
}

// ★ Phase 5 Batch 3: fetch variants for a product.
// Returns an array of variant objects (id, name, price, stock, available, sortOrder).
// Empty array if the product has no variants (backward compat).
// ★ Migration 2026-09-26: the `price`, `available`, `sort_order` columns
//   now exist on `product_variants` (added by the schema migration in
//   scripts/migrate_sqlite_schema.py + install.php). Previously this
//   query was throwing `SQLITE_ERROR: no such column: price` on every
//   product LIST call → storefront + dashboard couldn't load any products.
function fetch_variants(int $productId): array {
    $stmt = db()->prepare(
        'SELECT id, name, price, stock, available, sort_order
         FROM product_variants
         WHERE product_id = ?
         ORDER BY sort_order ASC, id ASC'
    );
    $stmt->execute([$productId]);
    return array_map(function ($v) {
        return [
            'id'        => (int)$v['id'],
            'name'      => $v['name'],
            'price'     => (float)$v['price'],
            'stock'     => ($v['stock'] !== null) ? (int)$v['stock'] : null,
            'available' => (bool)$v['available'],
            'sortOrder' => (int)$v['sort_order'],
        ];
    }, $stmt->fetchAll());
}

// ★ PERF-01 fix (Task 45): batched variant fetch for LIST responses.
// Replaces the N+1 pattern (map_product → fetch_variants per row) with ONE
// `WHERE product_id IN (...)` query for the whole page: 1 + N round-trips
// collapse to 2 (page + variants). Returns a map keyed by product_id where
// each value is the EXACT same array shape fetch_variants() returns for that
// product (same column list, same sort_order/id ordering, same casts) — so
// map_product's output is byte-identical to the pre-fix responses.
// An empty id list short-circuits to [] without touching the DB (empty page).
function fetch_variants_batch(array $productIds): array {
    if (!$productIds) return [];
    $ids = [];
    foreach ($productIds as $pid) {
        $pid = (int)$pid;
        if ($pid > 0) $ids[$pid] = $pid;  // de-dup + keep positive ints only
    }
    if (!$ids) return [];
    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $stmt = db()->prepare(
        "SELECT product_id, id, name, price, stock, available, sort_order
         FROM product_variants
         WHERE product_id IN ($placeholders)
         ORDER BY sort_order ASC, id ASC"
    );
    $stmt->execute(array_values($ids));
    $map = [];
    foreach ($stmt->fetchAll() as $v) {
        $map[(int)$v['product_id']][] = [
            'id'        => (int)$v['id'],
            'name'      => $v['name'],
            'price'     => (float)$v['price'],
            'stock'     => ($v['stock'] !== null) ? (int)$v['stock'] : null,
            'available' => (bool)$v['available'],
            'sortOrder' => (int)$v['sort_order'],
        ];
    }
    return $map;
}

// ★ Phase 5 Batch 3: save variants for a product (upsert-style: delete all
// existing, then insert the new ones). Called from handle_create + handle_update.
// ★ BL-11 fix: the original save_variants opened its OWN transaction (so a
// partial INSERT failure didn't leave half-old + half-new variants), but the
// OUTER caller (handle_update) ran the product UPDATE OUTSIDE that
// transaction. If save_variants threw, the product row was already committed
// with the new name/price/stock, but the variants were the OLD ones (rolled
// back) → confused state.
//
// Fix: save_variants no longer opens its own transaction. The caller must
// wrap the product INSERT/UPDATE + save_variants in a single outer
// transaction (see handle_create + handle_update). If save_variants throws,
// the outer transaction rolls back BOTH the product write AND the variant
// writes — atomic. The caller catches and returns 500.
//
// Signature change: the caller now passes its already-open PDO handle into
// save_variants (was: save_variants(int, array); now: save_variants(PDO, int, array)).
// This is a breaking change to the function signature, but the function is
// only called from two places in this file (handle_create + handle_update),
// both of which are patched in this same edit.
function save_variants(PDO $pdo, int $productId, array $variants): void {
    // Caller MUST have opened a transaction. We do NOT begin/commit/rollback
    // here — any thrown exception propagates up and the caller's catch block
    // rolls back the whole outer transaction.

    // ★ WF-04 fix: this used to be an unconditional
    //   `DELETE FROM product_variants WHERE product_id = ?` followed by
    //   re-INSERT — which rotated EVERY variant id on EVERY product save
    //   (even a description-only edit, because handleProductSave always
    //   sends the variants payload). Customer carts referenced the old ids,
    //   so every save orphaned those cart items: checkout then died with
    //   422 "Invalid variant for product" (payments.php looks the variant
    //   up by id + product). Fix: DIFF-based save —
    //     * payload row WITH an id that exists on this product → UPDATE in
    //       place (id preserved — carts stay valid, stock history intact);
    //     * payload row WITHOUT an id (or with a foreign/stale id) → INSERT
    //       (new id);
    //     * existing row whose id is ABSENT from the payload → DELETE (the
    //       admin removed it in the editor). Cart items referencing the
    //       removed id are swept by the storefront's variant-aware cleanup
    //       (storefront.js render — the WF-16 fix).
    //   Rows are matched with `AND product_id = ?` on every statement so a
    //   tampered payload can never touch another product's variants.
    $existingStmt = $pdo->prepare('SELECT id FROM product_variants WHERE product_id = ?');
    $existingStmt->execute([$productId]);
    $existingIds = [];
    foreach ($existingStmt->fetchAll() as $row) {
        $existingIds[(int)$row['id']] = true;
    }

    $updateStmt = $pdo->prepare(
        'UPDATE product_variants
         SET name = ?, price = ?, stock = ?, available = ?, sort_order = ?
         WHERE id = ? AND product_id = ?'
    );
    $insertStmt = $pdo->prepare(
        'INSERT INTO product_variants (product_id, name, price, stock, available, sort_order)
         VALUES (?, ?, ?, ?, ?, ?)'
    );
    $deleteStmt = $pdo->prepare(
        'DELETE FROM product_variants WHERE id = ? AND product_id = ?'
    );

    $keptIds = [];
    $order = 0;
    foreach ($variants as $v) {
        if (!is_array($v)) continue;
        $name = trim((string)($v['name'] ?? ''));
        if ($name === '') continue; // skip empty variant names
        $price = filter_var($v['price'] ?? 0, FILTER_VALIDATE_FLOAT);
        if ($price === false || $price < 0) $price = 0;
        $stock = null;
        if (isset($v['stock']) && $v['stock'] !== null && $v['stock'] !== '') {
            $s = filter_var($v['stock'], FILTER_VALIDATE_INT);
            if ($s !== false && $s >= 0) $stock = $s;
        }
        $available = to_bool($v['available'] ?? true, true);

        $vid = isset($v['id']) ? filter_var($v['id'], FILTER_VALIDATE_INT) : false;
        if ($vid !== false && $vid > 0 && isset($existingIds[$vid])) {
            // Existing variant → update in place, id preserved.
            $updateStmt->execute([$name, round($price, 2), $stock, $available ? 1 : 0, $order, $vid, $productId]);
            $keptIds[$vid] = true;
        } else {
            // New variant (no id, or an id that doesn't belong to this
            // product — stale/foreign ids are treated as new, never as a
            // hijack of another product's row).
            $insertStmt->execute([$productId, $name, round($price, 2), $stock, $available ? 1 : 0, $order]);
        }
        $order++;
    }

    // Anything the payload omitted was removed by the admin → delete it.
    foreach (array_keys($existingIds) as $oldId) {
        if (!isset($keptIds[$oldId])) {
            $deleteStmt->execute([$oldId, $productId]);
        }
    }
}
