<?php
/**
 * _env.php — Phase 4 (Car) optional .env file loader.
 *
 * If a .env file exists at the project root (next to api/), parse it and
 * putenv() each line. This lets cPanel users (who often can't set real
 * environment variables via the OS) configure secrets without editing
 * _config.php.
 *
 * If no .env exists, this is a no-op — _config.php falls back to getenv()
 * (which returns false for unset vars) and then to the hardcoded dev defaults.
 *
 * Format of .env (standard KEY=VALUE, one per line, # for comments):
 *   MORBI_DB_HOST=127.0.0.1
 *   MORBI_DB_NAME=morbi_shop
 *   MORBI_DB_USER=root
 *   MORBI_DB_PASS=secret
 *   MORBI_ADMIN_USER=morbi
 *   MORBI_ADMIN_PASS=secret
 *   MORBI_PAYSTACK_SECRET_KEY=sk_live_...
 *   MORBI_SMTP_HOST=smtp.morbi.shop
 *   MORBI_SMTP_USER=noreply@morbi.shop
 *   MORBI_SMTP_PASS=secret
 *   MORBI_PAYSTACK_CALLBACK_URL=https://morbi.shop/#/payment-callback
 *   MORBI_PAYSTACK_WEBHOOK_URL=https://morbi.shop/api/webhook.php
 *   MORBI_PASSWORD_RESET_URL_BASE=https://morbi.shop/
 *
 * See .env.example for the full template.
 *
 * Security: the .env file is blocked from web access by the root .htaccess
 * (the `^\.` FilesMatch rule blocks dotfiles). It's also in .gitignore so
 * it never gets committed.
 *
 * Blocked from direct web access by api/.htaccess (leading underscore →
 * FilesMatch ^_ → denied).
 */

$envPath = __DIR__ . '/../.env';

if (!file_exists($envPath)) {
    return;  // no .env file — _config.php will use getenv() + hardcoded fallbacks
}

if (!is_readable($envPath)) {
    error_log('[morbi] .env file exists but is not readable. Check permissions.');
    return;
}

// Parse the .env file. We use parse_ini_file (handles KEY=VALUE, comments
// with ;, and quoted values). The .env format is INI-compatible.
//
// parse_ini_file with INI_SCANNER_RAW preserves values as-is (no escaping
// of special chars). PROCESS SECTIONS is false (flat key=value, no [sections]).
$vars = @parse_ini_file($envPath, false, INI_SCANNER_RAW);

if (!is_array($vars)) {
    error_log('[morbi] .env file could not be parsed. Check syntax (KEY=VALUE, one per line).');
    return;
}

foreach ($vars as $key => $value) {
    // putenv() makes the value available to getenv() — which _config.php reads.
    // We also set $_ENV and $_SERVER for superglobal access (some frameworks
    // read these instead of getenv()).
    putenv($key . '=' . $value);
    $_ENV[$key] = $value;
    $_SERVER[$key] = $value;
}
