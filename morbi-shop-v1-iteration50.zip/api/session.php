<?php
/**
 * session.php — GET → current auth state. Used by the frontend at boot and
 * by the dashboard before rendering the admin UI.
 *
 * ★ Phase 8 Batch 2 (Task 59): the response now includes `role` so the
 * frontend can hide role-gated UI (the Admins tab is only shown to
 * super_admin). The frontend treats this as informational only — every
 * privileged API call enforces the role check server-side via
 * require_role(). If a non-super_admin tampers with the JS to show the
 * Admins tab, the API calls it makes will return 403.
 */

require __DIR__ . '/_bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    json_err('GET only.', 405);
}

// require_admin() lazy-loads the role into the session if missing. Calling
// it here (instead of just is_admin()) ensures the role is always populated
// for authenticated admins, even if they were logged in before this batch
// landed and never re-logged-in.
if (is_admin()) {
    require_admin();
}

json_ok([
    'authenticated' => is_admin(),
    'username'      => is_admin() ? $_SESSION['admin_username'] : null,
    // ★ Phase 8 Batch 2: include the role. Default to 'super_admin' if for
    // some reason the session is missing it (defensive — require_admin()
    // above ensures it's set, but belt-and-braces).
    'role'          => is_admin() ? current_admin_role() : null,
]);
