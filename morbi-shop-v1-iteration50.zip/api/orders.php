<?php
/**
 * orders.php — Phase 2 (Bicycle) order lookup.
 *
 *   GET  ?reference=XYZ  public  -> the order's public status (no PII beyond
 *                                   what the customer themselves provided).
 *   GET  ?action=verify&reference=XYZ  public  -> server-side verify-on-demand
 *                                   (called by the payment-callback route).
 *                                   Calls Paystack /transaction/verify and
 *                                   updates the order row, then returns the
 *                                   final status. Mirrors what the webhook does.
 *   GET  admin  (no query)        -> list all orders (admin only).
 *   GET  admin  ?id=N             -> one order with its items (admin only).
 *   DELETE  admin  ?id=N          -> soft-delete (sets status='deleted'; FK
 *                                   ON DELETE CASCADE on order_items means
 *                                   hard delete loses the items — we soft-delete
 *                                   by marking status='deleted' instead so the
 *                                   audit trail survives).
 *
 * The public paths (reference + verify) return only what the customer needs
 * to see on the callback page: status, total, items snapshot, paystack_channel.
 * Admin paths return the full row including customer PII.
 */

require __DIR__ . '/_bootstrap.php';
require_once __DIR__ . '/_paystack.php';

switch ($_SERVER['REQUEST_METHOD']) {
    case 'GET':    handle_get();   break;
    case 'DELETE': require_admin(); verify_csrf(); handle_delete(); break;
    default:       json_err('Method not allowed.', 405);
}

/* ---- GET router ---------------------------------------------------------- */
function handle_get(): void {
    $reference = (string)($_GET['reference'] ?? '');
    $action    = (string)($_GET['action'] ?? '');
    $id        = (int)($_GET['id'] ?? 0);

    // Public: verify-on-demand (called by payment-callback route).
    if ($action === 'verify' && $reference !== '') {
        verify_and_return($reference);
        return;
    }

    // Public: status lookup by reference (no PII beyond what the customer
    // provided at checkout — same data they'd see on the callback page).
    if ($reference !== '') {
        $order = fetch_order_by_reference($reference);
        if (!$order) json_err('Order not found.', 404);
        json_ok(['order' => map_order_public($order, fetch_items($order['id']))]);
    }

    // Admin: list or single.
    if (!is_admin()) json_err('Authentication required.', 401);
    if ($id > 0) {
        $order = fetch_order_by_id($id);
        if (!$order) json_err('Order not found.', 404);
        json_ok(['order' => map_order_admin($order, fetch_items($id))]);
        return;
    }
    handle_admin_list();
}

/* ---- Public: verify-on-demand ------------------------------------------- */
/* ★ SEC-06 fix: rate-limit the public verify path. Was: no rate limit —
 *   an attacker could spam ?action=verify&reference=morbi-{guess} to (a)
 *   enumerate which references resolve (404 vs 200), (b) exhaust Paystack
 *   API quota, (c) cost the merchant money. Fix: 10 requests/minute/IP.
 *   The rate limiter is placed BEFORE the DB lookup so even 404 responses
 *   (invalid reference enumeration) are rate-limited.
 * ★ SEC-05 fix: the verify path was a GET that performed DB writes +
 *   outbound Paystack API calls. Because SameSite=Lax allows top-level
 *   GET navigations, any malicious page could issue
 *   <img src="...?action=verify&reference=..."> to trigger UPDATE orders +
 *   stock decrement + discount release + a Paystack verify call — all
 *   with the victim's cookie. Fix: make the GET path READ-ONLY. Return
 *   the current order status WITHOUT calling paystack_verify() and
 *   WITHOUT any DB writes. The actual verify (Paystack API call + DB
 *   writes) is handled by the webhook (POST from Paystack — not
 *   exploitable via <img src=...>). The customer's callback page polls
 *   this read-only endpoint + auto-refreshes after 5 seconds — by then
 *   the webhook has typically fired + the status is 'paid'.
 *
 *   If the webhook is delayed (Paystack retries at 5min/30min/2h/12h),
 *   the customer sees "Payment Confirming…" until the webhook catches
 *   up. This is a deliberate tradeoff: SEC-05 (CSRF via GET) is High
 *   severity; the defense-in-depth verify-on-GET was a nice-to-have
 *   fallback that the webhook's retry schedule already covers.
 */
function verify_and_return(string $reference): void {
    // ★ SEC-06: rate limit BEFORE the DB lookup (prevents 404/200 enumeration).
    rate_limit_check('orders_verify:' . client_ip(), 10, 60);

    $order = fetch_order_by_reference($reference);
    if (!$order) json_err('Order not found.', 404);

    // ★ SEC-05: READ-ONLY status check. Was: called paystack_verify()
    //   (outbound HTTPS) + executed UPDATE orders + stock decrement +
    //   discount release inside a transaction. Now: just return the
    //   current status. The webhook handles the actual verify + DB writes.
    //   The BL-15 fix's idempotency check (paid/deleted short-circuit)
    //   is now implicit — ALL statuses are returned read-only, including
    //   'paid' and 'deleted'.
    json_ok(['order' => map_order_public($order, fetch_items($order['id'])), 'verified' => false]);
}

/* ---- Admin: list --------------------------------------------------------- */
function handle_admin_list(): void {
    // Optional filters: ?status=paid, ?limit=50, ?offset=0
    $status = (string)($_GET['status'] ?? '');
    // ★ RT-13 fix: was `$limit = min((int)($_GET['limit'] ?? 50), 200)` —
    //   capped at 200 but NOT floored at 1. A request like `?limit=-5` cast
    //   to -5, `min(-5, 200) = -5`, and the SQL became
    //   `... LIMIT -5 OFFSET 0` — MySQL rejected it with a syntax error,
    //   throwing an uncaught PDOException → 500 with HTML stack trace.
    //   Fix: floor at 1 with `max(1, ...)`. The `max(1, min(N, 200))`
    //   pattern clamps to the range [1, 200] — valid for MySQL's LIMIT clause.
    $limit  = max(1, min((int)($_GET['limit'] ?? 50), 200));   // range [1, 200]
    $offset = max((int)($_GET['offset'] ?? 0), 0);

    $sql = 'SELECT * FROM orders';
    $params = [];
    // ★ Phase 8 Batch 1 (Task 58): the orders list now also accepts
    //   partially_refunded + refunded as status filters (in addition to
    //   the original pending/paid/failed/abandoned/deleted). These were
    //   always possible paystack_status values once the refund flow landed
    //   but couldn't be filtered until now.
    $validStatuses = ['pending', 'paid', 'failed', 'abandoned', 'deleted',
                      'partially_refunded', 'refunded'];
    if (in_array($status, $validStatuses, true)) {
        $sql .= ' WHERE paystack_status = ?';
        $params[] = $status;
    }
    $sql .= ' ORDER BY created_at DESC, id DESC LIMIT ' . $limit . ' OFFSET ' . $offset;

    $stmt = db()->prepare($sql);
    $stmt->execute($params);
    $rows = $stmt->fetchAll();

    // ★ WF-15 fix: the response used to report `count => count($orders)` —
    //   the number of rows ON THIS PAGE (max = limit) — and nothing else.
    //   The dashboard's summary therefore read "Showing 50 of 50 orders."
    //   while the Analytics tab's total_orders said 73, and with no true
    //   total the Orders tab could never page past the first 50 rows.
    //   Fix: run a COUNT(*) with the SAME status filter to get the true
    //   total, returned as `total`. `count` (page rows) is kept for
    //   backward compatibility with the already-shipped dashboard code
    //   (UX-05's pagination reads it as a fallback).
    $statusValid = in_array($status, $validStatuses, true);
    $countStmt = db()->prepare(
        'SELECT COUNT(*) FROM orders' . ($statusValid ? ' WHERE paystack_status = ?' : '')
    );
    $countStmt->execute($statusValid ? [$status] : []);
    $total = (int)$countStmt->fetchColumn();

    // Lighter payload for the list view — items are fetched on detail view.
    $orders = array_map(function ($r) {
        return [
            'id'              => (int)$r['id'],
            'reference'       => $r['reference'],
            'customer_name'   => $r['customer_name'],
            'customer_phone'  => $r['customer_phone'],
            'total_amount'    => (float)$r['total_amount'],
            // ★ Phase 8 Batch 1 (Task 58): expose refunded_amount in list
            //   view so the dashboard Orders list can show "GHS X / Y refunded"
            //   badge without a per-order detail fetch.
            'refunded_amount' => isset($r['refunded_amount']) ? (float)$r['refunded_amount'] : 0.0,
            'currency'        => $r['currency'],
            'paystack_status' => $r['paystack_status'],
            'paystack_channel'=> $r['paystack_channel'],
            'created_at'      => $r['created_at'],
            'paystack_paid_at'=> $r['paystack_paid_at'],
        ];
    }, $rows);

    json_ok(['orders' => $orders, 'count' => count($orders), 'total' => $total, 'limit' => $limit, 'offset' => $offset]);
}

/* ---- Admin: soft-delete (mark status='deleted') ------------------------- */
function handle_delete(): void {
    $id = (int)($_GET['id'] ?? 0);
    if ($id <= 0) json_err('Order id is required.', 422);

    $stmt = db()->prepare('UPDATE orders SET paystack_status = ? WHERE id = ?');
    $stmt->execute(['deleted', $id]);
    // ★ Blind-spot fix (audit): rowCount()=0 means "no change" not "not found".
    //   If the order is already 'deleted', the UPDATE matches but doesn't change
    //   → rowCount()=0 → misleading "Order not found" error. Now: fetch first.
    if ($stmt->rowCount() === 0) {
        $check = db()->prepare('SELECT id FROM orders WHERE id = ? LIMIT 1');
        $check->execute([$id]);
        if (!$check->fetch()) json_err('Order not found.', 404);
        json_err('Order is already deleted.', 409);
    }

    json_ok(['deleted' => $id]);
}

/* ---- Helpers -------------------------------------------------------------- */
function fetch_order_by_reference(string $reference): ?array {
    $stmt = db()->prepare('SELECT * FROM orders WHERE reference = ? LIMIT 1');
    $stmt->execute([$reference]);
    $row = $stmt->fetch();
    return $row ?: null;
}

function fetch_order_by_id(int $id): ?array {
    $stmt = db()->prepare('SELECT * FROM orders WHERE id = ? LIMIT 1');
    $stmt->execute([$id]);
    $row = $stmt->fetch();
    return $row ?: null;
}

function fetch_items(int $orderId): array {
    $stmt = db()->prepare('SELECT * FROM order_items WHERE order_id = ? ORDER BY id ASC');
    $stmt->execute([$orderId]);
    return $stmt->fetchAll();
}

/** Public shape — no email, no paystack_fees (those are admin-only). */
function map_order_public(array $r, array $items): array {
    return [
        'reference'       => $r['reference'],
        'customer_name'   => $r['customer_name'],
        'total_amount'    => (float)$r['total_amount'],
        'currency'        => $r['currency'],
        'paystack_status' => $r['paystack_status'],
        'paystack_channel'=> $r['paystack_channel'],
        'created_at'      => $r['created_at'],
        'paystack_paid_at'=> $r['paystack_paid_at'],
        'items'           => array_map('map_item', $items),
    ];
}

/** Admin shape — includes email, fees, full PII. */
function map_order_admin(array $r, array $items): array {
    return [
        'id'               => (int)$r['id'],
        'reference'        => $r['reference'],
        'customer_name'    => $r['customer_name'],
        'customer_phone'   => $r['customer_phone'],
        'customer_email'   => (string)($r['customer_email'] ?? ''),
        'total_amount'     => (float)$r['total_amount'],
        // ★ Phase 8 Batch 1 (Task 58): refunded_amount + partially_refunded/refunded
        //   status values. Existing paid orders report refunded_amount=0.00
        //   (column added idempotently by install.php with DEFAULT 0.00).
        'refunded_amount'  => isset($r['refunded_amount']) ? (float)$r['refunded_amount'] : 0.0,
        'currency'         => $r['currency'],
        'paystack_status'  => $r['paystack_status'],
        'paystack_channel' => $r['paystack_channel'],
        'paystack_fees'    => $r['paystack_fees'] !== null ? (float)$r['paystack_fees'] : null,
        'created_at'       => $r['created_at'],
        'paystack_paid_at' => $r['paystack_paid_at'],
        'items'            => array_map('map_item', $items),
    ];
}

function map_item(array $r): array {
    // ★ Migration 2026-09-26: order_items schema columns are `product_name`,
    //   `variant_name`, `unit_price`, `quantity` (no `scent` column — that
    //   lives on the `products` table). Aliased here so the JS consumers
    //   (dashboard.js order detail, payment-callback.js) keep reading
    //   `name`/`scent`/`price`/`qty` unchanged. `variant_name` is mapped to
    //   the `scent` field for backward compat (the payment-callback page
    //   shows it as a sub-label under the product name, same as the old
    //   `scent` field was used).
    return [
        'product_id' => ($r['product_id'] !== null) ? (int)$r['product_id'] : null,
        // ★ BL-01 fix: expose variant_id in both the public and admin item
        // shapes so the payment-callback page + dashboard order detail can
        // show "you bought variant X" without parsing the snapshot-name
        // suffix. NULL when the product had no variants (the order was for
        // the parent product directly). Not PII — same visibility level as
        // product_id.
        'variant_id' => ($r['variant_id'] !== null) ? (int)$r['variant_id'] : null,
        'name'       => (string)($r['product_name'] ?? ''),
        'scent'      => (string)($r['variant_name'] ?? ''),
        'price'      => (float)($r['unit_price'] ?? 0),
        'qty'        => (int)($r['quantity'] ?? 0),
        'image_path' => (string)($r['image_path'] ?? ''),
    ];
}
