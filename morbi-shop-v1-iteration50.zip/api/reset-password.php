<?php
/**
 * reset-password.php — Phase 3 (Motorcycle) Batch 3 password recovery consumer.
 *
 *   POST  public { token, password }  -> { reset: true }
 *
 * Flow:
 *   1. Validate token format (64 hex chars — reject early on garbage to
 *      save a DB round-trip).
 *   2. Validate password strength (min 8 chars — mirrors the install.php
 *      seed password policy; ★ OTH-15 fix (iteration 25): the comment
 *      used to say "can be tightened in Phase 4 if the client wants
 *      stricter rules." Phase 4 is delivered and did NOT tighten the
 *      rules — 8 chars remains the policy. If the client ever wants
 *      stricter rules (mixed case + digit + symbol, ≥12 chars, etc.),
 *      add them as a Phase 6 (Super Car) deliverable with explicit
 *      approval — and document the change in install.php's seed password
 *      docstring too so the install-time password matches the reset-time
 *      policy.)
 *   3. Hash the incoming token with SHA-256 (same as forgot-password.php
 *      does on storage). Look up the hash in password_resets.
 *   4. Validate: token exists, not expired, not already used.
 *   5. Look up the admin_user via admin_user_id FK.
 *   6. In ONE transaction:
 *        a. UPDATE admin_users SET password_hash = ? WHERE id = ?
 *        b. UPDATE password_resets SET used_at = NOW() WHERE id = ?
 *           (mark THIS token as consumed — single-use)
 *        c. UPDATE password_resets SET used_at = NOW() WHERE admin_user_id = ?
 *           AND used_at IS NULL
 *           (nuke ALL OTHER unused tokens for this user — defense in depth:
 *           if one was used, others shouldn't work either)
 *   7. Return { reset: true } on success.
 *
 * Security:
 *   * No auth guard — public endpoint (the user is UN-authenticated; they
 *     just clicked a link from their email).
 *   * CSRF exempt (pre-auth, same as login.php + forgot-password.php).
 *   * NOT rate-limited (the token itself is the rate limiter — 256 bits of
 *     entropy means brute-force is infeasible, and a wrong token returns
 *     422 without side effects).
 *   * Token format validation BEFORE DB lookup — cheap reject for garbage.
 *   * Token hash lookup, not plaintext — matches the storage pattern.
 *   * Single-use + nuke-all-others on success — prevents token replay.
 *   * Password hashed with password_hash() + PASSWORD_DEFAULT (bcrypt by
 *     default in PHP 8.x) — same as install.php + login.php.
 *   * No user enumeration: identical 422 message + timing for "token not
 *     found", "token expired", "token already used".
 */

require __DIR__ . '/_bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_err('POST only.', 405);
}

$b = json_body();
if (!$b) json_err('Empty or malformed JSON body.', 422);

/* ---- 1. Validate token format ----------------------------------------- */
$token = trim((string)($b['token'] ?? ''));
// 64 hex chars (32 bytes hex-encoded) — matches forgot-password.php's output.
if (!preg_match('/^[0-9a-f]{64}$/', $token)) {
    json_err('Invalid or expired reset token.', 422);
}

/* ---- 2. Validate password strength ------------------------------------ */
$password = (string)($b['password'] ?? '');
if (mb_strlen($password) < 8) {
    json_err('Password must be at least 8 characters.', 422);
}
if (mb_strlen($password) > 1000) {
    json_err('Password is too long (max 1000 characters).', 422);
}

/* ---- 3-4. Look up the token hash + validate state --------------------- */
/* ★ SEC-17 fix: was `WHERE token_hash = ?` — B-tree byte-compare is not
 *   constant-time. The difference is sub-microsecond and dwarfed by network
 *   jitter, but in principle an attacker with low-jitter access could time
 *   thousands of requests to recover the hash byte-by-byte.
 *   Fix: fetch by hash PREFIX (first 16 hex chars = 8 bytes = first 8 chars
 *   of the SHA-256 hex). This narrows the result set to at most a few rows
 *   (statistically almost always 1 row — 8 bytes of hash prefix = 2^64
 *   possible values). Then use `hash_equals()` in PHP for a constant-time
 *   comparison of the full 64-char hash. The `hash_equals()` call is the
 *   defense-in-depth: even if the SQL prefix lookup leaks timing, the
 *   final comparison is constant-time.
 *   The prefix length (16 hex = 8 bytes) is a deliberate tradeoff: short
 *   enough that the SQL index is efficient, long enough that the prefix
 *   collision probability is negligible (2^64 address space).
 */
$tokenHash = hash('sha256', $token);
$hashPrefix = substr($tokenHash, 0, 16);  // first 16 hex chars (8 bytes)

$stmt = db()->prepare(
    'SELECT id, admin_user_id, token_hash, expires_at, used_at
     FROM password_resets
     WHERE token_hash LIKE ?
     LIMIT 10'
);
$stmt->execute([$hashPrefix . '%']);
$rows = $stmt->fetchAll();

// Constant-time comparison in PHP (defense-in-depth per SEC-17).
$row = null;
foreach ($rows as $r) {
    if (hash_equals($r['token_hash'], $tokenHash)) {
        $row = $r;
        break;
    }
}

if (!$row) {
    // Token not found — same message as expired/used (no information leak).
    json_err('Invalid or expired reset token.', 422);
}

$now = time();
$expires = strtotime((string)$row['expires_at']);
if ($expires === false || $expires < $now) {
    json_err('Invalid or expired reset token.', 422);
}
if ($row['used_at'] !== null) {
    json_err('Invalid or expired reset token.', 422);
}

/* ---- 5. Look up the admin user ---------------------------------------- */
$adminId = (int)$row['admin_user_id'];
$stmt = db()->prepare('SELECT id FROM admin_users WHERE id = ? LIMIT 1');
$stmt->execute([$adminId]);
$admin = $stmt->fetch();
if (!$admin) {
    // FK ON DELETE CASCADE should prevent this, but defense in depth.
    json_err('Invalid or expired reset token.', 422);
}

/* ---- 6. Update password + consume token + nuke others (transactional) -- */
$newHash = password_hash($password, PASSWORD_DEFAULT);
$pdo = db();
$pdo->beginTransaction();
try {
    // 6a. Update the admin's password.
    // ★ SEC-13 fix: also set password_changed_at = NOW() so that any
    //   other active sessions (stolen cookie, another device) are
    //   invalidated by require_admin()'s session-age check.
    $stmt = $pdo->prepare('UPDATE admin_users SET password_hash = ?, password_changed_at = CURRENT_TIMESTAMP WHERE id = ?');
    $stmt->execute([$newHash, $adminId]);

    // 6b. Mark THIS token as used (single-use).
    $stmt = $pdo->prepare('UPDATE password_resets SET used_at = CURRENT_TIMESTAMP WHERE id = ? AND used_at IS NULL');
    $stmt->execute([(int)$row['id']]);

    // 6c. Nuke ALL OTHER unused tokens for this user (defense in depth).
    $stmt = $pdo->prepare(
        'UPDATE password_resets
         SET used_at = CURRENT_TIMESTAMP
         WHERE admin_user_id = ? AND used_at IS NULL AND id != ?'
    );
    $stmt->execute([$adminId, (int)$row['id']]);

    $pdo->commit();
} catch (Exception $e) {
    $pdo->rollBack();
    error_log('[morbi] reset-password transaction failed: ' . $e->getMessage());
    json_err('Could not update password. Please try again or request a new reset link.', 500);
}

/* ---- 7. Return success ------------------------------------------------ */
json_ok(['reset' => true]);
