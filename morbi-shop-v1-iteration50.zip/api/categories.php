<?php
/**
 * categories.php — public GET + admin CRUD.
 *
 * GET    public                -> { categories: [...] } sorted by sort_order
 * POST   admin {name, description?, sortOrder?}
 * PUT    admin {id, ...patch}  — changing the name regenerates the slug
 * DELETE admin {id} or ?id=    — products in it become uncategorized
 *                                (FK ON DELETE SET NULL, mirrors old behavior)
 */

require __DIR__ . '/_bootstrap.php';

switch ($_SERVER['REQUEST_METHOD']) {
    case 'GET':    handle_get();      break;
    case 'POST':   require_admin(); verify_csrf(); handle_create();   break;
    case 'PUT':    require_admin(); verify_csrf(); handle_update();   break;
    case 'DELETE': require_admin(); verify_csrf(); handle_delete();   break;
    default:       json_err('Method not allowed.', 405);
}

/* ---- GET ------------------------------------------------------------------ */
function handle_get(): void {
    $rows = db()->query('SELECT * FROM categories ORDER BY sort_order ASC, id ASC')->fetchAll();
    json_ok(['categories' => array_map('map_category', $rows)]);
}

/* ---- POST ------------------------------------------------------------------ */
function handle_create(): void {
    $b = json_body();
    if (!array_key_exists('name', $b)) json_err('Name is required (min 2 characters, max 100).', 422);

    $v = validate_category($b);
    if ($v['error'] !== null) json_err($v['error'], 422);

    // Default sort order = end of the list (mirrors old addCategory).
    if ($v['sort_order'] === null) {
        $v['sort_order'] = (int)db()->query('SELECT COALESCE(MAX(sort_order), -1) + 1 FROM categories')->fetchColumn();
    }

    $stmt = db()->prepare('INSERT INTO categories (name, slug, description, sort_order) VALUES (?, ?, ?, ?)');
    $stmt->execute([$v['name'], slugify_server($v['name']), $v['description'], $v['sort_order']]);

    $row = fetch_category((int)db()->lastInsertId());
    json_ok(map_category($row), 201);
}

/* ---- PUT ------------------------------------------------------------------ */
function handle_update(): void {
    $b = json_body();
    $id = (int)($b['id'] ?? 0);
    if ($id <= 0) json_err('Category id is required.', 422);
    $existing = fetch_category($id);
    if (!$existing) json_err('Category not found.', 404);

    $v = validate_category($b);
    if ($v['error'] !== null) json_err($v['error'], 422);

    $name = $v['name'] ?? $existing['name'];
    // Mirrors old updateCategory: a new name regenerates the slug.
    $slug = array_key_exists('name', $b) ? slugify_server($name) : $existing['slug'];
    $description = $v['description'] !== null ? $v['description'] : $existing['description'];
    $sortOrder = $v['sort_order'] !== null ? $v['sort_order'] : (int)$existing['sort_order'];

    $stmt = db()->prepare('UPDATE categories SET name = ?, slug = ?, description = ?, sort_order = ? WHERE id = ?');
    $stmt->execute([$name, $slug, $description, $sortOrder, $id]);

    json_ok(map_category(fetch_category($id)));
}

/* ---- DELETE ------------------------------------------------------------------ */
function handle_delete(): void {
    $b = json_body();
    $id = (int)($b['id'] ?? ($_GET['id'] ?? 0));
    if ($id <= 0) json_err('Category id is required.', 422);

    $stmt = db()->prepare('DELETE FROM categories WHERE id = ?');
    $stmt->execute([$id]);
    if ($stmt->rowCount() === 0) json_err('Category not found.', 404);

    json_ok(['deleted' => $id]);
}

/* ---- Helpers ------------------------------------------------------------------ */
function fetch_category(int $id): ?array {
    $stmt = db()->prepare('SELECT * FROM categories WHERE id = ? LIMIT 1');
    $stmt->execute([$id]);
    $row = $stmt->fetch();
    return $row ?: null;
}

function validate_category(array $b): array {
    $out = ['name' => null, 'description' => null, 'sort_order' => null, 'error' => null];

    if (array_key_exists('name', $b)) {
        $name = trim((string)$b['name']);
        $len = mb_strlen($name);
        if ($len < 2 || $len > 100) { $out['error'] = 'Name is required (min 2 characters, max 100).'; return $out; }
        $out['name'] = $name;
    }

    if (array_key_exists('description', $b)) {
        $desc = trim((string)$b['description']);
        if (mb_strlen($desc) > 200) { $out['error'] = 'Description is too long (max 200 characters).'; return $out; }
        $out['description'] = $desc;
    }

    if (array_key_exists('sortOrder', $b)) {
        if ($b['sortOrder'] === null || $b['sortOrder'] === '') {
            $out['sort_order'] = null;
        } else {
            $sort = filter_var($b['sortOrder'], FILTER_VALIDATE_INT);
            if ($sort === false || $sort < 0) { $out['error'] = 'Valid sort order required (0 or greater).'; return $out; }
            $out['sort_order'] = $sort;
        }
    }

    return $out;
}

function map_category(array $r): array {
    return [
        'id'          => (int)$r['id'],
        'name'        => $r['name'],
        'slug'        => $r['slug'],
        'description' => (string)($r['description'] ?? ''),
        'sortOrder'   => (int)$r['sort_order'],
    ];
}
