import * as THREE from 'three';
import { PLAYER } from './config.js';

/**
 * car-factory.js — turns raw glTF scenes into uniform, game-ready cars.
 *
 * Handles the asset quirks found in the audit:
 *  - Sketchfab export cruft nodes (empty transforms like "sceneGroundPlane")
 *  - Inconsistent facing (length along X vs Z)
 *  - Wildly different scales (2.9k–15k tris, arbitrary export units)
 *  - Missing separate wheels (police car & Hyper GT are single welded meshes)
 *
 * KISS note: plain functions + plain objects. No class hierarchy — cars
 * differ only by data, so inheritance would add ceremony, not clarity.
 */

const WHEEL_NAME_RE = /wheel/i;

/** glTF assets natively face +Z; the player drives toward -Z. */
export const BASE_YAW = Math.PI;

/** Recursively collect meshes that actually carry geometry. */
function geometryMeshes(root) {
    const meshes = [];
    root.traverse((obj) => {
        if (obj.isMesh && obj.geometry?.attributes?.position?.count > 0) {
            meshes.push(obj);
        }
    });
    return meshes;
}

/** Union bounding box of real geometry only (ignores empty cruft nodes). */
function unionBox(root, box = new THREE.Box3()) {
    box.makeEmpty();
    const tmp = new THREE.Box3();
    for (const mesh of geometryMeshes(root)) {
        mesh.updateWorldMatrix(true, false);
        tmp.setFromObject(mesh);
        box.union(tmp);
    }
    return box;
}

/** Spin-aware clones need their own wheel references (names survive cloning). */
function findWheels(root) {
    const wheels = [];
    root.traverse((obj) => {
        if (obj.isMesh && WHEEL_NAME_RE.test(obj.name || '')) wheels.push(obj);
    });
    return wheels;
}

/**
 * Normalize a template scene in place:
 *  1. rotate so the long axis lies on Z
 *  2. uniform-scale to target length
 *  3. center on X/Z and ground on Y (wheels touch y=0)
 * @returns {{scene: THREE.Group, halfW: number, halfL: number}}
 */
export function normalizeModel(scene, targetLength = PLAYER.carLength, targetWidth = PLAYER.carWidth) {
    const root = new THREE.Group();
    root.add(scene);
    scene.position.set(0, 0, 0);
    scene.rotation.set(0, 0, 0);
    scene.updateWorldMatrix(true, true);

    let box = unionBox(root);
    let size = box.getSize(new THREE.Vector3());

    // Blender/Sketchfab exports may face down X — rotate if so.
    if (size.x > size.z) {
        scene.rotation.y = Math.PI / 2;
        scene.updateWorldMatrix(true, true);
        box = unionBox(root);
        size = box.getSize(new THREE.Vector3());
    }

    const scale = targetLength / Math.max(size.z, 0.0001);
    root.scale.setScalar(scale);
    root.updateWorldMatrix(true, true);

    box = unionBox(root);
    const center = box.getCenter(new THREE.Vector3());
    size = box.getSize(new THREE.Vector3());

    scene.position.set(-center.x, -box.min.y, -center.z);
    root.updateWorldMatrix(true, true);

    // If normalization makes it fatter than the target width, the model was
    // too wide for its length — accept it but record honest half-extents.
    return {
        scene: root,
        halfW: Math.min(size.x, targetWidth * 1.25) / 2,
        halfL: size.z / 2,
    };
}

/**
 * Build one placeable car from a normalized template.
 * @returns {{root: THREE.Group, wheels: THREE.Mesh[], halfW: number, halfL: number}}
 */
export function createCar(normalized) {
    const root = normalized.scene.clone(true);
    return {
        root,
        wheels: findWheels(root),
        halfW: normalized.halfW,
        halfL: normalized.halfL,
    };
}

/** Spin wheels proportionally to distance traveled (no-op for welded meshes). */
export function spinWheels(car, distance) {
    for (const wheel of car.wheels) {
        wheel.rotation.x += distance * PLAYER.wheelSpinRate;
    }
}
