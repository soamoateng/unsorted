import * as THREE from 'three';
import { ASSETS, PICKER_CARS } from './config.js';
import { loadAssets, enhanceMaterials } from './assets.js';
import { createSceneKit } from './scene.js';
import { createRoad } from './road.js';
import { normalizeModel, createCar } from './car-factory.js';
import { createPlayer } from './player.js';
import { createTraffic } from './traffic.js';
import { createPolice } from './police.js';
import { createInput } from './input.js';
import { createAudio } from './audio.js';
import { createGame } from './game.js';
import * as ui from './ui.js';

/**
 * main.js — composition root. The ONLY module that knows how every piece
 * fits together (Dependency Inversion: game.js depends on the contracts of
 * its collaborators, not on how they were built).
 */

const host = document.getElementById('gameArea');

// The inline boot watchdog (index.html) hands messaging over to us from this
// statement on — it stays silent while we drive the progress UI.
if (window.__boot) window.__boot.tookOver = true;
/** Any exit from the boot phase (ready or fatal) must stand the watchdog down. */
const bootSettled = () => { if (window.__boot) window.__boot.ready = true; };

let sceneKit;
try {
    sceneKit = createSceneKit(host);
} catch (err) {
    ui.showFatal(`${err.message} Try a recent Chrome, Edge, Firefox or Safari.`);
    bootSettled();
    throw err;
}

let loaded = false;
let selectedId = PICKER_CARS[0].id;
let thumbnails = {};
let startUI = null; // assigned immediately (below) — the controller must exist
                    // DURING the asset load so premature start activation can be
                    // answered (UX-10). Updates during load go through the
                    // module-level ui.* DOM helpers, not this controller.

// ---------------------------------------------------------------------------
// 1. Load + normalize every model once.
// ---------------------------------------------------------------------------
ui.setScore(0, ui.loadHighScore());

// UX-10 blind-spot fix (proven during the iter8 regression): this registration
// used to sit BELOW the top-level `await loadAssets`, so for the entire load
// window handlers.start was null and a premature click was a silent no-op one
// layer beneath the `loaded` guard the audit cited. Registering the controller
// BEFORE the await means every premature activation now reaches the nudge.
// Load-order safety: the nudge branch never dereferences `game` (declared
// later), and picker cards cannot exist before renderPicker() runs post-load,
// so onSelect is unreachable until every actor below is initialized.
const startUIController = ui.initStartScreen(
    (id) => swapPlayerCar(id),
    () => {
        if (loaded) {
            game.startRace();
        } else {
            // UX-10: a premature activation must never be a silent no-op —
            // pulse the loading UI so the user can see the system heard them
            // (the prompt already carries the live percentage to look at).
            ui.nudgeLoading();
        }
    }
);
startUI = startUIController;

let normalized;
try {
    const raw = await loadAssets(ASSETS, (done, total, agg) => {
        // Module-level helpers — the start-screen controller does not exist
        // yet, and the old startUI?.setPrompt routing silently dropped every
        // update (the frozen "Loading cars…" bug).
        ui.setLoadingProgress(agg.fraction);
        ui.setPromptText(describeProgress(done, total, agg), false);
    });
    normalized = {};
    for (const [id, scene] of Object.entries(raw)) {
        enhanceMaterials(scene, sceneKit.maxAnisotropy);
        normalized[id] = normalizeModel(scene);
    }
} catch (err) {
    ui.showFatal('Failed to load the 3D models \u2014 check your connection, then hit Reload below.');
    bootSettled();
    throw err;
}

/** Human summary of the aggregate download state (MB are binary MiB). */
function describeProgress(done, total, agg) {
    const mb = (b) => (b / 1048576).toFixed(1);
    const files = ` (${done}/${total})`;
    if (agg.fraction >= 0) {
        return `Loading cars ${Math.round(agg.fraction * 100)}% \u2014 ${mb(agg.bytesLoaded)} / ${mb(agg.bytesTotal)} MB${files}\u2026`;
    }
    return `Loading cars ${mb(agg.bytesLoaded)} MB${files}\u2026`;
}

// ---------------------------------------------------------------------------
// 2. Build actors.
// ---------------------------------------------------------------------------
const road = createRoad(sceneKit.scene);
const input = createInput();

const pickerTemplates = (excludeId) =>
    PICKER_CARS.filter((c) => c.id !== excludeId).map((c) => normalized[c.id]);

let player = createPlayer(createCar(normalized[selectedId]));
sceneKit.scene.add(player.car.root);

const police = createPolice(sceneKit.scene, createCar(normalized.police));
police.attachToRoof();
sceneKit.scene.add(police.car.root);

const traffic = createTraffic(sceneKit.scene, pickerTemplates(selectedId));

// ---------------------------------------------------------------------------
// 3. Car picker + thumbnails (rendered once with the main renderer).
// ---------------------------------------------------------------------------
function makeThumbnails() {
    const thumbScene = new THREE.Scene();
    thumbScene.background = new THREE.Color(0x1a1f29);
    thumbScene.add(new THREE.HemisphereLight(0x8fa6c9, 0x1a1d24, 1.3));
    const lamp = new THREE.DirectionalLight(0xdfe9ff, 1.8);
    lamp.position.set(4, 6, 3);
    thumbScene.add(lamp);

    const cam = new THREE.PerspectiveCamera(34, 160 / 96, 0.1, 50);
    cam.position.set(4.4, 2.4, 6.2);
    cam.lookAt(0, 0.55, 0);

    const urls = {};
    for (const { id } of PICKER_CARS) {
        const car = createCar(normalized[id]);
        car.root.rotation.y = Math.PI / 5; // three-quarter view
        thumbScene.add(car.root);
        sceneKit.renderer.setSize(160, 96, false);
        sceneKit.renderer.render(thumbScene, cam);
        // Safe without preserveDrawingBuffer: toDataURL reads the buffer
        // synchronously in the same task as render(), before any composite
        // can clear it. Do NOT defer this call (e.g. into a promise/rAF).
        urls[id] = sceneKit.renderer.domElement.toDataURL();
        thumbScene.remove(car.root);
    }
    sceneKit.renderer.setSize(window.innerWidth, window.innerHeight);
    return urls;
}

function swapPlayerCar(id) {
    if (id === selectedId) return; // keyboard repeat / re-click: no pointless rebuild
    selectedId = id;
    sceneKit.scene.remove(player.car.root);
    player = createPlayer(createCar(normalized[id]));
    sceneKit.scene.add(player.car.root);
    game.setPlayer(player);
    traffic.rebuild(pickerTemplates(id));
    startUI?.select(id);
}

// ---------------------------------------------------------------------------
// 4. Game + boot.
// ---------------------------------------------------------------------------
const audio = createAudio(); // UX-06: synthesized cues + haptics; context unlocks on race start

const game = createGame({
    sceneKit,
    road,
    input,
    ui,
    police,
    audio,
    onMenuRestore() {
        ui.restoreStartScreen();
        startUI.renderPicker(thumbnails, selectedId);
        startUI.setPrompt('Pick a car, then click here to run', true);
    },
});

game.setPlayer(player);
game.setTraffic(traffic);

// UX-01/UX-07: on-screen pause button + pause overlay's Resume / Quit.
ui.initRunControls(
    () => game.pauseRace(),
    () => game.resumeRace(),
    () => game.quitToMenu(),
);

thumbnails = makeThumbnails();
loaded = true;
bootSettled(); // playable from here — the boot watchdog stands down
ui.hideLoadingBar();
startUI.renderPicker(thumbnails, selectedId);
startUI.setPrompt('Pick a car, then click here to run', true);

game.run();
