import * as THREE from 'three';
import { WORLD, TRAFFIC } from './config.js';
import { createCar, spinWheels } from './car-factory.js';
import { overlapsXZ } from './collision.js';

/**
 * traffic.js — pooled obstacle stream. Every car is cloned once at build
 * time and recycled forever: zero allocations per frame (the 2D original
 * re-created DOM nodes every run — that pattern is gone).
 *
 * Spawn rule keeps lanes solvable: a lane is blocked only if its nearest
 * car ahead is inside TRAFFIC.laneCooldownZ, so a wall of 4 can't exist.
 *
 * Recycle invariant (F-1 fix): spawnOne is the single point that fully
 * re-initializes per-spawn state (lane, z, speed, hit, flingVx, pose), so
 * nothing from a previous life — not even a residual knock-fling — leaks
 * into a respawned car.
 */
export function createTraffic(scene, templates) {
    const cars = [];
    const pool = [];

    for (let i = 0; i < TRAFFIC.poolSize; i++) {
        const template = templates[i % templates.length];
        const car = createCar(template);
        car.root.visible = false;
        car.root.traverse((obj) => {
            if (obj.isMesh) obj.castShadow = true;
        });
        scene.add(car.root);
        pool.push(car);
    }

    const state = {
        metersSinceSpawn: 0,
    };

    function laneBlocked(lane, z) {
        return cars.some(
            (c) => c.lane === lane && Math.abs(c.z - z) < TRAFFIC.laneCooldownZ
        );
    }

    function spawnOne() {
        const car = pool.shift();
        if (!car) return;

        // Prefer lanes whose corridor is clear; skip the spawn if none are.
        const freeLanes = [0, 1, 2, 3].filter((lane) => !laneBlocked(lane, WORLD.spawnAheadZ));
        if (freeLanes.length === 0) {
            pool.push(car);
            return;
        }
        const lane = freeLanes[(Math.random() * freeLanes.length) | 0];

        car.lane = lane;
        car.z = WORLD.spawnAheadZ - Math.random() * TRAFFIC.spawnJitterZ;
        car.ownSpeedFrac = TRAFFIC.ownSpeedMin + Math.random() * (TRAFFIC.ownSpeedMax - TRAFFIC.ownSpeedMin);
        car.hit = false;
        car.flingVx = 0; // F-1: a stale fling must never survive recycling
        car.root.visible = true;
        car.root.position.set(WORLD.laneX[lane], 0, car.z);
        car.root.rotation.set(0, Math.PI, 0); // face the player (traffic drives toward camera)
        cars.push(car);
    }

    /**
     * @param {number} dt
     * @param {number} playerSpeed effective forward speed this frame
     * @param {number} baseSpeed ramped base speed, for traffic's own cruise
     */
    function update(dt, playerSpeed, baseSpeed, metersDelta) {
        state.metersSinceSpawn += metersDelta;
        const spawnBudget = state.metersSinceSpawn >= TRAFFIC.spawnEveryMeters;
        if (spawnBudget) state.metersSinceSpawn = 0;

        for (let i = cars.length - 1; i >= 0; i--) {
            const car = cars[i];
            // Relative motion: player streams forward, traffic cruises ahead.
            car.z += (playerSpeed - car.ownSpeedFrac * baseSpeed) * dt;

            if (car.z > WORLD.despawnZ) {
                car.root.visible = false;
                cars.splice(i, 1);
                pool.push(car);
                continue;
            }
            car.root.position.z = car.z;

            // Knocked-car flourish after a crash (set by game.js). The damp
            // is the exact exponential form v *= e^(−flingDamp·dt) (N-6):
            // identical tuned feel, frame-rate independent by construction,
            // and it can never invert the velocity for a huge dt the way the
            // old linear-per-frame clamp could. The flingCutoff hard-stop is
            // still required: an exponential never reaches zero, so without
            // the cutoff the spin would decay forever.
            if (car.flingVx) {
                car.root.position.x += car.flingVx * dt;
                car.root.rotation.y += TRAFFIC.flingSpinRate * dt;
                const damped = car.flingVx * Math.exp(-dt * TRAFFIC.flingDamp);
                car.flingVx = Math.abs(damped) < TRAFFIC.flingCutoff ? 0 : damped;
            }

            spinWheels(car, car.ownSpeedFrac * baseSpeed * dt);
        }

        if (spawnBudget) spawnOne();
    }

    /** First active traffic car overlapping the player, if any. */
    function hitPlayer(playerX, playerZ, playerHalfW, playerHalfL) {
        for (const car of cars) {
            if (car.hit) continue;
            if (overlapsXZ(playerX, playerZ, playerHalfW, playerHalfL, car.root.position.x, car.z, car.halfW, car.halfL)) {
                return car;
            }
        }
        return null;
    }

    function reset() {
        for (const car of cars) {
            car.flingVx = 0; // F-1 (belt & braces): reset() must not pool a stale flourish either
            car.root.visible = false;
            pool.push(car);
        }
        cars.length = 0;
        state.metersSinceSpawn = 0;
    }

    /** Rebuild the pool from the templates matching the current player pick
     *  (traffic = every model except the one you drive). */
    function rebuild(templates) {
        for (const car of cars) {
            scene.remove(car.root);
            pool.push(car);
        }
        cars.length = 0;
        for (const car of pool) scene.remove(car.root);
        pool.length = 0;
        state.metersSinceSpawn = 0;

        for (let i = 0; i < TRAFFIC.poolSize; i++) {
            const car = createCar(templates[i % templates.length]);
            car.root.visible = false;
            car.root.traverse((obj) => {
                if (obj.isMesh) obj.castShadow = true;
            });
            scene.add(car.root);
            pool.push(car);
        }
    }

    return { update, hitPlayer, reset, rebuild, activeCount: () => cars.length };
}
