import { TRAFFIC } from './config.js';

/**
 * collision.js — pure geometry helpers. No DOM, no three.js, no state:
 * trivially testable and shared by every collision check (DRY replacement
 * for the 2D original's isCollide(), whose implicit globals are gone).
 */

/** Axis-aligned overlap test on the XZ plane with a fairness shrink factor. */
export function overlapsXZ(ax, az, aHalfW, aHalfL, bx, bz, bHalfW, bHalfL, forgiveness = TRAFFIC.forgiveness) {
    return (
        Math.abs(ax - bx) < (aHalfW + bHalfW) * forgiveness &&
        Math.abs(az - bz) < (aHalfL + bHalfL) * forgiveness
    );
}
