import * as THREE from 'three';
import { WORLD, CAMERA, COLORS } from './config.js';

/**
 * scene.js — single responsibility: renderer + scene + lights + the chase
 * camera rig. Owns nothing about gameplay.
 *
 * Uses THREE.Timer (the r183+ replacement for the deprecated THREE.Clock);
 * its Page Visibility integration already suppresses the huge deltas that
 * happen when the tab is backgrounded.
 */

export function createSceneKit(domHost) {
    let renderer;
    try {
        renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
    } catch (err) {
        throw new Error('WebGL is not available in this browser.', { cause: err });
    }
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFShadowMap; // PCFSoftShadowMap was removed in recent three versions
    renderer.outputColorSpace = THREE.SRGBColorSpace; // default in modern three, explicit for clarity
    domHost.appendChild(renderer.domElement);

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(COLORS.background);
    scene.fog = new THREE.Fog(COLORS.fog, WORLD.fogNear, WORLD.fogFar);

    const camera = new THREE.PerspectiveCamera(
        CAMERA.fov,
        window.innerWidth / window.innerHeight,
        0.1,
        400
    );
    camera.position.set(...CAMERA.position);

    // --- Lights -----------------------------------------------------------
    const hemi = new THREE.HemisphereLight(COLORS.hemiSky, COLORS.hemiGround, 1.15);
    scene.add(hemi);

    const sun = new THREE.DirectionalLight(COLORS.sun, 1.6);
    sun.position.set(12, 22, 10);
    sun.castShadow = true;
    sun.shadow.mapSize.set(1024, 1024);
    // Shadow frustum covers the play corridor near the player; fog hides far traffic.
    sun.shadow.camera.left = -22;
    sun.shadow.camera.right = 22;
    sun.shadow.camera.top = 30;
    sun.shadow.camera.bottom = -55;
    sun.shadow.camera.near = 1;
    sun.shadow.camera.far = 90;
    sun.shadow.bias = -0.0005;
    scene.add(sun);
    scene.add(sun.target);

    // --- Chase camera rig -------------------------------------------------
    const lookTarget = new THREE.Vector3(...CAMERA.lookAt);
    let swayT = 0;

    function updateChase(playerX, dt, drift = 0) {
        swayT += dt;
        const targetX = playerX * CAMERA.lateralFollow + Math.sin(swayT * 0.6) * drift;
        camera.position.x += (targetX - camera.position.x) * Math.min(1, dt * 5);
        camera.lookAt(lookTarget);
    }

    // --- Delta timer (modern API; Clock is deprecated since r183) ----------
    const timer = new THREE.Timer();
    timer.connect(document);

    // --- Context-loss UX (three.js already preventDefaults the event and
    // re-creates GL state on restore; we only surface the outage) ----------
    const glLostEl = document.getElementById('glLost');
    renderer.domElement.addEventListener('webglcontextlost', () => {
        glLostEl?.classList.remove('hide');
    });
    renderer.domElement.addEventListener('webglcontextrestored', () => {
        glLostEl?.classList.add('hide');
    });

    // --- Resize -----------------------------------------------------------
    function resize() {
        const w = window.innerWidth;
        const h = window.innerHeight;
        camera.aspect = w / h;
        camera.updateProjectionMatrix();
        renderer.setSize(w, h);
    }
    window.addEventListener('resize', resize);

    return {
        renderer,
        scene,
        camera,
        timer,
        updateChase,
        maxAnisotropy: renderer.capabilities.getMaxAnisotropy(),
        dispose() {
            timer.disconnect();
            window.removeEventListener('resize', resize);
            renderer.dispose();
            renderer.domElement.remove();
        },
    };
}
