import { STORAGE_KEY, PICKER_CARS } from './config.js';

/**
 * ui.js — every DOM touch lives here. Game modules never query the DOM
 * (separation the 2D original ignored by mixing rendering into gamePlay()).
 *
 * Robustness detail: the BUSTED panel REPLACES the start-screen markup via
 * innerHTML, which would orphan any listeners attached to inner nodes. All
 * panel clicks are therefore handled with event delegation on the panel
 * itself, which survives any number of innerHTML swaps.
 */

const startScreenEl = document.querySelector('.startScreen');
const pauseOverlayEl = document.getElementById('pauseOverlay');
const glLostEl = document.getElementById('glLost');

/** Capture the pristine start-screen markup once, so the menu can be
 *  restored without duplicating the template anywhere. */
const START_SCREEN_TEMPLATE = startScreenEl.innerHTML;

const handlers = { start: null, restart: null, menu: null, resume: null, quit: null };

/** UX-13: the reload action exists in two overlays (fatal panel, GL-lost
 *  banner) — one shared implementation keeps them from drifting. */
function activateReload() {
    location.reload();
}

startScreenEl.addEventListener('click', (e) => {
    if (e.target.closest('#startPrompt')) handlers.start?.();
    else if (e.target.closest('#restartPrompt')) handlers.restart?.();
    else if (e.target.closest('#menuPrompt')) handlers.menu?.();
    else if (e.target.closest('#reloadPrompt')) activateReload();
});

/** Prompts are keyboard-focusable buttons: Enter/Space activate them. */
startScreenEl.addEventListener('keydown', (e) => {
    if (e.key !== 'Enter' && e.key !== ' ') return;
    const target = e.target.closest('#startPrompt, #restartPrompt, #menuPrompt, #reloadPrompt');
    if (!target) return;
    e.preventDefault(); // Space must not scroll the panel
    if (target.id === 'startPrompt') handlers.start?.();
    else if (target.id === 'restartPrompt') handlers.restart?.();
    else if (target.id === 'reloadPrompt') activateReload();
    else handlers.menu?.();
});

// --- Pause overlay (UX-01/UX-07) -------------------------------------------
// The overlay lives OUTSIDE .startScreen (it must survive the BUSTED panel's
// innerHTML swaps and never appear behind the menu), so it carries its own
// event-delegation pair — same pattern, same survival guarantees.
pauseOverlayEl.addEventListener('click', (e) => {
    if (e.target.closest('#resumePrompt')) handlers.resume?.();
    else if (e.target.closest('#quitPrompt')) handlers.quit?.();
});

pauseOverlayEl.addEventListener('keydown', (e) => {
    if (e.key !== 'Enter' && e.key !== ' ') return;
    const target = e.target.closest('#resumePrompt, #quitPrompt');
    if (!target) return;
    e.preventDefault();
    if (target.id === 'resumePrompt') handlers.resume?.();
    else handlers.quit?.();
});

// --- GL-lost banner (UX-13) -------------------------------------------------
// scene.js only toggles this banner's visibility; the Reload affordance below
// mirrors the fatal panel's, so the banner finally offers the action it asks for.
glLostEl.addEventListener('click', (e) => {
    if (e.target.closest('#glReloadPrompt')) activateReload();
});
glLostEl.addEventListener('keydown', (e) => {
    if (e.key !== 'Enter' && e.key !== ' ') return;
    if (!e.target.closest('#glReloadPrompt')) return;
    e.preventDefault();
    activateReload();
});

// --- Picker roving-tabindex arrow navigation (UX-16) ------------------------
// Delegated on the persistent .startScreen element: renderPicker() rebuilds
// the cards via innerHTML, which would orphan any listener on #carPicker.
const CARD_ARROW_STEP = { ArrowLeft: -1, ArrowUp: -1, ArrowRight: 1, ArrowDown: 1 };

/** Move the roving tabindex to `card`: exactly one card stays Tab-reachable. */
function rovePickerTo(card) {
    const picker = document.getElementById('carPicker');
    if (!picker) return;
    for (const c of picker.children) c.tabIndex = c === card ? 0 : -1;
}

startScreenEl.addEventListener('keydown', (e) => {
    const dir = CARD_ARROW_STEP[e.key];
    if (!dir) return;
    const picker = document.getElementById('carPicker');
    if (!picker || !picker.children.length) return;
    const cards = [...picker.children];
    const idx = cards.indexOf(document.activeElement);
    if (idx === -1) return; // arrows stay native (panel scroll) unless a card is focused — N-7 respected
    e.preventDefault(); // don't scroll the panel while stepping through cards
    const next = cards[(idx + dir + cards.length) % cards.length];
    rovePickerTo(next);
    next.focus();
});

function formatScore(n) {
    return Math.floor(n).toLocaleString('en-US');
}

export function loadHighScore() {
    try {
        return Number(localStorage.getItem(STORAGE_KEY)) || 0;
    } catch {
        return 0; // private-mode / storage-disabled browsers
    }
}

export function saveHighScore(value) {
    try {
        localStorage.setItem(STORAGE_KEY, String(value));
    } catch {
        /* non-fatal */
    }
}

export function showScore(visible) {
    const el = document.querySelector('.score');
    el.classList.toggle('hide', !visible);
    // The pause button is racing-HUD chrome (UX-01): it lives and dies with
    // the score HUD. Static markup ships it .hide so the boot menu — where
    // showScore is never called — can never show it either.
    document.getElementById('pauseBtn')?.classList.toggle('hide', !visible);
}

/** UX-11: the score is meters survived — label it, in the HUD and everywhere
 *  it is echoed (BUSTED panel). UX-12: `record` badges the BEST line the
 *  moment the live distance passes the stored best. */
export function setScore(value, best, record = false) {
    document.getElementById('scoreValue').textContent = `${formatScore(value)} m`;
    const bestEl = document.getElementById('bestValue');
    bestEl.textContent = `BEST ${formatScore(best)} m${record ? ' · NEW!' : ''}`;
    bestEl.classList.toggle('record', record);
}

// --- Boot-phase DOM helpers -----------------------------------------------
// These are module-level (NOT methods on the start-screen controller) on
// purpose: during the asset load — the only phase with meaningful progress —
// the controller does not exist yet, and routing updates through it silently
// dropped every one of them (the frozen "Loading cars…" bug).

/**
 * Write the prompt line. `ready` omitted → only the text changes;
 * true/false toggles the disabled (wait) state AND keeps the button
 * semantics (role/tabindex) in sync with it — see the note below.
 */
export function setPromptText(text, ready) {
    const prompt = document.getElementById('startPrompt');
    if (!prompt) return;
    prompt.textContent = text;
    if (ready !== undefined) {
        prompt.classList.toggle('disabled', !ready);
        // Blind-spot fix: button SEMANTICS must track the ready state. The
        // prompt shipped role=button while still loading — a focusable
        // "button" whose activation silently no-ops (main.js `if (loaded)`)
        // is a false affordance, and the UI-08 CTA plate keys off exactly
        // this attribute, so the two can never be allowed to diverge.
        if (ready) {
            prompt.setAttribute('role', 'button');
            prompt.tabIndex = 0;
        } else {
            prompt.removeAttribute('role');
            prompt.tabIndex = -1;
        }
    }
}

/**
 * Drive the boot progress bar. fraction 0..1 → determinate fill;
 * anything else (e.g. -1) → indeterminate sweep.
 */
export function setLoadingProgress(fraction) {
    const bar = document.getElementById('loadBar');
    const fill = document.getElementById('loadFill');
    if (!bar || !fill) return;
    if (fraction >= 0 && fraction <= 1) {
        bar.classList.remove('indeterminate');
        fill.style.width = `${Math.round(fraction * 100)}%`;
    } else {
        bar.classList.add('indeterminate');
    }
}

/** Hide the progress bar once loading is over (keeps the pristine template
 *  intact for restoreStartScreen — hiding is a class, not a markup swap). */
export function hideLoadingBar() {
    document.getElementById('loadBar')?.classList.add('hide');
}

/**
 * UX-10: the user activated the start prompt mid-load. The system must
 * visibly respond even though nothing can start yet — pulse a yellow halo
 * around the prompt and the progress bar, pointing at the live progress
 * readout the prompt already carries ("Loading cars 43% — …").
 */
export function nudgeLoading() {
    for (const id of ['startPrompt', 'loadBar']) {
        const el = document.getElementById(id);
        if (!el || el.classList.contains('hide')) continue;
        el.classList.remove('nudge');
        void el.offsetWidth; // force a reflow so the animation can re-fire
        el.classList.add('nudge');
        el.addEventListener('animationend', () => el.classList.remove('nudge'), { once: true });
    }
}

// --- Pause overlay API (UX-01 / UX-07 / UX-08) ------------------------------

/** Freeze the run behind the overlay; focus lands on the primary action. */
export function showPaused() {
    pauseOverlayEl.classList.remove('hide');
    document.getElementById('pauseBtn')?.classList.add('hide'); // the overlay's Resume replaces it
    document.getElementById('resumePrompt')?.focus();
}

/** Back to (or past) the run. The pause button returns only while the
 *  racing HUD is actually visible — never on the quit-to-menu path. */
export function hidePaused() {
    pauseOverlayEl.classList.add('hide');
    const hudVisible = !document.querySelector('.score').classList.contains('hide');
    document.getElementById('pauseBtn')?.classList.toggle('hide', !hudVisible);
}

/**
 * Wire the racing controls that live outside the start screen: the on-screen
 * pause button and the pause overlay's Resume / Quit prompts.
 * @param {() => void} onPause pause button pressed mid-run
 * @param {() => void} onResume resume prompt activated
 * @param {() => void} onQuit quit-to-menu prompt activated
 */
export function initRunControls(onPause, onResume, onQuit) {
    handlers.resume = onResume;
    handlers.quit = onQuit;
    document.getElementById('pauseBtn')?.addEventListener('click', onPause);
}

/**
 * Fatal boot error: explain it in the prompt, kill the bar, and offer a
 * Reload affordance (delegated to location.reload() above — no handler
 * state to survive innerHTML swaps).
 */
export function showFatal(detail) {
    setLoadingProgress(-1);
    hideLoadingBar();
    const prompt = document.getElementById('startPrompt');
    if (prompt) {
        prompt.textContent = detail;
        prompt.classList.remove('disabled');
        prompt.removeAttribute('role'); // no longer a button — just a message
        prompt.setAttribute('tabindex', '-1');
    }
    const controls = startScreenEl.querySelector('.controls');
    if (controls && !document.getElementById('reloadPrompt')) {
        const reload = document.createElement('span');
        reload.id = 'reloadPrompt';
        reload.className = 'prompt reloadBtn';
        reload.setAttribute('role', 'button');
        reload.tabIndex = 0;
        reload.textContent = 'Reload';
        controls.prepend(reload, document.createElement('br'));
    }
}

/**
 * @param {(id: string) => void} onSelect called when a car card is clicked
 * @param {() => void} onStart called when the start prompt is clicked
 */
export function initStartScreen(onSelect, onStart) {
    handlers.start = onStart;

    return {
        /** Render picker cards with pre-rendered thumbnail data URLs.
         *  UX-16: roving tabindex — the selected card is the one Tab stop;
         *  Arrow keys step focus through the group (see the delegated
         *  handler at the top of this module). */
        renderPicker(thumbnails, selectedId) {
            const picker = document.getElementById('carPicker');
            picker.innerHTML = '';
            for (const { id, label } of PICKER_CARS) {
                const card = document.createElement('div');
                card.className = 'carCard' + (id === selectedId ? ' selected' : '');
                card.dataset.id = id;
                card.setAttribute('role', 'button');
                card.tabIndex = id === selectedId ? 0 : -1; // roving stop
                card.setAttribute('aria-pressed', String(id === selectedId));

                const img = document.createElement('img');
                img.alt = label;
                // Blind-spot fix: a default-draggable <img> inside a
                // role=button card starts a native image drag on desktop,
                // swallowing the click interaction with a drag ghost.
                img.draggable = false;
                if (thumbnails[id]) img.src = thumbnails[id];

                const name = document.createElement('span');
                name.className = 'name';
                name.textContent = label;

                card.append(img, name);
                card.addEventListener('click', () => {
                    rovePickerTo(card); // a pointer-pressed card becomes the arrow-nav anchor too
                    onSelect(id);
                });
                card.addEventListener('keydown', (e) => {
                    if (e.key === 'Enter' || e.key === ' ') {
                        e.preventDefault();
                        rovePickerTo(card);
                        onSelect(id);
                    }
                });
                picker.appendChild(card);
            }
        },

        select(id) {
            const picker = document.getElementById('carPicker');
            if (!picker) return;
            for (const card of picker.children) {
                const isPicked = card.dataset.id === id;
                card.classList.toggle('selected', isPicked);
                card.setAttribute('aria-pressed', String(isPicked));
            }
        },

        setPrompt(text, ready) {
            setPromptText(text, ready); // shared implementation — see export above
        },
    };
}

export function hideStartScreen() {
    startScreenEl.classList.add('hide');
}

/**
 * BUSTED panel. UX-11: score/best carry their unit; UX-15: a compact run
 * summary (time survived, traffic crashes); UX-08: focus is PLACED on the
 * restart prompt instead of falling to <body> when the panel swap destroys
 * whatever held it. The pause button is explicitly retired with the HUD —
 * a busted run has nothing left to pause.
 */
export function showBusted(score, best, isNewBest, onRestart, onBackToMenu, runStats) {
    handlers.restart = onRestart;
    handlers.menu = onBackToMenu;
    const summary = runStats
        ? `<p class="runSummary">Survived ${Math.max(0, Math.round(runStats.seconds))} s &middot; ${runStats.stumbles} crash${runStats.stumbles === 1 ? '' : 'es'}</p>`
        : '';
    startScreenEl.innerHTML = `
        <h1>BUSTED!</h1>
        <p class="finalScore">SCORE ${formatScore(score)} m</p>
        <p class="finalScore">${isNewBest ? 'NEW BEST!' : `BEST ${formatScore(best)} m`}</p>
        ${summary}
        <p class="prompt" id="restartPrompt" role="button" tabindex="0">Click here to run again</p>
        <p class="controls"><span id="menuPrompt" role="button" tabindex="0" style="cursor:pointer;text-decoration:underline">change car</span></p>
    `;
    startScreenEl.classList.add('busted');
    startScreenEl.classList.remove('hide');
    document.querySelector('.score').classList.add('hide');
    document.getElementById('pauseBtn')?.classList.add('hide');
    document.getElementById('restartPrompt')?.focus();
}

/** Restore the pristine start screen after a BUSTED view or a mid-run quit.
 *  UX-08: focus the primary action — the start prompt — instead of dropping
 *  it on <body>. Blind-spot fix (caught by the iter8 regression): the quit
 *  path arrives with the panel still .hide'd by hideStartScreen() — the
 *  BUSTED path never noticed because showBusted() had already un-hidden it.
 *  A display:none panel also silently swallows focus(), so the hide must go
 *  BEFORE the focus call. */
export function restoreStartScreen() {
    startScreenEl.classList.remove('busted');
    startScreenEl.classList.remove('hide');
    startScreenEl.innerHTML = START_SCREEN_TEMPLATE;
    // The pristine template ships with the bar at 0% and visible; it is only
    // meaningful pre-load, so keep it hidden across menu round-trips.
    document.getElementById('loadBar')?.classList.add('hide');
    document.getElementById('startPrompt')?.focus({ preventScroll: true });
}
