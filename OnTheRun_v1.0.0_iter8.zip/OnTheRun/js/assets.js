import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';

/**
 * assets.js — single responsibility: load the GLB manifest and hand back
 * ready-to-clone glTF scenes. Nothing else knows about GLTFLoader.
 */

/**
 * Byte-accurate progress + stall watchdog + abortable downloads.
 *
 * GLTFLoader's per-file onProgress used to be discarded, so the UI could
 * only show whole-file counts — on a slow connection the prompt sat frozen
 * for minutes. Transfers now run on a manual fetch(): we aggregate
 * loaded/total bytes across all files, throttle emissions to ~100 ms, and
 * hard-fail if ZERO bytes move for STALL_TIMEOUT_MS (a hung request used to
 * hang Promise.all forever, leaving the loading screen up for eternity with
 * no explanation).
 *
 * On ANY fatal error every in-flight transfer is aborted through a shared
 * AbortController — bytes must not keep streaming in behind the fatal
 * panel until Reload (audit N-3).
 *
 * UX-09: a single transient failure (Wi-Fi blip, 5xx from a flaky proxy) no
 * longer forces the maximally expensive recovery — a full page reload that
 * re-downloads ~6 MB and resets the user's place. Each file retries itself
 * with backoff before the boot can go fatal: network throws, mid-stream
 * reader failures, and 5xx responses are retryable; deliberate aborts and
 * permanent conditions (404/403, a corrupt GLB failing to parse) are not —
 * retrying those would only add latency before the honest fatal panel.
 */

const EMIT_INTERVAL_MS = 100;
const STALL_TIMEOUT_MS = 20000;
const STALL_POLL_MS = 4000;
const RETRY_ATTEMPTS = 3;          // 1 initial try + 2 retries (UX-09)
const RETRY_BACKOFF_MS = [600, 1200];

const sleep = (ms, signal) => new Promise((resolve, reject) => {
    if (signal.aborted) {
        reject(new DOMException('Aborted', 'AbortError'));
        return;
    }
    const timer = setTimeout(resolve, ms);
    signal.addEventListener('abort', () => {
        clearTimeout(timer);
        reject(new DOMException('Aborted', 'AbortError'));
    }, { once: true });
});

/**
 * @param {Record<string, string>} manifest  id -> asset path
 * @param {(done: number, total: number, agg: {
 *   bytesLoaded: number, bytesTotal: number, fraction: number,
 *   file: string
 * }) => void} [onProgress]  fraction is -1 when byte totals are unknown
 * @returns {Promise<Record<string, object>>}  id -> glTF scene group
 */
export function loadAssets(manifest, onProgress) {
    return new Promise((resolveAll, rejectAll) => {
        const entries = Object.entries(manifest);
        const loader = new GLTFLoader(); // parse duty only; fetch does the transfer
        const result = {};
        const bytes = new Map(); // path -> { loaded, total }
        const accounted = new Set(); // paths that sent ≥1 progress event or completed
        let done = 0;
        let lastEmit = 0;
        let activePath = entries.length ? entries[0][1] : ''; // most recently active download

        const emit = (force = false) => {
            if (!onProgress) return;
            const now = Date.now();
            if (!force && now - lastEmit < EMIT_INTERVAL_MS) return;
            lastEmit = now;
            let bytesLoaded = 0;
            let bytesTotal = 0;
            let totalsKnown = true;
            for (const b of bytes.values()) {
                bytesLoaded += b.loaded;
                if (b.total > 0) bytesTotal += b.total;
                else totalsKnown = false;
            }
            // A percentage is only honest when EVERY file has reported. A file
            // that never sent its first byte contributes no total — counting
            // only the others can show a false 100% while data is missing
            // (exactly the false certainty this loading UI exists to prevent).
            const allReported = accounted.size === entries.length;
            onProgress(done, entries.length, {
                bytesLoaded,
                bytesTotal,
                fraction: allReported && totalsKnown && bytesTotal > 0
                    ? bytesLoaded / bytesTotal
                    : -1,
                file: activePath, // N-4: the download actually in flight, not a position guess
            });
        };

        // N-3: one AbortController rules every transfer, so a fatal error
        // terminates all stragglers at once.
        const controller = new AbortController();

        // One hung transfer must not hang the whole boot: if nothing at all
        // has moved (no bytes, no completions) for STALL_TIMEOUT_MS, fail
        // loudly so main.js can show the fatal UI instead of silence.
        let lastActivity = Date.now();
        const touch = (path) => {
            lastActivity = Date.now();
            if (path) activePath = path; // N-4: track the truly active file
        };

        let stall; // N-1: the id is captured so every settlement path can clear it
        const clearStallWatch = () => clearInterval(stall);
        const fail = (err) => {
            clearStallWatch();  // N-1: no poller survives ANY settlement, per-file errors included
            controller.abort(); // N-3: in-flight stragglers die with the fatal error
            rejectAll(err);
        };
        stall = setInterval(() => {
            if (Date.now() - lastActivity > STALL_TIMEOUT_MS) {
                fail(new Error('The download stalled — no data received for 20 seconds.'));
            }
        }, STALL_POLL_MS);

        /** Fetch one GLB with byte-level progress, then parse it — with
         *  bounded retry (UX-09) around every transient failure mode. */
        const loadOne = (id, path) => (async () => {
            for (let attempt = 0; ; attempt++) {
                try {
                    const res = await fetch(path, { signal: controller.signal });
                    if (!res.ok) {
                        const err = new Error(`HTTP ${res.status}`);
                        // 4xx will never succeed on retry; 5xx might.
                        err.permanent = res.status < 500;
                        throw err;
                    }
                    const record = { loaded: 0, total: Number(res.headers.get('Content-Length')) || 0 };
                    bytes.set(path, record);
                    accounted.add(path);
                    touch(path);
                    emit();

                    const chunks = [];
                    if (res.body) {
                        const reader = res.body.getReader();
                        for (;;) {
                            const { done: finished, value } = await reader.read();
                            if (finished) break;
                            chunks.push(value);
                            record.loaded += value.length;
                            touch(path);
                            emit();
                        }
                    } else {
                        // Bodyless-response fallback for unusual servers/proxies.
                        const all = new Uint8Array(await res.arrayBuffer());
                        chunks.push(all);
                        record.loaded = all.length;
                    }

                    const buffer = new Uint8Array(record.loaded);
                    let offset = 0;
                    for (const chunk of chunks) {
                        buffer.set(chunk, offset);
                        offset += chunk.length;
                    }

                    const gltf = await new Promise((resolve, reject) => {
                        try {
                            // GLBs are self-contained: parse needs no resource path.
                            loader.parse(buffer.buffer, '', resolve, reject);
                        } catch (err) {
                            reject(err);
                        }
                    }).catch((err) => {
                        // A complete buffer that fails to parse is corrupt —
                        // retrying cannot fix it, so the failure is permanent.
                        err.permanent = true;
                        throw err;
                    });
                    result[id] = gltf.scene;
                    done += 1;
                    touch(path);
                    emit(true);
                    return;
                } catch (err) {
                    const aborted = err?.name === 'AbortError' || controller.signal.aborted;
                    if (aborted || err?.permanent || attempt >= RETRY_ATTEMPTS - 1) {
                        // One consistent, path-tagged identity for every per-file failure.
                        const tries = attempt + 1;
                        throw new Error(
                            `Failed to load asset: ${path}${err && err.message ? ` (${err.message})` : ''}` +
                            (tries > 1 ? ` [after ${tries} attempts]` : '')
                        );
                    }
                    // UX-09: transient failure — drop THIS attempt's byte
                    // accounting (the aggregate must not double-count a file
                    // that restarts from zero) and retry after a short backoff.
                    bytes.set(path, { loaded: 0, total: 0 });
                    touch(path);
                    emit(true);
                    await sleep(RETRY_BACKOFF_MS[Math.min(attempt, RETRY_BACKOFF_MS.length - 1)], controller.signal);
                }
            }
        })();

        emit(true);
        Promise.all(entries.map(([id, path]) => loadOne(id, path))).then(
            () => {
                clearStallWatch(); // N-1: success path clears too
                resolveAll(result);
            },
            fail
        );
    });
}

/** Give every material in a model a bit of texture sharpness. */
export function enhanceMaterials(root, maxAnisotropy = 4) {
    root.traverse((obj) => {
        if (obj.isMesh && obj.material?.map) {
            obj.material.map.anisotropy = maxAnisotropy;
        }
    });
}
