import { SPEED, POLICE, TRAFFIC, CAMERA } from './config.js';

/**
 * game.js — the state machine + the single delta-time loop.
 *
 * States: menu → running → (paused ↔ running) → busting → busted → menu
 * The loop is the ONLY place that steps the simulation, and every step is
 * scaled by dt — the frame-rate bug from the 2D original is structurally
 * impossible here.
 *
 * UX fix pack: 'paused' is a first-class phase (UX-01) — reachable via
 * Esc/P (edge action from input.js) or the on-screen pause button, it
 * freezes every step without stopping the render loop, so a resume
 * continues the exact frame that was frozen. Visibility loss while
 * running deliberately parks the race in 'paused' (UX-03): the player
 * returns to a frozen world + resume prompt instead of live traffic.
 */

export function createGame({ sceneKit, road, input, ui, police, audio, onMenuRestore }) {
    let player = null;
    let traffic = null;

    const state = {
        phase: 'menu',
        elapsed: 0,
        distance: 0,
        best: ui.loadHighScore(),
        lastShownScore: -1,
        spinV: 0,
        stumbles: 0, // UX-15: traffic crashes this run (bust contact excluded)
    };

    // UX-01: the Esc/P toggle. input.js fires this edge action regardless of
    // its racing-only `enabled` gate (pausing needs it while setEnabled(false));
    // this phase filter is the single authority on what the toggle means.
    input.onPause(() => {
        if (state.phase === 'running') pauseRace();
        else if (state.phase === 'paused') resumeRace();
    });

    // UX-03: a tab/app switch mid-run must never hand the player back to live
    // traffic. The browser already freezes rAF while hidden; on return this
    // parks the run in the pause overlay (Resume prompt + frozen world) so
    // re-orientation is free and resumption is always an explicit act.
    // Stronger than the audited grace-window remedy: zero sim time can pass
    // without a deliberate resume. Other phases no-op via pauseRace's guard.
    document.addEventListener('visibilitychange', () => {
        if (document.hidden) pauseRace();
    });

    function setPlayer(p) {
        player = p;
    }

    function setTraffic(t) {
        traffic = t;
    }

    function startRace() {
        state.phase = 'running';
        state.elapsed = 0;
        state.distance = 0;
        state.lastShownScore = -1;
        state.spinV = 0;
        state.stumbles = 0;
        player.reset();
        traffic.reset();
        police.reset();
        police.show(); // F-4: the cop takes the stage at the start gap, not at the origin
        input.setEnabled(true);
        audio.unlock(); // UX-06: race start is always a user gesture — create/resume the context
        ui.hideStartScreen();
        ui.showScore(true); // also reveals the on-screen pause button (UX-01)
        ui.setScore(0, state.best);
    }

    /** UX-01: freeze the run behind a resume/quit overlay. */
    function pauseRace() {
        if (state.phase !== 'running') return;
        state.phase = 'paused';
        input.setEnabled(false); // wipes held keys/drags — a clean slate on resume
        audio.stopSiren();
        ui.showPaused(); // focuses the Resume prompt (UX-08)
    }

    function resumeRace() {
        if (state.phase !== 'paused') return;
        state.phase = 'running';
        input.setEnabled(true); // wipe + re-enable: stale keys can never resume applied
        ui.hidePaused(); // re-reveals the pause button
        // No dt compensation needed: the render loop never stopped, so the
        // next tick's delta is one ordinary frame.
    }

    /** UX-07: the run's route back to the menu — routed through pause so a
     *  quit is always a deliberate two-step act (no single-key mispress can
     *  abandon a run), and through toMenu so the cleanup is the existing one. */
    function quitToMenu() {
        if (state.phase !== 'paused') return;
        ui.hidePaused();
        toMenu();
    }

    function toMenu() {
        state.phase = 'menu';
        input.setEnabled(false);
        ui.showScore(false); // also hides the pause button
        ui.hidePaused();     // defensive: the quit path came through the overlay
        audio.stopSiren();
        player.reset();
        traffic.reset(); // F-2: no frozen traffic around the menu showcase
        police.reset();  // F-2: no half-busted cop parked next to it
        onMenuRestore();
    }

    function finalizeBust() {
        const finalScore = Math.floor(state.distance);
        const isNewBest = finalScore > state.best;
        if (isNewBest) {
            state.best = finalScore;
            ui.saveHighScore(finalScore);
        }
        state.phase = 'busted';
        input.setEnabled(false);
        // UX-15: the panel carries the run summary the state machine already holds.
        ui.showBusted(finalScore, state.best, isNewBest, () => startRace(), toMenu,
            { seconds: state.elapsed, stumbles: state.stumbles });
    }

    function stepRunning(dt) {
        state.elapsed += dt;

        // Difficulty ramp (authorized feature): speed grows while you survive.
        const baseSpeed = Math.min(SPEED.max, SPEED.base + SPEED.ramp * state.elapsed);

        // Player step → effective speed (stumble/throttle multipliers).
        const mult = player.update(dt, baseSpeed, input.steer(), input.throttle());
        const effectiveSpeed = baseSpeed * mult;
        const meters = effectiveSpeed * dt;
        state.distance += meters;

        // Traffic step + collision.
        traffic.update(dt, effectiveSpeed, baseSpeed, meters);
        const hitCar = traffic.hitPlayer(player.state.x, 0, player.car.halfW, player.car.halfL);
        if (hitCar && player.state.graceT <= 0) {
            hitCar.hit = true;
            hitCar.flingVx = (hitCar.root.position.x < player.state.x ? -1 : 1) * TRAFFIC.flingSpeed;
            player.stumble();
            state.stumbles += 1; // UX-15
            audio.crash();       // UX-06: thud + haptic on every collision
        }

        // Police pressure → bust?
        const verdict = police.update(dt, player.state.x, player.state.stumbleT > 0, baseSpeed);
        if (verdict === 'busted') {
            state.phase = 'busting';
            state.spinV = POLICE.bustSpin;
            input.setEnabled(false);
            audio.bust(); // UX-06: stands the siren down + plays the sting
        } else {
            // UX-06: proximity siren — normalize the gap (startGap → bustGap)
            // into 0..1 tension and let the audio module shape it.
            const prox = (POLICE.startGap - police.state.gap) / (POLICE.startGap - POLICE.bustGap);
            audio.setSiren(prox);
        }

        // World scroll + HUD.
        road.scroll(meters);
        const shown = Math.floor(state.distance);
        if (shown !== state.lastShownScore) {
            state.lastShownScore = shown;
            // UX-12: the BEST line must never report a stale figure mid-run —
            // the moment the live distance passes the stored best, the HUD
            // shows the new number and badges it. Display-only: the stored
            // best is still written exactly once, in finalizeBust.
            const record = state.best > 0 && shown > state.best;
            ui.setScore(shown, Math.max(state.best, shown), record);
        }
    }

    function stepBusting(dt) {
        // Player spins out, cop pulls alongside — then the panel drops.
        player.car.root.rotation.y += state.spinV * dt;
        state.spinV *= 1 - Math.min(1, dt * POLICE.bustSpinDamp);
        const done = police.updateBustAnim(dt, player.state.x);
        if (done) finalizeBust();
    }

    function stepMenu(dt) {
        road.scroll(SPEED.menuSpeed * dt);
        player.showcase(dt);
    }

    function tick() {
        sceneKit.timer.update();
        const dt = Math.min(sceneKit.timer.getDelta(), 0.05); // belt & braces vs. Timer's own visibility guard
        // 'paused' intentionally has no branch: nothing steps, but the render
        // continues (resize stays correct, the frozen world stays visible).
        if (state.phase === 'running') stepRunning(dt);
        else if (state.phase === 'busting') stepBusting(dt);
        else if (state.phase === 'menu') stepMenu(dt);

        sceneKit.updateChase(player.state.x, dt, state.phase === 'menu' ? CAMERA.menuDrift : 0);
        sceneKit.renderer.render(sceneKit.scene, sceneKit.camera);
    }

    function run() {
        sceneKit.renderer.setAnimationLoop(tick);
    }

    return { setPlayer, setTraffic, startRace, pauseRace, resumeRace, quitToMenu, toMenu, run, state };
}
