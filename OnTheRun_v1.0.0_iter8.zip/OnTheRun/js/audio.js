import { AUDIO } from './config.js';

/**
 * audio.js — synthesized feedback cues + haptics (UX-06 fix pack).
 * Single responsibility: the game's ears. No audio files, no loader, no
 * new downloads — every cue is a WebAudio oscillator/noise envelope, so
 * the no-build architecture gains zero assets and zero dependencies.
 *
 * Autoplay policy: the AudioContext is constructed and resumed lazily in
 * unlock(), which game.js calls from startRace() — always inside a real
 * user gesture (the click / Enter that pressed the start or restart
 * prompt), which is what Chrome and Safari both require.
 *
 * Every cue is defensive no-op when the context never reached 'running'
 * (headless probes, embedded webviews without audio, autoplay denial) —
 * feedback must enhance the game, never break it.
 *
 * Diagnostics: window.__audio exposes the live context state for headless
 * regression probes — the same established pattern as window.__boot.
 */

export function createAudio() {
    let ctx = null;      // AudioContext (created lazily, on a user gesture)
    let master = null;   // shared output gain
    let siren = null;    // { gain } — nodes persist; gain follows proximity

    function ensure() {
        if (ctx) return true;
        const AC = window.AudioContext || window.webkitAudioContext;
        if (!AC) return false;
        try {
            ctx = new AC();
        } catch {
            return false; // some embedded webviews deny construction outright
        }
        master = ctx.createGain();
        master.gain.value = AUDIO.master;
        master.connect(ctx.destination);
        window.__audio = { get state() { return ctx ? ctx.state : 'uninitialized'; } };
        return true;
    }

    /** Create/resume the context. MUST be called from a user-gesture path. */
    function unlock() {
        if (!ensure()) return;
        if (ctx.state === 'suspended') ctx.resume().catch(() => { /* denial is fine */ });
    }

    /** Best-effort haptics — silent no-op where unsupported. */
    function haptic(pattern) {
        try {
            navigator.vibrate?.(pattern);
        } catch { /* never let feedback throw into the game loop */ }
    }

    /** Short lowpass-filtered noise burst with a decay envelope: the thud. */
    function crash() {
        if (!ctx || ctx.state !== 'running') return;
        const t = ctx.currentTime;
        const dur = AUDIO.crash.duration;
        const buffer = ctx.createBuffer(1, Math.max(1, Math.ceil(ctx.sampleRate * dur)), ctx.sampleRate);
        const data = buffer.getChannelData(0);
        for (let i = 0; i < data.length; i++) {
            data[i] = (Math.random() * 2 - 1) * (1 - i / data.length); // linear decay
        }
        const src = ctx.createBufferSource();
        src.buffer = buffer;
        const filter = ctx.createBiquadFilter();
        filter.type = 'lowpass';
        filter.frequency.value = AUDIO.crash.filterHz;
        const gain = ctx.createGain();
        gain.gain.setValueAtTime(AUDIO.crash.gain, t);
        gain.gain.exponentialRampToValueAtTime(0.001, t + dur);
        src.connect(filter).connect(gain).connect(master);
        src.start(t);
        src.stop(t + dur);
        haptic([AUDIO.crash.vibrateMs]);
    }

    /** Descending wail — the BUSTED sting (also stands the siren down). */
    function bust() {
        stopSiren();
        haptic(AUDIO.bust.vibrate);
        if (!ctx || ctx.state !== 'running') return;
        const t = ctx.currentTime;
        const osc = ctx.createOscillator();
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(AUDIO.bust.fromHz, t);
        osc.frequency.exponentialRampToValueAtTime(AUDIO.bust.toHz, t + AUDIO.bust.duration);
        const gain = ctx.createGain();
        gain.gain.setValueAtTime(AUDIO.bust.gain, t);
        gain.gain.exponentialRampToValueAtTime(0.001, t + AUDIO.bust.duration);
        osc.connect(gain).connect(master);
        osc.start(t);
        osc.stop(t + AUDIO.bust.duration);
    }

    /**
     * Continuous proximity siren: a wobbling carrier whose gain follows the
     * cop's gap (intensity 0..1, already computed by game.js from the gap).
     * Built once, then only the gain moves — setTargetAtTime smooths steps.
     */
    function setSiren(intensity) {
        if (!ctx || ctx.state !== 'running') return;
        if (!siren) {
            const osc = ctx.createOscillator();
            osc.type = 'triangle';
            osc.frequency.value = AUDIO.siren.freqHz;
            const lfo = ctx.createOscillator();
            lfo.type = 'sine';
            lfo.frequency.value = AUDIO.siren.wobbleHz;
            const lfoGain = ctx.createGain();
            lfoGain.gain.value = AUDIO.siren.wobbleDepth;
            lfo.connect(lfoGain).connect(osc.frequency);
            const gain = ctx.createGain();
            gain.gain.value = 0;
            osc.connect(gain).connect(master);
            osc.start();
            lfo.start();
            siren = { gain };
        }
        const i = Math.max(0, Math.min(1, intensity));
        siren.gain.gain.setTargetAtTime(
            AUDIO.siren.maxGain * Math.pow(i, AUDIO.siren.curve),
            ctx.currentTime,
            0.1
        );
    }

    /** Fade the siren out (pause / bust / menu). Nodes persist at zero gain. */
    function stopSiren() {
        if (!siren || !ctx) return;
        siren.gain.gain.setTargetAtTime(0, ctx.currentTime, 0.05);
    }

    return { unlock, crash, bust, setSiren, stopSiren };
}
