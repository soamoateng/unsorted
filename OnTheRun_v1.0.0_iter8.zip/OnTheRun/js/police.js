import * as THREE from 'three';
import { POLICE, COLORS } from './config.js';

/**
 * police.js — the chase pressure system.
 *
 * The cop matches your speed at a breathing distance ("targetGap"). Crashing
 * into traffic costs you speed, so the gap shrinks fast while you stumble and
 * slowly heals while you drive clean. Gap <= bustGap → BUSTED.
 *
 * The audited police GLB is a single welded mesh (no wheel nodes), so motion
 * is sold with a light bar + body bob instead of wheel spin — the factory's
 * empty wheels array makes that branch automatic.
 */
export function createPolice(scene, car) {
    const lightBar = new THREE.Group();
    const blueGlass = new THREE.Mesh(
        new THREE.BoxGeometry(0.28, 0.12, 0.3),
        new THREE.MeshBasicMaterial({ color: COLORS.policeFlashBlue })
    );
    const redGlass = new THREE.Mesh(
        new THREE.BoxGeometry(0.28, 0.12, 0.3),
        new THREE.MeshBasicMaterial({ color: COLORS.policeFlashRed })
    );
    blueGlass.position.set(-0.18, 0, 0);
    redGlass.position.set(0.18, 0, 0);
    lightBar.add(blueGlass, redGlass);

    const state = {
        gap: POLICE.startGap,
        x: 0,
        flashT: 0,
        bustAnimT: 0,
    };

    // F-4: the cop stays offstage until a race begins — never parked at the
    // model origin (0,0,0) overlapping the menu's showcased player car.
    car.root.visible = false;

    // Player is always at z=0 (see player.js), so the cop rides at +gap behind.
    function place(playerX, dt) {
        state.x += (playerX - state.x) * Math.min(1, dt * POLICE.laneLerp);
        car.root.position.set(state.x, 0, state.gap);
        car.root.rotation.y = Math.PI;
    }

    /** Take the stage: hard-snap to the race-start pose (no 1-frame glitch). */
    function show() {
        car.root.visible = true;
        car.root.position.set(state.x, 0, state.gap);
        car.root.rotation.set(0, Math.PI, 0); // also zeroes the bob on rotation.z
    }

    /**
     * @returns {'chasing' | 'busted'}
     */
    function update(dt, playerX, stumbleActive, playerSpeed) {
        state.flashT += dt;

        // Sirens flash faster the closer the cop gets.
        const flashRate = 3 + (POLICE.startGap - state.gap) * 0.4;
        const phase = Math.sin(state.flashT * flashRate * Math.PI) > 0;
        blueGlass.material.color.setHex(phase ? COLORS.policeFlashBlue : 0x102040);
        redGlass.material.color.setHex(phase ? 0x401010 : COLORS.policeFlashRed);

        if (stumbleActive) {
            state.gap -= POLICE.catchRate * dt;
        } else {
            const equilibrium = POLICE.targetGap + POLICE.gapSpeedBonus * playerSpeed;
            if (state.gap < equilibrium) {
                state.gap = Math.min(equilibrium, state.gap + POLICE.recoverRate * dt);
            }
        }

        // Body bob (welded mesh — see module doc)
        car.root.rotation.z = Math.sin(state.flashT * 9) * 0.008;
        place(playerX, dt);

        if (state.gap <= POLICE.bustGap) {
            state.bustAnimT = POLICE.bustAnimTime;
            return 'busted';
        }
        return 'chasing';
    }

    /** Pull-over flourish: cop sweeps alongside while the player spins out. */
    function updateBustAnim(dt, playerX) {
        state.bustAnimT = Math.max(0, state.bustAnimT - dt);
        state.gap += (POLICE.pullGap - state.gap) * Math.min(1, dt * POLICE.pullGapLerp); // pull alongside
        state.x += (playerX + POLICE.pullSideOffset - state.x) * Math.min(1, dt * POLICE.pullSideLerp);
        car.root.position.set(state.x, 0, state.gap);
        const phase = Math.sin(state.flashT * POLICE.bustFlashRate * Math.PI) > 0;
        blueGlass.material.color.setHex(phase ? COLORS.policeFlashBlue : 0x102040);
        redGlass.material.color.setHex(phase ? 0x401010 : COLORS.policeFlashRed);
        state.flashT += dt;
        return state.bustAnimT <= 0;
    }

    function reset() {
        state.gap = POLICE.startGap;
        state.x = 0;
        state.flashT = 0;
        state.bustAnimT = 0;
        car.root.visible = false; // offstage again (pre-race / menu)
    }

    // Light bar rides on the roof; the normalized model grounds itself at y=0,
    // roof height comes from the template bounding box.
    function attachToRoof() {
        car.root.updateWorldMatrix(true, true);
        const box = new THREE.Box3().setFromObject(car.root);
        lightBar.position.set(0, box.max.y + 0.02, 0.4);
        car.root.add(lightBar);
    }

    return { car, state, update, updateBustAnim, show, reset, attachToRoof };
}
