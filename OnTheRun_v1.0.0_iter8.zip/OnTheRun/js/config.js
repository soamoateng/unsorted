/**
 * config.js — every tunable in one place.
 * Fixes the 2D original's biggest flaw: magic numbers (700/750/350…) welded
 * to one screen size. All units are metric (meters, meters/second, radians).
 */

export const ASSETS = {
    police: 'assets/cars/arunangshubanerjee-police-car-2064.glb',
    hyper: 'assets/cars/ergoninane-fast-71.glb',
    beef: 'assets/cars/ergoninane-fast-72.glb',
    charger: 'assets/cars/ergoninane-fast-74.glb',
    normal: 'assets/cars/quaternius_cc0-normal-car-1190.glb',
    sports: 'assets/cars/quaternius_cc0-sports-car-1371.glb',
};

/** Human names for the car picker (order = picker order). Police excluded. */
export const PICKER_CARS = [
    { id: 'sports', label: 'Sports Car' },
    { id: 'hyper', label: 'Hyper GT' },
    { id: 'beef', label: 'Mister Beef' },
    { id: 'charger', label: 'Fast Charger' },
    { id: 'normal', label: 'Street Car' },
];

// N-8 — documented balance decision: an idle player resting at x=0 threads
// the gap between the two center lanes (centers at ±1.75/±5.25, player
// limit 6.3). That easy-lane escape is intended, not a defect — see the
// README "Hardening Notes". Change this only as a deliberate design act.
export const WORLD = {
    laneX: [-5.25, -1.75, 1.75, 5.25], // 4 lanes
    roadWidth: 15.4,
    playerXLimit: 6.3,
    spawnAheadZ: -115, // traffic spawns this far in front (fog swallows the pop-in)
    despawnZ: 14,      // recycled once behind the camera
    fogNear: 55,
    fogFar: 150,
};

export const PLAYER = {
    z: 0,
    steerSpeed: 15,        // lateral m/s at full input
    steerAccel: 60,        // lateral accel toward target velocity (smooths input)
    tiltFactor: 0.028,     // body roll per unit of lateral velocity
    wobbleRate: 18,        // rad/s of the stumble wobble (F-8: flourish constants live here)
    wobbleAmp: 0.06,       // rad amplitude of the stumble wobble
    carLength: 4.4,        // normalized model length (m)
    carWidth: 2.0,         // normalized model width (m)
    wheelSpinRate: 2.6,    // wheel rad per (m traveled), tuned visually
};

export const SPEED = {
    base: 26,          // starting forward speed m/s (~94 km/h)
    ramp: 0.55,        // added per second of survival
    max: 78,
    stumbleFactor: 0.5,   // speed multiplier while stumbling
    stumbleTime: 1.25,    // s
    graceTime: 1.6,       // s of crash immunity after a stumble
    menuSpeed: 8,         // road scroll speed on the start screen
};

export const POLICE = {
    startGap: 14,        // distance behind player at race start (m)
    targetGap: 9,        // equilibrium distance while you drive clean
    bustGap: 3.4,        // if gap <= this → BUSTED
    catchRate: 2.6,      // m/s the cop gains while you stumble (per stumble second)
    recoverRate: 0.28,   // m/s the gap heals while driving clean
    gapSpeedBonus: 0.06, // equilibrium grows with speed (fast driving = safer gap)
    laneLerp: 2.2,       // how quickly the cop tracks your lane
    bustAnimTime: 1.4,   // s of pull-over animation before the panel shows
    bustSpin: 6,         // rad/s the player spins out at bust start
    bustSpinDamp: 1.5,   // per-second decay of the bust spin
    pullGap: 1.4,        // gap the cop eases to when pulling alongside (m)
    pullSideOffset: 2.4, // lateral offset beside the player during the bust (m)
    pullGapLerp: 2.5,    // how fast the gap eases to pullGap (per second)
    pullSideLerp: 2,     // how fast the cop slides alongside (per second)
    bustFlashRate: 14,   // lightbar flash rate during the bust (Hz-ish)
};

export const TRAFFIC = {
    poolSize: 10,
    ownSpeedMin: 0.42,   // fraction of player base speed (slower = you overtake)
    ownSpeedMax: 0.68,
    spawnEveryMeters: 14,// avg distance traveled per spawn event
    laneCooldownZ: 34,   // min z-gap to the nearest car ahead in a lane
    spawnJitterZ: 45,    // random extra distance past spawnAheadZ
    forgiveness: 0.78,   // shrink hitboxes so near misses feel fair
    flingSpeed: 7,       // lateral m/s a hit car is flung away with
    flingSpinRate: 5,    // rad/s a flung car tumbles while it slides
    flingDamp: 0.8,      // exp decay rate (1/s): v *= e^(−0.8·dt) — ≈55% of fling velocity lost per second (N-6)
    flingCutoff: 0.01,   // m/s below which the knock-flourish hard-stops
};

export const CAMERA = {
    fov: 62,
    position: [0, 4.4, 8.0],
    lookAt: [0, 1.0, -8],
    lateralFollow: 0.45, // camera follows a fraction of player x
    menuDrift: 0.18,     // subtle idle sway on the start screen
};

export const COLORS = {
    background: 0x10141c,
    fog: 0x10141c,
    road: 0x2d3436,      // same asphalt tone as the 2D original
    dash: 0xc8d6e5,      // same lane-line tone as the 2D original
    barrier: 0xb2bec3,
    ground: 0x0b0f16,
    hemiSky: 0x8fa6c9,
    hemiGround: 0x1a1d24,
    sun: 0xdfe9ff,
    policeFlashBlue: 0x2e86ff,
    policeFlashRed: 0xff4d4d,
};

// UX-06 — synthesized feedback cues (consumed by audio.js). Every value is
// a plain physical unit (seconds, Hz, gain 0..1, ms) — no audio files, no
// loader, zero extra downloads; the cues are WebAudio oscillators/noise.
export const AUDIO = {
    master: 0.5,                       // master gain headroom
    crash: {
        gain: 0.5,                     // thud loudness
        duration: 0.22,                // s
        filterHz: 900,                 // lowpass ceiling for the noise burst
        vibrateMs: 70,                 // navigator.vibrate on collision (mobile)
    },
    bust: {
        gain: 0.4,
        fromHz: 680,                   // descending wail start
        toHz: 240,                     // …and end
        duration: 0.7,                 // s
        vibrate: [90, 60, 140],        // pulse pattern on the bust
    },
    siren: {
        freqHz: 620,                   // carrier tone
        wobbleHz: 0.9,                 // wail LFO rate
        wobbleDepth: 130,              // wail LFO depth (Hz)
        maxGain: 0.07,                 // gain at full cop proximity
        curve: 1.5,                    // proximity→gain exponent (quiet until close)
    },
};

export const STORAGE_KEY = 'ontherun_highscore';
