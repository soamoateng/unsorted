import * as THREE from 'three';
import { WORLD, PLAYER, SPEED } from './config.js';
import { spinWheels, BASE_YAW } from './car-factory.js';

/**
 * player.js — the runner. Stays at z=0 forever; only lateral position is
 * player-controlled (the world streams past — the standard endless-runner
 * fix for the floating-point drift a moving player would accumulate).
 */

export function createPlayer(car) {
    car.root.position.set(0, 0, PLAYER.z);
    car.root.rotation.y = BASE_YAW;

    const state = {
        x: 0,
        lateralV: 0,
        stumbleT: 0,
        graceT: 0,
    };

    /** Apply a traffic hit: slow down + brief immunity. */
    function stumble() {
        state.stumbleT = SPEED.stumbleTime;
        state.graceT = SPEED.graceTime;
    }

    /**
     * @param {number} dt delta seconds
     * @param {number} forwardSpeed current forward speed m/s
     * @param {number} steer -1..1
     * @param {number} throttle -1..1
     * @returns {number} speed multiplier to apply this frame
     */
    function update(dt, forwardSpeed, steer, throttle) {
        // Lateral velocity eases toward the commanded value (keyboard = crisp,
        // pointer = proportional). One formula serves both inputs.
        const targetV = steer * PLAYER.steerSpeed;
        const blend = Math.min(1, dt * PLAYER.steerAccel / PLAYER.steerSpeed);
        state.lateralV += (targetV - state.lateralV) * blend;

        state.x = Math.max(-WORLD.playerXLimit, Math.min(WORLD.playerXLimit, state.x + state.lateralV * dt));

        // Timers
        if (state.stumbleT > 0) state.stumbleT = Math.max(0, state.stumbleT - dt);
        if (state.graceT > 0) state.graceT = Math.max(0, state.graceT - dt);

        // Throttle nudges the effective speed (ported up/down intent)
        const throttleMul = throttle > 0 ? 1.12 : throttle < 0 ? 0.78 : 1;
        const stumbleMul = state.stumbleT > 0 ? SPEED.stumbleFactor : 1;

        // Body roll sells the steering; slight wobble while stumbling
        // (F-8: the wobble constants live in config.js like every tunable).
        car.root.position.x = state.x;
        car.root.rotation.z = -state.lateralV * PLAYER.tiltFactor;
        car.root.rotation.y =
            BASE_YAW + (state.stumbleT > 0 ? Math.sin(state.stumbleT * PLAYER.wobbleRate) * PLAYER.wobbleAmp : 0);

        spinWheels(car, forwardSpeed * dt);
        return throttleMul * stumbleMul;
    }

    /** Idle turntable spin for the start screen; resets before a race. */
    function showcase(dt) {
        car.root.rotation.y += dt * 0.5;
    }

    function resetShowcase() {
        car.root.rotation.y = BASE_YAW;
        car.root.rotation.z = 0;
    }

    function reset() {
        state.x = 0;
        state.lateralV = 0;
        state.stumbleT = 0;
        state.graceT = 0;
        car.root.position.x = state.x; // F-3: mesh must match the reset state (menu is centered)
        resetShowcase();
    }

    return { car, state, update, stumble, showcase, reset };
}
