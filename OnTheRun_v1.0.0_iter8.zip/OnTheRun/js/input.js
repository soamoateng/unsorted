/**
 * input.js — unified keyboard + pointer steering.
 *
 * Fixes two 2D-original bugs at the source:
 *  - preventDefault is applied ONLY to the keys the game actually consumes,
 *    so F5 / DevTools / Tab stop being hijacked.
 *  - touch support (pointer events cover mouse + touch + pen with one API).
 *
 * Edges covered (F-5/F-6):
 *  - Keyboard matching uses e.code (physical key), so WASD works on any
 *    OS layout — AZERTY, Cyrillic, Greek — where e.key would be 'z'/'w'/etc.
 *  - Pointer drags are pointer-captured and id-guarded: releasing outside
 *    the window or a second finger can no longer leave steering stuck on.
 *  - A window blur wipes all held keys/drags; enabling input starts from a
 *    clean slate, so menu-time presses can't leak into a new race.
 *
 * N-7: the consumed-key preventDefault applies only while a race is
 * running (enabled) — in menus the arrows stay native, so an overflowing
 * start panel remains arrow-scrollable on short viewports.
 *
 * UX-01: Escape/P are EDGE-triggered actions (not holds) delivered through
 * onPause(). The edge channel is deliberately NOT gated on `enabled`: the
 * pause toggle must work while paused too, and pausing calls
 * setEnabled(false). game.js owns the phase filter (running ↔ paused);
 * menu/busting/busted phases simply ignore the event. Key-repeat is
 * suppressed or holding Esc would flip-flop pause/resume.
 */

const KEY_ALIASES = {
    ArrowLeft: 'left', KeyA: 'left',
    ArrowRight: 'right', KeyD: 'right',
    ArrowUp: 'up', KeyW: 'up',
    ArrowDown: 'down', KeyS: 'down',
};

const CONSUMED_KEYS = new Set(Object.keys(KEY_ALIASES));

/** UX-01: one-shot race actions — mapped by physical code like the holds. */
const KEY_EDGE_ACTIONS = {
    Escape: 'pause', KeyP: 'pause',
};

const edgeListeners = { pause: [] };

export function createInput() {
    const held = { left: false, right: false, up: false, down: false };
    let dragSteer = 0;      // -1..1 from pointer drag
    let dragOriginX = null;
    let dragPointerId = null;
    let enabled = false;

    function keyToAction(e) {
        return KEY_ALIASES[e.code];
    }

    /** Drop every held key + drag (blur / re-enable resets). */
    function wipeHeld() {
        held.left = false;
        held.right = false;
        held.up = false;
        held.down = false;
        endDrag();
    }

    window.addEventListener('keydown', (e) => {
        // UX-01: edge actions first — ungated by `enabled` (see module doc),
        // repeat-guarded, and preventDefaulted (neither key has native page
        // behavior worth preserving).
        if (KEY_EDGE_ACTIONS[e.code]) {
            e.preventDefault();
            if (!e.repeat) {
                for (const cb of edgeListeners[KEY_EDGE_ACTIONS[e.code]]) cb();
            }
            return;
        }
        if (!CONSUMED_KEYS.has(e.code)) return; // never touch other keys
        if (!enabled) return; // N-7: menus keep native arrow scrolling for overflowing panels
        e.preventDefault();
        const action = keyToAction(e);
        if (action) held[action] = true;
    });

    window.addEventListener('keyup', (e) => {
        if (!CONSUMED_KEYS.has(e.code)) return;
        const action = keyToAction(e);
        if (action) held[action] = false;
    });

    // Window lost focus (tab switch, alt-tab, app switch): the matching
    // keyups will never arrive, so force-release everything.
    window.addEventListener('blur', wipeHeld);

    // Pointer steering: hold anywhere, drag left/right. Sensitivity is
    // relative to viewport width so it feels identical on phone and desktop.
    const DRAG_FULL_STEER_PX = () => Math.min(160, window.innerWidth * 0.22);

    window.addEventListener('pointerdown', (e) => {
        if (!enabled || dragPointerId !== null) return;
        dragPointerId = e.pointerId;
        dragOriginX = e.clientX;
        // Keep receiving moves/ups even if the pointer leaves the window.
        try { e.target.setPointerCapture(e.pointerId); } catch { /* target gone */ }
    });

    window.addEventListener('pointermove', (e) => {
        if (!enabled || dragOriginX === null || e.pointerId !== dragPointerId) return;
        const full = DRAG_FULL_STEER_PX();
        let dx = e.clientX - dragOriginX;
        // UX-05: saturate-and-reanchor. The old fixed anchor made reversing
        // direction cost a ~2×full-deflection sweep back across the screen
        // (or a lift-and-repress, which zeroed steering). Once the finger
        // passes full deflection the anchor now follows it, so the held
        // steer stays saturated AND the first millimeter back toward center
        // immediately de-steers — correction in place, no full-screen sweep.
        if (dx > full) { dragOriginX = e.clientX - full; dx = full; }
        else if (dx < -full) { dragOriginX = e.clientX + full; dx = -full; }
        dragSteer = dx / full;
    });

    const endDrag = () => {
        dragOriginX = null;
        dragPointerId = null;
        dragSteer = 0;
    };
    window.addEventListener('pointerup', endDrag);
    window.addEventListener('pointercancel', endDrag);

    return {
        /** Enable steering inputs only while a race is running. */
        setEnabled(value) {
            enabled = value;
            // Both transitions start from a clean slate: disabling must not
            // leave a drag dangling, enabling must not inherit stale keys.
            wipeHeld();
        },

        /** UX-01: register a pause-toggle callback (Escape / P, edge-fired). */
        onPause(cb) {
            edgeListeners.pause.push(cb);
        },

        /** -1 (left) .. 1 (right). Keyboard wins only when pressed. */
        steer() {
            if (held.left) return -1;
            if (held.right) return 1;
            return dragSteer;
        },

        /** +1 (push), -1 (brake), 0 — the ported up/down intent. */
        throttle() {
            if (held.up) return 1;
            if (held.down) return -1;
            return 0;
        },
    };
}
