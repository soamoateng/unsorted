import * as THREE from 'three';
import { WORLD, COLORS } from './config.js';

/**
 * road.js — endless highway illusion.
 *
 * KISS insight from the 2D original: only *patterned* things need to scroll.
 * The asphalt plane and shoulders are uniform, so they stay static; the lane
 * dashes recycle (the exact same trick as the original's `.line` divs, just
 * in 3D with shared geometry/material and a delta-time-correct speed).
 */

const DASH_LENGTH = 3;
const DASH_GAP = 3;
const DASH_STEP = DASH_LENGTH + DASH_GAP;
const DASH_HEIGHT = 0.02;

export function createRoad(scene) {
    const road = new THREE.Group();
    scene.add(road);

    // --- Static uniform surfaces -------------------------------------------
    const asphalt = new THREE.Mesh(
        new THREE.PlaneGeometry(WORLD.roadWidth, 400),
        new THREE.MeshStandardMaterial({ color: COLORS.road, roughness: 0.94, metalness: 0 })
    );
    asphalt.rotation.x = -Math.PI / 2;
    asphalt.position.set(0, 0, -150);
    asphalt.receiveShadow = true;
    road.add(asphalt);

    const ground = new THREE.Mesh(
        new THREE.PlaneGeometry(600, 600),
        new THREE.MeshStandardMaterial({ color: COLORS.ground, roughness: 1 })
    );
    ground.rotation.x = -Math.PI / 2;
    ground.position.set(0, -0.05, -100);
    road.add(ground);

    const shoulderGeo = new THREE.BoxGeometry(0.5, 0.12, 400);
    const shoulderMat = new THREE.MeshStandardMaterial({ color: COLORS.barrier, roughness: 0.8 });
    for (const side of [-1, 1]) {
        const shoulder = new THREE.Mesh(shoulderGeo, shoulderMat);
        shoulder.position.set(side * (WORLD.roadWidth / 2 + 0.25), 0.06, -150);
        road.add(shoulder);
    }

    // --- Scrolling lane dashes (3 dividers x N segments) --------------------
    const dashGeo = new THREE.BoxGeometry(0.22, DASH_HEIGHT, DASH_LENGTH);
    const dashMat = new THREE.MeshBasicMaterial({ color: COLORS.dash });
    const dashes = [];

    const dividers = WORLD.laneX.slice(0, -1).map((x, i) => (x + WORLD.laneX[i + 1]) / 2);
    const totalSpan = WORLD.fogFar - WORLD.despawnZ + 20; // a little past the fog wall
    const perLine = Math.ceil(totalSpan / DASH_STEP);

    for (const x of dividers) {
        for (let i = 0; i < perLine; i++) {
            const dash = new THREE.Mesh(dashGeo, dashMat);
            dash.position.set(x, DASH_HEIGHT / 2, WORLD.despawnZ + i * DASH_STEP);
            road.add(dash);
            dashes.push(dash);
        }
    }

    /** Move dashes toward the camera and recycle — the 2D moveLines(), fixed. */
    function scroll(distance) {
        for (const dash of dashes) {
            dash.position.z += distance;
            if (dash.position.z > WORLD.despawnZ + DASH_LENGTH) {
                dash.position.z -= perLine * DASH_STEP;
            }
        }
    }

    return { scroll };
}
