# OnTheRun

A 3D endless police-chase driving game for the browser, built from the
boilerplate of the classic 2D DOM-based *Car-Game* (SahilAtahar) and six
community car models. Outdrive highway traffic — every crash makes you
stumble and lets the law close in. Get caught and you're **BUSTED**.

## Version

**1.0.0 (iteration 8)** — 2026-09-22

- **iteration 1** — initial build: no-build ES-module architecture (13
  single-responsibility modules), three.js 0.186.0 via import map, full
  menu → car-picker → chase → BUSTED → restart loop.
- **iteration 2** — hardening pass: GLB path resolution (`assets/cars/`
  prefix), `THREE.Clock` → `THREE.Timer` (r183+ deprecation),
  `PCFSoftShadowMap` → `PCFShadowMap` (removed constant), missing `.hide`
  CSS rule, player yaw facing (glTF +Z convention), traffic spawn distance
  tuning; end-to-end flows re-verified error-free in headless Chromium.
- **iteration 3** — full-category error audit fix pack:
  - traffic pool recycling no longer leaks a stale knock-fling into
    respawned cars (drift + spin while collidable), and the knock
    flourish hard-stops instead of decaying forever;
  - state-reset gaps closed — BUSTED → *change car* now hides the police
    car and freezes nothing (no frozen traffic or half-busted cop around
    the menu), and the showcased player car is re-centered;
  - the police car is properly staged (hidden until a race starts, then
    snapped to its start position — no origin overlap at boot);
  - WASD now uses physical-key codes, so it works on non-Latin keyboard
    layouts (AZERTY, Cyrillic, …);
  - sticky-input edges fixed: pointer capture + pointer-id guard for
    drags, window-blur wipes held keys, and enabling input starts from a
    clean slate;
  - dead code removed, all flourish constants moved into `config.js`,
    WebGL context-loss notice added, basic keyboard accessibility for
    the picker and prompts, zoom no longer force-disabled.
- **iteration 4** — boot visibility & loading overhaul (the "endless silent
  loading screen" fix):
  - loading progress is now byte-accurate — a real progress bar plus
    `Loading cars 43% — 2.4 / 5.6 MB (3/6)…`, using the GLTFLoader
    per-file `ProgressEvent` that was previously discarded;
  - fixed the bug that made all of this necessary: progress and error
    messages were routed through a start-screen controller that does not
    exist yet during the asset load, so every update was silently dropped
    and the prompt sat frozen at the static placeholder text;
  - a boot watchdog (plain inline script, runs before any module) now
    speaks when the game code never gets the chance: escalating status
    at 10/30/60 s, an explicit explanation when opened via `file://`
    (modules are blocked there), and Google Fonts load non-blocking so
    the boot UI always paints;
  - a stalled download (zero bytes for 20 s) fails loudly into a fatal
    panel with a **Reload** button instead of hanging forever; fatal
    paths also stand the watchdog down so it cannot talk over them.
- **iteration 5** — fix pack from the post-iter4 full-category audit
  (N-1…N-8; hygiene and documentation only, zero gameplay changes):
  - timer hygiene: the asset-loader stall poller now clears on every
    settlement path (including per-file errors), and the inline boot
    watchdog interval is captured and cleared the moment the boot
    settles — no wake-ups for the rest of the page's life;
  - a fatal load error now **aborts all in-flight model downloads**
    (shared `AbortController`) instead of letting stray bytes stream in
    behind the fatal panel — transfers run on a manual `fetch()` with
    byte-level progress, then hand the buffer to `GLTFLoader.parse()`;
  - the progress summary's `file` field now names the download actually
    in flight (previously a manifest-position guess that misnamed under
    parallel, out-of-order loads);
  - the knock-fling damping uses the exact exponential form
    `v *= e^(−0.8·dt)` — identical tuned feel, frame-rate independent by
    construction — and the config comment now states the literal decay
    (≈55% of fling velocity lost per second) instead of the misleading
    "80% per second" label;
  - arrow-key `preventDefault` applies only while a race is running, so
    an overflowing start panel is arrow-scrollable on short viewports;
  - a stale `main.js` comment was rewritten, and the idle-at-x=0
    between-lane escape is documented as an intended balance decision
    (see Hardening Notes).
- **iteration 6** — F-1…F-10 re-verification pass over the accumulated
  modifications, closing the last two open items (zero gameplay changes):
  - F-1 completed to the letter of the prescription: `traffic.reset()`
    now also zeroes `flingVx` on pooled cars (spawnOne was already the
    single re-initialization point — this is defense in depth);
  - F-8 residual closed: the stumble-wobble constants (18 rad/s, 0.06 rad
    at the old player.js:56) moved into `config.js` as
    `PLAYER.wobbleRate` / `PLAYER.wobbleAmp` — the last flourish family
    that lived outside the config module;
  - all other F-items verified fixed in place with file:line evidence
    (F-2 game.js:54-55, F-3 player.js:79, F-4 police.js:38/48-52/104,
    F-5 input.js:18-23, F-6 input.js:62/73, F-7 zero residue, F-9
    scene.js:76-81, F-10 index.html:6/26-33 + main.js:118-121); a full
    config-constant sweep found no dead values.
- **iteration 7** — UI fix pack from the three-category bug audit
  (`ui_bugs.md`, findings UI-01…UI-09; presentation only, zero gameplay
  changes):
  - the panel-wide uppercase transform no longer corrupts precision text
    — the `file://` guidance now renders `python3 -m http.server 8000`
    verbatim instead of "PYTHON3 -M HTTP.SERVER 8000" (UI-01);
  - contrast repairs driven by the WCAG math: score HUD ink darkened
    (2.10:1 → 6.9:1 on the green panel), start/restart CTAs moved onto a
    dark plate (2.77:1 → 14.6:1), tagline/controls switched to warm dark
    ink (≈3.2:1 → 5.2:1), with a white variant for the controls line on
    the dark BUSTED panel (UI-02/03/04);
  - readable typography floor: controls 10.9 px → 12 px, card names
    9.9 px → 12 px (UI-05);
  - a `:focus-visible` outline contract for every keyboard-focusable
    control on both panel colors (UI-06);
  - the selected car card now inverts to a yellow fill with dark ink
    instead of a near-invisible red-on-red shift (UI-07);
  - the start/restart/reload prompts are real buttons — dark plate, yellow
    border, hover/active states, pointer cursor only in button states —
    keyed off `role="button"`, whose semantics now track the ready state
    in `ui.js` (a focusable "button" that silently no-ops during loading
    was a false affordance) (UI-08);
  - picker thumbnails blend into their cards: the letterbox background now
    matches the render scene exactly (UI-09);
  - blind-spot fix: card images no longer start a native browser drag
    (`img.draggable = false`) — a default-draggable image inside a
    role=button control swallowed clicks with a drag ghost.
  Verified: syntax + cross-file gates clean, headless Chromium pass over
  boot → menu → focus → race → BUSTED → restored menu → `file://` with
  zero console errors; all contrast values re-measured from the shipped
  hex values.
- **iteration 8** — UX fix pack from the three-category bug audit
  (`ux_bugs.md`, findings UX-01…UX-16; interaction/feedback layer only —
  zero changes to speeds, gaps, physics or any tuned constant):
  - **Pause (UX-01)**: a real `paused` phase — Esc or P toggles it, an
    on-screen `II` button (visible while racing) does too, and the freeze
    happens behind a PAUSED overlay with Resume / quit-to-menu prompts;
    the render loop keeps running so resume continues the exact frame.
  - **No-JS honesty (UX-02)**: a static `<noscript>` notice now tells
    JS-disabled users why "Loading cars…" will never progress.
  - **Tab-return safety (UX-03)**: hiding the tab mid-run auto-parks the
    race in the pause overlay — returning players re-orient in a frozen
    world and resume explicitly instead of inheriting live traffic.
  - **Throttle/brake documented (UX-04)**: the controls copy states the
    Up/W, Down/S multipliers' trade-off (+speed +risk / brake).
  - **Drag steering re-anchor (UX-05)**: once a touch-drag saturates, the
    anchor follows the finger — direction reverses in place instead of
    demanding a full-screen sweep back through a frozen origin.
  - **Sound + haptics (UX-06)**: new `js/audio.js` (14th module) adds
    synthesized WebAudio cues — crash thud, proximity siren that swells
    as the cop closes, BUSTED sting — plus `navigator.vibrate` on
    collision. The context is created/resumed inside the start gesture;
    every cue degrades to a silent no-op where audio is denied.
  - **Quit route (UX-07)**: a live run can reach the menu again — pause
    (key/button) → *quit to menu* → the existing `toMenu` cleanup. The
    two-step design is deliberate: no single stray keypress can abandon
    a run.
  - **Focus management (UX-08)**: BUSTED → restart prompt, menu restore →
    start prompt, pause → Resume prompt; keyboard users no longer restart
    their Tab journey from `<body>` at the game's highest-frequency
    transitions.
  - **Soft asset retry (UX-09)**: a transient failure (Wi-Fi blip, 5xx)
    now retries the failed file up to 2 times with backoff before the
    boot can go fatal — no more full-page reload re-downloading ~6 MB
    because one request hiccuped. Aborts and permanent errors (404/403,
    corrupt GLB) skip the retries; byte accounting restarts honestly.
  - **Premature-start feedback (UX-10)**: activating the start prompt
    mid-load pulses a halo on the prompt and progress bar instead of
    silently doing nothing.
  - **Score unit (UX-11)**: the HUD and BUSTED panel now say meters —
    "1,376 m", "BEST 921 m" — and the controls copy states the metric.
  - **Live BEST (UX-12)**: the BEST line updates (and badges "· NEW!")
    the moment a run passes the stored best, not only after the bust.
  - **GL-lost Reload (UX-13)**: the banner now embeds the same Reload
    affordance (same classes, same delegation contract) as the fatal
    panel instead of asking for a gesture it never offered.
  - **Picker honesty (UX-14)**: "All cars drive the same — pick your
    look." sits under the cards.
  - **Run summary (UX-15)**: the BUSTED panel prints "Survived 47 s ·
    3 crashes" — data the state machine already held.
  - **Arrow-key picker (UX-16)**: roving-tabindex arrow navigation within
    the card group (←/↑/→/↓, wrapping); the selected card is the single
    Tab stop. This closes the "future work" note from the iter3 a11y pass.
  - Blind-spot companions found and fixed during the pack: the
    `:focus-visible` contract did not cover the new pause overlay or the
    GL-lost banner (both outside `.startScreen`); the pause button could
    have outlived its HUD into the BUSTED panel; retrying a file had to
    zero its byte accounting or the aggregate bar would double-count.
  Verified: syntax + cross-file gates clean (14 modules), a scripted
  unit gate for the input contract (re-anchor math, pause edges), a
  flaky-server boot proving the retry path, and a full headless
  Chromium pass — boot → picker arrows → race → pause/resume via key,
  button and simulated tab-hide → quit-to-menu → record-run HUD badge →
  BUSTED summary → restored menu → audio context running + vibration
  stub fired → `file://` intact, with zero console errors.

## How To Play

- **Steer**: Arrow keys / WASD, or drag horizontally on touch screens.
- **Push / brake**: Up / Down (W / S) slightly raises or lowers your speed
  (faster = more score, more risk).
- **Pause**: Esc or P (or the on-screen `II` button) — resume from the
  overlay, or quit to the menu. Switching tabs mid-run auto-pauses.
- You accelerate automatically. The longer you survive, the faster you go.
- Traffic crashes do **not** kill you instantly — you stumble and the police
  gains on you. Keep crashing and you get **BUSTED**.
- Score = meters survived. Your best score is saved in `localStorage`.

## Running The Game

The game uses native ES modules, so it must be served over HTTP (opening
`index.html` via `file://` will not work — browsers block module scripts on
opaque origins):

```bash
# from this folder — any static server works
python3 -m http.server 8000
# or: npx serve .
```

Then open <http://localhost:8000>.

## Tech Stack (verified current at build time)

- **three.js `0.186.0`** via CDN + import map — no build step, no bundler.
  - `THREE.Timer` (the r183+ replacement for the deprecated `Clock`)
  - `PCFShadowMap` (`PCFSoftShadowMap` was removed in recent three versions)
  - `three/addons/loaders/GLTFLoader.js`
- Vanilla JavaScript ES modules — plain functions and data, no framework.
- The delta-time game loop keeps physics identical on 60 Hz and 144 Hz
  displays (fixing the frame-rate-dependent bug of the original 2D game).

## Project Layout

```
index.html          UI overlay (start screen, car picker, HUD, pause + busted panels)
style.css           visual DNA carried over from the 2D original
js/
  main.js           composition root — wires everything together
  config.js         every tunable (speeds, lanes, gaps, colors, cues) in one place
  game.js           state machine (menu → running ⇄ paused → busting → busted) + loop
  scene.js          renderer, lights, chase-camera rig, THREE.Timer
  assets.js         GLB manifest loading (byte-accurate, retrying, abortable)
  car-factory.js    model normalization (scale/center/facing) + wheel lookup
  road.js           endless-road illusion (recycled dashes, static asphalt)
  player.js         lateral steering, stumble, wheel spin
  traffic.js        pooled obstacle stream with solvable spawn rules
  police.js         chase-gap AI, siren flash, bust animation
  collision.js      pure XZ-overlap helpers
  input.js          keyboard (arrows+WASD+Esc/P) + pointer drag, unified intents
  audio.js          synthesized WebAudio cues + haptics (no audio files)
  ui.js             all DOM access, event-delegated (survives panel swaps)
assets/cars/        six glTF 2.0 models (see credits)
```

## Tuning

Open `js/config.js` — speeds, difficulty ramp, police gap behavior, bust
spin-out and pull-over choreography, traffic density and knock-fling,
hitbox forgiveness, lanes and colors are all plain data there.

## Hardening Notes

- **CDN & integrity**: three.js is pinned to an exact version
  (`0.186.0`) over HTTPS, which is the practical integrity control for an
  import-map module tree (ES modules pull relative addon files, so
  per-file SRI hashes cannot cover the whole graph). For fully offline /
  zero-third-party deployments, vendor `build/three.module.js` plus the
  used `examples/jsm/` files into the project and point the import map at
  them. The Google Fonts stylesheet is intentionally not SRI-pinned —
  Google serves per-UA CSS, which makes static hashes break; the game
  degrades gracefully to `sans-serif` if fonts fail (and the stylesheet
  loads non-blocking, so a hung font CDN cannot delay the boot UI).
- **Boot watchdog**: an inline classic script runs before any module and
  covers the failure modes where `main.js` never gets to speak — `file://`
  module blocking (explained immediately), a hung/blocked CDN fetch for
  three.js (escalating status at 10/30/60 s). It stands down once the
  game is playable or a fatal error takes over messaging.
- **Load stall policy**: if no bytes move for 20 s during the model
  download, the boot fails loudly into a fatal panel with a Reload
  button — a hung transfer can no longer hold the loading screen hostage.
- **Download lifecycle**: model transfers run on a manual `fetch()` with
  byte-level progress and a shared `AbortController`; any fatal load
  error (including the 20 s stall watchdog) aborts every in-flight
  download and clears the loader timers. The stall poller and the boot
  watchdog interval are cleared on all settlement paths. Since the UX fix
  pack, transient per-file failures retry up to 2 times with backoff
  (600 ms / 1.2 s) before the boot can go fatal; deliberate aborts and
  permanent conditions (404/403, a GLB that fails to parse) are never
  retried, and a retrying file zeroes its byte accounting so the
  aggregate progress bar cannot double-count it.
- **Pause & tab-return policy**: Esc/P and the on-screen `II` button park
  a run in the pause overlay (Resume / quit-to-menu); the render loop
  keeps drawing the frozen world so resume is frame-exact. Losing tab
  visibility mid-run triggers the same pause deliberately — the game
  never resumes into live traffic on its own. Quit is a deliberate
  two-step (pause, then quit) so no stray keypress abandons a run.
- **Audio & haptics**: `js/audio.js` synthesizes every cue from WebAudio
  primitives (crash noise-burst, gap-driven proximity siren, BUSTED
  sting) — no audio files to host or download. The `AudioContext` is
  created/resumed inside the start gesture (autoplay-policy safe) and
  every cue is a guarded no-op when audio is unavailable or denied.
  `navigator.vibrate` fires on collisions and the bust where supported.
- **Idle-lane balance (documented as intended)**: a player who never
  steers rests at x=0, exactly between the two center lanes, and can
  thread that gap indefinitely (a hands-off 1,376 m run was observed
  during audit). This is retained deliberately as a low-pressure escape
  corridor for new players; biasing traffic spawns toward the idler was
  considered and rejected as an unauthorized gameplay change.
- **WebGL context loss**: on `webglcontextlost` a notice is shown while
  three.js halts rendering; on `webglcontextrestored` it re-uploads GPU
  resources and play resumes where it was.
- **Thumbnail buffer reads**: picker thumbnails use `toDataURL()` right
  after a synchronous `render()` in the same task — safe without
  `preserveDrawingBuffer`, and avoiding that flag keeps the main loop
  fast. Do not defer the read (see `main.js`).
- **Accessibility**: car cards and prompts are keyboard-activatable
  (Tab + Enter/Space, `role="button"`, `aria-pressed`), and pinch-zoom is
  no longer disabled. The picker group supports roving-tabindex arrow
  navigation (←/↑/→/↓, wrapping) since the UX fix pack, and focus is
  placed on the primary action after every panel swap (BUSTED → restart
  prompt, menu → start prompt, pause → Resume prompt).
- **Storage**: the high score uses `localStorage` inside try/catch, so
  private-mode or storage-blocked browsers simply don't persist.

## Credits & Licenses

- Original 2D game boilerplate: [Car-Game](https://github.com/SahilAtahar/Car-Game)
  by SahilAtahar (MIT — see `LICENSE`).
- `quaternius_cc0-normal-car-1190.glb`, `quaternius_cc0-sports-car-1371.glb`
  — [Quaternius](https://quaternius.com), CC0 / public domain.
- `arunangshubanerjee-police-car-2064.glb`, `ergoninane-fast-71.glb`,
  `ergoninane-fast-72.glb`, `ergoninane-fast-74.glb` — downloaded from
  Sketchfab (authors: Arunangshu Banerjee; ergoninane). Verify the license
  attached to your Sketchfab download before commercial use; some require
  attribution.
