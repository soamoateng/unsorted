#!/usr/bin/env bash
# scripts/smoke.sh — Esekiosk smoke test
#
# Curl every endpoint and expect 200, 401, 403, or 405 — NEVER a 500 or timeout.
# Run after starting the server:
#   cd /path/to/esekiosk && python3 -m http.server 8080 &
#   BASE_URL=http://localhost:8080/esekiosk ./scripts/smoke.sh
#
# Exit codes: 0 = all pass, 1 = at least one failure.

set -u

BASE="${BASE_URL:-http://localhost:8080/esekiosk}"
PASS=0
FAIL=0
FAILURES=()

check() {
  local path="$1"
  local expected="$2"
  local method="${3:-GET}"
  local code
  code=$(curl -s -o /dev/null -w "%{http_code}" -X "$method" "${BASE}${path}" 2>/dev/null)
  IFS=',' read -ra EXPECTED <<< "$expected"
  local ok=0
  for e in "${EXPECTED[@]}"; do
    if [ "$code" = "$e" ]; then ok=1; break; fi
  done
  if [ "$ok" = "1" ]; then
    printf "  \033[32mPASS\033[0m %-50s -> %s (expected %s)\n" "$method $path" "$code" "$expected"
    PASS=$((PASS + 1))
  else
    printf "  \033[31mFAIL\033[0m %-50s -> %s (expected %s)\n" "$method $path" "$code" "$expected"
    FAIL=$((FAIL + 1))
    FAILURES+=("$method $path -> $code (expected $expected)")
  fi
}

echo "=== Esekiosk smoke test ==="
echo "Base URL: $BASE"
echo ""

echo "--- Static assets (expect 200) ---"
check "/"                       200
check "/index.html"             200
check "/css/styles.css"         200
check "/js/app.js"              200
check "/js/router.js"           200
check "/js/services/api.js"     200
check "/js/services/paystack.js" 200
check "/js/views/storefrontView.js" 200
check "/js/views/dashboardView.js" 200
check "/js/views/adminDashboardView.js" 200
check "/assets/img/hero-3.jpg"  200

echo ""
echo "--- .env protection (expect 403 or 404) ---"
check "/api/config/.env"        "403,404"
# Note: .env.example is intentionally public (it's a template with placeholder values).

echo ""
echo "--- PHP endpoints (expect 200, 401, 403, or 405) ---"
echo "NOTE: requires Apache + PHP (XAMPP). Python's http.server will return 404 for .php files."
check "/api/auth/get_session.php"                "200,401"  GET
check "/api/auth/signup.php"                       "400,405"  GET
check "/api/auth/login.php"                        "400,405"  GET
check "/api/auth/logout.php"                      "401,405"  GET
check "/api/products/get_products.php?store=test" "200,404"  GET
check "/api/products/get_products.php?wholesale=1" "401,403" GET
check "/api/products/add_product.php"            "401,405"  GET
check "/api/products/clone_product.php"          "401,405"  GET
check "/api/orders/initialize_checkout.php"      "400,405"  GET
check "/api/orders/get_orders.php"                "401,405"  GET
check "/api/orders/update_order_status.php"      "401,405"  GET
check "/api/webhooks/paystack_webhook.php"       "200"      POST

echo ""
echo "=== Summary ==="
printf "Pass: %d\n" "$PASS"
printf "Fail: %d\n" "$FAIL"
if [ "$FAIL" -gt 0 ]; then
  echo ""
  echo "Failures:"
  for f in "${FAILURES[@]}"; do
    printf "  - %s\n" "$f"
  done
  exit 1
fi
echo ""
echo "All endpoints responded with expected status codes. No 500s detected."
exit 0
