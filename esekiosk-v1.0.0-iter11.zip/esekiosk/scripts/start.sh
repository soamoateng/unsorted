#!/usr/bin/env bash
# scripts/start.sh — start the Esekiosk frontend workspace
#
# Usage:
#   ./scripts/start.sh          # serves on http://localhost:8000/esekiosk/
#   PORT=8080 ./scripts/start.sh # custom port
#
# This serves the FRONTEND only. The PHP backend requires XAMPP (Apache + PHP + MySQL):
#   1. Copy the esekiosk/ folder into htdocs/
#   2. Run: mysql -u root -p < api/schema.sql
#   3. cp api/config/.env.example api/config/.env  (then fill in Paystack + DB credentials)
#   4. Visit http://localhost/esekiosk/
#
# With this Python server (no PHP), the storefront will render with the demo catalog
# from js/data/products.js. The signup/signin/dashboard views will render their UI
# but backend calls (/api/...) will fail — that's expected without XAMPP.

set -u
PORT="${PORT:-8000}"
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

# Kill any previous server on the same port
pkill -f "http.server ${PORT}" 2>/dev/null
sleep 0.3

echo "Starting Esekiosk workspace on port ${PORT}..."
echo "  Serving from: ${DIR}"
echo "  URL:          http://localhost:${PORT}/esekiosk/"
echo ""
echo "Routes (open in a browser):"
echo "  Storefront (demo catalog): http://localhost:${PORT}/esekiosk/"
echo "  Welcome / pricing cards:   http://localhost:${PORT}/esekiosk/#/welcome"
echo "  Sign in form:              http://localhost:${PORT}/esekiosk/#/signin"
echo "  Sign up form:              http://localhost:${PORT}/esekiosk/#/signup?role=merchant&cycle=monthly"
echo "  Merchant dashboard:       http://localhost:${PORT}/esekiosk/#/dashboard"
echo "  Admin dashboard (stubs):   http://localhost:${PORT}/esekiosk/#/admin"
echo "  Reseller inventory:       http://localhost:${PORT}/esekiosk/#/inventory"
echo ""
echo "Press Ctrl+C to stop."

cd "${DIR}/.." && exec python3 -m http.server "${PORT}" --bind 0.0.0.0
