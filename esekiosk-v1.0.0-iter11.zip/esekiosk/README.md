# Esekiosk — Intra-City Dropshipping Platform (v1.0.0)

Ghana's intra-city dropshipping platform. Merchants list wholesale inventory, resellers clone at a markup, and Paystack split-checkout pays both out instantly.

Built with **vanilla JavaScript (ES6 modules)** + **HTML5** + **CSS3** frontend, **PHP 8.0+** + **PDO (MySQL)** backend, and **Paystack** for payments. No frameworks, no build step, no dependencies.

## Quick start (XAMPP)

1. **Unzip** the project into your XAMPP `htdocs/` directory:
   ```
   htdocs/
   └── esekiosk/
       ├── index.html
       ├── .htaccess
       ├── css/
       ├── js/
       ├── api/
       └── ...
   ```

2. **Start Apache + MySQL** from the XAMPP control panel.

3. **Create the database**:
   ```bash
   mysql -u root -p < /path/to/esekiosk/api/schema.sql
   ```
   This creates 8 tables (users, auth_sessions, kyc_reviews, products, orders, order_items, merchant_ledger, app_settings) with FKs, indexes, and seeded pricing.

4. **Configure secrets**:
   ```bash
   cp /path/to/esekiosk/api/config/.env.example /path/to/esekiosk/api/config/.env
   ```
   Edit `.env` and fill in:
   - `PAYSTACK_SECRET_KEY` — your Paystack secret key (`sk_live_...` or `sk_test_...`)
   - `PAYSTACK_PUBLIC_KEY` — your Paystack public key (`pk_live_...` or `pk_test_...`)
   - `DB_HOST`, `DB_NAME`, `DB_USER`, `DB_PASSWORD` — your MySQL credentials
   - `APP_BASE_URL` — your app URL (e.g., `http://localhost/esekiosk` for local)
   - `APP_ALLOWED_ORIGINS` — comma-separated list of allowed origins for CORS
   - `PAYSTACK_COURIER_SUBACCOUNT` — optional courier subaccount code for delivery fees

5. **Visit the app**: `http://localhost/esekiosk/`

## Project structure

```
esekiosk/
├── index.html             ← SPA entry point
├── .htaccess              ← SPA fallback + CSP + security headers + .env protection
├── README.md
├── css/styles.css         ← Design system (green theme from eStore boilerplate)
├── assets/img/*.jpg       ← 22 product/hero/promo images
├── js/                    ← 28 ES6 modules
│   ├── app.js             ← Boot
│   ├── router.js          ← Hash + path SPA router (subdirectory-aware)
│   ├── components/        ← toast, layerManager, slider, kycUploader, addProductSheet
│   ├── data/products.js   ← Demo catalog (pesewas prices)
│   ├── services/          ← api.js (fetch wrapper), paystack.js (InlineJS V2)
│   ├── state/             ← pubsub, authStore, cartStore, searchStore
│   ├── utils/             ← escape, format, prefersReducedMotion, keyboard, orderStatus
│   └── views/             ← welcome, signup, signin, renew, storefront, dashboard, adminDashboard, resellerInventory, product
├── api/                   ← PHP backend
│   ├── config/           ← env, database, cors, paystack, momo_helper, csrf, .env (gitignored)
│   ├── middleware/        ← auth, sanitize
│   ├── endpoints/
│   │   ├── auth/          ← signup, login, get_session, logout
│   │   ├── kyc/           ← review_kyc (admin)
│   │   ├── products/      ← add_product, get_products, clone_product
│   │   ├── orders/        ← initialize_checkout, get_orders, update_order_status
│   │   └── admin/         ← metrics, update_pricing, ledger
│   ├── webhooks/          ← paystack_webhook (HMAC-SHA512, idempotent, activates user + creates subaccount)
│   ├── cron/              ← create_subaccounts.php (CLI — retries subaccount_pending=1 every 5 min)
│   ├── uploads/           ← user images (PHP engine off via .htaccess)
│   └── schema.sql
└── scripts/
    └── smoke.sh           ← Endpoint smoke test (curl every URL, expect 200/401/403/405)
```

## Features

### Customer-facing
- **Storefront** (`#/store/<slug>`) — CSS Grid `repeat(auto-fill, minmax(180px, 1fr))`, IntersectionObserver lazy-load, Paystack split checkout
- **Cart** — localStorage with in-memory fallback for Incognito mode
- **Checkout** — delivery form (name, phone, GhanaPost GPS, street, instructions) → Paystack popup → instant split payout to merchant + reseller + courier

### Merchant dashboard (`#/dashboard`)
- Responsive shell: desktop sidebar ↔ mobile bottom-nav
- Orders tab with item-level status (Pending → Processing → Shipped → Delivered)
- Mixed-cart support (each item shows its fulfillment merchant + reseller)
- Product upload (bottom-sheet, GD-compressed images, `finfo_file` real-MIME check)

### Reseller features
- Browse merchant wholesale inventory (`#/inventory`)
- Clone products with retail > wholesale validation
- Stock resolves against the merchant's live inventory (no separate stock column)

### Owner Admin (`#/admin`)
- 10 KPI cards: total merchants/resellers/active, MRR, KYC pending, subaccount pending, orders by status, outstanding debt, revenue (30d)
- Top 10 stores by GMV (30 days)
- Recent signups (7 days)
- Auto-refresh every 30 seconds
- Admin KYC review queue (approve/reject)
- Outstanding debt ledger (manual recovery)
- Pricing CRUD (app_settings) with secret-key blocklist

## Security

- **XSS** — `escapeHTML()` on every backend string interpolation
- **CSRF** — token issued on login/session, required on all mutations via `X-CSRF-Token` header
- **IDOR** — auth middleware on every protected endpoint; ownership checks on every resource
- **SQL injection** — PDO prepared statements with `ATTR_EMULATE_PREPARES => false`
- **Session** — HttpOnly + Secure + SameSite=Lax cookie; SHA-256 hashed in DB; 720h TTL; rotation on privilege change
- **Paystack webhook** — HMAC-SHA512 signature with `hash_equals` (timing-safe); idempotent via `orders.paystack_reference` UNIQUE
- **File uploads** — `finfo_file()` real-MIME check; GD re-encode strips payloads; `bin2hex(random_bytes(8))` filenames; PHP engine off in `/uploads/`
- **Secrets** — `.env` file (gitignored); blocked by `.htaccess` at root + `api/config/`; never stored in DB
- **Headers** — CSP, X-Frame-Options: SAMEORIGIN, X-Content-Type-Options: nosniff, Referrer-Policy, HSTS, Permissions-Policy
- **Race conditions** — `SELECT ... FOR UPDATE` row-locking during checkout
- **Privilege escalation** — server rejects `role='admin'` from client; whitelisted fields only

## Carry-overs from adversarial stress tests

This codebase was built with a fact-checker + refactoring specialist reviewing every claim and code file against August 2026 reality:

- **Telecel, not Vodafone** — Vodafone Ghana rebranded to Telecel in Feb 2024. `momo_helper.php` uses `TELECEL` (bank code remains `VOD` per Paystack).
- **MAX_SPLITS = 5** — self-imposed cap, NOT a Paystack-documented limit.
- **No Tesseract OCR** — Ghana Card is uploaded + admin-reviewed (no binary dependency).
- **`hash_equals()`** for Paystack webhook signature (timing-safe).
- **Tightened GPS regex** — `/^[A-Z]{2}-\d{3}-\d{4}$/` (not `\d{3,4}`).
- **User-selected MoMo network** — not prefix-guessed (MNP-safe).
- **Paystack InlineJS V2** — `new PaystackPop().resumeTransaction(access_code)`.
- **utf8mb4_unicode_ci** — portable across MySQL 5.7 / 8.0 / MariaDB 10.x.
- **Subdirectory hosting** — auto-detected via `import.meta.url`.

## Browser support

Chrome / Edge / Firefox / Safari (current versions, Aug 2026). Uses ES6 modules, `IntersectionObserver`, `inert` attribute, CSS custom properties, `prefers-reduced-motion`.

## Cron jobs

Schedule via `crontab -e`:

```cron
# Retry failed Paystack subaccount creation every 5 minutes
*/5 * * * * /usr/bin/php /path/to/esekiosk/api/cron/create_subaccounts.php >> /var/log/esekiosk-cron.log 2>&1
```

## Smoke test

```bash
# Start Apache (XAMPP) then:
cd /path/to/esekiosk
BASE_URL=http://localhost/esekiosk ./scripts/smoke.sh
```

Expects: all static assets 200, `.env` blocked (403/404), all PHP endpoints return 200/401/403/405 (never 500).

## License

Original code, MIT-style. Adapted from the eStore boilerplate (also MIT-style).
