// js/utils/escape.js
// Single source of truth for HTML escaping. Use on EVERY string interpolation
// into innerHTML where the string originates from user input or the backend.
//
// SRP: this module owns XSS prevention, nothing else.
// KISS: one function, five replacements, no dependencies.

/**
 * Escapes the five HTML-significant characters.
 * @param {string} str
 * @returns {string} safe to interpolate into innerHTML / template literals
 */
export function escapeHTML(str) {
  if (str == null) return "";
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

/** Escapes for use inside a `href="..."` or `data-foo="..."` attribute value. */
export function escapeAttr(str) {
  return escapeHTML(str);
}
