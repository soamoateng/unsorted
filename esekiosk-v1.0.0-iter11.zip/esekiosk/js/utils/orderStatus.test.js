// js/utils/orderStatus.test.js
// Unit tests for orderStatus.js — pure functions, no DOM, no I/O.
// Run with: node --test js/utils/orderStatus.test.js
// (Node 18+ has a built-in test runner)

import { test } from "node:test";
import { strict as assert } from "node:assert";
import { computeOverallStatus, nextStatus, isValidTransition } from "./orderStatus.js";

// --- computeOverallStatus ---

test("computeOverallStatus: empty array → 'pending'", () => {
  assert.equal(computeOverallStatus([]), "pending");
});

test("computeOverallStatus: non-array → 'pending'", () => {
  assert.equal(computeOverallStatus(null), "pending");
  assert.equal(computeOverallStatus(undefined), "pending");
  assert.equal(computeOverallStatus({}), "pending");
});

test("computeOverallStatus: single pending → 'pending'", () => {
  assert.equal(computeOverallStatus([{ status: "pending" }]), "pending");
});

test("computeOverallStatus: all pending → 'pending'", () => {
  assert.equal(
    computeOverallStatus([{ status: "pending" }, { status: "pending" }]),
    "pending"
  );
});

test("computeOverallStatus: single delivered → 'delivered'", () => {
  assert.equal(computeOverallStatus([{ status: "delivered" }]), "delivered");
});

test("computeOverallStatus: all delivered → 'delivered'", () => {
  assert.equal(
    computeOverallStatus([{ status: "delivered" }, { status: "delivered" }]),
    "delivered"
  );
});

test("computeOverallStatus: CRITICAL FIX — all cancelled → 'cancelled' (was 'delivered')", () => {
  assert.equal(
    computeOverallStatus([{ status: "cancelled" }, { status: "cancelled" }]),
    "cancelled"
  );
});

test("computeOverallStatus: some cancelled + rest delivered → 'delivered' (PRD rule)", () => {
  assert.equal(
    computeOverallStatus([{ status: "cancelled" }, { status: "delivered" }]),
    "delivered"
  );
});

test("computeOverallStatus: in-flight + delivered → 'partially_shipped'", () => {
  assert.equal(
    computeOverallStatus([{ status: "shipped" }, { status: "delivered" }]),
    "partially_shipped"
  );
  assert.equal(
    computeOverallStatus([{ status: "pending" }, { status: "delivered" }]),
    "partially_shipped"
  );
  assert.equal(
    computeOverallStatus([{ status: "processing" }, { status: "delivered" }]),
    "partially_shipped"
  );
});

test("computeOverallStatus: in-flight, no delivered → 'processing'", () => {
  assert.equal(
    computeOverallStatus([{ status: "processing" }, { status: "shipped" }]),
    "processing"
  );
  assert.equal(
    computeOverallStatus([{ status: "pending" }, { status: "processing" }]),
    "processing"
  );
});

test("computeOverallStatus: null/undefined items tolerated (defaults to 'pending')", () => {
  // [null, delivered] → ["pending", "delivered"] → partially_shipped (in-flight + delivered)
  assert.equal(
    computeOverallStatus([null, { status: "delivered" }]),
    "partially_shipped"
  );
  // [undefined, undefined] → ["pending", "pending"] → pending
  assert.equal(
    computeOverallStatus([undefined, undefined]),
    "pending"
  );
});

// --- nextStatus ---

test("nextStatus: pending → processing", () => {
  assert.equal(nextStatus("pending"), "processing");
});

test("nextStatus: processing → shipped", () => {
  assert.equal(nextStatus("processing"), "shipped");
});

test("nextStatus: shipped → delivered", () => {
  assert.equal(nextStatus("shipped"), "delivered");
});

test("nextStatus: delivered → null (terminal)", () => {
  assert.equal(nextStatus("delivered"), null);
});

test("nextStatus: cancelled → null (terminal)", () => {
  assert.equal(nextStatus("cancelled"), null);
});

test("nextStatus: unknown status → null", () => {
  assert.equal(nextStatus("unknown"), null);
});

// --- isValidTransition ---

test("isValidTransition: pending → processing (single-step forward) → true", () => {
  assert.equal(isValidTransition("pending", "processing"), true);
});

test("isValidTransition: processing → shipped → true", () => {
  assert.equal(isValidTransition("processing", "shipped"), true);
});

test("isValidTransition: shipped → delivered → true", () => {
  assert.equal(isValidTransition("shipped", "delivered"), true);
});

test("isValidTransition: pending → shipped (SKIP — multi-step) → false", () => {
  assert.equal(isValidTransition("pending", "shipped"), false);
});

test("isValidTransition: pending → delivered (SKIP) → false", () => {
  assert.equal(isValidTransition("pending", "delivered"), false);
});

test("isValidTransition: delivered → cancelled (terminal → cancel) → false", () => {
  assert.equal(isValidTransition("delivered", "cancelled"), false);
});

test("isValidTransition: cancelled → pending (terminal → revive) → false", () => {
  assert.equal(isValidTransition("cancelled", "pending"), false);
});

test("isValidTransition: pending → cancelled (cancel from non-terminal) → true", () => {
  assert.equal(isValidTransition("pending", "cancelled"), true);
});

test("isValidTransition: processing → cancelled → true", () => {
  assert.equal(isValidTransition("processing", "cancelled"), true);
});

test("isValidTransition: shipped → cancelled → true", () => {
  assert.equal(isValidTransition("shipped", "cancelled"), true);
});

test("isValidTransition: same status → false", () => {
  assert.equal(isValidTransition("pending", "pending"), false);
  assert.equal(isValidTransition("delivered", "delivered"), false);
});

test("isValidTransition: unknown status → false", () => {
  assert.equal(isValidTransition("unknown", "pending"), false);
  assert.equal(isValidTransition("pending", "unknown"), false);
});
