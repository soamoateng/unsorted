// js/utils/format.js
// Display formatters. Pure functions, no DOM, no I/O — unit-testable in isolation.
//
// SRP: this module owns the display format of money, dates, and star ratings.
// KISS: three exports, no Formatter class.

/** Currency lock per Phase 1 spec: GHS only. UI select is hidden but kept for future multi-currency. */
export const CURRENCY = Object.freeze({
  code: "GHS",
  symbol: "₵",
  locale: "en-GH",
});

/**
 * Format an integer pesewa amount as a GHS string.
 * @param {number} pesewas integer; 1 GHS = 100 pesewas
 * @returns {string} e.g. "₵49.00" or "₵1,234.56"
 */
export function formatPesewas(pesewas) {
  const n = Math.round(Number(pesewas) || 0);
  const cedis = n / 100;
  return CURRENCY.symbol + cedis.toLocaleString(CURRENCY.locale, {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
}

/**
 * Format an ISO 8601 date string as a short, locale-friendly date.
 * @param {string} iso e.g. "2026-09-21T10:30:00Z"
 * @returns {string} e.g. "21 Sep 2026"
 */
export function formatDate(iso) {
  if (!iso) return "";
  const d = new Date(iso);
  if (isNaN(d.getTime())) return "";
  return d.toLocaleDateString(CURRENCY.locale, {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });
}

/**
 * Render a star rating as an inline SVG string.
 * Replaces the boilerplate's entity-based starsHTML() — accessible + crisp at any DPI.
 * @param {number} rating 0..5 (decimals supported, rounds to nearest 0.5)
 * @returns {string} SVG markup; 5 star shapes, partial fill via clipPath
 */
export function starsSVG(rating) {
  const r = Math.max(0, Math.min(5, Number(rating) || 0));
  const rounded = Math.round(r * 2) / 2; // nearest 0.5
  const fullCount = Math.floor(rounded);
  const hasHalf = rounded % 1 !== 0;

  // FIX: generate a unique id prefix per call so multiple starsSVG calls on the same
  // page don't collide (was reusing "s1", "s0.5" etc. across all calls → invalid HTML,
  // url(#s1) resolved to the FIRST s1 in the document).
  const uid = "str" + Math.random().toString(36).slice(2, 8);

  // FIX: include the star index `i` in the clipPath id so the 3 full stars within
  // a single call don't share the same id (e.g., strXXX-0-1, strXXX-1-1, strXXX-2-1).
  const star = (i, fillPct) =>
    `<svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true">` +
    `<defs><clipPath id="${uid}-${i}-${fillPct}"><rect x="0" y="0" width="${fillPct * 24}" height="24"/></clipPath></defs>` +
    `<path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" ` +
    `fill="#e3e9e6" stroke="#e3e9e6" stroke-width="1"/>` +
    `<path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" ` +
    `fill="var(--amber, #f2a71b)" stroke="var(--amber, #f2a71b)" stroke-width="1" clip-path="url(#${uid}-${i}-${fillPct})"/></svg>`;

  const fillPctFor = (i) => {
    if (i < fullCount) return 1;
    if (i === fullCount && hasHalf) return 0.5;
    return 0;
  };
  const stars = Array.from({ length: 5 }, (_, i) => star(i, fillPctFor(i)));
  return `<span class="stars" role="img" aria-label="${rounded} out of 5">${stars.join("")}</span>`;
}
