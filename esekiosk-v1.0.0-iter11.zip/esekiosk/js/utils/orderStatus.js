// js/utils/orderStatus.js
// Pure helper: compute the parent order's overall status from its items' statuses.
//
// SRP: owns the order-status aggregation logic. No DOM, no I/O — unit-testable.
// KISS: pure functions, no class.
//
// Rules (PRD):
//   - If ALL items are 'delivered' → 'delivered'
//   - If ALL items are 'cancelled' → 'cancelled'  (CRITICAL FIX: was 'delivered')
//   - If SOME are 'cancelled' and the rest are 'delivered' → 'delivered'
//   - If ANY item is still in-flight (pending/processing/shipped) AND any are 'delivered' → 'partially_shipped'
//   - If ALL items are 'pending' → 'pending'
//   - Otherwise → 'processing' (some items have started but none delivered yet)

const IN_FLIGHT = new Set(["pending", "processing", "shipped"]);
const TERMINAL = new Set(["delivered", "cancelled"]);

/**
 * @param {Array<{status: string}>} items
 * @returns {string} one of: 'pending', 'processing', 'partially_shipped', 'delivered', 'cancelled'
 */
export function computeOverallStatus(items) {
  if (!Array.isArray(items) || items.length === 0) return "pending";

  // Defensive: tolerate null/undefined items
  const statuses = items.map((i) => (i && i.status) || "pending");
  const hasInFlight = statuses.some((s) => IN_FLIGHT.has(s));
  const hasDelivered = statuses.some((s) => s === "delivered");
  const hasCancelled = statuses.some((s) => s === "cancelled");
  const allCancelled = statuses.every((s) => s === "cancelled");
  const allDeliveredOrCancelled = statuses.every((s) => s === "delivered" || s === "cancelled");

  // CRITICAL FIX: all-cancelled → 'cancelled', NOT 'delivered'
  if (allCancelled) return "cancelled";
  if (allDeliveredOrCancelled) return "delivered";
  if (hasInFlight && hasDelivered) return "partially_shipped";
  if (statuses.every((s) => s === "pending")) return "pending";
  return "processing";
}

/**
 * Returns the next valid status in the fulfillment state machine.
 * 'cancelled' is terminal — returns null.
 * @param {string} current
 * @returns {string|null} next status or null if at terminal
 */
export function nextStatus(current) {
  const order = ["pending", "processing", "shipped", "delivered"];
  const idx = order.indexOf(current);
  if (idx < 0 || idx >= order.length - 1) return null;
  return order[idx + 1];
}

/**
 * Returns true if a transition from → to is valid.
 * FIX: enforces single-step forward transitions for the fulfillment chain,
 * and allows cancellation from any non-terminal state.
 * @param {string} from
 * @param {string} to
 */
export function isValidTransition(from, to) {
  if (from === to) return false;
  // Cancellation is allowed from any non-terminal state
  if (to === "cancelled" && from !== "delivered" && from !== "cancelled") return true;
  // Forward chain: pending → processing → shipped → delivered (single-step only)
  const order = ["pending", "processing", "shipped", "delivered"];
  const fi = order.indexOf(from);
  const ti = order.indexOf(to);
  if (fi < 0 || ti < 0) return false;
  // Single-step: ti === fi + 1
  return ti === fi + 1;
}
