// js/utils/keyboard.js
// Single document-level keydown listener with a small dispatch table.
// Replaces the boilerplate's two separate addEventListener("keydown") handlers.
//
// FIXES:
//   - Arrow handler now uses a STACK so two coexisting sliders (hero + testimonials)
//     don't overwrite each other. Was a single global slot.
//   - initKeyboard has an `initialized` guard to prevent double-registration.
//   - Escape is delegated to layerManager (was duplicated here AND in layerManager).
//
// SRP: owns keyboard shortcut dispatch, nothing else.
// KISS: dispatch table is a plain object — no keybinding framework.

const arrowStack = []; // stack of { leftFn, rightFn }
let initialized = false;

function topArrowHandler() {
  return arrowStack.length > 0 ? arrowStack[arrowStack.length - 1] : null;
}

const isTypingTarget = (target) =>
  target instanceof Element &&
  (target.matches("input, select, textarea") || target.isContentEditable);

export function initKeyboard() {
  if (initialized) return; // FIX: guard against double-registration
  initialized = true;
  document.addEventListener("keydown", (e) => {
    if (isTypingTarget(e.target)) return;
    if (e.key === "Escape") {
      // Escape is handled by layerManager.closeAllLayers() — do NOT also handle here
      // (was duplicated, causing closeAllLayers to run twice).
      return;
    }
    if (e.key === "ArrowLeft" || e.key === "ArrowRight") {
      const top = topArrowHandler();
      if (!top) return;
      if (e.key === "ArrowLeft" && top.leftFn) top.leftFn(e);
      if (e.key === "ArrowRight" && top.rightFn) top.rightFn(e);
    }
  });
}

/** Sliders call this to push their ArrowLeft/Right handler onto the stack. */
export function registerArrowHandler(leftFn, rightFn) {
  arrowStack.push({ leftFn, rightFn });
}

/** Sliders call this to pop their handler off the stack (when destroyed/inactive). */
export function unregisterArrowHandler() {
  arrowStack.pop();
}
