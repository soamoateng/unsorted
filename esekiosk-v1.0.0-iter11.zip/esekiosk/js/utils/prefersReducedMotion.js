// js/utils/prefersReducedMotion.js
// Single source of truth for the user's motion preference.
// Used by sliders (hero, testimonials, announcements) to skip setInterval autoplay.
//
// Source: MDN (Apr 2026) https://developer.mozilla.org/en-US/docs/Web/CSS/@media/prefers-reduced-motion

/** Returns true if the user has requested reduced motion at the OS / browser level. */
export function prefersReducedMotion() {
  return window.matchMedia("(prefers-reduced-motion: reduce)").matches;
}
