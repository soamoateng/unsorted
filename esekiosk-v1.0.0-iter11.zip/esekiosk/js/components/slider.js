// js/components/slider.js
// Generic carousel factory. Replaces the boilerplate's separate hero + testimonial
// slider code with a single reusable makeSlider() call.
//
// FIX: destroy() now removes ALL event listeners (was only clearing the timer).
// Previously, re-mounting a view that contained a slider would accumulate
// listeners on the track/buttons.
//
// SRP: owns slide index state, autoplay timer, dot rendering, user-gesture pause.
// KISS: no plugin system, no options object explosion — just what the two callers need.

import { prefersReducedMotion } from "../utils/prefersReducedMotion.js";
import { registerArrowHandler, unregisterArrowHandler } from "../utils/keyboard.js";

const SWIPE_THRESHOLD_PX = 44;

/**
 * Build a slider over a set of .is-active class-managed slides.
 * @param {Object} opts
 * @param {Element} opts.track     container that holds the .hero__slide / .testi__slide children
 * @param {Element} opts.dots      container that holds the dot buttons (rendered by this fn)
 * @param {Element} opts.prevBtn   prev-arrow button
 * @param {Element} opts.nextBtn   next-arrow button
 * @param {number}  opts.interval  autoplay ms (0 = no autoplay)
 * @param {boolean} opts.swipeable attach touch swipe on track (default true)
 * @param {string}  opts.dotLabel  aria-label prefix for dots (e.g. "Go to slide")
 */
export function makeSlider(opts) {
  const {
    track,
    dots,
    prevBtn,
    nextBtn,
    interval = 0,
    swipeable = true,
    dotLabel = "Go to slide",
  } = opts;

  // FIX: track all listeners so destroy() can remove them
  const listeners = []; // { target, type, handler, options }

  function addListener(target, type, handler, options) {
    if (!target) return;
    target.addEventListener(type, handler, options);
    listeners.push({ target, type, handler, options });
  }

  const slides = Array.from(track ? track.children : []).filter(
    (el) => el.nodeType === 1 // FIX: skip comment nodes
  );
  if (!slides.length) return { go() {}, destroy() {} };

  let idx = 0;
  let timer = null;

  // Render dots
  if (dots) {
    dots.innerHTML = "";
    slides.forEach((_, i) => {
      const b = document.createElement("button");
      b.setAttribute("role", "tab");
      b.setAttribute("aria-label", `${dotLabel} ${i + 1}`);
      b.setAttribute("aria-selected", i === 0 ? "true" : "false");
      if (i === 0) b.classList.add("is-active");
      const handler = () => go(i, true);
      addListener(b, "click", handler);
      dots.appendChild(b);
    });
  }

  function go(i, user = false) {
    idx = (i + slides.length) % slides.length;
    slides.forEach((s, k) => s.classList.toggle("is-active", k === idx));
    if (dots) {
      Array.from(dots.querySelectorAll("button")).forEach((d, k) => {
        d.classList.toggle("is-active", k === idx);
        d.setAttribute("aria-selected", k === idx ? "true" : "false");
      });
    }
    if (user) restart();
  }

  function restart() {
    if (timer) clearInterval(timer);
    if (interval > 0 && !prefersReducedMotion()) {
      timer = setInterval(() => go(idx + 1), interval);
    }
  }

  function next() {
    go(idx + 1, true);
  }
  function prev() {
    go(idx - 1, true);
  }
  function stop() {
    if (timer) {
      clearInterval(timer);
      timer = null;
    }
  }

  addListener(nextBtn, "click", next);
  addListener(prevBtn, "click", prev);

  if (swipeable && track) {
    let touchX = null;
    addListener(
      track,
      "touchstart",
      (e) => { touchX = e.touches[0].clientX; },
      { passive: true }
    );
    addListener(
      track,
      "touchend",
      (e) => {
        if (touchX === null) return;
        const dx = e.changedTouches[0].clientX - touchX;
        if (Math.abs(dx) > SWIPE_THRESHOLD_PX) go(idx + (dx < 0 ? 1 : -1), true);
        touchX = null;
      },
      { passive: true }
    );
  }
  // FIX: skip mouseenter/mouseleave when interval === 0 (was wasted work)
  if (interval > 0 && track) {
    addListener(track, "mouseenter", stop);
    addListener(track, "mouseleave", restart);
  }

  restart();

  // FIX: wire keyboard arrow handlers so Left/Right navigate this slider.
  // The keyboard.js dispatcher calls the top of the arrow-handler stack; when two
  // sliders coexist (hero + testimonials), only the most-recently-mounted gets arrows.
  // That's the same behavior as the boilerplate (which used a single global slot).
  // KISS: not all sliders need keyboard nav (e.g., the hero does; testimonials don't).
  // Callers can pass `keyboard: true` to opt in.
  if (opts.keyboard) {
    registerArrowHandler(prev, next);
  }

  function destroy() {
    // FIX: remove ALL listeners, not just the timer
    stop();
    listeners.forEach(({ target, type, handler, options }) => {
      target.removeEventListener(type, handler, options);
    });
    listeners.length = 0;
    // FIX: unregister the arrow handler so the next slider down the stack gets arrows
    if (opts.keyboard) {
      unregisterArrowHandler();
    }
  }

  return { go, next, prev, stop, destroy };
}
