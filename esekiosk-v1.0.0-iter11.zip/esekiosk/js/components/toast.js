// js/components/toast.js
// Toast notification helper. Extracted verbatim from the boilerplate's toast()
// function, with one addition: a queue host lookup so it survives view changes.
//
// SRP: owns the toast DOM + auto-dismiss. No business logic.

let toastHost = null;

export function initToast(host) {
  toastHost = host;
}

export function toast(msg, isError = false) {
  if (!toastHost) return;
  const el = document.createElement("div");
  el.className = "toast" + (isError ? " toast--error" : "");
  el.innerHTML =
    '<span class="toast__check">' + (isError ? "!" : "&#10003;") + "</span><span></span>";
  el.lastChild.textContent = msg;
  toastHost.appendChild(el);
  setTimeout(() => el.remove(), 3100);
}
