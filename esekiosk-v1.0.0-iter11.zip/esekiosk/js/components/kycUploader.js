// js/components/kycUploader.js
// Ghana Card file input with drag-drop + FileReader preview.
//
// SRP: owns the file-input UI + preview rendering. Does NOT own validation
//      (js/utils/validators.js owns that) or storage (authStore.setKycFile owns that).
//
// Hardening (from prior stress test flag 11e):
//   - dragover and drop handlers MUST call e.preventDefault() to stop the browser
//     from navigating to the dropped file.
//   - File preview uses FileReader.readAsDataURL — fine for an <img> preview, never
//     used for upload (the raw File object is held in authStore and sent via FormData).
//
// WCAG 2.2: drag-drop is an enhancement, not a requirement. The hidden <input> remains
//           the primary input method (keyboard-accessible).

import { setKycFile as authStoreSetKycFile } from "../state/authStore.js";

/**
 * Wire up a drag-drop + click-to-browse uploader.
 * @param {Object} opts
 * @param {Element} opts.dropZone   the visible drop area (click + drop)
 * @param {Element} opts.input      the hidden <input type="file"> (visually hidden)
 * @param {Element} opts.previewEl  <img> element that shows the FileReader preview
 * @param {Element} [opts.hintEl]   small text hint ("Drag a Ghana Card photo here…")
 * @param {(file: File) => string|null} [opts.validateFn]  returns error message or null
 * @param {(msg: string) => void} [opts.onError]  toast callback for validation errors
 */
export function initKycUploader({ dropZone, input, previewEl, hintEl, validateFn, onError }) {
  if (!dropZone || !input || !previewEl) return;

  function handleFile(file) {
    if (!file) return;
    if (typeof validateFn === "function") {
      const err = validateFn(file);
      if (err) {
        if (typeof onError === "function") onError(err);
        return;
      }
    }
    authStoreSetKycFile(file);
    const reader = new FileReader();
    reader.onload = (e) => {
      previewEl.src = e.target.result;
      previewEl.style.display = "block";
      if (hintEl) hintEl.style.display = "none";
    };
    reader.onerror = () => {
      if (typeof onError === "function") onError("Could not read the file. Try another image.");
    };
    reader.readAsDataURL(file);
  }

  // Click anywhere on the drop zone to trigger the file picker
  dropZone.addEventListener("click", () => input.click());

  // Native input change
  input.addEventListener("change", (e) => {
    const file = e.target.files && e.target.files[0];
    if (file) handleFile(file);
  });

  // Drag-drop — MUST preventDefault on dragover and drop, otherwise the browser
  // navigates to the dropped file (a long-standing footgun).
  ["dragenter", "dragover"].forEach((evt) =>
    dropZone.addEventListener(evt, (e) => {
      e.preventDefault();
      e.stopPropagation();
      dropZone.classList.add("kyc-drop--active");
    })
  );
  ["dragleave", "drop"].forEach((evt) =>
    dropZone.addEventListener(evt, (e) => {
      e.preventDefault();
      e.stopPropagation();
      dropZone.classList.remove("kyc-drop--active");
    })
  );
  dropZone.addEventListener("drop", (e) => {
    const dt = e.dataTransfer;
    if (!dt || !dt.files || !dt.files.length) return;
    // Mirror into the input so other code reading input.files sees the drop
    if (dt.files.length) {
      // input.files is a FileList — not directly assignable. Copy via DataTransfer.
      try {
        const transfer = new DataTransfer();
        transfer.items.add(dt.files[0]);
        input.files = transfer.files;
      } catch (_) {
        // Some older browsers; fall back to directly handling
      }
      handleFile(dt.files[0]);
    }
  });
}
