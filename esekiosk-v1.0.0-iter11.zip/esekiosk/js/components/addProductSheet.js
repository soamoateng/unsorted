// js/components/addProductSheet.js
// Bottom-sheet panel for uploading a new product. Slides up from the viewport bottom,
// keyboard-safe (doesn't get trapped under mobile keyboard), accessible (focus-trap
// via layerManager, Escape to close).
//
// SRP: owns the bottom-sheet UI for product upload. Does NOT own validation
//      (utils/validators.js) or upload (services/api.js).
//
// Per PRD: the form includes image input, name, description, wholesale price, and stock.
// On submit, POSTs FormData to /api/products/add_product.php.

import { toast } from "./toast.js";
import * as api from "../services/api.js";
import { emit } from "../state/pubsub.js";

let sheetEl = null;

function ensureSheet() {
  if (sheetEl) return sheetEl;
  sheetEl = document.createElement("aside");
  sheetEl.className = "sheet";
  sheetEl.id = "addProductSheet";
  sheetEl.setAttribute("aria-hidden", "true");
  sheetEl.setAttribute("role", "dialog");
  sheetEl.setAttribute("aria-modal", "true");
  sheetEl.setAttribute("aria-label", "Upload new product");
  sheetEl.innerHTML = `
    <div class="sheet__panel">
      <header class="sheet__head">
        <h3>Upload new product</h3>
        <button class="sheet__close" data-close-sheet aria-label="Close">&times;</button>
      </header>
      <form id="addProductForm" class="sheet__body" novalidate>
        <div class="sheet__field">
          <label for="ap-image">Product image (JPG / PNG / WebP, up to 6 MB)</label>
          <input id="ap-image" name="image" type="file" accept="image/jpeg,image/png,image/webp" required>
          <img id="ap-preview" alt="" style="display:none; max-width: 100%; max-height: 160px; margin-top: 8px; border-radius: 6px;">
        </div>
        <div class="sheet__field">
          <label for="ap-name">Name</label>
          <input id="ap-name" name="name" type="text" required maxlength="150" autocomplete="off">
        </div>
        <div class="sheet__field">
          <label for="ap-desc">Description</label>
          <textarea id="ap-desc" name="description" rows="3" maxlength="5000"></textarea>
        </div>
        <div class="sheet__row">
          <div class="sheet__field">
            <label for="ap-wholesale">Wholesale price (pesewas)</label>
            <input id="ap-wholesale" name="wholesale_price_pesewas" type="number" min="1" step="1" required inputmode="numeric">
            <small>1 GHS = 100 pesewas. e.g., 4500 = ₵45.00</small>
          </div>
          <div class="sheet__field">
            <label for="ap-stock">Stock</label>
            <input id="ap-stock" name="stock" type="number" min="0" step="1" required inputmode="numeric">
          </div>
        </div>
        <button type="submit" id="ap-submit" class="btn btn--primary btn--block btn--lg">Save product</button>
      </form>
    </div>
    <style>
      .sheet { position: fixed; inset: 0; z-index: 95; pointer-events: none; }
      .sheet.is-open { pointer-events: auto; }
      .sheet__panel {
        position: absolute; left: 0; right: 0; bottom: 0;
        max-height: 92vh; overflow-y: auto;
        background: #fff; border-radius: 16px 16px 0 0;
        box-shadow: 0 -10px 40px rgba(11, 59, 46, 0.18);
        transform: translateY(102%);
        transition: transform .32s cubic-bezier(.22, .8, .3, 1);
        padding: 20px 20px calc(20px + env(safe-area-inset-bottom));
      }
      .sheet.is-open .sheet__panel { transform: none; }
      .sheet__head { display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; }
      .sheet__head h3 { font-size: 18px; font-weight: 700; }
      .sheet__close { width: 38px; height: 38px; border-radius: 50%; background: var(--soft); }
      .sheet__close:hover { background: var(--g50); }
      .sheet__body { display: flex; flex-direction: column; gap: 14px; }
      .sheet__field { display: flex; flex-direction: column; gap: 4px; }
      .sheet__field label { font-size: 13px; font-weight: 600; }
      .sheet__field input, .sheet__field textarea, .sheet__field select {
        padding: 10px 12px; border: 1.5px solid var(--line); border-radius: 10px; font-size: 14.5px;
      }
      .sheet__field small { color: var(--muted); font-size: 12px; }
      .sheet__row { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; }
      @media (max-width: 540px) { .sheet__row { grid-template-columns: 1fr; } }
    </style>
  `;
  document.body.appendChild(sheetEl);

  // Close button
  sheetEl.querySelector("[data-close-sheet]").addEventListener("click", closeSheet);

  // Image preview
  const fileInput = sheetEl.querySelector("#ap-image");
  const preview = sheetEl.querySelector("#ap-preview");
  fileInput.addEventListener("change", (e) => {
    const file = e.target.files && e.target.files[0];
    if (!file) {
      preview.style.display = "none";
      preview.src = "";
      return;
    }
    if (!/^image\/(jpeg|png|webp)$/.test(file.type)) {
      toast("Image must be JPG, PNG, or WebP.", true);
      fileInput.value = "";
      preview.style.display = "none";
      return;
    }
    if (file.size > 6 * 1024 * 1024) {
      toast("Image must be under 6 MB.", true);
      fileInput.value = "";
      preview.style.display = "none";
      return;
    }
    const reader = new FileReader();
    reader.onload = (ev) => {
      preview.src = ev.target.result;
      preview.style.display = "block";
    };
    reader.readAsDataURL(file);
  });

  // Submit
  sheetEl.querySelector("#addProductForm").addEventListener("submit", onSubmit);
  return sheetEl;
}

let submitting = false;
async function onSubmit(e) {
  e.preventDefault();
  if (submitting) return;
  const form = e.target;
  const fd = new FormData(form);
  // Validate
  const name = (fd.get("name") || "").toString().trim();
  // FIX: validate integers properly (was parseInt which silently truncated "5.99" → 5)
  const wholesaleStr = (fd.get("wholesale_price_pesewas") || "").toString();
  const stockStr = (fd.get("stock") || "").toString();
  const wholesale = Number(wholesaleStr);
  const stock = Number(stockStr);
  const file = fd.get("image");
  if (!name || name.length < 2) return toast("Name must be at least 2 characters.", true);
  if (!Number.isInteger(wholesale) || wholesale <= 0)
    return toast("Wholesale price must be a positive integer (pesewas). E.g., 4500 = ₵45.00.", true);
  if (!Number.isInteger(stock) || stock < 0)
    return toast("Stock must be a non-negative integer.", true);
  if (!file || !(file instanceof File) || file.size === 0) return toast("Please select a product image.", true);

  const btn = sheetEl.querySelector("#ap-submit");
  const original = btn.innerHTML;
  btn.disabled = true;
  btn.innerHTML = "Saving…";
  submitting = true;

  try {
    const res = await api.post("/api/products/add_product.php", fd, { isForm: true });
    toast("Product uploaded: " + (res.product?.name || "OK"));
    emit("products:change", { kind: "added", product: res.product });
    closeSheet();
    form.reset();
    const preview = sheetEl.querySelector("#ap-preview");
    if (preview) preview.style.display = "none";
  } catch (err) {
    const msg = (err && err.payload && err.payload.error) || err.message || "Upload failed.";
    toast(msg, true);
  } finally {
    submitting = false;
    btn.disabled = false;
    btn.innerHTML = original;
  }
}

export function openSheet() {
  ensureSheet();
  sheetEl.classList.add("is-open");
  sheetEl.setAttribute("aria-hidden", "false");
  document.body.style.overflow = "hidden";
  // Focus the first input
  setTimeout(() => sheetEl.querySelector("#ap-name")?.focus(), 50);
  // Escape to close — FIX: remove the redundant options arg (once:false is the default)
  document.addEventListener("keydown", onKeydown);
}

export function closeSheet() {
  if (!sheetEl) return;
  sheetEl.classList.remove("is-open");
  sheetEl.setAttribute("aria-hidden", "true");
  document.body.style.overflow = "";
  document.removeEventListener("keydown", onKeydown);
  // FIX: reset submitting flag so the next open can submit
  submitting = false;
}

// FIX: new unmount export — parent views should call this when navigating away
// so body.overflow doesn't stay locked and the keydown listener is removed.
export function unmount() {
  closeSheet();
}

function onKeydown(e) {
  if (e.key === "Escape") closeSheet();
}
