// js/components/layerManager.js
// Single source of truth for overlay (drawer/modal/mobile-nav) open/close state.
// Extracted from the boilerplate's syncLayer / registerLayer / unregisterLayer /
// closeAllLayers functions, with these fixes:
//   (a) FIX: null guard on `scrim` — was throwing if #scrim was missing, killing init.
//   (b) FIX: focus-trap + focus-restore now use a STACK so multiple layers work.
//       Previously, opening layer B while A was open would never install B's trap,
//       and closing B would uninstall A's trap even though A was still open.
//   (c) FIX: closeAllLayers restores focus per-layer in reverse order.
// Both (b) and (c) are required by the WAI-ARIA Dialog Modal pattern (WCAG 2.2).
//
// SRP: owns layer visibility + keyboard focus behavior. Nothing else.

const LAYER_IDS = ["cartDrawer", "wishDrawer", "quickView", "mobileNav"];
let openLayers = [];
let scrim = null;
let focusStack = [];        // FIX: stack of { layerEl, lastFocused } for nested layers
let focusTrapHandler = null; // single Tab listener attached to the top layer

export function initLayerManager(scrimEl) {
  scrim = scrimEl;
  // FIX: null guard — was throwing if #scrim was missing, killing app.js init()
  if (!scrim) {
    console.warn("[layerManager] no #scrim element — overlays will not dim the background");
    return;
  }
  // Initial inert state — closed layers must not be keyboard-focusable
  LAYER_IDS.forEach((id) => {
    const el = document.getElementById(id);
    if (el) el.inert = true;
  });
  scrim.addEventListener("click", closeAllLayers);
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") closeAllLayers();
  });
  // Close buttons on drawers (data-close-drawer attribute)
  // FIX: use event delegation so dynamically-added close buttons also work
  document.addEventListener("click", (e) => {
    const btn = e.target.closest("[data-close-drawer]");
    if (!btn) return;
    unregisterLayer(btn.dataset.closeDrawer);
  });
}

function syncLayer(el, open) {
  if (!el) return;
  el.classList.toggle("is-open", open);
  el.setAttribute("aria-hidden", open ? "false" : "true");
  el.inert = !open;
  if (el.id === "mobileNav" && !open) {
    const t = document.getElementById("navToggle");
    if (t) t.setAttribute("aria-expanded", "false");
  }
}

function syncScrim() {
  const anyOpen = openLayers.length > 0;
  if (!scrim) return;
  scrim.classList.toggle("is-visible", anyOpen);
  document.body.style.overflow = anyOpen ? "hidden" : "";
}

function installFocusTrap(rootEl) {
  if (focusTrapHandler) {
    // FIX: remove the previous trap before installing a new one (was early-returning,
    // so opening B while A was open left B without a trap)
    rootEl.removeEventListener("keydown", focusTrapHandler);
  }
  focusTrapHandler = (e) => {
    if (e.key !== "Tab") return;
    const focusable = rootEl.querySelectorAll(
      'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
    );
    if (!focusable.length) return;
    const first = focusable[0];
    const last = focusable[focusable.length - 1];
    if (e.shiftKey && document.activeElement === first) {
      e.preventDefault();
      last.focus();
    } else if (!e.shiftKey && document.activeElement === last) {
      e.preventDefault();
      first.focus();
    }
  };
  rootEl.addEventListener("keydown", focusTrapHandler);
}

function uninstallFocusTrap(fromEl) {
  if (focusTrapHandler && fromEl) {
    fromEl.removeEventListener("keydown", focusTrapHandler);
  }
  focusTrapHandler = null;
}

export function registerLayer(name) {
  if (!LAYER_IDS.includes(name)) return;
  // FIX: if another layer is already open, uninstall its trap first (we'll re-install on top)
  if (openLayers.length > 0) {
    const prevEl = document.getElementById(openLayers[openLayers.length - 1]);
    if (prevEl) uninstallFocusTrap(prevEl);
  }
  if (!openLayers.includes(name)) openLayers.push(name);
  const el = document.getElementById(name);
  if (!el) return;
  // FIX: push { layerEl, lastFocused } onto the stack
  focusStack.push({ layerEl: el, lastFocused: document.activeElement });
  syncLayer(el, true);
  syncScrim();
  // Move focus into the layer
  const focusable = el.querySelector(
    'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
  );
  if (focusable) focusable.focus();
  installFocusTrap(el);
}

export function unregisterLayer(name) {
  const wasOpen = openLayers.includes(name);
  // FIX: capture whether this was the top layer BEFORE filtering (for focus-restore logic)
  const wasTopLayer = wasOpen && openLayers[openLayers.length - 1] === name;
  openLayers = openLayers.filter((n) => n !== name);
  const el = document.getElementById(name);
  syncLayer(el, false);

  // FIX: pop the focus stack entry for this layer and restore its lastFocused
  const stackIdx = focusStack.findIndex((s) => s.layerEl === el);
  let restoreFocus = null;
  if (stackIdx >= 0) {
    const entry = focusStack[stackIdx];
    restoreFocus = entry.lastFocused;
    focusStack.splice(stackIdx, 1);
  }
  uninstallFocusTrap(el);

  // FIX: if there's still a layer open, re-install its trap (the layer below this one)
  if (openLayers.length > 0) {
    const topEl = document.getElementById(openLayers[openLayers.length - 1]);
    if (topEl) installFocusTrap(topEl);
    // FIX: if the just-closed layer was NOT the top, move focus back to the top layer
    // (the still-open layer that's now visible). Don't restore to the closed layer's
    // lastFocused — that element is behind the still-open top layer.
    if (!wasTopLayer && topEl) {
      const focusable = topEl.querySelector(
        'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
      );
      if (focusable) focusable.focus();
    }
  } else {
    syncScrim();
  }

  // FIX: only restore focus to lastFocused if this was the top layer (closing it
  // returns focus to whatever was focused before the stack was built) OR if no
  // layer is left open. Closing a non-top layer should NOT steal focus from the
  // still-open top layer.
  if (restoreFocus && typeof restoreFocus.focus === "function" && wasOpen
      && (openLayers.length === 0 || wasTopLayer)) {
    restoreFocus.focus();
  }
}

export function closeAllLayers() {
  // FIX: close in reverse order, restoring focus per layer
  while (openLayers.length > 0) {
    const name = openLayers[openLayers.length - 1];
    unregisterLayer(name);
  }
}

export function isOpen(name) {
  return openLayers.includes(name);
}
