// js/views/storefrontView.js
// Public storefront. Renders the boilerplate's full UI: hero, categories, product grid,
// deal-of-the-day countdown, testimonials, newsletter, cart drawer, wishlist drawer,
// quick-view modal. UI/UX is preserved verbatim; only the code is modularised.
//
// Phase 3 update: now dual-mode. If `mount(container, params)` is called with
// `params.slug`, the catalog is fetched from /api/products/get_products.php?store=<slug>
// (real backend data). If called without params.slug (e.g. root URL demo), it falls
// back to the local data/products.js catalog.
//
// SRP: this module owns the storefront view's mount/unmount lifecycle + interactions.

import { PRODUCTS as LOCAL_PRODUCTS, TESTIMONIALS, byId as localById } from "../data/products.js";
import { escapeHTML, escapeAttr } from "../utils/escape.js";
import { formatPesewas, starsSVG } from "../utils/format.js";
import { prefersReducedMotion } from "../utils/prefersReducedMotion.js";
import { makeSlider } from "../components/slider.js";
import * as api from "../services/api.js";
import { getBasePath } from "../services/api.js";
import { openAccessCodePopup } from "../services/paystack.js";
import { registerLayer, unregisterLayer, closeAllLayers, isOpen } from "../components/layerManager.js";
import { toast } from "../components/toast.js";
import * as cartStore from "../state/cartStore.js";
import * as searchStore from "../state/searchStore.js";
import { on as pubsubOn, emit } from "../state/pubsub.js";

// Module-scoped state (re-initialised on every mount)
let wishlist = [];
let activeTab = "all";
let heroSlider = null;
let testiSlider = null;
let countdownTimer = null;
let dealEnds = null;
let dealBarTimeout = null;
let topbarTimer = null;
let announcementIdx = 0;
let root = null;
let qvProduct = null;
// FIX (audit m11): track pubsub unsubscribe handles so unmount can remove them
let pubsubUnsubscribers = [];

// Phase 3: API mode. If `apiProducts` is non-null, the view uses backend data
// (fetched from /api/products/get_products.php?store=<slug>). Otherwise it
// falls back to the local demo catalog from data/products.js.
let apiProducts = null;       // null = local demo mode; array = API mode
let apiStoreSlug = null;       // the slug of the store being viewed

/** Resolve the active product list — API if available, else local demo. */
function PRODUCTS() {
  return apiProducts !== null ? apiProducts : LOCAL_PRODUCTS;
}
/** byId works across both modes and always returns the normalised shape. */
function byId(id) {
  const raw = apiProducts !== null
    ? apiProducts.find((p) => String(p.id) === String(id))
    : localById(id);
  return normalise(raw);
}

/**
 * Normalise an API product row into the shape cardHTML/renderCart/openQuickView expect.
 * Local demo products already have this shape; API products need mapping.
 *
 * Local shape:  { id, name, category, price (pesewas), oldPrice (pesewas|null), rating, reviews, img, onSale, featured, top, desc }
 * API shape:     { id, name, description, image_path, retail_price_pesewas, stock, parent_product_id, merchant_id, is_clone }
 *
 * Phase 3 MVP: API products have no rating/reviews/category/oldPrice. We synthesize
 * neutral values (rating 4.5, reviews 0, category "all", no oldPrice) so the card
 * template works without modification. Phase 5+ will surface real ratings.
 */
function normalise(p) {
  if (!p) return null;
  // Already-normal shape (local demo data)?
  if (typeof p.img === "string") return p;
  return {
    id: String(p.id),
    name: p.name,
    category: "all",                          // API has no category in MVP
    price: p.retail_price_pesewas,
    oldPrice: null,                           // API has no oldPrice in MVP
    rating: 4.5,                              // synthesised neutral rating
    reviews: 0,
    img: getBasePath() + "/api/" + p.image_path,  // prepend app base + /api/ so it resolves from any route
    onSale: false,
    featured: false,
    top: false,
    desc: p.description || "",
    stock: p.stock,
    isClone: !!p.is_clone,
    parentProductId: p.parent_product_id || null,
  };
}

/** Returns the full normalised list (local or API). */
function normalisedList() {
  return PRODUCTS().map(normalise);
}

const STORAGE_WISH = "esekiosk_wishlist";
const STORAGE_DEAL = "esekiosk_deal_ends";

function $(sel, ctx) {
  return (ctx || root || document).querySelector(sel);
}
function $$(sel, ctx) {
  return Array.from((ctx || root || document).querySelectorAll(sel));
}

// --- HTML card builder (XSS-safe: every interpolation wrapped in escapeHTML) ---
function cardHTML(p, i) {
  const flags = [];
  if (p.oldPrice)
    flags.push(
      '<span class="flag flag--sale">-' +
        Math.round((1 - p.price / p.oldPrice) * 100) +
        "%</span>"
    );
  if (p.rating >= 4.8) flags.push('<span class="flag flag--top">Top</span>');
  if (!p.oldPrice && p.rating < 4.8 && p.featured)
    flags.push('<span class="flag flag--new">New</span>');
  const wished = wishlist.includes(p.id);
  return (
    '<article class="card" style="animation-delay:' +
    (i % 8) * 60 +
    'ms" data-id="' +
    escapeAttr(p.id) +
    '">' +
    '<div class="card__media">' +
    '<img src="' +
    escapeAttr(p.img) +
    '" alt="' +
    escapeHTML(p.name) +
    '" loading="lazy">' +
    '<div class="card__badges">' +
    flags.join("") +
    "</div>" +
    '<button class="card__wish' +
    (wished ? " is-active" : "") +
    '" data-wish="' +
    escapeAttr(p.id) +
    '" aria-label="Toggle wishlist for ' +
    escapeAttr(p.name) +
    '">' +
    '<svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20.5s-7.5-4.6-9.3-9.2C1.4 8 3.4 4.9 6.6 4.9c2 0 3.6 1.1 4.4 2.7h2c.8-1.6 2.4-2.7 4.4-2.7 3.2 0 5.2 3.1 3.9 6.4-1.8 4.6-9.3 9.2-9.3 9.2z"/></svg>' +
    "</button>" +
    '<div class="card__actions">' +
    '<button class="card__btn" data-add="' +
    escapeAttr(p.id) +
    '">' +
    '<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg>Add to cart</button>' +
    '<button class="card__btn card__btn--icon" data-view="' +
    escapeAttr(p.id) +
    '" aria-label="Quick view ' +
    escapeAttr(p.name) +
    '">' +
    '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12z"/><circle cx="12" cy="12" r="3"/></svg>' +
    "</button>" +
    "</div>" +
    "</div>" +
    '<div class="card__body">' +
    '<span class="card__cat">' +
    escapeHTML(p.category) +
    "</span>" +
    '<h3 class="card__title"><a href="#" data-view="' +
    escapeAttr(p.id) +
    '">' +
    escapeHTML(p.name) +
    "</a></h3>" +
    '<div class="card__rating">' +
    starsSVG(p.rating) +
    "<small>" +
    Number(p.rating).toFixed(1) +
    " (" +
    escapeHTML(String(p.reviews)) +
    ")</small></div>" +
    '<div class="card__price-row"><span class="card__price price" data-price="' +
    escapeAttr(String(p.price)) +
    '">' +
    formatPesewas(p.price) +
    "</span>" +
    (p.oldPrice
      ? '<span class="price price--old" data-price="' +
        escapeAttr(String(p.oldPrice)) +
        '">' +
        formatPesewas(p.oldPrice) +
        "</span>"
      : "") +
    "</div>" +
    "</div>" +
    "</article>"
  );
}

function currentList() {
  const q = searchStore.getQuery();
  const cat = searchStore.getCategory();
  return normalisedList().filter((p) => {
    if (activeTab === "sale" && !p.onSale) return false;
    if (activeTab === "featured" && !p.featured) return false;
    if (activeTab === "top" && !p.top) return false;
    if (cat !== "all" && p.category !== cat) return false;
    if (q) {
      const hay = (p.name + " " + p.category + " " + p.desc).toLowerCase();
      if (!hay.includes(q)) return false;
    }
    return true;
  });
}

function renderProducts() {
  const grid = $("#productsGrid");
  const emptyMsg = $("#productsEmpty");
  if (!grid) return;
  const list = currentList();
  grid.innerHTML = list.map(cardHTML).join("");
  if (emptyMsg) emptyMsg.hidden = list.length > 0;
}

function renderCart() {
  const cart = cartStore.getCart();
  const items = Object.entries(cart);
  const n = items.reduce((sum, [, q]) => sum + (parseInt(q, 10) || 0), 0);
  const cartCount = $("#cartCount");
  const cartDrawerCount = $("#cartDrawerCount");
  const cartSubtotal = $("#cartSubtotal");
  const cartItemsEl = $("#cartItems");
  if (cartCount) {
    cartCount.textContent = n;
    cartCount.hidden = n === 0;
  }
  if (cartDrawerCount) {
    cartDrawerCount.textContent = n ? "(" + n + " item" + (n > 1 ? "s" : "") + ")" : "";
  }
  if (cartSubtotal) {
    const sum = items.reduce((acc, [id, qty]) => {
      const p = byId(id);
      return p ? acc + p.price * parseInt(qty, 10) : acc;
    }, 0);
    cartSubtotal.textContent = formatPesewas(sum);
  }
  if (!cartItemsEl) return;
  if (n === 0) {
    cartItemsEl.innerHTML =
      '<div class="drawer__empty"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"><path d="M6 7h12l1.2 12.2a1.8 1.8 0 0 1-1.8 1.8H6.6a1.8 1.8 0 0 1-1.8-1.8L6 7z"/><path d="M9 10V6a3 3 0 0 1 6 0v4"/></svg><p>Your cart is empty.<br>Time to fix that.</p></div>';
    return;
  }
  cartItemsEl.innerHTML = items
    .map(([id, qty], i) => {
      const p = byId(id);
      if (!p) return "";
      const q = parseInt(qty, 10) || 0;
      return (
        '<div class="line-item" style="animation-delay:' +
        i * 40 +
        'ms">' +
        '<img class="line-item__img" src="' +
        escapeAttr(p.img) +
        '" alt="' +
        escapeHTML(p.name) +
        '">' +
        "<div>" +
        '<div class="line-item__t">' +
        escapeHTML(p.name) +
        "</div>" +
        '<div class="line-item__p">' +
        formatPesewas(p.price) +
        "</div>" +
        '<div class="line-item__ctrl">' +
        '<span class="qty"><button data-cart-minus="' +
        escapeAttr(id) +
        '" aria-label="Decrease">&minus;</button>' +
        '<input value="' +
        escapeAttr(String(q)) +
        '" readonly aria-label="Quantity">' +
        '<button data-cart-plus="' +
        escapeAttr(id) +
        '" aria-label="Increase">+</button></span>' +
        '<button class="line-item__remove" data-cart-remove="' +
        escapeAttr(id) +
        '">Remove</button>' +
        "</div>" +
        "</div>" +
        '<button class="line-item__x" data-cart-remove="' +
        escapeAttr(id) +
        '" aria-label="Remove ' +
        escapeAttr(p.name) +
        '">&#10005;</button>' +
        "</div>"
      );
    })
    .join("");
}

function renderWishlist() {
  const wishItems = $("#wishItems");
  const wishCount = $("#wishlistCount");
  const wishDrawerCount = $("#wishDrawerCount");
  if (wishCount) {
    wishCount.textContent = wishlist.length;
    wishCount.hidden = wishlist.length === 0;
  }
  if (wishDrawerCount) {
    wishDrawerCount.textContent = wishlist.length ? "(" + wishlist.length + ")" : "";
  }
  if (!wishItems) return;
  if (!wishlist.length) {
    wishItems.innerHTML =
      '<div class="drawer__empty"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20.5s-7.5-4.6-9.3-9.2C1.4 8 3.4 4.9 6.6 4.9c2 0 3.6 1.1 4.4 2.7h2c.8-1.6 2.4-2.7 4.4-2.7 3.2 0 5.2 3.1 3.9 6.4-1.8 4.6-9.3 9.2-9.3 9.2z"/></svg><p>Nothing saved yet.<br>Tap the heart on any product.</p></div>';
    return;
  }
  wishItems.innerHTML = wishlist
    .map((id, i) => {
      const p = byId(id);
      if (!p) return "";
      return (
        '<div class="line-item" style="animation-delay:' +
        i * 40 +
        'ms">' +
        '<img class="line-item__img" src="' +
        escapeAttr(p.img) +
        '" alt="' +
        escapeHTML(p.name) +
        '">' +
        "<div>" +
        '<div class="line-item__t">' +
        escapeHTML(p.name) +
        "</div>" +
        '<div class="line-item__p">' +
        formatPesewas(p.price) +
        "</div>" +
        '<div class="line-item__ctrl"><button class="card__btn" data-add="' +
        escapeAttr(id) +
        '" style="flex:none;padding:8px 16px">Add to cart</button></div>' +
        "</div>" +
        '<button class="line-item__x" data-wish-remove="' +
        escapeAttr(id) +
        '" aria-label="Remove from wishlist">&#10005;</button>' +
        "</div>"
      );
    })
    .join("");
}

function toggleWish(id) {
  const p = byId(id);
  if (!p) return;
  if (wishlist.includes(id)) {
    wishlist = wishlist.filter((w) => w !== id);
    toast(p.name + " removed from wishlist");
  } else {
    wishlist.push(id);
    toast(p.name + " saved to wishlist");
  }
  try {
    localStorage.setItem(STORAGE_WISH, JSON.stringify(wishlist));
  } catch (_) {
    /* ignore quota errors for wishlist */
  }
  renderWishlist();
  const heartBtn = $("#productsGrid")?.querySelector('[data-wish="' + CSS.escape(id) + '"]');
  if (heartBtn) heartBtn.classList.toggle("is-active", wishlist.includes(id));
}

function openQuickView(id) {
  const p = byId(id);
  if (!p) return;
  qvProduct = p;
  const set = (sel, val, attr) => {
    const el = $(sel);
    if (!el) return;
    if (attr) el[attr] = val;
    else el.textContent = val;
  };
  set("#qvImg", escapeAttr(p.img), "src");
  set("#qvImg", escapeHTML(p.name), "alt");
  set("#qvCat", escapeHTML(p.category));
  set("#qvTitle", escapeHTML(p.name));
  const qvRating = $("#qvRating");
  if (qvRating) {
    qvRating.innerHTML = starsSVG(p.rating) + '<small style="color:var(--muted)">' + p.rating.toFixed(1) + " · " + p.reviews + " reviews</small>";
  }
  set("#qvPrice", formatPesewas(p.price));
  const qvPriceEl = $("#qvPrice");
  if (qvPriceEl) qvPriceEl.dataset.price = String(p.price);
  const qvOld = $("#qvOldPrice");
  if (qvOld) {
    qvOld.textContent = p.oldPrice ? formatPesewas(p.oldPrice) : "";
    qvOld.style.display = p.oldPrice ? "" : "none";
  }
  set("#qvDesc", escapeHTML(p.desc));
  set("#qvQty", "1", "value");
  set("#qvMeta", "Free shipping over " + formatPesewas(9900) + " · 30-day returns · In stock, ships in 24h");
  const modal = $("#quickView");
  if (modal) {
    modal.classList.add("is-open");
    modal.setAttribute("aria-hidden", "false");
  }
  registerLayer("quickView");
}

function closeQuickView() {
  unregisterLayer("quickView");
}

function setTab(tab) {
  activeTab = tab;
  $$(".tab", $("#productTabs")).forEach((t) => {
    const on = t.dataset.tab === tab;
    t.classList.toggle("is-active", on);
    t.setAttribute("aria-selected", on ? "true" : "false");
  });
  renderProducts();
}

function syncSearchUI() {
  const sel = $("#searchCategory");
  const inp = $("#searchInput");
  const mInp = $("#mnavSearchInput");
  const q = searchStore.getQuery();
  const cat = searchStore.getCategory();
  if (sel && sel.value !== cat) sel.value = cat;
  if (inp && document.activeElement !== inp) inp.value = q;
  if (mInp && document.activeElement !== mInp) mInp.value = q;
}

function tickCountdown() {
  const cdCells = {
    d: $("#cdDays"),
    h: $("#cdHours"),
    m: $("#cdMins"),
    s: $("#cdSecs"),
  };
  if (!cdCells.d) return;
  let diff = dealEnds - Date.now();
  if (diff <= 0) {
    const end = new Date();
    end.setHours(23, 59, 59, 999);
    end.setTime(end.getTime() + 36 * 3600e3);
    dealEnds = end.getTime();
    try {
      localStorage.setItem(STORAGE_DEAL, String(dealEnds));
    } catch (_) {}
    diff = dealEnds - Date.now();
  }
  const d = Math.floor(diff / 86400e3);
  diff -= d * 86400e3;
  const h = Math.floor(diff / 3600e3);
  diff -= h * 3600e3;
  const m = Math.floor(diff / 60e3);
  diff -= m * 60e3;
  const s = Math.floor(diff / 1e3);
  const pad = (n) => String(n).padStart(2, "0");
  cdCells.d.textContent = pad(d);
  cdCells.h.textContent = pad(h);
  cdCells.m.textContent = pad(m);
  cdCells.s.textContent = pad(s);
}

function annGo(i) {
  const annMsgs = $$(".topbar__msg");
  if (!annMsgs.length) return;
  announcementIdx = (i + annMsgs.length) % annMsgs.length;
  annMsgs.forEach((m, k) => m.classList.toggle("is-active", k === announcementIdx));
}

// --- Public mount/unmount ---

/**
 * Fetch the store's products from the backend. Sets `apiProducts` to the array
 * (or empty on failure) and re-renders the grid.
 *
 * Per PRD: the grid uses CSS Grid `repeat(auto-fill, minmax(180px, 1fr))` and
 * `loading="lazy"` + IntersectionObserver fade-in. The CSS rule lives in
 * storefrontView's added <style> block below.
 */
// FIX: request-token guard against stale async responses. Each loadFromApi call
// increments a counter; the response is only applied if its token matches the latest.
let loadRequestToken = 0;

async function loadFromApi(slug) {
  const grid = $("#productsGrid");
  if (grid) {
    grid.innerHTML =
      '<p style="grid-column: 1 / -1; text-align: center; padding: 40px; color: var(--muted);">Loading products…</p>';
  }
  // FIX: capture this request's token. If the user navigates to another store before
  // this resolves, the token won't match and we discard the stale response.
  const myToken = ++loadRequestToken;
  try {
    const res = await api.get("/api/products/get_products.php?store=" + encodeURIComponent(slug));
    if (myToken !== loadRequestToken) return; // stale — a newer request supersedes this
    apiProducts = (res && res.products) ? res.products : [];
  } catch (err) {
    if (myToken !== loadRequestToken) return; // stale
    apiProducts = [];
    const msg = (err && err.payload && err.payload.error) || err.message || "Failed to load products.";
    toast(msg, true);
    if (grid) {
      grid.innerHTML =
        '<p style="grid-column: 1 / -1; text-align: center; padding: 40px; color: var(--red);">' +
        'Could not load this store. It may be inactive or the URL is wrong.</p>';
    }
    return;
  }
  // Re-render the grid now that apiProducts is set
  renderProducts();
  // Observe new card images for the fade-in IntersectionObserver
  observeCardImages();
  // Update the page title with the store name if we have it
  if (apiProducts.length && document.title.indexOf("Esekiosk") === 0) {
    document.title = "Esekiosk — Store: " + slug;
  }
}

// FIX: moved imgObserver + observeCardImages to MODULE scope (were inside mount(),
// but loadFromApi — also module-scope — calls observeCardImages → ReferenceError).
// Created lazily on first call so it's available before mount() runs.
let imgObserver = null;
function ensureImgObserver() {
  if (imgObserver) return imgObserver;
  imgObserver = new IntersectionObserver(
    (entries, obs) => {
      entries.forEach((en) => {
        if (!en.isIntersecting) return;
        const img = en.target;
        const dataSrc = img.getAttribute("data-src");
        if (dataSrc && !img.src) {
          img.src = dataSrc;
        }
        img.addEventListener("load", () => img.classList.add("is-loaded"), { once: true });
        obs.unobserve(img);
      });
    },
    { rootMargin: "200px 0px" }
  );
  return imgObserver;
}
function observeCardImages() {
  const obs = ensureImgObserver();
  $$("#productsGrid .card img").forEach((img) => obs.observe(img));
}

export function mount(container, params = {}) {
  // Phase-1 demo: container is the document body (the boilerplate's index.html
  // already has all the structural markup). This view wires up listeners only.
  root = document;

  // Phase 3: if a store slug is provided (params.slug from the router, e.g. /store/kwame-shop-88),
  // fetch the catalog from the backend instead of using the local demo data.
  if (params.slug) {
    apiStoreSlug = params.slug;
    loadFromApi(params.slug);
  } else {
    apiProducts = null;
    apiStoreSlug = null;
  }

  // Wishlist: hydrate from localStorage, sanitize
  try {
    const raw = JSON.parse(localStorage.getItem(STORAGE_WISH) || "[]");
    wishlist = Array.isArray(raw)
      ? raw.filter((id) => typeof id === "string" && byId(id))
      : [];
  } catch (_) {
    wishlist = [];
  }

  // Deal countdown: hydrate or roll forward
  const now = Date.now();
  try {
    const saved = parseInt(localStorage.getItem(STORAGE_DEAL) || "0", 10);
    if (saved && saved > now && saved - now < 72 * 3600e3) {
      dealEnds = saved;
    } else {
      const end = new Date();
      end.setHours(23, 59, 59, 999);
      end.setTime(end.getTime() + 36 * 3600e3);
      dealEnds = end.getTime();
      localStorage.setItem(STORAGE_DEAL, String(dealEnds));
    }
  } catch (_) {
    if (!dealEnds) dealEnds = Date.now() + 36 * 3600e3;
  }

  // Hero slider
  heroSlider = makeSlider({
    track: $("#heroTrack"),
    dots: $("#heroDots"),
    prevBtn: $("#heroPrev"),
    nextBtn: $("#heroNext"),
    interval: 6000,
    swipeable: true,
    dotLabel: "Go to slide",
    keyboard: true,  // FIX: opt in to Left/Right keyboard nav (testimonials don't)
  });

  // Testimonials
  const testiSlides = $("#testiSlides");
  if (testiSlides) {
    testiSlides.innerHTML = TESTIMONIALS.map(
      (t, i) =>
        '<figure class="testi__slide' +
        (i === 0 ? " is-active" : "") +
        '">' +
        '<div class="testi__stars" aria-label="' +
        escapeAttr(String(t.stars)) +
        ' out of 5 stars">' +
        "&#9733;".repeat(t.stars) +
        "</div>" +
        '<blockquote class="testi__quote">&ldquo;' +
        escapeHTML(t.quote) +
        "&rdquo;</blockquote>" +
        '<figcaption class="testi__person">' +
        '<span class="testi__avatar" aria-hidden="true">' +
        escapeHTML(t.initials) +
        "</span>" +
        '<span class="testi__who"><strong>' +
        escapeHTML(t.name) +
        "</strong><span>" +
        escapeHTML(t.role) +
        "</span></span>" +
        "</figcaption>" +
        "</figure>"
    ).join("");
  }
  testiSlider = makeSlider({
    track: testiSlides,
    dots: $("#testiDots"),
    prevBtn: $("#testiPrev"),
    nextBtn: $("#testiNext"),
    interval: 7000,
    swipeable: false,
    dotLabel: "Testimonial",
  });

  // Countdown
  tickCountdown();
  countdownTimer = setInterval(tickCountdown, 1000);
  const dealBar = $("#dealStockBar");
  if (dealBar) {
    dealBarTimeout = setTimeout(() => {
      if (!prefersReducedMotion()) dealBar.style.width = "72%";
    }, 400);
  }

  // Topbar announcements
  annGo(0);
  if (!prefersReducedMotion()) {
    topbarTimer = setInterval(() => annGo(announcementIdx + 1), 5000);
  }

  // Currency select — lock to GHS (the only option in Esekiosk for now)
  $$("select[data-currency]").forEach((sel) => {
    sel.value = "GHS";
    sel.addEventListener("change", () => {
      // Phase 1: any change is reverted (only GHS allowed)
      sel.value = "GHS";
      toast("Esekiosk is GHS-only for now");
    });
  });

  // Tabs
  const productTabs = $("#productTabs");
  if (productTabs) {
    productTabs.addEventListener("click", (e) => {
      const tab = e.target.closest(".tab");
      if (tab) setTab(tab.dataset.tab);
    });
  }

  // Global click handler for [data-tab] / [data-cat] links
  // (one delegated listener, replaces the boilerplate's two)
  document.addEventListener(
    "click",
    onGlobalClick
  );

  // Search forms
  const searchForm = $("#searchForm");
  if (searchForm) {
    searchForm.addEventListener("submit", onSearchSubmit);
  }
  const searchInput = $("#searchInput");
  if (searchInput) {
    searchInput.addEventListener("input", onSearchInput);
  }
  const mnavSearchForm = $("#mnavSearchForm");
  if (mnavSearchForm) {
    mnavSearchForm.addEventListener("submit", onMnavSearchSubmit);
  }
  const mnavSearchInput = $("#mnavSearchInput");
  if (mnavSearchInput) {
    mnavSearchInput.addEventListener("input", onMnavSearchInput);
  }

  // Cart drawer button + checkout
  const cartBtn = $("#cartBtn");
  if (cartBtn) cartBtn.addEventListener("click", () => registerLayer("cartDrawer"));
  const checkoutBtn = $("#checkoutBtn");
  if (checkoutBtn) {
    checkoutBtn.addEventListener("click", onCheckout);
  }
  const cartItems = $("#cartItems");
  if (cartItems) cartItems.addEventListener("click", onCartItemsClick);

  // Wishlist drawer button + "move all to cart"
  const wishlistBtn = $("#wishlistBtn");
  if (wishlistBtn) wishlistBtn.addEventListener("click", () => registerLayer("wishDrawer"));
  const wishItems = $("#wishItems");
  if (wishItems) wishItems.addEventListener("click", onWishItemsClick);
  const wishAllToCart = $("#wishAllToCart");
  if (wishAllToCart) wishAllToCart.addEventListener("click", onWishAllToCart);

  // Quick view buttons
  const grid = $("#productsGrid");
  if (grid) grid.addEventListener("click", onGridClick);
  $$("[data-close-modal]").forEach((el) =>
    el.addEventListener("click", closeQuickView)
  );
  const modal = $("#quickView");
  if (modal) modal.addEventListener("click", (e) => { if (e.target === modal) closeQuickView(); });
  const qvMinus = $("#qvMinus");
  if (qvMinus) qvMinus.addEventListener("click", () => {
    const inp = $("#qvQty");
    inp.value = Math.max(1, (parseInt(inp.value, 10) || 1) - 1);
  });
  const qvPlus = $("#qvPlus");
  if (qvPlus) qvPlus.addEventListener("click", () => {
    const inp = $("#qvQty");
    inp.value = Math.min(99, (parseInt(inp.value, 10) || 1) + 1);
  });
  const qvAdd = $("#qvAdd");
  if (qvAdd) qvAdd.addEventListener("click", () => {
    if (!qvProduct) return;
    const q = Math.min(99, Math.max(1, parseInt($("#qvQty").value, 10) || 1));
    cartStore.add(qvProduct.id, q);
    closeQuickView();
    registerLayer("cartDrawer");
  });

  // Deal-of-the-day add-to-cart
  $$("[data-add-to-cart]").forEach((btn) =>
    btn.addEventListener("click", () => cartStore.add(btn.dataset.addToCart, 1))
  );

  // Mobile nav
  const navToggle = $("#navToggle");
  if (navToggle) navToggle.addEventListener("click", onNavToggle);
  const mnavClose = $("#mnavClose");
  if (mnavClose) mnavClose.addEventListener("click", closeMnav);
  const mnavList = $("#mnavList");
  if (mnavList) mnavList.addEventListener("click", (e) => { if (e.target.closest("a")) closeMnav(); });

  // Desktop dropdown
  const ddItem = $(".nav__item--dropdown");
  const ddBtn = ddItem ? ddItem.querySelector("button") : null;
  if (ddItem && ddBtn) {
    ddBtn.addEventListener("click", () => {
      const open = ddItem.classList.toggle("is-open");
      ddBtn.setAttribute("aria-expanded", open ? "true" : "false");
    });
    document.addEventListener("click", (e) => {
      if (!ddItem.contains(e.target)) {
        ddItem.classList.remove("is-open");
        ddBtn.setAttribute("aria-expanded", "false");
      }
    });
  }

  // Newsletter
  const newsletterForm = $("#newsletterForm");
  if (newsletterForm) newsletterForm.addEventListener("submit", onNewsletterSubmit);

  // Scroll effects
  const header = $("#header");
  const toTop = $("#toTop");
  let ticking = false;
  window.addEventListener(
    "scroll",
    () => {
      if (ticking) return;
      ticking = true;
      requestAnimationFrame(() => {
        const y = window.scrollY;
        if (header) header.classList.toggle("is-stuck", y > 8);
        if (toTop) {
          toTop.hidden = false;
          toTop.classList.toggle("is-visible", y > 560);
        }
        ticking = false;
      });
    },
    { passive: true }
  );
  if (toTop) toTop.addEventListener("click", () => window.scrollTo({ top: 0, behavior: prefersReducedMotion() ? "auto" : "smooth" }));

  // IntersectionObserver for reveal
  const io = new IntersectionObserver(
    (entries) => {
      entries.forEach((en) => {
        if (en.isIntersecting) {
          const delay = en.target.dataset.delay;
          if (delay && !prefersReducedMotion()) {
            en.target.style.transitionDelay = delay * 80 + "ms";
          }
          en.target.classList.add("is-visible");
          io.unobserve(en.target);
        }
      });
    },
    { threshold: 0.12, rootMargin: "0px 0px -40px 0px" }
  );
  $$(".reveal").forEach((el) => io.observe(el));

  // Phase 3: PRD-spec CSS Grid + image lazy-load via IntersectionObserver.
  // Override the boilerplate's `.products { repeat(4, 1fr) }` with the PRD spec:
  //   repeat(auto-fill, minmax(180px, 1fr))
  // Use a single injected <style> with a unique id so it doesn't compound on remount.
  if (!document.getElementById("esekiosk-storefront-grid")) {
    const style = document.createElement("style");
    style.id = "esekiosk-storefront-grid";
    style.textContent = `
      #productsGrid {
        grid-template-columns: repeat(auto-fill, minmax(180px, 1fr)) !important;
        max-width: 1200px;
        margin-inline: auto;
      }
      /* Image fade-in on first scroll into view (PRD requirement) */
      #productsGrid .card img {
        opacity: 0;
        transition: opacity .35s ease;
      }
      #productsGrid .card img.is-loaded { opacity: 1; }
    `;
    document.head.appendChild(style);
  }
  // FIX (Task 10 C3+C4): the previous order was:
  //   1. observeCardImages()  ← observes nothing (grid is empty)
  //   2. pubsubOn("search:change", observeCardImages)  ← fires BEFORE renderProducts
  //   3. pubsubOn("search:change", () => renderProducts())  ← fires AFTER, replaces grid
  // Result: every search/tab change rendered NEW images that were never observed → opacity:0 forever.
  // Now: render first, observe second. The pubsub subscription order is reversed so
  // renderProducts() runs BEFORE observeCardImages() on every search:change.
  // FIX (audit m11): track unsubscribe handles so unmount can remove them.
  pubsubUnsubscribers.push(
    pubsubOn("search:change", () => { syncSearchUI(); renderProducts(); observeCardImages(); })
  );

  // Subscribe to cartStore changes
  pubsubUnsubscribers.push(pubsubOn("cart:change", renderCart));

  // Phase 3: detect in-app navigation to a different /store/<slug> and re-fetch.
  // (The storefront is mounted directly into <body>, so the router doesn't remount
  //  it on hash change — we handle it here.)
  window.addEventListener("hashchange", onHashChange);
  // FIX: also listen for the custom 'app:navigate' event so pushState-based
  // navigation (which doesn't fire hashchange) also triggers store re-fetch.
  window.addEventListener("app:navigate", onHashChange);

  // Initial renders — FIX: renderProducts FIRST, then observeCardImages.
  renderProducts();
  observeCardImages();
  renderCart();
  renderWishlist();
}

function onHashChange() {
  const hash = (window.location.hash || "").replace(/^#/, "");
  const hashNoQuery = hash.split("?")[0];
  if (hashNoQuery.startsWith("/store/")) {
    const newSlug = decodeURIComponent(hashNoQuery.slice("/store/".length));
    if (newSlug === apiStoreSlug) return; // no change
    apiStoreSlug = newSlug;
    loadFromApi(newSlug);
  } else {
    // FIX (audit M3): when leaving a /store/ route (back to #/ or #/welcome),
    // reset to local demo mode so the storefront shows the demo catalog instead
    // of the previous store's products.
    if (apiProducts !== null) {
      apiProducts = null;
      apiStoreSlug = null;
      renderProducts();
      observeCardImages();
    }
  }
}

function onGlobalClick(e) {
  const tabLink = e.target.closest("[data-tab]:not(.tab)");
  const catLink = e.target.closest("[data-cat]");
  if (tabLink) {
    searchStore.reset();
    syncSearchUI();
    setTab(tabLink.dataset.tab);
  }
  if (catLink) {
    const cat = catLink.dataset.cat;
    searchStore.setQuery("");
    searchStore.setCategory(cat === "sale" ? "all" : cat);
    setTab(cat === "sale" ? "sale" : "all");
    closeAllLayers();
  }
  // Placeholder links (href="#") must not yank the user back to the top
  if (e.target.closest('a[href="#"]')) e.preventDefault();
}

function onSearchSubmit(e) {
  e.preventDefault();
  searchStore.setQuery($("#searchInput").value.trim());
  searchStore.setCategory($("#searchCategory").value);
  setTab("all");
  document.getElementById("products").scrollIntoView({
    behavior: prefersReducedMotion() ? "auto" : "smooth",
  });
  if (!currentList().length) toast("No matches — try another keyword", true);
}
function onSearchInput(e) {
  if (!e.target.value.trim() && searchStore.getQuery()) {
    searchStore.setQuery("");
    renderProducts();
  }
}
function onMnavSearchSubmit(e) {
  e.preventDefault();
  searchStore.setQuery($("#mnavSearchInput").value.trim());
  searchStore.setCategory("all");
  syncSearchUI();
  setTab("all");
  closeMnav();
  document.getElementById("products").scrollIntoView({
    behavior: prefersReducedMotion() ? "auto" : "smooth",
  });
  if (!currentList().length) toast("No matches — try another keyword", true);
}
function onMnavSearchInput(e) {
  if (!e.target.value.trim() && searchStore.getQuery()) {
    searchStore.setQuery("");
    renderProducts();
  }
}

function onGridClick(e) {
  const wishBtn = e.target.closest("[data-wish]");
  const addBtn = e.target.closest("[data-add]");
  const viewEl = e.target.closest("[data-view]");
  if (wishBtn) { toggleWish(wishBtn.dataset.wish); return; }
  if (addBtn) { cartStore.add(addBtn.dataset.add, 1); toast(byId(addBtn.dataset.add)?.name + " added to cart"); return; }
  if (viewEl) { e.preventDefault(); openQuickView(viewEl.dataset.view); }
}

function onCartItemsClick(e) {
  const plus = e.target.closest("[data-cart-plus]");
  const minus = e.target.closest("[data-cart-minus]");
  const rem = e.target.closest("[data-cart-remove]");
  if (plus) cartStore.setQty(plus.dataset.cartPlus, (cartStore.getQty(plus.dataset.cartPlus) || 0) + 1);
  if (minus) cartStore.setQty(minus.dataset.cartMinus, (cartStore.getQty(minus.dataset.cartMinus) || 0) - 1);
  if (rem) {
    const p = byId(rem.dataset.cartRemove);
    cartStore.setQty(rem.dataset.cartRemove, 0);
    if (p) toast(p.name + " removed");
  }
}

function onWishItemsClick(e) {
  const addBtn = e.target.closest("[data-add]");
  const rm = e.target.closest("[data-wish-remove]");
  if (addBtn) cartStore.add(addBtn.dataset.add, 1);
  if (rm) toggleWish(rm.dataset.wishRemove);
}

function onWishAllToCart() {
  if (!wishlist.length) { toast("Wishlist is empty", true); return; }
  wishlist.forEach((id) => cartStore.add(id, 1));
  toast(wishlist.length + " item(s) moved to cart");
  wishlist = [];
  try { localStorage.setItem(STORAGE_WISH, JSON.stringify(wishlist)); } catch (_) {}
  renderWishlist();
  renderProducts();
}

function onNavToggle() {
  registerLayer("mobileNav");
  syncSearchUI();
  const t = $("#navToggle");
  if (t) t.setAttribute("aria-expanded", "true");
}
function closeMnav() {
  unregisterLayer("mobileNav");
  const t = $("#navToggle");
  if (t) t.setAttribute("aria-expanded", "false");
}

function onNewsletterSubmit(e) {
  e.preventDefault();
  const email = $("#newsletterEmail").value.trim();
  if (!/^\S+@\S+\.\S+$/.test(email)) { toast("Please enter a valid email", true); return; }
  toast("Welcome aboard — check your inbox!");
  e.target.reset();
}

// FIX: checkoutInProgress lifecycle — was reset in `finally` immediately after the
// `await api.post` resolved, but `openAccessCodePopup` is NOT awaited (it's a callback-based
// API). So the flag was `false` while the Paystack popup was still open → user could
// submit again → duplicate orders. Now the flag is only cleared in onSuccess/onCancel/onError.
let checkoutInProgress = false;
async function onCheckout() {
  if (checkoutInProgress) return;
  const cart = cartStore.getCart();
  if (Object.keys(cart).length === 0) {
    toast("Your cart is empty", true);
    return;
  }

  // Build cart array for the API
  const cartArray = Object.entries(cart).map(([id, qty]) => ({
    product_id: id,
    quantity: parseInt(qty, 10),
  }));

  // Open a simple checkout form (delivery details)
  openCheckoutForm(async (formData) => {
    if (checkoutInProgress) return; // double-submit guard inside the form too
    checkoutInProgress = true;
    try {
      const res = await api.post("/api/orders/initialize_checkout.php", {
        cart: cartArray,
        customer_name: formData.name,
        customer_phone: formData.phone,
        delivery_gps: formData.gps,
        delivery_street: formData.street,
        delivery_instructions: formData.instructions,
      });
      if (!res || !res.access_code) {
        throw new Error("No access_code returned");
      }
      // Open the Paystack popup. FIX: clear checkoutInProgress only when the popup
      // resolves (onSuccess/onCancel/onError), NOT here — otherwise the user can
      // submit again while the popup is still open.
      openAccessCodePopup({
        accessCode: res.access_code,
        onSuccess: () => {
          checkoutInProgress = false;
          toast("Payment received! Your order is being processed.");
          cartStore.clear();
          closeCheckoutForm();
          renderCart();
        },
        onCancel: () => {
          checkoutInProgress = false;
          toast("Payment cancelled. Your cart is saved.");
          closeCheckoutForm();
        },
        onError: (err) => {
          checkoutInProgress = false;
          const kind = err.kind === "load" ? "load" : "popup";
          toast("Paystack " + kind + " error: " + (err.message || "unknown"), true);
        },
      });
    } catch (err) {
      checkoutInProgress = false;
      const msg = (err && err.payload && err.payload.error) || err.message || "Checkout failed.";
      toast(msg, true);
    }
    // NOTE: no `finally` — checkoutInProgress is cleared in the Paystack callbacks above.
  });
}

function openCheckoutForm(onSubmit) {
  let modal = document.getElementById("checkoutFormModal");
  if (!modal) {
    modal = document.createElement("div");
    modal.id = "checkoutFormModal";
    modal.className = "modal";
    modal.setAttribute("role", "dialog");
    modal.setAttribute("aria-modal", "true");
    modal.setAttribute("aria-label", "Checkout");
    modal.innerHTML = `
      <div class="modal__panel" style="max-width: 440px;">
        <button class="modal__close" id="checkoutFormClose" aria-label="Close">&times;</button>
        <div class="modal__body" style="padding: 28px;">
          <h3 style="margin-bottom: 16px;">Delivery details</h3>
          <form id="checkoutForm" novalidate>
            <div style="margin-bottom: 14px;">
              <label style="font-size: 13px; font-weight: 600;">Name</label>
              <input id="cf-name" type="text" required style="width: 100%; padding: 10px 12px; border: 1.5px solid var(--line); border-radius: 10px; margin-top: 4px;">
            </div>
            <div style="margin-bottom: 14px;">
              <label style="font-size: 13px; font-weight: 600;">Phone</label>
              <input id="cf-phone" type="tel" required inputmode="numeric" placeholder="0541234567" style="width: 100%; padding: 10px 12px; border: 1.5px solid var(--line); border-radius: 10px; margin-top: 4px;">
            </div>
            <div style="margin-bottom: 14px;">
              <label style="font-size: 13px; font-weight: 600;">GhanaPost GPS</label>
              <input id="cf-gps" type="text" required placeholder="GA-183-4290" style="width: 100%; padding: 10px 12px; border: 1.5px solid var(--line); border-radius: 10px; margin-top: 4px;">
            </div>
            <div style="margin-bottom: 14px;">
              <label style="font-size: 13px; font-weight: 600;">Street (optional)</label>
              <input id="cf-street" type="text" style="width: 100%; padding: 10px 12px; border: 1.5px solid var(--line); border-radius: 10px; margin-top: 4px;">
            </div>
            <div style="margin-bottom: 18px;">
              <label style="font-size: 13px; font-weight: 600;">Delivery instructions (optional)</label>
              <textarea id="cf-instructions" rows="2" style="width: 100%; padding: 10px 12px; border: 1.5px solid var(--line); border-radius: 10px; margin-top: 4px;"></textarea>
            </div>
            <button type="submit" class="btn btn--primary btn--block btn--lg">Pay now</button>
          </form>
        </div>
      </div>
    `;
    document.body.appendChild(modal);
    modal.querySelector("#checkoutFormClose").addEventListener("click", closeCheckoutForm);
    modal.addEventListener("click", (e) => { if (e.target === modal) closeCheckoutForm(); });
  }
  modal.classList.add("is-open");
  modal.setAttribute("aria-hidden", "false");
  document.body.style.overflow = "hidden";

  // Wire the form (only once)
  const form = modal.querySelector("#checkoutForm");
  form.onsubmit = (e) => {
    e.preventDefault();
    const data = {
      name: modal.querySelector("#cf-name").value.trim(),
      phone: modal.querySelector("#cf-phone").value.trim(),
      gps: modal.querySelector("#cf-gps").value.trim().toUpperCase(),
      street: modal.querySelector("#cf-street").value.trim(),
      instructions: modal.querySelector("#cf-instructions").value.trim(),
    };
    if (!data.name || data.name.length < 2) return toast("Please enter your name.", true);
    if (!/^0\d{9}$/.test(data.phone)) return toast("Phone must be 10 digits starting with 0.", true);
    if (!/^[A-Z]{2}-\d{3}-\d{4}$/.test(data.gps)) return toast("GPS must be AA-NNN-NNNN (e.g., GA-183-4290).", true);
    onSubmit(data);
  };
}

function closeCheckoutForm() {
  const modal = document.getElementById("checkoutFormModal");
  if (modal) {
    modal.classList.remove("is-open");
    modal.setAttribute("aria-hidden", "true");
    document.body.style.overflow = "";
  }
}

export function unmount() {
  if (heroSlider) heroSlider.destroy();
  if (testiSlider) testiSlider.destroy();
  if (countdownTimer) clearInterval(countdownTimer);
  if (topbarTimer) clearInterval(topbarTimer);
  if (dealBarTimeout) clearTimeout(dealBarTimeout);
  // FIX (audit m11): disconnect the IntersectionObserver to release its references
  if (imgObserver) {
    imgObserver.disconnect();
    imgObserver = null;
  }
  document.removeEventListener("click", onGlobalClick);
  window.removeEventListener("hashchange", onHashChange);
  // FIX (audit m11): remove the app:navigate listener (added in Task 10)
  window.removeEventListener("app:navigate", onHashChange);
  // FIX (audit m11): unsubscribe pubsub listeners (was leaking across remounts)
  if (pubsubUnsubscribers.length) {
    pubsubUnsubscribers.forEach((unsub) => { try { unsub(); } catch (_) {} });
    pubsubUnsubscribers.length = 0;
  }
  countdownTimer = null;
  topbarTimer = null;
  heroSlider = null;
  testiSlider = null;
  // Phase 3: clear API mode so a remount on the root URL falls back to local demo
  apiProducts = null;
  apiStoreSlug = null;
  root = null;
}
