// js/views/adminDashboardView.js
// Phase 6: full Owner Admin dashboard. Fetches GET /api/admin/metrics.php (admin-only)
// and populates the 10 KPI cards + Top 10 stores table + Recent signups list.
// Auto-refreshes every 30 seconds.

import { escapeHTML, escapeAttr } from "../utils/escape.js";
import { formatPesewas, formatDate } from "../utils/format.js";
import * as authStore from "../state/authStore.js";
import * as api from "../services/api.js";
import { toast } from "../components/toast.js";

const KPI_DEFS = [
  { id: "total_merchants", label: "Merchants", get: (m) => m?.total_users?.merchants ?? "—", hint: "Active + expired merchants" },
  { id: "total_resellers", label: "Resellers", get: (m) => m?.total_users?.resellers ?? "—", hint: "Active + expired resellers" },
  { id: "active_users", label: "Active Users", get: (m) => m?.total_users?.active ?? "—", hint: "Currently active" },
  { id: "mrr", label: "MRR", get: (m) => formatPesewas(m?.mrr_pesewas ?? 0), hint: "Monthly recurring revenue" },
  { id: "kyc_pending", label: "KYC Pending", get: (m) => m?.kyc_pending ?? "—", hint: "Awaiting review" },
  { id: "subaccount_pending", label: "Subaccount Pending", get: (m) => m?.subaccount_pending ?? "—", hint: "Cron retries every 5 min" },
  { id: "orders_pending", label: "Orders Pending", get: (m) => m?.orders_by_status?.pending ?? 0, hint: "Awaiting payment" },
  { id: "orders_delivered", label: "Orders Delivered", get: (m) => m?.orders_by_status?.delivered ?? 0, hint: "All items delivered" },
  { id: "outstanding_debt", label: "Outstanding Debt", get: (m) => formatPesewas(m?.outstanding_debt_pesewas ?? 0), hint: "From chargebacks" },
  { id: "revenue_30d", label: "Revenue (30d)", get: (m) => formatPesewas(m?.revenue_30d_pesewas ?? 0), hint: "Subscriptions + ledger" },
];

let refreshTimer = null;

export function mount(container) {
  const user = authStore.getState();
  if (!authStore.isAuthenticated() || user?.role !== "admin") {
    container.innerHTML = `
      <section class="section container">
        <header class="section__head reveal">
          <p class="section__kicker">Admin</p>
          <h2 class="section__title">Admin access required</h2>
        </header>
        <p style="color: var(--muted); margin-bottom: 24px;">
          You must be signed in as an admin to view this dashboard.
        </p>
        <a href="#/signin" class="btn btn--primary">Sign in</a>
      </section>`;
    return;
  }

  container.innerHTML = `
    <section class="section container" id="admin">
      <header class="section__head reveal">
        <div>
          <p class="section__kicker">Owner Admin</p>
          <h2 class="section__title">Esekiosk Metrics</h2>
        </div>
        <div style="display: flex; gap: 10px; align-items: center;">
          <span id="adminLastRefresh" style="font-size: 12px; color: var(--muted);">Loading…</span>
          <button class="btn btn--light" id="adminRefreshBtn" style="padding: 8px 16px; font-size: 13px;">Refresh</button>
          <a href="#/dashboard" class="btn btn--ghost" style="color: var(--g700); padding: 8px 16px; font-size: 13px;">Back to dashboard</a>
        </div>
      </header>

      <!-- KPI cards -->
      <div id="adminKpis" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 16px; margin-bottom: 32px;">
        ${KPI_DEFS.map(
          (kpi) => `
          <div class="card" style="padding: 20px;">
            <div class="card__body">
              <p style="font-size: 12px; color: var(--muted); text-transform: uppercase; letter-spacing: 1.4px; margin-bottom: 8px;">
                ${escapeHTML(kpi.label)}
              </p>
              <p style="font-size: 28px; font-weight: 700; color: var(--g700); margin-bottom: 4px;" id="kpi-${kpi.id}">
                —
              </p>
              <p style="font-size: 12px; color: var(--muted);">${escapeHTML(kpi.hint)}</p>
            </div>
          </div>`
        ).join("")}
      </div>

      <!-- Top 10 stores by GMV (last 30 days) -->
      <div style="margin-bottom: 32px;">
        <h3 style="font-size: 18px; font-weight: 700; margin-bottom: 16px;">Top 10 Stores by GMV (30 days)</h3>
        <div id="adminTopStores" style="background: #fff; border: 1px solid var(--line); border-radius: 12px; overflow: hidden;">
          <p style="padding: 20px; color: var(--muted); text-align: center;">Loading…</p>
        </div>
      </div>

      <!-- Recent signups (last 7 days) -->
      <div>
        <h3 style="font-size: 18px; font-weight: 700; margin-bottom: 16px;">Recent Signups (7 days)</h3>
        <div id="adminRecentSignups" style="background: #fff; border: 1px solid var(--line); border-radius: 12px; overflow: hidden;">
          <p style="padding: 20px; color: var(--muted); text-align: center;">Loading…</p>
        </div>
      </div>
    </section>
  `;

  document.getElementById("adminRefreshBtn")?.addEventListener("click", () => fetchMetrics(container));

  fetchMetrics(container);
  // Auto-refresh every 30 seconds
  refreshTimer = setInterval(() => fetchMetrics(container), 30000);
}

async function fetchMetrics(container) {
  try {
    const res = await api.get("/api/admin/metrics.php");
    renderKpis(res);
    renderTopStores(res.top_stores_by_gmv || []);
    renderRecentSignups(res.recent_signups || []);
    const ts = new Date().toLocaleTimeString();
    const el = document.getElementById("adminLastRefresh");
    if (el) el.textContent = "Last refresh: " + ts;
  } catch (err) {
    const msg = (err && err.payload && err.payload.error) || err.message || "Failed to load metrics.";
    toast(msg, true);
    const el = document.getElementById("adminLastRefresh");
    if (el) el.textContent = "Refresh failed";
  }
}

function renderKpis(metrics) {
  KPI_DEFS.forEach((kpi) => {
    const el = document.getElementById("kpi-" + kpi.id);
    if (el) el.textContent = String(kpi.get(metrics));
  });
}

function renderTopStores(stores) {
  const el = document.getElementById("adminTopStores");
  if (!el) return;
  if (!stores.length) {
    el.innerHTML = '<p style="padding: 20px; color: var(--muted); text-align: center;">No store sales in the last 30 days.</p>';
    return;
  }
  el.innerHTML = `
    <table style="width: 100%; border-collapse: collapse;">
      <thead>
        <tr style="background: var(--soft); font-size: 12px; text-transform: uppercase; letter-spacing: 1px; color: var(--muted);">
          <th style="padding: 12px 16px; text-align: left;">Rank</th>
          <th style="padding: 12px 16px; text-align: left;">Store</th>
          <th style="padding: 12px 16px; text-align: left;">Owner</th>
          <th style="padding: 12px 16px; text-align: right;">Orders</th>
          <th style="padding: 12px 16px; text-align: right;">GMV</th>
          <th style="padding: 12px 16px;"></th>
        </tr>
      </thead>
      <tbody>
        ${stores
          .map(
            (s, i) => `
          <tr style="border-top: 1px solid var(--line);">
            <td style="padding: 12px 16px; font-weight: 700; color: var(--muted);">${i + 1}</td>
            <td style="padding: 12px 16px; font-weight: 600;">${escapeHTML(s.store_slug || "")}</td>
            <td style="padding: 12px 16px;">${escapeHTML(s.username || "")}</td>
            <td style="padding: 12px 16px; text-align: right;">${escapeHTML(String(s.order_count))}</td>
            <td style="padding: 12px 16px; text-align: right; font-weight: 700; color: var(--g700);">${formatPesewas(s.gmv_pesewas)}</td>
            <td style="padding: 12px 16px; text-align: right;">
              <a href="#/store/${escapeAttr(s.store_slug || "")}" class="btn btn--light btn--sm" style="padding: 4px 10px; font-size: 12px;">View</a>
            </td>
          </tr>`
          )
          .join("")}
      </tbody>
    </table>`;
}

function renderRecentSignups(signups) {
  const el = document.getElementById("adminRecentSignups");
  if (!el) return;
  if (!signups.length) {
    el.innerHTML = '<p style="padding: 20px; color: var(--muted); text-align: center;">No new signups in the last 7 days.</p>';
    return;
  }
  el.innerHTML = `
    <table style="width: 100%; border-collapse: collapse;">
      <thead>
        <tr style="background: var(--soft); font-size: 12px; text-transform: uppercase; letter-spacing: 1px; color: var(--muted);">
          <th style="padding: 12px 16px; text-align: left;">Username</th>
          <th style="padding: 12px 16px; text-align: left;">Role</th>
          <th style="padding: 12px 16px; text-align: left;">Cycle</th>
          <th style="padding: 12px 16px; text-align: left;">Joined</th>
        </tr>
      </thead>
      <tbody>
        ${signups
          .map(
            (s) => `
          <tr style="border-top: 1px solid var(--line);">
            <td style="padding: 12px 16px; font-weight: 600;">${escapeHTML(s.username || "")}</td>
            <td style="padding: 12px 16px; text-transform: capitalize;">${escapeHTML(s.role || "")}</td>
            <td style="padding: 12px 16px; text-transform: capitalize;">${escapeHTML(s.subscription_cycle || "—")}</td>
            <td style="padding: 12px 16px; color: var(--muted);">${escapeHTML(formatDate(s.created_at) || "")}</td>
          </tr>`
          )
          .join("")}
      </tbody>
    </table>`;
}

export function unmount() {
  if (refreshTimer) {
    clearInterval(refreshTimer);
    refreshTimer = null;
  }
}
