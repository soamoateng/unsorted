// js/views/resellerInventoryView.js
// Phase 3: reseller browses merchant wholesale inventory. Each product card has an
// "Add to My Store" button that opens a small modal asking for the selling price.
// clone_product.php enforces retail_price > wholesale_price server-side.
//
// SRP: owns the reseller inventory view + clone modal. Auth required (role='reseller').

import { escapeHTML, escapeAttr } from "../utils/escape.js";
import { formatPesewas } from "../utils/format.js";
import { toast } from "../components/toast.js";
import * as api from "../services/api.js";
import { getBasePath } from "../services/api.js";
import * as authStore from "../state/authStore.js";

let products = [];
let cloneTarget = null; // the product being cloned

function renderGrid() {
  const grid = document.getElementById("resellerGrid");
  if (!grid) return;
  if (!products.length) {
    grid.innerHTML = '<p style="grid-column: 1/-1; text-align: center; padding: 40px; color: var(--muted);">No merchant products available to clone yet.</p>';
    return;
  }
  grid.innerHTML = products.map((p, i) => `
    <article class="card" style="padding: 16px; animation-delay: ${(i % 8) * 60}ms">
      <img src="${getBasePath()}/api/${escapeAttr(p.image_path)}" alt="${escapeAttr(p.name)}" loading="lazy"
           style="width: 100%; height: 160px; object-fit: cover; border-radius: 8px; margin-bottom: 12px;">
      <span style="font-size: 11px; color: var(--muted); text-transform: uppercase; letter-spacing: 1px;">
        By ${escapeHTML(p.owner_username || "Merchant")}
      </span>
      <h3 style="font-size: 15px; font-weight: 600; margin: 4px 0 6px;">${escapeHTML(p.name)}</h3>
      <p style="font-size: 13px; color: var(--muted); margin-bottom: 8px; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;">
        ${escapeHTML(p.description || "")}
      </p>
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
        <div>
          <p style="font-size: 11px; color: var(--muted);">Wholesale</p>
          <p style="font-size: 18px; font-weight: 700; color: var(--g700);">${formatPesewas(p.wholesale_price_pesewas)}</p>
        </div>
        <div style="text-align: right;">
          <p style="font-size: 11px; color: var(--muted);">Stock</p>
          <p style="font-size: 16px; font-weight: 600;">${escapeHTML(String(p.stock ?? 0))}</p>
        </div>
      </div>
      <button class="btn btn--primary btn--block" data-clone="${escapeAttr(p.id)}">
        Add to My Store
      </button>
    </article>
  `).join("");

  // Wire up clone buttons
  grid.querySelectorAll("[data-clone]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const id = btn.dataset.clone;
      const product = products.find((p) => String(p.id) === String(id));
      if (product) openCloneModal(product);
    });
  });
}

function openCloneModal(product) {
  cloneTarget = product;
  const modal = document.getElementById("cloneModal");
  if (!modal) return;
  modal.querySelector("#cloneProductName").textContent = product.name;
  modal.querySelector("#cloneWholesale").textContent = formatPesewas(product.wholesale_price_pesewas);
  const input = modal.querySelector("#cloneRetail");
  // FIX: simplify min calculation (was a no-op round-trip). Set min to wholesale + 1 pesewa.
  input.min = product.wholesale_price_pesewas + 1;
  input.value = "";
  modal.classList.add("is-open");
  modal.setAttribute("aria-hidden", "false");
  document.body.style.overflow = "hidden";
  setTimeout(() => input.focus(), 50);
}

function closeCloneModal() {
  const modal = document.getElementById("cloneModal");
  if (!modal) return;
  modal.classList.remove("is-open");
  modal.setAttribute("aria-hidden", "true");
  document.body.style.overflow = "";
  cloneTarget = null;
}

async function submitClone(e) {
  e.preventDefault();
  if (!cloneTarget) return;
  const modal = document.getElementById("cloneModal");
  const input = modal.querySelector("#cloneRetail");
  // FIX: validate integer properly (was parseInt which silently truncated "5900.99" → 5900)
  const retail = Number(input.value);
  if (!Number.isInteger(retail) || retail <= cloneTarget.wholesale_price_pesewas) {
    toast("Selling price must be an integer greater than the wholesale price (" + formatPesewas(cloneTarget.wholesale_price_pesewas) + ").", true);
    return;
  }
  const btn = modal.querySelector("#cloneSubmit");
  const original = btn.innerHTML;
  btn.disabled = true;
  btn.innerHTML = "Cloning…";
  try {
    const res = await api.post("/api/products/clone_product.php", {
      parent_product_id: cloneTarget.id,
      retail_price_pesewas: retail,
    });
    toast("Cloned: " + (res.clone?.name || "OK") + ". Selling at " + formatPesewas(retail));
    closeCloneModal();
  } catch (err) {
    const msg = (err && err.payload && err.payload.error) || err.message || "Clone failed.";
    toast(msg, true);
  } finally {
    btn.disabled = false;
    btn.innerHTML = original;
  }
}

export function mount(container) {
  const user = authStore.getState();
  if (!authStore.isAuthenticated() || user?.role !== "reseller") {
    container.innerHTML = `
      <section class="section container">
        <h2 class="section__title">Resellers only</h2>
        <p style="color: var(--muted); margin-bottom: 24px;">You must be signed in as a reseller to browse merchant inventory.</p>
        <a href="#/signin" class="btn btn--primary">Sign in</a>
      </section>`;
    return;
  }
  container.innerHTML = `
    <section class="section container" id="resellerInventory">
      <header class="section__head reveal">
        <div>
          <p class="section__kicker">Reseller</p>
          <h2 class="section__title">Merchant Wholesale Inventory</h2>
        </div>
        <a href="#/dashboard" class="btn btn--ghost" style="color: var(--g700);">Back to dashboard</a>
      </header>
      <p style="color: var(--muted); margin-bottom: 24px;">
        Browse merchant products, click <strong>Add to My Store</strong>, and set your selling price.
        Your stock column stays <code>NULL</code> and resolves against the merchant's live count.
      </p>
      <div id="resellerGrid" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 20px;">
        <p style="grid-column: 1/-1; text-align: center; padding: 40px; color: var(--muted);">Loading merchant products…</p>
      </div>
    </section>

    <!-- Clone modal -->
    <div class="modal" id="cloneModal" aria-hidden="true" role="dialog" aria-modal="true" aria-label="Clone product">
      <div class="modal__panel">
        <button class="modal__close" id="cloneClose" aria-label="Close">&times;</button>
        <div class="modal__body" style="padding: 28px;">
          <p class="modal__cat">Add to my store</p>
          <h3 class="modal__title" id="cloneProductName"></h3>
          <p style="color: var(--muted); margin-bottom: 18px;">
            Merchant wholesale price: <strong id="cloneWholesale" style="color: var(--g700);"></strong>
          </p>
          <form id="cloneForm">
            <label for="cloneRetail" style="display: block; font-size: 13px; font-weight: 600; margin-bottom: 6px;">
              Your selling price (pesewas)
            </label>
            <input id="cloneRetail" type="number" min="1" step="1" required inputmode="numeric"
                   style="width: 100%; padding: 12px 14px; border: 1.5px solid var(--line); border-radius: 10px; font-size: 14.5px; margin-bottom: 8px;">
            <small style="color: var(--muted); font-size: 12px;">Must be greater than the wholesale price. 1 GHS = 100 pesewas (e.g., 5900 = ₵59.00).</small>
            <button type="submit" id="cloneSubmit" class="btn btn--primary btn--block btn--lg" style="margin-top: 18px;">
              Clone to my store
            </button>
          </form>
        </div>
      </div>
    </div>

    <style>
      #cloneModal { position: fixed; inset: 0; z-index: 90; display: none; background: rgba(0,0,0,.5); }
      #cloneModal.is-open { display: flex; align-items: center; justify-content: center; }
      #cloneModal .modal__panel { background: #fff; border-radius: 16px; max-width: 440px; width: 92%; position: relative; }
      #cloneClose { position: absolute; top: 16px; right: 16px; width: 32px; height: 32px; border-radius: 50%; background: var(--soft); }
    </style>
  `;

  // Wire up modal close
  document.getElementById("cloneClose").addEventListener("click", closeCloneModal);
  document.getElementById("cloneModal").addEventListener("click", (e) => {
    if (e.target.id === "cloneModal") closeCloneModal();
  });
  // FIX: name the handler so unmount can remove it (was anonymous — leaked across navigations)
  document.addEventListener("keydown", onCloneModalKeydown);
  document.getElementById("cloneForm").addEventListener("submit", submitClone);

  // Fetch wholesale products
  api.get("/api/products/get_products.php?wholesale=1")
    .then((res) => {
      products = (res && res.products) ? res.products : [];
      renderGrid();
    })
    .catch((err) => {
      const msg = (err && err.payload && err.payload.error) || err.message || "Failed to load inventory.";
      toast(msg, true);
      const grid = document.getElementById("resellerGrid");
      if (grid) grid.innerHTML = '<p style="grid-column: 1/-1; text-align: center; padding: 40px; color: var(--red);">Could not load merchant inventory.</p>';
    });
}

// FIX: named keydown handler so unmount can remove it (was anonymous — leaked)
function onCloneModalKeydown(e) {
  if (e.key === "Escape") closeCloneModal();
}

export function unmount() {
  closeCloneModal();
  // FIX: remove the keydown listener (was leaking across navigations)
  document.removeEventListener("keydown", onCloneModalKeydown);
  products = [];
}
