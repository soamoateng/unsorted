// js/views/renewView.js
// Phase 2 stub. Subscription renewal flow is wired in Phase 6 alongside the
// admin dashboard. For now, this view surfaces a banner explaining the user
// must renew and links back to #/signin (logout).

import { escapeHTML } from "../utils/escape.js";

export function mount(container) {
  container.innerHTML = `
    <section class="section container" id="renew">
      <header class="section__head section__head--center reveal">
        <p class="section__kicker">Subscription expired</p>
        <h2 class="section__title">Renew your Esekiosk subscription</h2>
      </header>
      <div style="max-width: 560px; margin: 0 auto; text-align: center;">
        <p style="color: var(--muted); margin-bottom: 24px;">
          Your subscription has expired. Renew to continue selling on Esekiosk.
        </p>
        <p style="color: var(--muted); font-size: 13px;">
          Phase 6 will wire this view to a Paystack one-time renewal charge.
          Until then, please contact support or sign in again with an active plan.
        </p>
        <a href="#/signin" class="btn btn--primary" style="margin-top: 24px;">Back to sign in</a>
      </div>
    </section>
  `;
}

export function unmount() {
  /* nothing to clean up */
}
