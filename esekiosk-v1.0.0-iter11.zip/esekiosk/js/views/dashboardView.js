// js/views/dashboardView.js
// Phase 5: full Store Admin dashboard.
//
// Layout (PRD):
//   - Desktop (≥768px): sidebar <aside> with nav links (Orders, Products, Profile)
//   - Mobile (<768px): bottom-nav <nav class="bottom-nav"> with the same links
//   - Main content wrapped in max-width: 1200px container
//
// Orders tab:
//   - Fetches GET /api/orders/get_orders.php (IDOR-safe — only this user's orders)
//   - Mixed carts may span multiple merchants → each item shows its own status
//   - Per-item status cycling: Pending → Processing → Shipped → Delivered
//   - Calls PATCH /api/orders/update_order_status.php on each item status change
//   - Recomputes parent order status client-side via computeOverallStatus(items)
//
// SRP: owns the dashboard view's mount/unmount + tab switching + order interactions.

import { escapeHTML, escapeAttr } from "../utils/escape.js";
import { formatPesewas, formatDate } from "../utils/format.js";
import { computeOverallStatus, nextStatus, isValidTransition } from "../utils/orderStatus.js";
import * as authStore from "../state/authStore.js";
import * as api from "../services/api.js";
import { toast } from "../components/toast.js";
import { openSheet as openAddProductSheet, unmount as unmountAddProductSheet } from "../components/addProductSheet.js";

let activeTab = "orders";
let orders = [];
let loadingOrders = false;

export function mount(container) {
  const user = authStore.getState();
  const isAuth = authStore.isAuthenticated();
  const role = user?.role || "merchant";

  if (!isAuth) {
    container.innerHTML = `
      <section class="section container">
        <header class="section__head reveal">
          <p class="section__kicker">Dashboard</p>
          <h2 class="section__title">Please sign in</h2>
        </header>
        <p style="color: var(--muted); margin-bottom: 24px;">You need to sign in to view your dashboard.</p>
        <a href="#/signin" class="btn btn--primary">Sign in</a>
      </section>`;
    return;
  }

  renderShell(container);
  switchTab("orders");
}

function renderShell(container) {
  const user = authStore.getState();
  const role = user?.role || "merchant";

  container.innerHTML = `
    <div class="dash-shell">
      <!-- Desktop sidebar -->
      <aside class="dash-sidebar" id="dashSidebar">
        <div class="dash-sidebar__brand">
          <a href="#/" class="header__logo">
            <svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
              <path d="M6 7h12l1.2 12.2a1.8 1.8 0 0 1-1.8 1.8H6.6a1.8 1.8 0 0 1-1.8-1.8L6 7z"/><path d="M9 10V6a3 3 0 0 1 6 0v4"/>
            </svg>
            Esekiosk<span class="header__logo-dot">.</span>
          </a>
        </div>
        <nav class="dash-sidebar__nav">
          <button class="dash-sidebar__link ${activeTab === 'orders' ? 'is-active' : ''}" data-tab="orders">
            <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M9 11H5a2 2 0 0 0-2 2v7h6V11zM9 11V5a2 2 0 0 1 2-2h2a2 2 0 0 1 2 2v6M15 11v9h6v-7a2 2 0 0 0-2-2h-4"/></svg>
            Orders
          </button>
          ${role === "merchant"
            ? `<button class="dash-sidebar__link" data-tab="products">
                <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/></svg>
                Products
              </button>`
            : ""}
          ${role === "reseller"
            ? `<a href="#/inventory" class="dash-sidebar__link">
                <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/></svg>
                Browse Inventory
              </a>`
            : ""}
          <a href="#/admin" class="dash-sidebar__link" ${role !== 'admin' ? 'style="opacity:.6"' : ''}>
            <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>
            Admin
          </a>
        </nav>
        <div class="dash-sidebar__user">
          <p style="font-size: 12px; color: var(--muted);">Signed in as</p>
          <p style="font-weight: 600; font-size: 14px;">${escapeHTML(user?.username || "")}</p>
          <p style="font-size: 12px; color: var(--muted); text-transform: capitalize;">${escapeHTML(role)}</p>
          <a href="#/signin" id="dashLogoutLink" class="btn btn--light" style="margin-top: 12px; padding: 6px 14px; font-size: 13px;">Sign out</a>
        </div>
      </aside>

      <!-- Main content -->
      <main class="dash-main">
        <header class="dash-header">
          <button class="dash-burger" id="dashBurger" aria-label="Open menu" aria-expanded="false">
            <span></span><span></span><span></span>
          </button>
          <h1 class="dash-title" id="dashTitle">Orders</h1>
        </header>
        <div class="dash-content" id="dashContent">
          <p style="color: var(--muted); padding: 40px;">Loading…</p>
        </div>
      </main>

      <!-- Mobile bottom-nav -->
      <nav class="bottom-nav" id="bottomNav">
        <button class="bottom-nav__link ${activeTab === 'orders' ? 'is-active' : ''}" data-tab="orders">
          <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M9 11H5a2 2 0 0 0-2 2v7h6V11zM9 11V5a2 2 0 0 1 2-2h2a2 2 0 0 1 2 2v6M15 11v9h6v-7a2 2 0 0 0-2-2h-4"/></svg>
          <span>Orders</span>
        </button>
        ${role === "merchant"
          ? `<button class="bottom-nav__link" data-tab="products">
              <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/></svg>
              <span>Products</span>
            </button>`
          : `<a href="#/inventory" class="bottom-nav__link">
              <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/></svg>
              <span>Browse</span>
            </a>`}
        <a href="#/admin" class="bottom-nav__link">
          <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>
          <span>Admin</span>
        </a>
      </nav>
    </div>

    <style>
      .dash-shell { display: grid; grid-template-columns: 240px 1fr; min-height: 100vh; }
      @media (max-width: 768px) {
        .dash-shell { grid-template-columns: 1fr; padding-bottom: 64px; }
        .dash-sidebar { display: none; }
      }
      .dash-sidebar {
        background: var(--g900); color: #fff; padding: 24px 16px;
        display: flex; flex-direction: column; gap: 24px;
        position: sticky; top: 0; height: 100vh;
      }
      .dash-sidebar__brand a { color: #fff; font-size: 22px; font-weight: 800; display: inline-flex; align-items: center; gap: 6px; }
      .dash-sidebar__nav { display: flex; flex-direction: column; gap: 4px; flex: 1; }
      .dash-sidebar__link {
        display: flex; align-items: center; gap: 10px;
        padding: 11px 14px; border-radius: 10px;
        color: rgba(255,255,255,.85); font-size: 14.5px; font-weight: 500;
        text-align: left; width: 100%; transition: background .15s, color .15s;
      }
      .dash-sidebar__link:hover, .dash-sidebar__link.is-active { background: rgba(255,255,255,.12); color: #fff; }
      .dash-sidebar__user { padding-top: 16px; border-top: 1px solid rgba(255,255,255,.12); }
      .dash-main { padding: 24px; max-width: 1200px; width: 100%; }
      @media (max-width: 768px) { .dash-main { padding: 16px; } }
      .dash-header { display: flex; align-items: center; gap: 12px; margin-bottom: 24px; }
      .dash-burger { display: none; flex-direction: column; gap: 4.5px; padding: 6px; }
      .dash-burger span { width: 21px; height: 2.2px; background: var(--ink); border-radius: 2px; }
      @media (max-width: 768px) { .dash-burger { display: flex; } }
      .dash-title { font-size: 26px; font-weight: 700; }

      /* Bottom-nav (mobile) */
      .bottom-nav {
        display: none; position: fixed; bottom: 0; left: 0; right: 0;
        background: #fff; border-top: 1px solid var(--line);
        padding: 8px 0 calc(8px + env(safe-area-inset-bottom));
        z-index: 50;
      }
      @media (max-width: 768px) { .bottom-nav { display: flex; justify-content: space-around; } }
      .bottom-nav__link {
        display: flex; flex-direction: column; align-items: center; gap: 2px;
        padding: 6px 16px; font-size: 11px; color: var(--muted);
        font-weight: 500; transition: color .15s;
      }
      .bottom-nav__link.is-active, .bottom-nav__link:hover { color: var(--g700); }

      /* Orders list */
      .order-card {
        background: #fff; border: 1px solid var(--line); border-radius: 12px;
        padding: 20px; margin-bottom: 16px;
      }
      .order-card__head {
        display: flex; justify-content: space-between; align-items: flex-start;
        gap: 16px; margin-bottom: 16px; flex-wrap: wrap;
      }
      .order-card__ref { font-size: 12px; color: var(--muted); font-family: monospace; }
      .order-card__date { font-size: 12px; color: var(--muted); }
      .order-card__customer { font-size: 14px; font-weight: 600; margin-top: 4px; }
      .order-card__delivery { font-size: 12px; color: var(--muted); margin-top: 2px; }
      .order-card__total { font-size: 18px; font-weight: 700; color: var(--g700); }
      .order-status-badge {
        display: inline-block; padding: 4px 10px; border-radius: 999px;
        font-size: 11px; font-weight: 600; text-transform: uppercase; letter-spacing: .5px;
      }
      .order-status-badge--pending { background: #fff3cd; color: #856404; }
      .order-status-badge--paid { background: #cce5ff; color: #004085; }
      .order-status-badge--processing { background: #cce5ff; color: #004085; }
      .order-status-badge--partially_shipped { background: #ffeeba; color: #856404; }
      .order-status-badge--shipped { background: #d4edda; color: #155724; }
      .order-status-badge--delivered { background: #d4edda; color: #155724; }
      .order-status-badge--cancelled { background: #f8d7da; color: #721c24; }

      .order-items { display: flex; flex-direction: column; gap: 8px; }
      .order-item {
        display: flex; align-items: center; gap: 12px;
        padding: 10px 12px; background: var(--soft); border-radius: 8px;
      }
      .order-item__img { width: 44px; height: 44px; border-radius: 6px; object-fit: cover; flex-shrink: 0; }
      .order-item__info { flex: 1; min-width: 0; }
      .order-item__name { font-size: 14px; font-weight: 600; }
      .order-item__meta { font-size: 12px; color: var(--muted); margin-top: 2px; }
      .order-item__meta strong { color: var(--ink); }
      .order-item__action { flex-shrink: 0; }
      .item-status-pill {
        display: inline-block; padding: 3px 8px; border-radius: 6px;
        font-size: 11px; font-weight: 600; margin-bottom: 4px;
      }
      .pill--pending { background: #fff3cd; color: #856404; }
      .pill--processing { background: #cce5ff; color: #004085; }
      .pill--shipped { background: #ffeeba; color: #856404; }
      .pill--delivered { background: #d4edda; color: #155724; }
      .pill--cancelled { background: #f8d7da; color: #721c24; }
      .btn--sm { padding: 6px 12px; font-size: 12.5px; border-radius: 8px; }

      .dash-empty { text-align: center; padding: 60px 20px; color: var(--muted); }
      .dash-empty svg { width: 48px; height: 48px; opacity: .4; margin-bottom: 12px; }
    </style>
  `;

  // Wire up tab switching
  const tabButtons = container.querySelectorAll("[data-tab]");
  tabButtons.forEach((btn) => {
    btn.addEventListener("click", () => {
      const tab = btn.dataset.tab;
      switchTab(tab);
    });
  });

  // Wire up logout link
  const logoutLink = container.querySelector("#dashLogoutLink");
  if (logoutLink) {
    logoutLink.addEventListener("click", async (e) => {
      e.preventDefault();
      try {
        // FIX: logout.php accepts POST or DELETE; use POST (was api.del which sends DELETE;
        // endpoint now accepts both, but POST is the canonical method for logout).
        await api.post("/api/auth/logout.php");
      } catch (_) {}
      authStore.setUser(null);
      toast("Signed out");
      window.location.hash = "#/signin";
    });
  }
}

function switchTab(tab) {
  activeTab = tab;
  // Update active states on both sidebar and bottom-nav
  document.querySelectorAll(".dash-sidebar__link, .bottom-nav__link").forEach((el) => {
    el.classList.toggle("is-active", el.dataset.tab === tab);
  });
  const titleEl = document.getElementById("dashTitle");
  if (titleEl) {
    titleEl.textContent = tab.charAt(0).toUpperCase() + tab.slice(1);
  }
  const contentEl = document.getElementById("dashContent");
  if (!contentEl) return;

  if (tab === "orders") {
    loadOrders(contentEl);
  } else if (tab === "products") {
    renderProductsTab(contentEl);
  }
}

async function loadOrders(contentEl) {
  if (loadingOrders) return;
  loadingOrders = true;
  contentEl.innerHTML = '<p style="color: var(--muted); padding: 40px;">Loading orders…</p>';
  try {
    const res = await api.get("/api/orders/get_orders.php");
    orders = (res && res.orders) ? res.orders : [];
    renderOrders(contentEl);
  } catch (err) {
    const msg = (err && err.payload && err.payload.error) || err.message || "Failed to load orders.";
    contentEl.innerHTML = `<p style="color: var(--red); padding: 40px;">${escapeHTML(msg)}</p>`;
  } finally {
    loadingOrders = false;
  }
}

function renderOrders(contentEl) {
  if (!orders.length) {
    contentEl.innerHTML = `
      <div class="dash-empty">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"><path d="M9 11H5a2 2 0 0 0-2 2v7h6V11zM9 11V5a2 2 0 0 1 2-2h2a2 2 0 0 1 2 2v6M15 11v9h6v-7a2 2 0 0 0-2-2h-4"/></svg>
        <h3 style="margin-bottom: 8px;">No orders yet</h3>
        <p>When customers buy from your store, their orders will appear here.</p>
      </div>`;
    return;
  }

  contentEl.innerHTML = orders.map((order) => {
    const overall = computeOverallStatus(order.items);
    const orderTotal = formatPesewas(order.total_paid_pesewas);
    const ref = escapeHTML(order.paystack_reference || "");
    const date = escapeHTML(formatDate(order.created_at) || "");
    const customerName = escapeHTML(order.customer_name || "");
    const customerPhone = escapeHTML(order.customer_phone || "");
    const deliveryGps = escapeHTML(order.delivery_gps || "");
    const deliveryStreet = escapeHTML(order.delivery_street || "");
    const storeSlug = authStore.getState()?.store_slug || "";

    const itemsHTML = order.items.map((item) => {
      const productName = escapeHTML(item.product_name || "");
      const imgSrc = item.image_path
        ? `${api.getBasePath()}/api/${escapeAttr(item.image_path)}`
        : "";
      const qty = item.quantity;
      const wholesale = formatPesewas(item.wholesale_price_pesewas);
      const retail = formatPesewas(item.retail_price_pesewas);
      const status = item.status || "pending";
      // FIX: role gating — resellers can only mark items as 'shipped' (handoff to courier).
      // Merchants can advance through the full chain. Server enforces the same rule.
      const isMerchant = item.fulfilling_merchant_id === authStore.getState()?.id;
      const isReseller = item.reseller_id === authStore.getState()?.id;
      const canUpdate = isMerchant || isReseller;
      const next = canUpdate ? nextStatus(status) : null;
      // If reseller-only (not the merchant), restrict to 'shipped'
      const allowedNext = (isReseller && !isMerchant)
        ? (status === 'pending' ? 'shipped' : null)
        : next;

      return `
        <div class="order-item" data-item-id="${item.id}">
          ${imgSrc ? `<img class="order-item__img" src="${imgSrc}" alt="${productName}" loading="lazy">` : ""}
          <div class="order-item__info">
            <span class="item-status-pill pill--${status}">${escapeHTML(status)}</span>
            <div class="order-item__name">${productName}</div>
            <div class="order-item__meta">
              Qty: <strong>${qty}</strong> · Wholesale: <strong>${wholesale}</strong> · Retail: <strong>${retail}</strong>
              ${item.reseller_id ? ` · <span style="color: var(--g700);">Reseller sale</span>` : ""}
            </div>
          </div>
          <div class="order-item__action">
            ${canUpdate && allowedNext
              ? `<button class="btn btn--primary btn--sm" data-advance-item="${item.id}" data-next-status="${allowedNext}">
                  Mark as ${escapeHTML(allowedNext)}
                </button>`
              : status === "delivered"
                ? `<span style="font-size: 12px; color: var(--g700); font-weight: 600;">✓ Done</span>`
                : status === "cancelled"
                  ? `<span style="font-size: 12px; color: var(--red); font-weight: 600;">Cancelled</span>`
                  : ""
            }
          </div>
        </div>`;
    }).join("");

    return `
      <article class="order-card">
        <div class="order-card__head">
          <div>
            <p class="order-card__ref">${ref}</p>
            <p class="order-card__date">${date}</p>
            <p class="order-card__customer">${customerName} · ${customerPhone}</p>
            <p class="order-card__delivery">Deliver to: ${deliveryGps}${deliveryStreet ? " · " + deliveryStreet : ""}</p>
          </div>
          <div style="text-align: right;">
            <span class="order-status-badge order-status-badge--${overall}">${escapeHTML(overall.replace("_", " "))}</span>
            <p class="order-card__total" style="margin-top: 8px;">${orderTotal}</p>
          </div>
        </div>
        <div class="order-items">
          ${itemsHTML}
        </div>
      </article>`;
  }).join("");

  // Wire up "Mark as ..." buttons
  contentEl.querySelectorAll("[data-advance-item]").forEach((btn) => {
    btn.addEventListener("click", () => advanceItemStatus(btn));
  });
}

async function advanceItemStatus(btn) {
  const itemId = parseInt(btn.dataset.advanceItem, 10);
  const nextStat = btn.dataset.nextStatus;
  if (!itemId || !nextStat) return;

  const original = btn.innerHTML;
  btn.disabled = true;
  btn.innerHTML = "Updating…";
  try {
    const res = await api.post("/api/orders/update_order_status.php", {
      item_id: itemId,
      status: nextStat,
    });
    toast(`Item marked as ${nextStat}`);
    // Update the local orders state + re-render
    for (const order of orders) {
      for (const item of order.items) {
        if (item.id === itemId) {
          item.status = nextStat;
        }
      }
      // Recompute order status
      const newOverall = computeOverallStatus(order.items);
      order.status = newOverall;
    }
    const contentEl = document.getElementById("dashContent");
    if (contentEl) renderOrders(contentEl);
  } catch (err) {
    const msg = (err && err.payload && err.payload.error) || err.message || "Update failed.";
    toast(msg, true);
    btn.disabled = false;
    btn.innerHTML = original;
  }
}

function renderProductsTab(contentEl) {
  const user = authStore.getState();
  if (user?.role !== "merchant") {
    contentEl.innerHTML = '<p style="color: var(--muted); padding: 40px;">Products tab is for merchants only.</p>';
    return;
  }
  contentEl.innerHTML = `
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; flex-wrap: wrap; gap: 12px;">
      <h2 style="font-size: 20px; font-weight: 700;">Your products</h2>
      <button class="btn btn--primary" id="dashUploadBtn">Upload new product</button>
    </div>
    <p style="color: var(--muted);">Phase 5 lists your products here. For now, use the "Upload new product" button to add products. Customers can browse them at <a href="#/store/${escapeAttr(user?.store_slug || "")}" style="color: var(--g700); text-decoration: underline;">your store</a>.</p>
  `;
  const uploadBtn = document.getElementById("dashUploadBtn");
  if (uploadBtn) uploadBtn.addEventListener("click", openAddProductSheet);
}

export function unmount() {
  activeTab = "orders";
  orders = [];
  loadingOrders = false;
  // FIX: clean up the addProductSheet if it was open (was leaking body.overflow + keydown listener)
  unmountAddProductSheet();
}
