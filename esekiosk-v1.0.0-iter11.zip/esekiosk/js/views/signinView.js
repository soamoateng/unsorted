// js/views/signinView.js
// Phase 2: signin form. POSTs to /api/auth/login.php; on success navigates to
// #/dashboard (or #/admin for admin role, #/renew if subscription expired).
//
// FIX: route to #/renew if the backend returns subscription_expired=true.
// FIX: removed redundant dynamic import of api.js (already imported at top).
//
// SRP: owns the signin form UI + validation. Does NOT own session storage
//      (authStore + api.js do that).

import { toast } from "../components/toast.js";
import * as api from "../services/api.js";
import * as authStore from "../state/authStore.js";
import { navigate } from "../router.js";

export function mount(container) {
  container.innerHTML = `
    <section class="section container" id="signin">
      <header class="section__head section__head--center reveal">
        <p class="section__kicker">Welcome back</p>
        <h2 class="section__title">Sign in to Esekiosk</h2>
      </header>

      <form id="signinForm" style="max-width: 440px; margin: 0 auto;" novalidate>
        <div style="margin-bottom: 18px;">
          <label for="si-username" style="display: block; font-size: 13px; font-weight: 600; margin-bottom: 6px;">Username or email</label>
          <input id="si-username" name="username" type="text" required
                 autocomplete="username"
                 style="width: 100%; padding: 12px 14px; border: 1.5px solid var(--line); border-radius: 10px; font-size: 14.5px;">
        </div>

        <div style="margin-bottom: 24px;">
          <label for="si-password" style="display: block; font-size: 13px; font-weight: 600; margin-bottom: 6px;">Password</label>
          <input id="si-password" name="password" type="password" required
                 autocomplete="current-password"
                 style="width: 100%; padding: 12px 14px; border: 1.5px solid var(--line); border-radius: 10px; font-size: 14.5px;">
        </div>

        <button id="signinSubmit" type="submit" class="btn btn--primary btn--block btn--lg">Sign in</button>

        <p style="margin-top: 16px; text-align: center; color: var(--muted); font-size: 13px;">
          New to Esekiosk?
          <a href="#/" style="color: var(--g700); text-decoration: underline;">Choose a plan</a>
        </p>
      </form>
    </section>
  `;

  const form = document.getElementById("signinForm");
  form.addEventListener("submit", onSubmit);

  async function onSubmit(e) {
    e.preventDefault();
    const username = document.getElementById("si-username").value.trim();
    const password = document.getElementById("si-password").value;
    if (!username || !password) return toast("Please enter your username and password.", true);

    const btn = document.getElementById("signinSubmit");
    const originalText = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = "Signing in…";

    try {
      const res = await api.post("/api/auth/login.php", { username, password });
      if (res && res.user) {
        // FIX: pass subscription_expired flag into the user object so authStore
        // and dashboardView can check it
        authStore.setUser({ ...res.user, subscription_expired: res.subscription_expired });
        // FIX: setCsrfToken now syncs into api.js automatically (no dynamic import needed)
        if (res.csrf_token) {
          authStore.setCsrfToken(res.csrf_token);
        }
        toast("Welcome back, " + res.user.username);
        // FIX: route to #/renew if subscription expired (was missing — expired users
        // landed on #/dashboard and hit a dead-end "Please sign in")
        if (res.subscription_expired) {
          navigate("#/renew");
        } else if (res.user.role === "admin") {
          navigate("#/admin");
        } else {
          navigate("#/dashboard");
        }
      } else {
        throw new Error("Invalid response from server.");
      }
    } catch (err) {
      btn.disabled = false;
      btn.innerHTML = originalText;
      const msg = (err && err.payload && err.payload.error) || "Sign in failed. Check your credentials.";
      toast(msg, true);
    }
  }
}

export function unmount() {
  /* nothing to clean up */
}
