// js/views/signupView.js
// Phase 2: signup form. Collects username, email, password, MoMo number + network,
// GhanaPost GPS (merchants only), Ghana Card photo. On submit, POSTs FormData
// to /api/auth/signup.php, gets an access_code back, opens the Paystack popup
// synchronously inside the click handler chain.
//
// Validation mirrors the backend sanitize.php (defense in depth).
//   - phone: /^0\d{9}$/ (Ghana mobile, 10 digits starting 0)
//   - gps:   /^[A-Z]{2}-\d{3}-\d{4}$/ (GhanaPost GPS, tightened from the PRD's \d{3,4})
//   - email: /^\S+@\S+\.\S+$/
//   - password: >= 8 chars
//
// SRP: owns the signup form UI + validation + Paystack-popup trigger.
//      Does NOT own backend whitelisting (signup.php does that).

import { escapeHTML } from "../utils/escape.js";
import { toast } from "../components/toast.js";
import { initKycUploader } from "../components/kycUploader.js";
import { setKycFile } from "../state/authStore.js";
import * as api from "../services/api.js";
import { openAccessCodePopup } from "../services/paystack.js";
import { navigate } from "../router.js";

const REGEX = {
  phone: /^0\d{9}$/,
  gps: /^[A-Z]{2}-\d{3}-\d{4}$/,
  email: /^\S+@\S+\.\S+$/,
};

let submitted = false;

function parseParams() {
  const hash = window.location.hash.replace(/^#/, "");
  const qIdx = hash.indexOf("?");
  if (qIdx < 0) return { role: "merchant", cycle: "monthly" };
  const sp = new URLSearchParams(hash.slice(qIdx + 1));
  const role = sp.get("role") === "reseller" ? "reseller" : "merchant";
  const cycle =
    role === "reseller"
      ? "yearly"
      : ["monthly", "quarterly", "yearly"].includes(sp.get("cycle") || "")
      ? sp.get("cycle")
      : "monthly";
  return { role, cycle };
}

function validateImageFile(file) {
  if (!file) return "Please select your Ghana Card photo.";
  if (!/^image\/(jpeg|png)$/.test(file.type)) return "Ghana Card must be a JPG or PNG image.";
  if (file.size > 4 * 1024 * 1024) return "Ghana Card image must be under 4 MB.";
  return null;
}

export function mount(container) {
  const { role, cycle } = parseParams();
  const isMerchant = role === "merchant";

  container.innerHTML = `
    <section class="section container" id="signup">
      <header class="section__head section__head--center reveal">
        <p class="section__kicker">Sign up · ${escapeHTML(isMerchant ? "Merchant" : "Reseller")}</p>
        <h2 class="section__title">Create your Esekiosk account</h2>
      </header>

      <form id="signupForm" style="max-width: 560px; margin: 0 auto;" novalidate>
        <input type="hidden" name="role" value="${escapeHTML(role)}">
        <input type="hidden" name="subscription_cycle" value="${escapeHTML(cycle)}">

        <div style="margin-bottom: 18px;">
          <label for="su-username" style="display: block; font-size: 13px; font-weight: 600; margin-bottom: 6px;">Username</label>
          <input id="su-username" name="username" type="text" required minlength="3" maxlength="50"
                 autocomplete="username"
                 style="width: 100%; padding: 12px 14px; border: 1.5px solid var(--line); border-radius: 10px; font-size: 14.5px;">
        </div>

        <div style="margin-bottom: 18px;">
          <label for="su-email" style="display: block; font-size: 13px; font-weight: 600; margin-bottom: 6px;">Email</label>
          <input id="su-email" name="email" type="email" required autocomplete="email"
                 style="width: 100%; padding: 12px 14px; border: 1.5px solid var(--line); border-radius: 10px; font-size: 14.5px;">
        </div>

        <div style="margin-bottom: 18px;">
          <label for="su-password" style="display: block; font-size: 13px; font-weight: 600; margin-bottom: 6px;">Password</label>
          <input id="su-password" name="password" type="password" required minlength="8"
                 autocomplete="new-password"
                 style="width: 100%; padding: 12px 14px; border: 1.5px solid var(--line); border-radius: 10px; font-size: 14.5px;">
          <small style="color: var(--muted); font-size: 12px;">At least 8 characters.</small>
        </div>

        <div style="margin-bottom: 18px;">
          <label for="su-momo" style="display: block; font-size: 13px; font-weight: 600; margin-bottom: 6px;">Mobile Money number</label>
          <input id="su-momo" name="momo_number" type="tel" required inputmode="numeric" placeholder="0541234567"
                 autocomplete="tel-national"
                 style="width: 100%; padding: 12px 14px; border: 1.5px solid var(--line); border-radius: 10px; font-size: 14.5px;">
          <small style="color: var(--muted); font-size: 12px;">10 digits starting with 0 (e.g., 0541234567).</small>
        </div>

        <div style="margin-bottom: 18px;">
          <label for="su-network" style="display: block; font-size: 13px; font-weight: 600; margin-bottom: 6px;">MoMo network</label>
          <select id="su-network" name="momo_network" required
                  style="width: 100%; padding: 12px 14px; border: 1.5px solid var(--line); border-radius: 10px; font-size: 14.5px;">
            <option value="">Select network…</option>
            <option value="MTN">MTN Mobile Money</option>
            <option value="TELECEL">Telecel Cash (formerly Vodafone)</option>
            <option value="AT">AT Money (AirtelTigo)</option>
          </select>
          <small style="color: var(--muted); font-size: 12px;">Select your actual network — Mobile Number Portability means we cannot reliably detect it from the prefix.</small>
        </div>

        ${
          isMerchant
            ? `<div style="margin-bottom: 18px;">
                <label for="su-gps" style="display: block; font-size: 13px; font-weight: 600; margin-bottom: 6px;">GhanaPost GPS code</label>
                <input id="su-gps" name="ghana_post_gps" type="text" required placeholder="GA-183-4290"
                       style="width: 100%; padding: 12px 14px; border: 1.5px solid var(--line); border-radius: 10px; font-size: 14.5px;">
                <small style="color: var(--muted); font-size: 12px;">Format: AA-NNN-NNNN (e.g., GA-183-4290). Find yours on the GhanaPostGPS app.</small>
              </div>`
            : ""
        }

        <div style="margin-bottom: 24px;">
          <label style="display: block; font-size: 13px; font-weight: 600; margin-bottom: 6px;">Ghana Card photo</label>
          <div id="kycDrop" class="kyc-drop"
               style="border: 2px dashed var(--line); border-radius: 12px; padding: 24px; text-align: center; cursor: pointer; transition: border-color .18s, background .18s;">
            <input id="kycFile" type="file" accept="image/jpeg,image/png" capture="environment"
                   style="position: absolute; width: 1px; height: 1px; opacity: 0; overflow: hidden;">
            <p id="kycHint" style="color: var(--muted); font-size: 13px; margin: 0;">
              Tap to upload or drag a Ghana Card photo here.<br>
              JPG or PNG, up to 4 MB.
            </p>
            <img id="kycPreview" alt="" style="display: none; max-width: 100%; max-height: 220px; margin-top: 12px; border-radius: 8px;">
          </div>
          <small style="color: var(--muted); font-size: 12px; display: block; margin-top: 6px;">
            Required for AML compliance. An admin will review your card before payouts activate.
          </small>
        </div>

        <button id="signupSubmit" type="submit" class="btn btn--primary btn--block btn--lg">
          Pay &amp; sign up
        </button>

        <p style="margin-top: 16px; text-align: center; color: var(--muted); font-size: 13px;">
          Already have an account?
          <a href="#/signin" style="color: var(--g700); text-decoration: underline;">Sign in</a>
        </p>
      </form>
    </section>

    <style>
      .kyc-drop.kyc-drop--active { border-color: var(--g600); background: var(--g50); }
    </style>
  `;

  // Wire up the KYC uploader
  initKycUploader({
    dropZone: document.getElementById("kycDrop"),
    input: document.getElementById("kycFile"),
    previewEl: document.getElementById("kycPreview"),
    hintEl: document.getElementById("kycHint"),
    validateFn: validateImageFile,
    onError: (msg) => toast(msg, true),
  });

  // Form submit
  const form = document.getElementById("signupForm");
  form.addEventListener("submit", onSubmit);

  async function onSubmit(e) {
    e.preventDefault();
    if (submitted) return; // double-submit guard

    // 1. Client-side validation
    const username = document.getElementById("su-username").value.trim();
    const email = document.getElementById("su-email").value.trim().toLowerCase();
    const password = document.getElementById("su-password").value;
    const momo = document.getElementById("su-momo").value.trim();
    const network = document.getElementById("su-network").value;
    const gps = isMerchant ? document.getElementById("su-gps").value.trim().toUpperCase() : "";
    const kycFile = (document.getElementById("kycFile").files && document.getElementById("kycFile").files[0]) || null;

    if (!username || username.length < 3) return toast("Username must be at least 3 characters.", true);
    if (!REGEX.email.test(email)) return toast("Please enter a valid email.", true);
    if (!password || password.length < 8) return toast("Password must be at least 8 characters.", true);
    if (!REGEX.phone.test(momo)) return toast("MoMo number must be 10 digits starting with 0.", true);
    if (!network) return toast("Please select your MoMo network.", true);
    if (isMerchant && !REGEX.gps.test(gps)) return toast("GPS code must be AA-NNN-NNNN (e.g., GA-183-4290).", true);
    const imgErr = validateImageFile(kycFile);
    if (imgErr) return toast(imgErr, true);

    // 2. Build FormData
    const fd = new FormData();
    fd.append("username", username);
    fd.append("email", email);
    fd.append("password", password);
    fd.append("momo_number", momo);
    fd.append("momo_network", network);
    fd.append("role", role);
    fd.append("subscription_cycle", cycle);
    if (isMerchant) fd.append("ghana_post_gps", gps);
    if (kycFile) fd.append("kyc_file", kycFile);

    // 3. Submit button → loading state
    const btn = document.getElementById("signupSubmit");
    const originalText = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = "Setting up your payment…";
    submitted = true;

    let accessCode = null;
    try {
      const res = await api.post("/api/auth/signup.php", fd, { isForm: true });
      accessCode = res && res.access_code;
    } catch (err) {
      submitted = false;
      btn.disabled = false;
      btn.innerHTML = originalText;
      const msg = (err && err.payload && err.payload.error) || err.message || "Signup failed.";
      return toast(msg, true);
    }

    if (!accessCode) {
      submitted = false;
      btn.disabled = false;
      btn.innerHTML = originalText;
      return toast("Server did not return a payment access code. Please try again.", true);
    }

    // 4. Open Paystack popup — synchronously inside the click chain
    //    (browser user-activation persists for a few seconds after a click).
    btn.innerHTML = "Opening Paystack…";
    openAccessCodePopup({
      accessCode,
      onSuccess: (resp) => {
        // The webhook is the source of truth for activation. We optimistically
        // navigate to the dashboard; if the user isn't activated yet, the dashboard
        // will show a "verification pending" banner.
        toast("Payment received. Verifying your account…");
        setTimeout(() => navigate("#/dashboard"), 600);
      },
      onCancel: () => {
        submitted = false;
        btn.disabled = false;
        btn.innerHTML = originalText;
        toast("Payment cancelled. Your account was created but is not yet active.");
        // FIX: route to #/welcome (was #/signin — would dead-end because the user can
        // sign in but is active=0, so dashboardView rejects them with "Please sign in")
        setTimeout(() => navigate("#/welcome"), 1500);
      },
      onError: (err) => {
        submitted = false;
        btn.disabled = false;
        btn.innerHTML = originalText;
        const kind = err.kind === "load" ? "load" : "popup";
        toast("Paystack " + kind + " failed: " + (err.message || "unknown error"), true);
      },
    });
  }
}

export function unmount() {
  // Clear the in-memory KYC file so it doesn't leak across view changes.
  setKycFile(null);
  submitted = false;
}
