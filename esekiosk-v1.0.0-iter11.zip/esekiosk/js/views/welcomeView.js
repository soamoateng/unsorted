// js/views/welcomeView.js
// Phase 2: full pricing-card selection for Merchant (Monthly/Quarterly/Yearly)
// and Reseller (Yearly only). On click, navigates to #/signup with the chosen
// role + cycle as URL params (e.g., #/signup?role=merchant&cycle=yearly).
//
// SRP: owns the welcome page's mount/unmount + role-selection interaction.
// KISS: a flat data table; no PricingPlan class.

import { escapeHTML, escapeAttr } from "../utils/escape.js";

const PLANS = [
  {
    role: "merchant",
    cycle: "monthly",
    title: "Merchant · Monthly",
    price: "₵50",
    period: "/ month",
    blurb: "List wholesale inventory and let resellers move it for you.",
    features: ["Unlimited products", "Live stock sync", "Paystack split payouts", "Ghana Card KYC", "Intra-city courier network"],
    cta: "Sign up monthly",
    featured: false,
  },
  {
    role: "merchant",
    cycle: "quarterly",
    title: "Merchant · Quarterly",
    price: "₵135",
    period: "/ quarter",
    blurb: "Save 10% vs monthly. Best for shops with steady inventory.",
    features: ["Everything in Monthly", "Quarterly billing", "Priority courier routing", "Debt-ledger auto-recovery"],
    cta: "Sign up quarterly",
    featured: true,
  },
  {
    role: "merchant",
    cycle: "yearly",
    title: "Merchant · Yearly",
    price: "₵500",
    period: "/ year",
    blurb: "Save 17% vs monthly. Lock in the rate for a full year.",
    features: ["Everything in Quarterly", "Yearly billing", "Early access to features", "Dedicated support"],
    cta: "Sign up yearly",
    featured: false,
  },
  {
    role: "reseller",
    cycle: "yearly",
    title: "Reseller · Yearly",
    price: "₵300",
    period: "/ year",
    blurb: "Clone merchant inventory at a markup — no stock, no warehouse.",
    features: ["Clone any product", "Set your retail price", "Paystack split payouts (markup → you)", "Ghana Card KYC", "Yearly billing only"],
    cta: "Sign up as reseller",
    featured: false,
  },
];

export function mount(container) {
  container.innerHTML = `
    <section class="section container" id="welcome">
      <header class="section__head section__head--center reveal">
        <p class="section__kicker">Welcome to Esekiosk</p>
        <h2 class="section__title">Sell across the city, the smart way</h2>
        <p style="max-width: 640px; margin: 16px auto 0; color: var(--muted);">
          Esekiosk is Ghana's intra-city dropshipping platform.
          Merchants list wholesale inventory; Resellers clone at a markup;
          Paystack split-checkout pays everyone instantly.
        </p>
      </header>

      <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(260px, 1fr)); gap: 20px; margin-top: 40px;">
        ${PLANS.map(
          (p, i) => `
          <article class="card reveal" data-delay="${i}" style="padding: 28px 24px; display: flex; flex-direction: column;">
            <div class="card__body" style="flex: 1; display: flex; flex-direction: column;">
              ${p.featured ? '<span class="flag flag--top" style="margin-bottom: 12px;">Most popular</span>' : ""}
              <h3 style="font-size: 18px; font-weight: 700; margin-bottom: 6px;">${escapeHTML(p.title)}</h3>
              <p style="color: var(--muted); font-size: 13px; margin-bottom: 18px;">${escapeHTML(p.blurb)}</p>
              <div style="margin-bottom: 20px;">
                <span style="font-size: 36px; font-weight: 800; color: var(--g700);">${escapeHTML(p.price)}</span>
                <span style="color: var(--muted); font-size: 14px;">${escapeHTML(p.period)}</span>
              </div>
              <ul style="list-style: none; padding: 0; margin: 0 0 24px; flex: 1;">
                ${p.features
                  .map(
                    (f) =>
                      `<li style="font-size: 14px; padding: 6px 0; color: var(--ink); display: flex; align-items: center; gap: 8px;">
                        <span style="color: var(--g700); font-weight: 700;">✓</span>
                        ${escapeHTML(f)}
                      </li>`
                  )
                  .join("")}
              </ul>
              <a href="#/signup?role=${escapeAttr(p.role)}&cycle=${escapeAttr(p.cycle)}"
                 class="btn ${p.featured ? "btn--primary" : "btn--light"} btn--block"
                 style="color: ${p.featured ? "#fff" : "var(--g700)"};">
                ${escapeHTML(p.cta)}
              </a>
            </div>
          </article>`
        ).join("")}
      </div>

      <p style="margin-top: 40px; text-align: center; color: var(--muted); font-size: 13px;">
        Already have an account?
        <a href="#/signin" style="color: var(--g700); text-decoration: underline;">Sign in</a>
        &nbsp;·&nbsp;
        <a href="#/store/kwame-shop-88" style="color: var(--g700); text-decoration: underline;">Browse the demo storefront</a>
      </p>

      <p style="margin-top: 16px; text-align: center; color: var(--muted); font-size: 12px;">
        All payments processed by Paystack. Ghana Card verification required for AML compliance.
      </p>
    </section>
  `;
}

export function unmount() {
  /* nothing to clean up */
}
