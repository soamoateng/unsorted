// js/views/productView.js
// Single-product detail page. Per PRD: no FLIP / Hero animations; padding respects
// env(safe-area-inset-*) for notched devices.
//
// Phase 3 stub: the storefront currently doesn't expose a per-product route, but the
// PRD lists productView.js as a future addition for direct product links. This view
// will be wired when Phase 4 introduces order_item-level detail.
//
// SRP: owns the single-product view. Renders from a product object passed in or
//      fetched by id via /api/products/get_products.php?store=<slug>.

import { escapeHTML, escapeAttr } from "../utils/escape.js";
import { formatPesewas, starsSVG } from "../utils/format.js";
import { toast } from "../components/toast.js";
import * as cartStore from "../state/cartStore.js";
import { getBasePath } from "../services/api.js";

export function mount(container, params = {}) {
  const p = params.product || null;
  if (!p) {
    container.innerHTML = `
      <section class="section container">
        <p style="color: var(--muted);">Product not specified.</p>
      </section>`;
    return;
  }
  container.innerHTML = `
    <section class="section container" id="product" style="padding-top: calc(72px + env(safe-area-inset-top));">
      <a href="#/store/${escapeAttr(params.storeSlug || "")}" style="display: inline-flex; align-items: center; gap: 6px; color: var(--muted); margin-bottom: 16px;">
        &larr; Back to store
      </a>
      <div style="display: grid; grid-template-columns: minmax(0, 1fr) minmax(0, 1fr); gap: 32px;">
        <div>
          <img src="${getBasePath()}/api/${escapeAttr(p.image_path || "")}" alt="${escapeAttr(p.name || "")}"
               style="width: 100%; max-height: 480px; object-fit: cover; border-radius: 12px;">
        </div>
        <div>
          <h1 class="section__title" style="margin-bottom: 12px;">${escapeHTML(p.name || "")}</h1>
          <div style="margin-bottom: 12px;">${starsSVG(4.8)}</div>
          <p style="font-size: 28px; font-weight: 700; color: var(--g700); margin-bottom: 16px;">
            ${formatPesewas(p.retail_price_pesewas || 0)}
          </p>
          <p style="color: var(--muted); margin-bottom: 24px;">${escapeHTML(p.description || "")}</p>
          <p style="font-size: 14px; margin-bottom: 24px;">
            <strong>Stock:</strong> ${escapeHTML(String(p.stock ?? 0))} available
          </p>
          <button class="btn btn--primary btn--lg" data-add-to-cart="${escapeAttr(p.id || "")}">
            Add to cart
          </button>
        </div>
      </div>
    </section>
    <style>
      @media (max-width: 768px) {
        #product > div[style*="grid-template-columns"] { grid-template-columns: 1fr !important; }
      }
    </style>
  `;
  const addBtn = container.querySelector('[data-add-to-cart]');
  if (addBtn) {
    addBtn.addEventListener("click", () => {
      cartStore.add(p.id, 1);
      toast(p.name + " added to cart");
    });
  }
}

export function unmount() {
  /* nothing to clean up */
}
