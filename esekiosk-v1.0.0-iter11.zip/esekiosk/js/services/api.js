// js/services/api.js
// Single fetch wrapper. All views and stores import from here — they never
// call fetch() directly.
//
// SRP: owns HTTP, credentials, CSRF, 401/403 redirects, JSON parsing.
// DIP: depends on authStore + router via injected dependencies (init(api)),
// so tests can substitute stubs.
//
// SUBDIRECTORY SUPPORT: BASE_PATH is auto-detected from this module's URL
// so the app works whether it's hosted at /, /esekiosk/, or any other subdirectory.
//   - api.js is at <base>/js/services/api.js
//   - <base> = new URL("../../", import.meta.url).pathname (up 2 levels)
//   - e.g. http://localhost:8000/esekiosk/js/services/api.js → BASE_PATH = "/esekiosk"
// Callers pass paths like "/api/auth/get_session.php" and we prepend BASE_PATH.

// Auto-detect the app's base path from this module's URL.
// Works for: root deployment (BASE_PATH = ""), subdirectory (BASE_PATH = "/esekiosk"), etc.
const BASE_PATH = (() => {
  try {
    // new URL("../../", import.meta.url) resolves relative to api.js's location.
    // api.js is at <base>/js/services/api.js → "../../" → <base>/
    return new URL("../../", import.meta.url).pathname.replace(/\/$/, "");
  } catch (_) {
    return "";
  }
})();

/** Resolve a path (e.g., "/api/auth/get_session.php") against the app base. */
function resolveUrl(path) {
  if (!path) return path;
  if (/^https?:\/\//.test(path)) return path; // absolute URL — leave as-is
  if (!path.startsWith("/")) path = "/" + path;
  return BASE_PATH + path;
}

let csrfToken = null;
let onUnauthorized = null;       // injected by app.js boot: () => router.navigate("#/signin")
let onSubscriptionExpired = null; // injected: () => router.navigate("#/renew")

// FIX: destructure with a default to prevent throw on `api.configure()` with no arg.
export function configure({ csrf, on401, on403Expired } = {}) {
  if (csrf !== undefined) csrfToken = csrf;
  if (typeof on401 === "function") onUnauthorized = on401;
  if (typeof on403Expired === "function") onSubscriptionExpired = on403Expired;
}

/** Expose BASE_PATH so other modules (e.g., router, paystack) can build URLs consistently. */
export function getBasePath() {
  return BASE_PATH;
}

async function request(method, url, { body, isForm } = {}) {
  const headers = {};
  if (csrfToken) headers["X-CSRF-Token"] = csrfToken;
  if (body && !isForm) headers["Content-Type"] = "application/json";

  const init = {
    method,
    credentials: "include",
    headers,
  };
  if (body !== undefined) {
    init.body = isForm ? body : JSON.stringify(body);
  }

  let res;
  try {
    res = await fetch(resolveUrl(url), init);
  } catch (err) {
    // Network failure / CORS block / DNS — wrap as a structured error.
    // FIX: preserve the original error via `cause` for debugging.
    const e = new Error("Network request failed");
    e.kind = "network";
    e.cause = err;
    throw e;
  }

  if (res.status === 401) {
    if (onUnauthorized) onUnauthorized();
    const e = new Error("Unauthorized");
    e.status = 401;
    throw e;
  }
  if (res.status === 403) {
    // Distinguish "subscription expired" 403 from a generic forbidden.
    let payload = null;
    try {
      // FIX: read the body directly (was using res.clone().json() — clone was wasted work).
      payload = await res.json();
    } catch (_) {}
    if (payload && payload.error === "subscription_expired" && onSubscriptionExpired) {
      onSubscriptionExpired();
    }
    const e = new Error("Forbidden");
    e.status = 403;
    e.payload = payload;
    throw e;
  }

  let data = null;
  const ct = res.headers.get("content-type") || "";
  if (ct.includes("application/json")) {
    // FIX: log JSON parse errors instead of silently returning null (was .catch(() => null))
    try {
      data = await res.json();
    } catch (err) {
      console.warn("[api] JSON parse failed:", err);
      data = null;
    }
  } else if (res.status !== 204) {
    data = await res.text().catch(() => "");
  }
  if (!res.ok) {
    const e = new Error((data && data.error) || `HTTP ${res.status}`);
    e.status = res.status;
    e.payload = data;
    throw e;
  }
  return data;
}

export function get(url) {
  return request("GET", url);
}
export function post(url, body, opts) {
  return request("POST", url, { body, ...opts });
}
export function patch(url, body, opts) {
  return request("PATCH", url, { body, ...opts });
}
export function del(url, opts) {
  // FIX: align signature with post/patch (was passing opts directly as the 3rd arg)
  return request("DELETE", url, opts || {});
}

export function setCsrfToken(token) {
  csrfToken = token || null;
}
