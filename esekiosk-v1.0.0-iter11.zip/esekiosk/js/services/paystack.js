// js/services/paystack.js
// Paystack InlineJS V2 wrapper.
//
// FIXES:
//   - Pre-warm the script load at app boot so the first signup click doesn't
//     break the user-gesture activation window (was: `async openAccessCodePopup`
//     awaited `loadScript()` on first call, potentially losing user activation).
//   - Remove orphan <script> tags on load failure (was leaking DOM nodes).
//   - Distinguish script-load failure from popup-runtime failure via err.kind.
//   - Dedup concurrent script loads with a cached promise.
//
// Critical patterns (verified August 2026):
//   1. Lazy-load the script tag from https://js.paystack.co/v2/inline.js.
//   2. Use the V2 API: `new PaystackPop()` + `.resumeTransaction(access_code)`.
//   3. The popup MUST be opened inside a user-gesture chain. Browsers maintain "user activation"
//      for a few seconds after a click, so an async fetch in between is fine — but do not
//      await anything between the fetch returning and the .resumeTransaction() call.
//
// SRP: owns the Paystack script load + popup lifecycle. Nothing else.
// KISS: one exported function for now (openAccessCodePopup); Phase 4 adds openSplitPopup.

const PAYSTACK_INLINE_URL = "https://js.paystack.co/v2/inline.js";

let scriptPromise = null;

/** Pre-warm the script load. Call from app.js init() so the first signup click is fast. */
export function prewarm() {
  return loadScript();
}

/** Loads the InlineJS V2 script tag once. Subsequent calls return the cached promise. */
function loadScript() {
  if (scriptPromise) return scriptPromise;
  scriptPromise = new Promise((resolve, reject) => {
    // If already present (e.g., the page hot-reloaded), reuse it.
    const existing = document.querySelector(`script[src="${PAYSTACK_INLINE_URL}"]`);
    if (existing) {
      if (typeof window.PaystackPop !== "undefined") {
        resolve();
        return;
      }
      // FIX: script tag exists but still loading — attach our handlers to it,
      // don't create a duplicate tag (was creating a second tag → race)
      existing.addEventListener("load", () => {
        if (typeof window.PaystackPop !== "undefined") resolve();
        else reject(new Error("Paystack InlineJS loaded but window.PaystackPop is undefined"));
      }, { once: true });
      existing.addEventListener("error", () => {
        scriptPromise = null; // allow retry
        reject(new Error("Failed to load Paystack InlineJS"));
      }, { once: true });
      return;
    }
    const s = document.createElement("script");
    s.src = PAYSTACK_INLINE_URL;
    s.async = true;
    s.onload = () => {
      if (typeof window.PaystackPop === "undefined") {
        scriptPromise = null; // allow retry
        reject(new Error("Paystack InlineJS loaded but window.PaystackPop is undefined"));
        return;
      }
      resolve();
    };
    s.onerror = () => {
      scriptPromise = null; // allow retry
      // FIX: remove the orphan script tag (was leaking DOM nodes on retry)
      if (s.parentNode) s.parentNode.removeChild(s);
      reject(new Error("Failed to load Paystack InlineJS"));
    };
    document.head.appendChild(s);
  });
  return scriptPromise;
}

/**
 * Open the Paystack popup using an access_code returned by the backend's
 * transaction/initialize call. MUST be called synchronously inside a click handler's
 * user-gesture chain (an awaited fetch in between is OK; a setTimeout is not).
 *
 * @param {Object} opts
 * @param {string} opts.accessCode  access_code from POST /api/auth/signup.php
 * @param {(resp: Object) => void} opts.onSuccess  Paystack returns the transaction payload
 * @param {() => void} opts.onCancel  user closed the popup without paying
 * @param {(err: Error) => void} [opts.onError]  script load or popup error (err.kind = 'load' | 'popup')
 */
export async function openAccessCodePopup({ accessCode, onSuccess, onCancel, onError }) {
  if (!accessCode) {
    if (onError) {
      const e = new Error("Missing access_code");
      e.kind = "load";
      onError(e);
    }
    return;
  }
  try {
    await loadScript();
  } catch (err) {
    if (onError) {
      err.kind = "load";
      onError(err);
    }
    return;
  }
  try {
    const popup = new window.PaystackPop();
    popup.resumeTransaction(accessCode, {
      onSuccess: (response) => {
        if (typeof onSuccess === "function") onSuccess(response);
      },
      onDismissed: () => {
        // V2 uses onDismissed for user-cancelled (V1 used onClose)
        if (typeof onCancel === "function") onCancel();
      },
      onError: (err) => {
        if (typeof onError === "function") {
          if (err instanceof Error) err.kind = "popup";
          else err = Object.assign(new Error(String(err)), { kind: "popup" });
          onError(err);
        }
      },
    });
  } catch (err) {
    if (onError) {
      err.kind = "popup";
      onError(err);
    }
  }
}
