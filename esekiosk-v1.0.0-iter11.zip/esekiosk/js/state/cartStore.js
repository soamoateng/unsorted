// js/state/cartStore.js
// Cart state with localStorage persistence + in-memory fallback.
//
// On mutation, serialises to localStorage.setItem. If localStorage throws
// (Incognito, blocked, quota exceeded), silently falls back to a module-scoped
// in-memory object AND emits a 'cart:fallback' event so a root view can toast.
//
// FIX: the fallback event was emitted at module-import time (inside loadInitial),
// before subscribers in app.js/storefrontView.js were registered — so the toast
// was never shown. Now we defer the emit to the first mutation (add/setQty) and
// also expose hasFallback() so app.js can check on boot.
//
// SRP: owns the cart dictionary { productId: qty }.
// KISS: plain object, no Cart class.

import { emit } from "./pubsub.js";

const STORAGE_KEY = "esekiosk_cart";
const MAX_QTY_PER_LINE = 99;
let memoryFallback = null;   // null = localStorage is fine; object = fallback
let fallbackNotified = false; // FIX: track whether the fallback toast has been shown
let cart = loadInitial();

function loadInitial() {
  try {
    const v = localStorage.getItem(STORAGE_KEY);
    if (!v) return {};
    const parsed = JSON.parse(v);
    return sanitize(parsed);
  } catch (e) {
    // First localStorage access failed — switch to in-memory mode for this session.
    // FIX: do NOT emit here (subscribers not yet registered). Just set the flag;
    // the first mutation OR app.js boot will emit.
    memoryFallback = {};
    return memoryFallback;
  }
}

/**
 * FIX: public getter so app.js can check on boot and toast if the cart is in
 * fallback mode. Returns true if localStorage is unavailable.
 */
export function hasFallback() {
  return memoryFallback !== null;
}

/**
 * FIX: emit the fallback event if not yet emitted. Called from app.js boot
 * AND from the first mutation. Idempotent.
 */
export function notifyFallbackIfPending() {
  if (memoryFallback !== null && !fallbackNotified) {
    fallbackNotified = true;
    emit("cart:fallback", { reason: "localStorage unavailable" });
  }
}

function sanitize(obj) {
  // Drop phantom ids, clamp qty 1..99, drop NaN.
  const out = {};
  if (!obj || typeof obj !== "object" || Array.isArray(obj)) return out;
  for (const [id, qty] of Object.entries(obj)) {
    if (!id) continue; // keys are always strings from Object.entries; just check truthy
    const q = parseInt(qty, 10);
    if (!Number.isFinite(q) || q < 1) continue;
    out[id] = Math.min(q, MAX_QTY_PER_LINE);
  }
  return out;
}

function persist() {
  if (memoryFallback !== null) return; // already in fallback mode
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(cart));
  } catch (e) {
    // Quota exceeded or storage blocked mid-session — switch to fallback now.
    memoryFallback = cart;
    notifyFallbackIfPending();
  }
}

export function getCart() {
  return { ...cart };
}

export function getQty(productId) {
  if (!productId) return 0;
  return cart[productId] || 0;
}

export function getTotalItems() {
  return Object.values(cart).reduce((a, b) => a + (parseInt(b, 10) || 0), 0);
}

export function add(productId, qty = 1) {
  if (!productId) return;
  // FIX: handle qty=0 explicitly (was coerced to 1 because 0 is falsy)
  const parsed = parseInt(qty, 10);
  const q = Number.isFinite(parsed) && parsed > 0
    ? Math.min(MAX_QTY_PER_LINE, parsed)
    : 1;
  cart[productId] = Math.min(MAX_QTY_PER_LINE, (cart[productId] || 0) + q);
  persist();
  notifyFallbackIfPending();
  emit("cart:change", getCart());
}

export function setQty(productId, qty) {
  if (!productId) return;
  // FIX: reject fractional qty (was parseInt → "0.5" became 0 → deleted the line)
  const parsed = parseInt(qty, 10);
  if (!Number.isFinite(parsed) || parsed <= 0) {
    delete cart[productId];
  } else {
    cart[productId] = Math.min(parsed, MAX_QTY_PER_LINE);
  }
  persist();
  notifyFallbackIfPending();
  emit("cart:change", getCart());
}

export function remove(productId) {
  if (!productId) return;
  delete cart[productId];
  persist();
  emit("cart:change", getCart());
}

export function clear() {
  // FIX: in fallback mode, simply empty the existing object (was re-aliasing)
  for (const k of Object.keys(cart)) delete cart[k];
  persist();
  emit("cart:change", getCart());
}
