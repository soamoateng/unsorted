// js/state/searchStore.js
// Single source of truth for storefront search query + category.
// Replaces the boilerplate's scattered `let searchQuery` / `let searchCategory`
// mutations across 5 places in app.js.
//
// SRP: owns search state, nothing else. Views subscribe via pubsub.

import { emit } from "./pubsub.js";

let query = "";
let category = "all";

export function getQuery() {
  return query;
}

export function getCategory() {
  return category;
}

export function setQuery(q) {
  query = String(q || "").toLowerCase();
  emit("search:change", { query, category });
}

export function setCategory(cat) {
  category = cat || "all";
  emit("search:change", { query, category });
}

export function reset() {
  query = "";
  category = "all";
  emit("search:change", { query, category });
}
