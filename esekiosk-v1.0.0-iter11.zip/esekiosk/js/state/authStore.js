// js/state/authStore.js
// Single source of truth for the authenticated session.
// Hydrated from GET /api/auth/get_session.php on boot; cleared on logout / 401.
//
// SRP: owns session, role, billing cycle, KYC file object (held in-memory only,
// never serialized to localStorage). Notifies views via pubsub.

import { emit } from "./pubsub.js";
import { setCsrfToken as apiSetCsrfToken } from "../services/api.js";

const state = {
  user: null,             // { id, username, email, role, momo_number, momo_network,
                          //   ghana_post_gps, store_slug, subaccount_pending,
                          //   kyc_status, subscription_cycle, subscription_expiry, active,
                          //   payouts_paused_at, subscription_expired }
  csrfToken: null,        // raw CSRF token (also pushed into api.js)
  kycFile: null,          // raw File object held during signup (never serialized)
};

/**
 * Return a deep-enough snapshot of the state so callers can't mutate internal state.
 * FIX: previously Object.freeze was shallow — callers could mutate state.user.role.
 * Now we shallow-clone the user object too.
 */
export function getState() {
  return Object.freeze({
    ...state,
    user: state.user ? { ...state.user } : null,
    kycFile: state.kycFile,  // File is immutable; safe to share by reference
  });
}

export function setUser(user) {
  state.user = user ? { ...user } : null;
  emit("auth:change", state.user);
}

export function setCsrfToken(token) {
  state.csrfToken = token || null;
  // FIX: also push into api.js so all future mutations carry the new token.
  // Previously this was only done once at boot, so post-login CSRF tokens
  // were never sent on mutations → 403 storms.
  apiSetCsrfToken(token);
}

export function setKycFile(file) {
  state.kycFile = file || null;
}

/**
 * FIX: explicit boolean coercion for `active`. The backend may return
 * `active` as 0, 1, "0", "1", true, false. Treat 1 / "1" / true as authenticated.
 */
export function isAuthenticated() {
  const u = state.user;
  if (!u) return false;
  const a = u.active;
  return a === true || a === 1 || a === "1" || a === "true";
}

export function isAdmin() {
  return Boolean(state.user && state.user.role === "admin");
}

export function isMerchant() {
  return Boolean(state.user && state.user.role === "merchant");
}

export function isReseller() {
  return Boolean(state.user && state.user.role === "reseller");
}

export function isSubscriptionExpired() {
  return Boolean(state.user && state.user.subscription_expired);
}

let hydratePromise = null;

/** Hydrate from the backend on boot. Returns the user or null. */
export function hydrate(apiGet) {
  // FIX: dedupe concurrent hydrate calls (idempotent guard).
  if (hydratePromise) return hydratePromise;
  hydratePromise = (async () => {
    try {
      const res = await apiGet("/api/auth/get_session.php");
      if (res && res.user) {
        // FIX: pass subscription_expired flag into the user object so views can check it
        setUser({ ...res.user, subscription_expired: res.subscription_expired });
        // FIX: only set the CSRF token if the backend issued a new one (null = keep existing)
        if (res.csrf_token) {
          setCsrfToken(res.csrf_token);
        }
      }
      return state.user;
    } catch (err) {
      // 401 is the normal case (not signed in); any other error is logged but not fatal.
      if (err && err.status !== 401) console.warn("[authStore] hydrate failed:", err);
      return null;
    } finally {
      hydratePromise = null;  // allow re-hydration later (e.g., after login)
    }
  })();
  return hydratePromise;
}
