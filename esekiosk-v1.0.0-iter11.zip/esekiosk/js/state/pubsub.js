// js/state/pubsub.js
// Minimal event emitter (on/emit/off). Used by stores to notify views.
//
// SRP: this module owns the publish/subscribe primitive, nothing else.
// KISS: 3 methods, no wildcards, no namespacing. ~20 lines.

const listeners = new Map(); // event -> Set<fn>

export function on(event, fn) {
  if (!listeners.has(event)) listeners.set(event, new Set());
  listeners.get(event).add(fn);
  return () => off(event, fn); // unsubscribe handle
}

export function off(event, fn) {
  const set = listeners.get(event);
  if (set) set.delete(fn);
}

export function emit(event, payload) {
  const set = listeners.get(event);
  if (!set) return;
  // Clone to safely support unsubscribe-during-emit
  [...set].forEach((fn) => {
    try {
      fn(payload);
    } catch (err) {
      // Never let one listener throw break the rest
      console.error(`[pubsub] listener for "${event}" threw:`, err);
    }
  });
}
