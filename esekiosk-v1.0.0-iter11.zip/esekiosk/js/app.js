// js/app.js
// Boot module — the single <script type="module"> entry in index.html.
//
// Responsibility: hydrate stores, configure services, init shared components,
// start the router, and coordinate the storefront ↔ routed-view coexistence.
//
// FIX (Task 10 C1+C2+M4): previously the storefront was mounted once into <body>
// and stayed visible under every routed view (#/dashboard, #/admin, #/signin, etc.)
// because nothing hid <main id="top">. Now app.js owns the storefront lifecycle:
// it mounts the storefront for /, /welcome, and /store/:slug; for any other route,
// it unmounts the storefront and hides <main id="top"> so the routed view in #app
// is the only visible content.

import { initKeyboard } from "./utils/keyboard.js";
import { initToast, toast } from "./components/toast.js";
import { initLayerManager } from "./components/layerManager.js";
import * as api from "./services/api.js";
import * as authStore from "./state/authStore.js";
import { on as pubsubOn } from "./state/pubsub.js";
import { notifyFallbackIfPending as cartNotifyFallback } from "./state/cartStore.js";
import { prewarm as prewarmPaystack } from "./services/paystack.js";
import { startRouter, navigate } from "./router.js";
import { mount as storefrontMount, unmount as storefrontUnmount } from "./views/storefrontView.js";

let storefrontMounted = false;

function configureApi() {
  api.configure({
    on401: () => navigate("#/signin"),
    on403Expired: () => navigate("#/renew"),
  });
}

async function hydrateSession() {
  try {
    await authStore.hydrate(api.get);
  } catch (err) {
    if (err && err.status !== 401) {
      console.warn("[app] session hydrate failed:", err.message);
    }
  }
}

/**
 * Determine whether the current URL should show the storefront (vs a routed view).
 * Storefront routes: root `/`, `#/welcome`, `#/store/:slug`, path-routed `/store/:slug`.
 */
function isStorefrontRoute() {
  const hash = window.location.hash.replace(/^#/, "");
  const hashNoQuery = hash.split("?")[0];
  const basePath = api.getBasePath();
  let path = window.location.pathname;
  if (basePath && path.startsWith(basePath)) {
    path = path.slice(basePath.length) || "/";
  }
  // No hash + root path → storefront
  if (!hash && (path === "/" || path === "/index.html")) return true;
  // #/store/<slug> → storefront (with API fetch)
  if (hashNoQuery.startsWith("/store/")) return true;
  // path-routed /store/<slug> (without hash)
  if (!hash && path.startsWith("/store/")) return true;
  // FIX: #/welcome is NOT a storefront route — it's the pricing-cards page (rendered
  // by the router into #app). Was previously included, which stacked the storefront
  // hero under the pricing cards.
  return false;
}

/**
 * Extract the store slug from the current URL, or null if not a store route.
 */
function extractStoreSlug() {
  const hash = window.location.hash.replace(/^#/, "");
  const hashNoQuery = hash.split("?")[0];
  const basePath = api.getBasePath();
  let path = window.location.pathname;
  if (basePath && path.startsWith(basePath)) {
    path = path.slice(basePath.length) || "/";
  }
  if (hashNoQuery.startsWith("/store/")) {
    return decodeURIComponent(hashNoQuery.slice("/store/".length));
  }
  if (!hash && path.startsWith("/store/")) {
    return decodeURIComponent(path.slice("/store/".length));
  }
  return null;
}

/**
 * Show the storefront: mount it (if not already), ensure <main id="top"> is visible,
 * and clear the #app container so no routed view is stacked underneath.
 */
function showStorefront() {
  const mainEl = document.getElementById("top");
  if (mainEl) mainEl.hidden = false;
  const appEl = document.getElementById("app");
  if (appEl) appEl.innerHTML = "";
  if (!storefrontMounted) {
    const slug = extractStoreSlug();
    storefrontMount(document.body, slug ? { slug } : {});
    storefrontMounted = true;
  } else {
    // Already mounted — re-trigger slug-based fetch if the slug changed
    const slug = extractStoreSlug();
    // storefrontView's onHashChange listener handles re-fetch; but if we just
    // re-showed the storefront after a routed view, we may need to refresh.
    // The onHashChange listener fires on navigation, so this is usually a no-op.
  }
}

/**
 * Hide the storefront: unmount it (cleans listeners/timers) and hide <main id="top">.
 */
function hideStorefront() {
  if (storefrontMounted) {
    storefrontUnmount(document.body);
    storefrontMounted = false;
  }
  const mainEl = document.getElementById("top");
  if (mainEl) mainEl.hidden = true;
}

/**
 * Coordinate storefront ↔ routed-view visibility based on the current URL.
 * Called on boot and on every navigation (popstate + custom app-level nav event).
 */
function syncStorefrontVisibility() {
  if (isStorefrontRoute()) {
    showStorefront();
  } else {
    hideStorefront();
  }
}

function init() {
  initToast(document.getElementById("toasts"));
  initLayerManager(document.getElementById("scrim"));
  initKeyboard();
  configureApi();
  pubsubOn("cart:fallback", () => toast("Incognito mode: cart will not persist after refresh", true));
  cartNotifyFallback();
  prewarmPaystack();

  hydrateSession().finally(() => {
    // Initial visibility sync based on the boot URL
    syncStorefrontVisibility();
    // Start the router against the #app container
    const appEl = document.getElementById("app");
    if (appEl) startRouter(appEl);
    // Listen for navigations (popstate + custom 'app:navigate' event from router.navigate)
    window.addEventListener("popstate", syncStorefrontVisibility);
    window.addEventListener("app:navigate", syncStorefrontVisibility);
  });
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", init);
} else {
  init();
}
