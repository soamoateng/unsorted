// js/router.js
// Hash + path SPA router. Resolves a URL to a view loader and mounts it into #app.
//
// FIX (Task 10 C2+M4): removed `/store/:slug` from ROUTES — the storefront is owned
// by app.js (mountStorefront/showStorefront), not the router. Previously the router
// would call storefrontMount(appEl, {slug}) which silently no-op'd because the
// storefront's DOM lives in <main id="top"> (body), not #app.
//
// FIX: navigate() now emits a custom 'app:navigate' event so app.js can sync
// storefront visibility (show/hide <main id="top">) — previously pushState didn't
// fire hashchange/popstate, so app.js never learned about in-app navigation.
//
// FIX: notFoundMount now escapes the URL via escapeHTML (was using a weaker
// local escapeHTMLSafe that missed quotes — XSS risk if a future href lands
// a malicious value into the hash).
//
// SRP: owns URL → view resolution + History API coordination. Does NOT own auth
//      checks — views are responsible for redirecting to #/signin if they need
//      auth and the authStore says none.
// KISS: route table is a plain object. No regex router, no middleware chain.

import { mount as welcomeMount, unmount as welcomeUnmount } from "./views/welcomeView.js";
import { mount as dashboardMount, unmount as dashboardUnmount } from "./views/dashboardView.js";
import { mount as adminMount, unmount as adminUnmount } from "./views/adminDashboardView.js";
import { mount as signupMount, unmount as signupUnmount } from "./views/signupView.js";
import { mount as signinMount, unmount as signinUnmount } from "./views/signinView.js";
import { mount as renewMount, unmount as renewUnmount } from "./views/renewView.js";
import { mount as resellerInventoryMount, unmount as resellerInventoryUnmount } from "./views/resellerInventoryView.js";
import { getBasePath } from "./services/api.js";
import { escapeHTML } from "./utils/escape.js";

// FIX: /welcome is a router-owned route (pricing cards render in #app).
// /store/:slug is owned by app.js (storefront in body).
const ROUTES = {
  "/welcome": welcomeMount,
  "/signup": signupMount,
  "/signin": signinMount,
  "/renew": renewMount,
  "/inventory": resellerInventoryMount,
  "/dashboard": dashboardMount,
  "/admin": adminMount,
};

const UNMOUNTS = {
  "/welcome": welcomeUnmount,
  "/signup": signupUnmount,
  "/signin": signinUnmount,
  "/renew": renewUnmount,
  "/inventory": resellerInventoryUnmount,
  "/dashboard": dashboardUnmount,
  "/admin": adminUnmount,
};

let currentUnmount = null;
let appEl = null;

export function startRouter(appElement) {
  appEl = appElement;
  window.addEventListener("popstate", () => resolveAndRender());
  document.addEventListener("click", onAnchorClick);
  resolveAndRender();
}

export function navigate(url) {
  if (url.startsWith("#")) {
    const path = url.slice(1) || "/";
    history.pushState({ path }, "", "#" + path);
  } else {
    const base = getBasePath();
    const pushUrl = (url.startsWith("/") && base && url !== base && !url.startsWith(base + "/"))
      ? base + url
      : url;
    history.pushState({ path: url }, "", pushUrl);
  }
  resolveAndRender();
  // FIX: emit a custom event so app.js can sync storefront visibility.
  // pushState does NOT fire hashchange or popstate, so without this event,
  // app.js would never learn about in-app navigation and the storefront would
  // stay visible under routed views (or stay hidden when navigating back).
  window.dispatchEvent(new CustomEvent("app:navigate"));
}

function onAnchorClick(e) {
  const a = e.target.closest("a");
  if (!a) return;
  const href = a.getAttribute("href") || "";
  if (href.startsWith("#/")) {
    e.preventDefault();
    navigate(href);
  } else if (href.startsWith("/") && !href.startsWith("//")) {
    e.preventDefault();
    navigate(href);
  }
}

function resolveRoute() {
  const hash = window.location.hash.replace(/^#/, "");
  if (hash) {
    const hashNoQuery = stripQuery(hash);
    // FIX: /store/:slug is a storefront route owned by app.js — render nothing
    // into #app (app.js owns the storefront for these).
    if (hashNoQuery === "/" || hashNoQuery.startsWith("/store/")) {
      return { path: hashNoQuery, mount: () => {}, unmount: () => {}, params: {} };
    }
    return matchRoute(hashNoQuery);
  }
  const base = getBasePath();
  let path = window.location.pathname;
  if (base && path.startsWith(base)) {
    path = path.slice(base.length) || "/";
  }
  if (path && path !== "/" && path !== "/index.html") {
    // FIX: path-routed /store/:slug is a storefront route — no-op in #app.
    if (path.startsWith("/store/")) {
      return { path, mount: () => {}, unmount: () => {}, params: {} };
    }
    return matchRoute(stripQuery(path));
  }
  // Root URL — no-op (app.js shows the storefront)
  return { path: "/", mount: () => {}, unmount: () => {}, params: {} };
}

function stripQuery(p) {
  const q = p.indexOf("?");
  return q >= 0 ? p.slice(0, q) : p;
}

function matchRoute(path) {
  if (ROUTES[path]) return { path, mount: ROUTES[path], unmount: UNMOUNTS[path], params: {} };
  return { path, mount: notFoundMount, unmount: null, params: {} };
}

function notFoundMount(container) {
  const url = window.location.hash || window.location.pathname;
  container.innerHTML = `
    <section class="section container">
      <h2 class="section__title">404 — Not Found</h2>
      <p style="color: var(--muted); margin: 16px 0;">
        The route <code>${escapeHTML(url)}</code> does not exist.
      </p>
      <a href="#/" class="btn btn--primary">Back to welcome</a>
    </section>
  `;
}

function resolveAndRender() {
  const route = resolveRoute();
  if (!appEl) return;
  if (currentUnmount) {
    try {
      currentUnmount();
    } catch (err) {
      console.warn("[router] unmount threw:", err);
    }
    currentUnmount = null;
  }
  appEl.innerHTML = "";
  try {
    route.mount(appEl, route.params || {});
    currentUnmount = route.unmount || null;
  } catch (err) {
    console.error("[router] mount threw:", err);
    appEl.innerHTML = `<div class="section container"><h2>View error</h2><p>${escapeHTML(err.message || "")}</p></div>`;
  }
}
