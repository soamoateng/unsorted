-- ============================================================================
-- Esekiosk — Migration script for existing databases (iter8 bugfix → iter9)
-- Run this if you already have an Esekiosk database and need to apply the
-- schema changes from the bug-fix pass WITHOUT dropping your data.
--
-- Usage:
--   mysql -u root -p esekiosk < api/migrations/001_iter8_bugfix.sql
--
-- If you're starting fresh, use `api/schema.sql` instead (it creates all
-- tables from scratch with the fixes already applied).
-- ============================================================================

-- 1. Add the dedicated csrf_token_hash column to auth_sessions.
--    Previously the CSRF token hash was overloaded into the user_agent column
--    (destroying the real UA captured at login). This migration adds a proper
--    column; the old user_agent value is left in place (it now correctly stores
--    the UA, not the CSRF hash).
ALTER TABLE `auth_sessions`
  ADD COLUMN `csrf_token_hash` CHAR(64) NULL AFTER `token_hash`;

-- 2. Add the UNIQUE constraint on products (owner_user_id, parent_product_id)
--    to prevent double-cloning. MySQL NULL semantics: NULL != NULL, so multiple
--    merchant originals (parent_product_id IS NULL) are allowed; reseller clones
--    are constrained to one per (reseller, parent).
--    NOTE: if you already have duplicate clones from the race condition, this
--    ALTER will fail. Run this cleanup query first to keep only the earliest
--    clone per (owner, parent):
--    DELETE p2 FROM products p2 INNER JOIN products p1
--      ON p2.owner_user_id = p1.owner_user_id
--     AND p2.parent_product_id = p1.parent_product_id
--     AND p2.id > p1.id;
ALTER TABLE `products`
  ADD UNIQUE KEY `uq_products_owner_parent` (`owner_user_id`, `parent_product_id`);

-- 3. Add missing indexes for query performance.
ALTER TABLE `orders`        ADD KEY `idx_orders_created_at` (`created_at`);
ALTER TABLE `order_items`  ADD KEY `idx_order_items_reseller_id` (`reseller_id`);
ALTER TABLE `merchant_ledger` ADD KEY `idx_ledger_recovered_at` (`recovered_at`);

-- 4. Update the subaccount_pending column comment to document the 3-state flag.
ALTER TABLE `users`
  MODIFY COLUMN `subaccount_pending` TINYINT(1) NOT NULL DEFAULT 0
  COMMENT '0=done, 1=pending (cron retries), 2=in_progress (cron lock)';

-- 5. Re-arm any stale "in_progress" (subaccount_pending=2) rows from previous
--    cron crashes so the next cron run picks them up.
UPDATE `users` SET `subaccount_pending` = 1 WHERE `subaccount_pending` = 2;
