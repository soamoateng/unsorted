<?php
declare(strict_types=1);

/**
 * api/webhooks/paystack_webhook.php
 * Paystack webhook receiver. Phase 2 full handler.
 *
 * Security:
 *   - HMAC-SHA512 signature verify via hash_equals (timing-safe).
 *   - Always return HTTP 200 (after signature check) so Paystack doesn't re-deliver
 *     on parse failures.
 *   - Idempotency: unique constraint on orders.paystack_reference prevents duplicate
 *     inserts on re-delivery.
 *   - Event-type whitelist: only `charge.success` triggers activation.
 *
 * Flow on `charge.success`:
 *   1. Verify signature.
 *   2. Parse payload, check `data.status === 'success'`.
 *   3. Look up the orders row by `data.reference`. If status is already 'paid', return
 *      (idempotent — duplicate webhook).
 *   4. Inspect `data.metadata.kind`:
 *        - 'subscription': activate user, compute subscription_expiry, create subaccount.
 *        - 'checkout':     Phase 4 — insert order_items + start subaccount reconciliation.
 *   5. Return 200.
 */

require_once __DIR__ . '/../config/cors.php';
require_once __DIR__ . '/../config/env.php';
require_once __DIR__ . '/../config/paystack.php';
require_once __DIR__ . '/../config/momo_helper.php';
require_once __DIR__ . '/../config/database.php';

// Always read the raw body — never use $_POST (it's empty for JSON payloads)
$rawBody = file_get_contents('php://input');
$sig = $_SERVER['HTTP_X_PAYSTACK_SIGNATURE'] ?? '';

if (!verify_paystack_signature($rawBody, $sig)) {
    error_log('[paystack_webhook] signature verification failed');
    http_response_code(200);
    header('Content-Type: application/json');
    echo json_encode(['ok' => true, 'processed' => false]);
    exit;
}

$event = json_decode($rawBody, true);
if (!is_array($event) || !isset($event['event'], $event['data'])) {
    error_log('[paystack_webhook] malformed payload');
    http_response_code(200);
    header('Content-Type: application/json');
    echo json_encode(['ok' => true, 'processed' => false]);
    exit;
}

// Only charge.success triggers activation in Phase 2.
if ($event['event'] !== 'charge.success') {
    error_log('[paystack_webhook] unhandled event: ' . $event['event']);
    http_response_code(200);
    header('Content-Type: application/json');
    echo json_encode(['ok' => true, 'processed' => false]);
    exit;
}

try {
    Env::load(__DIR__ . '/../config/.env');
} catch (Throwable $e) {
    error_log('[paystack_webhook] env load failed: ' . $e->getMessage());
    http_response_code(200);
    header('Content-Type: application/json');
    echo json_encode(['ok' => true, 'processed' => false]);
    exit;
}

$data = $event['data'] ?? [];
$reference = $data['reference'] ?? '';
$status = $data['status'] ?? '';
if ($status !== 'success' || $reference === '') {
    http_response_code(200);
    header('Content-Type: application/json');
    echo json_encode(['ok' => true, 'processed' => false]);
    exit;
}

$pdo = db();

try {
    // CRITICAL FIX: move idempotency check INSIDE the transaction with FOR UPDATE.
    // Previously, two concurrent webhook deliveries for the same reference both read
    // status='pending' outside the transaction, both passed the check, both
    // activated the user → double activation + duplicate Paystack subaccounts.
    $pdo->beginTransaction();

    $stmt = $pdo->prepare(
        'SELECT id, store_id, status FROM orders WHERE paystack_reference = ? LIMIT 1 FOR UPDATE'
    );
    $stmt->execute([$reference]);
    $order = $stmt->fetch();

    if (!$order) {
        $pdo->rollBack();
        error_log('[paystack_webhook] reference not found: ' . $reference);
        http_response_code(200);
        header('Content-Type: application/json');
        echo json_encode(['ok' => true, 'processed' => false, 'reason' => 'reference_not_found']);
        exit;
    }

    if ($order['status'] === 'paid') {
        $pdo->rollBack();
        http_response_code(200);
        header('Content-Type: application/json');
        echo json_encode(['ok' => true, 'processed' => false, 'reason' => 'already_paid']);
        exit;
    }

    // FIX: read user_id from metadata (set by signup.php), not store_id — for
    // subscription orders store_id == user_id, but for checkout orders store_id is
    // the merchant/reseller store, not the paying customer.
    $metadata = $data['metadata'] ?? [];
    // FIX (Task 10 C7): reject unknown kind instead of defaulting to 'subscription'.
    // A checkout order with missing metadata would be mis-processed as a subscription
    // (activating the merchant, creating a duplicate subaccount, etc.).
    $kind = $metadata['kind'] ?? '';
    if (!in_array($kind, ['subscription', 'checkout'], true)) {
        $pdo->rollBack();
        error_log('[paystack_webhook] unknown or missing kind: ' . $kind);
        http_response_code(200);
        header('Content-Type: application/json');
        echo json_encode(['ok' => true, 'processed' => false, 'reason' => 'unknown_kind']);
        exit;
    }
    $cycle = $metadata['subscription_cycle'] ?? null;
    $userId = isset($metadata['user_id']) ? (int) $metadata['user_id'] : (int) $order['store_id'];

    // Update the order row to 'paid'
    $upd = $pdo->prepare(
        'UPDATE orders SET status = ?, paid_at = NOW() WHERE id = ?'
    );
    $upd->execute(['paid', $order['id']]);

    if ($kind === 'subscription') {
        // Compute expiry from cycle. FIX: extend from MAX(NOW, current_expiry) so
        // renewals stack instead of overwriting.
        $intervalSpec = match ($cycle) {
            'monthly' => '+1 month',
            'quarterly' => '+3 months',
            'yearly' => '+1 year',
            default => '+1 month',
        };
        // Read current expiry to support renewal stacking
        $currentExpiryStmt = $pdo->prepare('SELECT subscription_expiry FROM users WHERE id = ?');
        $currentExpiryStmt->execute([$userId]);
        $currentExpiry = $currentExpiryStmt->fetchColumn();
        $base = ( $currentExpiry && strtotime($currentExpiry) > time() )
            ? strtotime($currentExpiry)
            : time();
        $expiryDate = date('Y-m-d', strtotime($intervalSpec, $base));

        // Activate user
        $userStmt = $pdo->prepare(
            'UPDATE users
             SET active = 1, subscription_expiry = ?, subaccount_pending = 1
             WHERE id = ?'
        );
        $userStmt->execute([$expiryDate, $userId]);
        // FIX: set subaccount_pending=1 INSIDE the transaction so that if the process
        // dies between commit and the post-commit create_subaccount_for_user() call,
        // the cron will still retry (the user is active=1 + subaccount_pending=1).
        // On success, the post-commit code sets it back to 0. On failure, it stays 1.

        // Create Paystack subaccount — FIX: do this AFTER commit (moved below)
        // to avoid holding DB locks during the slow cURL call.
        $needsSubaccount = true;
    } elseif ($kind === 'checkout') {
        // Stock decrement is done at checkout init (initialize_checkout.php), not here.
        // The webhook only marks the order 'paid' (done above) — merchants then update
        // item statuses via update_order_status.php.
        // NOTE: if Paystack init fails, initialize_checkout marks the order 'cancelled'
        // and a future cleanup cron can restore stock for stale 'cancelled' orders.
        $needsSubaccount = false;
    } else {
        $needsSubaccount = false;
    }

    $pdo->commit();

    // FIX: subaccount creation moved OUTSIDE the transaction to avoid holding
    // locks during the slow cURL call. If it fails, set subaccount_pending=1
    // for the cron to retry.
    if ($needsSubaccount) {
        $subOk = create_subaccount_for_user($userId);
        if (!$subOk) {
            try {
                $pdo->prepare('UPDATE users SET subaccount_pending = 1 WHERE id = ?')
                    ->execute([$userId]);
            } catch (PDOException $e) {
                error_log('[paystack_webhook] failed to set subaccount_pending: ' . $e->getMessage());
            }
        }
    }

    http_response_code(200);
    header('Content-Type: application/json');
    echo json_encode(['ok' => true, 'processed' => true, 'kind' => $kind, 'reference' => $reference]);
    exit;
} catch (PDOException $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    error_log('[paystack_webhook] db error: ' . $e->getMessage());
    http_response_code(200);
    header('Content-Type: application/json');
    echo json_encode(['ok' => true, 'processed' => false, 'reason' => 'db_error']);
    exit;
} catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    error_log('[paystack_webhook] general error: ' . $e->getMessage());
    http_response_code(200);
    header('Content-Type: application/json');
    echo json_encode(['ok' => true, 'processed' => false, 'reason' => 'internal_error']);
    exit;
}

/**
 * Create a Paystack subaccount for the user's MoMo number.
 * On success: store the subaccount_code in the users row.
 * On failure: log; caller sets subaccount_pending=1 for cron retry.
 *
 * @return bool true on success, false on failure
 */
function create_subaccount_for_user(int $userId): bool
{
    $pdo = db();
    $stmt = $pdo->prepare(
        'SELECT momo_number, momo_network, store_slug, username, subaccount_code
         FROM users WHERE id = ?'
    );
    $stmt->execute([$userId]);
    $u = $stmt->fetch();
    if (!$u) return false;

    // FIX (Task 10 C2): if the user already has a subaccount_code, don't create a duplicate.
    // On renewal, the webhook sets subaccount_pending=1 (line 150), which triggers this
    // function post-commit. Without this guard, every renewal creates a second subaccount
    // at Paystack, orphaning the first.
    if (!empty($u['subaccount_code'])) {
        // Already have a subaccount — just clear the pending flag.
        $pdo->prepare('UPDATE users SET subaccount_pending = 0 WHERE id = ?')
            ->execute([$userId]);
        return true;
    }

    try {
        $bankCode = resolve_bank_code($u['momo_network']);
    } catch (Throwable $e) {
        error_log('[paystack_webhook] bad network for user ' . $userId . ': ' . $u['momo_network']);
        return false;
    }

    $businessName = $u['username'] . ' (Esekiosk)';
    $payload = [
        'business_name' => $businessName,
        'settlement_bank' => $bankCode,
        'account_number' => $u['momo_number'],
        'percentage_charge' => 0, // Esekiosk takes 0% commission per PRD
        'primary_contact_email' => null,
        'description' => 'Esekiosk ' . $u['momo_network'] . ' MoMo subaccount',
    ];

    $ch = curl_init('https://api.paystack.co/subaccount');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => json_encode($payload),
        CURLOPT_HTTPHEADER => [
            'Authorization: Bearer ' . paystack_secret_key(),
            'Content-Type: application/json',
        ],
        CURLOPT_TIMEOUT => 15,
    ]);
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlErr = curl_error($ch);
    curl_close($ch);

    if ($response === false || $httpCode < 200 || $httpCode >= 300) {
        error_log('[paystack_webhook] subaccount/create failed for user ' . $userId . ': HTTP ' . $httpCode . ' err=' . $curlErr);
        return false;
    }

    $ps = json_decode($response, true);
    $subCode = $ps['data']['subaccount_code'] ?? null;
    if (!$subCode) {
        error_log('[paystack_webhook] subaccount/create response missing subaccount_code: ' . $response);
        return false;
    }

    $pdo->prepare('UPDATE users SET subaccount_code = ?, subaccount_pending = 0 WHERE id = ?')
        ->execute([$subCode, $userId]);
    return true;
}
