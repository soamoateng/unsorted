-- ============================================================================
-- Esekiosk — MySQL 5.7 / 8.0 / MariaDB 10.x compatible schema
-- All money stored as INTEGER pesewas (1 GHS = 100 pesewas) to avoid FP errors.
-- Charset: utf8mb4 + collate utf8mb4_unicode_ci for cross-engine portability.
-- ============================================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------------------------------------------------------
-- users
-- ----------------------------------------------------------------------------
DROP TABLE IF EXISTS `order_items`;
DROP TABLE IF EXISTS `orders`;
DROP TABLE IF EXISTS `merchant_ledger`;
DROP TABLE IF EXISTS `products`;
DROP TABLE IF EXISTS `kyc_reviews`;
DROP TABLE IF EXISTS `auth_sessions`;
DROP TABLE IF EXISTS `users`;
DROP TABLE IF EXISTS `app_settings`;

CREATE TABLE `users` (
  `id`                    BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `username`              VARCHAR(50)  NOT NULL,
  `email`                 VARCHAR(254) NOT NULL,
  `password_hash`         VARCHAR(255) NOT NULL,
  `role`                  ENUM('merchant','reseller','admin') NOT NULL,
  `momo_number`           VARCHAR(15)  NOT NULL,
  `momo_network`          ENUM('MTN','TELECEL','AT') NOT NULL,
  `ghana_post_gps`        VARCHAR(12)  NULL,
  `store_description`     TEXT         NULL,
  `store_slug`            VARCHAR(80)  NULL,
  `subaccount_code`       VARCHAR(50)  NULL,
  `subaccount_pending`    TINYINT(1)   NOT NULL DEFAULT 0 COMMENT '0=done, 1=pending (cron retries), 2=in_progress (cron lock)',
  `subaccount_error`      VARCHAR(255) NULL,
  `kyc_status`            ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `subscription_cycle`    ENUM('monthly','quarterly','yearly') NULL,
  `subscription_expiry`   DATE         NULL,
  `active`                TINYINT(1)   NOT NULL DEFAULT 0,
  `payouts_paused_at`     DATETIME     NULL,
  `created_at`            DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`            DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_users_username` (`username`),
  UNIQUE KEY `uq_users_email` (`email`),
  UNIQUE KEY `uq_users_store_slug` (`store_slug`),
  KEY `idx_users_kyc_status` (`kyc_status`),
  KEY `idx_users_subaccount_pending` (`subaccount_pending`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- auth_sessions  (cookie = raw 64-hex token; DB stores SHA-256 hash of it)
-- ----------------------------------------------------------------------------
CREATE TABLE `auth_sessions` (
  `id`           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`      BIGINT UNSIGNED NOT NULL,
  `token_hash`   CHAR(64)      NOT NULL,
  `csrf_token_hash` CHAR(64)   NULL,                  -- FIX: dedicated CSRF token column (was overloaded into user_agent)
  `expires_at`    DATETIME      NOT NULL,
  `ip_address`   VARCHAR(45)   NULL,
  `user_agent`    VARCHAR(255)  NULL,
  `last_seen_at`  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at`    DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_auth_sessions_token_hash` (`token_hash`),
  KEY `idx_auth_sessions_user_id` (`user_id`),
  KEY `idx_auth_sessions_expires_at` (`expires_at`),
  CONSTRAINT `fk_auth_sessions_user_id`
    FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- kyc_reviews
-- ----------------------------------------------------------------------------
CREATE TABLE `kyc_reviews` (
  `id`           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`      BIGINT UNSIGNED NOT NULL,
  `image_path`   VARCHAR(255)  NOT NULL,
  `status`       ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `reviewed_by`  BIGINT UNSIGNED NULL,
  `reject_reason` VARCHAR(255) NULL,
  `created_at`   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `reviewed_at`  DATETIME     NULL,
  PRIMARY KEY (`id`),
  KEY `idx_kyc_status` (`status`),
  KEY `idx_kyc_user_id` (`user_id`),
  CONSTRAINT `fk_kyc_user_id`
    FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_kyc_reviewed_by`
    FOREIGN KEY (`reviewed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- products
-- ----------------------------------------------------------------------------
CREATE TABLE `products` (
  `id`                  BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `owner_user_id`       BIGINT UNSIGNED NOT NULL,
  `parent_product_id`   BIGINT UNSIGNED NULL,
  `name`                VARCHAR(150) NOT NULL,
  `description`         TEXT         NULL,
  `image_path`          VARCHAR(255) NOT NULL,
  `wholesale_price_pesewas`  INT UNSIGNED NOT NULL,
  `retail_price_pesewas`     INT UNSIGNED NOT NULL,
  `stock`               INT UNSIGNED NULL,
  `created_at`          DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`          DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_products_owner_user_id` (`owner_user_id`),
  KEY `idx_products_parent_product_id` (`parent_product_id`),
  -- FIX: prevent double-clone (one clone per reseller per parent). NULL parent_product_id
  -- rows (merchant originals) are excluded from the unique constraint by MySQL's
  -- NULL-not-equal-NULL semantics, so multiple merchant originals are allowed.
  UNIQUE KEY `uq_products_owner_parent` (`owner_user_id`, `parent_product_id`),
  CONSTRAINT `fk_products_owner_user_id`
    FOREIGN KEY (`owner_user_id`) REFERENCES `users` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_products_parent_product_id`
    FOREIGN KEY (`parent_product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- orders
-- ----------------------------------------------------------------------------
CREATE TABLE `orders` (
  `id`                     BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `store_id`               BIGINT UNSIGNED NOT NULL,
  `customer_name`          VARCHAR(120) NOT NULL,
  `customer_phone`         VARCHAR(15)  NOT NULL,
  `delivery_gps`           VARCHAR(12)  NOT NULL,
  `delivery_street`        VARCHAR(255) NULL,
  `delivery_instructions` TEXT         NULL,
  `subtotal_pesewas`       INT UNSIGNED NOT NULL,
  `delivery_fee_pesewas`   INT UNSIGNED NOT NULL DEFAULT 0,
  `total_paid_pesewas`     INT UNSIGNED NOT NULL,
  `currency`               CHAR(3)      NOT NULL DEFAULT 'GHS',
  `paystack_reference`     VARCHAR(100) NOT NULL,
  `status`                 ENUM('pending','paid','partially_shipped','delivered','cancelled')
                           NOT NULL DEFAULT 'pending',
  `created_at`             DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `paid_at`                DATETIME     NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_orders_paystack_reference` (`paystack_reference`),
  KEY `idx_orders_store_id` (`store_id`),
  KEY `idx_orders_status` (`status`),
  KEY `idx_orders_paid_at` (`paid_at`),
  KEY `idx_orders_created_at` (`created_at`),  -- FIX: index for ORDER BY in get_orders.php
  CONSTRAINT `fk_orders_store_id`
    FOREIGN KEY (`store_id`) REFERENCES `users` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- order_items
-- ----------------------------------------------------------------------------
CREATE TABLE `order_items` (
  `id`                          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `order_id`                    BIGINT UNSIGNED NOT NULL,
  `product_id`                  BIGINT UNSIGNED NOT NULL,
  `parent_product_id`           BIGINT UNSIGNED NULL,
  `quantity`                    INT UNSIGNED    NOT NULL,
  `retail_price_pesewas`        INT UNSIGNED    NOT NULL,
  `wholesale_price_pesewas`     INT UNSIGNED    NOT NULL,
  `fulfilling_merchant_id`       BIGINT UNSIGNED NOT NULL,
  `reseller_id`                 BIGINT UNSIGNED NULL,
  `status`                      ENUM('pending','processing','shipped','delivered','cancelled')
                                NOT NULL DEFAULT 'pending',
  `updated_at`                  DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_order_items_order_id` (`order_id`),
  KEY `idx_order_items_fulfilling_merchant_id` (`fulfilling_merchant_id`),
  KEY `idx_order_items_reseller_id` (`reseller_id`),  -- FIX: index for reseller_id queries in get_orders.php
  KEY `idx_order_items_status` (`status`),
  CONSTRAINT `fk_order_items_order_id`
    FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_order_items_product_id`
    FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_order_items_fulfilling_merchant_id`
    FOREIGN KEY (`fulfilling_merchant_id`) REFERENCES `users` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_order_items_reseller_id`
    FOREIGN KEY (`reseller_id`) REFERENCES `users` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- merchant_ledger
-- ----------------------------------------------------------------------------
CREATE TABLE `merchant_ledger` (
  `id`                       BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `owing_user_id`            BIGINT UNSIGNED NOT NULL,
  `debt_type`                ENUM('chargeback','subscription_nonpayment','manual_adjustment')
                             NOT NULL DEFAULT 'chargeback',
  `amount_pesewas`           INT UNSIGNED NOT NULL,
  `recovered_amount_pesewas` INT UNSIGNED NOT NULL DEFAULT 0,
  `originating_paystack_reference` VARCHAR(100) NOT NULL,
  `notes`                    VARCHAR(255) NULL,
  `created_at`               DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `recovered_at`             DATETIME     NULL,
  PRIMARY KEY (`id`),
  KEY `idx_ledger_owing_user_id` (`owing_user_id`),
  KEY `idx_ledger_outstanding` (`owing_user_id`, `recovered_amount_pesewas`),
  KEY `idx_ledger_recovered_at` (`recovered_at`),  -- FIX: index for revenue query in metrics.php
  CONSTRAINT `fk_ledger_owing_user_id`
    FOREIGN KEY (`owing_user_id`) REFERENCES `users` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- app_settings  (business logic only — NO secrets; keys live in .env)
-- ----------------------------------------------------------------------------
CREATE TABLE `app_settings` (
  `id`                      BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `setting_key`             VARCHAR(64)  NOT NULL,
  `setting_value`           VARCHAR(255) NOT NULL,
  `description`             VARCHAR(255) NULL,
  `updated_at`             DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_app_settings_key` (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `app_settings` (`setting_key`, `setting_value`, `description`) VALUES
  ('merchant_monthly_fee_pesewas',  '5000',   'Merchant monthly subscription in pesewas (50 GHS)'),
  ('merchant_quarterly_fee_pesewas','13500',  'Merchant quarterly subscription in pesewas (135 GHS)'),
  ('merchant_yearly_fee_pesewas',   '50000',  'Merchant yearly subscription in pesewas (500 GHS)'),
  ('reseller_yearly_fee_pesewas',  '30000',  'Reseller yearly subscription in pesewas (300 GHS)'),
  ('delivery_fee_pesewas',          '2000',   'Flat courier delivery fee in pesewas (20 GHS)'),
  ('max_splits',                    '5',      'Self-imposed cap on Paystack subaccount splits per checkout (NOT a Paystack limit)');

SET FOREIGN_KEY_CHECKS = 1;
