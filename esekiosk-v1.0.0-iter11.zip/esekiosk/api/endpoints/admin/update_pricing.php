<?php
declare(strict_types=1);

/**
 * api/endpoints/admin/update_pricing.php
 * Admin CRUD on app_settings business-logic rows. NEVER accepts secret keys.
 *
 * Routes (single file, action via ?op= query param):
 *   GET  ?op=list                          → list all business-logic settings
 *   POST ?op=update&key=<>&value=<>         → update one setting
 *
 * Security:
 *   - Auth required (role='admin').
 *   - CSRF required on mutations.
 *   - Blocklist: setting_key containing 'secret', 'key', 'password', 'token' is rejected.
 *     (Paystack + DB secrets live in .env, never in app_settings.)
 */

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../config/cors.php';
require_once __DIR__ . '/../../config/env.php';
require_once __DIR__ . '/../../config/csrf.php';
require_once __DIR__ . '/../../middleware/auth.php';

header('Content-Type: application/json');

try {
    Env::load(__DIR__ . '/../../config/.env');
} catch (Throwable $e) {
    http_response_code(503);
    echo json_encode(['error' => 'server_misconfiguration']);
    exit;
}

$user = require_auth();
if ($user['role'] !== 'admin') {
    http_response_code(403);
    echo json_encode(['error' => 'admin_required']);
    exit;
}

$pdo = db();
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$op = $_GET['op'] ?? 'list';

if ($method === 'GET' && $op === 'list') {
    try {
        $stmt = $pdo->query('SELECT setting_key, setting_value, description FROM app_settings ORDER BY setting_key');
        $settings = $stmt->fetchAll();
    } catch (PDOException $e) {
        http_response_code(503);
        echo json_encode(['error' => 'database_unavailable']);
        exit;
    }
    http_response_code(200);
    echo json_encode(['settings' => $settings]);
    exit;
}

if ($method === 'POST' && $op === 'update') {
    // CSRF
    $sessionId = find_session_id_for_current_cookie();
    if ($sessionId <= 0) {
        http_response_code(401);
        echo json_encode(['error' => 'unauthorized']);
        exit;
    }
    require_csrf($sessionId);

    $body = json_decode(file_get_contents('php://input') ?: '', true);
    if (!is_array($body)) {
        http_response_code(400);
        echo json_encode(['error' => 'invalid_json']);
        exit;
    }
    $key = trim($body['key'] ?? '');
    $value = trim($body['value'] ?? '');

    if ($key === '' || $value === '') {
        http_response_code(400);
        echo json_encode(['error' => 'missing_key_or_value']);
        exit;
    }

    // FIX: blocklist using word boundaries to avoid false positives like "monkey_business"
    $keyLower = strtolower($key);
    // Use exact-match allowlist for blocked substrings at word boundaries
    if (preg_match('/\b(secret|password|token|api[_-]?key)\b/i', $keyLower)
        || str_contains($keyLower, 'private_key')
        || str_contains($keyLower, 'secret_key')) {
        http_response_code(400);
        echo json_encode(['error' => 'secret_keys_must_live_in_env', 'key' => $key]);
        exit;
    }

    try {
        // FIX: verify the setting exists FIRST (rowCount() returns 0 for no-op updates,
        // which would incorrectly 404 a valid setting that the admin saved without changes).
        $check = $pdo->prepare('SELECT id FROM app_settings WHERE setting_key = ?');
        $check->execute([$key]);
        if (!$check->fetch()) {
            http_response_code(404);
            echo json_encode(['error' => 'setting_not_found']);
            exit;
        }
        $stmt = $pdo->prepare('UPDATE app_settings SET setting_value = ? WHERE setting_key = ?');
        $stmt->execute([$value, $key]);
    } catch (PDOException $e) {
        error_log('[update_pricing] failed: ' . $e->getMessage());
        http_response_code(503);
        echo json_encode(['error' => 'database_unavailable']);
        exit;
    }
    http_response_code(200);
    echo json_encode(['ok' => true, 'key' => $key, 'value' => $value]);
    exit;
}

http_response_code(400);
echo json_encode(['error' => 'unknown_op']);
