<?php
declare(strict_types=1);

/**
 * api/endpoints/admin/metrics.php
 * Phase 6: returns a JSON KPI bundle for the Owner Admin dashboard.
 *
 * Auth: role='admin' (enforced). No CSRF needed (GET = read-only).
 *
 * Returns:
 *   {
 *     total_users: { merchants: int, resellers: int, active: int, expired: int },
 *     mrr_pesewas: int,                          // monthly recurring revenue (active monthly × monthly fee + prorated quarterly/yearly)
 *     kyc_pending: int,                          // count of kyc_reviews with status='pending'
 *     subaccount_pending: int,                  // count of users with subaccount_pending=1
 *     orders_by_status: { pending, paid, partially_shipped, delivered, cancelled },
 *     outstanding_debt_pesewas: int,             // SUM(amount - recovered) from merchant_ledger
 *     top_stores_by_gmv: [{ store_slug, username, gmv_pesewas, order_count }],  // last 30 days, top 10
 *     recent_signups: [{ id, username, role, subscription_cycle, created_at }], // last 7 days
 *     revenue_30d_pesewas: int                   // subscriptions + ledger recoveries in last 30 days
 *   }
 */

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../config/cors.php';
require_once __DIR__ . '/../../config/env.php';
require_once __DIR__ . '/../../middleware/auth.php';

header('Content-Type: application/json');

try {
    Env::load(__DIR__ . '/../../config/.env');
} catch (Throwable $e) {
    http_response_code(503);
    echo json_encode(['error' => 'server_misconfiguration']);
    exit;
}

$user = require_auth();
if ($user['role'] !== 'admin') {
    http_response_code(403);
    echo json_encode(['error' => 'admin_required']);
    exit;
}

$pdo = db();

// --- Total users (merchants vs resellers, active vs expired) ---
try {
    $stmt = $pdo->query(
        "SELECT
           SUM(CASE WHEN role = 'merchant' THEN 1 ELSE 0 END) AS merchants,
           SUM(CASE WHEN role = 'reseller' THEN 1 ELSE 0 END) AS resellers,
           SUM(CASE WHEN active = 1 THEN 1 ELSE 0 END) AS active,
           SUM(CASE WHEN active = 1 AND (subscription_expiry IS NULL OR subscription_expiry < CURDATE()) THEN 1 ELSE 0 END) AS expired
         FROM users
         WHERE role IN ('merchant', 'reseller')"
    );
    $totalUsers = $stmt->fetch();
} catch (PDOException $e) {
    $totalUsers = ['merchants' => 0, 'resellers' => 0, 'active' => 0, 'expired' => 0];
}

// --- MRR (Monthly Recurring Revenue) ---
// Approximate: count active merchants by cycle, multiply by the per-cycle fee,
// then normalise to monthly: monthly × 1, quarterly × 1/3, yearly × 1/12.
// Same for resellers (yearly only → × 1/12).
try {
    $stmt = $pdo->query(
        "SELECT setting_key, setting_value FROM app_settings
         WHERE setting_key IN (
           'merchant_monthly_fee_pesewas', 'merchant_quarterly_fee_pesewas',
           'merchant_yearly_fee_pesewas', 'reseller_yearly_fee_pesewas'
         )"
    );
    $fees = [];
    foreach ($stmt->fetchAll() as $row) {
        $fees[$row['setting_key']] = (int) $row['setting_value'];
    }

    $stmt = $pdo->query(
        "SELECT role, subscription_cycle, COUNT(*) AS cnt
         FROM users
         WHERE active = 1 AND role IN ('merchant', 'reseller')
         GROUP BY role, subscription_cycle"
    );
    // FIX: MRR computed with intdiv to avoid FP drift, and rounded once at the end
    // per cycle (was truncating per-user, losing fractional pesewas across many users).
    $mrr = 0;
    foreach ($stmt->fetchAll() as $row) {
        $cycle = $row['subscription_cycle'];
        $cnt = (int) $row['cnt'];
        if ($row['role'] === 'merchant') {
            if ($cycle === 'monthly')   $mrr += $cnt * ($fees['merchant_monthly_fee_pesewas'] ?? 0);
            if ($cycle === 'quarterly') $mrr += intdiv($cnt * ($fees['merchant_quarterly_fee_pesewas'] ?? 0), 3);
            if ($cycle === 'yearly')    $mrr += intdiv($cnt * ($fees['merchant_yearly_fee_pesewas'] ?? 0), 12);
        } elseif ($row['role'] === 'reseller') {
            $mrr += intdiv($cnt * ($fees['reseller_yearly_fee_pesewas'] ?? 0), 12);
        }
    }
} catch (PDOException $e) {
    $mrr = 0;
}

// --- KYC pending count ---
try {
    $kycPending = (int) $pdo->query("SELECT COUNT(*) FROM kyc_reviews WHERE status = 'pending'")->fetchColumn();
} catch (PDOException $e) {
    $kycPending = 0;
}

// --- Subaccount pending count ---
try {
    $subaccountPending = (int) $pdo->query("SELECT COUNT(*) FROM users WHERE subaccount_pending = 1")->fetchColumn();
} catch (PDOException $e) {
    $subaccountPending = 0;
}

// --- Orders by status ---
$ordersByStatus = ['pending' => 0, 'paid' => 0, 'partially_shipped' => 0, 'delivered' => 0, 'cancelled' => 0];
try {
    $stmt = $pdo->query("SELECT status, COUNT(*) AS cnt FROM orders GROUP BY status");
    foreach ($stmt->fetchAll() as $row) {
        if (isset($ordersByStatus[$row['status']])) {
            $ordersByStatus[$row['status']] = (int) $row['cnt'];
        }
    }
} catch (PDOException $e) { /* keep zeros */ }

// --- Outstanding debt ---
$outstandingDebt = 0;
try {
    $stmt = $pdo->query("SELECT SUM(amount_pesewas - recovered_amount_pesewas) FROM merchant_ledger WHERE recovered_amount_pesewas < amount_pesewas");
    $outstandingDebt = (int) ($stmt->fetchColumn() ?: 0);
} catch (PDOException $e) { /* keep 0 */ }

// --- Top 10 stores by GMV (last 30 days) ---
$topStores = [];
try {
    $stmt = $pdo->prepare(
        "SELECT u.id, u.username, u.store_slug,
                COALESCE(SUM(o.total_paid_pesewas), 0) AS gmv_pesewas,
                COUNT(o.id) AS order_count
         FROM users u
         LEFT JOIN orders o ON o.store_id = u.id
            AND o.status IN ('paid','processing','partially_shipped','delivered')
            AND o.paid_at >= (NOW() - INTERVAL 30 DAY)
         WHERE u.role IN ('merchant', 'reseller') AND u.active = 1
         GROUP BY u.id, u.username, u.store_slug
         HAVING gmv_pesewas > 0
         ORDER BY gmv_pesewas DESC
         LIMIT 10"
    );
    $stmt->execute();
    foreach ($stmt->fetchAll() as $row) {
        $topStores[] = [
            'store_slug' => $row['store_slug'],
            'username' => $row['username'],
            'gmv_pesewas' => (int) $row['gmv_pesewas'],
            'order_count' => (int) $row['order_count'],
        ];
    }
} catch (PDOException $e) { /* keep empty */ }

// --- Recent signups (last 7 days) ---
$recentSignups = [];
try {
    $stmt = $pdo->prepare(
        "SELECT id, username, role, subscription_cycle, created_at
         FROM users
         WHERE role IN ('merchant', 'reseller') AND created_at >= (NOW() - INTERVAL 7 DAY)
         ORDER BY created_at DESC
         LIMIT 20"
    );
    $stmt->execute();
    foreach ($stmt->fetchAll() as $row) {
        $recentSignups[] = [
            'id' => (int) $row['id'],
            'username' => $row['username'],
            'role' => $row['role'],
            'subscription_cycle' => $row['subscription_cycle'],
            'created_at' => $row['created_at'],
        ];
    }
} catch (PDOException $e) { /* keep empty */ }

// --- Revenue last 30 days (subscription fees paid + ledger recoveries) ---
$revenue30d = 0;
try {
    // Subscription revenue: sum of orders where metadata.kind = 'subscription' and paid in last 30d.
    // We approximate by summing orders with reference prefix 'esekiosk_sub_'.
    $stmt = $pdo->prepare(
        "SELECT COALESCE(SUM(total_paid_pesewas), 0)
         FROM orders
         WHERE paystack_reference LIKE 'esekiosk_sub_%'
           AND status = 'paid'
           AND paid_at >= (NOW() - INTERVAL 30 DAY)"
    );
    $stmt->execute();
    $revenue30d += (int) $stmt->fetchColumn();

    // FIX: ledger recoveries — count rows where recovered_at is in the last 30 days.
    // The previous fix added `AND created_at >= ...` which excluded debts created >30d
    // ago that were recovered in the window — undercounting revenue. Reverted to just
    // recovered_at. Known limitation: a partial recovery 60d ago + completion today
    // counts the FULL recovered_amount (not just the 30d portion). Phase 9 should add
    // a per-recovery `ledger_recoveries` table to fix this precisely.
    $stmt = $pdo->prepare(
        "SELECT COALESCE(SUM(recovered_amount_pesewas), 0)
         FROM merchant_ledger
         WHERE recovered_at >= (NOW() - INTERVAL 30 DAY)"
    );
    $stmt->execute();
    $revenue30d += (int) $stmt->fetchColumn();
} catch (PDOException $e) { /* keep partial */ }

http_response_code(200);
echo json_encode([
    'total_users' => [
        'merchants' => (int) ($totalUsers['merchants'] ?? 0),
        'resellers' => (int) ($totalUsers['resellers'] ?? 0),
        'active' => (int) ($totalUsers['active'] ?? 0),
        'expired' => (int) ($totalUsers['expired'] ?? 0),
    ],
    'mrr_pesewas' => $mrr,
    'kyc_pending' => $kycPending,
    'subaccount_pending' => $subaccountPending,
    'orders_by_status' => $ordersByStatus,
    'outstanding_debt_pesewas' => $outstandingDebt,
    'top_stores_by_gmv' => $topStores,
    'recent_signups' => $recentSignups,
    'revenue_30d_pesewas' => $revenue30d,
]);
