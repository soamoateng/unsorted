<?php
declare(strict_types=1);

/**
 * api/endpoints/admin/ledger.php
 * Lists outstanding debts from merchant_ledger + manual recovery actions.
 *
 * Routes (single file, action via ?op= query param):
 *   GET  ?op=outstanding                    → list all outstanding debts
 *   GET  ?op=user&id=<user_id>              → list debts for a specific user
 *   POST ?op=mark_recovered&id=<debt_id>    → mark a debt fully recovered (manual override)
 *
 * Security:
 *   - Auth required (role='admin').
 *   - CSRF required on mutations.
 */

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../config/cors.php';
require_once __DIR__ . '/../../config/env.php';
require_once __DIR__ . '/../../config/csrf.php';
require_once __DIR__ . '/../../middleware/auth.php';

header('Content-Type: application/json');

try {
    Env::load(__DIR__ . '/../../config/.env');
} catch (Throwable $e) {
    http_response_code(503);
    echo json_encode(['error' => 'server_misconfiguration']);
    exit;
}

$user = require_auth();
if ($user['role'] !== 'admin') {
    http_response_code(403);
    echo json_encode(['error' => 'admin_required']);
    exit;
}

$pdo = db();
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$op = $_GET['op'] ?? 'outstanding';

if ($method === 'GET' && ($op === 'outstanding' || $op === 'user')) {
    try {
        if ($op === 'outstanding') {
            $stmt = $pdo->prepare(
                "SELECT ml.id, ml.owing_user_id, u.username, u.momo_number, u.momo_network,
                        ml.debt_type, ml.amount_pesewas, ml.recovered_amount_pesewas,
                        (ml.amount_pesewas - ml.recovered_amount_pesewas) AS outstanding_pesewas,
                        ml.originating_paystack_reference, ml.notes, ml.created_at, ml.recovered_at
                 FROM merchant_ledger ml
                 JOIN users u ON u.id = ml.owing_user_id
                 WHERE ml.recovered_amount_pesewas < ml.amount_pesewas
                 ORDER BY ml.created_at ASC
                 LIMIT 100"
            );
            $stmt->execute();
        } else {
            $userId = (int) ($_GET['id'] ?? 0);
            if ($userId <= 0) {
                http_response_code(400);
                echo json_encode(['error' => 'invalid_user_id']);
                exit;
            }
            $stmt = $pdo->prepare(
                "SELECT ml.id, ml.owing_user_id, u.username, u.momo_number, u.momo_network,
                        ml.debt_type, ml.amount_pesewas, ml.recovered_amount_pesewas,
                        (ml.amount_pesewas - ml.recovered_amount_pesewas) AS outstanding_pesewas,
                        ml.originating_paystack_reference, ml.notes, ml.created_at, ml.recovered_at
                 FROM merchant_ledger ml
                 JOIN users u ON u.id = ml.owing_user_id
                 WHERE ml.owing_user_id = ?
                 ORDER BY ml.created_at ASC
                 LIMIT 100"
            );
            $stmt->execute([$userId]);
        }
        $debts = $stmt->fetchAll();
    } catch (PDOException $e) {
        error_log('[ledger] list failed: ' . $e->getMessage());
        http_response_code(503);
        echo json_encode(['error' => 'database_unavailable']);
        exit;
    }
    $result = array_map(function ($d) {
        return [
            'id' => (int) $d['id'],
            'owing_user_id' => (int) $d['owing_user_id'],
            'username' => $d['username'],
            'momo_number' => $d['momo_number'],
            'momo_network' => $d['momo_network'],
            'debt_type' => $d['debt_type'],
            'amount_pesewas' => (int) $d['amount_pesewas'],
            'recovered_amount_pesewas' => (int) $d['recovered_amount_pesewas'],
            'outstanding_pesewas' => (int) $d['outstanding_pesewas'],
            'originating_paystack_reference' => $d['originating_paystack_reference'],
            'notes' => $d['notes'],
            'created_at' => $d['created_at'],
            'recovered_at' => $d['recovered_at'],
        ];
    }, $debts);
    http_response_code(200);
    echo json_encode(['debts' => $result]);
    exit;
}

if ($method === 'POST' && $op === 'mark_recovered') {
    $sessionId = find_session_id_for_current_cookie();
    if ($sessionId <= 0) {
        http_response_code(401);
        echo json_encode(['error' => 'unauthorized']);
        exit;
    }
    require_csrf($sessionId);

    // FIX: accept id from POST body only (was $_POST or $_GET — invites IDOR via query string)
    $body = json_decode(file_get_contents('php://input') ?: '', true);
    if (!is_array($body)) {
        // Fallback to form-encoded
        $debtId = (int) ($_POST['id'] ?? 0);
    } else {
        $debtId = (int) ($body['id'] ?? 0);
    }
    if ($debtId <= 0) {
        http_response_code(400);
        echo json_encode(['error' => 'invalid_debt_id']);
        exit;
    }

    try {
        $stmt = $pdo->prepare(
            'UPDATE merchant_ledger
             SET recovered_amount_pesewas = amount_pesewas,
                 recovered_at = NOW()
             WHERE id = ? AND recovered_amount_pesewas < amount_pesewas'
        );
        $stmt->execute([$debtId]);
        if ($stmt->rowCount() === 0) {
            http_response_code(409);
            echo json_encode(['error' => 'already_recovered_or_not_found']);
            exit;
        }
    } catch (PDOException $e) {
        error_log('[ledger] mark_recovered failed: ' . $e->getMessage());
        http_response_code(503);
        echo json_encode(['error' => 'database_unavailable']);
        exit;
    }
    http_response_code(200);
    echo json_encode(['ok' => true, 'debt_id' => $debtId]);
    exit;
}

http_response_code(400);
echo json_encode(['error' => 'unknown_op']);
