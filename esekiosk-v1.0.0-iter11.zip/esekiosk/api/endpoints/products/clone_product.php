<?php
declare(strict_types=1);

/**
 * api/endpoints/products/clone_product.php
 * Reseller clones a merchant's wholesale product. Server enforces retail_price > wholesale_price.
 *
 * Security:
 *   - Auth required (role='reseller').
 *   - CSRF required (mutation).
 *   - IDOR: the reseller cannot choose their own user_id — auth middleware supplies it.
 *   - The parent_product_id must point to a merchant-owned original (parent_product_id IS NULL).
 *   - Server-side retail > wholesale check (don't trust the client).
 *
 * Per PRD:
 *   - The clone's stock column stays NULL and always resolves against the parent's live count.
 *   - The clone's retail_price is the customer-facing price (the markup).
 *   - The clone's wholesale_price stays equal to the merchant's wholesale price (captured at clone time).
 */

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../config/cors.php';
require_once __DIR__ . '/../../config/env.php';
require_once __DIR__ . '/../../config/csrf.php';
require_once __DIR__ . '/../../middleware/auth.php';
require_once __DIR__ . '/../../middleware/sanitize.php';

header('Content-Type: application/json');

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'method_not_allowed']);
    exit;
}

try {
    Env::load(__DIR__ . '/../../config/.env');
} catch (Throwable $e) {
    http_response_code(503);
    echo json_encode(['error' => 'server_misconfiguration']);
    exit;
}

$user = require_auth();
if ($user['role'] !== 'reseller') {
    http_response_code(403);
    echo json_encode(['error' => 'reseller_required']);
    exit;
}

// FIX: initialize $pdo (was missing — every call crashed with "Call to a member function prepare() on null")
$pdo = db();

// CSRF
$sessionId = find_session_id_for_current_cookie();
if ($sessionId <= 0) {
    http_response_code(401);
    echo json_encode(['error' => 'unauthorized']);
    exit;
}
require_csrf($sessionId);

// --- Parse input ---
$body = json_decode(file_get_contents('php://input') ?: '', true);
if (!is_array($body)) {
    http_response_code(400);
    echo json_encode(['error' => 'invalid_json']);
    exit;
}

// FIX: validate integers properly (was (int) cast that silently truncated floats)
$parentId = filter_var($body['parent_product_id'] ?? '', FILTER_VALIDATE_INT);
$retailPrice = filter_var($body['retail_price_pesewas'] ?? '', FILTER_VALIDATE_INT);

if ($parentId === false || $parentId <= 0 || $retailPrice === false || $retailPrice <= 0) {
    http_response_code(400);
    echo json_encode(['error' => 'validation_failed', 'fields' => ['parent_product_id', 'retail_price_pesewas']]);
    exit;
}

try {
    // Look up the parent product. Must be a merchant-owned original (parent_product_id IS NULL).
    $stmt = $pdo->prepare(
        'SELECT id, owner_user_id, name, description, image_path,
                wholesale_price_pesewas, retail_price_pesewas, stock
         FROM products
         WHERE id = ? AND parent_product_id IS NULL
         LIMIT 1'
    );
    $stmt->execute([$parentId]);
    $parent = $stmt->fetch();
    if (!$parent) {
        http_response_code(404);
        echo json_encode(['error' => 'parent_not_found_or_not_original']);
        exit;
    }

    // Server-side markup validation: retail must be > wholesale (strict).
    if ($retailPrice <= (int) $parent['wholesale_price_pesewas']) {
        http_response_code(400);
        echo json_encode([
            'error' => 'retail_must_exceed_wholesale',
            'wholesale_price_pesewas' => (int) $parent['wholesale_price_pesewas'],
            'retail_price_pesewas' => $retailPrice,
        ]);
        exit;
    }

    // FIX: wrap double-clone check + insert in a transaction with FOR UPDATE on the parent.
    // The UNIQUE KEY uq_products_owner_parent is the final safety net.
    $pdo->beginTransaction();
    // Re-lock the parent row to prevent concurrent clones from racing
    $parentLock = $pdo->prepare('SELECT id FROM products WHERE id = ? AND parent_product_id IS NULL FOR UPDATE');
    $parentLock->execute([$parentId]);

    // Prevent the reseller from cloning the same product twice.
    $stmt = $pdo->prepare(
        'SELECT id FROM products
         WHERE owner_user_id = ? AND parent_product_id = ?
         LIMIT 1'
    );
    $stmt->execute([$user['id'], $parentId]);
    if ($stmt->fetch()) {
        $pdo->rollBack();
        http_response_code(409);
        echo json_encode(['error' => 'already_cloned']);
        exit;
    }

    // Insert the clone — stock stays NULL (resolves against parent at query time in get_products.php).
    $stmt = $pdo->prepare(
        'INSERT INTO products
         (owner_user_id, parent_product_id, name, description, image_path,
          wholesale_price_pesewas, retail_price_pesewas, stock)
         VALUES (?, ?, ?, ?, ?, ?, ?, NULL)'
    );
    $stmt->execute([
        $user['id'], $parentId,
        $parent['name'], $parent['description'], $parent['image_path'],
        $parent['wholesale_price_pesewas'], $retailPrice,
    ]);
    $cloneId = (int) $pdo->lastInsertId();
    $pdo->commit();
} catch (PDOException $e) {
    if (isset($pdo) && $pdo->inTransaction()) $pdo->rollBack();
    // FIX: catch the UNIQUE constraint violation from uq_products_owner_parent
    if ($e->getCode() === '23000' || str_contains($e->getMessage(), 'Duplicate')) {
        http_response_code(409);
        echo json_encode(['error' => 'already_cloned']);
        exit;
    }
    error_log('[clone_product] failed: ' . $e->getMessage());
    http_response_code(503);
    echo json_encode(['error' => 'database_unavailable']);
    exit;
}

http_response_code(201);
echo json_encode([
    'ok' => true,
    'clone' => [
        'id' => $cloneId,
        'owner_user_id' => (int) $user['id'],
        'parent_product_id' => $parentId,
        'name' => $parent['name'],
        'image_path' => $parent['image_path'],
        'wholesale_price_pesewas' => (int) $parent['wholesale_price_pesewas'],
        'retail_price_pesewas' => $retailPrice,
        'stock' => null, // resolves against parent at query time
    ],
]);
