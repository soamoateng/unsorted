<?php
declare(strict_types=1);

/**
 * api/endpoints/products/add_product.php
 * Merchant uploads a new product. Validates the file's real bytes via finfo_file(),
 * compresses with GD, renames to bin2hex(random_bytes(8)) . '.jpg', saves to /uploads/products/.
 *
 * Security:
 *   - Auth required (role='merchant').
 *   - CSRF required (mutation).
 *   - IDOR: only the authenticated user's id is used as owner_user_id. The client
 *     cannot set owner_user_id; we ignore any such field in the POST body.
 *   - finfo_file() real-MIME check (don't trust the browser's Content-Type).
 *   - GD re-encodes the image — strips any embedded PHP/malware payloads.
 *   - random_bytes(8) filename — unpredictable; prevents path traversal.
 *   - Stock must be a non-negative integer. Wholesale price must be > 0.
 *
 * Sources:
 *   https://www.php.net/manual/en/function.finfo-file.php
 *   https://www.php.net/manual/en/function.imagejpeg.php
 *   https://phppot.com — "Secure File Upload in PHP 8" (Jul 10, 2026)
 *   https://security.stackexchange.com — finfo_file real-MIME check best practice
 */

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../config/cors.php';
require_once __DIR__ . '/../../config/env.php';
require_once __DIR__ . '/../../config/csrf.php';
require_once __DIR__ . '/../../middleware/auth.php';
require_once __DIR__ . '/../../middleware/sanitize.php';

header('Content-Type: application/json');

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'method_not_allowed']);
    exit;
}

try {
    Env::load(__DIR__ . '/../../config/.env');
} catch (Throwable $e) {
    http_response_code(503);
    echo json_encode(['error' => 'server_misconfiguration']);
    exit;
}

$user = require_auth();
if ($user['role'] !== 'merchant') {
    http_response_code(403);
    echo json_encode(['error' => 'merchant_required']);
    exit;
}

// CSRF: find the session id for the current cookie and verify the token
$sessionId = find_session_id_for_current_cookie();
if ($sessionId <= 0) {
    http_response_code(401);
    echo json_encode(['error' => 'unauthorized']);
    exit;
}
require_csrf($sessionId);

// --- Parse + sanitize text fields ---
$name        = sanitize_text($_POST['name'] ?? '');
$description = sanitize_text($_POST['description'] ?? '');
// FIX: validate integers properly (was (int) cast that silently truncated "5.99" → 5)
$wholesaleRaw = $_POST['wholesale_price_pesewas'] ?? '';
$wholesale = filter_var($wholesaleRaw, FILTER_VALIDATE_INT);
$stockRaw = $_POST['stock'] ?? '';
$stock = ($stockRaw === '' || $stockRaw === null) ? null : filter_var($stockRaw, FILTER_VALIDATE_INT);

// --- Validate text ---
$errors = [];
if (mb_strlen($name) < 2 || mb_strlen($name) > 150) $errors[] = 'name';
if (mb_strlen($description) > 5000) $errors[] = 'description';
// FIX: filter_var returns false on invalid input — distinguish from valid 0
if ($wholesale === false || $wholesale <= 0) $errors[] = 'wholesale_price_pesewas';
if ($stock === false || $stock === null || $stock < 0 || $stock > 1_000_000) {
    $errors[] = 'stock';
}

// --- Validate file ---
$file = $_FILES['image'] ?? null;
if (!$file || $file['error'] !== UPLOAD_ERR_OK) {
    $errors[] = 'image';
} else {
    if ($file['size'] > 6 * 1024 * 1024) {
        $errors[] = 'image_size';
    }
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $realMime = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);
    if (!in_array($realMime, ['image/jpeg', 'image/png', 'image/webp'], true)) {
        $errors[] = 'image_type';
    }
}

if ($errors) {
    http_response_code(400);
    echo json_encode(['error' => 'validation_failed', 'fields' => $errors]);
    exit;
}

// --- GD re-encode (strips embedded payloads, normalises to JPEG) ---
$src = $file['tmp_name'];
$img = null;
$mime = $realMime ?? '';
if ($mime === 'image/jpeg') $img = @imagecreatefromjpeg($src);
elseif ($mime === 'image/png') $img = @imagecreatefrompng($src);
elseif ($mime === 'image/webp') $img = @imagecreatefromwebp($src);

if (!$img) {
    error_log('[add_product] GD could not decode image for user ' . $user['id']);
    http_response_code(400);
    echo json_encode(['error' => 'image_unreadable']);
    exit;
}

// Convert palette to truecolor so imagejpeg works for PNG with alpha
if (!imageistruecolor($img)) {
    $tc = imagecreatetruecolor(imagesx($img), imagesy($img));
    $white = imagecolorallocate($tc, 255, 255, 255);
    imagefill($tc, 0, 0, $white);
    imagecopy($tc, $img, 0, 0, 0, 0, imagesx($img), imagesy($img));
    imagedestroy($img);
    $img = $tc;
}

// Resize if max dimension exceeds 1200 (keeps file size small for storefront)
$maxDim = 1200;
$w = imagesx($img);
$h = imagesy($img);
if ($w > $maxDim || $h > $maxDim) {
    $ratio = min($maxDim / $w, $maxDim / $h);
    $newW = (int) round($w * $ratio);
    $newH = (int) round($h * $ratio);
    $resized = imagecreatetruecolor($newW, $newH);
    imagecopyresampled($resized, $img, 0, 0, 0, 0, $newW, $newH, $w, $h);
    imagedestroy($img);
    $img = $resized;
}

// Save to a temp buffer, then write to disk
$uploadDir = __DIR__ . '/../../uploads/products/';
if (!is_dir($uploadDir)) {
    @mkdir($uploadDir, 0755, true);
}
$destName = 'prod_' . bin2hex(random_bytes(8)) . '.jpg';
$destPath = $uploadDir . $destName;
$quality = 82; // visual quality vs file size sweet spot
if (!imagejpeg($img, $destPath, $quality)) {
    imagedestroy($img);
    error_log('[add_product] imagejpeg failed for user ' . $user['id']);
    http_response_code(500);
    echo json_encode(['error' => 'image_save_failed']);
    exit;
}
imagedestroy($img);
chmod($destPath, 0644);

$imagePath = 'uploads/products/' . $destName;

// FIX: initialize $pdo (was missing — every upload crashed with "Call to a member function prepare() on null")
$pdo = db();

// --- Insert product row ---
try {
    $stmt = $pdo->prepare(
        'INSERT INTO products
         (owner_user_id, parent_product_id, name, description, image_path,
          wholesale_price_pesewas, retail_price_pesewas, stock)
         VALUES (?, NULL, ?, ?, ?, ?, ?, ?)'
    );
    // For a merchant's own product, retail = wholesale (resellers set the markup)
    $stmt->execute([
        $user['id'], $name, $description, $imagePath,
        $wholesale, $wholesale, $stock,
    ]);
    $productId = (int) $pdo->lastInsertId();
} catch (PDOException $e) {
    error_log('[add_product] insert failed: ' . $e->getMessage());
    // Clean up the orphaned image file
    @unlink($destPath);
    http_response_code(503);
    echo json_encode(['error' => 'database_unavailable']);
    exit;
}

http_response_code(201);
echo json_encode([
    'ok' => true,
    'product' => [
        'id' => $productId,
        'owner_user_id' => (int) $user['id'],
        'name' => $name,
        'description' => $description,
        'image_path' => $imagePath,
        'wholesale_price_pesewas' => $wholesale,
        'retail_price_pesewas' => $wholesale,
        'stock' => $stock,
    ],
]);
