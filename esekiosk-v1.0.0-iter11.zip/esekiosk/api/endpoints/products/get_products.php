<?php
declare(strict_types=1);

/**
 * api/endpoints/products/get_products.php
 * Fetch products. Two query modes (controlled by query params):
 *
 *   1. ?store=<slug>           Public storefront: fetch the merchant's or reseller's
 *                              storefront products (what a customer sees). IDOR-safe
 *                              because the slug is looked up — the client cannot pass
 *                              a user_id.
 *   2. ?wholesale=1            Merchant wholesale inventory for resellers to browse.
 *                              Auth required (role='reseller' or 'merchant').
 *
 * IDOR safety:
 *   - Never accepts owner_user_id from the client. The slug lookup isolates the store.
 *   - For wholesale browse, the auth middleware supplies the user (and we don't filter
 *     by user_id — all merchants' wholesale products are browseable by resellers).
 *
 * JOINs:
 *   - For a reseller's store (products.parent_product_id IS NOT NULL), JOIN to the
 *     parent product to resolve the live stock from the merchant's inventory.
 *
 * Returns:
 *   - 200 with {products: [...]} on success
 *   - 404 if the store slug doesn't exist
 *   - 401 if wholesale=1 and no valid session
 */

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../config/cors.php';
require_once __DIR__ . '/../../config/env.php';
require_once __DIR__ . '/../../middleware/auth.php';
require_once __DIR__ . '/../../middleware/sanitize.php';

header('Content-Type: application/json');

try {
    Env::load(__DIR__ . '/../../config/.env');
} catch (Throwable $e) {
    http_response_code(503);
    echo json_encode(['error' => 'server_misconfiguration']);
    exit;
}

$pdo = db();
$storeSlug = isset($_GET['store']) ? sanitize_text($_GET['store']) : '';
$wholesale = isset($_GET['wholesale']) && $_GET['wholesale'] === '1';

if ($wholesale) {
    // Reseller browse: all merchants' wholesale products, excluding the user's own.
    // Auth required.
    $user = optional_auth();
    if (!$user) {
        http_response_code(401);
        echo json_encode(['error' => 'unauthorized']);
        exit;
    }
    if ($user['role'] !== 'reseller' && $user['role'] !== 'merchant') {
        http_response_code(403);
        echo json_encode(['error' => 'merchant_or_reseller_required']);
        exit;
    }
    try {
        // Only merchant-owned original products (parent_product_id IS NULL).
        // JOIN users to surface merchant name + slug for display.
        $stmt = $pdo->prepare(
            'SELECT p.id, p.name, p.description, p.image_path,
                    p.wholesale_price_pesewas, p.retail_price_pesewas,
                    p.stock, p.owner_user_id, u.username AS owner_username,
                    u.store_slug AS owner_store_slug
             FROM products p
             JOIN users u ON u.id = p.owner_user_id
             WHERE p.parent_product_id IS NULL
               AND p.owner_user_id <> ?
               AND u.active = 1
             ORDER BY p.created_at DESC
             LIMIT 200'
        );
        $stmt->execute([$user['id']]);
        $rows = $stmt->fetchAll();
    } catch (PDOException $e) {
        error_log('[get_products] wholesale query failed: ' . $e->getMessage());
        http_response_code(503);
        echo json_encode(['error' => 'database_unavailable']);
        exit;
    }
    // For wholesale, expose live stock (reseller sees merchant's stock for cloning decisions)
    $products = array_map(function ($r) {
        return [
            'id' => (int) $r['id'],
            'name' => $r['name'],
            'description' => $r['description'],
            'image_path' => $r['image_path'],
            'wholesale_price_pesewas' => (int) $r['wholesale_price_pesewas'],
            'retail_price_pesewas' => (int) $r['retail_price_pesewas'],
            'stock' => $r['stock'] !== null ? (int) $r['stock'] : null,
            'owner_user_id' => (int) $r['owner_user_id'],
            'owner_username' => $r['owner_username'],
            'owner_store_slug' => $r['owner_store_slug'],
            'is_clone' => false,
        ];
    }, $rows);
    http_response_code(200);
    echo json_encode(['products' => $products]);
    exit;
}

// --- Public storefront by slug ---
if ($storeSlug === '') {
    http_response_code(400);
    echo json_encode(['error' => 'store_or_wholesale_required']);
    exit;
}

try {
    // Look up the store by slug
    $stmt = $pdo->prepare(
        'SELECT id, username, store_slug, role, momo_number, momo_network,
                subaccount_code, subaccount_pending, kyc_status, active
         FROM users WHERE store_slug = ? LIMIT 1'
    );
    $stmt->execute([$storeSlug]);
    $store = $stmt->fetch();
    if (!$store) {
        http_response_code(404);
        echo json_encode(['error' => 'store_not_found']);
        exit;
    }
    if (!$store['active']) {
        http_response_code(403);
        echo json_encode(['error' => 'store_inactive']);
        exit;
    }
    $storeId = (int) $store['id'];

    // Fetch the store's products. For reseller clones (parent_product_id IS NOT NULL),
    // JOIN to the parent to resolve live stock from the merchant's inventory.
    $stmt = $pdo->prepare(
        'SELECT p.id, p.name, p.description, p.image_path,
                p.retail_price_pesewas, p.stock AS reseller_stock,
                parent.stock AS merchant_stock, parent.id AS parent_product_id,
                parent.owner_user_id AS merchant_id
         FROM products p
         LEFT JOIN products parent ON parent.id = p.parent_product_id
         WHERE p.owner_user_id = ?
         ORDER BY p.created_at DESC
         LIMIT 200'
    );
    $stmt->execute([$storeId]);
    $rows = $stmt->fetchAll();
} catch (PDOException $e) {
    error_log('[get_products] store query failed: ' . $e->getMessage());
    http_response_code(503);
    echo json_encode(['error' => 'database_unavailable']);
    exit;
}

// Resolve stock: reseller clones use the merchant's live stock; merchant originals
// use their own stock column. This is the "real-time stock sync" PRD requirement.
$products = array_map(function ($r) {
    $isClone = $r['parent_product_id'] !== null;
    $liveStock = $isClone ? (int) $r['merchant_stock'] : (int) $r['reseller_stock'];
    return [
        'id' => (int) $r['id'],
        'name' => $r['name'],
        'description' => $r['description'],
        'image_path' => $r['image_path'],
        'retail_price_pesewas' => (int) $r['retail_price_pesewas'],
        'stock' => $liveStock,
        'parent_product_id' => $r['parent_product_id'] !== null ? (int) $r['parent_product_id'] : null,
        'merchant_id' => $r['merchant_id'] !== null ? (int) $r['merchant_id'] : null,
        'is_clone' => $isClone,
    ];
}, $rows);

http_response_code(200);
echo json_encode([
    'store' => [
        'id' => (int) $store['id'],
        'username' => $store['username'],
        'store_slug' => $store['store_slug'],
        'role' => $store['role'],
        'subaccount_pending' => (bool) $store['subaccount_pending'],
    ],
    'products' => $products,
]);
