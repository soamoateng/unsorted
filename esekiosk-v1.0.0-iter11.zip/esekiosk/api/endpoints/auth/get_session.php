<?php
declare(strict_types=1);

/**
 * api/endpoints/auth/get_session.php
 * Validate the cookie and return the user + a fresh CSRF token.
 *
 * Called on app boot by authStore.hydrate() to populate the SPA's session state.
 * Returns 401 if the cookie is missing or invalid — the frontend redirects to #/signin.
 */

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../config/cors.php';
require_once __DIR__ . '/../../config/env.php';
require_once __DIR__ . '/../../config/csrf.php';
require_once __DIR__ . '/../../middleware/auth.php';

header('Content-Type: application/json');

$cookie = $_COOKIE['esekiosk_session'] ?? '';
if ($cookie === '' || !ctype_xdigit($cookie) || strlen($cookie) !== 64) {
    http_response_code(401);
    echo json_encode(['error' => 'unauthorized']);
    exit;
}

try {
    Env::load(__DIR__ . '/../../config/.env');
} catch (Throwable $e) {
    http_response_code(503);
    echo json_encode(['error' => 'server_misconfiguration']);
    exit;
}

$pdo = db();
$tokenHash = hash('sha256', $cookie);
try {
    $stmt = $pdo->prepare(
        'SELECT s.id AS session_id, s.expires_at,
                u.id, u.username, u.email, u.role, u.momo_number, u.momo_network,
                u.ghana_post_gps, u.store_slug, u.subaccount_code, u.subaccount_pending,
                u.kyc_status, u.subscription_cycle, u.subscription_expiry, u.active,
                u.payouts_paused_at
         FROM auth_sessions s
         JOIN users u ON u.id = s.user_id
         WHERE s.token_hash = ?'
    );
    $stmt->execute([$tokenHash]);
    $row = $stmt->fetch();
} catch (PDOException $e) {
    error_log('[get_session] lookup failed: ' . $e->getMessage());
    http_response_code(503);
    echo json_encode(['error' => 'database_unavailable']);
    exit;
}

if (!$row) {
    http_response_code(401);
    echo json_encode(['error' => 'unauthorized']);
    exit;
}

if (strtotime($row['expires_at']) < time()) {
    http_response_code(401);
    echo json_encode(['error' => 'session_expired']);
    exit;
}

// Refresh last_seen_at (best-effort)
try {
    $stmt = $pdo->prepare('UPDATE auth_sessions SET last_seen_at = NOW() WHERE id = ?');
    $stmt->execute([$row['session_id']]);
} catch (PDOException $e) {
    /* non-fatal */
}

// Phase 7: Session rotation on privilege change.
// If the user was 'pending' (inactive) when this session was created but is now 'active',
// rotate the session token to invalidate any pre-activation session that may have leaked.
// The frontend gets a new cookie via Set-Cookie + a fresh CSRF token.
if ((int) $row['active'] === 1) {
    // Check if the session predates activation. We approximate by comparing
    // auth_sessions.created_at to users.updated_at (which updates on activation).
    // If the session is older than the user's last update, rotate.
    try {
        $checkStmt = $pdo->prepare(
            'SELECT s.created_at AS session_created, u.updated_at AS user_updated
             FROM auth_sessions s
             JOIN users u ON u.id = s.user_id
             WHERE s.id = ?'
        );
        $checkStmt->execute([$row['session_id']]);
        $dates = $checkStmt->fetch();
        if ($dates && strtotime($dates['session_created']) < strtotime($dates['user_updated']) - 1) {
            // Session predates the user's last update → rotate.
            $newRaw = bin2hex(random_bytes(32));
            $newHash = hash('sha256', $newRaw);
            $upd = $pdo->prepare('UPDATE auth_sessions SET token_hash = ? WHERE id = ?');
            $upd->execute([$newHash, $row['session_id']]);
            // FIX: trusted-proxy check (was blindly trusting X-Forwarded-Proto)
            $isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
            $trustedProxy = Env::get('APP_TRUSTED_PROXY', '');
            if (!$isHttps && $trustedProxy && ($_SERVER['REMOTE_ADDR'] ?? '') === $trustedProxy) {
                $isHttps = ($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https';
            }
            setcookie('esekiosk_session', $newRaw, [
                'expires' => time() + 720 * 3600,
                'path' => '/',
                'secure' => $isHttps,
                'httponly' => true,
                'samesite' => 'Lax',
            ]);
            // FIX: also rotate the CSRF token so the old token doesn't validate against the rotated session.
            // (issue_csrf_token overwrites csrf_token_hash with a fresh hash)
        }
    } catch (Throwable $e) {
        // Non-fatal: continue with the existing session if rotation fails.
        error_log('[get_session] rotation check failed: ' . $e->getMessage());
    }
}

// FIX (Task 10 C4): always issue a fresh CSRF token on get_session. The previous
// "return null when one exists" approach locked out users who restarted their
// browser (the in-memory token was lost, the server returned null → no token →
// all mutations fail with 403). The multi-tab limitation (each tab's get_session
// invalidates the other's token) is accepted as a known trade-off for MVP. Phase 8
// can add a csrf_tokens table (one row per token) to fix this properly.
$csrfToken = issue_csrf_token((int) $row['session_id']);

// Build response (strip internal fields)
$user = [
    'id' => (int) $row['id'],
    'username' => $row['username'],
    'email' => $row['email'],
    'role' => $row['role'],
    'momo_number' => $row['momo_number'],
    'momo_network' => $row['momo_network'],
    'ghana_post_gps' => $row['ghana_post_gps'],
    'store_slug' => $row['store_slug'],
    'subaccount_code' => $row['subaccount_code'],
    'subaccount_pending' => (bool) $row['subaccount_pending'],
    'kyc_status' => $row['kyc_status'],
    'subscription_cycle' => $row['subscription_cycle'],
    'subscription_expiry' => $row['subscription_expiry'],
    'active' => (bool) $row['active'],
    'payouts_paused_at' => $row['payouts_paused_at'],
];

// Surface subscription_expired as a 403 with a distinct error so the SPA can
// route to #/renew (Phase 6 will enforce — Phase 2 still lets users through).
$subscriptionExpired = false;
if ($user['subscription_expiry'] !== null && $user['subscription_expiry'] < date('Y-m-d')) {
    $subscriptionExpired = true;
}

http_response_code(200);
echo json_encode([
    'user' => $user,
    'csrf_token' => $csrfToken,
    'subscription_expired' => $subscriptionExpired,
]);
