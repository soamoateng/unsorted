<?php
declare(strict_types=1);

/**
 * api/endpoints/auth/logout.php
 * Delete the auth_sessions row for the current cookie and clear the cookie.
 *
 * Requires a valid CSRF token (mutation endpoint).
 */

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../config/cors.php';
require_once __DIR__ . '/../../config/env.php';
require_once __DIR__ . '/../../config/csrf.php';
require_once __DIR__ . '/../../middleware/auth.php';

header('Content-Type: application/json');

// Accept POST or DELETE (client uses api.del which sends DELETE; some callers may use POST).
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
if (!in_array($method, ['POST', 'DELETE'], true)) {
    http_response_code(405);
    echo json_encode(['error' => 'method_not_allowed']);
    exit;
}

try {
    Env::load(__DIR__ . '/../../config/.env');
} catch (Throwable $e) {
    http_response_code(503);
    echo json_encode(['error' => 'server_misconfiguration']);
    exit;
}

$cookie = $_COOKIE['esekiosk_session'] ?? '';
if ($cookie === '') {
    http_response_code(200);
    echo json_encode(['ok' => true, 'already_logged_out' => true]);
    exit;
}

// FIX (Task 10 M2): clear the cookie FIRST, before the CSRF check.
// If require_csrf fails (e.g., the SPA lost its CSRF token after a browser restart),
// it calls exit → the cookie-clearing code below never runs → the user is trapped
// in a logged-in state they can't escape. By clearing the cookie first, we ensure
// the user is always logged out client-side, even if the server-side session row
// lingers until its TTL.
$isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
setcookie('esekiosk_session', '', [
    'expires' => time() - 3600,
    'path' => '/',
    'secure' => $isHttps,
    'httponly' => true,
    'samesite' => 'Lax',
]);

$sessionId = find_session_id_for_current_cookie();
$pdo = db();
try {
    if ($sessionId > 0) {
        require_csrf($sessionId);
        $del = $pdo->prepare('DELETE FROM auth_sessions WHERE id = ?');
        $del->execute([$sessionId]);
    }
} catch (PDOException $e) {
    error_log('[logout] failed: ' . $e->getMessage());
    // Don't leak; we already cleared the cookie above.
}

http_response_code(200);
echo json_encode(['ok' => true]);
