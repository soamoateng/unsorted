<?php
declare(strict_types=1);

/**
 * api/endpoints/auth/signup.php
 * Phase 2 signup: validate + whitelist + hash password + save Ghana Card image
 * + enqueue KYC review + call Paystack transaction/initialize.
 *
 * Security:
 *   - Whitelisted fields only. The PRD explicitly ignores `role`/`is_admin` sent
 *     by the client to prevent privilege escalation — we accept `role` but ONLY
 *     `merchant` or `reseller` (admin is auto-rejected by sanitize.php).
 *   - password_hash(PASSWORD_DEFAULT) = bcrypt currently, will auto-upgrade to
 *     Argon2id when PHP is built with libsodium.
 *   - Ghana Card image saved with random_bytes(8) filename + finfo_file real-MIME check.
 *   - Paystack transaction/initialize call uses server-to-server cURL with the secret key.
 *
 * Flow:
 *   1. Sanitize + validate all inputs.
 *   2. INSERT into users with active=0, kyc_status='pending'.
 *   3. Save Ghana Card image to /uploads/ghana_cards/.
 *   4. INSERT into kyc_reviews (status='pending').
 *   5. Generate a Paystack reference (esekiosk_sub_<userid>_<hex>).
 *   6. Call Paystack transaction/initialize with the subscription fee for the chosen cycle.
 *   7. Return {access_code, paystack_reference} to the frontend.
 *
 * The user is NOT yet active. The webhook activates them after Paystack confirms payment.
 */

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../config/cors.php';
require_once __DIR__ . '/../../config/env.php';
require_once __DIR__ . '/../../config/paystack.php';
require_once __DIR__ . '/../../config/momo_helper.php';
require_once __DIR__ . '/../../middleware/sanitize.php';

header('Content-Type: application/json');

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'method_not_allowed']);
    exit;
}

// --- Parse input (multipart/form-data) ---
// FIX (Task 10 C1): use sanitize_username (regex allowlist, no HTML encoding) for the
// DB-bound username. Was sanitize_string which HTML-encodes → login comparisons fail.
$username       = sanitize_username($_POST['username'] ?? '');
$email          = sanitize_email($_POST['email'] ?? '');
$password       = $_POST['password'] ?? '';
$momoNumber     = sanitize_phone($_POST['momo_number'] ?? '');
$momoNetwork    = sanitize_momo_network($_POST['momo_network'] ?? '');
$role           = sanitize_role($_POST['role'] ?? '');
$cycle          = sanitize_cycle($_POST['subscription_cycle'] ?? '');
$gps            = $role === 'merchant' ? sanitize_gps($_POST['ghana_post_gps'] ?? '') : null;

// --- Validate ---
$errors = [];
if ($username === null) $errors[] = 'username';  // FIX: sanitize_username returns null on invalid
if ($email === null) $errors[] = 'email';
if (strlen($password) < 8) $errors[] = 'password';
if ($momoNumber === null) $errors[] = 'momo_number';
if ($momoNetwork === null) $errors[] = 'momo_network';
if ($role === null) $errors[] = 'role';
if ($cycle === null) $errors[] = 'subscription_cycle';
if ($role === 'merchant' && $gps === null) $errors[] = 'ghana_post_gps';
// Reseller cycle must be yearly per PRD
if ($role === 'reseller' && $cycle !== 'yearly') $errors[] = 'reseller_cycle_yearly_only';

// Ghana Card file
$kycFile = $_FILES['kyc_file'] ?? null;
if (!$kycFile || $kycFile['error'] !== UPLOAD_ERR_OK) {
    $errors[] = 'kyc_file';
} else {
    // Real MIME check via finfo (don't trust the browser's Content-Type)
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $realMime = finfo_file($finfo, $kycFile['tmp_name']);
    finfo_close($finfo);
    if (!in_array($realMime, ['image/jpeg', 'image/png'], true)) {
        $errors[] = 'kyc_file_type';
    }
    if ($kycFile['size'] > 4 * 1024 * 1024) {
        $errors[] = 'kyc_file_size';
    }
}

if ($errors) {
    http_response_code(400);
    echo json_encode(['error' => 'validation_failed', 'fields' => $errors]);
    exit;
}

try {
    Env::load(__DIR__ . '/../../config/.env');
} catch (Throwable $e) {
    http_response_code(503);
    echo json_encode(['error' => 'server_misconfiguration']);
    exit;
}

$pdo = db();

// --- Uniqueness check (username + email) ---
try {
    $stmt = $pdo->prepare('SELECT id FROM users WHERE username = ? OR email = ? LIMIT 1');
    $stmt->execute([$username, $email]);
    if ($stmt->fetch()) {
        http_response_code(409);
        echo json_encode(['error' => 'username_or_email_taken']);
        exit;
    }
} catch (PDOException $e) {
    error_log('[signup] uniqueness check failed: ' . $e->getMessage());
    http_response_code(503);
    echo json_encode(['error' => 'database_unavailable']);
    exit;
}

// --- Generate store slug (auto-readable) ---
$slugBase = preg_replace('/[^a-z0-9]+/', '-', strtolower($username));
$slug = $slugBase . '-' . bin2hex(random_bytes(2)); // e.g. kwame-3f2a
// Ensure uniqueness
$stmt = $pdo->prepare('SELECT id FROM users WHERE store_slug = ?');
$stmt->execute([$slug]);
while ($stmt->fetch()) {
    $slug = $slugBase . '-' . bin2hex(random_bytes(2));
    $stmt->execute([$slug]);
}

// --- Look up subscription fee from app_settings (BEFORE the user insert so we can bail early) ---
$settingKey = $role === 'merchant'
    ? "merchant_{$cycle}_fee_pesewas"
    : "reseller_yearly_fee_pesewas";
try {
    $stmt = $pdo->prepare('SELECT setting_value FROM app_settings WHERE setting_key = ?');
    $stmt->execute([$settingKey]);
    $feePesewas = (int) $stmt->fetchColumn();
} catch (PDOException $e) {
    $feePesewas = 0;
}
if ($feePesewas <= 0) {
    error_log('[signup] missing app_settings row for ' . $settingKey);
    http_response_code(503);
    echo json_encode(['error' => 'pricing_not_configured']);
    exit;
}

// --- Generate Paystack reference (needed for the placeholder order insert) ---
$paystackRef = 'esekiosk_sub_' . bin2hex(random_bytes(8));
$callbackUrl = Env::get('APP_BASE_URL', 'https://esekiosk.com') . '/#/welcome';

// --- Insert user + placeholder order in one transaction (CRITICAL FIX) ---
// Previously the placeholder order insert was non-fatal and outside the transaction.
// If it failed, the webhook later couldn't find the order → user paid but never activated.
$passwordHash = password_hash($password, PASSWORD_DEFAULT);
try {
    $pdo->beginTransaction();
    $stmt = $pdo->prepare(
        'INSERT INTO users
         (username, email, password_hash, role, momo_number, momo_network, ghana_post_gps,
          store_slug, kyc_status, subscription_cycle, active, subaccount_pending)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, 0)'
    );
    $stmt->execute([
        $username, $email, $passwordHash, $role, $momoNumber, $momoNetwork,
        $gps, $slug, 'pending', $cycle,
    ]);
    $userId = (int) $pdo->lastInsertId();

    // Insert placeholder order (fatal on failure — was non-fatal before)
    $stmt = $pdo->prepare(
        'INSERT INTO orders
         (store_id, customer_name, customer_phone, delivery_gps,
          subtotal_pesewas, delivery_fee_pesewas, total_paid_pesewas, currency,
          paystack_reference, status)
         VALUES (?, ?, ?, ?, ?, 0, ?, ?, ?, ?)'
    );
    $stmt->execute([
        $userId, $username, $momoNumber, $gps ?? '',
        $feePesewas, $feePesewas, 'GHS', $paystackRef, 'pending',
    ]);
    $orderId = (int) $pdo->lastInsertId();

    $pdo->commit();
} catch (PDOException $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    // Distinguish unique-constraint violations (username/email/slug collision) from real errors
    if ($e->getCode() === '23000' || str_contains($e->getMessage(), 'Duplicate')) {
        http_response_code(409);
        echo json_encode(['error' => 'username_or_email_taken']);
        exit;
    }
    error_log('[signup] user+order insert failed: ' . $e->getMessage());
    http_response_code(503);
    echo json_encode(['error' => 'database_unavailable']);
    exit;
}

// --- Save Ghana Card image ---
$uploadDir = __DIR__ . '/../../uploads/ghana_cards/';
if (!is_dir($uploadDir)) {
    @mkdir($uploadDir, 0755, true);
}
// FIX: reuse a single finfo resource (was opened twice previously — leak)
$finfo = finfo_open(FILEINFO_MIME_TYPE);
$realMime = $finfo ? finfo_file($finfo, $kycFile['tmp_name']) : 'image/jpeg';
finfo_close($finfo);
$imageExt = str_starts_with($realMime, 'image/png') ? 'png' : 'jpg';
$imageName = 'gc_' . bin2hex(random_bytes(8)) . '.' . $imageExt;
$imagePath = $uploadDir . $imageName;
if (!move_uploaded_file($kycFile['tmp_name'], $imagePath)) {
    error_log('[signup] failed to save Ghana Card image for user ' . $userId);
} else {
    try {
        $stmt = $pdo->prepare(
            'INSERT INTO kyc_reviews (user_id, image_path, status) VALUES (?, ?, ?)'
        );
        $stmt->execute([$userId, 'uploads/ghana_cards/' . $imageName, 'pending']);
    } catch (PDOException $e) {
        error_log('[signup] kyc_reviews insert failed: ' . $e->getMessage());
    }
}

// --- Call Paystack transaction/initialize ---
$payload = [
    'email' => $email,
    'amount' => $feePesewas,
    'currency' => 'GHS',
    'reference' => $paystackRef,
    'callback_url' => $callbackUrl,
    'metadata' => [
        'user_id' => $userId,
        'subscription_cycle' => $cycle,
        'role' => $role,
        'kind' => 'subscription',
    ],
];

$ch = curl_init('https://api.paystack.co/transaction/initialize');
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => json_encode($payload),
    CURLOPT_HTTPHEADER => [
        'Authorization: Bearer ' . paystack_secret_key(),
        'Content-Type: application/json',
        'Cache-Control: no-cache',
    ],
    CURLOPT_TIMEOUT => 15,
]);
$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curlErr = curl_error($ch);
curl_close($ch);

if ($response === false || $httpCode < 200 || $httpCode >= 300) {
    // FIX: do NOT echo $curlErr to the client (may leak internal host/network info)
    error_log('[signup] Paystack initialize failed: HTTP ' . $httpCode . ' err=' . $curlErr);
    http_response_code(502);
    echo json_encode(['error' => 'paystack_init_failed']);
    exit;
}

$ps = json_decode($response, true);
if (!isset($ps['data']['access_code'])) {
    error_log('[signup] Paystack response missing access_code: ' . $response);
    http_response_code(502);
    echo json_encode(['error' => 'paystack_response_invalid']);
    exit;
}

$accessCode = $ps['data']['access_code'];

// --- Return access_code to frontend ---
http_response_code(200);
echo json_encode([
    'access_code' => $accessCode,
    'paystack_reference' => $paystackRef,
    'user_id' => $userId,
    'order_id' => $orderId,
]);
