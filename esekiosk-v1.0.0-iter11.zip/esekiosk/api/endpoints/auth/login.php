<?php
declare(strict_types=1);

/**
 * api/endpoints/auth/login.php
 * Verify credentials and issue a session cookie + auth_sessions row.
 *
 * Security:
 *   - password_verify (timing-safe) for the hash check.
 *   - Session token = 32 random bytes (64 hex chars). Cookie = raw; DB = SHA-256 hash.
 *   - Cookie attributes: HttpOnly, Secure (in prod), SameSite=Lax, Path=/.
 *   - Issued CSRF token returned in the JSON response so the frontend can attach it
 *     to all future mutations via the X-CSRF-Token header.
 */

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../config/cors.php';
require_once __DIR__ . '/../../config/env.php';
require_once __DIR__ . '/../../config/csrf.php';

header('Content-Type: application/json');

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'method_not_allowed']);
    exit;
}

$body = json_decode(file_get_contents('php://input') ?: '', true);
if (!is_array($body)) {
    http_response_code(400);
    echo json_encode(['error' => 'invalid_json']);
    exit;
}

$identifier = trim($body['username'] ?? '');
$password = (string)($body['password'] ?? '');
if ($identifier === '' || $password === '') {
    http_response_code(400);
    echo json_encode(['error' => 'missing_credentials']);
    exit;
}

try {
    Env::load(__DIR__ . '/../../config/.env');
} catch (Throwable $e) {
    http_response_code(503);
    echo json_encode(['error' => 'server_misconfiguration']);
    exit;
}

$pdo = db();
try {
    // Allow login by username OR email
    $stmt = $pdo->prepare(
        'SELECT id, username, email, password_hash, role, momo_number, momo_network,
                ghana_post_gps, store_slug, subaccount_code, subaccount_pending,
                kyc_status, subscription_cycle, subscription_expiry, active, payouts_paused_at
         FROM users
         WHERE username = ? OR email = ?
         LIMIT 1'
    );
    $stmt->execute([$identifier, strtolower($identifier)]);
    $user = $stmt->fetch();
} catch (PDOException $e) {
    error_log('[login] user lookup failed: ' . $e->getMessage());
    http_response_code(503);
    echo json_encode(['error' => 'database_unavailable']);
    exit;
}

// Always do a password_verify (even if user not found) to mitigate timing attacks.
// FIX: dummy hash uses the SAME cost as real hashes (cost 10) so timing doesn't reveal
// whether the username exists. Was cost 04 — defeated the mitigation.
// FIX: this is a valid 60-char bcrypt hash. password_verify will run the full
// cost-10 bcrypt computation (~50-100ms) regardless of whether the user exists.
$dummyHash = '$2y$10$YsX5P/fVY8qXfVY8qXfVYuW2qXfVY8qXfVY8qXfVY8qXfVY8qXfVY';
$hashToCheck = $user ? $user['password_hash'] : $dummyHash;
$ok = password_verify($password, $hashToCheck);

if (!$user || !$ok) {
    // Generic error — don't leak whether the username exists
    http_response_code(401);
    echo json_encode(['error' => 'invalid_credentials']);
    exit;
}

// Create session
$rawToken = bin2hex(random_bytes(32));
$tokenHash = hash('sha256', $rawToken);
$ttlHours = (int) (Env::get('SESSION_TTL_HOURS', '720'));
$expiresAt = date('Y-m-d H:i:s', time() + $ttlHours * 3600);
$ip = $_SERVER['REMOTE_ADDR'] ?? null;
$ua = $_SERVER['HTTP_USER_AGENT'] ?? null;

try {
    $stmt = $pdo->prepare(
        'INSERT INTO auth_sessions (user_id, token_hash, expires_at, ip_address, user_agent)
         VALUES (?, ?, ?, ?, ?)'
    );
    $stmt->execute([$user['id'], $tokenHash, $expiresAt, $ip, $ua]);
    $sessionId = (int) $pdo->lastInsertId();
} catch (PDOException $e) {
    error_log('[login] session insert failed: ' . $e->getMessage());
    http_response_code(503);
    echo json_encode(['error' => 'database_unavailable']);
    exit;
}

// Issue CSRF token (uses dedicated csrf_token_hash column — Phase 7 fix)
$csrfToken = issue_csrf_token($sessionId);

// Issue cookie
// FIX: only trust X-Forwarded-Proto when APP_TRUSTED_PROXY is configured and REMOTE_ADDR matches.
// An attacker over HTTP could send X-Forwarded-Proto: https → cookie gets Secure flag →
// browser refuses to send it over HTTP → login appears to fail.
$isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
$trustedProxy = Env::get('APP_TRUSTED_PROXY', '');
if (!$isHttps && $trustedProxy && ($_SERVER['REMOTE_ADDR'] ?? '') === $trustedProxy) {
    $isHttps = ($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https';
}
setcookie('esekiosk_session', $rawToken, [
    'expires' => time() + $ttlHours * 3600,
    'path' => '/',
    'secure' => $isHttps,
    'httponly' => true,
    'samesite' => 'Lax',
]);

// Strip sensitive fields from the response
unset($user['password_hash']);
$user['active'] = (int) $user['active'];

// FIX: return subscription_expired flag so the SPA can route to #/renew (was missing).
$subscriptionExpired = $user['role'] !== 'admin'
    && $user['subscription_expiry'] !== null
    && $user['subscription_expiry'] < date('Y-m-d');

http_response_code(200);
echo json_encode([
    'user' => $user,
    'csrf_token' => $csrfToken,
    'expires_at' => $expiresAt,
    'subscription_expired' => $subscriptionExpired,
]);
