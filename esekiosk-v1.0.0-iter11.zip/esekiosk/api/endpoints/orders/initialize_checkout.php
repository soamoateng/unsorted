<?php
declare(strict_types=1);

/**
 * api/endpoints/orders/initialize_checkout.php
 * Phase 4: customer checkout. Takes the cart array + delivery details, verifies stock
 * with row-locking, computes split payments in pesewas, calls Paystack transaction/initialize
 * with the subaccount split configuration, returns the access_code.
 *
 * Security:
 *   - Public endpoint (customers don't need an account — they're guests).
 *   - CSRF NOT required (no session to protect — the order is created from scratch).
 *   - SELECT ... FOR UPDATE inside a transaction to lock product rows (prevents race
 *     conditions where two customers check out the last item simultaneously).
 *   - All money is pesewas (integers) — no floating-point.
 *   - MAX_SPLITS = 5 (self-imposed, NOT a Paystack limit — see api/config/paystack.php).
 *   - Courier is a proper Paystack subaccount (per Phase 1 stress test flag 7).
 *   - If payouts_paused_at is set on a merchant/reseller, their split routes to
 *     Esekiosk's primary account instead of their subaccount (per Phase 1 stress test flag 11).
 *
 * Flow:
 *   1. Parse cart + delivery details from JSON body.
 *   2. Start transaction. SELECT ... FOR UPDATE on product rows.
 *   3. Verify live stock for every item; reject with {failed_product_id} if short.
 *   4. Compute splits per merchant/reseller in pesewas.
 *   5. Deduct outstanding debts from merchant_ledger (partial recovery).
 *   6. Build the subaccount split array (cap at MAX_SPLITS).
 *   7. Insert orders row (status='pending') + order_items rows (snapshots of wholesale/retail).
 *   8. Call Paystack transaction/initialize with the split config.
 *   9. Return {access_code, paystack_reference} to the frontend.
 */

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../config/cors.php';
require_once __DIR__ . '/../../config/env.php';
require_once __DIR__ . '/../../config/paystack.php';
require_once __DIR__ . '/../../middleware/sanitize.php';

header('Content-Type: application/json');

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'method_not_allowed']);
    exit;
}

try {
    Env::load(__DIR__ . '/../../config/.env');
} catch (Throwable $e) {
    http_response_code(503);
    echo json_encode(['error' => 'server_misconfiguration']);
    exit;
}

$body = json_decode(file_get_contents('php://input') ?: '', true);
if (!is_array($body)) {
    http_response_code(400);
    echo json_encode(['error' => 'invalid_json']);
    exit;
}

// --- Parse + validate input ---
$cart = $body['cart'] ?? [];           // [{ product_id, quantity }, ...]
$customerName = sanitize_text($body['customer_name'] ?? '');
$customerPhone = sanitize_phone($body['customer_phone'] ?? '');
$deliveryGps = sanitize_gps($body['delivery_gps'] ?? '');
$deliveryStreet = sanitize_text($body['delivery_street'] ?? '');
$deliveryInstructions = sanitize_text($body['delivery_instructions'] ?? '');
// FIX: collect customer email (was hardcoded 'customer@example.com').
$customerEmail = sanitize_email($body['customer_email'] ?? '') ?? 'guest@esekiosk.com';

$errors = [];
if (!is_array($cart) || count($cart) === 0) $errors[] = 'cart_empty';
if (mb_strlen($customerName) < 2) $errors[] = 'customer_name';
if ($customerPhone === null) $errors[] = 'customer_phone';
if ($deliveryGps === null) $errors[] = 'delivery_gps';

if ($errors) {
    http_response_code(400);
    echo json_encode(['error' => 'validation_failed', 'fields' => $errors]);
    exit;
}

$pdo = db();

// --- Validate cart items and collect product IDs ---
$items = [];
foreach ($cart as $entry) {
    $pid = (int) ($entry['product_id'] ?? 0);
    $qty = (int) ($entry['quantity'] ?? 0);
    if ($pid <= 0 || $qty <= 0 || $qty > 99) {
        http_response_code(400);
        echo json_encode(['error' => 'invalid_cart_item', 'product_id' => $pid]);
        exit;
    }
    $items[] = ['product_id' => $pid, 'quantity' => $qty];
}

try {
    $pdo->beginTransaction();

    // --- Lock product rows with SELECT ... FOR UPDATE ---
    // FIX: also lock parent rows (for reseller clones) to prevent concurrent checkouts
    // from buying the same parent stock simultaneously.
    $productIds = array_column($items, 'product_id');
    $placeholders = implode(',', array_fill(0, count($productIds), '?'));
    $stmt = $pdo->prepare(
        "SELECT p.id, p.name, p.owner_user_id, p.parent_product_id,
                p.wholesale_price_pesewas, p.retail_price_pesewas,
                p.stock AS own_stock,
                parent.stock AS parent_stock,
                parent.id AS parent_id,
                parent.owner_user_id AS merchant_id,
                u.username AS owner_username, u.role AS owner_role,
                u.subaccount_code, u.payouts_paused_at,
                merchant.subaccount_code AS merchant_subaccount_code,
                merchant.payouts_paused_at AS merchant_payouts_paused_at
         FROM products p
         LEFT JOIN products parent ON parent.id = p.parent_product_id
         LEFT JOIN users u ON u.id = p.owner_user_id
         LEFT JOIN users merchant ON merchant.id = parent.owner_user_id
         WHERE p.id IN ($placeholders)
         FOR UPDATE"
    );
    $stmt->execute($productIds);
    $rows = $stmt->fetchAll();

    if (count($rows) !== count($productIds)) {
        $pdo->rollBack();
        http_response_code(400);
        echo json_encode(['error' => 'some_products_not_found']);
        exit;
    }

    // --- Verify stock for every item ---
    $subtotalPesewas = 0;
    $orderItems = [];          // snapshot for order_items insert
    $splitsByUserId = [];      // user_id => { subaccount_code, amount_pesewas, is_reseller }

    foreach ($items as $item) {
        $product = null;
        foreach ($rows as $r) {
            if ((int) $r['id'] === $item['product_id']) { $product = $r; break; }
        }
        if (!$product) {
            $pdo->rollBack();
            http_response_code(400);
            echo json_encode(['error' => 'product_not_found', 'failed_product_id' => $item['product_id']]);
            exit;
        }

        // Resolve live stock: reseller clones use parent's stock; merchant originals use own.
        $isClone = $product['parent_product_id'] !== null;
        $liveStock = $isClone ? (int) $product['parent_stock'] : (int) $product['own_stock'];
        if ($liveStock < $item['quantity']) {
            $pdo->rollBack();
            http_response_code(409);
            echo json_encode([
                'error' => 'insufficient_stock',
                'failed_product_id' => $item['product_id'],
                'available' => $liveStock,
                'requested' => $item['quantity'],
            ]);
            exit;
        }

        $wholesale = (int) $product['wholesale_price_pesewas'];
        $retail = (int) $product['retail_price_pesewas'];
        $lineTotal = $retail * $item['quantity'];
        $subtotalPesewas += $lineTotal;

        // Determine who gets paid:
        //   - If it's a clone: merchant gets wholesale * qty, reseller gets (retail - wholesale) * qty
        //   - If it's a direct merchant sale: merchant gets retail * qty
        $merchantId = $isClone ? (int) $product['merchant_id'] : (int) $product['owner_user_id'];
        $merchantSubaccount = $isClone ? $product['merchant_subaccount_code'] : $product['subaccount_code'];
        $merchantPaused = $isClone ? $product['merchant_payouts_paused_at'] : $product['payouts_paused_at'];

        $merchantAmount = $wholesale * $item['quantity'];
        if (!$isClone) {
            $merchantAmount = $retail * $item['quantity']; // direct sale: merchant gets full retail
        }

        // Route to Esekiosk primary if payouts are paused (don't add subaccount_code)
        $merchantSubaccountForSplit = $merchantPaused ? null : $merchantSubaccount;

        // Accumulate per-user splits (merge multiple items from the same merchant)
        if (!isset($splitsByUserId[$merchantId])) {
            $splitsByUserId[$merchantId] = [
                'subaccount_code' => $merchantSubaccountForSplit,
                'amount_pesewas' => 0,
                'is_reseller' => false,
            ];
        }
        $splitsByUserId[$merchantId]['amount_pesewas'] += $merchantAmount;
        $splitsByUserId[$merchantId]['subaccount_code'] = $merchantSubaccountForSplit; // last write wins (same merchant)

        if ($isClone) {
            $resellerId = (int) $product['owner_user_id'];
            $resellerSubaccount = $product['subaccount_code'];
            $resellerPaused = $product['payouts_paused_at'];
            $resellerAmount = ($retail - $wholesale) * $item['quantity'];
            $resellerSubaccountForSplit = $resellerPaused ? null : $resellerSubaccount;

            if (!isset($splitsByUserId[$resellerId])) {
                $splitsByUserId[$resellerId] = [
                    'subaccount_code' => $resellerSubaccountForSplit,
                    'amount_pesewas' => 0,
                    'is_reseller' => true,
                ];
            }
            $splitsByUserId[$resellerId]['amount_pesewas'] += $resellerAmount;
            $splitsByUserId[$resellerId]['subaccount_code'] = $resellerSubaccountForSplit;
        }

        // Snapshot for order_items (captures wholesale + retail at purchase time)
        $orderItems[] = [
            'product_id' => $item['product_id'],
            'parent_product_id' => $isClone ? (int) $product['parent_product_id'] : null,
            'quantity' => $item['quantity'],
            'retail_price_pesewas' => $retail,
            'wholesale_price_pesewas' => $wholesale,
            'fulfilling_merchant_id' => $merchantId,
            'reseller_id' => $isClone ? (int) $product['owner_user_id'] : null,
        ];
    }

    // --- Deduct outstanding debts from merchant_ledger ---
    // FIX: lock ledger rows with FOR UPDATE to prevent lost updates from concurrent checkouts.
    // Use atomic UPDATE ... SET recovered_amount = recovered_amount + ? to avoid race.
    foreach ($splitsByUserId as $userId => &$split) {
        try {
            // Lock outstanding debt rows for this user
            $debtStmt = $pdo->prepare(
                'SELECT id, amount_pesewas, recovered_amount_pesewas
                 FROM merchant_ledger
                 WHERE owing_user_id = ? AND recovered_amount_pesewas < amount_pesewas
                 ORDER BY created_at ASC
                 FOR UPDATE'
            );
            $debtStmt->execute([$userId]);
            $debts = $debtStmt->fetchAll();
        } catch (PDOException $e) {
            $debts = [];
        }

        $remainingSplit = $split['amount_pesewas'];
        foreach ($debts as $debt) {
            if ($remainingSplit <= 0) break;
            $outstanding = (int) $debt['amount_pesewas'] - (int) $debt['recovered_amount_pesewas'];
            $recovery = min($remainingSplit, $outstanding);
            $remainingSplit -= $recovery;

            // FIX (Task 10 C6): MySQL evaluates SET clauses left-to-right, so the
            // second clause sees the NEW value of the first. We must evaluate
            // recovered_at BEFORE updating recovered_amount_pesewas. Swap the order
            // so the CASE reads the OLD recovered_amount_pesewas (before increment).
            $upd = $pdo->prepare(
                'UPDATE merchant_ledger
                 SET recovered_at = CASE
                       WHEN (recovered_amount_pesewas + ?) >= amount_pesewas THEN NOW()
                       ELSE recovered_at
                     END,
                     recovered_amount_pesewas = recovered_amount_pesewas + ?
                 WHERE id = ?'
            );
            $upd->execute([$recovery, $recovery, $debt['id']]);
        }
        $split['amount_pesewas'] = $remainingSplit;
    }
    unset($split);

    // --- Delivery fee (flat) → courier subaccount ---
    $deliveryFee = 2000; // ₵20 flat default
    try {
        $stmt = $pdo->prepare("SELECT setting_value FROM app_settings WHERE setting_key = 'delivery_fee_pesewas'");
        $stmt->execute();
        // FIX (Task 10 M4): Elvis ?: treats 0 as falsy, so delivery_fee=0 (free shipping)
        // was overridden by the default 2000. Use explicit null/false check instead.
        $val = $stmt->fetchColumn();
        if ($val !== false && $val !== null) {
            $deliveryFee = (int) $val;
        }
    } catch (PDOException $e) { /* use default */ }

    // --- Build Paystack split array ---
    $paystackSplits = [];
    foreach ($splitsByUserId as $userId => $split) {
        if ($split['amount_pesewas'] <= 0) continue;
        if (!$split['subaccount_code']) continue; // payouts paused → remainder goes to primary
        $paystackSplits[] = [
            'subaccount' => $split['subaccount_code'],
            'share_amount' => $split['amount_pesewas'],
        ];
    }

    // Courier subaccount (Phase 6 makes this a DB row; for now, read from env or skip)
    $courierSubaccount = Env::get('PAYSTACK_COURIER_SUBACCOUNT', '');
    if ($courierSubaccount && $deliveryFee > 0) {
        $paystackSplits[] = [
            'subaccount' => $courierSubaccount,
            'share_amount' => $deliveryFee,
        ];
    }

    // Enforce MAX_SPLITS cap (self-imposed, NOT a Paystack limit)
    if (count($paystackSplits) > MAX_SPLITS) {
        $pdo->rollBack();
        http_response_code(400);
        echo json_encode([
            'error' => 'too_many_splits',
            'count' => count($paystackSplits),
            'max' => MAX_SPLITS,
        ]);
        exit;
    }

    $totalPaid = $subtotalPesewas + $deliveryFee;

    // --- Insert orders row ---
    $paystackRef = 'esekiosk_ord_' . bin2hex(random_bytes(6));

    // FIX: the dead ternary (both branches identical) is removed. Use the first
    // item's owner as the store_id — for mixed carts this is a known limitation
    // (multi-store attribution is a Phase 8 schema concern; for MVP most carts
    // are single-store because reseller clones share the reseller's store_id).
    $firstProduct = $rows[0];
    $storeId = (int) $firstProduct['owner_user_id'];

    $stmt = $pdo->prepare(
        'INSERT INTO orders
         (store_id, customer_name, customer_phone, delivery_gps, delivery_street,
          delivery_instructions, subtotal_pesewas, delivery_fee_pesewas,
          total_paid_pesewas, currency, paystack_reference, status)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
    );
    $stmt->execute([
        $storeId, $customerName, $customerPhone, $deliveryGps, $deliveryStreet,
        $deliveryInstructions, $subtotalPesewas, $deliveryFee,
        $totalPaid, 'GHS', $paystackRef, 'pending',
    ]);
    $orderId = (int) $pdo->lastInsertId();

    // --- Insert order_items rows (snapshots) ---
    $itemStmt = $pdo->prepare(
        'INSERT INTO order_items
         (order_id, product_id, parent_product_id, quantity,
          retail_price_pesewas, wholesale_price_pesewas,
          fulfilling_merchant_id, reseller_id, status)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'
    );
    foreach ($orderItems as $oi) {
        $itemStmt->execute([
            $orderId, $oi['product_id'], $oi['parent_product_id'], $oi['quantity'],
            $oi['retail_price_pesewas'], $oi['wholesale_price_pesewas'],
            $oi['fulfilling_merchant_id'], $oi['reseller_id'], 'pending',
        ]);
    }

    // FIX: decrement stock atomically inside the transaction (was missing entirely).
    // For reseller clones, decrement the parent's stock (the merchant's original).
    // For merchant originals, decrement the product's own stock.
    // Stock is only decremented on checkout init — the webhook does NOT re-decrement
    // (so a failed payment leaves stock intact, which is the correct business rule:
    // stock is "reserved" at checkout init and only consumed if the order is paid).
    // NOTE: this reserves stock at init; if the customer never pays, the stock stays
    // decremented. A future Phase 8 cron can restore stock for stale 'pending' orders.
    foreach ($items as $item) {
        $pid = $item['product_id'];
        $qty = $item['quantity'];
        // Find the product row (already locked above)
        $product = null;
        foreach ($rows as $r) {
            if ((int) $r['id'] === $pid) { $product = $r; break; }
        }
        if (!$product) continue;

        $targetId = $product['parent_product_id'] !== null
            ? (int) $product['parent_id']
            : (int) $product['id'];
        $dec = $pdo->prepare(
            'UPDATE products SET stock = GREATEST(0, stock - ?) WHERE id = ?'
        );
        $dec->execute([$qty, $targetId]);
    }

    $pdo->commit();
} catch (PDOException $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    error_log('[initialize_checkout] DB error: ' . $e->getMessage());
    http_response_code(503);
    echo json_encode(['error' => 'database_unavailable']);
    exit;
} catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    error_log('[initialize_checkout] error: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'internal_error']);
    exit;
}

// --- Call Paystack transaction/initialize with split config ---
// FIX: use the real customer email (was hardcoded 'customer@example.com').
// FIX: callback_url points to a public route (was #/dashboard which requires auth).
$payload = [
    'email' => $customerEmail,
    'amount' => $totalPaid,
    'currency' => 'GHS',
    'reference' => $paystackRef,
    'callback_url' => Env::get('APP_BASE_URL', 'https://esekiosk.com') . '/#/welcome',
    'metadata' => [
        'order_id' => $orderId,
        'kind' => 'checkout',
        'customer_name' => $customerName,
        'customer_phone' => $customerPhone,
    ],
];
if (count($paystackSplits) > 0) {
    $payload['subaccounts'] = $paystackSplits;
}

$ch = curl_init('https://api.paystack.co/transaction/initialize');
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => json_encode($payload),
    CURLOPT_HTTPHEADER => [
        'Authorization: Bearer ' . paystack_secret_key(),
        'Content-Type: application/json',
    ],
    CURLOPT_TIMEOUT => 15,
]);
$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curlErr = curl_error($ch);
curl_close($ch);

if ($response === false || $httpCode < 200 || $httpCode >= 300) {
    // FIX (Task 10 C5): on Paystack failure, restore stock + cancel the order.
    // Previously stock was decremented in the committed transaction but never restored
    // on Paystack failure → permanent inventory leak.
    error_log('[initialize_checkout] Paystack init failed: HTTP ' . $httpCode . ' err=' . $curlErr);
    try {
        // Restore stock for each item
        foreach ($items as $item) {
            $pid = $item['product_id'];
            $qty = $item['quantity'];
            $product = null;
            foreach ($rows as $r) {
                if ((int) $r['id'] === $pid) { $product = $r; break; }
            }
            if (!$product) continue;
            $targetId = $product['parent_product_id'] !== null
                ? (int) $product['parent_id']
                : (int) $product['id'];
            $restore = $pdo->prepare('UPDATE products SET stock = stock + ? WHERE id = ?');
            $restore->execute([$qty, $targetId]);
        }
        $cancelStmt = $pdo->prepare("UPDATE orders SET status = 'cancelled' WHERE id = ?");
        $cancelStmt->execute([$orderId]);
    } catch (PDOException $e) {
        error_log('[initialize_checkout] failed to restore stock/cancel: ' . $e->getMessage());
    }
    http_response_code(502);
    echo json_encode(['error' => 'paystack_init_failed']);
    exit;
}

$ps = json_decode($response, true);
if (!isset($ps['data']['access_code'])) {
    error_log('[initialize_checkout] Paystack response missing access_code');
    try {
        foreach ($items as $item) {
            $pid = $item['product_id'];
            $qty = $item['quantity'];
            $product = null;
            foreach ($rows as $r) {
                if ((int) $r['id'] === $pid) { $product = $r; break; }
            }
            if (!$product) continue;
            $targetId = $product['parent_product_id'] !== null
                ? (int) $product['parent_id']
                : (int) $product['id'];
            $restore = $pdo->prepare('UPDATE products SET stock = stock + ? WHERE id = ?');
            $restore->execute([$qty, $targetId]);
        }
        $cancelStmt = $pdo->prepare("UPDATE orders SET status = 'cancelled' WHERE id = ?");
        $cancelStmt->execute([$orderId]);
    } catch (PDOException $e) {
        error_log('[initialize_checkout] failed to restore stock/cancel: ' . $e->getMessage());
    }
    http_response_code(502);
    echo json_encode(['error' => 'paystack_response_invalid']);
    exit;
}

http_response_code(200);
echo json_encode([
    'access_code' => $ps['data']['access_code'],
    'paystack_reference' => $paystackRef,
    'order_id' => $orderId,
    'total_paid_pesewas' => $totalPaid,
    'splits' => $paystackSplits,
]);
