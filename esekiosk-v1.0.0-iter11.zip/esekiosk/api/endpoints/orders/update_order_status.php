<?php
declare(strict_types=1);

/**
 * api/endpoints/orders/update_order_status.php
 * Merchant/reseller updates an item-level status (Pending → Processing → Shipped → Delivered).
 * After every item update, recomputes the parent order.status in the same transaction.
 *
 * Security:
 *   - Auth required. CSRF required.
 *   - IDOR: the merchant can only update items where they are the fulfilling_merchant_id.
 *     The reseller can only update items where they are the reseller_id (they mark as "shipped"
 *     once they've handed off to the courier).
 *   - State machine: only forward transitions allowed.
 */

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../config/cors.php';
require_once __DIR__ . '/../../config/env.php';
require_once __DIR__ . '/../../config/csrf.php';
require_once __DIR__ . '/../../middleware/auth.php';

header('Content-Type: application/json');

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'method_not_allowed']);
    exit;
}

try {
    Env::load(__DIR__ . '/../../config/.env');
} catch (Throwable $e) {
    http_response_code(503);
    echo json_encode(['error' => 'server_misconfiguration']);
    exit;
}

$user = require_auth();
$userId = (int) $user['id'];

// CSRF
$sessionId = find_session_id_for_current_cookie();
if ($sessionId <= 0) {
    http_response_code(401);
    echo json_encode(['error' => 'unauthorized']);
    exit;
}
require_csrf($sessionId);

$body = json_decode(file_get_contents('php://input') ?: '', true);
if (!is_array($body)) {
    http_response_code(400);
    echo json_encode(['error' => 'invalid_json']);
    exit;
}

$itemId = (int) ($body['item_id'] ?? 0);
$newStatus = $body['status'] ?? '';

$VALID = ['pending', 'processing', 'shipped', 'delivered', 'cancelled'];
if ($itemId <= 0 || !in_array($newStatus, $VALID, true)) {
    http_response_code(400);
    echo json_encode(['error' => 'validation_failed']);
    exit;
}

// FIX: initialize $pdo (was missing — every "Mark as …" click crashed)
$pdo = db();

try {
    $pdo->beginTransaction();

    // Look up the item — must belong to this user (IDOR fix)
    // FIX: use FOR UPDATE to lock the row and prevent concurrent status updates
    $stmt = $pdo->prepare(
        'SELECT oi.id, oi.order_id, oi.status, oi.fulfilling_merchant_id, oi.reseller_id
         FROM order_items oi
         WHERE oi.id = ?
         FOR UPDATE'
    );
    $stmt->execute([$itemId]);
    $item = $stmt->fetch();
    if (!$item) {
        $pdo->rollBack();
        http_response_code(404);
        echo json_encode(['error' => 'item_not_found']);
        exit;
    }

    $isMerchant = (int) $item['fulfilling_merchant_id'] === $userId;
    $isReseller = (int) $item['reseller_id'] === $userId;
    if (!$isMerchant && !$isReseller) {
        $pdo->rollBack();
        http_response_code(403);
        echo json_encode(['error' => 'not_your_item']);
        exit;
    }

    // FIX: role gating — resellers can only mark items as 'shipped' (handoff to courier).
    // Merchants can advance through the full fulfillment chain + cancel.
    if ($isReseller && !$isMerchant && !in_array($newStatus, ['shipped', 'cancelled'], true)) {
        $pdo->rollBack();
        http_response_code(403);
        echo json_encode(['error' => 'reseller_can_only_ship_or_cancel']);
        exit;
    }

    // FIX: state machine — single-step forward transitions only.
    // 'cancelled' is terminal; cancellation is allowed from any non-terminal state.
    $currentState = $item['status'];
    $isValid = isValidTransitionServer($currentState, $newStatus);
    if (!$isValid) {
        $pdo->rollBack();
        http_response_code(409);
        echo json_encode(['error' => 'invalid_transition', 'from' => $currentState, 'to' => $newStatus]);
        exit;
    }

    // Update the item status
    $upd = $pdo->prepare('UPDATE order_items SET status = ? WHERE id = ?');
    $upd->execute([$newStatus, $itemId]);

    // Recompute the parent order status
    $orderId = (int) $item['order_id'];
    $stmt = $pdo->prepare('SELECT status FROM order_items WHERE order_id = ?');
    $stmt->execute([$orderId]);
    $itemStatuses = $stmt->fetchAll(PDO::FETCH_COLUMN);

    // FIX: distinguish all-cancelled from all-delivered (was treating all-cancelled as 'delivered').
    $hasInFlight = in_array('pending', $itemStatuses) || in_array('processing', $itemStatuses) || in_array('shipped', $itemStatuses);
    $hasDelivered = in_array('delivered', $itemStatuses);
    $allCancelled = count($itemStatuses) > 0 && !in_array('pending', $itemStatuses)
        && !in_array('processing', $itemStatuses) && !in_array('shipped', $itemStatuses)
        && !in_array('delivered', $itemStatuses)
        && in_array('cancelled', $itemStatuses);
    $allDeliveredOrCancelled = count($itemStatuses) > 0
        && !in_array('pending', $itemStatuses)
        && !in_array('processing', $itemStatuses)
        && !in_array('shipped', $itemStatuses);

    if ($allCancelled) {
        $orderStatus = 'cancelled';
    } elseif ($allDeliveredOrCancelled && $hasDelivered) {
        $orderStatus = 'delivered';
    } elseif ($hasInFlight && $hasDelivered) {
        $orderStatus = 'partially_shipped';
    } else {
        // FIX: 'processing' is NOT in the orders.status enum (which is
        // 'pending','paid','partially_shipped','delivered','cancelled'). Use 'paid'
        // for all "items in motion but none delivered yet" states. The item-level
        // 'processing'/'shipped' statuses are still tracked per-item; the order-level
        // status only distinguishes paid / partially_shipped / delivered / cancelled.
        $orderStatus = 'paid';
    }

    $upd = $pdo->prepare('UPDATE orders SET status = ? WHERE id = ?');
    $upd->execute([$orderStatus, $orderId]);

    $pdo->commit();
    http_response_code(200);
    echo json_encode([
        'ok' => true,
        'item_id' => $itemId,
        'item_status' => $newStatus,
        'order_id' => $orderId,
        'order_status' => $orderStatus,
    ]);
    exit;
} catch (PDOException $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    error_log('[update_order_status] failed: ' . $e->getMessage());
    http_response_code(503);
    echo json_encode(['error' => 'database_unavailable']);
    exit;
}

/**
 * Server-side state machine validation (mirrors js/utils/orderStatus.js isValidTransition).
 * FIX: single-step forward transitions only; cancellation allowed from any non-terminal state.
 */
function isValidTransitionServer(string $from, string $to): bool
{
    if ($from === $to) return false;
    // Cancellation allowed from any non-terminal state
    if ($to === 'cancelled' && $from !== 'delivered' && $from !== 'cancelled') return true;
    // Forward chain: pending → processing → shipped → delivered (single-step only)
    $order = ['pending' => 0, 'processing' => 1, 'shipped' => 2, 'delivered' => 3];
    if (!isset($order[$from]) || !isset($order[$to])) return false;
    return $order[$to] === $order[$from] + 1;
}
