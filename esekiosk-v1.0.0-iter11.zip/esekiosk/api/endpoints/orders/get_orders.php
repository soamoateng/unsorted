<?php
declare(strict_types=1);

/**
 * api/endpoints/orders/get_orders.php
 * Fetch orders for the authenticated merchant/reseller. IDOR-safe — only returns
 * orders where the user is the fulfilling_merchant or the reseller.
 *
 * Returns orders with their item-level statuses so the dashboard can show
 * Pending / Processing / Shipped / Delivered per item.
 */

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../config/cors.php';
require_once __DIR__ . '/../../config/env.php';
require_once __DIR__ . '/../../middleware/auth.php';

header('Content-Type: application/json');

try {
    Env::load(__DIR__ . '/../../config/.env');
} catch (Throwable $e) {
    http_response_code(503);
    echo json_encode(['error' => 'server_misconfiguration']);
    exit;
}

$user = require_auth();
$userId = (int) $user['id'];

$pdo = db();
try {
    // Fetch orders that have at least one item where this user is the merchant or reseller.
    $stmt = $pdo->prepare(
        'SELECT o.id, o.store_id, o.customer_name, o.customer_phone,
                o.delivery_gps, o.delivery_street, o.delivery_instructions,
                o.subtotal_pesewas, o.delivery_fee_pesewas, o.total_paid_pesewas,
                o.paystack_reference, o.status, o.created_at, o.paid_at
         FROM orders o
         WHERE EXISTS (
           SELECT 1 FROM order_items oi
           WHERE oi.order_id = o.id
             AND (oi.fulfilling_merchant_id = ? OR oi.reseller_id = ?)
         )
         ORDER BY o.created_at DESC
         LIMIT 100'
    );
    $stmt->execute([$userId, $userId]);
    $orders = $stmt->fetchAll();

    // Fetch items for these orders — CRITICAL IDOR FIX: filter by user so a merchant
    // does NOT see other merchants' items (wholesale prices, product names) in a multi-merchant order.
    $orderIds = array_column($orders, 'id');
    $items = [];
    if (count($orderIds)) {
        $placeholders = implode(',', array_fill(0, count($orderIds), '?'));
        $stmt = $pdo->prepare(
            "SELECT oi.id, oi.order_id, oi.product_id, oi.parent_product_id,
                    oi.quantity, oi.retail_price_pesewas, oi.wholesale_price_pesewas,
                    oi.fulfilling_merchant_id, oi.reseller_id, oi.status, oi.updated_at,
                    p.name AS product_name, p.image_path
             FROM order_items oi
             JOIN products p ON p.id = oi.product_id
             WHERE oi.order_id IN ($placeholders)
               AND (oi.fulfilling_merchant_id = ? OR oi.reseller_id = ?)
             ORDER BY oi.id ASC"
        );
        $params = array_merge($orderIds, [$userId, $userId]);
        $stmt->execute($params);
        foreach ($stmt->fetchAll() as $item) {
            $items[] = $item;
        }
    }
} catch (PDOException $e) {
    error_log('[get_orders] failed: ' . $e->getMessage());
    http_response_code(503);
    echo json_encode(['error' => 'database_unavailable']);
    exit;
}

// Group items by order_id
$itemsByOrder = [];
foreach ($items as $item) {
    $itemsByOrder[(int) $item['order_id']][] = [
        'id' => (int) $item['id'],
        'product_id' => (int) $item['product_id'],
        'product_name' => $item['product_name'],
        'image_path' => $item['image_path'],
        'parent_product_id' => $item['parent_product_id'] !== null ? (int) $item['parent_product_id'] : null,
        'quantity' => (int) $item['quantity'],
        'retail_price_pesewas' => (int) $item['retail_price_pesewas'],
        'wholesale_price_pesewas' => (int) $item['wholesale_price_pesewas'],
        'fulfilling_merchant_id' => (int) $item['fulfilling_merchant_id'],
        'reseller_id' => $item['reseller_id'] !== null ? (int) $item['reseller_id'] : null,
        'status' => $item['status'],
        'updated_at' => $item['updated_at'],
    ];
}

$result = array_map(function ($o) use ($itemsByOrder) {
    return [
        'id' => (int) $o['id'],
        'store_id' => (int) $o['store_id'],
        'customer_name' => $o['customer_name'],
        'customer_phone' => $o['customer_phone'],
        'delivery_gps' => $o['delivery_gps'],
        'delivery_street' => $o['delivery_street'],
        'delivery_instructions' => $o['delivery_instructions'],
        'subtotal_pesewas' => (int) $o['subtotal_pesewas'],
        'delivery_fee_pesewas' => (int) $o['delivery_fee_pesewas'],
        'total_paid_pesewas' => (int) $o['total_paid_pesewas'],
        'paystack_reference' => $o['paystack_reference'],
        'status' => $o['status'],
        'created_at' => $o['created_at'],
        'paid_at' => $o['paid_at'],
        'items' => $itemsByOrder[(int) $o['id']] ?? [],
    ];
}, $orders);

http_response_code(200);
echo json_encode(['orders' => $result]);
