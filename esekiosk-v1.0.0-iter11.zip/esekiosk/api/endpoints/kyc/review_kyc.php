<?php
declare(strict_types=1);

/**
 * api/endpoints/kyc/review_kyc.php
 * Admin endpoint to list pending KYC reviews and approve / reject them.
 *
 * Auth: role='admin' (enforced). CSRF token required for mutations.
 *
 * Routes (single file, action via ?op= query param):
 *   GET  ?op=list[&status=pending|approved|rejected]   → list reviews
 *   POST ?op=approve&id=<n>                            → approve a review
 *   POST ?op=reject&id=<n>&reason=<text>               → reject with reason
 */

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../config/cors.php';
require_once __DIR__ . '/../../config/env.php';
require_once __DIR__ . '/../../config/csrf.php';
require_once __DIR__ . '/../../middleware/auth.php';

header('Content-Type: application/json');

try {
    Env::load(__DIR__ . '/../../config/.env');
} catch (Throwable $e) {
    http_response_code(503);
    echo json_encode(['error' => 'server_misconfiguration']);
    exit;
}

$user = require_auth();
if ($user['role'] !== 'admin') {
    http_response_code(403);
    echo json_encode(['error' => 'admin_required']);
    exit;
}

$pdo = db();
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$op = $_GET['op'] ?? 'list';

if ($method === 'GET' && $op === 'list') {
    $status = $_GET['status'] ?? 'pending';
    if (!in_array($status, ['pending', 'approved', 'rejected'], true)) $status = 'pending';
    try {
        $stmt = $pdo->prepare(
            'SELECT k.id, k.user_id, u.username, u.email, u.momo_number, u.momo_network,
                    k.image_path, k.status, k.created_at, k.reviewed_at, k.reject_reason
             FROM kyc_reviews k
             JOIN users u ON u.id = k.user_id
             WHERE k.status = ?
             ORDER BY k.created_at DESC
             LIMIT 100'
        );
        $stmt->execute([$status]);
        echo json_encode(['reviews' => $stmt->fetchAll()]);
        exit;
    } catch (PDOException $e) {
        error_log('[review_kyc] list failed: ' . $e->getMessage());
        http_response_code(503);
        echo json_encode(['error' => 'database_unavailable']);
        exit;
    }
}

if ($method === 'POST') {
    $sessionId = find_session_id_for_current_cookie();
    if ($sessionId <= 0) {
        http_response_code(401);
        echo json_encode(['error' => 'unauthorized']);
        exit;
    }
    require_csrf($sessionId);

    $id = (int) ($_POST['id'] ?? $_GET['id'] ?? 0);
    if ($id <= 0) {
        http_response_code(400);
        echo json_encode(['error' => 'invalid_id']);
        exit;
    }

    if ($op === 'approve') {
        try {
            $pdo->beginTransaction();
            $stmt = $pdo->prepare(
                'UPDATE kyc_reviews SET status = ?, reviewed_by = ?, reviewed_at = NOW()
                 WHERE id = ? AND status = ?'
            );
            $stmt->execute(['approved', $user['id'], $id, 'pending']);
            $affected = $stmt->rowCount();
            if ($affected === 0) {
                $pdo->rollBack();
                http_response_code(409);
                echo json_encode(['error' => 'not_pending_or_not_found']);
                exit;
            }
            // Also update the user's kyc_status
            $userIdStmt = $pdo->prepare('SELECT user_id FROM kyc_reviews WHERE id = ?');
            $userIdStmt->execute([$id]);
            $reviewUserId = (int) $userIdStmt->fetchColumn();
            $pdo->prepare('UPDATE users SET kyc_status = ? WHERE id = ?')
                ->execute(['approved', $reviewUserId]);
            $pdo->commit();
            http_response_code(200);
            echo json_encode(['ok' => true, 'id' => $id, 'user_id' => $reviewUserId]);
            exit;
        } catch (PDOException $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            error_log('[review_kyc] approve failed: ' . $e->getMessage());
            http_response_code(503);
            echo json_encode(['error' => 'database_unavailable']);
            exit;
        }
    }

    if ($op === 'reject') {
        $reason = sanitize_text($_POST['reason'] ?? '');
        if (mb_strlen($reason) > 250) $reason = mb_substr($reason, 0, 250);
        try {
            $pdo->beginTransaction();
            $stmt = $pdo->prepare(
                'UPDATE kyc_reviews
                 SET status = ?, reject_reason = ?, reviewed_by = ?, reviewed_at = NOW()
                 WHERE id = ? AND status = ?'
            );
            $stmt->execute(['rejected', $reason, $user['id'], $id, 'pending']);
            $affected = $stmt->rowCount();
            if ($affected === 0) {
                $pdo->rollBack();
                http_response_code(409);
                echo json_encode(['error' => 'not_pending_or_not_found']);
                exit;
            }
            $userIdStmt = $pdo->prepare('SELECT user_id FROM kyc_reviews WHERE id = ?');
            $userIdStmt->execute([$id]);
            $reviewUserId = (int) $userIdStmt->fetchColumn();
            $pdo->prepare('UPDATE users SET kyc_status = ? WHERE id = ?')
                ->execute(['rejected', $reviewUserId]);
            $pdo->commit();
            http_response_code(200);
            echo json_encode(['ok' => true, 'id' => $id, 'user_id' => $reviewUserId]);
            exit;
        } catch (PDOException $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            error_log('[review_kyc] reject failed: ' . $e->getMessage());
            http_response_code(503);
            echo json_encode(['error' => 'database_unavailable']);
            exit;
        }
    }
}

http_response_code(400);
echo json_encode(['error' => 'unknown_op']);
