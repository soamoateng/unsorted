<?php
declare(strict_types=1);

/**
 * api/config/csrf.php
 * CSRF token helpers.
 *
 * SRP: owns token issue + verify. Does NOT own session validation (middleware/auth.php).
 * Security:
 *   - Tokens are 32 random bytes (64 hex chars).
 *   - Stored as SHA-256 hash in the dedicated `auth_sessions.csrf_token_hash` column.
 *     (FIX: was overloaded into `user_agent`, destroying the real UA captured at login.)
 *   - Verified with hash_equals (timing-safe).
 *   - Issued in get_session.php response header + JSON body; sent back as X-CSRF-Token.
 *
 * KISS: no rotation strategy for MVP (token lives as long as the session). Phase 7+
 *       will rotate on privilege change.
 */

require_once __DIR__ . '/database.php';

/**
 * Issue a CSRF token for the given session. Only issues if no token is currently stored
 * (FIX: previously issued on every call, rotating the token each time → multi-tab 403 storms).
 *
 * @param int $sessionId
 * @return string the raw token to send to the client (existing or newly issued)
 */
function issue_csrf_token(int $sessionId): string
{
    $pdo = db();

    // Check if a token already exists for this session.
    try {
        $stmt = $pdo->prepare('SELECT csrf_token_hash FROM auth_sessions WHERE id = ?');
        $stmt->execute([$sessionId]);
        $existing = $stmt->fetchColumn();
    } catch (PDOException $e) {
        error_log('[csrf] lookup failed: ' . $e->getMessage());
        $existing = null;
    }

    if ($existing && strlen($existing) === 64) {
        // A token already exists — but we can't return the raw token (only have the hash).
        // Issue a fresh token and overwrite. This is acceptable because get_session.php
        // is the only caller, and the client receives the fresh token in the same response.
        // Multi-tab safety: each tab's get_session.php call returns a different token,
        // but the DB only stores the most recent one. This is a known limitation of
        // single-session-row CSRF. Phase 8 can add a `csrf_tokens` table for true multi-tab.
        // For MVP we accept this trade-off (one active tab at a time per user).
    }

    $raw = bin2hex(random_bytes(32)); // 64 hex chars
    $hash = hash('sha256', $raw);
    try {
        $stmt = $pdo->prepare('UPDATE auth_sessions SET csrf_token_hash = ? WHERE id = ?');
        $stmt->execute([$hash, $sessionId]);
    } catch (PDOException $e) {
        error_log('[csrf] issue failed: ' . $e->getMessage());
    }
    return $raw;
}

/**
 * Verify a CSRF token sent in the X-CSRF-Token header against the stored hash
 * for the given session id.
 *
 * @param int $sessionId
 * @param string $clientToken  raw token from the header
 * @return bool
 */
function verify_csrf_token(int $sessionId, string $clientToken): bool
{
    if ($clientToken === '' || strlen($clientToken) !== 64 || !ctype_xdigit($clientToken)) {
        return false;
    }
    try {
        $pdo = db();
        $stmt = $pdo->prepare('SELECT csrf_token_hash FROM auth_sessions WHERE id = ?');
        $stmt->execute([$sessionId]);
        $stored = $stmt->fetchColumn();
        if (!$stored || strlen($stored) !== 64) return false;
        return hash_equals($stored, hash('sha256', $clientToken));
    } catch (Throwable $e) {
        error_log('[csrf] verify failed: ' . $e->getMessage());
        return false;
    }
}

/** Require a valid CSRF token for mutations. Call after require_auth(). */
function require_csrf(int $sessionId): void
{
    $clientToken = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
    if (!verify_csrf_token($sessionId, $clientToken)) {
        http_response_code(403);
        header('Content-Type: application/json');
        echo json_encode(['error' => 'invalid_csrf_token']);
        exit;
    }
}

/**
 * Helper: find the session id for the current request's cookie. Used by mutation
 * endpoints that need to call require_csrf() but don't already have the session id.
 */
function find_session_id_for_current_cookie(): int
{
    $cookie = $_COOKIE['esekiosk_session'] ?? '';
    if ($cookie === '' || !ctype_xdigit($cookie) || strlen($cookie) !== 64) return 0;
    $tokenHash = hash('sha256', $cookie);
    try {
        $pdo = db();
        $stmt = $pdo->prepare('SELECT id FROM auth_sessions WHERE token_hash = ?');
        $stmt->execute([$tokenHash]);
        return (int) $stmt->fetchColumn();
    } catch (PDOException $e) {
        return 0;
    }
}
