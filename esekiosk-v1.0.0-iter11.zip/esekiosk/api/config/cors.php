<?php
declare(strict_types=1);

/**
 * api/config/cors.php
 * CORS handling. Allows the configured origin with credentials.
 *
 * SRP: owns CORS headers. Nothing else.
 * Security: dynamic origin whitelist (no `*` because we need credentials).
 *
 * Verification: MDN — Access-Control-Allow-Credentials requires explicit origin (never `*`).
 */

require __DIR__ . '/env.php';

function apply_cors(): void
{
    try {
        Env::load(__DIR__ . '/.env');
    } catch (Throwable $e) {
        // Skip CORS if env is broken; the database.php will 503 anyway.
        return;
    }

    $allowed = Env::get('APP_ALLOWED_ORIGINS', 'http://localhost:8080,http://localhost:3000');
    $allowedList = array_map('trim', explode(',', $allowed));
    $origin = $_SERVER['HTTP_ORIGIN'] ?? '';

    if ($origin && in_array($origin, $allowedList, true)) {
        header('Access-Control-Allow-Origin: ' . $origin);
        header('Access-Control-Allow-Credentials: true');
        header('Vary: Origin');
        header('Access-Control-Allow-Methods: GET, POST, PATCH, DELETE, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type, X-CSRF-Token, X-Requested-With');
        header('Access-Control-Max-Age: 600');
    }

    // Preflight
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'OPTIONS') {
        http_response_code(204);
        exit;
    }
}

apply_cors();
