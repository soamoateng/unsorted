<?php
declare(strict_types=1);

/**
 * api/config/paystack.php
 * Paystack helpers: signature verification + MAX_SPLITS constant.
 *
 * SRP: owns Paystack crypto + limits. Nothing else.
 * Security:
 *   - hash_equals() for timing-safe comparison (prevents timing attacks).
 *   - HMAC-SHA512 (not SHA256) — verified against Paystack docs (Aug 2026).
 *   - MAX_SPLITS is a self-imposed cap (Paystack does NOT document a hard limit).
 *
 * Sources:
 *   https://paystack.com/docs/webhooks
 *   https://hookdeck.com — "HMAC-SHA512, not SHA256" (Jul 22 2026)
 *   https://www.mctaba.com — "Paystack Multi-Split Payments Explained" (Jul 22 2026)
 */

require __DIR__ . '/env.php';

/** Self-imposed cap on subaccounts per transaction. NOT a Paystack limit. */
const MAX_SPLITS = 5;

/**
 * Verify the x-paystack-signature header for a raw webhook body.
 *
 * @param string $rawBody  file_get_contents('php://input')
 * @param string $signatureFromHeader  $_SERVER['HTTP_X_PAYSTACK_SIGNATURE'] ?? ''
 * @return bool
 */
function verify_paystack_signature(string $rawBody, string $signatureFromHeader): bool
{
    if ($signatureFromHeader === '' || $rawBody === '') return false;
    try {
        $secret = Env::require('PAYSTACK_SECRET_KEY');
    } catch (Throwable $e) {
        error_log('[paystack] secret key missing during signature verify');
        return false;
    }
    $expected = hash_hmac('sha512', $rawBody, $secret);
    return hash_equals($expected, $signatureFromHeader);
}

/** Returns the Paystack secret key. Caller decides whether to use it for API calls or signature verify. */
function paystack_secret_key(): string
{
    return Env::require('PAYSTACK_SECRET_KEY');
}

/** Returns the Paystack public key (safe to expose to the frontend via an endpoint). */
function paystack_public_key(): string
{
    return Env::require('PAYSTACK_PUBLIC_KEY');
}
