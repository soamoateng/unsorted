<?php
declare(strict_types=1);

/**
 * api/config/env.php
 * Single source of truth for environment-variable loading. Every other config
 * file requires this. The .env file is gitignored; only .env.example is committed.
 *
 * SRP: owns env parsing + caching. Nothing else.
 * DIP: every config file depends on this abstraction, never on $_SERVER directly.
 *
 * Usage:
 *   require __DIR__ . '/env.php';
 *   Env::load(__DIR__ . '/.env');
 *   $key = Env::require('PAYSTACK_SECRET_KEY');
 */

final class Env
{
    private static array $cache = [];
    private static bool $loaded = false;

    public static function load(string $path): void
    {
        if (self::$loaded) return;
        self::$loaded = true;

        if (!is_readable($path)) {
            throw new RuntimeException('Env file not readable: ' . $path);
        }
        $lines = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        if ($lines === false) {
            throw new RuntimeException('Env file unreadable: ' . $path);
        }
        foreach ($lines as $line) {
            if ($line === '' || $line[0] === '#') continue;
            if (!str_contains($line, '=')) continue;
            [$k, $v] = explode('=', $line, 2);
            $k = trim($k);
            $v = trim($v, " \t\"'");
            self::$cache[$k] = $v;
            putenv("{$k}={$v}");
            $_ENV[$k] = $v;
        }
    }

    /** Returns null if the var is missing or empty. */
    public static function get(string $key, ?string $default = null): ?string
    {
        if (array_key_exists($key, self::$cache)) return self::$cache[$key];
        $v = getenv($key);
        if ($v === false || $v === '') return $default;
        return $v;
    }

    /** Throws if the var is missing or empty. Use for hard-required keys. */
    public static function require(string $key): string
    {
        $v = self::get($key);
        if ($v === null || $v === '') {
            throw new RuntimeException('Missing required env var: ' . $key);
        }
        return $v;
    }
}
