<?php
declare(strict_types=1);

/**
 * api/config/database.php
 * PDO connection factory. Every endpoint imports this via `require __DIR__ . '/config/database.php';`
 *
 * SRP: owns the PDO connection. Nothing else.
 * Security: PDO::ERRMODE_EXCEPTION, FETCH_ASSOC, prepared statements enforced by convention.
 * Verification: PHP 8.0+ default error mode is now ERRMODE_EXCEPTION (php.watch/8.0/pdo-default-error-mode),
 *                but we set it explicitly to be safe across hosts.
 *
 * Returns a PDO instance. Throws RuntimeException on failure (503 from the caller).
 */

require __DIR__ . '/env.php';

function db(): PDO
{
    static $pdo = null;
    if ($pdo instanceof PDO) return $pdo;

    try {
        Env::load(__DIR__ . '/.env');
    } catch (Throwable $e) {
        http_response_code(503);
        header('Content-Type: application/json');
        echo json_encode(['error' => 'server_misconfiguration']);
        exit;
    }

    try {
        $host = Env::get('DB_HOST', 'localhost');
        $name = Env::require('DB_NAME');
        $user = Env::require('DB_USER');
        $pass = Env::require('DB_PASSWORD');
        $charset = 'utf8mb4';

        $dsn = "mysql:host={$host};dbname={$name};charset={$charset}";
        $pdo = new PDO($dsn, $user, $pass, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,  // real prepared statements — prevents edge-case SQLi
            PDO::ATTR_PERSISTENT => false,
        ]);
        return $pdo;
    } catch (PDOException $e) {
        // Never leak the DSN or SQL message to the client.
        error_log('[database] PDO connect failed: ' . $e->getMessage());
        http_response_code(503);
        header('Content-Type: application/json');
        echo json_encode(['error' => 'database_unavailable']);
        exit;
    } catch (Throwable $e) {
        error_log('[database] init failed: ' . $e->getMessage());
        http_response_code(503);
        header('Content-Type: application/json');
        echo json_encode(['error' => 'server_misconfiguration']);
        exit;
    }
}
