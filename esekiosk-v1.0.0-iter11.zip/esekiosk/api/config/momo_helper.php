<?php
declare(strict_types=1);

/**
 * api/config/momo_helper.php
 * Maps user-selected MoMo network → Paystack bank_code.
 *
 * SRP: owns the network → bank code map. Nothing else.
 *
 * IMPORTANT (from prior stress tests):
 *   - Vodafone Ghana rebranded to Telecel Ghana in February 2024.
 *     In August 2026, the network is "Telecel", MoMo product is "Telecel Cash".
 *   - Mobile Number Portability (MNP) means prefix-based detection is unreliable.
 *     The user explicitly selects their network at signup; we trust that selection.
 *   - The bank codes below must be resolved from Paystack's GET /list_banks?country=gh
 *     on first deploy and cached. Hardcoded here for MVP; refresh once per year.
 *
 * Sources:
 *   https://paystack.com/docs/banks/list  (GET /bank?country=gh)
 *   https://support.paystack.com — "Telecel (formerly called Vodafone)" for Ghana MoMo
 *   https://en.wikipedia.org/wiki/Telecel_Ghana
 */

const MOMO_NETWORKS = [
    'MTN'     => ['product' => 'MTN Mobile Money',     'bank_code' => 'MTN'],
    'TELECEL' => ['product' => 'Telecel Cash',         'bank_code' => 'VOD'], // Paystack keeps 'VOD' code for Telecel as of Aug 2026
    'AT'      => ['product' => 'AirtelTigo Money',     'bank_code' => 'ATL'],
];

/**
 * Returns the Paystack bank code for a user-selected network.
 * @param string $network 'MTN' | 'TELECEL' | 'AT'
 * @return string bank_code (e.g. 'MTN', 'VOD', 'ATL')
 * @throws InvalidArgumentException if network is unknown
 */
function resolve_bank_code(string $network): string
{
    $network = strtoupper(trim($network));
    if (!isset(MOMO_NETWORKS[$network])) {
        throw new InvalidArgumentException("Unknown MoMo network: {$network}");
    }
    return MOMO_NETWORKS[$network]['bank_code'];
}

/** Returns the MoMo product display name. */
function momo_product_name(string $network): string
{
    $network = strtoupper(trim($network));
    return MOMO_NETWORKS[$network]['product'] ?? 'Unknown';
}

/** Returns true if the network string is one we recognise. */
function is_valid_momo_network(string $network): bool
{
    return isset(MOMO_NETWORKS[strtoupper(trim($network))]);
}
