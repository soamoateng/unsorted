<?php
declare(strict_types=1);

/**
 * api/middleware/sanitize.php
 * Input validation + cleaning helpers.
 *
 * FIX (Task 10 C1): `sanitize_string` HTML-encodes its input, which is correct for
 * output escaping but WRONG for DB storage. Storing HTML-encoded values means:
 *   - Login comparisons fail (raw input vs encoded DB value)
 *   - Frontend double-escapes (escapeHTML on an already-encoded string → &amp;amp;)
 * The new `sanitize_username` uses a regex allowlist (no encoding) for DB-bound fields.
 * `sanitize_string` is kept for fields that are ONLY rendered in HTML (e.g., product
 * description displayed via textContent — actually textContent doesn't need encoding
 * either, but keeping it as defense-in-depth for any future innerHTML path).
 *
 * SRP: owns input validation. Does NOT own output escaping (frontend's escapeHTML does).
 *
 * Verification: OWASP Input Validation Cheat Sheet
 *   https://cheatsheetseries.owasp.org/cheatsheets/Input_Validation_Cheat_Sheet.html
 */

/**
 * Strip tags + HTML-entity-encode for safe HTML-context interpolation.
 * WARNING: use ONLY for values that will be interpolated into innerHTML templates.
 * Do NOT use for DB-bound fields that will be compared against raw user input (e.g., username).
 * For DB-bound text fields, use `sanitize_text` (raw, tag-stripped) or a specific validator.
 */
function sanitize_string(string $input): string
{
    return htmlspecialchars(strip_tags($input), ENT_QUOTES | ENT_HTML5, 'UTF-8');
}

/**
 * FIX (Task 10 C1): Strip tags but DO NOT HTML-encode. Use for DB-bound text fields
 * (product name, description, customer name, delivery street, etc.). The frontend's
 * escapeHTML handles output encoding; storing raw avoids the login-comparison break
 * and the double-encoding display bug.
 */
function sanitize_text(string $input): string
{
    return strip_tags(trim($input));
}

/**
 * FIX (Task 10 C1): Username validator — allowlist of safe chars, no HTML encoding.
 * Stores the raw username so login comparisons work. Returns null on invalid input.
 */
function sanitize_username(string $input): ?string
{
    $v = trim($input);
    if (preg_match('/^[A-Za-z0-9_.-]{3,50}$/', $v)) return $v;
    return null;
}

/** Trim + lowercase + basic email format check. Does NOT verify deliverability. */
function sanitize_email(string $input): ?string
{
    $v = trim(strtolower($input));
    if ($v === '' || !filter_var($v, FILTER_VALIDATE_EMAIL)) return null;
    return $v;
}

/** Strip non-digits, require exactly 10 (Ghana mobile format /^0\d{9}$/). */
function sanitize_phone(string $input): ?string
{
    $v = preg_replace('/\D+/', '', $input);
    if ($v === null || strlen($v) !== 10 || $v[0] !== '0') return null;
    return $v;
}

/** Validate GhanaPost GPS format AA-NNN-NNNN (case-insensitive, uppercased on return). */
function sanitize_gps(string $input): ?string
{
    $v = strtoupper(trim($input));
    if (preg_match('/^[A-Z]{2}-\d{3}-\d{4}$/', $v)) return $v;
    return null;
}

/** Validate Ghana mobile money network selection (one of MTN/TELECEL/AT). */
function sanitize_momo_network(string $input): ?string
{
    $v = strtoupper(trim($input));
    return in_array($v, ['MTN', 'TELECEL', 'AT'], true) ? $v : null;
}

/** Validate a role selection — clients can submit this but the DB whitelists; we
 *  reject 'admin' sent from the client to prevent privilege escalation. */
function sanitize_role(string $input): ?string
{
    $v = strtolower(trim($input));
    if ($v === 'admin') return null; // never accept admin from client
    return in_array($v, ['merchant', 'reseller'], true) ? $v : null;
}

/** Validate a subscription cycle. */
function sanitize_cycle(string $input): ?string
{
    $v = strtolower(trim($input));
    return in_array($v, ['monthly', 'quarterly', 'yearly'], true) ? $v : null;
}
