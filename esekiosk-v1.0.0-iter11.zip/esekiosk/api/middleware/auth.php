<?php
declare(strict_types=1);

/**
 * api/middleware/auth.php
 * Validates the esekiosk_session HttpOnly cookie, looks up the auth_sessions row,
 * and loads the user. Returns 401 if no valid session.
 *
 * SRP: owns authentication. Does NOT own authorization (role checks are the caller's job).
 * Security:
 *   - Cookie = raw token (64 hex chars from random_bytes(32)).
 *   - DB stores hash('sha256', $rawToken). Lookup uses the hash, never the raw.
 *   - Subscription expiry is enforced: expired → 403 subscription_expired (SPA → #/renew).
 *     Admin role is exempt (admins don't have subscriptions).
 *
 * Usage in an endpoint:
 *   require __DIR__ . '/../middleware/auth.php';
 *   $user = require_auth();        // exits 401/403 if not signed in / expired
 *   if ($user['role'] !== 'admin') { http 403 }
 */

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/cors.php';

/**
 * Internal: load the user from the session cookie. Returns the user array or null.
 * Does NOT exit — callers (require_auth / optional_auth) decide what to do on null.
 */
function _load_user_from_session(): ?array
{
    $cookie = $_COOKIE['esekiosk_session'] ?? '';
    if ($cookie === '' || !ctype_xdigit($cookie) || strlen($cookie) !== 64) return null;
    $tokenHash = hash('sha256', $cookie);

    try {
        $pdo = db();
        $stmt = $pdo->prepare(
            'SELECT u.id, u.username, u.email, u.role, u.momo_number, u.momo_network,
                    u.ghana_post_gps, u.store_slug, u.subaccount_code, u.subaccount_pending,
                    u.kyc_status, u.subscription_cycle, u.subscription_expiry, u.active,
                    u.payouts_paused_at,
                    s.expires_at
             FROM auth_sessions s
             JOIN users u ON u.id = s.user_id
             WHERE s.token_hash = ?'
        );
        $stmt->execute([$tokenHash]);
        $row = $stmt->fetch();
    } catch (PDOException $e) {
        error_log('[auth] session lookup failed: ' . $e->getMessage());
        return null;
    }

    if (!$row) return null;

    if (strtotime($row['expires_at']) < time()) return null;

    unset($row['expires_at']);
    return $row;
}

/**
 * Require a valid authenticated session. Exits 401 if missing/expired,
 * 403 if subscription expired (and role is not admin). Returns the user array.
 */
function require_auth(): array
{
    $user = _load_user_from_session();

    if (!$user) {
        http_response_code(401);
        header('Content-Type: application/json');
        echo json_encode(['error' => 'unauthorized']);
        exit;
    }

    // FIX (Task 10 M1): block inactive (unpaid) users from calling protected endpoints.
    // A user who signed up but never paid has active=0 and no subscription_expiry.
    // The subscription-expiry check below skips them (because subscription_expiry IS NULL),
    // so without this check they can log in and call add_product, clone_product, etc.
    if ($user['role'] !== 'admin' && (int)$user['active'] !== 1) {
        http_response_code(403);
        header('Content-Type: application/json');
        echo json_encode(['error' => 'account_not_active']);
        exit;
    }

    // Subscription expiry enforcement (Phase 7 — uncommented from the Phase 1 stub).
    // Admin role is exempt (admins don't have subscriptions).
    if ($user['role'] !== 'admin'
        && $user['subscription_expiry'] !== null
        && $user['subscription_expiry'] < date('Y-m-d')) {
        http_response_code(403);
        header('Content-Type: application/json');
        echo json_encode(['error' => 'subscription_expired']);
        exit;
    }

    return $user;
}

/**
 * Returns the current user or null (does not exit). Useful for endpoints that
 * degrade gracefully when auth is missing (e.g., storefront shows public data,
 * wholesale browse falls back to 401 only when wholesale=1 is requested).
 *
 * FIX: previously called require_auth() inside try/catch, but require_auth()
 * exits on failure — the catch was unreachable. Now does the lookup directly.
 */
function optional_auth(): ?array
{
    return _load_user_from_session();
}
