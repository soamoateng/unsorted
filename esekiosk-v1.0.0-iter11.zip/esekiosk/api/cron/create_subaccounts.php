#!/usr/bin/env php
<?php
declare(strict_types=1);

/**
 * api/cron/create_subaccounts.php
 * CLI script: retries Paystack subaccount creation for users with subaccount_pending=1.
 *
 * Run via cron every 5 minutes:
 *   */5 * * * * /usr/bin/php /path/to/esekiosk/api/cron/create_subaccounts.php >> /var/log/esekiosk-cron.log 2>&1
 *
 * Or manually:
 *   php api/cron/create_subaccounts.php
 *
 * For each user with subaccount_pending=1:
 *   1. Look up the user's momo_number + momo_network.
 *   2. Resolve the Paystack bank_code via momo_helper.php.
 *   3. Call Paystack subaccount/create.
 *   4. On success: store subaccount_code, clear subaccount_pending.
 *   5. On failure: log; the cron retries on the next run.
 *
 * Exits 0 on success, 1 on env load failure.
 */

require_once __DIR__ . '/../config/env.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/paystack.php';
require_once __DIR__ . '/../config/momo_helper.php';

try {
    Env::load(__DIR__ . '/../config/.env');
} catch (Throwable $e) {
    fwrite(STDERR, "[create_subaccounts] env load failed: " . $e->getMessage() . "\n");
    exit(1);
}

$pdo = db();

// FIX: re-arm any "in_progress" (subaccount_pending=2) rows from a previous crashed cron run.
// If the previous run died between the in-progress flag and the Paystack call, those users
// would be stuck at =2 forever (the SELECT WHERE subaccount_pending=1 would never pick them up).
try {
    $pdo->exec("UPDATE users SET subaccount_pending = 1 WHERE subaccount_pending = 2");
} catch (PDOException $e) {
    fwrite(STDERR, "[create_subaccounts] failed to re-arm stale in_progress rows: " . $e->getMessage() . "\n");
    // Non-fatal — continue with whatever =1 rows exist
}

// FIX: idempotency — use a transaction with FOR UPDATE + a 3-state flag (0=pending, 1=done, 2=in_progress)
// to prevent concurrent cron runs from creating duplicate subaccounts at Paystack.
// We reuse subaccount_pending as a 2-state (1=pending, 0=done). To mark in-progress,
// we wrap the SELECT+UPDATE atomically.
try {
    $pdo->beginTransaction();
    $stmt = $pdo->query(
        "SELECT id, username, momo_number, momo_network
         FROM users
         WHERE subaccount_pending = 1 AND subaccount_code IS NULL
         ORDER BY created_at ASC
         LIMIT 50
         FOR UPDATE"
    );
    $pending = $stmt->fetchAll();
    // Mark them as "in progress" by setting subaccount_pending = 2 within the transaction.
    // The cron will set it to 0 (done) on success or back to 1 (retry) on failure.
    if (!empty($pending)) {
        $ids = array_column($pending, 'id');
        $placeholders = implode(',', array_fill(0, count($ids), '?'));
        $pdo->prepare("UPDATE users SET subaccount_pending = 2 WHERE id IN ($placeholders)")
            ->execute($ids);
    }
    $pdo->commit();
} catch (PDOException $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    fwrite(STDERR, "[create_subaccounts] query failed: " . $e->getMessage() . "\n");
    exit(1);
}

if (empty($pending)) {
    fwrite(STDOUT, "[create_subaccounts] no pending users\n");
    exit(0);
}

$success = 0;
$fail = 0;

foreach ($pending as $u) {
    $userId = (int) $u['id'];
    $momoNumber = $u['momo_number'];
    $network = $u['momo_network'];

    try {
        $bankCode = resolve_bank_code($network);
    } catch (Throwable $e) {
        fwrite(STDERR, "[create_subaccounts] user {$userId} bad network '{$network}': " . $e->getMessage() . "\n");
        $fail++;
        continue;
    }

    $payload = [
        'business_name' => $u['username'] . ' (Esekiosk)',
        'settlement_bank' => $bankCode,
        'account_number' => $momoNumber,
        'percentage_charge' => 0,
        'description' => 'Esekiosk ' . $network . ' MoMo subaccount (cron retry)',
    ];

    $ch = curl_init('https://api.paystack.co/subaccount');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => json_encode($payload),
        CURLOPT_HTTPHEADER => [
            'Authorization: Bearer ' . paystack_secret_key(),
            'Content-Type: application/json',
        ],
        CURLOPT_TIMEOUT => 15,
    ]);
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlErr = curl_error($ch);
    curl_close($ch);

    if ($response === false || $httpCode < 200 || $httpCode >= 300) {
        fwrite(STDERR, "[create_subaccounts] user {$userId} Paystack failed: HTTP {$httpCode} err={$curlErr}\n");
        // FIX: revert to pending=1 so the next cron run retries
        try {
            $pdo->prepare('UPDATE users SET subaccount_pending = 1 WHERE id = ?')->execute([$userId]);
        } catch (PDOException $e) { /* log only */ }
        $fail++;
        // FIX: small sleep to avoid hammering Paystack if many users fail with 429
        usleep(200_000);
        continue;
    }

    $ps = json_decode($response, true);
    $subCode = $ps['data']['subaccount_code'] ?? null;
    if (!$subCode) {
        fwrite(STDERR, "[create_subaccounts] user {$userId} no subaccount_code in response\n");
        try {
            $pdo->prepare('UPDATE users SET subaccount_pending = 1 WHERE id = ?')->execute([$userId]);
        } catch (PDOException $e) { /* log only */ }
        $fail++;
        continue;
    }

    try {
        // FIX: set subaccount_pending = 0 (done) + store the code
        $upd = $pdo->prepare('UPDATE users SET subaccount_code = ?, subaccount_pending = 0 WHERE id = ?');
        $upd->execute([$subCode, $userId]);
        $success++;
        fwrite(STDOUT, "[create_subaccounts] user {$userId} → subaccount {$subCode}\n");
    } catch (PDOException $e) {
        fwrite(STDERR, "[create_subaccounts] user {$userId} DB update failed: " . $e->getMessage() . "\n");
        // FIX: the subaccount was created at Paystack but we couldn't store the code.
        // Log it so an admin can manually reconcile.
        fwrite(STDERR, "[create_subaccounts] ORPHAN SUBACCOUNT: user {$userId} code {$subCode} — store manually!\n");
        // Revert to pending=1 so the cron retries (will likely create a duplicate at Paystack,
        // but the admin can clean up using the logged orphan code).
        try {
            $pdo->prepare('UPDATE users SET subaccount_pending = 1 WHERE id = ?')->execute([$userId]);
        } catch (PDOException $e2) { /* log only */ }
        $fail++;
    }
}

fwrite(STDOUT, "[create_subaccounts] done: {$success} success, {$fail} fail\n");
exit(0);
